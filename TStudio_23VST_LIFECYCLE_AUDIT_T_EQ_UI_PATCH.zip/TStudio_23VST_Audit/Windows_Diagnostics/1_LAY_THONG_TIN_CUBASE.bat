@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Collect-CubaseInfo.ps1"
if errorlevel 1 echo Khong thu thap duoc day du. Giu lai noi dung loi tren man hinh.
pause
