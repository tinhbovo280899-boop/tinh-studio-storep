param([string[]]$AdditionalVst3Paths = @())
$ErrorActionPreference = 'Stop'
$outDir = Join-Path $PSScriptRoot ('KetQua_Cubase_' + (Get-Date -Format 'yyyyMMdd_HHmmss'))
New-Item -ItemType Directory -Path $outDir -Force | Out-Null
$problems = New-Object 'System.Collections.Generic.List[string]'
$processRows = @(Get-Process -ErrorAction SilentlyContinue | Where-Object { $_.ProcessName -like '*Cubase*' } | ForEach-Object {
    $p = $_
    $v = $null
    try { $v = $p.MainModule.FileVersionInfo } catch { $problems.Add($_.Exception.Message) }
    [pscustomobject]@{ Name=$p.ProcessName; ProcessId=$p.Id; Responding=$p.Responding; FileVersion=$v.FileVersion; ProductVersion=$v.ProductVersion; Path=$v.FileName; MemoryBytes=$p.WorkingSet64 }
})
ConvertTo-Json -InputObject $processRows -Depth 5 | Set-Content -LiteralPath (Join-Path $outDir 'Cubase-process.json') -Encoding UTF8
$roots = @((Join-Path $env:CommonProgramFiles 'VST3'), (Join-Path $env:LOCALAPPDATA 'Programs\Common\VST3'), (Join-Path $env:ProgramFiles 'Steinberg\VST3')) + $AdditionalVst3Paths
$modules = New-Object 'System.Collections.Generic.List[object]'
foreach ($scanRoot in ($roots | Select-Object -Unique)) {
    if (-not (Test-Path -LiteralPath $scanRoot -PathType Container)) { continue }
    $scanErrors = @()
    $items = @(Get-ChildItem -LiteralPath $scanRoot -Recurse -Filter '*.vst3' -ErrorAction SilentlyContinue -ErrorVariable scanErrors)
    foreach ($failure in $scanErrors) { $problems.Add($failure.Exception.Message) }
    foreach ($item in $items) {
        $metadata = $null; $binary = $null; $hash = $null; $fileVersion = $null
        $jsonFile = Join-Path $item.FullName 'Contents\Resources\moduleinfo.json'
        if ($item.PSIsContainer -and (Test-Path -LiteralPath $jsonFile -PathType Leaf)) {
            try {
                # Steinberg moduleinfo.json may contain trailing commas. Preserve
                # quoted strings while removing only commas before closing braces.
                $rawJson = Get-Content -LiteralPath $jsonFile -Raw
                $strictJson = [regex]::Replace($rawJson, '("(?:\\.|[^"\\])*")|,\s*(?=[}\]])', {
                    param($match)
                    if ($match.Groups[1].Success) { return $match.Value }
                    return ''
                })
                $metadata = $strictJson | ConvertFrom-Json
            } catch { $problems.Add('moduleinfo: ' + $jsonFile + ': ' + $_.Exception.Message) }
        }
        $isTStudio = $item.BaseName -match '^(T-|TStudio|T Studio|T-AUTO|NT[- ])' -or ($null -ne $metadata -and $metadata.'Factory Info'.Vendor -match 'T Studio|NT Studio')
        if ($isTStudio) {
            if ($item.PSIsContainer) {
                $binary = Get-ChildItem -LiteralPath $item.FullName -Recurse -File -Filter '*.vst3' -ErrorAction SilentlyContinue | Where-Object { $_.FullName -match 'x86_64-win' } | Select-Object -First 1
            } else { $binary = $item }
            if ($null -ne $binary) {
                try { $hash=(Get-FileHash -LiteralPath $binary.FullName -Algorithm SHA256).Hash; $fileVersion=$binary.VersionInfo.FileVersion } catch { $problems.Add($_.Exception.Message) }
            }
        }
        $modules.Add([pscustomobject]@{ Name=$item.Name; Path=$item.FullName; LastWrite=$item.LastWriteTime.ToString('o'); TStudioCandidate=[bool]$isTStudio; Binary=$binary.FullName; Sha256=$hash; FileVersion=$fileVersion; ModuleInfo=$metadata })
    }
}
ConvertTo-Json -InputObject @($modules.ToArray()) -Depth 12 | Set-Content -LiteralPath (Join-Path $outDir 'VST3-inventory.json') -Encoding UTF8
try {
    $events = @(Get-WinEvent -FilterHashtable @{LogName='Application'; Id=1000,1001,1002; StartTime=(Get-Date).AddDays(-7)} -ErrorAction Stop | Where-Object { $_.Message -match '(?i)Cubase' } | Select-Object -Property @('TimeCreated','Id','ProviderName','Message'))
    ConvertTo-Json -InputObject $events -Depth 5 | Set-Content -LiteralPath (Join-Path $outDir 'Cubase-events.json') -Encoding UTF8
} catch { $problems.Add('Application event log: ' + $_.Exception.Message) }
$dumpDirs = @((Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Steinberg\CrashDumps'), (Join-Path $env:LOCALAPPDATA 'CrashDumps'))
$dumps = @(foreach ($dumpDir in $dumpDirs) {
    if (Test-Path -LiteralPath $dumpDir -PathType Container) {
        Get-ChildItem -LiteralPath $dumpDir -File -ErrorAction SilentlyContinue | Where-Object { $_.Name -match '(?i)Cubase' } | Sort-Object LastWriteTime -Descending | Select-Object -First 15 -Property @('Name','FullName','Length','LastWriteTime')
    }
})
ConvertTo-Json -InputObject $dumps -Depth 5 | Set-Content -LiteralPath (Join-Path $outDir 'Existing-dump-file-list.json') -Encoding UTF8
$problems | Set-Content -LiteralPath (Join-Path $outDir 'Read-errors.txt') -Encoding UTF8
@'
Please add: Cubase version, Windows version, ASIO driver and buffer size,
the last plugin added/removed, and whether its editor or a menu was open.
This tool reads metadata/event logs. It does not load any VST, terminate Cubase,
change licensing, delete files, or upload the results.
'@ | Set-Content -LiteralPath (Join-Path $outDir 'Ghi-chu.txt') -Encoding UTF8
$zipPath = $outDir + '.zip'
Compress-Archive -LiteralPath $outDir -DestinationPath $zipPath -CompressionLevel Optimal
Write-Host ('Da tao ZIP thong tin: ' + $zipPath)
