param([string]$SourceRoot)
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($SourceRoot)) { $SourceRoot = Read-Host 'Nhap duong dan thu muc T-Studio_Plugins da giai nen' }
$SourceRoot = $SourceRoot.Trim().Trim('"')
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH_MANIFEST.json') -Raw | ConvertFrom-Json
$pending = @()
foreach ($entry in $manifest.files) {
    $target = Join-Path $SourceRoot $entry.path
    $source = Join-Path (Join-Path $PSScriptRoot 'files') $entry.path
    if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw ('Khong tim thay file: ' + $target) }
    $actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -eq $entry.after_sha256) { continue }
    if ($actual -ne $entry.before_sha256) { throw ('File da thay doi so voi ZIP goc; dung de tranh ghi de: ' + $target) }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.after_sha256) { throw ('Ban va sai SHA256: ' + $source) }
    $backup = $target + '.before-t-eq-ui-fix'
    if (Test-Path -LiteralPath $backup) { throw ('Da co file sao luu; kiem tra truoc khi chay tiep: ' + $backup) }
    $pending += [pscustomobject]@{Target=$target; Source=$source; Backup=$backup; Expected=$entry.after_sha256}
}
foreach ($entry in $pending) {
    Copy-Item -LiteralPath $entry.Target -Destination $entry.Backup
    Copy-Item -LiteralPath $entry.Source -Destination $entry.Target -Force
    if ((Get-FileHash -LiteralPath $entry.Target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Expected) { throw ('Kiem tra sau khi ghi that bai: ' + $entry.Target) }
}
Write-Host 'Da ap dung/da co ban va menu T-EQ 2.0.5. Can build lai tren Windows/macOS bang script cua du an goc.'
Write-Host 'Day chua phai xac nhan da sua dung nguyen nhan Cubase treo.'
