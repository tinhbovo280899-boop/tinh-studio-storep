@echo off
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply-T_EQ_UI_Fix.ps1" %*
if errorlevel 1 echo Chua ap dung xong. Doc ly do tren man hinh.
pause
