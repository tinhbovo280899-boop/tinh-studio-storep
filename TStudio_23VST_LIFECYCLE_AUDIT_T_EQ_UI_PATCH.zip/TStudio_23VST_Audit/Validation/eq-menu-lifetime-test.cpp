#include <juce_dsp/juce_dsp.h>
#include "NTEqProcessor.h"
#include "HwKit.h"
// Test-only access to the actual callback used by showBandMenu().
#define private public
#include "HwEditor.h"
#undef private
#include <cstdio>
int main(){
 juce::ScopedJuceInitialiser_GUI init;
 int checks=0;
 for(int n=0;n<24;++n){
  auto processor=std::make_unique<NTEqProcessor>();
  auto editor=std::make_unique<teq_hw::Editor>(*processor);
  const int band=1+n%8;
  auto callback=editor->bandMenuCallback(band);
  callback(101);
  auto* place=processor->apvts.getRawParameterValue(NTEqProcessor::bandParamId(band,"place"));
  if(!place || std::abs(place->load()-1.0f)>.001f)return 1;
  ++checks;
  editor.reset();
  // Queued positive, cancelled, slope and toggle results after editor removal
  // must all be inert, including before the processor has been removed.
  callback(100);callback(203);callback(300);callback(0);
  if(std::abs(place->load()-1.0f)>.001f)return 2;
  checks+=4;
  processor.reset();
  callback(100);callback(203);callback(300);callback(0);checks+=4;
  juce::MessageManager::getInstance()->runDispatchLoopUntil(5);
 }
 std::printf("EQ menu lifetime: %d checks passed; live callbacks work, queued callbacks after destruction are inert.\n",checks);
}
