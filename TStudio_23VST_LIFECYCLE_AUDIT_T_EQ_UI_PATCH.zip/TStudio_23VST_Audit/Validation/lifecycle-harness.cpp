#include <juce_audio_utils/juce_audio_utils.h>
#include <atomic>
#include <thread>
#include <chrono>
#include <cstdio>
#include <cmath>
extern juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
#if defined(QA_AUTOTUNE)
#include "TAutoTuneProcessor.h"
#endif
static thread_local bool inAudio=false;
struct Listener : juce::AudioProcessorListener {
 std::atomic<int> audioParameterNotifications{0}, audioLatencyNotifications{0};
 void audioProcessorParameterChanged(juce::AudioProcessor*,int,float) override{if(inAudio)++audioParameterNotifications;}
 void audioProcessorChanged(juce::AudioProcessor*,const ChangeDetails& d)override{if(inAudio && d.latencyChanged)++audioLatencyNotifications;}
};
using Clock=std::chrono::steady_clock;
static double ms(Clock::time_point begin){return std::chrono::duration<double,std::milli>(Clock::now()-begin).count();}
int main(int argc,char**argv){
 juce::ScopedJuceInitialiser_GUI init;
 const int cycles=argc>1?std::atoi(argv[1]):8;
 double maxCreate=0,maxEditor=0,maxClose=0;int finiteErrors=0, rtParams=0, rtLatency=0;
 for(int n=0;n<cycles;++n){
  auto start=Clock::now();std::unique_ptr<juce::AudioProcessor> p(createPluginFilter());maxCreate=std::max(maxCreate,ms(start));
  std::printf("CYCLE %d %s created %.2f ms\n",n,p->getName().toRawUTF8(),ms(start));std::fflush(stdout);
  if(n%4==0){p.reset();juce::MessageManager::getInstance()->runDispatchLoopUntil(3);continue;}
  Listener listener;p->addListener(&listener);
  const double rate=n%2?48000:96000;
  p->setRateAndBufferSizeDetails(rate,128);p->prepareToPlay(rate,128);
  juce::MemoryBlock state;p->getStateInformation(state);p->setStateInformation(state.getData(),(int)state.getSize());
  std::atomic<bool> running{true};
  std::thread audio([&]{juce::AudioBuffer<float> b(std::max(2,p->getTotalNumOutputChannels()),128);juce::MidiBuffer midi;int block=0;
   while(running.load()){
    for(int ch=0;ch<b.getNumChannels();++ch)for(int i=0;i<128;++i)b.setSample(ch,i,.08f*std::sin(6.283185307179586*220*(block*128+i)/rate));
    {const juce::ScopedLock lock(p->getCallbackLock());inAudio=true;p->processBlock(b,midi);inAudio=false;}
    for(int ch=0;ch<b.getNumChannels();++ch)for(int i=0;i<128;++i)if(!std::isfinite(b.getSample(ch,i)))++finiteErrors;
    ++block;std::this_thread::sleep_for(std::chrono::milliseconds(2));
   }
  });
  start=Clock::now();std::unique_ptr<juce::AudioProcessorEditor> ed(p->createEditor());maxEditor=std::max(maxEditor,ms(start));
  if(ed){
   ed->setVisible(true);juce::MessageManager::getInstance()->runDispatchLoopUntil(135);
   if(n==1){
    for(auto* parameter:p->getParameters()) if(auto* id=dynamic_cast<juce::AudioProcessorParameterWithID*>(parameter))
     if(id->paramID=="mode" || id->paramID=="lookahead") parameter->setValueNotifyingHost(1.0f);
    juce::MessageManager::getInstance()->runDispatchLoopUntil(150);
   }
#if defined(QA_AUTOTUNE)
   if(n==1){auto* tune=dynamic_cast<TAutoTuneProcessor*>(p.get());tune->setAutoKeySyncEnabled(false);tune->startInputTypeLearn();tune->startAutoKeyDetect();juce::MessageManager::getInstance()->runDispatchLoopUntil(7200);}
#endif
   if(n==1){auto snapshot=ed->createComponentSnapshot(ed->getLocalBounds());if(snapshot.isNull())return 7;}
   start=Clock::now();ed.reset();maxClose=std::max(maxClose,ms(start));
   juce::MessageManager::getInstance()->runDispatchLoopUntil(15);
  }
  running.store(false);audio.join();rtParams+=listener.audioParameterNotifications.load();rtLatency+=listener.audioLatencyNotifications.load();p->removeListener(&listener);p->releaseResources();
  juce::MessageManager::getInstance()->runDispatchLoopUntil(15);
  start=Clock::now();
  if(n%3==0){std::atomic<bool> done{false};std::thread closer([&]{const juce::MessageManagerLock lock;p.reset();done.store(true);});while(!done.load())juce::MessageManager::getInstance()->runDispatchLoopUntil(3);closer.join();}
  else p.reset();
  maxClose=std::max(maxClose,ms(start));juce::MessageManager::getInstance()->runDispatchLoopUntil(10);
 }
 std::printf("RESULT cycles=%d max_create_ms=%.3f max_editor_ms=%.3f max_close_ms=%.3f finite_errors=%d audio_parameter_notifications=%d audio_latency_notifications=%d\n",cycles,maxCreate,maxEditor,maxClose,finiteErrors,rtParams,rtLatency);
 return finiteErrors?2:0;
}
