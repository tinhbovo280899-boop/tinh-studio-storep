# Kết quả rà 4 gói / 23 VST — 30/10/2026

Chưa xác định được nguyên nhân chính xác khiến Cubase Windows của anh treo. Em đã rà mã nguồn và thử vòng đời trên Linux; không có Cubase/Windows/ASIO trong môi trường này.

## Đã kiểm tra được

- 23 plugin: Compressor 2, FX 4, Plugins 15, VocalPack 2. Có danh sách riêng ở DANH_SACH_23_VST.csv.
- Trong đúng bốn ZIP này không trùng cặp mã nhà sản xuất/plugin, không trùng bundle ID hay tên sản phẩm. Cả bốn dùng JUCE 8.0.12.
- Cùng hệ bản quyền TVOCALPACK/TSTUDIO; các file LicenseCodec/LicenseManager giống nhau. config/public_key.txt trong cả bốn ZIP đang trống; khi phát hành cần dùng đúng public key hiện có. Không tự sinh bộ key thay thế.
- 184 lượt tạo/xoá processor, 138 lượt mở/đóng editor trên Linux đều hoàn tất, không timeout/crash, output hữu hạn. Có xử lý audio trên luồng nền, state round trip và một số lượt huỷ processor dưới MessageManagerLock.
- T-EQ có callback menu giữ con trỏ tham số; em đã gia cố bằng SafePointer tới editor và chỉ lấy tham số khi callback còn chủ sở hữu. Kiểm tra callback sống/đã xoá editor/đã xoá processor: 216 kiểm tra, AddressSanitizer/UBSan đều qua.

## Những chỗ cần đối chiếu thêm với Cubase

1. T-AutoTune: constructor và prepareToPlay đọc Auto-Key.handoff; timer giao diện đọc lại mỗi 250 ms. Reader đọc cả nội dung file, chưa có giới hạn kích thước. Nếu vị trí lưu file chậm/lỗi, luồng gọi có thể bị giữ. Chưa tái hiện tình huống này trên máy anh.
2. T-AutoTune: Learn/Input Type và Auto Key hoàn tất trong audio callback rồi đổi tham số; bộ thử ghi nhận 3 thông báo ở mức AudioProcessor. Dữ liệu tích luỹ Learn và lastKeyIdx/lastScaleIdx cũng có truy cập qua nhiều luồng chưa đồng bộ đầy đủ. Cần rà tiếp khi triển khai bản sửa riêng; chưa thay thuật toán tune trong gói này.
3. T-Comp, T-DeNoise và T-Pitch đổi độ trễ khi Lookahead/Mode thay đổi; bộ thử ghi nhận mỗi con một thông báo độ trễ khi đổi nút. JUCE VST3 đã chuyển restart sang message thread: chưa có chứng cứ những đường này trực tiếp deadlock Cubase. Không cố định độ trễ hay tăng latency live trong bản vá này.
4. Các worker bản quyền dừng bằng stopThread(3000), T-BE handoff reader dùng stopThread(2000). JUCE có đường cưỡng bức kết thúc thread nếu quá hạn. Trong lượt thử bình thường worker đã dừng nhanh, chưa gặp timeout; không kết luận lỗi bản quyền gây treo.
5. Khác phiên bản 1.2.0 và 1.7.0 là phiên bản từng gói, không tự nó là lỗi. Bộ soát mã nguồn không chứng minh Cubase đang nạp đúng binary vừa build hay không còn bản VST cũ trong thư mục khác.

## Dùng các file kèm theo

- **Windows_Diagnostics/1_LAY_THONG_TIN_CUBASE.bat**: chạy trên máy dùng Cubase, tốt nhất khi Cubase đang mở. Nó tạo ZIP chứa phiên bản Cubase, danh sách VST3, hash các binary nhận diện là T Studio, sự kiện Cubase 7 ngày gần nhất và danh sách dump đã có. Không nạp VST, không tắt DAW, không thay key, không tự gửi dữ liệu. Gửi lại ZIP kết quả trong cuộc trò chuyện để đối chiếu bản thực tế. Nếu VST nằm ở thư mục riêng, xem tham số AdditionalVst3Paths của script PowerShell.
- **T_EQ_UI_Patch/1_AP_DUNG_BAN_VA.bat**: chọn/nhập đường dẫn thư mục T-Studio_Plugins đã giải nén từ ZIP anh gửi. Script xác minh SHA256 trước khi ghi, sao lưu hai file .before-t-eq-ui-fix, cập nhật menu và version T-EQ 2.0.5. Sau đó dùng script build/installer của dự án gốc. Đây là bản vá mã nguồn, không phải VST3/bộ cài đã biên dịch.
- **Validation/**: log theo từng plugin, test source và giới hạn kiểm tra.

Bản vá T-EQ chỉ phòng callback trễ truy cập dữ liệu đã giải phóng. Chưa có bằng chứng T-EQ là thủ phạm của lần Cubase treo; cũng chưa thể chứng nhận 23 plugin không còn lỗi. Không đổi DSP, preset, parameter IDs, plugin codes hay chính sách bản quyền. Các gói cài native Windows/macOS chưa được build ở lượt này.
