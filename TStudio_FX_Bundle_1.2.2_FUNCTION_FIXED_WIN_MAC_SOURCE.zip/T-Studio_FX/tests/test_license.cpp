// SPDX-License-Identifier: AGPL-3.0-or-later
#include "licensing/LicenseCodec.h"
#include "licensing/LicenseManager.h"
#include <cstdio>
#include <stdexcept>

static int checks=0;
static void check(bool ok,const char* what){++checks;if(!ok)throw std::runtime_error(what);}
int main(){try{
 using namespace tak::license;
 juce::String pub,priv,error;check(createKeyPair(pub,priv,error),"RSA generation");
 check(pub.startsWith("10001,"),"RSA exponent must be 65537");
 constexpr juce::int64 now=1700000000000LL,day=86400000LL,hour=3600000LL;
 Configuration cfg{"TVOCALPACK","TSTUDIO","T-Studio Vocal Pack",pub,7,now-30*day};
 const juce::StringArray ids{"A1B2-C3D4-E5F6","1122-3344-5566","7788-99AA-BBCC"};
 Claims c{"Khách thử Nguyễn Tình","TVOCALPACK","TSTUDIO",now,now+30*day,ids};
 const auto token=sign(c,priv,error);check(token.startsWith("TAK1."),"Token format");
 auto v=verify(token,cfg,ids,now);check(v.valid&&v.claims.owner==c.owner,"Valid UTF-8 owner");
 check(verify(token,cfg,{ids[0],ids[1]},now).valid,"Two of three identifiers");
 check(!verify(token,cfg,{ids[0],"AAAA-BBBB-CCCC"},now).valid,"One of three is rejected");
 auto other=cfg;other.productId="TAUTOKEY";check(!verify(token,other,ids,now).valid,"Pack key is not a single-product key");
 other=cfg;other.brandId="OTHER";check(!verify(token,other,ids,now).valid,"Other brand rejected");
 other=cfg;other.publicKey=priv;check(!verify(token,other,ids,now).valid,"Private key cannot serve as the public verifier");
 check(!verify(token,cfg,ids,now+30*day).valid,"Expiry boundary");
 check(!verify(token,cfg,ids,now-2*day).valid,"Future issue rejected");
 auto mutated=token;const int index=mutated.lastIndexOf(".")+10;mutated=mutated.replaceSection(index,1,mutated[index]=='a'?"b":"a");
 check(!verify(mutated,cfg,ids,now).valid,"Modified signature rejected");
 auto parts=juce::StringArray::fromTokens(token,".","");juce::MemoryOutputStream decoded;juce::Base64::convertFromBase64(decoded,parts[1]);
 auto payload=decoded.toUTF8().replace(c.owner,"Other customer");
 check(!verify("TAK1."+juce::Base64::toBase64(payload.toRawUTF8(),size_t(payload.getNumBytesAsUTF8()))+"."+parts[2],cfg,ids,now).valid,"Modified payload rejected");
 for(const auto& bad:{juce::String(),juce::String("TAK1.bad.bad"),token+"x",juce::String::repeatedString("x",33000)})check(!verify(bad,cfg,ids,now).valid,"Malformed token rejected");
 c.expiresMs=0;const auto forever=sign(c,priv,error);check(verify(forever,cfg,ids,now+3650*day).valid,"Perpetual license");
 check(parseRequest(requestText(cfg,ids),cfg,error)==ids,"Export/import request");
 check(requestText(cfg,ids).startsWith("T-Studio Vocal Pack activation request"),"Request names the pack");
 check(parseRequest("Product: OTHER\n"+ids.joinIntoString("\n"),cfg,error).isEmpty(),"Wrong request product");
 check(parseRequest("Product: TAUTOKEY\n"+ids.joinIntoString("\n"),cfg,error,{"TAUTOKEY"})==ids,"Old T-AutoKey request accepted by the pack keygen");
 check(hmacSha256Hex("key","The quick brown fox jumps over the lazy dog")=="f7bc83f430538424b13298e6aa6fb143ef4d59a14946175997479dbc2d1a3cd8","HMAC-SHA256 RFC vector");
 auto noOwner=c;noOwner.owner.clear();check(sign(noOwner,priv,error).isEmpty(),"Empty owner rejected");

 const auto folder=juce::File::getSpecialLocation(juce::File::tempDirectory).getChildFile("tak-license-test-"+juce::Uuid().toString());
 struct Cleanup{juce::File folder;~Cleanup(){folder.deleteRecursively();}} cleanup{folder};
 auto store=[&](const char* name){return StorePaths::under(folder.getChildFile(juce::String::fromUTF8(name)),cfg.productId+"-"+cfg.brandId);};
 auto deleteMirrors=[](const StorePaths& p,int keep){for(int i=0;i<p.trialRecords.size();++i)if(i!=keep)p.trialRecords[i].deleteFile();};
 {
  const auto paths=store("Dùng thử có dấu");
  LicenseManager manager(cfg,paths,ids);manager.poll(now);
  check(!manager.isAllowed()&&manager.snapshot().trialAvailable,"Fresh instance waits for first use");
  check(!folder.exists(),"Host scanning must not create a trial or data directory");
  manager.requestTrial();manager.poll(now);check(manager.isAllowed()&&manager.snapshot().daysLeft==7,"Explicit 7-day trial");
  for(const auto& f:paths.trialRecords)check(f.existsAsFile(),"Trial mirrored to every location");
  manager.poll(now+6*day);check(manager.isAllowed()&&manager.snapshot().daysLeft==1,"Trial day six");
  manager.poll(now+7*day);check(!manager.isAllowed(),"Trial expires after seven days");
  manager.requestTrial();manager.poll(now+7*day);check(!manager.isAllowed(),"Trial cannot restart");
  deleteMirrors(paths,3);LicenseManager reopened(cfg,paths,ids);reopened.requestAutomaticTrial();reopened.poll(now+7*day);
  check(!reopened.isAllowed(),"Deleting all but one mirror does not reset the trial");
  for(const auto& f:paths.trialRecords)check(f.existsAsFile(),"Deleted mirrors are restored");
 }
 {
  // Second plugin of the pack on the same machine shares the same trial.
  const auto paths=store("shared");
  LicenseManager autoKey(cfg,paths,ids);autoKey.requestAutomaticTrial();autoKey.poll(now);
  LicenseManager autoTune(cfg,paths,ids);autoTune.requestAutomaticTrial();autoTune.poll(now+2*day);
  check(autoTune.isAllowed()&&autoTune.snapshot().daysLeft==5,"Both plugins count the same 7 days");
 }
 {
  const auto paths=store("rollback");
  LicenseManager manager(cfg,paths,ids);manager.requestAutomaticTrial();manager.poll(now);
  manager.poll(now+2*day);check(manager.isAllowed()&&manager.snapshot().daysLeft==5,"Normal use");
  manager.poll(now+2*day-30*60000LL);check(manager.isAllowed(),"Small clock correction (30 min) tolerated");
  manager.poll(now+1*day);check(!manager.isAllowed()&&manager.snapshot().tampered,"Clock set back one day ends the trial");
  manager.poll(now+3*day);check(!manager.isAllowed(),"Setting the clock forward again does not revive it");
  LicenseManager reopened(cfg,paths,ids);reopened.poll(now+3*day);check(!reopened.isAllowed()&&reopened.snapshot().tampered,"Tamper mark persists after reopening");
  reopened.requestActivation(token);reopened.poll(now+3*day);check(reopened.isAllowed()&&reopened.snapshot().activated,"A real key still activates after tampering");
 }
 {
  const auto paths=store("rollback-between-sessions");
  {LicenseManager first(cfg,paths,ids);first.requestAutomaticTrial();first.poll(now);first.poll(now+3*day);}
  LicenseManager second(cfg,paths,ids);second.poll(now+1*day);
  check(!second.isAllowed()&&second.snapshot().tampered,"Clock rolled back while the DAW was closed is detected");
 }
 {
  const auto paths=store("forward");
  LicenseManager manager(cfg,paths,ids);manager.requestAutomaticTrial();manager.poll(now);
  manager.poll(now+30*day);check(!manager.isAllowed(),"Clock set far forward uses up the trial");
  manager.poll(now+1*hour);check(!manager.isAllowed(),"Going back to the real date does not restore it");
 }
 {
  const auto paths=store("edited");
  LicenseManager manager(cfg,paths,ids);manager.requestAutomaticTrial();manager.poll(now);manager.poll(now+6*day);
  auto json=juce::JSON::parse(paths.trialRecords[0].loadFileAsString());
  json.getDynamicObject()->setProperty("first",now+6*day);
  check(atomicWrite(paths.trialRecords[0],juce::JSON::toString(json),error),"Write edited fixture");
  LicenseManager reopened(cfg,paths,ids);reopened.poll(now+6*day+hour);
  check(!reopened.isAllowed()&&reopened.snapshot().tampered,"Hand-edited trial start is detected");
 }
 {
  const auto paths=store("before-build");
  LicenseManager manager(cfg,paths,ids);manager.requestAutomaticTrial();manager.poll(cfg.buildEpochMs-10*day);
  check(!manager.isAllowed()&&!paths.trialRecords[0].exists(),"Clock earlier than the build date cannot start a trial");
  manager.requestAutomaticTrial();manager.poll(now);
  check(manager.isAllowed()&&manager.snapshot().daysLeft==7,"Trial starts once the clock is correct");
 }
 {
  const auto paths=store("all-deleted");
  {LicenseManager m(cfg,paths,ids);m.requestAutomaticTrial();m.poll(now);m.poll(now+8*day);check(!m.isAllowed(),"Expired fixture");}
  deleteMirrors(paths,-1);
  LicenseManager fresh(cfg,paths,ids);fresh.requestAutomaticTrial();fresh.poll(now+8*day);
  check(fresh.isAllowed(),"Documented limit: deleting every mirror (test store has no registry) starts over");
 }
 {
  const auto paths=store("activated");
  LicenseManager manager(cfg,paths,ids);manager.poll(now);manager.requestActivation(token);manager.poll(now);
  check(manager.isAllowed()&&manager.snapshot().activated,"Activation enables the pack");
  check(paths.license.loadFileAsString()==token,"Activation persists exact token");
  manager.requestActivation(mutated);manager.poll(now+1000);
  check(manager.isAllowed()&&paths.license.loadFileAsString()==token,"Invalid replacement preserves valid license");
  manager.poll(now+10*day);manager.poll(now+2*day);check(manager.isAllowed(),"Clock rollback never locks a paid key");
  manager.poll(now+31*day);check(!manager.isAllowed(),"Activated license expiry");
  manager.requestTrial();manager.poll(now+31*day);check(!manager.isAllowed(),"Expired activated machine does not gain a trial");
  paths.license.deleteFile();paths.activationHistory.deleteFile();
  LicenseManager reopened(cfg,paths,ids);reopened.requestAutomaticTrial();reopened.poll(now+31*day);
  check(!reopened.isAllowed(),"Deleting the key and history does not open a trial on a licensed machine");
 }
 {
  // Old single-product T-AutoKey key keeps T-AutoKey working (only where passed in).
  auto legacyCfg=cfg;legacyCfg.productId="TAUTOKEY";legacyCfg.trialDays=0;
  Claims lc{"Khách cũ","TAUTOKEY","TSTUDIO",now,0,ids};const auto legacyToken=sign(lc,priv,error);
  const auto paths=store("legacy");const auto legacyFile=folder.getChildFile("legacy/TAUTOKEY-TSTUDIO/license.taklic");
  LicenseManager autoKey(cfg,paths,ids,{LegacyLicense{legacyCfg,legacyFile,"key T-AutoKey cũ"}});
  autoKey.requestActivation(legacyToken);autoKey.poll(now);
  check(autoKey.isAllowed()&&autoKey.snapshot().legacy&&legacyFile.existsAsFile(),"Legacy key activates T-AutoKey");
  LicenseManager autoTune(cfg,paths,ids);autoTune.poll(now);
  check(!autoTune.snapshot().activated,"Legacy T-AutoKey key does not unlock T-AutoTune");
  autoTune.requestAutomaticTrial();autoTune.poll(now);
  check(autoTune.isAllowed()&&autoTune.snapshot().trialStarted,"Old T-AutoKey customers can still try T-AutoTune");
 }
 {
  const auto paths=store("bad-trial");check(atomicWrite(paths.trialRecords[0],"broken",error),"Write corrupted state fixture");
  LicenseManager manager(cfg,paths,ids);manager.requestTrial();manager.poll(now);check(!manager.isAllowed(),"Corrupt trial does not restart");
  manager.requestAutomaticTrial();manager.poll(now);check(!manager.isAllowed(),"Automatic request cannot replace corrupt trial state");
 }
 std::printf("LICENSE TESTS PASSED: %d checks; RSA/SHA-256, pack key, legacy key, mirrored signed trial, clock rollback/forward, edits\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"LICENSE TEST FAILURE: %s\n",e.what());return 1;}}
