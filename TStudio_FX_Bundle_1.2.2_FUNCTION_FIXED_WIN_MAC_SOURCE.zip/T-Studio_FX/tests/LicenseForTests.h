#pragma once
// Processor-level tests run the real license gate. Inside an isolated test HOME
// (CTest sets TSTUDIO_TEST_ISOLATED_HOME=1 on Linux/macOS) the shared trial is
// started there; otherwise the machine must already be activated or in trial.
// Without either, the test reports SKIPPED (exit 77) instead of touching the
// owner's real trial state.
#include "licensing/PluginLicense.h"
#include <cstdio>
#include <cstdlib>
#include <thread>
#include <chrono>

namespace tstudio_test
{
inline constexpr int kSkip = 77;
inline bool unlock(tak::license::PluginLicense& license)
{
    if (const char* iso = std::getenv("TSTUDIO_TEST_ISOLATED_HOME"); iso != nullptr && iso[0] == '1')
        license.ensureAutomaticTrial();
    for (int i = 0; i < 250 && ! license.isAllowed(); ++i)
        std::this_thread::sleep_for(std::chrono::milliseconds(20));
    if (! license.isAllowed())
        std::printf("SKIPPED: no T Studio activation/trial on this machine (processor test needs an unlocked plugin)\n");
    return license.isAllowed();
}
}
