// Linux integration QA for the four FX plugins with the shared T Studio license.
// Use a NEW isolated HOME for each run:
//   TVerbQA /tmp/home audio|expired|sharedtrial
//   TVerbQA /tmp/home activated <license.taklic>
//   TVerbQA /tmp/home snapshot <out.png> [page] [license|locked]
#if QA_TVERB
 #include "VerbProcessor.h"
 using Processor = tverb::Processor;
#elif QA_TRVERB
 #include "RVerbProcessor.h"
 using Processor = trverb::Processor;
#elif QA_TPANTHEON
 #include "TPantheonProcessor.h"
 using Processor = TPantheonAudioProcessor;
#else
 #include "TDelayProcessor.h"
 using Processor = TDelayAudioProcessor;
#endif
#include "StudioEditor.h"
#include "HwKit.h"
#include <cstdio>
#include <cstdlib>
#include <stdexcept>

static void require (bool ok, const char* message) { if (! ok) throw std::runtime_error (message); }
template <class F> static bool waitFor (F check, int ms)
{
    for (int i = 0; i < ms / 20; ++i) { if (check()) return true; juce::MessageManager::getInstance()->runDispatchLoopUntil (20); }
    return check();
}
static juce::Component* findId (juce::Component* c, const juce::String& id)
{
    if (c->getComponentID() == id) return c;
    for (auto* k : c->getChildren()) if (auto* f = findId (k, id)) return f;
    return nullptr;
}
static void savePng (juce::Component& c, const char* path)
{
    const char* scaleEnv = std::getenv ("TSTUDIO_SNAP_SCALE");   // e.g. 2 for marketing screenshots
    const float scale = scaleEnv != nullptr ? juce::jlimit (1.0f, 3.0f, (float) std::atof (scaleEnv)) : 1.0f;
    const auto image = c.createComponentSnapshot (c.getLocalBounds(), true, scale);
    juce::File out (path); out.deleteFile(); juce::FileOutputStream stream (out); juce::PNGImageFormat png;
    require (png.writeImageToStream (image, stream), "could not save snapshot");
}

int main (int argc, char** argv)
{
  #if ! JUCE_LINUX
    return 77;
  #else
    try
    {
        require (argc >= 3, "Supply a NEW isolated HOME and a mode");
        const juce::File home (argv[1]); const juce::String mode (argv[2]);
        require (! home.exists(), "QA HOME must not already exist");
        home.createDirectory(); setenv ("HOME", home.getFullPathName().toRawUTF8(), 1);
        const auto xdg = home.getChildFile ("config"); xdg.createDirectory(); setenv ("XDG_CONFIG_HOME", xdg.getFullPathName().toRawUTF8(), 1);
        juce::ScopedJuceInitialiser_GUI init;
        const auto store = tak::license::productStore();
        const auto now = juce::Time::getCurrentTime().toMilliseconds();
        const bool locked = mode == "expired" || (argc >= 6 && juce::String (argv[5]) == "locked");
        if (locked)
        {
            tak::license::LicenseManager fixture (tak::license::productConfiguration(), store);
            fixture.requestAutomaticTrial(); fixture.poll (now); fixture.poll (now + 8 * 86400000LL);
        }
        if (mode == "sharedtrial")
        {
            tak::license::LicenseManager other (tak::license::productConfiguration(), store);   // e.g. T-1176 started it
            other.requestAutomaticTrial(); other.poll (now);
        }
        if (mode == "activated")
        {
            require (argc >= 4, "activated needs a license file");
            juce::String error;
            require (tak::license::atomicWrite (store.license, juce::File (argv[3]).loadFileAsString(), error, true), "cannot place license");
        }

        Processor p;
        p.setPlayConfigDetails (2, 2, 48000, 512);
        p.prepareToPlay (48000, 512);
        require (waitFor ([&] { return p.getLicense().snapshot().fingerprint.isNotEmpty(); }, 3000), "license thread did not start");
        if (mode == "audio")
            require (! p.getLicense().isAllowed() && ! store.trialRecords[0].existsAsFile(), "host scan/prepare consumed the trial");

        juce::AudioBuffer<float> b (2, 512); juce::MidiBuffer midi; double t = 0.0;
        auto block = [&] (float level)   // returns true when the output equals the input (pass-through)
        {
            for (int i = 0; i < 512; ++i)
            {
                const double env = (std::fmod (t, 0.5) < 0.12) ? 1.0 : 0.0;
                const float s = (float) (level * env * std::sin (juce::MathConstants<double>::twoPi * 330.0 * t));
                b.setSample (0, i, s); b.setSample (1, i, s); t += 1.0 / 48000.0;
            }
            juce::AudioBuffer<float> before; before.makeCopyOf (b);
            p.processBlock (b, midi);
            for (int ch = 0; ch < 2; ++ch) for (int i = 0; i < 512; ++i)
                if (std::abs (b.getSample (ch, i) - before.getSample (ch, i)) > 1.0e-6f) return false;
            return true;
        };

        if (mode == "expired")
        {
            std::unique_ptr<juce::AudioProcessorEditor> editor (p.createEditor());
            bool dry = true;
            for (int n = 0; n < 80; ++n) { const bool same = block (0.5f); if (n > 20) dry = dry && same; juce::MessageManager::getInstance()->runDispatchLoopUntil (3); }
            require (! p.getLicense().isAllowed(), "expired trial did not lock the plugin");
            require (dry, "locked plugin changed the audio");
            std::printf ("FX QA PASS [%s]: expired trial locks; audio passes through unchanged\n", p.getName().toRawUTF8());
            return 0;
        }
        if (mode == "activated")
        {
            block (0.5f);
            require (waitFor ([&] { return p.getLicense().snapshot().activated; }, 3000), "T Studio pack key did not activate this plugin");
            std::printf ("FX QA PASS [%s]: pack key activates this plugin (%s)\n", p.getName().toRawUTF8(), p.getLicense().snapshot().status.toRawUTF8());
            return 0;
        }
        if (mode == "sharedtrial")
        {
            const auto before = juce::JSON::parse (store.trialRecords[0].loadFileAsString())["first"];
            block (0.5f);
            require (waitFor ([&] { return p.getLicense().isAllowed(); }, 3000), "shared trial not seen");
            const auto after = juce::JSON::parse (store.trialRecords[0].loadFileAsString())["first"];
            require (p.getLicense().snapshot().trialStarted && before == after, "plugin must continue the existing trial, not start a new one");
            std::printf ("FX QA PASS [%s]: continues the trial started by another T Studio plugin (%s)\n", p.getName().toRawUTF8(), p.getLicense().snapshot().status.toRawUTF8());
            return 0;
        }
        if (mode == "audio")
        {
            block (0.5f);
            require (waitFor ([&] { return p.getLicense().isAllowed(); }, 3000), "first audio did not start the trial");
            require (p.getLicense().snapshot().daysLeft == 7, "trial is not seven days");
            bool changed = false;
            for (int n = 0; n < 60; ++n) if (! block (0.5f)) changed = true;
            require (changed, "licensed plugin did not process audio");
            std::printf ("FX QA PASS [%s]: first audio starts the shared 7-day trial; effect is processing\n", p.getName().toRawUTF8());
            return 0;
        }
        require (mode == "snapshot" && argc >= 4, "unknown mode");
        std::unique_ptr<juce::AudioProcessorEditor> editor (p.createEditor());
        editor->setVisible (true);
        if (! locked) require (waitFor ([&] { return p.getLicense().isAllowed(); }, 3000), "editor did not start the trial");
        const int page = argc >= 5 ? juce::String (argv[4]).getIntValue() : 0;
        if (auto* tab = dynamic_cast<juce::Button*> (findId (editor.get(), "page" + juce::String (page)))) tab->triggerClick();
        for (int n = 0; n < 120; ++n) { block (0.25f); if (n % 2 == 0) juce::MessageManager::getInstance()->runDispatchLoopUntil (6); }
        if (argc >= 6 && juce::String (argv[5]) == "license")
        {
            if (auto* fx = dynamic_cast<tstudio_ui::Editor*> (editor.get())) fx->openLicensePanel();
            if (auto* hw = dynamic_cast<thw::Editor*> (editor.get())) hw->openLicensePanel();
        }
        juce::MessageManager::getInstance()->runDispatchLoopUntil (400);
        savePng (*editor, argv[3]);
        std::printf ("FX QA PASS [%s]: editor renders (%s)\n", p.getName().toRawUTF8(), p.getLicense().snapshot().status.toRawUTF8());
        return 0;
    }
    catch (const std::exception& e) { std::fprintf (stderr, "FX QA FAIL: %s\n", e.what()); return 1; }
  #endif
}
