#pragma once
// Display branding for T-LIQUID DELAY.
namespace AppBranding {
inline constexpr const char* kAppDisplayName = "T-LIQUID DELAY";
inline constexpr const char* kBrandWord1 = "T-LIQUID DELAY";
inline constexpr const char* kBrandWord2 = "";
inline constexpr const char* kBrandSubtitle = "T STUDIO STEREO DELAY";
inline constexpr const char* kSplashLine2 = "T STUDIO";
inline constexpr const char* kPublisher = "T Studio";
inline constexpr const char* kAppVersion = "1.1.0";
inline constexpr const char* kExeName = "T-LIQUID DELAY.exe";
inline constexpr const char* kSetupName = "Setup_T_LIQUID_DELAY";
}
