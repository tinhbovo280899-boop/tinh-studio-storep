#pragma once
#include "HwKit.h"
#include "TDelayProcessor.h"

// T-LIQUID DELAY: delay / filter / LFO / drive sections, every parameter on the face.
namespace tliquid_hw
{
using namespace thw;
inline String hz (float f) { return f >= 1000.0f ? String (f / 1000.0f, f >= 10000.0f ? 1 : 2) + " kHz" : String (juce::roundToInt (f)) + " Hz"; }

class Editor final : public thw::Editor
{
public:
    explicit Editor (TDelayAudioProcessor& p)
        : thw::Editor (p, p.getAPVTS(), p.getLicense(), { "T-LIQUID DELAY", vn ("Stereo delay · filter · drive"), 1080, 700, "ldelay", { "T-LIQUI DELAY" } }), proc (p)
    {
        auto at = [this] (const String& id, std::initializer_list<std::pair<const char*, float>> vals)
        {
            std::vector<std::pair<String, float>> m;
            if (auto* q = param (id)) for (auto& v : vals) m.push_back ({ v.first, q->convertTo0to1 (v.second) });
            return m;
        };
        section (20, 76, 500, 304, "DELAY");
        button ("dlyLOn", 36, 104, 80, "L ON");
        button ("dlyROn", 124, 104, 80, "R ON");
        button ("dlySync", 212, 104, 90, "SYNC");
        select ("dlyLXTime", 320, 104, 90, "L TIME");
        select ("dlyRXTime", 418, 104, 90, "R TIME");
        button ("dlyLDot", 320, 138, 43, "DOT", 20);
        button ("dlyLTri", 367, 138, 43, "TRI", 20);
        button ("dlyRDot", 418, 138, 43, "DOT", 20);
        button ("dlyRTri", 465, 138, 43, "TRI", 20);
        big ("dlyFeedback", 140, 246, 48, "FEEDBACK", { "0", "25", "50", "75", "100" }, unit ("dlyFeedback", "%"));
        big ("mix", 390, 246, 48, "MIX", { "0", "25", "50", "75", "100" }, unit ("mix", "%"));
        screen (214, 200, 96, 92, [this] (juce::Graphics& g, juce::Rectangle<float> r)
        {
            // L / R tap times
            const float l = proc.getEffectiveDelayMsL(), rr = proc.getEffectiveDelayMsR(), mx = juce::jmax (100.0f, juce::jmax (l, rr) * 1.15f);
            const bool lon = value ("dlyLOn") > 0.5f, ron = value ("dlyROn") > 0.5f;
            const float h = r.getHeight() - 40;
            g.setColour (lon ? orange() : dimDark()); g.fillRect (r.getX() + 24, r.getY() + 14 + h * (1 - l / mx), 14.0f, h * l / mx);
            g.setColour (ron ? orangeLight() : dimDark()); g.fillRect (r.getRight() - 38, r.getY() + 14 + h * (1 - rr / mx), 14.0f, h * rr / mx);
            thw::text (g, String (juce::roundToInt (l)), r.getX() + 31, r.getBottom() - 16, 9.0f, lcdText(), 8);
            thw::text (g, String (juce::roundToInt (rr)), r.getRight() - 31, r.getBottom() - 16, 9.0f, lcdText(), 8);
        });

        section (532, 76, 528, 304, "FILTER");
        button ("filterOn", 548, 104, 100, "FILTER");
        button ("hdFilter", 656, 104, 100, "HD").setTooltip("HD filters; OFF keeps the classic filter tone. No added lookahead latency.");
        button ("inLoop", 764, 104, 110, "IN LOOP");
        bigAt ("lowCut", 620, 246, 44, "LOW CUT", at ("lowCut", { { "22", 22.0f }, { "150", 150.0f }, { "1k", 1000.0f }, { "11k", 11025.0f } }), [this] { return hz (value ("lowCut")); });
        bigAt ("highCut", 800, 246, 44, "HIGH CUT", at ("highCut", { { "500", 501.14f }, { "2k", 2000.0f }, { "8k", 8000.0f }, { "22k", 22050.0f } }), [this] { return hz (value ("highCut")); });
        small ("resonance", 980, 236, 24, "RESONANCE", "0", "100", unit ("resonance", "%"));

        section (20, 392, 600, 234, "LFO");
        button ("lfoOn", 36, 420, 90, "LFO ON");
        button ("lfoSync", 134, 420, 90, "SYNC");
        seg ("lfoWave", 250, 420, { "SINE", "TRI", "PULSE", vn ("SAW ↑"), vn ("SAW ↓") }, 72);
        screen (36, 456, 568, 22, [this] (juce::Graphics& g, juce::Rectangle<float> r)
        {
            const float u = juce::jlimit (0.0f, 1.0f, proc.getLfoMeter() * 0.5f + 0.5f);
            const bool on = value ("lfoOn") > 0.5f;
            g.setColour (on ? orange().withAlpha (0.8f) : dimDark());
            g.fillRoundedRectangle (r.getX() + 8 + (r.getWidth() - 28) * u, r.getY() + 5, 12.0f, r.getHeight() - 10, 3.0f);
        });
        row (90, 514, 150, 24, {
            { "lfoRate", "RATE", "0.05", "22", unit ("lfoRate", "Hz") },
            { "lfoDepth", "DEPTH", "0", "100", unit ("lfoDepth", "%") },
            { "stereoWidth", "WIDTH", "0", "100", unit ("stereoWidth", "%") },
            { "dlyTempo", "TEMPO", "40", "500", [this] { return String (value ("dlyTempo"), 1) + " BPM"; } } });

        section (632, 392, 428, 234, vn ("DRIVE · OUTPUT"));
        select ("fxMode", 652, 444, 220, "FX CHAIN", { vn ("Filter → Drive → Delay"), vn ("Filter → Delay → Drive"), vn ("Delay → Drive → Filter"),
                                                       vn ("Delay → Filter → Drive"), vn ("Drive → Delay → Filter"), vn ("Drive → Filter → Delay") });
        button ("peakLimit", 890, 445, 150, "PEAK LIMIT");
        row (700, 534, 120, 24, {
            { "overdrive", "OVERDRIVE", "0", "100", unit ("overdrive", "%") },
            { "inputLevel", "INPUT", "-24", "+24", unit ("inputLevel", "dB") },
            { "outputLevel", "OUTPUT", "-24", "+24", unit ("outputLevel", "dB") } });
        button ("bypass", 890, 408, 150, "BYPASS", 24);

        infoItem ("TEMPO", [this] { return String (proc.getActiveBpm(), 1) + " BPM"; });
        infoItem ("DELAY L / R", [this] { return String (juce::roundToInt (proc.getEffectiveDelayMsL())) + " / " + String (juce::roundToInt (proc.getEffectiveDelayMsR())) + " ms"; });
        finish();
    }
private:
    TDelayAudioProcessor& proc;
};
}
