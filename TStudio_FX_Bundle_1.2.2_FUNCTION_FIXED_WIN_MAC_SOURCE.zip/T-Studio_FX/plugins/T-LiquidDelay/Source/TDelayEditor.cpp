#include "TDelayEditor.h"
TDelayAudioProcessorEditor::TDelayAudioProcessorEditor(TDelayAudioProcessor& p)
    : tstudio_ui::Editor(p,p.getAPVTS(),tstudio_ui::delaySpec(),p.getLicense(),[&p]{return std::array<float,2>{{p.getOutputLevelL(),p.getOutputLevelR()}};}) {setMotionMeter([&p]{return p.getLfoMeter();});setTempoSource([&p]{return p.getActiveBpm();});}
