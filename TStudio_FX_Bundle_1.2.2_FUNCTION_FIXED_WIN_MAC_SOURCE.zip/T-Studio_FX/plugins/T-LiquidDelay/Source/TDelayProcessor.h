#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <vector>
#include <atomic>
#include <cmath>
#include <algorithm>
#include "AppBranding.h"
#include "licensing/PluginLicense.h"

#include "dsp/DelayComponents.h"

class TDelayAudioProcessor : public juce::AudioProcessor
{
public:
    TDelayAudioProcessor();
    ~TDelayAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return AppBranding::kAppDisplayName; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentPresetIndex.load(std::memory_order_relaxed); }
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    // Shared T Studio license (same key/trial as T-AutoKey, T-AutoTune, T-1176, T-LA2a).
    tak::license::PluginLicense& getLicense() noexcept { return license; }

    // Real-time UI meters
    float getInputLevelL() const noexcept  { return meterInL.load(std::memory_order_relaxed); }
    float getInputLevelR() const noexcept  { return meterInR.load(std::memory_order_relaxed); }
    float getOutputLevelL() const noexcept { return meterOutL.load(std::memory_order_relaxed); }
    float getOutputLevelR() const noexcept { return meterOutR.load(std::memory_order_relaxed); }
    float getLfoMeter() const noexcept     { return meterLfo.load(std::memory_order_relaxed); }
    float getActiveBpm() const noexcept    { return meterBpm.load(std::memory_order_relaxed); }
    float getEffectiveDelayMsL() const noexcept { return currentDelayMsL.load(std::memory_order_relaxed); }
    float getEffectiveDelayMsR() const noexcept { return currentDelayMsR.load(std::memory_order_relaxed); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    static const std::vector<tdelay::FactoryPreset>& getFactoryPresets();

private:
    tak::license::PluginLicense license;
    juce::AudioProcessorValueTreeState apvts;

    tdelay::CPassFilters lowCutFilter;
    tdelay::CPassFilters highCutFilter;
    tdelay::COverdrive overdrive;
    tdelay::CDelayLine delayLine;
    tdelay::CLFO lfo;
    tdelay::CBrickWallLimiter brickWallLimiter;
    juce::SmoothedValue<float> hdBlend;

    float lastLfoOut = 0.0f;
    unsigned int filterModCounter = 0;
    double meterDecayCoeff = 0.9999;
    std::atomic<int> currentPresetIndex { 0 };

    std::atomic<float> meterInL { 0.0f }, meterInR { 0.0f };
    std::atomic<float> meterOutL { 0.0f }, meterOutR { 0.0f };
    std::atomic<float> meterBpm { 0.0f };
    std::atomic<float> meterLfo { 0.0f };
    std::atomic<float> currentDelayMsL { 206.9f }, currentDelayMsR { 413.8f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TDelayAudioProcessor)
};
