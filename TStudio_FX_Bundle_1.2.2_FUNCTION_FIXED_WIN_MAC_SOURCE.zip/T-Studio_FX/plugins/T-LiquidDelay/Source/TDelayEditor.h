#pragma once
#include "TDelayProcessor.h"
#include "../../common/StudioSpecs.h"
class TDelayAudioProcessorEditor final : public tstudio_ui::Editor
{
public:
    explicit TDelayAudioProcessorEditor(TDelayAudioProcessor&);
};
