#include "dsp/DelayComponents.h"
#include <cstdio>
#include <limits>
static int failures=0,checks=0;
#define CHECK(x) do{++checks;if(!(x)){std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;}}while(false)
static double response(double sr,double frequency,bool highPass,bool hd)
{
    tdelay::CPassFilters filter;filter.prepare(sr);filter.setCoefficients(2000,0,highPass);
    double energy=0;int count=0;
    for(int i=0;i<int(sr);++i){float x=float(.1*std::sin(2*juce::MathConstants<double>::pi*frequency*i/sr));
        const float y=hd?filter.processSampleHD(0,x,highPass):filter.processSample(0,x,highPass);
        CHECK(std::isfinite(y));if(i>int(sr/2)){energy+=y*y;++count;}}
    return std::sqrt(energy/count)/(.1/std::sqrt(2.));
}
int main()
{
    for(double sr:{32000.,44100.,48000.,96000.,192000.}){
        const double atCut=response(sr,2000,false,true);
        const double low=response(sr,250,false,true),high=response(sr,8000,false,true);
        const double hpLow=response(sr,250,true,true),hpHigh=response(sr,8000,true,true);
        std::printf("HD sr=%.0f cutoff=%.6f low=%.6f high=%.6f hpLow=%.6f hpHigh=%.6f\n",sr,atCut,low,high,hpLow,hpHigh);
        CHECK(std::abs(atCut-.70710678)<.005);CHECK(low>.97&&high<.1);CHECK(hpLow<.03&&hpHigh>.97);
    }
    const double normal=response(48000,2000,false,false),hd=response(48000,2000,false,true);
    CHECK(std::abs(normal-hd)>.05);
    tdelay::CPassFilters filter;filter.prepare(48000);filter.setCoefficients(2000,100,false);
    for(int i=0;i<10000;++i){float x=i==0?std::numeric_limits<float>::infinity():i==1?std::numeric_limits<float>::quiet_NaN():.1f;
        CHECK(std::isfinite(filter.processSampleHD(i&1,x,false)));}
    filter.reset();filter.setCoefficients(2000,0,false);
    for(int i=0;i<128;++i)CHECK(filter.processSampleHD(i&1,0,false)==0);
    std::printf("HD FILTER: %d checks, %d failures\n",checks,failures);return failures?1:0;
}
