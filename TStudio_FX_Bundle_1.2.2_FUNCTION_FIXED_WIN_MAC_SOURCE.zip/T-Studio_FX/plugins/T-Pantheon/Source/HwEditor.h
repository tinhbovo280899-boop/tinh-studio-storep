#pragma once
#include "HwKit.h"
#include "TPantheonProcessor.h"

// T-PANTHEON: type row, RT60 / MIX, decay screen with the two echo taps.
namespace tpantheon_hw
{
using namespace thw;
inline String hz (float f) { return f >= 1000.0f ? String (f / 1000.0f, f >= 10000.0f ? 1 : 2) + " kHz" : String (juce::roundToInt (f)) + " Hz"; }

class Editor final : public thw::Editor
{
public:
    explicit Editor (TPantheonAudioProcessor& p)
        : thw::Editor (p, p.getAPVTS(), p.getLicense(), { "T-PANTHEON", "Studio reverb", 1040, 680, "pantheon", { "T-PHANGHEO" } }), proc (p)
    {
        seg ("reverbType", 250, 96, { "HALL", "CHAMBER", "ROOM", "PLATE", "AMBIENCE", "CUSTOM" }, 92);
        big ("rt60", 150, 222, 62, "RT60", { "0.1", "1.7", "3.3", "5", "6.6" }, [this] { return String (value ("rt60"), 2) + " s"; });
        screen (290, 140, 460, 160, [this] (juce::Graphics& g, juce::Rectangle<float> r)
        {
            const auto a = r.reduced (12).withTrimmedTop (12);
            const float rt = juce::jmax (0.1f, value ("rt60")), span = juce::jmax (1.0f, rt * 1.6f);
            const float pre = value ("preDelay") / 1000.0f;
            auto tx = [&] (float s) { return a.getX() + a.getWidth() * juce::jlimit (0.0f, 1.0f, s / span); };
            curve (g, a.withLeft (tx (pre)), [=] (float u)
            {
                const float s = u * (span - pre);
                return std::exp (-s * 6.9f / rt) * (s > 0.04f ? 1.0f : s / 0.04f);
            }, true);
            for (int k = 0; k < 2; ++k)
            {
                const float lvl = value (k == 0 ? "echoLevelL" : "echoLevelR"), ms = value (k == 0 ? "echoTimeL" : "echoTimeR");
                if (lvl <= -59.5f || ms <= 0.5f) continue;
                const float x = tx (ms / 1000.0f), h = a.getHeight() * juce::Decibels::decibelsToGain (lvl);
                g.setColour (k == 0 ? lcdText() : creamBright()); g.fillRect (x - 1.5f, a.getBottom() - h, 3.0f, h);
                thw::text (g, k == 0 ? "L" : "R", x, a.getBottom() - h - 9, 9.0f, lcdText(), 8);
            }
            thw::text (g, "RT60 " + String (rt, 2) + " s", r.getRight() - 12, r.getY() + 20, 11.0f, lcdText(), 8, 1);
        });
        mixKnob = &big ("mix", 890, 222, 62, "MIX", { "0", "25", "50", "75", "100" },
            [this] { return proc.isFxSendMode() ? String("100% WET") : String(value("mix"), 1) + "%"; });
        mixValue = values.back().get();
        const auto insertMixEdit = mixValue->onType;
        mixValue->onType = [this, insertMixEdit](const String& text) { if(!proc.isFxSendMode()) insertMixEdit(text); };
        mixKnob->setEnabled(!proc.isFxSendMode());
        mixValue->setEnabled(!proc.isFxSendMode());
        sendButton = &button ("", 780, 370, 240, "FX SEND 100% WET", 20);
        sendButton->momentary = false;
        sendButton->setClickingTogglesState(true);
        sendButton->setToggleState(proc.isFxSendMode(), juce::dontSendNotification);
        sendButton->setTooltip("FX Send: wet only; presets keep Mix at 100%. OFF: normal insert Mix and Mix automation.");
        sendButton->onClick = [this] {
            proc.setFxSendMode(sendButton->getToggleState());
            if(proc.isFxSendMode()) if(auto* p=param("mix")) {
                p->beginChangeGesture(); p->setValueNotifyingHost(1.0f); p->endChangeGesture();
            }
        };
        infoItem("ROUTE", [this] { return proc.isFxSendMode() ? String("FX SEND / WET") : String("INSERT / MIX"); });

        section (20, 396, 640, 226, "ROOM");
        row (64, 448, 89, 19, {
            { "roomSize", "SIZE", "4", "76", [this] { return String (value ("roomSize"), 1); } },
            { "preDelay", "PRE-DELAY", "0", "250", unit ("preDelay", "ms") },
            { "diffusion", "DIFFUSION", "0", "100", unit ("diffusion", "%") },
            { "spread", "SPREAD", "0", "100", unit ("spread", "%") },
            { "damping", "DAMPING", "500", "20k", [this] { return hz (value ("damping")); } },
            { "delay", "DELAY", "0", "250", unit ("delay", "ms") },
            { "regen", "REGEN", "0", "100", unit ("regen", "%") } });
        row (64, 548, 89, 19, {
            { "bassBoost", "BASS BOOST", "0.1", "2.5", [this] { return String (value ("bassBoost"), 2) + "x"; } },
            { "bassFreq", "BASS FREQ", "60", "2.5k", [this] { return hz (value ("bassFreq")); } },
            { "inputLevel", "INPUT", "-24", "+12", unit ("inputLevel", "dB") },
            { "level", "LEVEL", "-36", "+6", unit ("level", "dB") } });
        section (672, 396, 348, 226, "ECHO L / R");
        row (718, 448, 84, 19, {
            { "echoLevelL", "LEVEL L", "-60", "0", unit ("echoLevelL", "dB") },
            { "echoTimeL", "TIME L", "0", "600", unit ("echoTimeL", "ms") },
            { "echoLevelR", "LEVEL R", "-60", "0", unit ("echoLevelR", "dB") },
            { "echoTimeR", "TIME R", "0", "600", unit ("echoTimeR", "ms") } });
        screen (700, 534, 300, 46, [this] (juce::Graphics& g, juce::Rectangle<float> r)
        {
            for (int k = 0; k < 2; ++k)
            {
                const auto b = juce::Rectangle<float> (r.getX() + 26, r.getY() + 9 + (float) k * 16, r.getWidth() - 38, 10);
                g.setColour (well()); g.fillRoundedRectangle (b, 2.0f);
                const float u = juce::jlimit (0.0f, 1.0f, (out[k] + 48.0f) / 48.0f);
                g.setGradientFill (juce::ColourGradient (orangeDeep(), b.getX(), 0, orangeLight(), b.getRight(), 0, false));
                g.fillRoundedRectangle (b.withWidth (b.getWidth() * u), 2.0f);
                thw::text (g, k == 0 ? "L" : "R", r.getX() + 14, b.getCentreY(), 9.0f, dim(), 8);
            }
        });
        caption ("OUTPUT", 850, 594, 9.0f);
        infoItem ("OUT", [this] { return String (juce::Decibels::gainToDecibels (juce::jmax (proc.getOutputLevelL(), proc.getOutputLevelR()), -60.0f), 1) + " dB"; });
        finish();
    }
private:
    void tick() override
    {
        const bool send = proc.isFxSendMode();
        sendButton->setToggleState(send, juce::dontSendNotification);
        mixKnob->setEnabled(!send);
        mixValue->setEnabled(!send);
        mixKnob->setValue(send ? 100.0 : value("mix"), juce::dontSendNotification);
        const float in[2] = { juce::Decibels::gainToDecibels (proc.getOutputLevelL(), -60.0f), juce::Decibels::gainToDecibels (proc.getOutputLevelR(), -60.0f) };
        for (int k = 0; k < 2; ++k) out[k] += (in[k] - out[k]) * (in[k] > out[k] ? 0.5f : 0.12f);
    }
    TPantheonAudioProcessor& proc;
    thw::Knob* mixKnob = nullptr;
    thw::ValueBox* mixValue = nullptr;
    thw::LedButton* sendButton = nullptr;
    float out[2] = { -60.0f, -60.0f };
};
}
