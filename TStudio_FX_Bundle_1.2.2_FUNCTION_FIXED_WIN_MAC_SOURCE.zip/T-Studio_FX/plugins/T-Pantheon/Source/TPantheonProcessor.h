#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <vector>
#include <atomic>
#include <cmath>
#include <algorithm>
#include "AppBranding.h"
#include "licensing/PluginLicense.h"

#include "dsp/PhoenixChamber.h"

class TPantheonAudioProcessor : public juce::AudioProcessor
{
public:
    TPantheonAudioProcessor();
    ~TPantheonAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    void reset() override { chamber.reset(); }
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return AppBranding::kAppDisplayName; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentPresetIndex.load(std::memory_order_relaxed); }
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    // Shared T Studio license (same key/trial as T-AutoKey, T-AutoTune, T-1176, T-LA2a).
    tak::license::PluginLicense& getLicense() noexcept { return license; }
    bool isFxSendMode() const noexcept { return fxSendMode.load(std::memory_order_relaxed); }
    void setFxSendMode(bool enabled) noexcept { fxSendMode.store(enabled, std::memory_order_relaxed); }

    float getOutputLevelL() const noexcept { return meterOutL.load(std::memory_order_relaxed); }
    float getOutputLevelR() const noexcept { return meterOutR.load(std::memory_order_relaxed); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    static const std::vector<tpantheon::PantheonPreset>& getFactoryPresets();

private:
    tak::license::PluginLicense license;
    juce::AudioProcessorValueTreeState apvts;

    tpantheon::PhoenixChamber chamber;
    std::atomic<int> currentPresetIndex { 0 };
    // Routing preference, saved as a state property rather than adding or
    // reordering host parameters. Old states without it remain insert mode.
    std::atomic<bool> fxSendMode { true };
    std::atomic<float> meterOutL { 0.0f }, meterOutR { 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TPantheonAudioProcessor)
};
