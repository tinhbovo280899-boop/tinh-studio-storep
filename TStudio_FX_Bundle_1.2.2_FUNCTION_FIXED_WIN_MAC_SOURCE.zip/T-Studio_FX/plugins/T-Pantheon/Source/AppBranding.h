#pragma once
// Display branding for T-PANTHEON.
namespace AppBranding {
inline constexpr const char* kAppDisplayName = "T-PANTHEON";
inline constexpr const char* kBrandWord1 = "T-PANTHEON";
inline constexpr const char* kBrandWord2 = "";
inline constexpr const char* kBrandSubtitle = "T STUDIO CHAMBER REVERB";
inline constexpr const char* kSplashLine2 = "T STUDIO";
inline constexpr const char* kPublisher = "T Studio";
inline constexpr const char* kAppVersion = "1.1.0";
inline constexpr const char* kExeName = "T-PANTHEON.exe";
inline constexpr const char* kSetupName = "Setup_T_PANTHEON";
}
