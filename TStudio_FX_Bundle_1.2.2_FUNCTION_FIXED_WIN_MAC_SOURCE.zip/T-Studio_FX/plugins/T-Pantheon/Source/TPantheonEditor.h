#pragma once
#include "TPantheonProcessor.h"
#include "../../common/StudioSpecs.h"
class TPantheonAudioProcessorEditor final : public tstudio_ui::Editor
{
public:
    explicit TPantheonAudioProcessorEditor(TPantheonAudioProcessor&);
};
