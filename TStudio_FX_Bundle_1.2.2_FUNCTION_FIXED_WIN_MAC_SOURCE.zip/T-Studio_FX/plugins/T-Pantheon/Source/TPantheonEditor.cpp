#include "TPantheonEditor.h"
TPantheonAudioProcessorEditor::TPantheonAudioProcessorEditor(TPantheonAudioProcessor& p)
    : tstudio_ui::Editor(p,p.getAPVTS(),tstudio_ui::pantheonSpec(),p.getLicense(),[&p]{return std::array<float,2>{{p.getOutputLevelL(),p.getOutputLevelR()}};}) {}
