#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
namespace tpantheon
{

                                                                                          
struct TapDescriptor
{
    int prevTap;
    int tapIdx;
    int baseLen;
    uint32_t scaleFlag;
};

static constexpr std::array<TapDescriptor, 88> kPhoenixTapTable = {{
    {  0,  0,    0, 1 }, {  0, 80,   38, 1 },
    {  1,  1,    0, 1 }, {  1, 81,   89, 1 },
    {  2,  2,    0, 1 }, {  2, 82,   45, 1 },
    {  3,  3,    0, 1 }, {  3, 83,   74, 1 },
    {  4,  4,    0, 0 }, {  4, 22, 2395, 0 }, {  4, 23, 1273, 0 }, {  4, 24,    1, 0 },
    {  4, 25,  853, 0 }, {  4, 26,  293, 0 }, {  4, 27,    1, 0 }, {  4, 28,    1, 0 }, {  4, 29, 1400, 0 },
    {  5,  5,    0, 0 }, {  5, 30, 4497, 0 }, {  5, 31, 2197, 0 }, {  5, 32,  871, 0 },
    {  5, 33,    1, 0 }, {  5, 34,  301, 0 }, {  5, 35,    1, 0 }, {  5, 36,    1, 0 }, {  5, 37, 1400, 0 },
    {  6,  6,    0, 1 }, {  6, 38,   76, 1 }, {  6, 39,  194, 1 }, {  6, 40,  508, 1 }, {  6, 41,  627, 1 }, {  6, 42,  721, 1 },
    {  7,  7,    0, 1 }, {  7, 43,   76, 1 }, {  7, 44,  268, 1 }, {  7, 45,  507, 1 }, {  7, 46,  621, 1 }, {  7, 47,  622, 1 },
    {  8,  8,    0, 1 }, {  8, 48,  198, 1 }, {  8, 49,  345, 1 }, {  8, 50,  435, 1 }, {  8, 51,  520, 1 }, {  8, 52,  543, 1 },
    {  9,  9,    0, 1 }, {  9, 53,   21, 1 }, {  9, 54,  205, 1 }, {  9, 55,  395, 1 }, {  9, 56,  579, 1 }, {  9, 57,  793, 1 }, {  9, 58,  855, 1 },
    { 10, 10,    0, 1 }, { 10, 59,   23, 1 }, { 10, 60,  288, 1 }, { 10, 61,  454, 1 }, { 10, 62,  624, 1 },
    { 11, 11,    0, 1 }, { 11, 63,   47, 1 }, { 11, 64,   58, 1 }, { 11, 65,  326, 1 }, { 11, 66,  422, 1 },
    { 12, 12,    0, 1 }, { 12, 67,   33, 1 }, { 12, 68,  129, 1 },
    { 13, 13,    0, 1 }, { 13, 69,  166, 1 }, { 13, 70,  228, 1 },
    { 14, 14,    0, 1 }, { 14, 71,   61, 1 }, { 14, 72,  185, 1 },
    { 15, 15,    0, 1 }, { 15, 73,   59, 1 }, { 15, 74,  269, 1 },
    { 16, 16,    0, 1 }, { 16, 75,  148, 1 }, { 16, 76,  226, 1 },
    { 17, 17,    0, 1 }, { 17, 77,  110, 1 }, { 17, 78,  206, 1 }, { 17, 79,  428, 1 },
    { 18, 18,    0, 0 }, { 18, 84,    1, 0 },
    { 20, 20,    0, 0 }, { 20, 86,    1, 0 },
    { 19, 19,    0, 0 }, { 19, 85,    1, 0 },
    { 21, 21,    0, 0 }, { 21, 87,    1, 0 }
}};

                                                                                                    
class PhoenixChamber
{
public:
    static constexpr int kBufferSize = 524288;                  
    static constexpr int kBufferMask = 0x7ffff;

    PhoenixChamber()
    {
        delayBuf.assign(static_cast<size_t>(kBufferSize), 0.0f);
        reset();
    }

    void prepare(double sampleRate)
    {
        sr = static_cast<float>(std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0);
        size_t required = kBufferSize;
        while (required < static_cast<size_t>(std::ceil(sr * 2.6))) required *= 2;
        delayBuf.resize(required);
        bufferMask = static_cast<int>(required - 1);
        initFixedGains();
        rebuildTapOffsets(true);
        updateDampingCoeffs();
        updateBassAndRT60Coeffs();
        smoothing = static_cast<float>(1.0 - std::exp(-1.0 / (0.02 * sr)));
        for (auto* s : { &diffuseA, &diffuseB, &tankDiffuse, &earlyBlend, &lateBlend }) s->reset(sr, 0.02);
        configured = false;
    }

    void reset()
    {
        std::fill(delayBuf.begin(), delayBuf.end(), 0.0f);
        writePos = 0;
        wetLow.fill(0.0f);
        wetBassLow.fill(0.0f);
        tapTransition = 0;
        pendingTaps = false;
        decayGain = targetDecay;
        for (auto* s : { &diffuseA, &diffuseB, &tankDiffuse, &earlyBlend, &lateBlend })
            s->setCurrentAndTargetValue(s->getTargetValue());
    }

                                                                                   
    void setParameters(int reverbType,
                       float roomSizeMeters,
                       float rt60Seconds,
                       float spreadPct,
                       float dampingHz,
                       float bassBoostMult,
                       float bassFreqHz,
                       float diffusionPct,
                       float regenPct,
                       float delayMs,
                       float preDelayMs,
                       float mixPct,
                       float levelDb,
                       float echoLvlLDb,
                       float echoTimeLMs,
                       float echoLvlRDb,
                       float echoTimeRMs,
                       float inputLinearGain)
    {
        // Six T Studio voicings of the existing chamber network. These are not
        // six recovered vendor algorithms; the topology and parameter IDs stay.
        struct Voicing { float inputDiffusion, tankDiffusion, early, late; };
        static constexpr Voicing voices[] = {
            { 0.95f, 0.63f, 0.30f, 1.05f }, // Hall: dense, late-dominant
            { 0.90f, 0.53f, 0.75f, 0.95f }, // Chamber: balanced
            { 0.65f, 0.32f, 1.10f, 0.78f }, // Room: distinct early reflections
            { 1.12f, 0.72f, 0.12f, 1.10f }, // Plate: dense and diffuse
            { 0.45f, 0.22f, 1.15f, 0.58f }, // Ambience: early-dominant
            { 1.00f, 0.50f, 1.00f, 1.00f }  // Custom: uncoloured routing
        };
        const auto voice = voices[juce::jlimit(0, 5, reverbType)];
        auto finite = [](float v, float fallback) { return std::isfinite(v) ? v : fallback; };
        roomSizeMeters=finite(roomSizeMeters,38); rt60Seconds=finite(rt60Seconds,2.03f);
        spreadPct=finite(spreadPct,83); dampingHz=finite(dampingHz,2080);
        bassBoostMult=finite(bassBoostMult,1.2f); bassFreqHz=finite(bassFreqHz,381);
        diffusionPct=finite(diffusionPct,65); regenPct=finite(regenPct,0);
        delayMs=finite(delayMs,14); preDelayMs=finite(preDelayMs,12);
        mixPct=finite(mixPct,15); levelDb=finite(levelDb,0);
        echoLvlLDb=finite(echoLvlLDb,-60); echoLvlRDb=finite(echoLvlRDb,-60);
        echoTimeLMs=finite(echoTimeLMs,0); echoTimeRMs=finite(echoTimeRMs,0);
        inputLinearGain=finite(inputLinearGain,1);

                                                               
        const float sizeNorm   = juce::jlimit(0.0f, 1.0f, (roomSizeMeters - 4.0f) / 72.0f);
        const float newSize    = sizeNorm * 18.0f + 1.0f;

                                                    
        const float spreadNorm = juce::jlimit(0.0f, 1.0f, spreadPct * 0.01f);
        const float newSpread  = spreadNorm * 256.0f;

                                                                                      
        const float newPreDly  = juce::jlimit(1.0f, 22050.0f, preDelayMs * 44.1f + 1.0f);
        const float newDly     = juce::jlimit(1.0f, 52920.0f, delayMs * 44.1f + 1.0f);

                                                                                   
        const float newEchoTL  = juce::jlimit(0.0f, 1.0f, echoTimeLMs / 1200.0f);
        const float newEchoTR  = juce::jlimit(0.0f, 1.0f, echoTimeRMs / 1200.0f);
        const float newEarlyScale = juce::jlimit(0.125f, 1.0f, rt60Seconds / 0.8f);

        const bool tapsChanged = (std::fabs(newSize - paramSize) > 0.01f ||
                                  std::fabs(newSpread - paramSpread) > 0.1f ||
                                  std::fabs(newPreDly - paramPreDelay) > 0.5f ||
                                  std::fabs(newDly - paramDelay) > 0.5f ||
                                  std::fabs(newEchoTL - paramEchoTimeL) > 0.0005f ||
                                  std::fabs(newEchoTR - paramEchoTimeR) > 0.0005f ||
                                  std::fabs(newEarlyScale - paramEarlyScale) > 0.0001f);

        paramSize      = newSize;
        paramSpread    = newSpread;
        paramPreDelay  = newPreDly;
        paramDelay     = newDly;
        paramEchoTimeL = newEchoTL;
        paramEchoTimeR = newEchoTR;
        paramEarlyScale = newEarlyScale;

        // 5. RT60 (seconds), Damping (Hz), Bass Boost (multiplier - 1.0), Bass Freq (Hz)
        paramRT60      = juce::jlimit(0.05f, 10.0f, rt60Seconds);
        paramDamping   = juce::jlimit(100.0f, 20000.0f, dampingHz);
        paramBassBoost = juce::jlimit(-0.9f, 4.0f, bassBoostMult - 1.0f);
        paramBassFreq  = juce::jlimit(30.0f, 20000.0f, bassFreqHz);

                                                                                       
        const float diffNorm = juce::jlimit(0.0f, 1.0f, diffusionPct * 0.01f);
        auto smooth = [this](juce::SmoothedValue<float>& s, float target) {
            if (configured) s.setTargetValue(target); else s.setCurrentAndTargetValue(target);
        };
        smooth(diffuseA, std::min(0.90f, diffNorm * voice.inputDiffusion * 0.75f));
        smooth(diffuseB, std::min(0.85f, diffNorm * voice.inputDiffusion * 0.625f));
        smooth(tankDiffuse, voice.tankDiffusion);
        smooth(earlyBlend, voice.early);
        smooth(lateBlend, voice.late);

                                                    
        const float regenVal = (regenPct <= 0.05f) ? 0.0f : juce::jlimit(0.0f, 0.95f, regenPct * 0.0095f);
        g[5]  = regenVal;
        g[11] = regenVal;

                                                                           
        wetGain   = juce::jlimit(0.0f, 1.0f, mixPct * 0.01f);
        dryGain   = 1.0f - wetGain;
        levelGain = juce::Decibels::decibelsToGain(levelDb, -60.0f);
        echoGainL = (echoLvlLDb <= -59.5f) ? 0.0f : juce::Decibels::decibelsToGain(echoLvlLDb, -60.0f);
        echoGainR = (echoLvlRDb <= -59.5f) ? 0.0f : juce::Decibels::decibelsToGain(echoLvlRDb, -60.0f);
        inputGain = juce::jlimit(0.0f, 4.0f, inputLinearGain);

        updateDampingCoeffs();
        if (tapsChanged)
            rebuildTapOffsets(false);
        updateBassAndRT60Coeffs();
        if (!configured) {
            tapTransition = 0;
            pendingTaps = false;
            decayGain = targetDecay;
            currentDampingPole = wetDampingPole;
            currentBassPole = wetBassPole;
            currentBassBoost = 1.0f + paramBassBoost;
        }
        configured = true;
    }

                                                                                     
    inline void processStereoSample(float inL, float inR, float& outL, float& outR) noexcept
    {
        inL = std::isfinite(inL) ? inL : 0.0f;
        inR = std::isfinite(inR) ? inR : 0.0f;
        g[43] = g[45] = diffuseA.getNextValue();
        g[44] = g[46] = diffuseB.getNextValue();
        g[35] = tankDiffuse.getNextValue();
        const float early = earlyBlend.getNextValue(), late = lateBlend.getNextValue();
        const int wp = writePos;
        const float transition = tapTransition > 0 ? 1.0f - float(tapTransition) / float(tapTransitionLength) : 1.0f;
        auto rd = [this, wp, transition](int tag) noexcept -> float
        {
            decayGain[tag] += smoothing * (targetDecay[tag] - decayGain[tag]);
            float x = delayBuf[static_cast<size_t>((wp + taps[tag]) & bufferMask)] * decayGain[tag];
            if (tapTransition > 0) {
                const float old = delayBuf[static_cast<size_t>((wp + previousTaps[tag]) & bufferMask)] * previousDecay[tag];
                x = old + (x - old) * transition;
            }
            return std::isfinite(x) ? x : 0.0f;
        };
        auto wr = [this, wp](int tapOffset, float val) noexcept
        {
            const float clean = std::isfinite(val) ? (val + 1.0e-18f) - 1.0e-18f : 0.0f;
            delayBuf[static_cast<size_t>((wp + tapOffset) & bufferMask)] = juce::jlimit(-4.0f, 4.0f, clean);
        };

                                                                 
        const float sL = inL * inputGain;
        const float ap0_del = rd(80);
        const float ap0_in  = sL - ap0_del * g[43] + rd(27) * g[5];
        wr(taps[0], ap0_in);
        const float ap0_out = ap0_in * g[43] + ap0_del;

        const float ap1_del = rd(81);
        const float ap1_in  = ap0_out - ap1_del * g[44];
        wr(taps[1], ap1_in);
        const float ap1_out = ap1_in * g[44] + ap1_del;
        wr(taps[4], ap1_out);

                                                                  
        const float sR = inR * inputGain;
        const float ap2_del = rd(82);
        const float ap2_in  = sR - ap2_del * g[45] + rd(35) * g[11];
        wr(taps[2], ap2_in);
        const float ap2_out = ap2_in * g[45] + ap2_del;

        const float ap3_del = rd(83);
        const float ap3_in  = ap2_out - ap3_del * g[46];
        wr(taps[3], ap3_in);
        const float ap3_out = ap3_in * g[46] + ap3_del;
        wr(taps[5], ap3_out);

                                                    
        // Note: taps[85] = taps[19] + 1 (1-sample z^-1 state for Damping A)
        //       taps[84] = taps[18] + 1 (1-sample z^-1 state for Bass/RT60 A)
        const float sumA     = rd(25) * g[4] + rd(22) * g[1] + rd(52);
        const float dampA_z1 = rd(85);
        const float dampA_in = sumA + dampA_z1 * dampA1;
        wr(taps[19], dampA_in);
        const float dampA_out = dampA_in * dampB0 + dampA_z1 * dampB1;

        const float bassA_z1 = rd(84);
        const float bassA_in = dampA_out + bassA_z1 * bassA1;
        wr(taps[18], bassA_in);
        const float bassA_out = bassA_in * bassB0 + bassA_z1 * bassB1;

        const float tankApA_del = rd(74);
        const float tankApA_in  = bassA_out - tankApA_del * g[35];
        wr(taps[15], tankApA_in);
        const float tankApA_out = tankApA_in * g[35] + tankApA_del;
        wr(taps[9], tankApA_out);

                                                    
        const float sumB        = rd(23) * g[2] + rd(58) * rt60Gain;
        const float tankApB_del = rd(76);
        const float tankApB_in  = sumB + tankApB_del * g[35];
        wr(taps[16], tankApB_in);
        const float tankApB_out = tankApB_del - tankApB_in * g[35];
        wr(taps[10], tankApB_out);

                                                    
        const float sumC        = rd(24) * g[3] - rd(62) * rt60Gain;
        const float tankApC_del = rd(79);
        const float tankApC_in  = sumC - tankApC_del * g[35];
        wr(taps[17], tankApC_in);
        const float tankApC_out = tankApC_in * g[35] + tankApC_del;
        wr(taps[11], tankApC_out);

                                                    
        // Note: taps[87] = taps[21] + 1 (1-sample z^-1 state for Damping D)
        //       taps[86] = taps[20] + 1 (1-sample z^-1 state for Bass/RT60 D)
        const float sumD     = rd(30) * g[7] + rd(33) * g[10] + rd(66);
        const float dampD_z1 = rd(87);
        const float dampD_in = sumD + dampD_z1 * dampA1;
        wr(taps[21], dampD_in);
        const float dampD_out = dampD_in * dampB0 + dampD_z1 * dampB1;

        const float bassD_z1 = rd(86);
        const float bassD_in = dampD_out + bassD_z1 * bassA1;
        wr(taps[20], bassD_in);
        const float bassD_out = bassD_in * bassB0 + bassD_z1 * bassB1;

        const float tankApD_del = rd(68);
        const float tankApD_in  = bassD_out + tankApD_del * g[35];
        wr(taps[12], tankApD_in);
        const float tankApD_out = tankApD_del - tankApD_in * g[35];
        wr(taps[6], tankApD_out);

                                                    
        const float sumE        = rd(31) * g[8] + rd(42) * rt60Gain;
        const float tankApE_del = rd(70);
        const float tankApE_in  = sumE - tankApE_del * g[35];
        wr(taps[13], tankApE_in);
        const float tankApE_out = tankApE_in * g[35] + tankApE_del;
        wr(taps[7], tankApE_out);

                                                    
        const float sumF        = rd(32) * g[9] + rd(47) * rt60Gain;
        const float tankApF_del = rd(72);
        const float tankApF_in  = sumF + tankApF_del * g[35];
        wr(taps[14], tankApF_in);
        const float tankApF_out = tankApF_del - tankApF_in * g[35];
        wr(taps[8], tankApF_out);

                                                                      
        const float accumL = rd(53) * g[24]
                           + rd(55) * g[26]
                           + rd(57) * g[28]
                           + rd(51) * g[23]
                           + rd(49) * g[21]
                           + rd(71) * g[38]
                           + rd(59) * g[29]
                           + rd(61) * g[31]
                           + rd(45) * g[18]
                           + rd(43) * g[16]
                           + rd(78) * g[42]
                           + rd(64) * g[33]
                           + rd(41) * g[15]
                           + rd(39) * g[13]
                           + rd(63) * g[36]
                           + rd(26) * g[0];
        const float earlyL = rd(26) * g[0];
        const float wetL = ((accumL - earlyL) * late + earlyL * early) * g[34] + rd(28) * echoGainL;

                                                                        
        const float accumR = rd(73) * g[39]
                           + rd(54) * g[25]
                           + rd(56) * g[27]
                           + rd(50) * g[22]
                           + rd(48) * g[20]
                           + rd(75) * g[40]
                           + rd(60) * g[30]
                           + rd(46) * g[19]
                           + rd(44) * g[17]
                           + rd(77) * g[41]
                           + rd(59) * g[32]
                           + rd(67) * g[37]
                           + rd(65) * g[34]
                           + rd(40) * g[14]
                           + rd(38) * g[12]
                           + rd(34) * g[6];
        const float earlyR = rd(34) * g[6];
        const float wetR = ((accumR - earlyR) * late + earlyR * early) * g[34] + rd(36) * echoGainR;
        currentDampingPole += smoothing * (wetDampingPole - currentDampingPole);
        currentBassPole += smoothing * (wetBassPole - currentBassPole);
        currentBassBoost += smoothing * (1.0f + paramBassBoost - currentBassBoost);
        auto colour = [this](float wet, int channel) noexcept {
            wetLow[channel] = (1.0f - currentDampingPole) * wet + currentDampingPole * wetLow[channel];
            wetBassLow[channel] = (1.0f - currentBassPole) * wetLow[channel] + currentBassPole * wetBassLow[channel];
            return wetLow[channel] + (currentBassBoost - 1.0f) * wetBassLow[channel];
        };
        outL = (sL * dryGain + colour(wetL, 0) * wetGain) * levelGain;
        outR = (sR * dryGain + colour(wetR, 1) * wetGain) * levelGain;

        writePos = (wp - 1) & bufferMask;
        if (tapTransition > 0 && --tapTransition == 0 && pendingTaps) {
            pendingTaps = false;
            rebuildTapOffsets(false);
        }
    }

private:
                                                                                 
    void initFixedGains() noexcept
    {
        g.fill(0.0f);
        g[0]  =  0.9375f;  g[1]  =  0.9375f;  g[2]  =  0.9375f;  g[3]  =  0.9375f;
        g[4]  =  0.0f;     g[5]  =  0.0f;     g[6]  =  0.9375f;  g[7]  =  0.9375f;
        g[8]  =  0.9375f;  g[9]  =  0.9375f;  g[10] =  0.0f;     g[11] =  0.0f;
        g[12] =  0.4375f;  g[13] = -0.375f;   g[14] =  0.375f;   g[15] =  0.5f;
        g[16] = -0.4375f;  g[17] = -0.375f;   g[18] = -0.375f;   g[19] =  0.5f;
        g[20] = -0.4375f;  g[21] =  0.375f;   g[22] = -0.375f;   g[23] =  0.5f;
        g[24] = -0.4375f;  g[25] = -0.4375f;  g[26] =  0.375f;   g[27] =  0.375f;
        g[28] = -0.5f;     g[29] =  0.375f;   g[30] =  0.375f;   g[31] = -0.4375f;
        g[32] = -0.375f;   g[33] =  0.0f;     g[34] =  0.375f;   g[35] =  0.5f;
        g[36] = -0.5f;     g[37] =  0.5f;     g[38] = -0.5f;     g[39] =  0.5f;
        g[40] =  0.5f;     g[41] =  0.5f;     g[42] =  0.5f;     g[43] =  0.75f;
        g[44] =  0.625f;   g[45] =  0.75f;    g[46] =  0.625f;   g[47] =  1.0f;
    }

                                                                                      
    void updateDampingCoeffs() noexcept
    {
        const double fc = juce::jlimit(100.0, static_cast<double>(sr) * 0.42, static_cast<double>(paramDamping));
        // Tone filtering is outside the recirculating network, so turning a
        // cutoff does not silently redefine the displayed decay time.
        const double a = 2.0 - std::cos(6.283185307179586 * fc / sr);
        wetDampingPole = static_cast<float>(a - std::sqrt(a * a - 1.0));
        dampB0 = 1.0f; dampB1 = dampA1 = 0.0f;
    }

                                                                                                     
    void updateBassAndRT60Coeffs() noexcept
    {
                                                                                    
        const double rt = std::max(0.05, static_cast<double>(paramRT60));
        // Uniform exponential loss on every tank delay, including the tank
        // allpasses: H(z) becomes H(z/alpha). This accounts for actual delay
        // age rather than applying one "longest delay" loss six times.
        if (decayDirty || lastDecayRT != paramRT60) {
            for (size_t i = 0; i < targetDecay.size(); ++i)
                targetDecay[i] = tapAge[i] == 0 ? 1.0f : static_cast<float>(std::exp(-6.907755278982137 * tapAge[i] / (rt * sr)));
            lastDecayRT = paramRT60;
            decayDirty = false;
        }
        rt60Gain = 1.0f;
        const double fc = juce::jlimit(30.0, static_cast<double>(sr) * 0.40, static_cast<double>(paramBassFreq));
        const double a = 2.0 - std::cos(6.283185307179586 * fc / sr);
        wetBassPole = static_cast<float>(a - std::sqrt(a * a - 1.0));
        // Bass is a feed-forward wet shelf. Its complete 0.1x..2.5x range
        // remains useful without raising any feedback gain above unity.
        bassB0 = 1.0f; bassB1 = bassA1 = 0.0f;
    }

                                                                      
    void rebuildTapOffsets(bool clearBuffer = false) noexcept
    {
        // Coalesce edits arriving during a read-head crossfade. Restarting a
        // fade mid-flight would itself create a discontinuity.
        if (!clearBuffer && tapTransition > 0) { pendingTaps = true; return; }
        previousTaps = taps;
        previousDecay = decayGain;
        const double srRatio   = static_cast<double>(sr) / 44100.0;
        const double sizeRatio = static_cast<double>(paramSize) / 19.0;

        int runningEnd = 0;                                 
        for (const auto& td : kPhoenixTapTable)
        {
            if (td.baseLen == 0)
            {
                taps[static_cast<size_t>(td.tapIdx)] = runningEnd & bufferMask;
                continue;
            }

            double deltaSamples = 1.0;
            double maxDeltaSamples = 1.0;

            if (td.scaleFlag != 0)
            {
                                                                          
                deltaSamples    = static_cast<double>(td.baseLen) * sizeRatio * srRatio;
                maxDeltaSamples = static_cast<double>(td.baseLen) * srRatio;
            }
            else if (td.tapIdx <= 37)
            {
                                                                         
                switch (td.tapIdx)
                {
                    case 22: case 23: case 24: case 25: case 26:
                    case 30: case 31: case 32: case 33: case 34:
                                                                                                                            
                        deltaSamples    = (static_cast<double>(td.baseLen)
                                        * (1.0 + (static_cast<double>(paramSpread) + 28.0) / 284.0)
                                        * paramEarlyScale + paramPreDelay) * srRatio;
                        maxDeltaSamples = (2.0 * static_cast<double>(td.baseLen) + 22050.0) * srRatio;
                        break;

                    case 27: case 35:
                                                               
                        deltaSamples    = static_cast<double>(paramDelay) * srRatio;
                        maxDeltaSamples = 52920.0 * srRatio;
                        break;

                    case 28:
                                                              
                        deltaSamples    = static_cast<double>(paramEchoTimeL) * 1.2 * static_cast<double>(sr);
                        maxDeltaSamples = 1.2 * static_cast<double>(sr);
                        break;

                    case 29: case 37:
                                                             
                        deltaSamples    = (2.0 * static_cast<double>(td.baseLen) * paramEarlyScale + paramPreDelay) * srRatio;
                        maxDeltaSamples = (2.0 * static_cast<double>(td.baseLen) + 22050.0) * srRatio;
                        break;

                    case 36:
                                                               
                        deltaSamples    = static_cast<double>(paramEchoTimeR) * 1.2 * static_cast<double>(sr);
                        maxDeltaSamples = 1.2 * static_cast<double>(sr);
                        break;

                    default:
                        deltaSamples    = static_cast<double>(td.baseLen) * srRatio;
                        maxDeltaSamples = deltaSamples;
                        break;
                }
            }
            else
            {
                                                                                                                 
                deltaSamples    = 1.0;
                maxDeltaSamples = 1.0;
            }

            const int prevStart = taps[static_cast<size_t>(td.prevTap)];
            const int tapPos    = prevStart + std::max(1, static_cast<int>(std::ceil(deltaSamples)));
            taps[static_cast<size_t>(td.tapIdx)] = tapPos & bufferMask;
            tapAge[static_cast<size_t>(td.tapIdx)] = td.prevTap >= 6 && td.prevTap <= 21
                ? std::max(1, static_cast<int>(std::ceil(deltaSamples))) : 0;

                                                                                                               
            const int maxEnd = prevStart + std::max(1, static_cast<int>(std::ceil(maxDeltaSamples))) + 2;
            if (maxEnd > runningEnd)
                runningEnd = maxEnd;
        }

        decayDirty = true;
        updateBassAndRT60Coeffs();
        if (clearBuffer) {
            decayGain = targetDecay;
            reset();
        } else {
            tapTransitionLength = std::max(1, static_cast<int>(sr * 0.02));
            tapTransition = tapTransitionLength;
        }
    }

    float sr = 44100.0f;
    std::vector<float> delayBuf;
    int writePos = 0;
    int bufferMask = kBufferMask;
    std::array<int, 96> taps {};
    std::array<int, 96> previousTaps {}, tapAge {};
    std::array<float, 96> decayGain {}, targetDecay {}, previousDecay {};
    int tapTransition = 0, tapTransitionLength = 1;
    bool pendingTaps = false, configured = false;
    bool decayDirty = true;
    float lastDecayRT = -1.0f;
    float smoothing = 0.001f;
    juce::SmoothedValue<float> diffuseA, diffuseB, tankDiffuse, earlyBlend, lateBlend;
    std::array<float, 2> wetLow {}, wetBassLow {};
    float wetDampingPole = 0.5f, wetBassPole = 0.9f;
    float currentDampingPole = 0.5f, currentBassPole = 0.9f, currentBassBoost = 1.2f;
    std::array<float, 48> g {};

    float paramSize      = 9.5f;
    float paramSpread    = 212.48f;
    float paramPreDelay  = 530.0f;
    float paramDelay     = 618.0f;
    float paramEchoTimeL = 0.0f;
    float paramEchoTimeR = 0.0f;
    float paramEarlyScale = 1.0f;
    float paramRT60      = 2.03f;
    float paramDamping   = 2080.0f;
    float paramBassBoost = 0.2f;
    float paramBassFreq  = 381.0f;

    float dampB0 = 0.25f, dampB1 = 0.0f, dampA1 = 0.75f;
    float bassB0 = 0.82f, bassB1 = 0.0f, bassA1 = 0.95f;
    float rt60Gain  = 0.82f;
    float wetGain   = 0.15f;
    float dryGain   = 0.85f;
    float levelGain = 1.0f;
    float echoGainL = 0.0f;
    float echoGainR = 0.0f;
    float inputGain = 1.0f;
};

struct PantheonPreset
{
    const char* name;
    int reverbType; // 0=Hall, 1=Chamber, 2=Room, 3=Plate, 4=Ambience, 5=Custom
    std::array<float, 16> normVals;                                                                    
};

} // namespace tpantheon
