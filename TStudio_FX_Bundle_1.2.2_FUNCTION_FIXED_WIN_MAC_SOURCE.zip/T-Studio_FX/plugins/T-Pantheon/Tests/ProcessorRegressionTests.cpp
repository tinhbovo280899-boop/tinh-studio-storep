#include "TPantheonProcessor.h"
#include "LicenseForTests.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include <cstdio>
#include <limits>
#include <cmath>
#include <vector>
static int failures=0;
#define CHECK(x) do { if(!(x)){std::printf("FAIL line %d: %s\n",__LINE__,#x);++failures;} }while(0)

static void set(juce::AudioProcessorValueTreeState& v,const char* id,float value){auto* p=v.getParameter(id);CHECK(p);if(p)p->setValueNotifyingHost(p->convertTo0to1(value));}
static juce::Button* routeButton(juce::Component& c){
 if(auto* b=dynamic_cast<juce::Button*>(&c);b&&b->getButtonText()=="FX SEND 100% WET")return b;
 for(int i=0;i<c.getNumChildComponents();++i)if(auto* b=routeButton(*c.getChildComponent(i)))return b;
 return nullptr;
}
int main(){juce::ScopedJuceInitialiser_GUI gui;
 TPantheonAudioProcessor p;if(!tstudio_test::unlock(p.getLicense()))return tstudio_test::kSkip;p.setPlayConfigDetails(1,2,32000,128);p.prepareToPlay(32000,128);
 CHECK(p.isFxSendMode());p.setFxSendMode(false); // legacy insert dry test
 auto& v=p.getAPVTS();set(v,"mix",0);set(v,"inputLevel",0);set(v,"level",0);
 juce::AudioBuffer<float>b(2,128);juce::MidiBuffer m;for(int i=0;i<128;++i){b.setSample(0,i,-.25f);b.setSample(1,i,.9f);}p.processBlock(b,m);
 for(int i=0;i<128;++i){CHECK(std::abs(b.getSample(0,i)+.25f)<1e-6);CHECK(std::abs(b.getSample(1,i)+.25f)<1e-6);}
 set(v,"rt60",6.59f);CHECK(p.getTailLengthSeconds()>12);

 p.setFxSendMode(true);
 for(int preset=0;preset<p.getNumPrograms();++preset){p.setCurrentProgram(preset);CHECK(v.getRawParameterValue("mix")->load()==100.f);p.releaseResources();p.prepareToPlay(32000,128);for(int k=0;k<6;++k){for(int i=0;i<128;++i){b.setSample(0,i,.1f*std::sin((i+k*128)*.2));b.setSample(1,i,0);}p.processBlock(b,m);for(int ch=0;ch<2;++ch)for(int i=0;i<128;++i)CHECK(std::isfinite(b.getSample(ch,i)));}}
 const int index=p.getNumPrograms()-1;p.setCurrentProgram(index);juce::MemoryBlock state;p.getStateInformation(state);TPantheonAudioProcessor q;q.setStateInformation(state.getData(),int(state.getSize()));CHECK(q.getCurrentProgram()==index);
 CHECK(q.isFxSendMode());
 for(const auto* id:{"mix","inputLevel"})CHECK(std::abs(p.getAPVTS().getRawParameterValue(id)->load()-q.getAPVTS().getRawParameterValue(id)->load())<1e-6);
 // A state written before routing mode existed must retain its insert Mix.
 p.setFxSendMode(false);set(v,"mix",23);p.getStateInformation(state);
 auto legacy=juce::AudioProcessor::getXmlFromBinary(state.getData(),int(state.getSize()));CHECK(legacy!=nullptr);
 if(legacy){legacy->removeAttribute("fxSendMode");juce::AudioProcessor::copyXmlToBinary(*legacy,state);
     q.setFxSendMode(true);q.setStateInformation(state.getData(),int(state.getSize()));
     CHECK(!q.isFxSendMode());CHECK(std::abs(q.getAPVTS().getRawParameterValue("mix")->load()-23.f)<1.e-4f);}
 CHECK(p.getParameters().size()==18);
 p.setFxSendMode(true);set(v,"mix",0);set(v,"preDelay",50);p.releaseResources();p.prepareToPlay(32000,128);
 for(int i=0;i<128;++i){b.setSample(0,i,.2f);b.setSample(1,i,0);}p.processBlock(b,m);
 CHECK(b.getMagnitude(0,128)<1.e-6f); // no dry leakage even if host automates Mix
 std::unique_ptr<juce::AudioProcessorEditor> e(p.createEditor());CHECK(e!=nullptr);
 if(e){auto* route=routeButton(*e);CHECK(route!=nullptr);if(route){
     route->setToggleState(false,juce::dontSendNotification);route->onClick();CHECK(!p.isFxSendMode());
     route->setToggleState(true,juce::dontSendNotification);route->onClick();CHECK(p.isFxSendMode());CHECK(v.getRawParameterValue("mix")->load()==100.f);}
     const auto path=juce::SystemStats::getEnvironmentVariable("TSTUDIO_QA_SNAPSHOT",{});
     if(path.isNotEmpty()){
       #if JUCE_MODAL_LOOPS_PERMITTED
        juce::MessageManager::getInstance()->runDispatchLoopUntil(80);
       #endif
        juce::Image image(juce::Image::ARGB,e->getWidth(),e->getHeight(),true);juce::Graphics g(image);e->paintEntireComponent(g,true);
        auto stream=juce::File(path).createOutputStream();CHECK(stream!=nullptr);if(stream)CHECK(juce::PNGImageFormat().writeImageToStream(image,*stream));
     }
 }
 p.releaseResources();
 std::printf("TPantheonAudioProcessor mono/stereo, meters/tempo/tail, %d presets, state/editor: %d failures\n",p.getNumPrograms(),failures);
 return failures?1:0;}
