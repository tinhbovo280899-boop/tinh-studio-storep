#include "dsp/PhoenixChamber.h"
#include <cstdio>
#include <limits>
#include <cmath>
#include <vector>
static int failures=0;
#define CHECK(x) do { if(!(x)){std::printf("FAIL line %d: %s\n",__LINE__,#x);++failures;} }while(0)

static void config(tpantheon::PhoenixChamber& c,float mix=100,float rt=2.03f) {
 c.setParameters(1,38,rt,83,2080,1.2f,381,65,0,14,12,mix,0,-60,0,-60,0,1);
}
int main(){
 int cases=0;
 for(double sr:{8000.,16000.,32000.,44100.,48000.,96000.,192000.,384000.}) {
  tpantheon::PhoenixChamber c;c.prepare(sr);config(c,0);
  for(int i=0;i<1024;++i){float l,r;c.processStereoSample(.1f,-.2f,l,r);CHECK(std::abs(l-.1f)<1e-6);CHECK(std::abs(r+.2f)<1e-6);}
  config(c);c.reset();double energy=0;
  for(int i=0;i<int(sr);++i){float l,r;c.processStereoSample(i==0?.25f:0,0,l,r);CHECK(std::isfinite(l)&&std::isfinite(r));energy+=l*l+r*r;}
  CHECK(energy>1e-10);c.reset();
  for(int i=0;i<1024;++i){float l,r;c.processStereoSample(0,0,l,r);CHECK(l==0&&r==0);}
  ++cases;
 }
 for(int ch:{0,1}) {
  tpantheon::PhoenixChamber a,b;a.prepare(48000);b.prepare(48000);config(a);config(b);
  for(int i=0;i<48000;++i){float x=.05f*std::sin(i*.17f),y=.03f*std::cos(i*.11f);float al,ar,bl,br;
   float il=x,ir=y;if(i==501||i==502){if(ch==0)il=i==501?std::numeric_limits<float>::quiet_NaN():std::numeric_limits<float>::infinity();else ir=i==501?std::numeric_limits<float>::quiet_NaN():std::numeric_limits<float>::infinity();}
   a.processStereoSample(il,ir,al,ar);b.processStereoSample(std::isfinite(il)?il:0,std::isfinite(ir)?ir:0,bl,br);
   CHECK(std::isfinite(al)&&std::isfinite(ar));CHECK(std::abs(al-bl)<1e-6&&std::abs(ar-br)<1e-6);
  }++cases;
 }
 std::printf("Reverb DSP: %d rate/NaN/Inf cases; %d failures\n",cases,failures);return failures?1:0;
}
