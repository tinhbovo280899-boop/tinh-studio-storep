#include "dsp/PhoenixChamber.h"
#include <cstdio>
#include <limits>
#include <numeric>

static int failures=0,checks=0;
#define CHECK(x) do { ++checks; if(!(x)){std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;} }while(false)

static void configure(tpantheon::PhoenixChamber& c,int type=0,float rt=2.03f,float size=38,float bass=1.2f,float damping=2080,float mix=100)
{c.setParameters(type,size,rt,83,damping,bass,381,65,0,14,12,mix,0,-60,0,-60,0,1);}
static std::vector<float> impulse(double sr,int type,float rt,float size=38,float bass=1.2f,float damping=2080)
{
    tpantheon::PhoenixChamber c;c.prepare(sr);configure(c,type,rt,size,bass,damping);c.reset();
    std::vector<float> a(size_t(sr*(2*rt+1))*2);
    for(size_t i=0;i<a.size()/2;++i)c.processStereoSample(i==0?.1f:0,i==0?.1f:0,a[i*2],a[i*2+1]);
    return a;
}
// Independent measurement filter: a 1 kHz, 1/3-octave RBJ bandpass, then
// Schroeder integration and a least-squares T30 fit (-5..-35 dB).
static double measureRt(const std::vector<float>& a,double sr)
{
    const double w=2*juce::MathConstants<double>::pi*1000/sr,alpha=std::sin(w)/(2*4.318473046963146);
    const double b0=alpha/(1+alpha),b2=-b0,a1=-2*std::cos(w)/(1+alpha),a2=(1-alpha)/(1+alpha);
    double x1[2]{},x2[2]{},y1[2]{},y2[2]{};
    std::vector<double> edc(a.size()/2);
    for(size_t i=0;i<edc.size();++i)for(int c=0;c<2;++c){
        const double x=a[i*2+c],y=b0*x+b2*x2[c]-a1*y1[c]-a2*y2[c];
        x2[c]=x1[c];x1[c]=x;y2[c]=y1[c];y1[c]=y;edc[i]+=y*y;
    }
    for(size_t i=edc.size()-1;i>0;--i)edc[i-1]+=edc[i];
    double st=0,sy=0,stt=0,sty=0,n=0;
    for(size_t i=0;i<edc.size();++i){const double db=10*std::log10(std::max(1.e-30,edc[i]/edc[0]));
        if(db<=-5&&db>=-35){const double t=i/sr;++n;st+=t;sy+=db;stt+=t*t;sty+=t*db;}}
    return n>10 ? -60/((n*sty-st*sy)/(n*stt-st*st)) : -1;
}
static double difference(const std::vector<float>& a,const std::vector<float>& b)
{double m=0;for(size_t i=0;i<a.size();++i)m=std::max(m,std::abs(double(a[i])-b[i]));return m;}
static double toneRms(float hz,float damping,float bass)
{
    tpantheon::PhoenixChamber c;c.prepare(48000);configure(c,0,1,38,bass,damping);double sum=0;
    for(int i=0;i<96000;++i){float l,r;const float x=.02f*std::sin(float(2*juce::MathConstants<double>::pi*hz*i/48000));
        c.processStereoSample(x,x,l,r);if(i>=48000)sum+=double(l)*l+double(r)*r;}
    return std::sqrt(sum/96000);
}
int main()
{
    for(double sr:{44100.,48000.,96000.})for(float rt:{.5f,2.03f,5.f}){
        const auto a=impulse(sr,0,rt);const double measured=measureRt(a,sr);
        std::printf("RT sr=%.0f requested=%.3f measured_1k=%.6f\n",sr,rt,measured);
        const double tolerance=rt<=.5f?.20:.10;
        CHECK(measured>rt*(1-tolerance)&&measured<rt*(1+tolerance));
    }
    for(float size:{8.f,38.f,76.f})for(int type=0;type<6;++type){
        auto a=impulse(48000,type,2.03f,size);const double measured=measureRt(a,48000);
        std::printf("TYPE type=%d size=%.0f measured_1k=%.6f\n",type,size,measured);
        CHECK(measured>2.03*.9&&measured<2.03*1.1);
    }
    std::array<std::vector<float>,6> modes;
    for(int i=0;i<6;++i)modes[size_t(i)]=impulse(48000,i,1);
    for(int a=0;a<6;++a)for(int b=a+1;b<6;++b)CHECK(difference(modes[a],modes[b])>1.e-6);
    auto previous=impulse(48000,0,1,38,1.2f);
    for(float bass:{1.5f,2.f,2.5f}){auto next=impulse(48000,0,1,38,bass);CHECK(difference(previous,next)>1.e-6);previous=std::move(next);}
    CHECK(toneRms(8000,20000,1)>toneRms(8000,500,1)*3);
    const double cutoffRatio=toneRms(2080,2080,1)/toneRms(2080,20000,1);
    CHECK(cutoffRatio>.69&&cutoffRatio<.73);
    CHECK(toneRms(100,2080,2.5f)>toneRms(100,2080,1.2f)*1.5);
    for(double sr:{8000.,32000.,48000.,96000.,192000.,384000.}){
        tpantheon::PhoenixChamber c;c.prepare(sr);configure(c,0,1,38,1.2f,2080,0);
        for(int i=0;i<64;++i){float l,r;c.processStereoSample(-.25f,.5f,l,r);CHECK(l==-.25f&&r==.5f);}
        configure(c);c.reset();
        for(int i=0;i<int(sr*.4);++i){float l,r;c.processStereoSample(i==0?.1f:0,0,l,r);CHECK(std::isfinite(l)&&std::isfinite(r));}
        c.reset();for(int i=0;i<64;++i){float l,r;c.processStereoSample(0,0,l,r);CHECK(l==0&&r==0);}
    }
    tpantheon::PhoenixChamber live;live.prepare(48000);configure(live);float previousL=0,maxStep=0;
    for(int i=0;i<144000;++i){
        if(i%2400==0)configure(live,(i/2400)%6);
        float l,r;const float x=.08f*std::sin(i*.0287979327f);live.processStereoSample(x,x,l,r);
        CHECK(std::isfinite(l)&&std::isfinite(r));maxStep=std::max(maxStep,std::abs(l-previousL));previousL=l;
    }
    std::printf("Hot type switching max adjacent step %.6f\n",maxStep);CHECK(maxStep<.1f);
    std::printf("PANTHEON FUNCTION: %d checks, %d failures\n",checks,failures);return failures?1:0;
}
