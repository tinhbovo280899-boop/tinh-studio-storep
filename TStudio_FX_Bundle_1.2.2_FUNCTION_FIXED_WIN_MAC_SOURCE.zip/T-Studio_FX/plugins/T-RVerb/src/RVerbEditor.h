#pragma once
#include "RVerbProcessor.h"
#include "../../common/StudioSpecs.h"
namespace trverb
{
class Editor final : public tstudio_ui::Editor
{
public:
    explicit Editor(Processor& p)
        : tstudio_ui::Editor(p,p.apvts,tstudio_ui::rverbSpec(),p.getLicense(),[&p]{float a=juce::Decibels::decibelsToGain(p.meterOut.db.load());return std::array<float,2>{{a,a}};}) {}
};
}
