#pragma once
#include "HwKit.h"
#include "RVerbProcessor.h"

// T-RVerb: 12 reverb types as buttons, TIME and MIX up front, decay screen in the middle.
namespace trverb
{
namespace hw
{
using namespace thw;
inline String hz (float f) { return f >= 1000.0f ? String (f / 1000.0f, f >= 10000.0f ? 1 : 2) + " kHz" : String (juce::roundToInt (f)) + " Hz"; }

class Editor final : public thw::Editor
{
public:
    explicit Editor (Processor& p) : thw::Editor (p, p.apvts, p.getLicense(), { "T-RVerb", "Digital reverb", 1080, 660, "trverb" }), proc (p)
    {
        section (20, 76, 300, 236, "REVERB TYPE");
        grid ("reverbType", 34, 104, { "HALL 1", "HALL 2", "ROOM", "CHAMBER", "CHURCH", "PLATE 1", "PLATE 2", "REVERSE", "GATED", "NONLIN", "ECHOVERB", "RESOVERB" }, 3, 86, 38, 8, 12);
        big ("time", 440, 170, 56, "TIME", { "0.1", "1", "4", "10", "20" }, [this] { return String (value ("time"), 2) + " s"; });
        screen (560, 86, 300, 200, [this] (juce::Graphics& g, juce::Rectangle<float> r)
        {
            const auto a = r.reduced (12).withTrimmedTop (8);
            const float er = juce::Decibels::decibelsToGain (value ("erLevel")), rev = juce::Decibels::decibelsToGain (value ("revLevel"));
            const float pre = juce::jlimit (0.0f, 0.3f, std::abs (value ("preDelay")) / 160.0f * 0.3f);
            juce::Random rnd (3);
            for (int i = 0; i < 14; ++i)
            {
                const float hh = a.getHeight() * er * (0.3f + 0.5f * rnd.nextFloat());
                g.setColour (orange().withAlpha (0.8f)); g.fillRect (a.getX() + 20 + a.getWidth() * pre * 0.5f + (float) i * 5.0f, a.getBottom() - hh, 2.0f, hh);
            }
            const float t = value ("time"), shape = 1.0f + 1.6f * value ("decay") / 100.0f;
            const float span = juce::jmax (1.0f, t * 1.4f);
            curve (g, a.withTrimmedLeft (20 + a.getWidth() * pre * 0.5f), [=] (float u) { const float s = u * span; return rev * juce::jmax (0.0f, std::pow (juce::jmax (0.0f, 1.0f - s / t), shape)); }, true);
            thw::text (g, String (t, 2) + " s", r.getRight() - 14, r.getY() + 20, 12.0f, lcdText(), 8, 1);
            thw::text (g, "RT", r.getRight() - 14, r.getY() + 36, 8.5f, Colour (0xff8f897f), 8, 1, 2.0f);
        });
        big ("wetDry", 960, 170, 56, "MIX", { "0", "25", "50", "75", "100" }, unit ("wetDry", "%"));

        section (20, 326, 520, 264, "SPACE");
        row (76, 386, 96, 20, {
            { "preDelay", "PRE-DELAY", "-160", "160", unit ("preDelay", "ms") },
            { "size", "SIZE", "50", "160", unit ("size", "%") },
            { "diffusion", "DIFFUSION", "0", "100", unit ("diffusion", "%") },
            { "decay", "DECAY", "0", "100", unit ("decay", "%") },
            { "inGain", "INPUT", "-24", "0", unit ("inGain", "dB") } });
        row (124, 500, 96, 20, {
            { "erLevel", "ER LEVEL", "-40", "0", unit ("erLevel", "dB") },
            { "revLevel", "REV LEVEL", "-40", "0", unit ("revLevel", "dB") } });
        section (552, 326, 508, 264, vn ("DAMPING  ·  EQ"));
        auto hzOf = [this] (const char* id) { return [this, id] { return hz (value (id)); }; };
        auto x2 = [this] (const char* id) { return [this, id] { return String (value (id), 2) + "x"; }; };
        row (606, 386, 100, 20, {
            { "lfCut", "LF FREQ", "16", "1.6k", hzOf ("lfCut") },
            { "lfRatio", "LF RATIO", "0.1", "2", x2 ("lfRatio") },
            { "hfCut", "HF FREQ", "1k", "21k", hzOf ("hfCut") },
            { "hfRatio", "HF RATIO", "0.1", "2", x2 ("hfRatio") } });
        row (606, 500, 100, 20, {
            { "eqLowFreq", "LOW FREQ", "16", "1.6k", hzOf ("eqLowFreq") },
            { "eqLowGain", "LOW GAIN", "-24", "+12", unit ("eqLowGain", "dB") },
            { "eqHighFreq", "HIGH FREQ", "1k", "21k", hzOf ("eqHighFreq") },
            { "eqHighGain", "HIGH GAIN", "-24", "+12", unit ("eqHighGain", "dB") } });
        infoItem ("OUT", [this] { return String (juce::jmax (-60.0f, proc.meterOut.db.load()), 1) + " dB"; });
        finish();
    }
private:
    Processor& proc;
};
}
}
