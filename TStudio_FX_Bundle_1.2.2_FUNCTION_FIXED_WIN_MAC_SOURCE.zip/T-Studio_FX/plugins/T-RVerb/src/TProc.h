#pragma once
// T Studio shared processor base (no GUI code): parameters, state, bypass, meters, analyser feed.
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>
#include <atomic>
#include <array>
#include <vector>

namespace tkit
{
    /** Lock-free hand-off of the mono input to the editor's spectrum display. */
    class AnalyserFeed
    {
    public:
        AnalyserFeed() : fifo (1 << 15), data ((size_t) (1 << 15), 0.0f) {}
        void push (const float* x, int n) noexcept          // audio thread
        {
            const auto scope = fifo.write (n);
            if (scope.blockSize1 > 0) std::copy (x, x + scope.blockSize1, data.begin() + scope.startIndex1);
            if (scope.blockSize2 > 0) std::copy (x + scope.blockSize1, x + scope.blockSize1 + scope.blockSize2, data.begin() + scope.startIndex2);
        }
        int pull (float* dest, int maxN)                     // message thread
        {
            const auto scope = fifo.read (std::min (maxN, fifo.getNumReady()));
            if (scope.blockSize1 > 0) std::copy (data.begin() + scope.startIndex1, data.begin() + scope.startIndex1 + scope.blockSize1, dest);
            if (scope.blockSize2 > 0) std::copy (data.begin() + scope.startIndex2, data.begin() + scope.startIndex2 + scope.blockSize2, dest + scope.blockSize1);
            return scope.blockSize1 + scope.blockSize2;
        }
    private:
        juce::AbstractFifo fifo; std::vector<float> data;
    };

    /** RBJ biquad (transposed direct form II, double). Coefficient setters never allocate. */
    struct Biquad
    {
        double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
        void reset() { z1 = z2 = 0; }
        void identity() { b0 = 1; b1 = b2 = a1 = a2 = 0; }
        void set (double B0, double B1, double B2, double A0, double A1, double A2)
        { b0 = B0 / A0; b1 = B1 / A0; b2 = B2 / A0; a1 = A1 / A0; a2 = A2 / A0; }
        void lowpass (double fs, double f, double q = 0.70710678)
        {
            f = std::min (f, 0.49 * fs); const double w = juce::MathConstants<double>::twoPi * f / fs, al = std::sin (w) / (2 * q), c = std::cos (w);
            set ((1 - c) / 2, 1 - c, (1 - c) / 2, 1 + al, -2 * c, 1 - al);
        }
        void highpass (double fs, double f, double q = 0.70710678)
        {
            f = std::min (f, 0.49 * fs); const double w = juce::MathConstants<double>::twoPi * f / fs, al = std::sin (w) / (2 * q), c = std::cos (w);
            set ((1 + c) / 2, -(1 + c), (1 + c) / 2, 1 + al, -2 * c, 1 - al);
        }
        void bandpass (double fs, double f, double q)
        {
            f = std::min (f, 0.49 * fs); const double w = juce::MathConstants<double>::twoPi * f / fs, al = std::sin (w) / (2 * q), c = std::cos (w);
            set (al, 0, -al, 1 + al, -2 * c, 1 - al);
        }
        inline float process (float x) noexcept
        {
            const double y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return (float) y;
        }
    };

    /** Envelope follower in dB with separate attack / release (ms). */
    struct Envelope
    {
        float env = 0.0f, att = 0.0f, rel = 0.0f;
        void setup (double fs, double attackMs, double releaseMs)
        { att = (float) std::exp (-1.0 / (fs * attackMs * 0.001)); rel = (float) std::exp (-1.0 / (fs * releaseMs * 0.001)); }
        inline float process (float x) noexcept
        { const float a = std::abs (x); env = a > env ? att * env + (1 - att) * a : rel * env + (1 - rel) * a; return env; }
        float db() const { return env > 1.0e-6f ? 20.0f * std::log10 (env) : -120.0f; }
    };

    /** Smoothed peak meter value in dB, written by the audio thread. */
    struct PeakMeter
    {
        std::atomic<float> db { -90.0f };
        void update (float peakLin, int numSamples, double sr) noexcept
        {
            const float in = peakLin > 1.0e-5f ? 20.0f * std::log10 (peakLin) : -90.0f;
            const float fall = (float) (numSamples / sr) * 24.0f;   // 24 dB/s release
            const float cur = db.load (std::memory_order_relaxed);
            db.store (in > cur ? in : std::max (in, cur - fall), std::memory_order_relaxed);
        }
    };

    /** Base processor: APVTS state, host bypass, meters and analyser feed for the editor. */
    class BaseProcessor : public juce::AudioProcessor
    {
    public:
        BaseProcessor (juce::AudioProcessorValueTreeState::ParameterLayout layout, const juce::String& name)
            : juce::AudioProcessor (BusesProperties().withInput ("Input", juce::AudioChannelSet::stereo(), true)
                                                     .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
              apvts (*this, nullptr, "STATE", std::move (layout)), pluginName (name) {}

        void releaseResources() override {}
        bool isBusesLayoutSupported (const BusesLayout& l) const override
        {
            const auto& o = l.getMainOutputChannelSet();
            return (o == juce::AudioChannelSet::mono() || o == juce::AudioChannelSet::stereo()) && l.getMainInputChannelSet() == o;
        }
        /** Call from prepareToPlay(). maxLatency: largest latency the plugin may report. */
        void prepareBase (double sr, int maxBlock, int maxLatency = 0)
        {
            const int chunk = std::max (512, maxBlock);
            dry.setSize (2, chunk, false, true, true);
            dryDelay.setSize (2, std::max (1, maxLatency + 1), false, true, true);
            dryDelayPos = 0;
            bypassMix.reset (sr, 0.02);
            bypassMix.setCurrentAndTargetValue (isBypassed() ? 1.0f : 0.0f);
            sampleRateHz = sr;
        }
        /** Latency the dry path is delayed by (must equal getLatencySamples()). */
        void setDryLatency (int samples) { dryLatency = juce::jlimit (0, dryDelay.getNumSamples() - 1, samples); }

        /** Runs process(chunk) on <= chunk-sized pieces and crossfades to the latency-aligned dry
            signal when the host / plugin bypass is on. process() always runs, so states stay warm. */
        template <typename Fn>
        void runWithBypass (juce::AudioBuffer<float>& buffer, Fn&& process)
        {
            const int numCh = std::min (buffer.getNumChannels(), 2);
            bypassMix.setTargetValue ((isBypassed() || licenseLocked) ? 1.0f : 0.0f);
            for (int start = 0; start < buffer.getNumSamples();)
            {
                const int n = std::min (dry.getNumSamples(), buffer.getNumSamples() - start);
                // dry copy, delayed by the plugin latency
                for (int c = 0; c < numCh; ++c)
                {
                    const float* in = buffer.getReadPointer (c, start);
                    float* d = dry.getWritePointer (c);
                    float* line = dryDelay.getWritePointer (c);
                    const int L = dryDelay.getNumSamples();
                    int pos = dryDelayPos;
                    for (int i = 0; i < n; ++i)
                    {
                        line[pos] = in[i];
                        int rd = pos - dryLatency; if (rd < 0) rd += L;
                        d[i] = line[rd];
                        if (++pos >= L) pos = 0;
                    }
                }
                dryDelayPos = (dryDelayPos + n) % dryDelay.getNumSamples();
                juce::AudioBuffer<float> view (buffer.getArrayOfWritePointers(), buffer.getNumChannels(), start, n);
                process (view);
                if (bypassMix.isSmoothing() || bypassMix.getTargetValue() > 0.5f)
                {
                    for (int i = 0; i < n; ++i)
                    {
                        const float b = bypassMix.getNextValue();
                        for (int c = 0; c < numCh; ++c)
                            view.setSample (c, i, view.getSample (c, i) * (1.0f - b) + dry.getSample (c, i) * b);
                    }
                }
                start += n;
            }
        }

        /** Not activated / trial ended: crossfade to the latency-aligned dry signal. */
        void setLicenseLocked (bool locked) noexcept { licenseLocked = locked; }

        juce::AudioProcessorParameter* getBypassParameter() const override { return apvts.getParameter ("bypass"); }
        bool isBypassed() const { return apvts.getRawParameterValue ("bypass")->load() > 0.5f; }
        float param (const char* id) const { return apvts.getRawParameterValue (id)->load(); }

        /** Feed the analyser with the mono sum of the first channels. */
        void feedAnalyser (const juce::AudioBuffer<float>& b)
        {
            const int n = b.getNumSamples(), ch = b.getNumChannels();
            if ((int) monoScratch.size() < n) return;        // sized in the constructor; never allocate here
            for (int i = 0; i < n; ++i)
            {
                float s = 0.0f;
                for (int c = 0; c < ch; ++c) s += b.getSample (c, i);
                monoScratch[(size_t) i] = ch > 0 ? s / (float) ch : 0.0f;
            }
            analyser.push (monoScratch.data(), n);
        }
        bool hasEditor() const override { return true; }
        const juce::String getName() const override { return pluginName; }
        bool acceptsMidi() const override { return false; }
        bool producesMidi() const override { return false; }
        double getTailLengthSeconds() const override { return 0.0; }
        int getNumPrograms() override { return 1; }
        int getCurrentProgram() override { return 0; }
        void setCurrentProgram (int) override {}
        const juce::String getProgramName (int) override { return {}; }
        void changeProgramName (int, const juce::String&) override {}
        void getStateInformation (juce::MemoryBlock& d) override
        { if (auto x = apvts.copyState().createXml()) copyXmlToBinary (*x, d); }
        void setStateInformation (const void* d, int n) override
        { if (auto x = getXmlFromBinary (d, n)) apvts.replaceState (juce::ValueTree::fromXml (*x)); /* v1.2.1: snap on/off params to exactly 0/1 (JUCE skips them in replaceState when already matching) */ for (auto* tsP : getParameters()) if (auto* tsB = dynamic_cast<juce::AudioParameterBool*> (tsP)) { const float tsV = tsB->get() ? 1.0f : 0.0f; if (tsP->getValue() != tsV) tsP->setValueNotifyingHost (tsV); } }

        juce::AudioProcessorValueTreeState apvts;
        AnalyserFeed analyser;                         // input (or output) samples for the display
        std::array<std::atomic<float>, 256> curve2 {};  // extra display curve in dB (noise profile)
        PeakMeter meterIn, meterOut;
        std::atomic<float> meterGR { 0.0f };           // gain reduction in dB (positive)
        std::atomic<double> hostBpm { 120.0 };
    protected:
        std::vector<float> monoScratch = std::vector<float> (1 << 15, 0.0f);
        double sampleRateHz = 48000.0;
        /** Reads tempo from the host play head (audio thread). */
        void readHostTempo()
        {
            if (auto* ph = getPlayHead())
                if (auto pos = ph->getPosition())
                    if (auto bpm = pos->getBpm()) if (*bpm > 20.0 && *bpm < 400.0) hostBpm.store (*bpm);
        }
    private:
        juce::AudioBuffer<float> dry, dryDelay;
        int dryDelayPos = 0, dryLatency = 0;
        bool licenseLocked = false;
        juce::SmoothedValue<float> bypassMix;
    private:
        juce::String pluginName;
    };

    using P = juce::AudioProcessorValueTreeState::ParameterLayout;
    inline auto fl (const juce::String& id, const juce::String& n, float lo, float hi, float def, float skewCentre = 0.0f, const juce::String& unit = {})
    {
        juce::NormalisableRange<float> r (lo, hi);
        if (skewCentre > 0.0f) r.setSkewForCentre (skewCentre);
        return std::make_unique<juce::AudioParameterFloat> (juce::ParameterID { id, 1 }, n, r, def, juce::AudioParameterFloatAttributes().withLabel (unit));
    }
    inline auto ch (const juce::String& id, const juce::String& n, juce::StringArray c, int def)
    { return std::make_unique<juce::AudioParameterChoice> (juce::ParameterID { id, 1 }, n, c, def); }
    inline auto bo (const juce::String& id, const juce::String& n, bool def)
    { return std::make_unique<juce::AudioParameterBool> (juce::ParameterID { id, 1 }, n, def); }

}
