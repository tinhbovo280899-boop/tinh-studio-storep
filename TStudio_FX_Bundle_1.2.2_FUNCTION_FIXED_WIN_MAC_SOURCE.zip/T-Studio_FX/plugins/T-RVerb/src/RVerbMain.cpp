#include "RVerbEditor.h"
#include "HwEditor.h"
juce::AudioProcessorEditor* trverb::Processor::createEditor() { return new hw::Editor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new trverb::Processor(); }
