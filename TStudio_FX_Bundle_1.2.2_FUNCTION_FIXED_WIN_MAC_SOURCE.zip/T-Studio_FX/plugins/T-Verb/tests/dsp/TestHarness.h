#pragma once
// Regression checks for the DSP defects identified in the 1.0.0 review.
#include "TVerbParameters.h"
#include <iostream>
#include <fstream>
#include <iomanip>
#include <random>
#include <chrono>
using namespace tverbdsp;
static int checks=0, failures=0;
void check(bool ok, const std::string& name, double actual=0, double expected=0) {
    ++checks; if(!ok) ++failures;
    std::cout << (ok?"PASS ":"FAIL ") << name << " actual=" << actual << " expected=" << expected << std::endl;
}
void components() {
    for (int d : {0,1,71,96000}) {
        CDelay<double> delay; delay.set_DelaySamples(d);
        std::vector<double> x(d+100,0); x[0]=1; delay.DoDelay(x.data(),x.size());
        double err=0; for(size_t i=0;i<x.size();++i)err=std::max(err,std::abs(x[i]-(i==size_t(d)?1.:0.)));
        check(err==0,"predelay_samples_"+std::to_string(d),err);
    }
    double scaleErr=0;
    for(int i=0;i<=10000;++i){float n=i/10000.f;
        scaleErr=std::max(scaleErr,double(std::abs(TVScaling::RatioToNorm(TVScaling::RatioFromNorm(n))-n)));
    }
    check(scaleErr<0.0002,"damping_ratio_roundtrip",scaleErr);
    const int D=100, ringSize=4096;
    std::vector<double> ring(ringSize,0),out(2000,0);ring[ringSize-1]=1;
    CComb<double> comb;comb.bindSharedInputBuffer(ring.data(),ringSize,ring.data()+ringSize-1);
    comb.set_Delay(D);const double perSample=std::pow(.5,1./D);
    comb.set_3BandDamping(.7,-.2,perSample,perSample,perSample);
    comb.Do3BandComb(out.data(),out.size());
    check(std::abs(out[D]+.5)<1e-10,"comb_equal_band_first_echo",out[D],-.5);
    check(std::abs(out[D+1])<1e-10,"comb_equal_band_no_filter_coloration",out[D+1],0);
    for(double gain:{.5,.8,.95}){
        std::fill(out.begin(),out.end(),0);CComb<double> c;c.bindSharedInputBuffer(ring.data(),ringSize,ring.data()+ringSize-1);c.set_Delay(D);
        double g=std::pow(gain,1./D);c.set_3BandDamping(.89,.53,g,g,g);c.Do3BandComb(out.data(),out.size());
        check(std::abs(out[D]+gain)<1e-9,"comb_equal_band_other_crossovers_"+std::to_string(gain),out[D],-gain);
    }
    CBiQuad<double> a,b;a.set_TP2(1000,1.41421356237);b.set_TP2(1000,1.41421356237);
    std::vector<double> va(100,1),vb=va;a.DoBiQuad(va.data(),100);
    for(int i=0;i<100;i+=10)b.DoBiQuad(vb.data()+i,10);
    double e=0;for(int i=0;i<100;++i)e=std::max(e,std::abs(va[i]-vb[i]));
    check(e<1e-12,"biquad_crossfade_block_partition",e);
}
std::vector<float> convertRoundtrip(int sr,int dsp,int block){
    CSampleRateConvert<double> in,out;in.set_SampleRates(sr,dsp);out.set_SampleRates(sr,dsp);
    std::vector<float> result(sr),x(block);std::vector<double> tmp(size_t(block)*dsp/sr+64);
    for(int pos=0;pos<sr;pos+=block){int n=std::min(block,sr-pos);
        for(int i=0;i<n;++i)x[i]=float(.25*std::sin(2*M_PI*997*(pos+i)/sr));
        long k=in.DoConvertInput(x.data(),tmp.data(),n);out.DoConvertOutput(tmp.data(),result.data()+pos,n,k,true);
    }return result;
}
void resampling(){for(int sr:{44100,48000,96000})for(int dsp:{22050,44100,96000}){
    auto ref=convertRoundtrip(sr,dsp,512);
    for(int block:{1,7,64,511}){auto v=convertRoundtrip(sr,dsp,block);double e=0;for(int i=1024;i<sr;++i)e=std::max(e,double(std::abs(v[i]-ref[i])));
        check(e<1e-5,"resampler_partition_sr"+std::to_string(sr)+"_dsp"+std::to_string(dsp)+"_block"+std::to_string(block),e);
    }
}}
struct Metrics {double energy=0,peak=0;int nonfinite=0,first=-1;};
Metrics process(TVerbPluginWrapper& p,int sr,int block,double seconds,std::string save="",bool noise=false){
    int count=int(sr*seconds);std::vector<float> l(count,0),r(count,0);l[64]=r[64]=1;
    if(noise){std::mt19937 gen(123);std::uniform_real_distribution<float> dist(-.1,.1);for(int i=0;i<count;++i){l[i]=dist(gen);r[i]=dist(gen);}}
    for(int i=0;i<count;i+=block){int n=std::min(block,count-i);float* io[2]={l.data()+i,r.data()+i};p.processReplacing(io,io,n);}
    Metrics m;for(int i=0;i<count;++i){
        if(!std::isfinite(l[i])||!std::isfinite(r[i]))++m.nonfinite;
        else {m.energy+=double(l[i])*l[i]+double(r[i])*r[i];m.peak=std::max({m.peak,double(std::abs(l[i])),double(std::abs(r[i]))});}
        if(m.first<0&&(std::abs(l[i])>1e-5||std::abs(r[i])>1e-5))m.first=i;
    }
    if(!save.empty()){std::ofstream f(save,std::ios::binary);f.write((char*)l.data(),l.size()*sizeof(float));}
    return m;
}
void wet(TVerbPluginWrapper& p){
    p.setParameter(kParam_DryLevelEnable,0);p.setParameter(kParam_WetLevel, TVScaling::SquareToNorm(1,TVScaling::kMinGainLinear,TVScaling::kMaxGainLinear));
    p.setParameter(kParam_LoCut,0);p.setParameter(kParam_HiCut,1);p.setParameter(kParam_Modulation,0);p.setParameter(kParam_EchoInt,0);
}
void engine(){
    std::ofstream metrics("engine_metrics.csv");metrics<<"sr,quality,type,nonfinite,peak,energy,first\n";
    for(int sr:{44100,48000,96000})for(int q:{0,1,2})for(int t=0;t<13;++t){
        TVerbPluginWrapper p(sr,512);wet(p);p.setParameter(kParam_RevType,t/12.f);p.setParameter(kParam_Quality,q/2.f);p.suspend();
        auto m=process(p,sr,512,1.0);metrics<<sr<<','<<q<<','<<t<<','<<m.nonfinite<<','<<m.peak<<','<<m.energy<<','<<m.first<<'\n';
        check(m.nonfinite==0&&m.energy>1e-10&&m.peak<10,"impulse_sr"+std::to_string(sr)+"_q"+std::to_string(q)+"_type"+std::to_string(t),m.peak);
    }
    for(float decay:{.2f,1.f,2.f,5.f,15.f,45.2f}){
        TVerbPluginWrapper p(44100,512);wet(p);p.setParameter(kParam_Decay,TVScaling::PowToNorm(decay,.2,45.2));
        for(int id:{kParam_LoRatio,kParam_MidRatio,kParam_HiRatio}) {
            p.setParameter(id,TVScaling::RatioToNorm(1));
        }
        p.suspend();
        auto m=process(p,44100,512,10,"decay_"+std::to_string(decay)+".f32");
        check(m.nonfinite==0&&m.peak<10,"tail_stability_decay_"+std::to_string(decay),m.peak);
    }
    for(int sr:{44100,48000,96000})for(int block:{1,7,64,512}){
        TVerbPluginWrapper p(sr,block);p.setParameter(kParam_WetLevelEnable,0);p.setParameter(kParam_DryLevelEnable,1);
        p.setParameter(kParam_DryLevel,TVScaling::SquareToNorm(1,TVScaling::kMinGainLinear,TVScaling::kMaxGainLinear));
        std::vector<float> l(block,.25f),r(block,-.125f);float* io[2]={l.data(),r.data()};p.processReplacing(io,io,block);
        double e=0;for(int i=0;i<block;++i)e=std::max({e,std::abs(double(l[i]-.25f)),std::abs(double(r[i]+.125f))});
        check(e<1e-6,"dry_unity_sr"+std::to_string(sr)+"_block"+std::to_string(block),e);
    }
    TVerbPluginWrapper p;wet(p);p.setParameter(kParam_BitDepth,0);
    check(p.getReverbEngine()->get_bitDepth()==kBitDepth_64BitDouble,"bitdepth_forced_64_even_when_32_selected");
}
