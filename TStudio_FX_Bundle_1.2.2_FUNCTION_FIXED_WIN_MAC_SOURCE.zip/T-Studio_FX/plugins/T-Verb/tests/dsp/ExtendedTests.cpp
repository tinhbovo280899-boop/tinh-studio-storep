#include "TestHarness.h"
#include "FactoryPresets.h"
using tverb::FactoryPreset;
using tverb::getFactoryPresets;
void applyPreset(TVerbPluginWrapper& p,const FactoryPreset& pr) {
    p.setParameter(kParam_RevType,pr.type/12.f);
    p.setParameter(kParam_Decay,TVScaling::PowToNorm(pr.decay,.2,45.2));
    p.setParameter(kParam_Predelay,TVScaling::SquareToNorm(pr.predelay,0,1000));
    p.setParameter(kParam_Attack,pr.attack/100);p.setParameter(kParam_Spread,pr.spread/100);
    p.setParameter(kParam_RoomSize,TVScaling::PowToNorm(pr.size,2,62));
    p.setParameter(kParam_RoomWidth,TVScaling::LinearToNorm(pr.width,-180,180));
    p.setParameter(kParam_Diffusion,pr.diffusion/100);p.setParameter(kParam_Density,pr.density/100);
    p.setParameter(kParam_DryLevel,TVScaling::SquareToNorm(TVScaling::DbToLinearGain(pr.dryDb),TVScaling::kMinGainLinear,TVScaling::kMaxGainLinear));
    p.setParameter(kParam_WetLevel,TVScaling::SquareToNorm(TVScaling::DbToLinearGain(pr.wetDb),TVScaling::kMinGainLinear,TVScaling::kMaxGainLinear));
    p.setParameter(kParam_DryLevelEnable,pr.dryOn?1:0);p.setParameter(kParam_WetLevelEnable,pr.wetOn?1:0);
    p.setParameter(kParam_LoCut,TVScaling::SquareToNorm(pr.loCut,20,10000));
    p.setParameter(kParam_HiCut,TVScaling::SquareToNorm(pr.hiCut,200,20000));
    p.setParameter(kParam_CrossLoMid,TVScaling::SquareToNorm(pr.crossLo,20,5500));
    p.setParameter(kParam_CrossMidHi,TVScaling::SquareToNorm(pr.crossHi,200,16000));
    p.setParameter(kParam_LoRatio,TVScaling::RatioToNorm(pr.loRatio));
    p.setParameter(kParam_MidRatio,TVScaling::RatioToNorm(pr.midRatio));
    p.setParameter(kParam_HiRatio,TVScaling::RatioToNorm(pr.hiRatio));
    p.setParameter(kParam_EchoInt,pr.echoInt/100);p.setParameter(kParam_EchoSize,TVScaling::LinearToNorm(pr.echoSize,50,750));
    p.setParameter(kParam_Modulation,pr.mod/100);p.setParameter(kParam_Quality,pr.quality/2.f);
}
void presetTests() {
    for(int sr:{44100,48000,96000}) {
        int i=0;
        for(const auto& pr:getFactoryPresets()) {
            TVerbPluginWrapper p(sr,512);applyPreset(p,pr);p.suspend();
            const auto m=process(p,sr,512,3);
            check(m.nonfinite==0&&m.energy>1e-12&&m.peak<10,"preset_sr"+std::to_string(sr)+"_"+std::to_string(i),m.peak);
            ++i;
        }
    }
}
void tailTests() {
    for(float decay:{2.f,15.f,45.2f}) {
        TVerbPluginWrapper p(44100,512);wet(p);
        p.setParameter(kParam_Decay,TVScaling::PowToNorm(decay,.2,45.2));
        for(int id:{kParam_LoRatio,kParam_MidRatio,kParam_HiRatio})p.setParameter(id,TVScaling::RatioToNorm(1));
        p.suspend();auto m=process(p,44100,512,30,"long_decay_"+std::to_string(decay)+".f32");
        check(m.nonfinite==0&&m.peak<10,"long_tail_"+std::to_string(decay),m.peak);
        std::ifstream f("long_decay_"+std::to_string(decay)+".f32",std::ios::binary);
        std::vector<float> x(30*44100);f.read((char*)x.data(),x.size()*sizeof(float));
        double middle=0,last=0;
        for(int i=0;i<44100;++i){middle+=double(x[10*44100+i])*x[10*44100+i];last+=double(x[29*44100+i])*x[29*44100+i];}
        check(last<middle,"tail_energy_decreases_after_ten_seconds_"+std::to_string(decay),last,middle);
    }
    for(int quality:{0,1,2}) {
        TVerbPluginWrapper p(48000,512);wet(p);p.setParameter(kParam_Quality,quality/2.f);p.suspend();
        auto m=process(p,48000,512,5,"quality_"+std::to_string(quality)+".f32");
        check(m.nonfinite==0&&m.peak<10,"five_second_quality_"+std::to_string(quality),m.peak);
        std::cout<<"QUALITY "<<quality<<" nonfinite="<<m.nonfinite<<" peak="<<m.peak<<std::endl;
    }
}
void extremaTests() {
    for(int id=2;id<kParam_BitDepth;++id)for(float value:{0.f,1.f}) {
        TVerbPluginWrapper p(48000,512);wet(p);p.setParameter(id,value);p.suspend();auto m=process(p,48000,512,2);
        check(m.nonfinite==0&&m.peak<10,"parameter_"+std::to_string(id)+"_end_"+std::to_string(value),m.peak);
    }
    TVerbPluginWrapper p(48000,512);wet(p);std::vector<float> l(64,.01f),r(64,.02f);float* io[2]={l.data(),r.data()};
    std::mt19937 gen(123);std::uniform_real_distribution<float> dist(0,1);bool finite=true;
    for(int j=0;j<200;++j){p.setParameter(2+gen()%20,dist(gen));p.processReplacing(io,io,64);for(int i=0;i<64;++i)finite&=std::isfinite(l[i])&&std::isfinite(r[i]);}
    check(finite,"rapid_parameter_switches_finite");
}
void discontinuityTests(){
    for(int sr:{44100,48000,96000})for(int q:{0,1,2}) {
        TVerbPluginWrapper p(sr,16);p.setParameter(kParam_Quality,q/2.f);
        p.setParameter(kParam_WetLevelEnable,0);p.setParameter(kParam_DryLevelEnable,1);
        p.setParameter(kParam_DryLevel,TVScaling::SquareToNorm(1,TVScaling::kMinGainLinear,TVScaling::kMaxGainLinear));
        double e=0;int dropped=0;
        for(int block=0;block<100;++block){float l=.25,r=-.125;float* io[2]={&l,&r};p.processReplacing(io,io,1);e=std::max(e,std::abs(double(l)-.25));if(l==0)++dropped;}
        check(e<1e-6,"dry_stream_sr"+std::to_string(sr)+"_q"+std::to_string(q),e);
        if(dropped)std::cout<<"DROPPED_DRY "<<sr<<" quality="<<q<<" samples="<<dropped<<"/100"<<std::endl;
    }
    TVerbPluginWrapper p(44100,512);p.setParameter(kParam_CrossLoMid,TVScaling::SquareToNorm(5500,20,5500));
    double adjusted=TVScaling::SquareFromNorm(p.getParameter(kParam_CrossMidHi),200,16000);
    std::cout<<"CROSSOVER host-original-hi=4000 engine-adjusted-hi="<<adjusted<<std::endl;
}
void streamingRegressionTests() {
    for(int sr:{44100,48000,96000})for(int quality:{0,1,2}) {
        auto render=[&](bool variable) {
            TVerbPluginWrapper p(sr,512);wet(p);p.setParameter(kParam_Quality,quality/2.f);p.suspend();
            std::vector<float> l(sr/2),r(sr/2);
            for(size_t i=0;i<l.size();++i) {
                l[i]=i<size_t(sr/4)?float(.05*std::sin(2*M_PI*997*i/sr)):0;
                r[i]=i<size_t(sr/4)?float(.04*std::sin(2*M_PI*613*i/sr)):0;
            }
            const int sizes[]={1,7,64,511,23,2048};int step=0;
            for(size_t pos=0;pos<l.size();) {
                int n=std::min(int(l.size()-pos),variable?sizes[step++%6]:512);
                float* io[2]={l.data()+pos,r.data()+pos};p.processReplacing(io,io,n);pos+=n;
            }
            l.insert(l.end(),r.begin(),r.end());return l;
        };
        auto reference=render(false),variable=render(true);double error=0;
        for(size_t i=0;i<reference.size();++i)error=std::max(error,double(std::abs(reference[i]-variable[i])));
        check(error<1e-5,"full_engine_variable_blocks_sr"+std::to_string(sr)+"_q"+std::to_string(quality),error);
    }
    TVerbPluginWrapper p(48000,512);
    p.setParameter(kParam_HiCut,TVScaling::SquareToNorm(16000,200,20000));
    p.setParameter(kParam_Quality,0);float lo=0,hi=0;p.getReverbEngine()->get_PostEQFreq(&lo,&hi);
    check(hi<11000,"low_quality_clamps_high_cut",hi);
    p.setParameter(kParam_Quality,.5f);p.getReverbEngine()->get_PostEQFreq(&lo,&hi);
    check(std::abs(hi-16000)<1,"normal_quality_restores_requested_high_cut",hi,16000);
}
int main(int argc,char**argv){std::cout<<std::setprecision(10);std::string mode=argc>1?argv[1]:"all";
    if(mode=="all"||mode=="presets")presetTests();
    if(mode=="all"||mode=="tails")tailTests();
    if(mode=="all"||mode=="extrema")extremaTests();
    if(mode=="all"||mode=="stream")discontinuityTests();
    if(mode=="all"||mode=="streaming-regression")streamingRegressionTests();
    std::cout<<"TOTAL "<<checks<<" FAILED "<<failures<<std::endl;return failures?1:0;
}
