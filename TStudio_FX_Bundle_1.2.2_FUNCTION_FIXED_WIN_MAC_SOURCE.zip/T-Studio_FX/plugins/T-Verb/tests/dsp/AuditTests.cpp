#include "TestHarness.h"
int main(int argc,char**argv){std::cout<<std::setprecision(10);std::string mode=argc>1?argv[1]:"all";
    if(mode=="all"||mode=="components")components();
    if(mode=="all"||mode=="resampling")resampling();
    if(mode=="all"||mode=="engine")engine();
    std::cout<<"TOTAL "<<checks<<" FAILED "<<failures<<std::endl;return failures?1:0;
}
