// Window-free checks for unit labels and interactive plot conversions.
#include "OrbitValues.h"
#include <cstdio>
#include <cmath>

int main()
{
    int failures = 0;
    auto check = [&] (bool ok, const char* what)
    {
        if (!ok) { ++failures; std::printf ("FAIL: %s\n",what); }
    };
    check (tverb::orbit::display("decay",3.506f) == "3.506 s", "decay is seconds with three decimals");
    check (tverb::orbit::display("predelay",70) == "70 ms", "predelay is milliseconds");
    check (tverb::orbit::display("echosize",400) == "400 ms", "echo size is milliseconds");
    check (tverb::orbit::display("size",40) == "40.0 mtr", "room size is metres");
    check (tverb::orbit::display("locut",20) == "off", "low cut disabled endpoint");
    check (tverb::orbit::display("hicut",20000) == "off", "high cut disabled endpoint");
    check (tverb::orbit::display("hicut",11500) == "11.50 kHz", "cutoff in kHz");
    check (tverb::orbit::display("dry",-96.0f) == "-oo dB", "dry default muted at -oo dB");
    check (tverb::orbit::display("wet",0.84f) == "0.84 dB", "independent wet level in dB");
    check (tverb::orbit::display("hiratio",0.65f) == "0.65 x", "damping is a time multiplier");
    for (float f : {20.f,90.f,700.f,4200.f,11500.f,20000.f})
        check (std::abs (tverb::orbit::normToFreq(tverb::orbit::freqToNorm(f))/f-1) < 0.0001f, "frequency drag round trip");
    for (float ratio : {0.05f,0.6f,1.f,2.f,5.f})
        check (std::abs (tverb::orbit::normToRatio(tverb::orbit::ratioToNorm(ratio))/ratio-1) < 0.0001f, "damping drag round trip");
    check (tverb::orbit::normToFreq(-1) == 20, "frequency drag clamps below range");
    check (std::abs(tverb::orbit::normToFreq(2)-20000) < 1, "frequency drag clamps above range");
    std::printf ("%s\n",failures == 0 ? "ALL UI VALUE CHECKS PASSED" : "UI VALUE CHECKS FAILED");
    return failures == 0 ? 0 : 1;
}
