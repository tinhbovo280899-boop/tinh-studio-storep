#pragma once
#include "HwKit.h"
#include "VerbProcessor.h"

// T-Verb: the familiar layout (sliders on the left, time + damping displays on the right) in black / orange.
namespace tverb
{
namespace hw
{
using namespace thw;
inline String hz (float f) { return f >= 1000.0f ? String (f / 1000.0f, f >= 10000.0f ? 1 : 2) + " kHz" : String (juce::roundToInt (f)) + " Hz"; }

class Editor final : public thw::Editor
{
public:
    explicit Editor (Processor& p) : thw::Editor (p, p.apvts, p.getLicense(), { "T-Verb", "Spatial reverb", 1040, 806, "tverb" }), proc (p)
    {
        auto pct = [this] (const char* id) { return [this, id] { return String (juce::roundToInt (value (id))) + " %"; }; };
        auto ratio = [this] (const char* id) { return [this, id] { return String (value (id), 2) + "x"; }; };
        auto level = [this] (const char* id) { return [this, id] { const float v = value (id); return v <= -95.9f ? vn ("-∞ dB") : String (v, 2) + " dB"; }; };

        section (18, 76, 330, 236, "TIME DESIGN");
        hslider ("decay", 40, 134, 200, "DECAY", [this] { return String (value ("decay"), 3) + " s"; });
        hslider ("predelay", 40, 186, 200, "PREDELAY", [this] { return String (juce::roundToInt (value ("predelay"))) + " ms"; });
        hslider ("attack", 40, 238, 200, "ATTACK", pct ("attack"));
        hslider ("spread", 40, 290, 200, "SPREAD", pct ("spread"));
        select ("type", 256, 130, 82, "TYPE");

        section (18, 326, 330, 236, "ROOM DESIGN");
        hslider ("size", 40, 384, 270, "ROOM SIZE", [this] { return String (value ("size"), 1) + " m"; });
        hslider ("width", 40, 436, 270, "ROOM WIDTH", [this] { return String (juce::roundToInt (value ("width"))) + vn ("°"); });
        hslider ("diffusion", 40, 488, 270, "DIFFUSION", pct ("diffusion"));
        hslider ("density", 40, 540, 270, "DENSITY", pct ("density"));

        section (362, 76, 660, 236, "TIME DISPLAY");
        screen (380, 100, 624, 196, [this] (juce::Graphics& g, juce::Rectangle<float> r) { paintTime (g, r); });

        section (362, 326, 660, 236, vn ("FREQUENCY DISPLAY  ·  DAMPING"));
        auto& fs = screen (380, 350, 624, 196, [this] (juce::Graphics& g, juce::Rectangle<float> r) { paintDamping (g, r); });
        fs.onDown = [this, &fs] (const juce::MouseEvent& e) { pickDamping (fs.getLocalBounds().toFloat(), e.position); };
        fs.onDrag = [this, &fs] (const juce::MouseEvent& e) { dragDamping (fs.getLocalBounds().toFloat(), e.position, e.mods.isShiftDown()); };
        fs.onUp = [this] (const juce::MouseEvent&) { if (dragId.isNotEmpty()) param (dragId)->endChangeGesture(); dragId = {}; };

        const float sy = 576;
        section (18, sy, 170, 172, "LEVEL");
        small ("dry", 66, sy + 66, 24, "DRY", vn ("-∞"), "+6", level ("dry"));
        small ("wet", 140, sy + 66, 24, "WET", vn ("-∞"), "+6", level ("wet"));
        section (200, sy, 170, 172, "EQ");
        small ("locut", 248, sy + 66, 24, "LO CUT", "off", "10k", [this] { const float f = value ("locut"); return f <= 20.5f ? String ("off") : hz (f); });
        small ("hicut", 322, sy + 66, 24, "HI CUT", "200", "off", [this] { const float f = value ("hicut"); return f >= 19990.0f ? String ("off") : hz (f); });
        section (382, sy, 300, 172, "DAMPING");
        caption (vn ("LO ‹ › MID"), 464, sy + 32, 8.5f, 1.2f);
        caption (vn ("MID ‹ › HI"), 602, sy + 32, 8.5f, 1.2f);
        hslider ("crosslo", 402, sy + 52, 124, {}, [this] { return hz (value ("crosslo")); }, {}, 62);
        hslider ("crosshi", 540, sy + 52, 124, {}, [this] { return hz (value ("crosshi")); }, {}, 62);
        small ("loratio", 440, sy + 98, 19, "LO RATIO", {}, {}, ratio ("loratio"), {}, 60);
        small ("midratio", 532, sy + 98, 19, "MID RATIO", {}, {}, ratio ("midratio"), {}, 60);
        small ("hiratio", 624, sy + 98, 19, "HI RATIO", {}, {}, ratio ("hiratio"), {}, 60);
        section (694, sy, 170, 172, "ECHO");
        small ("echoint", 742, sy + 66, 24, "INTENSITY", "0", "100", [this] { const float v = value ("echoint"); return v < 0.05f ? String ("off") : String (juce::roundToInt (v)) + " %"; });
        small ("echosize", 816, sy + 66, 24, "SIZE", "50", "750", [this] { return String (juce::roundToInt (value ("echosize"))) + " ms"; });
        section (876, sy, 146, 172, "MISC");
        small ("mod", 914, sy + 66, 24, "MODULATION", "off", "100", [this] { const float v = value ("mod"); return v < 0.05f ? String ("off") : String (juce::roundToInt (v)) + " %"; });
        select ("quality", 958, sy + 52, 58, "QUALITY");

        infoItem ("ENGINE", [this] { return value ("bitdepth") > 0.5f ? String ("64-BIT") : String ("32-BIT"); });
        infoItem ("OUT", [this] { return String (juce::Decibels::gainToDecibels (juce::jmax (proc.vuOutL.load(), proc.vuOutR.load()), -60.0f), 1) + " dB"; });
        finish();
    }

private:
    // ---- time display: early reflections + decay envelope on a log time axis (0 .. 8 s)
    void paintTime (juce::Graphics& g, juce::Rectangle<float> r)
    {
        const float x = r.getX(), w = r.getWidth(), t0 = x + 20, base = r.getBottom() - 26, peak = r.getY() + 26;
        auto tx = [&] (float s) { return t0 + (w - 40) * std::log10 (1.0f + juce::jlimit (0.0f, 8.0f, s) * 9.0f / 8.0f); };
        const float decay = value ("decay"), pre = value ("predelay") / 1000.0f;
        const float att = value ("attack") / 100.0f * juce::jmin (decay, 2.0f) * 0.3f;
        const int ers = 8 + juce::roundToInt (value ("density") * 0.16f);
        juce::Random rnd (7);
        for (int i = 0; i < ers; ++i)
        {
            const float s = pre + 0.004f + (float) i * (0.006f + 0.01f * value ("size") / 62.0f) + rnd.nextFloat() * 0.005f;
            const float hh = (base - peak) * (0.35f + 0.4f * rnd.nextFloat()) * std::exp (-(float) i / 16.0f);
            g.setColour (orange().withAlpha (0.85f)); g.fillRect (tx (s), base - hh, 1.6f, hh);
        }
        juce::Path env; const float s0 = pre + 0.005f, end = juce::jmin (8.0f, s0 + att + decay);
        env.startNewSubPath (tx (s0), base);
        env.lineTo (tx (s0 + att), peak);
        for (float s = s0 + att; s <= end; s += 0.02f) env.lineTo (tx (s), peak + (base - peak) * (s - s0 - att) / juce::jmax (0.01f, decay));
        env.lineTo (tx (end), peak + (base - peak) * juce::jmin (1.0f, (end - s0 - att) / juce::jmax (0.01f, decay)));
        juce::Path fill (env); fill.lineTo (tx (end), base); fill.closeSubPath();
        g.setGradientFill (juce::ColourGradient (orangeLight().withAlpha (0.6f), 0, peak, orangeDeep().withAlpha (0.12f), 0, base, false));
        g.fillPath (fill);
        g.setColour (orangeLight()); g.strokePath (env, juce::PathStrokeType (1.6f));
        for (auto m : { std::pair<float, const char*> { 0.01f, "0.01" }, { 0.1f, "0.1" }, { 0.5f, "0.5" }, { 1.0f, "1" }, { 2.0f, "2" }, { 5.0f, "5" }, { 8.0f, "8 s" } })
            thw::text (g, m.second, juce::jmin (tx (m.first), r.getRight() - 20), base + 14, 9.5f, Colour (0xff8f897f), 7);
        thw::text (g, String (decay, 3) + " s", r.getRight() - 16, r.getY() + 20, 13.0f, lcdText(), 8, 1);
        thw::text (g, "RT60", r.getRight() - 16, r.getY() + 36, 8.5f, Colour (0xff8f897f), 8, 1, 2.0f);
    }

    // ---- damping display: decay-time ratio per band; drag nodes up/down, drag the dashed lines sideways
    juce::Rectangle<float> plot (juce::Rectangle<float> r) const { return r.reduced (20, 0).withTrimmedTop (10).withTrimmedBottom (28); }
    float fx (juce::Rectangle<float> r, float f) const { const auto p = plot (r); return p.getX() + p.getWidth() * std::log10 (juce::jlimit (20.0f, 20000.0f, f) / 20.0f) / 3.0f; }
    float fFromX (juce::Rectangle<float> r, float x) const { const auto p = plot (r); return 20.0f * std::pow (1000.0f, juce::jlimit (0.0f, 1.0f, (x - p.getX()) / p.getWidth())); }
    float yr (juce::Rectangle<float> r, float ratio) const { const auto p = plot (r); return juce::jlimit (p.getY() + 4, p.getBottom() - 4, p.getY() + p.getHeight() * 0.55f - std::log2 (juce::jmax (0.05f, ratio)) * 26.0f); }
    float ratioFromY (juce::Rectangle<float> r, float y) const { const auto p = plot (r); return std::pow (2.0f, (p.getY() + p.getHeight() * 0.55f - y) / 26.0f); }
    float nodeF (int i) const
    {
        const float lo = value ("crosslo"), hi = value ("crosshi");
        if (i == 0) return juce::jmax (30.0f, lo / 2.7f);
        if (i == 1) return std::sqrt (lo * juce::jmax (lo, hi));
        return juce::jmin (16000.0f, hi * 2.25f);
    }
    static const char* ratioId (int i) { return i == 0 ? "loratio" : i == 1 ? "midratio" : "hiratio"; }
    float ratioAt (float f) const
    {
        const float lo = value ("crosslo"), hi = juce::jmax (lo, value ("crosshi"));
        const float l = std::log2 (value ("loratio")), m = std::log2 (value ("midratio")), h = std::log2 (value ("hiratio"));
        auto blend = [] (float a, float b, float t) { t = juce::jlimit (0.0f, 1.0f, t); t = t * t * (3 - 2 * t); return a + (b - a) * t; };
        const float o = std::log2 (f);
        const float v = o < std::log2 (std::sqrt (lo * hi)) ? blend (l, m, (o - std::log2 (lo) + 0.4f) / 0.8f) : blend (m, h, (o - std::log2 (hi) + 0.4f) / 0.8f);
        return std::pow (2.0f, v);
    }
    void paintDamping (juce::Graphics& g, juce::Rectangle<float> r)
    {
        const auto p = plot (r);
        const float xl = fx (r, value ("crosslo")), xh = fx (r, value ("crosshi"));
        g.setColour (orange().withAlpha (0.06f)); g.fillRect (xl, p.getY(), juce::jmax (0.0f, xh - xl), p.getHeight());
        g.setColour (juce::Colours::white.withAlpha (0.06f)); g.drawHorizontalLine (juce::roundToInt (yr (r, 1.0f)), p.getX(), p.getRight());
        juce::Path c;
        for (int i = 0; i <= 200; ++i)
        {
            const float f = 20.0f * std::pow (1000.0f, (float) i / 200.0f), X = fx (r, f), Y = yr (r, ratioAt (f));
            if (i == 0) c.startNewSubPath (X, Y); else c.lineTo (X, Y);
        }
        g.setColour (orangeLight().withAlpha (0.9f)); g.strokePath (c, juce::PathStrokeType (2.0f));
        for (float x : { xl, xh })
        {
            juce::Path l; l.startNewSubPath (x, p.getY()); l.lineTo (x, p.getBottom());
            juce::Path d; const float dash[] = { 3.0f, 4.0f }; juce::PathStrokeType (1.2f).createDashedStroke (d, l, dash, 2);
            g.setColour (orange().withAlpha (0.65f)); g.fillPath (d);
            juce::Path t; t.addTriangle (x - 6, p.getBottom() + 2, x + 6, p.getBottom() + 2, x, p.getBottom() - 6);
            g.setColour (orange()); g.fillPath (t);
        }
        const char* names[] = { "LO", "MID", "HI" };
        for (int i = 0; i < 3; ++i)
        {
            const float X = fx (r, nodeF (i)), Y = yr (r, value (ratioId (i)));
            g.setColour (Colour (0xfffff3d6)); g.fillEllipse (X - 4.5f, Y - 4.5f, 9, 9);
            thw::text (g, String (names[i]) + " " + String (value (ratioId (i)), 2) + "x", X, Y - 16, 10.0f, orangeLight(), 8);
        }
        for (auto m : { std::pair<float, const char*> { 20.0f, "20" }, { 50.0f, "50" }, { 100.0f, "100" }, { 400.0f, "400" }, { 1000.0f, "1k" }, { 4000.0f, "4k" }, { 10000.0f, "10k" }, { 20000.0f, "20k Hz" } })
            thw::text (g, m.second, juce::jmin (fx (r, m.first), r.getRight() - 24), r.getBottom() - 12, 9.5f, Colour (0xff8f897f), 7);
    }
    void pickDamping (juce::Rectangle<float> r, juce::Point<float> pos)
    {
        dragId = {}; float best = 14.0f;
        for (int i = 0; i < 3; ++i)
        {
            const float d = pos.getDistanceFrom ({ fx (r, nodeF (i)), yr (r, value (ratioId (i))) });
            if (d < best) { best = d; dragId = ratioId (i); }
        }
        if (dragId.isEmpty())
        {
            best = 10.0f;
            for (auto id : { "crosslo", "crosshi" })
                if (std::abs (fx (r, value (id)) - pos.x) < best) { best = std::abs (fx (r, value (id)) - pos.x); dragId = id; }
        }
        if (dragId.isNotEmpty()) { param (dragId)->beginChangeGesture(); dragDamping (r, pos, false); }
    }
    void dragDamping (juce::Rectangle<float> r, juce::Point<float> pos, bool)
    {
        if (dragId.isEmpty()) return;
        auto* p = param (dragId);
        const float v = dragId.startsWith ("cross") ? fFromX (r, pos.x) : ratioFromY (r, pos.y);
        p->setValueNotifyingHost (p->convertTo0to1 (juce::jlimit (p->getNormalisableRange().start, p->getNormalisableRange().end, v)));
    }

    Processor& proc;
    String dragId;
};
}
}
