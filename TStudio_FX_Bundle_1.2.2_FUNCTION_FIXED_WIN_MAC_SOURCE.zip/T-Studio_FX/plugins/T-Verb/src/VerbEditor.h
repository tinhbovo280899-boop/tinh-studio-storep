#pragma once
#include "VerbProcessor.h"
#include "../../common/StudioSpecs.h"
namespace tverb
{
class Editor final : public tstudio_ui::Editor
{
public:
    explicit Editor(Processor& p)
        : tstudio_ui::Editor(p,p.apvts,tstudio_ui::verbSpec(),p.getLicense(),[&p]{return std::array<float,2>{{p.vuOutL.load(),p.vuOutR.load()}};}) {}
};
}
