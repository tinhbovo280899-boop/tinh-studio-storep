#pragma once
// T Studio shared kit: header, logo glyphs, mode buttons, meters, base processor.
#include "NTUI.h"
#include "TBrand.h"
#include "TProc.h"
#include <atomic>
#include <array>
#include <vector>

namespace tkit
{
    enum class Glyph { GEQ, DeNoise, Delay, DeEsser, Verb, Pitch };

    inline void drawGlyph (juce::Graphics& g, juce::Rectangle<float> lr, Glyph gl)
    {
        const float cx = lr.getCentreX(), cy = lr.getCentreY();
        juce::Path p;
        const juce::PathStrokeType st (1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);
        g.setColour (ntc::gold);
        switch (gl)
        {
            case Glyph::GEQ:
            {
                const float hs[] = { 4, 8, 5, 9, 6 };
                for (int i = 0; i < 5; ++i) g.drawLine (cx - 8 + i * 4.0f, cy + 6, cx - 8 + i * 4.0f, cy + 6 - hs[i] * 1.2f, 2.0f);
                return;
            }
            case Glyph::DeNoise:
                p.startNewSubPath (cx - 9, cy);
                for (int i = 0; i <= 18; ++i) p.lineTo (cx - 9 + i, cy + std::sin (i * 1.3f) * (i < 9 ? 5.0f : 1.5f));
                g.strokePath (p, st); return;
            case Glyph::Delay:
                for (int i = 0; i < 4; ++i) { const float r = 3.2f - i * 0.6f; g.setColour (ntc::gold.withAlpha (1.0f - i * 0.22f));
                    g.fillEllipse (cx - 9 + i * 5.5f - r, cy - r, r * 2, r * 2); }
                return;
            case Glyph::DeEsser:
                g.setFont (ntc::font (ntc::W::Bold, 16.0f)); g.drawText ("S", lr.translated (-3, -1), juce::Justification::centred);
                p.startNewSubPath (cx + 5, cy - 5); p.lineTo (cx + 5, cy + 5); p.startNewSubPath (cx + 2, cy + 2); p.lineTo (cx + 5, cy + 5); p.lineTo (cx + 8, cy + 2);
                g.strokePath (p, st); return;
            case Glyph::Verb:
                for (int i = 0; i < 3; ++i) { const float r = 4.0f + i * 3.5f; p.addCentredArc (cx - 6, cy + 4, r, r, 0, 0.25f, 1.45f, true); }
                g.strokePath (p, st); return;
            case Glyph::Pitch:
                p.startNewSubPath (cx - 5, cy + 7); p.lineTo (cx - 5, cy - 6); p.startNewSubPath (cx - 8.5f, cy - 2.5f); p.lineTo (cx - 5, cy - 6); p.lineTo (cx - 1.5f, cy - 2.5f);
                p.startNewSubPath (cx + 5, cy - 7); p.lineTo (cx + 5, cy + 6); p.startNewSubPath (cx + 1.5f, cy + 2.5f); p.lineTo (cx + 5, cy + 6); p.lineTo (cx + 8.5f, cy + 2.5f);
                g.strokePath (p, st); return;
        }
    }

    /** Background + logo + "T-<suffix>" + tagline, exactly like T-Comp / T-EQ. */
    inline void paintHeader (juce::Graphics& g, juce::Rectangle<float> r, Glyph gl,
                             const juce::String& suffix, const juce::String& tagline)
    {
        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff111318), 0, 0, ntc::bg, 0, r.getBottom(), false));
        g.fillAll();
        auto lr = juce::Rectangle<float> (18, 12, 30, 30);
        g.setColour (ntc::gold.withAlpha (0.16f)); g.fillEllipse (lr);
        g.setColour (ntc::gold); g.drawEllipse (lr.reduced (1), 1.4f);
        drawGlyph (g, lr, gl);
        txbrand::draw (g, { 58, 10, 260, 22 }, suffix,
                       ntc::font (ntc::W::Bold, 19.0f).withExtraKerningFactor (0.06f), ntc::text, ntc::gold);
        ntc::caps (g, tagline, { 58, 30, 300, 14 }, ntc::gold, juce::Justification::centredLeft, 10.0f);
    }

    /** Row of radio buttons bound to an AudioParameterChoice. */
    class ChoiceButtons : public juce::Component, private juce::AudioProcessorValueTreeState::Listener
    {
    public:
        ChoiceButtons (juce::AudioProcessorValueTreeState& s, const juce::String& id, juce::StringArray labels)
            : state (s), paramId (id)
        {
            for (int i = 0; i < labels.size(); ++i)
            {
                auto* b = buttons.add (new juce::TextButton (labels[i]));
                b->setClickingTogglesState (false);
                b->onClick = [this, i] { if (auto* p = state.getParameter (paramId)) {
                    p->beginChangeGesture(); p->setValueNotifyingHost (p->convertTo0to1 ((float) i)); p->endChangeGesture(); }
                    if (onChange) onChange (i); };
                addAndMakeVisible (b);
            }
            state.addParameterListener (paramId, this);
            sync();
        }
        ~ChoiceButtons() override { state.removeParameterListener (paramId, this); }
        void resized() override
        {
            const int n = buttons.size(), gap = 6;
            const float w = (getWidth() - gap * (n - 1)) / (float) n;
            for (int i = 0; i < n; ++i) buttons[i]->setBounds (juce::roundToInt (i * (w + gap)), 0, juce::roundToInt (w), getHeight());
        }
        std::function<void (int)> onChange;   // called after the user picks an option
        void sync()
        {
            const int v = (int) state.getRawParameterValue (paramId)->load();
            for (int i = 0; i < buttons.size(); ++i) buttons[i]->setToggleState (i == v, juce::dontSendNotification);
        }
    private:
        void parameterChanged (const juce::String&, float) override
        { juce::MessageManager::callAsync ([sp = juce::Component::SafePointer<ChoiceButtons> (this)] { if (sp) sp->sync(); }); }
        juce::AudioProcessorValueTreeState& state; juce::String paramId;
        juce::OwnedArray<juce::TextButton> buttons;
    };

    /** Vertical level / gain-reduction meter. value() returns dB. */
    class Meter : public juce::Component
    {
    public:
        Meter (juce::String label, float minDb, float maxDb, bool reduction)
            : name (std::move (label)), lo (minDb), hi (maxDb), gr (reduction) {}
        std::function<float()> value;
        void paint (juce::Graphics& g) override
        {
            auto r = getLocalBounds().toFloat();
            ntc::caps (g, name, r.removeFromTop (16), ntc::dim, juce::Justification::centred, 10.0f);
            auto val = r.removeFromBottom (18);
            auto bar = r.withSizeKeepingCentre (12.0f, r.getHeight() - 6);
            g.setColour (ntc::well); g.fillRoundedRectangle (bar, 3.0f);
            const float db = value ? value() : lo;
            const float t = juce::jlimit (0.0f, 1.0f, (db - lo) / (hi - lo));
            g.setColour (gr ? ntc::coral : ntc::gold);
            if (gr) g.fillRoundedRectangle (bar.withHeight (bar.getHeight() * t), 3.0f);
            else    g.fillRoundedRectangle (bar.withTrimmedTop (bar.getHeight() * (1 - t)), 3.0f);
            g.setColour (ntc::text); g.setFont (ntc::font (ntc::W::Medium, 11.0f));
            g.drawText (juce::String (db, 1), val, juce::Justification::centred);
        }
    private:
        juce::String name; float lo, hi; bool gr;
    };

    /** NTLook + vertical fader drawing (GEQ bands). */
    class TLook : public NTLook
    {
    public:
        void drawLinearSlider (juce::Graphics& g, int x, int y, int w, int h, float pos, float a, float b,
                               juce::Slider::SliderStyle st, juce::Slider& s) override
        {
            if (st != juce::Slider::LinearVertical) { NTLook::drawLinearSlider (g, x, y, w, h, pos, a, b, st, s); return; }
            const float cx = x + w * 0.5f;
            const float zero = y + h * 0.5f;
            g.setColour (ntc::well); g.fillRoundedRectangle (cx - 2.0f, (float) y, 4.0f, (float) h, 2.0f);
            g.setColour (ntc::gold.withAlpha (0.9f));
            g.fillRoundedRectangle (cx - 2.0f, std::min (pos, zero), 4.0f, std::abs (pos - zero), 2.0f);
            auto thumb = juce::Rectangle<float> (w * 0.78f, 11.0f).withCentre ({ cx, pos });
            g.setColour (juce::Colours::black.withAlpha (0.45f)); g.fillRoundedRectangle (thumb.translated (0, 1.5f), 3.0f);
            g.setGradientFill (juce::ColourGradient (ntc::raised.brighter (0.35f), 0, thumb.getY(), ntc::raised.darker (0.3f), 0, thumb.getBottom(), false));
            g.fillRoundedRectangle (thumb, 3.0f);
            g.setColour (ntc::gold); g.drawHorizontalLine ((int) pos, thumb.getX() + 2, thumb.getRight() - 2);
        }
    };

    inline void stylePower (juce::TextButton& b)
    {
        b.getProperties().set ("power", true);
        b.setClickingTogglesState (true);
    }

    /** Message-thread spectrum: pulls samples from an AnalyserFeed, 4096-point Hann FFT, 256 log bins. */
    class SpectrumAnalyser
    {
    public:
        SpectrumAnalyser() : fft (12), ring (4096, 0.0f), win (4096), work (8192), tmp (1 << 15)
        {
            juce::dsp::WindowingFunction<float>::fillWindowingTables (win.data(), win.size(), juce::dsp::WindowingFunction<float>::hann, false);
            winSum = 0.0f; for (float w : win) winSum += w;
            db.fill (-90.0f);
        }
        /** Returns true when new audio arrived. */
        bool update (AnalyserFeed& feed, double sr)
        {
            const int n = feed.pull (tmp.data(), (int) tmp.size());
            if (n <= 0) { for (auto& v : db) v = std::max (-90.0f, v - 1.0f); return false; }
            for (int i = 0; i < n; ++i) { ring[(size_t) pos] = tmp[(size_t) i]; pos = (pos + 1) % (int) ring.size(); }
            const int N = (int) ring.size();
            for (int i = 0; i < N; ++i) work[(size_t) i] = ring[(size_t) ((pos + i) % N)] * win[(size_t) i];
            std::fill (work.begin() + N, work.end(), 0.0f);
            fft.performFrequencyOnlyForwardTransform (work.data(), true);
            const double binHz = (sr > 0 ? sr : 48000.0) / N;
            for (int i = 0; i < 256; ++i)
            {
                const double f0 = 20.0 * std::pow (1000.0, (i - 0.5) / 255.0), f1 = 20.0 * std::pow (1000.0, (i + 0.5) / 255.0);
                const int k0 = juce::jlimit (1, N / 2 - 1, (int) std::floor (f0 / binHz)), k1 = juce::jlimit (k0, N / 2 - 1, (int) std::ceil (f1 / binHz));
                float m = 0.0f; for (int k = k0; k <= k1; ++k) m = std::max (m, work[(size_t) k]);
                const float d = m > 0 ? 20.0f * std::log10 (m * 2.0f / winSum) : -90.0f;
                db[(size_t) i] = std::max (d, db[(size_t) i] - 1.5f);        // fast attack, slow fall
            }
            return true;
        }
        std::array<float, 256> db {};
    private:
        juce::dsp::FFT fft;
        std::vector<float> ring, win, work, tmp;
        float winSum = 1.0f; int pos = 0;
    };

    inline juce::String fmtDb (double v)  { return (v > 0 ? "+" : "") + juce::String (v, 1) + " dB"; }
    inline juce::String fmtMs (double v)  { return v < 10 ? juce::String (v, 1) + " ms" : v < 1000 ? juce::String (juce::roundToInt (v)) + " ms" : juce::String (v / 1000.0, 2) + " s"; }
    inline juce::String fmtHz (double v)  { return v < 1000 ? juce::String (juce::roundToInt (v)) + " Hz" : juce::String (v / 1000.0, v < 10000 ? 2 : 1) + " kHz"; }
    inline juce::String fmtPct (double v) { return juce::String (juce::roundToInt (v)) + "%"; }

    /** Log-frequency axis helpers for displays (20 Hz .. 20 kHz). */
    // Plot area inside a display card: 26 px left for dB labels, 6 px right, 18 px bottom for Hz labels.
    inline juce::Rectangle<float> plotArea (juce::Rectangle<float> r) { return { r.getX() + 26, r.getY() + 6, r.getWidth() - 32, r.getHeight() - 24 }; }
    inline float freqToX (float f, juce::Rectangle<float> r)
    { auto a = plotArea (r); return a.getX() + a.getWidth() * std::log (f / 20.0f) / std::log (1000.0f); }

    inline void drawFreqGrid (juce::Graphics& g, juce::Rectangle<float> r, float dbLo, float dbHi, float dbStep)
    {
        g.setColour (ntc::well); g.fillRoundedRectangle (r, 8.0f);
        g.setFont (ntc::font (ntc::W::Regular, 10.5f));
        for (float f : { 50.f, 100.f, 200.f, 500.f, 1000.f, 2000.f, 5000.f, 10000.f })
        {
            const float x = freqToX (f, r);
            g.setColour (ntc::line); g.drawVerticalLine ((int) x, r.getY() + 4, r.getBottom() - 16);
            g.setColour (ntc::dim);
            g.drawText (f < 1000 ? juce::String ((int) f) : juce::String ((int) (f / 1000)) + "k", juce::Rectangle<float> (x - 20, r.getBottom() - 15, 40, 12), juce::Justification::centred);
        }
        for (float d = dbLo; d <= dbHi + 0.01f; d += dbStep)
        {
            const float y = juce::jmap (d, dbLo, dbHi, r.getBottom() - 18, r.getY() + 6);
            g.setColour (ntc::line); g.drawHorizontalLine ((int) y, r.getX() + 26, r.getRight() - 6);
            g.setColour (ntc::dim);
            g.drawText (juce::String ((int) d), juce::Rectangle<float> (r.getX() + 2, y - 6, 22, 12), juce::Justification::centredRight);
        }
    }

    inline juce::Path spectrumPath (const std::array<float, 256>& s, juce::Rectangle<float> r, float dbLo, float dbHi, bool closed)
    {
        juce::Path p;
        for (size_t i = 0; i < s.size(); ++i)
        {
            const float x = plotArea (r).getX() + plotArea (r).getWidth() * (float) i / (float) (s.size() - 1);
            const float y = juce::jmap (juce::jlimit (dbLo, dbHi, s[i]), dbLo, dbHi, r.getBottom() - 18, r.getY() + 6);
            if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
        }
        if (closed) { p.lineTo (r.getRight() - 6, r.getBottom() - 18); p.lineTo (r.getX() + 26, r.getBottom() - 18); p.closeSubPath(); }
        return p;
    }
}
