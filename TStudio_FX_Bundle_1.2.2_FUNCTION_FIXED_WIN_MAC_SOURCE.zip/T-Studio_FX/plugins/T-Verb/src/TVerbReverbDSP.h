#pragma once
#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <vector>
#include <memory>
#include <algorithm>
#include "TVerbTables.h"
#include "TVerbSubComponents.h"

namespace tverbdsp {

// ============================================================================
                                                                           
// ============================================================================
enum BitDepth_t : int {
    kBitDepth_32BitFloat  = 0, // CReverb<float>
    kBitDepth_64BitDouble = 1  // CReverb<double>
};

enum Quality_t : int {
    kQuality_Low    = 0,                                                 
    kQuality_Normal = 1,                                                 
    kQuality_High   = 2                                                  
};

// ============================================================================
// CReverbBase — Abstract Dual-Precision Reverb Engine Interface
                                                                                        
// ============================================================================
class CReverbBase {
public:
    virtual ~CReverbBase() = default;

                                                              
    static bool CreateAndInit(CReverbBase** ppOutReverb, float sampleRate, long blockSize, int quality, BitDepth_t bitDepth);
    static bool ChangeBitDepth(CReverbBase** ppInOutReverb, BitDepth_t newBitDepth);

                                                                             
    virtual void       DoReverb(float** inputs, float** outputs, long sampleFrames, bool replacing) = 0;
    virtual void       DoSilence(float** inputs, float** outputs, long sampleFrames, bool replacing) = 0;
    virtual void       set_DecayInSec(float decaySec) = 0;
    virtual void       set_DryLevel(float dryLinear) = 0;
    virtual void       set_WetLevel(float wetLinear) = 0;
    virtual void       set_Type(int type) = 0;
    virtual void       set_Damping(float lowFreq, float highFreq, float lowRatio, float midRatio, float highRatio) = 0;
    virtual void       set_RoomSize(float roomSizeNorm) = 0;
    virtual void       set_Attack(float attackNorm) = 0;
    virtual void       set_Spread(float spreadNorm) = 0;
    virtual void       set_Diffusion(float diffusionNorm) = 0;
    virtual void       set_Density(float densityNorm) = 0;
    virtual void       set_Echo(float echoIntensityNorm, float echoSizeMs) = 0;
    virtual void       set_Predelay(float predelayMs) = 0;
    virtual void       set_RoomWidth(float widthNorm) = 0;
    virtual void       set_Modulation(float modNorm) = 0;
    virtual void       set_PostEQFreq(float loCutHz, float hiCutHz) = 0;
    virtual void       get_PostEQFreq(float* outLoCutHz, float* outHiCutHz) const = 0;
    virtual void       set_PostEQOnOff(bool loCutOn, bool hiCutOn) = 0;
    virtual void       set_Quality(int quality) = 0;
    virtual void       set_DryLevelEnable(bool enable) = 0;
    virtual void       set_WetLevelEnable(bool enable) = 0;
    virtual void       set_SampleRate(float hostSampleRate) = 0;
    virtual void       set_BlockSize(long hostBlockSize) = 0;
    virtual float      get_SampleRate() const = 0;
    virtual long       get_BlockSize() const = 0;
    virtual int        get_Quality() const = 0;
    virtual void       suspend() = 0;
    virtual BitDepth_t get_bitDepth() const = 0;
    virtual void       get_Reflections(ReflectionStruct* outRefl) const = 0;
    virtual bool       ConstructorSucceded() = 0;
};

// ============================================================================
                                                                                   
                                                                                               
// ============================================================================
template <typename T>
class CReverb final : public CReverbBase {
public:
    static constexpr int kMaxCombsPerChannel     = 40; // 80 total CComb<T> instances (+0x90 .. +0x308)
    static constexpr int kMaxAllpassesPerChannel = 40; // 80 total CAllpass<T> instances (+0x310 .. +0x588)
    static constexpr int kCombInputRingSize      = CComb<T>::kSharedRingBufSize; // up to 57,600 samples

    CReverb();
    ~CReverb() override;

    void       DoReverb(float** inputs, float** outputs, long sampleFrames, bool replacing) override;
    void       DoSilence(float** inputs, float** outputs, long sampleFrames, bool replacing) override;
    void       set_DecayInSec(float decaySec) override;
    void       set_DryLevel(float dryLinear) override;
    void       set_WetLevel(float wetLinear) override;
    void       set_Type(int type) override;
    void       set_Damping(float lowFreq, float highFreq, float lowRatio, float midRatio, float highRatio) override;
    void       set_RoomSize(float roomSizeNorm) override;
    void       set_Attack(float attackNorm) override;
    void       set_Spread(float spreadNorm) override;
    void       set_Diffusion(float diffusionNorm) override;
    void       set_Density(float densityNorm) override;
    void       set_Echo(float echoIntensityNorm, float echoSizeMs) override;
    void       set_Predelay(float predelayMs) override;
    void       set_RoomWidth(float widthNorm) override;
    void       set_Modulation(float modNorm) override;
    void       set_PostEQFreq(float loCutHz, float hiCutHz) override;
    void       get_PostEQFreq(float* outLoCutHz, float* outHiCutHz) const override;
    void       set_PostEQOnOff(bool loCutOn, bool hiCutOn) override;
    void       set_Quality(int quality) override;
    void       set_DryLevelEnable(bool enable) override;
    void       set_WetLevelEnable(bool enable) override;
    void       set_SampleRate(float hostSampleRate) override;
    void       set_BlockSize(long hostBlockSize) override;
    float      get_SampleRate() const override { return static_cast<float>(m_fHostSampleRate); }
    long       get_BlockSize() const override  { return m_nHostBlockSize; }
    int        get_Quality() const override    { return m_nQuality; }
    void       suspend() override;
    BitDepth_t get_bitDepth() const override;
    void       get_Reflections(ReflectionStruct* outRefl) const override;
    bool       ConstructorSucceded() override  { return m_bConstructorSucceeded; }

    void       CalcParams(int mode);
    void       ResetBuffer();

private:
    void AllocateWorkBuffers();

    // Single-owner DSP: prepare, setters, process and suspend must be serialized
    // by the host/processor. Never read or mutate this engine from the UI thread.

    // Internal work buffers (+0x20 .. +0x48)
    std::vector<T> m_BufInL;       // +0x20
    std::vector<T> m_BufInR;       // +0x28
    std::vector<T> m_BufLateL;     // +0x30
    std::vector<T> m_BufLateR;     // +0x38
    std::vector<T> m_BufEarlyL;    // +0x40
    std::vector<T> m_BufEarlyR;    // +0x48
    std::vector<float> m_DryCopyL;
    std::vector<float> m_DryCopyR;

    // Shared circular input history buffers feeding the 80 parallel combs (+0x50 .. +0x70)
    T  m_CombInputRingL[kCombInputRingSize]; // +0x50
    T  m_CombInputRingR[kCombInputRingSize]; // +0x58
    T* m_pCombRingWriteL;                    // +0x60
    T* m_pCombRingWriteR;                    // +0x68
    int m_nActiveCombRingSize;               // +0x70 (int(0.6 * m_fDspSampleRate))

    // DSP sub-modules
    CSampleRateConvert<T> m_ResamplerInL;    // +0x5c8
    CSampleRateConvert<T> m_ResamplerInR;    // +0x5d0
    CSampleRateConvert<T> m_ResamplerOutL;   // +0x5d8
    CSampleRateConvert<T> m_ResamplerOutR;   // +0x5e0
    CDelay<T>             m_PreDelayL;       // +0x80
    CDelay<T>             m_PreDelayR;       // +0x88
    CComb<T>              m_Combs[kMaxCombsPerChannel * 2];       // +0x90 .. +0x308 (80 combs)
    CAllpass<T>           m_Allpasses[kMaxAllpassesPerChannel * 2];// +0x310 .. +0x588 (80 allpasses)
    CPattern<T>           m_Pattern;         // +0x590
    CStereoModDelay<T>    m_ModDelay1;       // +0x598 (Input Chorus/Modulation)
    CStereoModDelay<T>    m_ModDelay2;       // +0x5a0 (Late Echo / Stereo Chorus)
    CBiQuad<T>            m_PostEqHiCutL;    // +0x5a8
    CBiQuad<T>            m_PostEqLoCutL;    // +0x5b0
    CBiQuad<T>            m_PostEqHiCutR;    // +0x5b8
    CBiQuad<T>            m_PostEqLoCutR;    // +0x5c0

    // State & Parameters (+0x5e8 .. +0x750)
    int    m_nCombs;                 // +0x5e8 (Active stereo comb pairs, 4..40)
    double m_fCombDelayMaxMs;        // +0x5f0 (Base comb delay in ms)
    double m_fCombDelayRatio;        // +0x5f8 (Comb delay max/min ratio)
    int    m_nAllpasses;             // +0x600 (Active stereo allpass pairs, 0..40)
    double m_fAllpassDelayMaxMs;     // +0x608 (Base allpass delay in ms)
    double m_fAllpassDelayRatio;                              
    double m_fLowRatio;              // +0x620
    double m_fMidRatio;              // +0x628
    double m_fHighRatio;             // +0x630
    double m_fCombGainLow;           // +0x638
    double m_fCombGainMid;           // +0x640
    double m_fCombGainHigh;          // +0x648
    double m_fLowCrossoverCoeff;     // +0x650 (cLow Jot allpass coeff)
    double m_fHighCrossoverCoeff;    // +0x658 (cHigh Jot allpass coeff)
    double m_fLowCrossoverHz;
    double m_fHighCrossoverHz;
    double m_fTypeGain;              // +0x660
    double m_fDecayInSec;            // +0x670
    double m_fDiffusion;             // +0x678
    double m_fDensity;               // +0x680
    double m_fWidthCrossGain;        // +0x688 (Stereo matrix factor in DoReverb)
    double m_fWidthCombCorr;         // +0x690 (Comb L/R decorrelation factor in CalcParams(1))
    double m_fRoomWidth;             // +0x698
    double m_fModulation;            // +0x6a0
    double m_fRoomSize;              // +0x6a8
    double m_fPredelayMs;            // +0x6b0
    double m_fEchoIntensity;         // +0x6b8
    double m_fEchoSizeMs;            // +0x6c0
    int    m_nType;                  // +0x6c8
    int    m_nQuality;               // +0x6cc
    double m_fAttack;                // +0x6d0
    double m_fSpread;                // +0x6d8
    long   m_nHostBlockSize;         // +0x6e0
    long   m_nInternalBlockSize;
    double m_fDspSampleRate;         // +0x6e8
    double m_fHostSampleRate;        // +0x6f0
    float  m_fWetLevel;              // +0x700
    float  m_fDryLevel;              // +0x704
    bool   m_bDryLevelEnable;        // +0x708
    bool   m_bWetLevelEnable;        // +0x709
    double m_fEarlyGain;             // +0x710
    double m_fOverallCombGain;       // +0x718
    double m_fLateGain;              // +0x720
    double m_fLoCutHz;               // +0x728
    double m_fHiCutHz;               // +0x730
    bool   m_bLoCutOn;               // +0x738
    bool   m_bHiCutOn;               // +0x739
    bool   m_bConstructorSucceeded;  // +0x73a
    T      m_fPreEmphasisStateL;     // +0x740
    T      m_fPreEmphasisStateR;     // +0x748
};

}                          
