#include "TVerbReverbDSP.h"

namespace tverbdsp {

// ============================================================================
                                                              
// ============================================================================
bool CReverbBase::CreateAndInit(CReverbBase** ppOutReverb, float sampleRate, long blockSize, int quality, BitDepth_t bitDepth) {
    if (!ppOutReverb) return false;
    if (*ppOutReverb) {
        delete *ppOutReverb;
        *ppOutReverb = nullptr;
    }

    CReverbBase* pNew = nullptr;
    if (bitDepth == kBitDepth_64BitDouble) {
        pNew = new CReverb<double>();
    } else {
        pNew = new CReverb<float>();
    }

    if (!pNew || !pNew->ConstructorSucceded()) {
        delete pNew;
        return false;
    }

    pNew->set_SampleRate(sampleRate);
    pNew->set_BlockSize(blockSize);
    pNew->set_Quality(quality);
    pNew->suspend();

    *ppOutReverb = pNew;
    return true;
}

bool CReverbBase::ChangeBitDepth(CReverbBase** ppInOutReverb, BitDepth_t newBitDepth) {
    if (!ppInOutReverb || !*ppInOutReverb) return false;
    if ((*ppInOutReverb)->get_bitDepth() == newBitDepth) return false;

    float sr   = (*ppInOutReverb)->get_SampleRate();
    long  bs   = (*ppInOutReverb)->get_BlockSize();
    int   qual = (*ppInOutReverb)->get_Quality();

    return CreateAndInit(ppInOutReverb, sr, bs, qual, newBitDepth);
}

// ============================================================================
                                                                     
// ============================================================================
template <>
BitDepth_t CReverb<float>::get_bitDepth() const {
    return kBitDepth_32BitFloat;
}

template <>
BitDepth_t CReverb<double>::get_bitDepth() const {
    return kBitDepth_64BitDouble;
}

template <typename T>
CReverb<T>::CReverb()
    : m_pCombRingWriteL(m_CombInputRingL)
    , m_pCombRingWriteR(m_CombInputRingR)
    , m_nActiveCombRingSize(26460)                                
    , m_nCombs(20)                                  
    , m_fCombDelayMaxMs(22.67)                                    
    , m_fCombDelayRatio(2.0)                                      
    , m_nAllpasses(10)                              
    , m_fAllpassDelayMaxMs(2.267)                                 
    , m_fAllpassDelayRatio(1.2)                                   
    , m_fLowRatio(0.8)                                            
    , m_fMidRatio(1.0)                                            
    , m_fHighRatio(1.0)                                           
    , m_fCombGainLow(0.8)                    
    , m_fCombGainMid(1.0)                    
    , m_fCombGainHigh(1.0)                   
    , m_fLowCrossoverCoeff(-0.7)                                  
    , m_fHighCrossoverCoeff(0.6)                                  
    , m_fLowCrossoverHz(800.0)
    , m_fHighCrossoverHz(4000.0)
    , m_fTypeGain(0.0)                       
    , m_fDecayInSec(2.0)                     
    , m_fDiffusion(0.8)                      
    , m_fDensity(0.5)                        
    , m_fWidthCrossGain(0.8)                 
    , m_fWidthCombCorr(1.0)                  
    , m_fRoomWidth(0.8)                      
    , m_fModulation(0.0)                     
    , m_fRoomSize(0.3)                                            
    , m_fPredelayMs(0.0)                     
    , m_fEchoIntensity(0.0)                  
    , m_fEchoSizeMs(250.0)                                        
    , m_nType(-1)
    , m_nQuality(-1)                         
    , m_fAttack(0.0)                         
    , m_fSpread(0.0)                         
    , m_nHostBlockSize(512)
    , m_nInternalBlockSize(1024)
    , m_fDspSampleRate(44100.0)              
    , m_fHostSampleRate(44100.0)             
    , m_fWetLevel(1.0f)                      
    , m_fDryLevel(0.0f)                      
    , m_bDryLevelEnable(true)                
    , m_bWetLevelEnable(true)                
    , m_fEarlyGain(0.0)                      
    , m_fOverallCombGain(1.0)                
    , m_fLateGain(1.0)                       
    , m_fLoCutHz(20.0)                                            
    , m_fHiCutHz(10000.0)                                         
    , m_bLoCutOn(false)                      
    , m_bHiCutOn(false)                      
    , m_bConstructorSucceeded(false)
    , m_fPreEmphasisStateL(static_cast<T>(0))
    , m_fPreEmphasisStateR(static_cast<T>(0))
{
    std::memset(m_CombInputRingL, 0, sizeof(m_CombInputRingL));
    std::memset(m_CombInputRingR, 0, sizeof(m_CombInputRingR));

                                                                                  
    for (int i = 0; i < kMaxAllpassesPerChannel * 2; ++i) {
        m_Allpasses[i].set_Gain(static_cast<T>(-0.5));
    }

    AllocateWorkBuffers();
    set_Quality(kQuality_Normal);
    set_Type(0);
    set_Damping(800.0f, 4000.0f, 1.0f, 1.0f, 0.6f);
    set_Modulation(0.1f);
    set_RoomWidth(0.9444444f);
    m_bConstructorSucceeded = true;
}

template <typename T>
CReverb<T>::~CReverb() = default;

// ============================================================================
                                                           
// ============================================================================
template <typename T>
void CReverb<T>::AllocateWorkBuffers() {
    m_nActiveCombRingSize = std::clamp(
        static_cast<int>(0.6 * m_fDspSampleRate),
        1024,
        kCombInputRingSize);

    double ratio = m_fDspSampleRate / std::max(1.0, m_fHostSampleRate);
    long dspBlock = static_cast<long>(static_cast<double>(m_nHostBlockSize) * ratio) + 1;
    if (dspBlock > m_nActiveCombRingSize) {
        m_nActiveCombRingSize = std::min<int>(static_cast<int>(dspBlock) + 16, kCombInputRingSize);
    }
    m_nInternalBlockSize = dspBlock + 10;
    // Reserve for the highest quality up front. Switching quality must not grow
    // vectors in the audio callback; larger host blocks are processed in chunks.
    const long maxDspBlock = static_cast<long>(std::ceil(
        m_nHostBlockSize * 96000.0 / std::max(8000.0, m_fHostSampleRate))) + 16;
    size_t sz = static_cast<size_t>(std::max<long>(maxDspBlock, 256));

    m_BufInL.assign(sz, static_cast<T>(0));
    m_BufInR.assign(sz, static_cast<T>(0));
    m_BufLateL.assign(sz, static_cast<T>(0));
    m_BufLateR.assign(sz, static_cast<T>(0));
    m_BufEarlyL.assign(sz, static_cast<T>(0));
    m_BufEarlyR.assign(sz, static_cast<T>(0));
    m_DryCopyL.resize(static_cast<size_t>(m_nHostBlockSize));
    m_DryCopyR.resize(static_cast<size_t>(m_nHostBlockSize));
    m_Pattern.PrepareBlockSize(maxDspBlock);
    m_ResamplerInL.PrepareBlockSize(m_nHostBlockSize, maxDspBlock);
    m_ResamplerInR.PrepareBlockSize(m_nHostBlockSize, maxDspBlock);
    m_ResamplerOutL.PrepareBlockSize(m_nHostBlockSize, maxDspBlock);
    m_ResamplerOutR.PrepareBlockSize(m_nHostBlockSize, maxDspBlock);

    std::memset(m_CombInputRingL, 0, sizeof(m_CombInputRingL));
    std::memset(m_CombInputRingR, 0, sizeof(m_CombInputRingR));

                                                                                              
    m_pCombRingWriteL = m_CombInputRingL + (m_nActiveCombRingSize - 1);
    m_pCombRingWriteR = m_CombInputRingR + (m_nActiveCombRingSize - 1);

                                                                                                                
    for (int i = 0; i < kMaxCombsPerChannel * 2; i += 2) {
        m_Combs[i].bindSharedInputBuffer(m_CombInputRingL, m_nActiveCombRingSize, m_pCombRingWriteL);
        m_Combs[i + 1].bindSharedInputBuffer(m_CombInputRingR, m_nActiveCombRingSize, m_pCombRingWriteR);
    }
}

// ============================================================================
                                             
// ============================================================================
template <typename T>
void CReverb<T>::ResetBuffer() {
    std::fill(m_BufInL.begin(), m_BufInL.end(), static_cast<T>(0));
    std::fill(m_BufInR.begin(), m_BufInR.end(), static_cast<T>(0));
    std::fill(m_BufLateL.begin(), m_BufLateL.end(), static_cast<T>(0));
    std::fill(m_BufLateR.begin(), m_BufLateR.end(), static_cast<T>(0));
    std::fill(m_BufEarlyL.begin(), m_BufEarlyL.end(), static_cast<T>(0));
    std::fill(m_BufEarlyR.begin(), m_BufEarlyR.end(), static_cast<T>(0));

    std::memset(m_CombInputRingL, 0, sizeof(m_CombInputRingL));
    std::memset(m_CombInputRingR, 0, sizeof(m_CombInputRingR));
    m_pCombRingWriteL = m_CombInputRingL + (m_nActiveCombRingSize - 1);
    m_pCombRingWriteR = m_CombInputRingR + (m_nActiveCombRingSize - 1);

    for (int i = 0; i < kMaxCombsPerChannel * 2; i += 2) {
        m_Combs[i].bindSharedInputBuffer(m_CombInputRingL, m_nActiveCombRingSize, m_pCombRingWriteL);
        m_Combs[i + 1].bindSharedInputBuffer(m_CombInputRingR, m_nActiveCombRingSize, m_pCombRingWriteR);
    }

    m_ResamplerInL.Reset();
    m_ResamplerInR.Reset();
    m_ResamplerOutL.Reset();
    m_ResamplerOutR.Reset();
    m_PreDelayL.Reset();
    m_PreDelayR.Reset();

    for (int i = 0; i < kMaxCombsPerChannel * 2; ++i) {
        m_Combs[i].Reset();
    }
    for (int i = 0; i < kMaxAllpassesPerChannel * 2; ++i) {
        m_Allpasses[i].Reset();
    }

    m_Pattern.Reset();
    m_ModDelay1.Reset();
    m_ModDelay2.Reset();
    m_PostEqHiCutL.Reset();
    m_PostEqLoCutL.Reset();
    m_PostEqHiCutR.Reset();
    m_PostEqLoCutR.Reset();

    m_fPreEmphasisStateL = static_cast<T>(0);
    m_fPreEmphasisStateR = static_cast<T>(0);

    CalcParams(3);
}

template <typename T>
void CReverb<T>::suspend() {
    ResetBuffer();
}

// ============================================================================
                                                                            
// ============================================================================
template <typename T>
void CReverb<T>::DoReverb(float** inputs, float** outputs, long sampleFrames, bool replacing) {
    if (!inputs || !outputs || sampleFrames <= 0) return;
    if (sampleFrames > m_nHostBlockSize) {
        for (long start = 0; start < sampleFrames; start += m_nHostBlockSize) {
            const long n = std::min(m_nHostBlockSize, sampleFrames - start);
            float* in[2] = { inputs[0] + start, (inputs[1] ? inputs[1] : inputs[0]) + start };
            float* out[2] = { outputs[0] + start, (outputs[1] ? outputs[1] : outputs[0]) + start };
            DoReverb(in, out, n, replacing);
        }
        return;
    }

    const float* hostInL = inputs[0];
    const float* hostInR = inputs[1] ? inputs[1] : inputs[0];
    float*       hostOutL = outputs[0];
    float*       hostOutR = outputs[1] ? outputs[1] : outputs[0];

                                                 
    const T     wetGain = m_bWetLevelEnable ? static_cast<T>(m_fWetLevel) : static_cast<T>(0);
    const float dryGain = m_bDryLevelEnable ? m_fDryLevel : 0.0f;

                                                                                
    const T gSelf  = static_cast<T>((0.5 * m_fWidthCrossGain + 0.5) * m_fOverallCombGain);
    const T gCross = static_cast<T>(m_fOverallCombGain) - gSelf;

                                                                          
    std::copy_n(hostInL, sampleFrames, m_DryCopyL.data());
    std::copy_n(hostInR, sampleFrames, m_DryCopyR.data());
    if (replacing) {
        std::memset(hostOutL, 0, static_cast<size_t>(sampleFrames) * sizeof(float));
        std::memset(hostOutR, 0, static_cast<size_t>(sampleFrames) * sizeof(float));
    }

    // ------------------------------------------------------------------------
    // Stage 1: Input Resampling (Host Rate -> Internal DSP Quality Rate)
                                    
    // ------------------------------------------------------------------------
    long nDspSamples = m_ResamplerInL.DoConvertInput(m_DryCopyL.data(), m_BufInL.data(), sampleFrames);
    m_ResamplerInR.DoConvertInput(m_DryCopyR.data(), m_BufInR.data(), sampleFrames);
    // A short block may produce no DSP sample. The zero-length stages below
    // are no-ops, but output FIFO draining and dry mixing must still run.

                                                            
    for (long i = 0; i < nDspSamples; ++i) {
        m_BufInL[static_cast<size_t>(i)] += static_cast<T>(1e-18);
        m_BufInR[static_cast<size_t>(i)] += static_cast<T>(1e-18);
    }

    // ------------------------------------------------------------------------
                                              
    // ------------------------------------------------------------------------
    m_PreDelayL.DoDelay(m_BufInL.data(), nDspSamples);
    m_PreDelayR.DoDelay(m_BufInR.data(), nDspSamples);

    // ------------------------------------------------------------------------
                                                                             
    //          Note: m_fModulation is always in [0.1, 1.0], so always active!
    // ------------------------------------------------------------------------
    if (m_fModulation > 0.0) {
        m_ModDelay1.DoStereoModDelay(
            m_BufInL.data(), m_BufInR.data(),
            m_BufInL.data(), m_BufInR.data(),
            nDspSamples);
    }

    // ------------------------------------------------------------------------
                                                                                          
    //          Outputs early/diffused signal into (m_BufEarlyL, m_BufEarlyR)
    // ------------------------------------------------------------------------
    m_Pattern.DoPattern(
        m_BufInL.data(), m_BufInR.data(),
        m_BufEarlyL.data(), m_BufEarlyR.data(),
        nDspSamples);

    // ------------------------------------------------------------------------
                                                                                 
    //          UNCONDITIONALLY called in original binary! Even when EchoInt == 0,
    //          provides the 2nd LFO-modulated stereo figure-8 chorus & warm spread!
    // ------------------------------------------------------------------------
    m_ModDelay2.DoStereoModDelay(
        m_BufEarlyL.data(), m_BufEarlyR.data(),
        m_BufLateL.data(), m_BufLateR.data(),
        nDspSamples);

    // ------------------------------------------------------------------------
    // Stage 6: Stereo Width Matrix + High-Frequency Pre-Emphasis Injection
                                                                        
    //          xMixL = gSelf * inL + gCross * inR
    //          y[n]  = 1.5 * xMix[n] - 0.5 * xMix[n-1]
    // ------------------------------------------------------------------------
    T* writeL = m_pCombRingWriteL;
    T* writeR = m_pCombRingWriteR;
    T  prevL  = m_fPreEmphasisStateL;
    T  prevR  = m_fPreEmphasisStateR;
    const int ringSize = m_nActiveCombRingSize;

    for (long i = 0; i < nDspSamples; ++i) {
        T inL = m_BufLateL[static_cast<size_t>(i)];
        T inR = m_BufLateR[static_cast<size_t>(i)];

        T mixL = gSelf * inL + gCross * inR;
        T mixR = gSelf * inR + gCross * inL;

        *writeL = static_cast<T>(1.5) * mixL - static_cast<T>(0.5) * prevL;
        *writeR = static_cast<T>(1.5) * mixR - static_cast<T>(0.5) * prevR;

        prevL = mixL;
        prevR = mixR;

        if (--writeL < m_CombInputRingL) {
            writeL += ringSize;
        }
        if (--writeR < m_CombInputRingR) {
            writeR += ringSize;
        }
    }
    m_fPreEmphasisStateL = prevL;
    m_fPreEmphasisStateR = prevR;
    m_pCombRingWriteL    = writeL;
    m_pCombRingWriteR    = writeR;

    // ------------------------------------------------------------------------
                                                                            
    //          Alternates stereo accumulation every 2 pairs (r13d = 0,1 vs 2,3)
    // ------------------------------------------------------------------------
    std::fill_n(m_BufLateL.data(), nDspSamples, static_cast<T>(0));
    std::fill_n(m_BufLateR.data(), nDspSamples, static_cast<T>(0));

    const int totalCombInstances = m_nCombs * 2;
    int pairToggle = 0;
    for (int c = 0; c < totalCombInstances; c += 2) {
        if (pairToggle <= 1) {
            m_Combs[c].Do3BandComb(m_BufLateL.data(), nDspSamples);
            m_Combs[c + 1].Do3BandComb(m_BufLateR.data(), nDspSamples);
            ++pairToggle;
        } else {
            m_Combs[c].Do3BandComb(m_BufLateR.data(), nDspSamples);
            m_Combs[c + 1].Do3BandComb(m_BufLateL.data(), nDspSamples);
            ++pairToggle;
            if (pairToggle > 3) {
                pairToggle = 0;
            }
        }
    }

    // ------------------------------------------------------------------------
                                                                 
    //          Up to 40 stereo pairs (80 CAllpass<T> instances) in series
    // ------------------------------------------------------------------------
    const int totalAllpassInstances = m_nAllpasses * 2;
    for (int a = 0; a < totalAllpassInstances; a += 2) {
        m_Allpasses[a].DoAllpassReplace(m_BufLateL.data(), nDspSamples);
        m_Allpasses[a + 1].DoAllpassReplace(m_BufLateR.data(), nDspSamples);
    }

    // ------------------------------------------------------------------------
                                                                          
    // ------------------------------------------------------------------------
    const T earlyGain = static_cast<T>(m_fEarlyGain);
    const T lateGain  = static_cast<T>(m_fLateGain);
    for (long i = 0; i < nDspSamples; ++i) {
        size_t idx = static_cast<size_t>(i);
        m_BufLateL[idx] = (m_BufEarlyL[idx] * earlyGain + m_BufLateL[idx] * lateGain) * wetGain;
        m_BufLateR[idx] = (m_BufEarlyR[idx] * earlyGain + m_BufLateR[idx] * lateGain) * wetGain;
    }

    // ------------------------------------------------------------------------
    // Stage 10: Post-EQ 2nd-Order Butterworth High-Cut & Low-Cut Filters
                                     
    // ------------------------------------------------------------------------
    if (m_bHiCutOn) {
        m_PostEqHiCutL.DoBiQuad(m_BufLateL.data(), nDspSamples);
        m_PostEqHiCutR.DoBiQuad(m_BufLateR.data(), nDspSamples);
    }
    if (m_bLoCutOn) {
        m_PostEqLoCutL.DoBiQuad(m_BufLateL.data(), nDspSamples);
        m_PostEqLoCutR.DoBiQuad(m_BufLateR.data(), nDspSamples);
    }

    // ------------------------------------------------------------------------
    // Stage 11: Output Resampling (DSP Rate -> Host Rate) & Dry/Wet Mix
                                     
    // ------------------------------------------------------------------------
    m_ResamplerOutL.DoConvertOutput(m_BufLateL.data(), hostOutL, sampleFrames, nDspSamples, false);
    m_ResamplerOutR.DoConvertOutput(m_BufLateR.data(), hostOutR, sampleFrames, nDspSamples, false);

    for (long i = 0; i < sampleFrames; ++i) {
        size_t idx = static_cast<size_t>(i);
        hostOutL[idx] += m_DryCopyL[idx] * dryGain;
        hostOutR[idx] += m_DryCopyR[idx] * dryGain;
    }
}

// ============================================================================
                      
// ============================================================================
template <typename T>
void CReverb<T>::DoSilence(float** /*inputs*/, float** outputs, long sampleFrames, bool replacing) {
    if (!outputs || sampleFrames <= 0) return;
    if (replacing) {
        std::memset(outputs[0], 0, static_cast<size_t>(sampleFrames) * sizeof(float));
        std::memset(outputs[1], 0, static_cast<size_t>(sampleFrames) * sizeof(float));
    }
}

// ============================================================================
                                                                       
// ============================================================================
template <typename T>
void CReverb<T>::set_DecayInSec(float decaySec) {
                         
    double d = (decaySec < 0.01f) ? 0.01 : static_cast<double>(decaySec);
    m_fDecayInSec = d;
    m_Pattern.set_DecayInSec(static_cast<T>( std::min(1.0, d) ));
    CalcParams(2);
}

template <typename T>
void CReverb<T>::set_DryLevel(float dryLinear) {
              
    m_fDryLevel = dryLinear;
}

template <typename T>
void CReverb<T>::set_WetLevel(float wetLinear) {
              
    m_fWetLevel = wetLinear;
}

template <typename T>
void CReverb<T>::set_Type(int type) {
                         
    int clamped = std::clamp(type, 0, kNumReverbTypes - 1);
    if (clamped == m_nType) return;

    m_Pattern.set_Type(clamped);
    m_nType = clamped;
    suspend();
    for (int m = 0; m < 8; ++m) {
        CalcParams(m);
    }
}

template <typename T>
void CReverb<T>::set_Damping(float lowFreq, float highFreq, float lowRatio, float midRatio, float highRatio) {
                         
    m_fLowRatio  = static_cast<double>(lowRatio);
    m_fMidRatio  = static_cast<double>(midRatio);
    m_fHighRatio = static_cast<double>(highRatio);

    double fLo = static_cast<double>(lowFreq);
    double fHi = static_cast<double>(highFreq);
    if (fLo > fHi) {
        double avg = 0.5 * (fLo + fHi);
        fHi = 1.1 * avg;
        fLo = 0.9 * avg;
    }

    double maxAllowed = 0.48 * m_fDspSampleRate;
    if (fHi > maxAllowed) fHi = maxAllowed;
    if (fLo > maxAllowed) fLo = maxAllowed;
    if (fHi < 5.0) fHi = 5.0;
    if (fLo < 5.0) fLo = 5.0;

    m_fLowCrossoverHz  = fLo;
    m_fHighCrossoverHz = fHi;

                                                                     
    //   c = (1 - |sin(2*pi*f/fs)|) / cos(2*pi*f/fs)
    double wLo = (2.0 * M_PI / m_fDspSampleRate) * fLo;
    double wHi = (2.0 * M_PI / m_fDspSampleRate) * fHi;
    m_fLowCrossoverCoeff  = (1.0 - std::fabs(std::sin(wLo))) / std::cos(wLo);
    m_fHighCrossoverCoeff = (1.0 - std::fabs(std::sin(wHi))) / std::cos(wHi);

    CalcParams(2);
}

template <typename T>
void CReverb<T>::set_RoomSize(float roomSizeNorm) {
                         
    double r = std::clamp(static_cast<double>(roomSizeNorm), 0.0, 0.99);
    m_fRoomSize = r;
    m_Pattern.set_RoomSize(static_cast<T>(r));
    CalcParams(0);
    CalcParams(1);
    CalcParams(2);
    CalcParams(3);
    CalcParams(4);
    CalcParams(7);
}

template <typename T>
void CReverb<T>::set_Attack(float attackNorm) {
                         
    double a = std::clamp(static_cast<double>(attackNorm), 0.0, 1.0);
    m_fAttack = a;
                                                                                            
    m_Pattern.set_DirectFeedGain(static_cast<T>(-(0.5 - 0.5 * a)));
    CalcParams(3);
}

template <typename T>
void CReverb<T>::set_Spread(float spreadNorm) {
                         
    double s = std::clamp(static_cast<double>(spreadNorm), 0.0, 1.0);
    m_fSpread = s;
    m_Pattern.set_Spread(static_cast<T>(s));
    CalcParams(3);
    CalcParams(2);
}

template <typename T>
void CReverb<T>::set_Diffusion(float diffusionNorm) {
                         
    double d = std::clamp(static_cast<double>(diffusionNorm), 0.0, 1.0);
    m_fDiffusion = d;
    CalcParams(0);
    CalcParams(3);
    CalcParams(4);
}

template <typename T>
void CReverb<T>::set_Density(float densityNorm) {
                         
    double d = std::clamp(static_cast<double>(densityNorm), 0.0, 1.0);
    m_fDensity = d;
    CalcParams(0);
    CalcParams(1);
    CalcParams(2);
    CalcParams(3);
    CalcParams(4);
    m_Pattern.set_Density(static_cast<T>(d));
}

template <typename T>
void CReverb<T>::set_Echo(float echoIntensityNorm, float echoSizeMs) {
                         
    double eInt  = std::clamp(static_cast<double>(echoIntensityNorm), 0.0, 1.0);
    double eSize = std::clamp(static_cast<double>(echoSizeMs), 50.0, 750.0);
    m_fEchoIntensity = eInt;

                                                                                                     
    if (eInt == 0.0) {
        eSize = 300.0;
    }
    m_fEchoSizeMs = eSize;

                                                                                                   
    int delayL = static_cast<int>(0.9 * eSize * 0.001 * m_fDspSampleRate);
    int delayR = static_cast<int>(1.1 * eSize * 0.001 * m_fDspSampleRate);
    m_ModDelay2.set_FbDelays(delayL, delayR);
    CalcParams(2);
}

template <typename T>
void CReverb<T>::set_Predelay(float predelayMs) {
                         
    double pMs = std::clamp(static_cast<double>(predelayMs), 0.0, 1000.0);
    m_fPredelayMs = pMs;
    int samples = static_cast<int>(pMs * 0.001 * m_fDspSampleRate);
    m_PreDelayL.set_DelaySamples(samples);
    m_PreDelayR.set_DelaySamples(samples);
}

template <typename T>
void CReverb<T>::set_RoomWidth(float widthNorm) {
                         
    double w = std::clamp(static_cast<double>(widthNorm), 0.0, 1.0);
    m_fRoomWidth = w;

                                                                 
    if (m_fModulation > 0.2) {
        m_fWidthCombCorr  = w;
        m_fWidthCrossGain = std::sqrt(w);
    } else {
        if (w < 0.5) {
            m_fWidthCombCorr  = 0.0;
            m_fWidthCrossGain = std::sqrt(2.0 * w);
        } else {
            m_fWidthCombCorr  = 2.0 * w - 1.0;
            m_fWidthCrossGain = 1.0; // 100% discrete L/R comb injection!
        }
    }

    CalcParams(1);
    CalcParams(2);
    CalcParams(3);
    CalcParams(4);
    m_Pattern.set_RoomWidth(static_cast<T>(w));
}

template <typename T>
void CReverb<T>::set_Modulation(float modNorm) {
                         
    // Maps GUI [0.0 .. 1.0] to internal m_fModulation in [0.1 .. 1.0] (0.9f * mod + 0.1f)!
    float clamped = std::min(1.0f, modNorm);
    float mapped  = (clamped >= 0.0f) ? (clamped * 0.9f + 0.1f) : 0.1f;

    if (m_fModulation == 0.0 && mapped > 0.0f) {
        m_ModDelay1.Reset();
    }
    m_fModulation = static_cast<double>(mapped);
    CalcParams(7);
    set_RoomWidth(static_cast<float>(m_fRoomWidth));
}

template <typename T>
void CReverb<T>::set_PostEQFreq(float loCutHz, float hiCutHz) {
                         
    double maxHi = 0.48 * m_fDspSampleRate;
    double hi = static_cast<double>(hiCutHz);
    if (hi > maxHi) hi = maxHi;
    m_fLoCutHz = hi; // Note: binary stores HiCut at +0x728 and LoCut at +0x730!

    double lo = (loCutHz < 5.0f) ? 5.0 : static_cast<double>(loCutHz);
    m_fHiCutHz = lo;

                                                                                                    
    m_fLoCutHz = lo;
    m_fHiCutHz = hi;
    CalcParams(6);
}

template <typename T>
void CReverb<T>::get_PostEQFreq(float* outLoCutHz, float* outHiCutHz) const {
    if (outLoCutHz) *outLoCutHz = static_cast<float>(m_fLoCutHz);
    if (outHiCutHz) *outHiCutHz = static_cast<float>(m_fHiCutHz);
}

template <typename T>
void CReverb<T>::set_PostEQOnOff(bool loCutOn, bool hiCutOn) {
              
    m_bLoCutOn = loCutOn;
    m_bHiCutOn = hiCutOn;
}

// ============================================================================
// set_Quality — Selects Internal DSP Sample Rate (22050, 44100, or 96000 Hz)
                                     
// ============================================================================
template <typename T>
void CReverb<T>::set_Quality(int quality) {
    int q = std::clamp(quality, 0, 2);
    if (q == m_nQuality) return;

    m_nQuality = q;
    if (m_nQuality == kQuality_Low) {
        m_fDspSampleRate = 22050.0;
    } else if (m_nQuality == kQuality_High) {
        m_fDspSampleRate = 96000.0;
    } else {
        m_fDspSampleRate = 44100.0;
    }

    m_Pattern.set_SampleRate(static_cast<T>(m_fDspSampleRate));
    m_PostEqHiCutL.set_SampleRate(m_fDspSampleRate);
    m_PostEqLoCutL.set_SampleRate(m_fDspSampleRate);
    m_PostEqHiCutR.set_SampleRate(m_fDspSampleRate);
    m_PostEqLoCutR.set_SampleRate(m_fDspSampleRate);

    m_ModDelay1.set_SampleRate(m_fDspSampleRate);
    m_ModDelay2.set_SampleRate(m_fDspSampleRate);

    set_Predelay(static_cast<float>(m_fPredelayMs));

    m_ResamplerInL.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));
    m_ResamplerInR.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));
    m_ResamplerOutL.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));
    m_ResamplerOutR.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));

    AllocateWorkBuffers();
    set_Damping(
        static_cast<float>(m_fLowCrossoverHz),
        static_cast<float>(m_fHighCrossoverHz),
        static_cast<float>(m_fLowRatio),
        static_cast<float>(m_fMidRatio),
        static_cast<float>(m_fHighRatio));
    set_Echo(static_cast<float>(m_fEchoIntensity), static_cast<float>(m_fEchoSizeMs));

    for (int m = 0; m < 8; ++m) {
        CalcParams(m);
    }
    suspend();
}

template <typename T>
void CReverb<T>::set_DryLevelEnable(bool enable) {
    m_bDryLevelEnable = enable;
}

template <typename T>
void CReverb<T>::set_WetLevelEnable(bool enable) {
    m_bWetLevelEnable = enable;
}

template <typename T>
void CReverb<T>::set_SampleRate(float hostSampleRate) {
                         
    m_fHostSampleRate = std::max(8000.0, static_cast<double>(hostSampleRate));
    m_ResamplerInL.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));
    m_ResamplerInR.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));
    m_ResamplerOutL.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));
    m_ResamplerOutR.set_SampleRates(static_cast<T>(m_fHostSampleRate), static_cast<T>(m_fDspSampleRate));
    AllocateWorkBuffers();
    suspend();
}

template <typename T>
void CReverb<T>::set_BlockSize(long hostBlockSize) {
                         
    m_nHostBlockSize = std::max<long>(16, hostBlockSize);
    AllocateWorkBuffers();
}

template <typename T>
void CReverb<T>::get_Reflections(ReflectionStruct* outRefl) const {
                         
    m_Pattern.getReflections(outRefl);
    if (outRefl) {
        float eg = static_cast<float>(m_fEarlyGain);
        for (int i = 0; i < outRefl->numTapsL; ++i) {
            outRefl->gainL[i] *= eg;
        }
        for (int i = 0; i < outRefl->numTapsR; ++i) {
            outRefl->gainR[i] *= eg;
        }
    }
}

// ============================================================================
// CalcParams(int mode) — Exact Master Acoustic Parameter Solver
                                                                 
                                                                                            
                                                                                                      
//                     + Input Chorus CStereoModDelay #1 delay lengths
                                                                                                     
                                                                              
                                                                                                 
                                                                        
                                                                      
                                                                                           
                                                                                       
// ============================================================================
template <typename T>
void CReverb<T>::CalcParams(int mode) {
    const RevTypeParamEntry& rt = c_RevTypeParams[std::clamp(m_nType, 0, kNumReverbTypes - 1)];
    const double room = m_fRoomSize;
    const double dens = m_fDensity;
    const double fs   = m_fDspSampleRate;

    switch (mode) {
    case 0: {
                             
        m_fCombDelayMaxMs    = room * rt.combMaxDelayScale + rt.combMaxDelayOffset;
        m_fCombDelayRatio    = room * rt.combRatioScale    + rt.combRatioOffset;
        m_fAllpassDelayMaxMs = room * rt.apMaxDelayScale   + rt.apMaxDelayOffset;
        m_fTypeGain          = rt.typeGainOffset;

        int nCombs = static_cast<int>(room * 6.0) + static_cast<int>(dens * rt.combCountDensScale) + 4;
        m_nCombs = std::clamp(nCombs, 4, kMaxCombsPerChannel);

        int nAllpasses = static_cast<int>(dens * dens * rt.apCountDensScale);
        m_nAllpasses = std::clamp(nAllpasses, 0, kMaxAllpassesPerChannel);

                                                                                 
        m_fEarlyGain = 0.6 * (1.0 - m_fDiffusion);
        break;
    }

    case 1: {
                                                                                            
        // Note: m_fCombDelayMaxMs (+0x5f0) is the BASE (shortest) comb delay in ms,
        // and m_fCombDelayRatio (+0x5f8) MULTIPLIES it to give the longest comb delay!
        double dStartMs = m_fCombDelayMaxMs * (1.0 + 0.3 * m_fCombDelayRatio * (1.0 - dens));
        double dEndMs   = m_fCombDelayMaxMs * m_fCombDelayRatio;

        double logStart = std::log(std::max(0.1, dStartMs));
        double logEnd   = std::log(std::max(0.2, dEndMs));
        double curveBase = std::max(1.05, rt.combCurveExp);
        double logBase  = std::log(curveBase);

        int nCombs = std::clamp(m_nCombs, 4, kMaxCombsPerChannel);
        int totalCombs = nCombs * 2;

        double expStart = logStart / logBase;
        double expStep  = (logStart - logEnd) / (-2.0 * static_cast<double>(nCombs) * logBase);
        int stereoSplitIdx = static_cast<int>(m_fWidthCombCorr * static_cast<double>(nCombs)) * 2 - 1;

        TVRandom rng(0x22);                                           
        int tempDelays[kMaxCombsPerChannel * 2]{};
        double prevMs = dStartMs;

        for (int idx = 0; idx < totalCombs; ++idx) {
            double exponent = expStart + static_cast<double>(idx) * expStep;
            double dCurMs   = std::pow(curveBase, exponent);
            double deltaMs  = dCurMs - prevMs;
            double r        = rng.nextNorm() - 0.5;
            double jitterMs = dCurMs + r * (2.0 * deltaMs);
            prevMs          = jitterMs;

            int dSamp = static_cast<int>(jitterMs * 0.001 * fs);
            tempDelays[idx] = dSamp;
            if (idx > stereoSplitIdx && (idx + 1) < totalCombs) {
                ++idx;
                tempDelays[idx] = dSamp;
            }
        }

                                                                                            
        int nThird      = nCombs / 3;
        int twoThirds   = 2 * nThird;
        int threeThirds = 3 * nThird;

        for (int p = 0; p < nThird; ++p) {
            m_Combs[2 * p].set_Delay(tempDelays[6 * p + 0]);
            m_Combs[2 * p + 1].set_Delay(tempDelays[6 * p + 1]);
        }
        for (int p = nThird; p < twoThirds; ++p) {
            int k = p - nThird;
            m_Combs[2 * p].set_Delay(tempDelays[6 * k + 3]);
            m_Combs[2 * p + 1].set_Delay(tempDelays[6 * k + 2]);
        }
        for (int p = twoThirds; p < threeThirds; ++p) {
            int k = p - twoThirds;
            m_Combs[2 * p].set_Delay(tempDelays[6 * k + 4]);
            m_Combs[2 * p + 1].set_Delay(tempDelays[6 * k + 5]);
        }
        for (int p = threeThirds; p < nCombs; ++p) {
            int baseIdx = 6 * nThird + 2 * (p - threeThirds);
            m_Combs[2 * p].set_Delay(tempDelays[baseIdx + 1]);
            m_Combs[2 * p + 1].set_Delay(tempDelays[baseIdx + 0]);
        }

                                                                                      
        double roomScale = 0.9 * room + 0.6;
        int mod1DelayL = static_cast<int>(307.0 * roomScale * 0.001 * fs);
        int mod1DelayR = static_cast<int>(229.0 * roomScale * 0.001 * fs);
        m_ModDelay1.set_FbDelays(mod1DelayL, mod1DelayR);
        break;
    }

    case 2: {
                                                                                                        
        double echoSpreadFactor = 0.8 * std::sqrt(m_fEchoIntensity) + 0.04 + 0.1 * m_fSpread;
        double decayComp = 1.0 - 0.9 * echoSpreadFactor * echoSpreadFactor;

        double decayLow  = m_fDecayInSec * m_fLowRatio  * decayComp;
        double decayMid  = m_fDecayInSec * m_fMidRatio  * decayComp;
        double decayHigh = m_fDecayInSec * m_fHighRatio * decayComp;

        double maxCombSec        = std::max(0.001, m_fCombDelayMaxMs * 0.001);
        double invMaxCombSamples = 1.0 / (maxCombSec * fs);
        double threeMaxCombSec   = 3.0 * maxCombSec;

        double gMaxMid  = 1.0 / std::pow(10.0, threeMaxCombSec / std::max(0.01, decayMid));
        double dampMid  = std::pow(gMaxMid, invMaxCombSamples);

        double gMaxLow  = 1.0 / std::pow(10.0, threeMaxCombSec / std::max(0.01, decayLow));
        double dampLow  = (m_fLowRatio > 0.05) ? std::pow(gMaxLow, invMaxCombSamples) : 0.0;

        double gMaxHigh = 1.0 / std::pow(10.0, threeMaxCombSec / std::max(0.01, decayHigh));
        double dampHigh = (m_fHighRatio > 0.05) ? std::pow(gMaxHigh, invMaxCombSamples) : 0.0;

        double cLow  = m_fLowCrossoverCoeff;
        double cHigh = m_fHighCrossoverCoeff;

                                                           
        if (decayLow < 0.08 && decayMid < 0.08 && decayHigh < 0.08) {
            gMaxHigh = 1.0 / std::pow(10.0, threeMaxCombSec / 0.2);
            dampHigh = std::pow(gMaxHigh, invMaxCombSamples);
            cLow     = 0.9981;
        }

        int totalCombs = m_nCombs * 2;
        for (int i = 0; i < totalCombs; ++i) {
            m_Combs[i].set_3BandDamping(cLow, cHigh, dampLow, dampMid, dampHigh);
        }

                                                                                                                     
        m_fCombGainLow  = gMaxLow;
        m_fCombGainMid  = gMaxMid;
        m_fCombGainHigh = gMaxHigh;

        double echoScale2 = std::sqrt(1.3 * echoSpreadFactor);
        double eDecayLow  = std::max(0.01, m_fDecayInSec * m_fLowRatio  * echoScale2);
        double eDecayMid  = std::max(0.01, m_fDecayInSec * m_fMidRatio  * echoScale2);
        double eDecayHigh = std::max(0.01, m_fDecayInSec * m_fHighRatio * echoScale2);

        double eGainHigh = 1.0 / std::pow(10.0, threeMaxCombSec / eDecayHigh);
        double eDampHigh = (m_fHighRatio > 0.05) ? std::pow(eGainHigh, invMaxCombSamples) : 0.0;

        double eGainLow  = 1.0 / std::pow(10.0, threeMaxCombSec / eDecayLow);
        double eDampLow  = (m_fLowRatio > 0.05) ? std::pow(eGainLow, invMaxCombSamples) : 0.0;

        double eGainMid  = 1.0 / std::pow(10.0, threeMaxCombSec / eDecayMid);
        double eDampMid  = std::pow(eGainMid, invMaxCombSamples);

        m_ModDelay2.set_3BandDamping(cLow, cHigh, eDampLow, eDampMid, eDampHigh);

                                                                                                 
        m_fCombGainLow  = 0.5 * (m_fCombGainLow  + eGainLow);
        m_fCombGainMid  = 0.5 * (m_fCombGainMid  + eGainMid);
        m_fCombGainHigh = 0.5 * (m_fCombGainHigh + eGainHigh);

                                                                                     
        double mod1Decay = std::min(1.5, 0.5 * m_fDecayInSec);
        double mod1Gain  = rt.modDelayDecayRatio / std::pow(10.0, threeMaxCombSec / std::max(0.01, mod1Decay));
        double mod1Damp  = (mod1Gain > 0.0) ? std::pow(mod1Gain, invMaxCombSamples) : 0.0;
        m_ModDelay1.set_3BandDamping(0.9, -0.9, mod1Damp, mod1Damp, mod1Damp);
        break;
    }

    case 3: {
                                                                                        
        int nPairs = std::max(1, m_nCombs);
        for (int p = 0; p < nPairs; ++p) {
            double tapF = (static_cast<double>(p) * 20.0 / 44.1) * fs / static_cast<double>(nPairs) * m_fSpread;
            int tapSamples = static_cast<int>(tapF);
            m_Combs[2 * p].set_InputDelay(tapSamples, m_pCombRingWriteL);
            m_Combs[2 * p + 1].set_InputDelay(tapSamples, m_pCombRingWriteR);
        }

        double attack = m_fAttack;
        double logStart = std::log(std::max(0.05, 1.0 - 0.9 * attack));
        double logEnd   = std::log(1.0 + 2.0 * attack);
        double logStep  = (logEnd - logStart) / static_cast<double>(nPairs);
        int roomAttackSamples = static_cast<int>((room * 10.0 / 44.1) * fs);

        for (int p = 0; p < nPairs; ++p) {
            double attEnv = (std::exp(logStart + static_cast<double>(p) * logStep) - 0.5) * attack;
            m_Combs[2 * p].set_AttackParams(attEnv, m_fTypeGain, roomAttackSamples);
            m_Combs[2 * p + 1].set_AttackParams(attEnv, m_fTypeGain, roomAttackSamples);
        }
        break;
    }

    case 4: {
                                                                                                                 
        int nAp = std::clamp(m_nAllpasses, 0, kMaxAllpassesPerChannel);
        if (nAp > 0) {
            double stepMs = (m_fAllpassDelayMaxMs * m_fAllpassDelayRatio - m_fAllpassDelayMaxMs) / static_cast<double>(nAp);
            double curMs  = m_fAllpassDelayMaxMs;

            TVRandom rng(0x22);                                           
            int apDelays[kMaxAllpassesPerChannel]{};

            for (int i = 0; i < nAp; ++i) {
                apDelays[i] = static_cast<int>(curMs * 0.001 * fs);
                double r = rng.nextNorm();
                curMs += stepMs + (r * 0.27 - 0.135);
            }

                                                              
            for (int i = 0; i < nAp; ++i) {
                int j = static_cast<int>(rng.nextNorm() * static_cast<double>(nAp));
                j = std::clamp(j, 0, nAp - 1);
                std::swap(apDelays[i], apDelays[j]);
            }

                                                                                                                       
            for (int p = 0; p < nAp; ++p) {
                int dL = apDelays[p];
                m_Allpasses[2 * p].set_Delay(dL);
                int offsetR = 0;
                if (m_fRoomWidth > 0.9) {
                    offsetR = static_cast<int>(rng.nextNorm() * 100.0);
                }
                m_Allpasses[2 * p + 1].set_Delay(dL + offsetR);
            }
        }
        break;
    }

    case 5: {
                                                                            
        for (int i = 0; i < kMaxAllpassesPerChannel * 2; ++i) {
            m_Allpasses[i].set_Gain(static_cast<T>(-0.5));
        }
        break;
    }

    case 6: {
                                                                                               
        m_PostEqHiCutL.set_TP2(m_fHiCutHz, 2.5);
        m_PostEqHiCutR.set_TP2(m_fHiCutHz, 2.5);
        m_PostEqLoCutL.set_HP2(m_fLoCutHz, 2.5);
        m_PostEqLoCutR.set_HP2(m_fLoCutHz, 2.5);
        break;
    }

    case 7: {
                                                                                                     
        double mod = m_fModulation;
        double modDepth = 0.0;
        double modRate  = 0.0;

        if (mod > 0.0) {
            if (mod <= 0.6) {
                modDepth = 2.0 * mod;
                modRate  = 1.0;
            } else {
                modDepth = 1.2;
                modRate  = (mod - 0.6) * 0.4 + 1.0;
            }
        }

                                                                                   
        m_ModDelay1.set_Rate(0.19 * modRate, 0.23 * modRate);

        double maxExcursion = 0.05 * fs;                  
        double d1R = std::clamp(0.21 * modDepth, 0.0, 1.0);                  
        double d1L = std::clamp(0.18 * modDepth, 0.0, 1.0);                  
        int exc1L  = static_cast<int>(maxExcursion * d1L * d1L);
        int exc1R  = static_cast<int>(maxExcursion * d1R * d1R);
        m_ModDelay1.set_Excursions(exc1L, exc1R);

                                                                                   
        m_ModDelay2.set_Rate(0.45 * modRate, 0.35 * modRate);

        double d2L = std::clamp(0.13 * modDepth, 0.0, 1.0);                  
        double d2R = d1L;                                   // uses [rbp-0x228] = clamp(0.18 * modDepth, 0, 1)
        int exc2L  = static_cast<int>(maxExcursion * d2L * d2L);
        int exc2R  = static_cast<int>(maxExcursion * d2R * d2R);
        m_ModDelay2.set_Excursions(exc2L, exc2R);
        break;
    }

    default:
        break;
    }

    // ------------------------------------------------------------------------
                                            
    // Executed at the end of EVERY CalcParams(0..7) call in the original binary!
    // Computes exact RMS band-energy tail compensation (m_fLateGain) and
    // overall comb bank input scaling (m_fOverallCombGain).
    // ------------------------------------------------------------------------
    double decayFactor = std::exp(-1.3375 * m_fDecayInSec + 1.38629) + 1.0;
    double rmsBand = 0.5 * std::sqrt(
        m_fCombGainLow  * m_fCombGainLow +
        m_fCombGainMid  * m_fCombGainMid +
        m_fCombGainHigh * m_fCombGainHigh);

    if (rmsBand < 1e-6) rmsBand = 1e-6;
    m_fLateGain = std::sqrt(decayFactor / rmsBand);

    double diffTerm       = ((0.3 * m_fDiffusion + 0.7) * 3.5) / (static_cast<double>(m_nCombs) + 10.0);
    double typeTerm       = 1.2 * m_fTypeGain + 1.0;
    double attTerm        = 1.0 - 0.2 * m_fAttack * m_fAttack;
    double echoSpreadTerm = (m_fSpread + 0.2) * 0.8 * m_fEchoIntensity + 0.4 + 0.2 * m_fSpread;
    double roomTerm       = 0.5 * m_fRoomSize + 0.5;

    m_fOverallCombGain = roomTerm * diffTerm * typeTerm * echoSpreadTerm * attTerm * m_fLateGain;
}

// Explicit template instantiations for 32-bit (float) and 64-bit (double) engines
template class CReverb<float>;
template class CReverb<double>;

}                          
