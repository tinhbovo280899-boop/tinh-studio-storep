#pragma once
#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <cmath>
#include <cstring>
#include <cstdio>
#include <string>
#include <algorithm>
#include "TVerbReverbDSP.h"

namespace tverbdsp {

// ============================================================================
                                                                                           
// ============================================================================
enum TVParamID : int {
    kParam_DryLevel       = 0,  // "DryLevel",        dB,  CVstScalingSquare (1.58489e-5 .. 1.99526, def 1.0 = 0.00 dB)
    kParam_WetLevel       = 1,  // "WetLevel",        dB,  CVstScalingSquare (1.58489e-5 .. 1.99526, def 0.25 = -12.0 dB)
    kParam_RevType        = 2,  // "Rev Type",        idx, CVstScalingLinearInteger (0..12, def 0 "smooth")
    kParam_Decay          = 3,  // "Decay",           s,   CVstScalingPow(exp=2.0) (0.2 .. 45.2 s, def 1.8 s)
    kParam_RoomSize       = 4,  // "Room Size",       mtr, CVstScalingPow(exp=2.0) (2.0 .. 62.0 m, def 40.0 m)
    kParam_Diffusion      = 5,  // "Diffusion",       %,   CVstScalingLinear (0 .. 100 %, def 70 %)
    kParam_Density        = 6,  // "Density",         %,   CVstScalingLinear (0 .. 100 %, def 80 %)
    kParam_Attack         = 7,  // "Attack",          %,   CVstScalingLinear (0 .. 100 %, def 0 %)
    kParam_Spread         = 8,  // "Spread",          %,   CVstScalingLinear (0 .. 100 %, def 10 %)
    kParam_Predelay       = 9,  // "Predelay",        ms,  CVstScalingSquare (0 .. 1000 ms, def 0 ms)
    kParam_HiRatio        = 10, // "Hi Ratio",        x,   CVstScaling_DIR_Ratio (0.05 .. 5.0 x, def 0.6 x)
    kParam_MidRatio       = 11, // "Mid Ratio",       x,   CVstScaling_DIR_Ratio (0.05 .. 5.0 x, def 1.0 x)
    kParam_LoRatio        = 12, // "Lo Ratio",        x,   CVstScaling_DIR_Ratio (0.05 .. 5.0 x, def 1.0 x)
    kParam_CrossLoMid     = 13, // "Cross Lo-Mid",    Hz,  CVstScalingSquare (20 .. 5500 Hz, def 800 Hz)
    kParam_CrossMidHi     = 14, // "Cross Mid-Hi",    Hz,  CVstScalingSquare (200 .. 16000 Hz, def 4000 Hz)
    kParam_RoomWidth      = 15, // "Room Width",      deg, CVstScalingLinear (-180 .. 180, def 160)
    kParam_Modulation     = 16, // "Modulation",      %,   CVstScalingLinear (0 .. 100 %, def 10 %)
    kParam_EchoInt        = 17, // "Echo Int",        %,   CVstScalingLinear (0 .. 100 %, def 0 %)
    kParam_EchoSize       = 18, // "Echo Size",       ms,  CVstScalingLinear (50 .. 750 ms, def 400 ms)
    kParam_LoCut          = 19, // "Lo Cut",          Hz,  CVstScalingSquare (20 .. 10000 Hz, def 20 Hz = Off)
    kParam_HiCut          = 20, // "Hi Cut",          Hz,  CVstScalingSquare (200 .. 20000 Hz, def 12000 Hz)
    kParam_Quality        = 21, // "Quality",         idx, CVstScalingLinearInteger (0=lo, 1=normal, 2=ultra, def 1)
    kParam_DryLevelEnable = 22, // "DryLevel Enable", idx, CVstScalingLinearInteger (0..1, def 1)
    kParam_WetLevelEnable = 23, // "WetLevel Enable", idx, CVstScalingLinearInteger (0..1, def 1)
    kParam_BitDepth       = 24, // "BitDepth",        idx, CVstScalingLinearInteger (0=32-bit, 1=64-bit, def 1)
    kNumVstParameters     = 25
};

// ============================================================================
                                                                       
// ============================================================================
struct TVScaling {
    static constexpr float kMinGainLinear = 1.58489319e-5f;                         
    static constexpr float kMaxGainLinear = 1.99526231f;                            

    // 0xe96c: CVstScalingLinear<float>
    static float LinearFromNorm(float norm, float minVal, float maxVal) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return minVal + norm * (maxVal - minVal);
    }
    static float LinearToNorm(float val, float minVal, float maxVal) {
        if (maxVal <= minVal) return 0.0f;
        return std::clamp((val - minVal) / (maxVal - minVal), 0.0f, 1.0f);
    }

    // 0xf1fa: CVstScalingLinearInteger<float>
    static int IntFromNorm(float norm, int minVal, int maxVal) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return static_cast<int>(minVal + norm * static_cast<float>(maxVal - minVal) + 0.5f);
    }
    static float IntToNorm(int val, int minVal, int maxVal) {
        if (maxVal <= minVal) return 0.0f;
        return std::clamp(static_cast<float>(val - minVal) / static_cast<float>(maxVal - minVal), 0.0f, 1.0f);
    }

    // 0xff08: CVstScalingSquare<float>
    static float SquareFromNorm(float norm, float minVal, float maxVal) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return minVal + (norm * norm) * (maxVal - minVal);
    }
    static float SquareToNorm(float val, float minVal, float maxVal) {
        if (maxVal <= minVal) return 0.0f;
        float r = std::clamp((val - minVal) / (maxVal - minVal), 0.0f, 1.0f);
        return std::sqrt(r);
    }

                                                                      
    static float PowFromNorm(float norm, float minVal, float maxVal, float exponent = 2.0f) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return minVal + static_cast<float>(std::pow(static_cast<double>(norm), static_cast<double>(exponent))) * (maxVal - minVal);
    }
    static float PowToNorm(float val, float minVal, float maxVal, float exponent = 2.0f) {
        if (maxVal <= minVal || exponent <= 0.0f) return 0.0f;
        double r = std::clamp(static_cast<double>(val - minVal) / static_cast<double>(maxVal - minVal), 0.0, 1.0);
        return static_cast<float>(std::pow(r, 1.0 / static_cast<double>(exponent)));
    }

                                            
    // Piecewise quadratic curve mapping norm=0.0 -> 0.05, norm=0.5 -> 1.0, norm=1.0 -> 5.0
    static float RatioFromNorm(float norm, float minVal = 0.05f, float maxVal = 5.0f) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        float span  = maxVal - minVal;
        float mid   = 0.5f;
        float midSq = mid * mid;
        float corr  = -(midSq * span + minVal - 1.0f);
        float shape = (norm <= mid) ? (norm * norm) : ((1.0f - norm) * (1.0f - norm));
        float out   = (norm * norm) * span + minVal + (shape * corr) / midSq;
        if (std::fabs(out - 1.0f) < 1e-4f) out = 1.0f;
        return std::clamp(out, minVal, maxVal);
    }

    static float RatioToNorm(float val, float minVal = 0.05f, float maxVal = 5.0f) {
        val = std::clamp(val, minVal, maxVal);
        float span  = maxVal - minVal;
        float mid   = 0.5f;
        float midSq = mid * mid;
        float corr  = -(midSq * span + minVal - 1.0f);
        if (val <= 1.0f) {
            float denom = (span * midSq + corr) / midSq;
            return std::clamp(std::sqrt(std::max(0.0f, (val - minVal) / denom)), 0.0f, 1.0f);
        } else {
            float a = (span * midSq + corr) / midSq;
            float b = (-2.0f * corr) / midSq;
            float c = (corr / midSq) + minVal - val;
            float disc = std::max(0.0f, 0.25f * b * b - a * c);
            return std::clamp((-0.5f * b + std::sqrt(disc)) / a, 0.0f, 1.0f);
        }
    }

    // 0xe292: CVstDisplayLevel<float> (dB <-> linear gain conversion)
    static float DbToLinearGain(float db) {
        if (db <= -95.9f) return 0.0f;
        return std::clamp(std::pow(10.0f, db / 20.0f), 0.0f, kMaxGainLinear);
    }
    static float LinearGainToDb(float lin) {
        if (lin <= kMinGainLinear * 1.01f) return -96.0f;
        return 20.0f * std::log10(lin);
    }
};

// ============================================================================
                                                                               
                                                                                
// ============================================================================
class TVerbPluginWrapper {
public:
    TVerbPluginWrapper(float sampleRate = 44100.0f, long blockSize = 512)
        : m_pReverb(nullptr)
    {
        CReverbBase::CreateAndInit(&m_pReverb, sampleRate, blockSize, kQuality_Normal, kBitDepth_64BitDouble);
        InitDefaultPreset();
        UpdateAllParameters();
    }

    ~TVerbPluginWrapper() {
        delete m_pReverb;
        m_pReverb = nullptr;
    }

                                                                                              
    void InitDefaultPreset() {
        m_NormParams[kParam_DryLevel]       = 0.0f; // -oo dB (0.0 linear gain for Send FX)
        m_NormParams[kParam_WetLevel]       = TVScaling::SquareToNorm(TVScaling::DbToLinearGain(0.84f), TVScaling::kMinGainLinear, TVScaling::kMaxGainLinear); // +0.84 dB
        m_NormParams[kParam_RevType]        = TVScaling::IntToNorm(0,          0,     12);      // "smooth"
        m_NormParams[kParam_Decay]          = TVScaling::PowToNorm(3.506f,     0.2f,  45.2f, 2.0f);
        m_NormParams[kParam_RoomSize]       = TVScaling::PowToNorm(40.0f,      2.0f,  62.0f, 2.0f);
        m_NormParams[kParam_Diffusion]      = TVScaling::LinearToNorm(70.0f,   0.0f,  100.0f);
        m_NormParams[kParam_Density]        = TVScaling::LinearToNorm(80.0f,   0.0f,  100.0f);
        m_NormParams[kParam_Attack]         = TVScaling::LinearToNorm(7.0f,    0.0f,  100.0f);
        m_NormParams[kParam_Spread]         = TVScaling::LinearToNorm(10.0f,   0.0f,  100.0f);
        m_NormParams[kParam_Predelay]       = TVScaling::SquareToNorm(70.0f,   0.0f,  1000.0f);
        m_NormParams[kParam_HiRatio]        = TVScaling::RatioToNorm(0.6f,     0.05f, 5.0f);
        m_NormParams[kParam_MidRatio]       = TVScaling::RatioToNorm(1.0f,     0.05f, 5.0f);
        m_NormParams[kParam_LoRatio]        = TVScaling::RatioToNorm(1.0f,     0.05f, 5.0f);
        m_NormParams[kParam_CrossLoMid]     = TVScaling::SquareToNorm(800.0f,  20.0f, 5500.0f);
        m_NormParams[kParam_CrossMidHi]     = TVScaling::SquareToNorm(4000.0f, 200.0f, 16000.0f);
        m_NormParams[kParam_RoomWidth]      = TVScaling::LinearToNorm(160.0f,  -180.0f, 180.0f);
        m_NormParams[kParam_Modulation]     = TVScaling::LinearToNorm(10.0f,   0.0f,  100.0f);
        m_NormParams[kParam_EchoInt]        = TVScaling::LinearToNorm(0.0f,    0.0f,  100.0f);
        m_NormParams[kParam_EchoSize]       = TVScaling::LinearToNorm(400.0f,  50.0f, 750.0f);
        m_NormParams[kParam_LoCut]          = TVScaling::SquareToNorm(120.0f,  20.0f, 10000.0f);
        m_NormParams[kParam_HiCut]          = TVScaling::SquareToNorm(9819.0f, 200.0f, 20000.0f);
        m_NormParams[kParam_Quality]        = TVScaling::IntToNorm(1,          0,     2);
        m_NormParams[kParam_DryLevelEnable] = 1.0f;
        m_NormParams[kParam_WetLevelEnable] = 1.0f;
        m_NormParams[kParam_BitDepth]       = 1.0f; // Locked to 64-bit double precision
    }

    float getParameter(int index) const {
        if (index < 0 || index >= kNumVstParameters) return 0.0f;
        return m_NormParams[index];
    }

                                               
    // Enforces minimum 1.05x separation between Cross Lo-Mid and Cross Mid-Hi
    void HandleCrossDamping(int changedParam) {
        float fLo = TVScaling::SquareFromNorm(m_NormParams[kParam_CrossLoMid], 20.0f,  5500.0f);
        float fHi = TVScaling::SquareFromNorm(m_NormParams[kParam_CrossMidHi], 200.0f, 16000.0f);
        if (changedParam == kParam_CrossLoMid) {
            if (fLo * 1.05f > fHi) {
                fHi = std::clamp(fLo * 1.05f, 200.0f, 16000.0f);
                m_NormParams[kParam_CrossMidHi] = TVScaling::SquareToNorm(fHi, 200.0f, 16000.0f);
            }
        } else if (changedParam == kParam_CrossMidHi) {
            if (fLo * 1.05f > fHi) {
                fLo = std::clamp(fHi / 1.05f, 20.0f, 5500.0f);
                m_NormParams[kParam_CrossLoMid] = TVScaling::SquareToNorm(fLo, 20.0f, 5500.0f);
            }
        }
    }

                                                                   
    void setParameter(int index, float normValue) {
        if (index < 0 || index >= kNumVstParameters || !m_pReverb) return;
        normValue = std::clamp(normValue, 0.0f, 1.0f);
        m_NormParams[index] = normValue;

        if (index == kParam_CrossLoMid || index == kParam_CrossMidHi) {
            HandleCrossDamping(index);
        }

        switch (index) {
        case kParam_DryLevel: {
            float v = TVScaling::SquareFromNorm(normValue, TVScaling::kMinGainLinear, TVScaling::kMaxGainLinear);
            m_pReverb->set_DryLevel(v <= TVScaling::kMinGainLinear * 1.01f ? 0.0f : v);
            break;
        }
        case kParam_WetLevel: {
            float v = TVScaling::SquareFromNorm(normValue, TVScaling::kMinGainLinear, TVScaling::kMaxGainLinear);
            m_pReverb->set_WetLevel(v <= TVScaling::kMinGainLinear * 1.01f ? 0.0f : v);
            break;
        }
        case kParam_RevType:
            m_pReverb->set_Type(TVScaling::IntFromNorm(normValue, 0, 12));
            break;
        case kParam_Decay:
            m_pReverb->set_DecayInSec(TVScaling::PowFromNorm(normValue, 0.2f, 45.2f, 2.0f));
            break;
        case kParam_RoomSize:
            m_pReverb->set_RoomSize(normValue);
            break;
        case kParam_Diffusion:
            m_pReverb->set_Diffusion(normValue);
            break;
        case kParam_Density:
            m_pReverb->set_Density(normValue);
            break;
        case kParam_Attack:
            m_pReverb->set_Attack(normValue);
            break;
        case kParam_Spread:
            m_pReverb->set_Spread(normValue);
            break;
        case kParam_Predelay:
            m_pReverb->set_Predelay(TVScaling::SquareFromNorm(normValue, 0.0f, 1000.0f));
            break;
        case kParam_HiRatio:
        case kParam_MidRatio:
        case kParam_LoRatio:
        case kParam_CrossLoMid:
        case kParam_CrossMidHi: {
            float fLo  = TVScaling::SquareFromNorm(m_NormParams[kParam_CrossLoMid], 20.0f,  5500.0f);
            float fHi  = TVScaling::SquareFromNorm(m_NormParams[kParam_CrossMidHi], 200.0f, 16000.0f);
            float rLo  = TVScaling::RatioFromNorm(m_NormParams[kParam_LoRatio]);
            float rMid = TVScaling::RatioFromNorm(m_NormParams[kParam_MidRatio]);
            float rHi  = TVScaling::RatioFromNorm(m_NormParams[kParam_HiRatio]);
            m_pReverb->set_Damping(fLo, fHi, rLo, rMid, rHi);
            break;
        }
        case kParam_RoomWidth:
            m_pReverb->set_RoomWidth(normValue);
            break;
        case kParam_Modulation:
            m_pReverb->set_Modulation(TVScaling::LinearFromNorm(normValue, 0.0f, 100.0f) / 100.0f);
            break;
        case kParam_EchoInt:
        case kParam_EchoSize: {
            float eInt  = m_NormParams[kParam_EchoInt];
            float eSize = TVScaling::LinearFromNorm(m_NormParams[kParam_EchoSize], 50.0f, 750.0f);
            m_pReverb->set_Echo(eInt, eSize);
            break;
        }
        case kParam_LoCut:
        case kParam_HiCut: {
            float loHz = TVScaling::SquareFromNorm(m_NormParams[kParam_LoCut], 20.0f,  10000.0f);
            float hiHz = TVScaling::SquareFromNorm(m_NormParams[kParam_HiCut], 200.0f, 20000.0f);
            bool loOn  = (loHz > 21.0f);
            bool hiOn  = (hiHz < 19999.0f);
            m_pReverb->set_PostEQOnOff(loOn, hiOn);
            m_pReverb->set_PostEQFreq(loHz, hiHz);
            break;
        }
        case kParam_Quality:
            m_pReverb->set_Quality(TVScaling::IntFromNorm(normValue, 0, 2));
            // Restore requested frequencies after a previous quality setting
            // clamped them to its lower Nyquist limit.
            setParameter(kParam_HiRatio, m_NormParams[kParam_HiRatio]);
            setParameter(kParam_LoCut, m_NormParams[kParam_LoCut]);
            break;
        case kParam_DryLevelEnable:
            m_pReverb->set_DryLevelEnable(normValue >= 0.5f);
            break;
        case kParam_WetLevelEnable:
            m_pReverb->set_WetLevelEnable(normValue >= 0.5f);
            break;
        case kParam_BitDepth: {
            m_NormParams[kParam_BitDepth] = 1.0f;
            if (CReverbBase::ChangeBitDepth(&m_pReverb, kBitDepth_64BitDouble)) {
                UpdateAllParameters();
            }
            break;
        }
        default:
            break;
        }
    }

    void UpdateAllParameters() {
        for (int i = 0; i < kParam_BitDepth; ++i) {
            setParameter(i, m_NormParams[i]);
        }
    }

    void setSampleRateAndBlockSize(float sampleRate, long blockSize) {
        if (!m_pReverb) return;
        m_pReverb->set_SampleRate(sampleRate);
        m_pReverb->set_BlockSize(blockSize);
        m_pReverb->suspend();
        UpdateAllParameters();
    }

    void suspend() {
        if (m_pReverb) m_pReverb->suspend();
    }

    void processReplacing(float** inputs, float** outputs, int sampleFrames) {
        if (m_pReverb) {
            m_pReverb->DoReverb(inputs, outputs, sampleFrames, true);
        }
    }

    void processAccumulating(float** inputs, float** outputs, int sampleFrames) {
        if (m_pReverb) {
            m_pReverb->DoReverb(inputs, outputs, sampleFrames, false);
        }
    }

    CReverbBase* getReverbEngine() const { return m_pReverb; }

private:
    CReverbBase* m_pReverb;
    float        m_NormParams[kNumVstParameters]{};
};

}                          
