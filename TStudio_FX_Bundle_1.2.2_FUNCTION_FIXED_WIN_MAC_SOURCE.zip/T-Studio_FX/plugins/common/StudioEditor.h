#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_dsp/juce_dsp.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include <array>
#include <cmath>
#include <functional>
#include <map>
#include <set>
#include <vector>
#include "TStudioFonts.h"
#include "licensing/PluginLicense.h"
#include "licensing/LicensePanel.h"

// T Studio "Gold" vector interface shared by T-Verb, T-RVerb, T-PANTHEON and
// T-LIQUID DELAY. No audio processing happens here. The UI is drawn on a fixed
// 1100 x 720 canvas and scaled as one piece, so it keeps its proportions.
namespace tstudio_ui
{
// ---------------------------------------------------------------- palette
inline juce::Colour bg()        { return juce::Colour(0xff0d1016); }
inline juce::Colour panel()     { return juce::Colour(0xff151922); }
inline juce::Colour panelHi()   { return juce::Colour(0xff1b202a); }
inline juce::Colour edge()      { return juce::Colour(0xff2a303b); }
inline juce::Colour well()      { return juce::Colour(0xff090b0f); }
inline juce::Colour ink()       { return juce::Colour(0xfff2eee6); }
inline juce::Colour dim()       { return juce::Colour(0xff8c94a1); }
inline juce::Colour gold()      { return juce::Colour(0xffe2bf7e); }
inline juce::Colour goldLight() { return juce::Colour(0xfff8e2ae); }
inline juce::Colour goldDeep()  { return juce::Colour(0xffa97a3c); }
inline juce::Colour hot()       { return juce::Colour(0xffe8826b); }

inline juce::String vn(const char* s) { return juce::String::fromUTF8(s); }
inline juce::String sep() { return vn("  \xc2\xb7  "); }

// ---------------------------------------------------------------- embedded Inter (same as the compressors)
inline juce::Typeface::Ptr loadFace(const char* data,int size) { return juce::Typeface::createSystemTypefaceFor(data,(size_t)size); }
inline juce::Typeface::Ptr faceSemi()  { static auto& f=*new juce::Typeface::Ptr(loadFace(TStudioFonts::InterSemiBold_otf, TStudioFonts::InterSemiBold_otfSize)); return f; }
inline juce::Typeface::Ptr faceBold()  { static auto& f=*new juce::Typeface::Ptr(loadFace(TStudioFonts::InterBold_otf,     TStudioFonts::InterBold_otfSize)); return f; }
inline juce::Typeface::Ptr faceHeavy() { static auto& f=*new juce::Typeface::Ptr(loadFace(TStudioFonts::InterExtraBold_otf,TStudioFonts::InterExtraBold_otfSize)); return f; }

inline juce::Font font(float size, bool bold=false, float kerning=0.f)
{
    auto face=bold ? (size>=24.f ? faceHeavy() : faceBold()) : faceSemi();
    return juce::Font(juce::FontOptions(face).withHeight(size)).withExtraKerningFactor(kerning);
}
inline void text(juce::Graphics& g, const juce::String& s, juce::Rectangle<float> r,
                 float size, juce::Colour colour, int alignment=juce::Justification::centredLeft,
                 bool bold=false, float kerning=0.f)
{ g.setColour(colour); g.setFont(font(size,bold,kerning)); g.drawText(s,r,alignment,true); }
inline void caps(juce::Graphics& g, const juce::String& s, juce::Rectangle<float> r, juce::Colour c,
                 int alignment=juce::Justification::centredLeft, float size=10.5f)
{ text(g,s.toUpperCase(),r,size,c,alignment,true,.16f); }

inline double engineeringValue(const juce::String& value,const juce::String& unit)
{
    double v=value.getDoubleValue();
    const auto t=value.trim().toLowerCase();
    if(unit=="Hz" && t.endsWith("khz"))return v*1000;
    if(unit=="ms" && t.endsWith("s") && !t.endsWith("ms"))return v*1000;
    if(unit=="s" && t.endsWith("ms"))return v*.001;
    return v;
}

// ---------------------------------------------------------------- per-plugin description
struct Group { juce::String name, description; juce::StringArray ids; };
enum class Screen { reverb, delay };
enum class EqModel { none, threeBand, shelves, chamber };
struct Spec
{
    juce::String name, subtitle, number, legacyExtension, decayID="decay";
    juce::Colour accent;                 // kept for compatibility; the gold theme is shared
    bool delay=false, stereoMeter=true;
    juce::StringArray legacyNames;
    std::vector<Group> groups;
    std::map<juce::String,juce::String> labels, units;
    juce::String heroLeft, heroRight;    // the two large knobs
    juce::String tag="FX", engine;       // display captions
    Screen screen=Screen::reverb;
    juce::String preDelayID, densityID;  // decay display
    EqModel eq=EqModel::none;            // damping / EQ display
};

inline bool matchesPresetPlugin(const Spec& spec,const juce::String& stored,const juce::String& current)
{ return stored==current || spec.legacyNames.contains(stored); }

// ---------------------------------------------------------------- drawing helpers
inline void drawGlowDot(juce::Graphics& g, juce::Point<float> p, float r, juce::Colour c)
{
    juce::ColourGradient glow(c.withAlpha(.55f),p.x,p.y,c.withAlpha(0.f),p.x+r*3.2f,p.y,true);
    g.setGradientFill(glow); g.fillEllipse(p.x-r*3.2f,p.y-r*3.2f,r*6.4f,r*6.4f);
    juce::ColourGradient core(goldLight().interpolatedWith(juce::Colours::white,.5f),p.x-r*.3f,p.y-r*.3f,c,p.x+r,p.y+r,true);
    g.setGradientFill(core); g.fillEllipse(p.x-r,p.y-r,r*2,r*2);
}

inline void drawKnob(juce::Graphics& g, juce::Rectangle<float> area, float pos, float start, float end, bool hero)
{
    const auto c=area.getCentre();
    const float outer=juce::jmin(area.getWidth(),area.getHeight())*.5f;
    const float ringR=outer-(hero?14.f:7.f);
    const float ringW=hero?11.f:6.f;
    const float angle=start+pos*(end-start);
    auto polar=[&](float r,float a){return c+juce::Point<float>(std::sin(a)*r,-std::cos(a)*r);};

    const int ticks=hero?40:16;
    for(int i=0;i<=ticks;++i)
    {
        const float t=start+float(i)/ticks*(end-start);
        const bool major=(i%(ticks/4))==0;
        const float r0=outer-(hero?(major?9.f:6.f):3.5f), r1=outer-(hero?1.f:.5f);
        const bool lit=float(i)/ticks<=pos+1e-4f;
        g.setColour(lit ? gold().withAlpha(major?.95f:.75f) : dim().withAlpha(major?.55f:.3f));
        auto a=polar(r0,t),b=polar(r1,t);
        g.drawLine(a.x,a.y,b.x,b.y,major&&hero?1.6f:1.1f);
    }
    juce::Path track; track.addCentredArc(c.x,c.y,ringR,ringR,0,start,end,true);
    g.setColour(well()); g.strokePath(track,juce::PathStrokeType(ringW,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));
    if(pos>0.002f)
    {
        juce::Path arc; arc.addCentredArc(c.x,c.y,ringR,ringR,0,start,angle,true);
        juce::ColourGradient grad(goldDeep(),c.x-ringR,c.y+ringR,goldLight(),c.x+ringR,c.y-ringR,false);
        g.setGradientFill(grad);
        g.strokePath(arc,juce::PathStrokeType(ringW*.78f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));
    }
    const float bodyR=ringR-ringW*.5f-(hero?7.f:4.f);
    juce::Rectangle<float> body(c.x-bodyR,c.y-bodyR,bodyR*2,bodyR*2);
    g.setColour(juce::Colours::black.withAlpha(.55f));
    g.fillEllipse(body.translated(0,hero?6.f:3.f).expanded(hero?3.f:1.5f));
    {
        juce::ColourGradient shell(juce::Colour(0xff3a404b),c.x,c.y-bodyR,juce::Colour(0xff0f1217),c.x,c.y+bodyR,false);
        g.setGradientFill(shell); g.fillEllipse(body);
    }
    const auto cap=body.reduced(bodyR*(hero?.13f:.12f));
    {
        juce::ColourGradient face(juce::Colour(0xff2a2f38),cap.getX()+cap.getWidth()*.3f,cap.getY()+cap.getHeight()*.25f,
                                  juce::Colour(0xff15181e),cap.getRight(),cap.getBottom(),true);
        g.setGradientFill(face); g.fillEllipse(cap);
    }
    if(hero)
        for(float r=cap.getWidth()*.5f-4;r>8;r-=3.2f)
        { g.setColour(juce::Colours::white.withAlpha(.022f)); g.drawEllipse(c.x-r,c.y-r,r*2,r*2,.8f); }
    g.setColour(juce::Colours::white.withAlpha(.07f)); g.drawEllipse(cap,1.f);
    g.setColour(juce::Colours::black.withAlpha(.6f)); g.drawEllipse(body,1.2f);
    drawGlowDot(g,polar(cap.getWidth()*.5f*(hero?.68f:.6f),angle),hero?5.5f:3.2f,gold());
}

// ---------------------------------------------------------------- look & feel
class Look final : public juce::LookAndFeel_V4
{
public:
    explicit Look(juce::Colour)
    {
        setColour(juce::ComboBox::backgroundColourId,well());
        setColour(juce::ComboBox::textColourId,ink());
        setColour(juce::ComboBox::outlineColourId,edge());
        setColour(juce::PopupMenu::backgroundColourId,juce::Colour(0xff161a22));
        setColour(juce::PopupMenu::textColourId,ink());
        setColour(juce::PopupMenu::highlightedBackgroundColourId,gold().withAlpha(.18f));
        setColour(juce::PopupMenu::highlightedTextColourId,goldLight());
        setColour(juce::Label::textColourId,ink());
        setColour(juce::Label::textWhenEditingColourId,ink());
        setColour(juce::Label::backgroundWhenEditingColourId,well());
        setColour(juce::Label::outlineWhenEditingColourId,gold().withAlpha(.6f));
        setColour(juce::TextEditor::highlightColourId,gold().withAlpha(.3f));
        setColour(juce::TextEditor::outlineColourId,edge());
        setColour(juce::TextEditor::focusedOutlineColourId,gold().withAlpha(.6f));
        setColour(juce::CaretComponent::caretColourId,gold());
        setColour(juce::TooltipWindow::backgroundColourId,juce::Colour(0xff161a22));
        setColour(juce::TooltipWindow::textColourId,ink());
        setColour(juce::TooltipWindow::outlineColourId,edge());
        setColour(juce::ScrollBar::thumbColourId,gold().withAlpha(.35f));
        setColour(juce::AlertWindow::backgroundColourId,panel());
        setColour(juce::AlertWindow::textColourId,ink());
    }
    juce::Typeface::Ptr getTypefaceForFont(const juce::Font& f) override
    { return f.isBold() ? faceBold() : faceSemi(); }
    juce::Font getComboBoxFont(juce::ComboBox&) override { return font(14,true); }
    juce::Font getPopupMenuFont() override { return font(14); }
    juce::Font getLabelFont(juce::Label& l) override { return font(l.getFont().getHeight(),true); }
    juce::Font getTextButtonFont(juce::TextButton&,int) override { return font(13,true,.06f); }
    void drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float start,float end,juce::Slider& s) override
    { drawKnob(g,juce::Rectangle<float>(float(x),float(y),float(w),float(h)),pos,start,end,(bool)s.getProperties()["hero"]); }

    void drawButtonBackground(juce::Graphics& g,juce::Button& b,const juce::Colour& base,bool over,bool down) override
    {
        const auto style=b.getProperties()["style"].toString();
        auto r=b.getLocalBounds().toFloat();
        const bool on=b.getToggleState();
        if(style.isEmpty()) // plain buttons (license panel): dark pill with gold text
        {
            r=r.reduced(1);
            g.setColour(over && b.isEnabled() ? panelHi().brighter(.1f) : panelHi()); g.fillRoundedRectangle(r,8);
            g.setColour(b.isEnabled()?gold().withAlpha(.45f):edge()); g.drawRoundedRectangle(r.reduced(.5f),8,1);
            juce::ignoreUnused(base,down); return;
        }
        if(style=="power")
        {
            r=r.reduced(2);
            g.setColour(juce::Colours::black.withAlpha(.5f)); g.fillEllipse(r.translated(0,3));
            if(!on) { juce::ColourGradient f(goldLight(),r.getX(),r.getY(),goldDeep(),r.getRight(),r.getBottom(),false); g.setGradientFill(f); }
            else      g.setColour(panelHi());
            g.fillEllipse(r);
            g.setColour(on?edge():goldLight().withAlpha(.6f)); g.drawEllipse(r.reduced(.5f),1);
            if(over && !down){g.setColour(juce::Colours::white.withAlpha(.06f));g.fillEllipse(r);}
            return;
        }
        if(style=="icon")
        {
            r=r.reduced(2);
            g.setColour(juce::Colours::black.withAlpha(.45f)); g.fillEllipse(r.translated(0,3));
            g.setColour(over?panelHi().brighter(.08f):panelHi()); g.fillEllipse(r);
            g.setColour(edge()); g.drawEllipse(r.reduced(.5f),1);
            return;
        }
        if(style=="arrow")
        {
            if(over){g.setColour(juce::Colours::white.withAlpha(.06f));g.fillRoundedRectangle(r.reduced(2),6);}
            return;
        }
        if(style=="led")
        {
            r=r.reduced(1);
            g.setColour(well()); g.fillRoundedRectangle(r,r.getHeight()*.5f);
            g.setColour(on?gold().withAlpha(.45f):edge()); g.drawRoundedRectangle(r.reduced(.5f),r.getHeight()*.5f,1);
            const auto p=juce::Point<float>(r.getX()+r.getHeight()*.5f+4,r.getCentreY());
            if(on) drawGlowDot(g,p,5.f,gold());
            else { g.setColour(juce::Colour(0xff3a404b)); g.fillEllipse(p.x-5,p.y-5,10,10); }
            return;
        }
        if(on) // segmented / tab / chip buttons: outlined gold when selected
        {
            auto s=r.reduced(style=="chip"?2.f:3.f);
            juce::ColourGradient f(juce::Colour(0xff3a3222),s.getX(),s.getY(),juce::Colour(0xff221e17),s.getX(),s.getBottom(),false);
            g.setGradientFill(f); g.fillRoundedRectangle(s,s.getHeight()*.5f);
            g.setColour(gold().withAlpha(.75f)); g.drawRoundedRectangle(s.reduced(.5f),s.getHeight()*.5f,1.2f);
        }
        else if(over)
        { g.setColour(juce::Colours::white.withAlpha(.04f)); g.fillRoundedRectangle(r.reduced(3),r.getHeight()*.5f); }
    }
    void drawButtonText(juce::Graphics& g,juce::TextButton& b,bool over,bool) override
    {
        const auto style=b.getProperties()["style"].toString();
        auto r=b.getLocalBounds().toFloat();
        if(style.isEmpty())
        { text(g,b.getButtonText(),r,12.f,b.isEnabled()?gold():dim(),juce::Justification::centred,true,.04f); return; }
        if(style=="power")
        {
            const bool bypassed=b.getToggleState();
            const auto c=r.getCentre(); const float rad=r.getWidth()*.2f;
            juce::Path p; p.addCentredArc(c.x,c.y+1,rad,rad,0,.55f,juce::MathConstants<float>::twoPi-.55f,true);
            p.startNewSubPath(c.x,c.y-rad-2); p.lineTo(c.x,c.y+1);
            g.setColour(bypassed?dim():juce::Colour(0xff1a1610));
            g.strokePath(p,juce::PathStrokeType(2.4f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));
            return;
        }
        if(style=="icon") // gear
        {
            const auto c=r.getCentre(); const float ro=r.getWidth()*.2f, ri=ro*.72f;
            juce::Path gearPath;
            auto pt=[&](float a,float rad){return c+juce::Point<float>(std::sin(a)*rad,-std::cos(a)*rad);};
            for(int i=0;i<16;++i)
            {
                const float a0=i*juce::MathConstants<float>::twoPi/16, a1=(i+1)*juce::MathConstants<float>::twoPi/16;
                const float rr=(i%2==0)?ro:ri;
                if(i==0)gearPath.startNewSubPath(pt(a0,rr));else gearPath.lineTo(pt(a0,rr));
                gearPath.lineTo(pt(a1,rr));
            }
            gearPath.closeSubPath();
            const float hole=ro*.42f; gearPath.addEllipse(c.x-hole,c.y-hole,hole*2,hole*2); gearPath.setUsingNonZeroWinding(false);
            g.setColour(over?goldLight():ink()); g.fillPath(gearPath);
            return;
        }
        if(style=="arrow")
        { text(g,b.getButtonText(),r,17,over?goldLight():ink(),juce::Justification::centred,true); return; }
        if(style=="led")
        {
            text(g,b.getButtonText(),r.withTrimmedLeft(r.getHeight()*.5f+22).withTrimmedRight(8),12,
                 b.getToggleState()?gold():dim(),juce::Justification::centredLeft,true,.14f);
            return;
        }
        const float size=style=="chip"?9.5f:12.5f;
        text(g,b.getButtonText().toUpperCase(),r,size,b.getToggleState()?goldLight():dim().brighter(.25f),
             juce::Justification::centred,true,style=="chip"?.14f:.08f);
    }
    void drawComboBox(juce::Graphics& g,int w,int h,bool,int,int,int,int,juce::ComboBox&) override
    {
        auto r=juce::Rectangle<float>(0,0,float(w),float(h)).reduced(.5f);
        g.setColour(well()); g.fillRoundedRectangle(r,h*.5f);
        g.setColour(edge()); g.drawRoundedRectangle(r,h*.5f,1);
        juce::Path arrow; arrow.startNewSubPath(float(w-24),float(h)*.5f-2.5f); arrow.lineTo(float(w-19),float(h)*.5f+2.5f); arrow.lineTo(float(w-14),float(h)*.5f-2.5f);
        g.setColour(gold()); g.strokePath(arrow,juce::PathStrokeType(1.6f,juce::PathStrokeType::curved,juce::PathStrokeType::rounded));
    }
    void positionComboBoxText(juce::ComboBox& box,juce::Label& label) override
    { label.setBounds(14,0,box.getWidth()-40,box.getHeight()); label.setFont(font(14,true)); }
    void drawPopupMenuBackground(juce::Graphics& g,int w,int h) override
    { g.fillAll(juce::Colour(0xff161a22)); g.setColour(edge()); g.drawRect(0,0,w,h); }
    void drawScrollbar(juce::Graphics& g,juce::ScrollBar&,int x,int y,int w,int h,bool vertical,int thumbStart,int thumbSize,bool over,bool) override
    {
        if(!vertical)return;
        g.setColour(gold().withAlpha(over?.5f:.28f));
        g.fillRoundedRectangle(float(x+w/2-2),float(thumbStart+2),4.f,float(thumbSize-4),2.f);
        juce::ignoreUnused(y,h);
    }
};

// ---------------------------------------------------------------- parameter text helpers
struct ParamText
{
    juce::RangedAudioParameter& param; juce::String unit;
    juce::String format(float value) const
    {
        if(unit.isNotEmpty())
        {
            if(unit=="Hz" && value>=1000)return juce::String(value*.001f,2)+" kHz";
            if(unit=="ms" && std::abs(value)>=1000)return juce::String(value*.001f,2)+" s";
            int decimals=std::abs(value)<10 ? 2 : (std::abs(value)<100 ? 1 : 0);
            if(unit=="BPM"||unit=="%"||unit=="m")decimals=std::abs(value)<10?1:(unit=="BPM"?1:0);
            if(unit=="dB" && value<=-95.5f)return "-inf dB";
            return (decimals==0?juce::String(juce::roundToInt(value)):juce::String(value,decimals))+" "+unit;
        }
        return param.getText(param.convertTo0to1(value),24);
    }
    juce::String formatShort(float value) const
    {
        if(unit=="Hz" && value>=1000)return juce::String(value*.001f,1)+"k";
        if(unit=="dB" && value<=-95.5f)return "-inf";
        const float a=std::abs(value);
        if(a>=10||std::abs(value-std::round(value))<.05f)return juce::String(juce::roundToInt(value));
        return juce::String(value,1);
    }
    void apply(const juce::String& typed) const
    {
        float v=unit.isNotEmpty()?float(engineeringValue(typed,unit)):param.convertFrom0to1(param.getValueForText(typed));
        v=param.getNormalisableRange().getRange().clipValue(v);
        param.beginChangeGesture(); param.setValueNotifyingHost(param.convertTo0to1(v)); param.endChangeGesture();
    }
    float current() const { return param.convertFrom0to1(param.getValue()); }
};

inline juce::String titleFor(const Spec& spec,juce::RangedAudioParameter& p)
{ auto it=spec.labels.find(p.paramID); return it==spec.labels.end()?p.getName(80):it->second; }
inline juce::String unitFor(const Spec& spec,juce::RangedAudioParameter& p)
{ auto it=spec.units.find(p.paramID); return it==spec.units.end()?p.getLabel():it->second; }

inline void setupValueLabel(juce::Label& l,float size)
{
    l.setFont(font(size,true)); l.setJustificationType(juce::Justification::centredLeft);
    l.setEditable(true,true,false); l.setColour(juce::Label::textColourId,ink());
    l.setMouseCursor(juce::MouseCursor::IBeamCursor);
}

inline void setupSlider(juce::Slider& s,juce::AudioProcessorValueTreeState& state,juce::RangedAudioParameter& p,
                        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>& att,bool hero)
{
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::NoTextBox,false,0,0);
    s.setVelocityModeParameters(.3,1,0.0,true,juce::ModifierKeys::shiftModifier);
    s.setRotaryParameters(juce::MathConstants<float>::pi*1.25f,juce::MathConstants<float>::pi*2.75f,true);
    s.getProperties().set("hero",hero);
    att=std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(state,p.paramID,s);
    s.setDoubleClickReturnValue(true,p.convertFrom0to1(p.getDefaultValue()));
    s.setMouseDragSensitivity(hero?320:220);
}

// ---------------------------------------------------------------- large knob with scale and value pill
class HeroKnob final : public juce::Component
{
public:
    HeroKnob(juce::AudioProcessorValueTreeState& state,juce::RangedAudioParameter& p,const Spec& spec)
        : param(p),fmt{p,unitFor(spec,p)},title(titleFor(spec,p))
    {
        setupSlider(slider,state,p,attachment,true); addAndMakeVisible(slider);
        setupValueLabel(value,17.f); value.setJustificationType(juce::Justification::centred); addAndMakeVisible(value);
        value.onTextChange=[this]{fmt.apply(value.getText());refresh();};
        slider.setTooltip(title+"  (double-click: default, Shift: fine)");
        value.setTooltip("Click to type a value");
        refresh();
    }
    void refresh(){ if(!value.isBeingEdited())value.setText(fmt.format(fmt.current()),juce::dontSendNotification); }
    void paint(juce::Graphics& g) override
    {
        const float w=float(getWidth());
        caps(g,title,{0,0,w,18},dim().brighter(.15f),juce::Justification::centred,12.f);
        const auto k=slider.getBounds().toFloat(); const auto c=k.getCentre(); const float r=k.getWidth()*.5f+20;
        const auto& rp=slider.getRotaryParameters();
        for(int i=0;i<5;++i)
        {
            const float t=float(i)/4, a=rp.startAngleRadians+t*(rp.endAngleRadians-rp.startAngleRadians);
            auto p=c+juce::Point<float>(std::sin(a)*r,-std::cos(a)*r);
            text(g,fmt.formatShort(param.convertFrom0to1(t)),{p.x-28,p.y-8,56,16},11.f,dim(),juce::Justification::centred,true);
        }
        auto pill=value.getBounds().toFloat().expanded(18,0).withX(w*.5f-74).withWidth(148);
        g.setColour(well()); g.fillRoundedRectangle(pill,pill.getHeight()*.5f);
        g.setColour(edge()); g.drawRoundedRectangle(pill.reduced(.5f),pill.getHeight()*.5f,1);
        drawGlowDot(g,{pill.getX()+20,pill.getCentreY()},3.6f,gold());
    }
    void resized() override
    {
        const int w=getWidth(); const int k=196;
        slider.setBounds((w-k)/2,44,k,k);
        value.setBounds(w/2-50,44+k+28,100,38);
    }
private:
    juce::RangedAudioParameter& param; ParamText fmt; juce::String title;
    juce::Slider slider; juce::Label value;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
};

// ---------------------------------------------------------------- compact control cell
class Control final : public juce::Component
{
public:
    Control(juce::AudioProcessorValueTreeState& state,juce::RangedAudioParameter& p,const Spec& spec)
        : param(p),fmt{p,unitFor(spec,p)},title(titleFor(spec,p))
    {
        id=p.paramID;
        const auto tooltip=title+(fmt.unit.isEmpty()?juce::String():" ("+fmt.unit+")");
        if(p.isBoolean())
        {
            kind=Kind::toggle; led.getProperties().set("style","led"); led.setClickingTogglesState(true);
            addAndMakeVisible(led); buttonAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(state,id,led);
            led.setTooltip(tooltip);
        }
        else if(auto* choice=dynamic_cast<juce::AudioParameterChoice*>(&p))
        {
            bool shortNames=choice->choices.size()<=3;
            for(auto& s:choice->choices)shortNames=shortNames && s.length()<=7;
            if(shortNames)
            {
                kind=Kind::segment;
                for(int i=0;i<choice->choices.size();++i)
                {
                    auto b=std::make_unique<juce::TextButton>(choice->choices[i]);
                    b->getProperties().set("style","seg");
                    b->onClick=[this,i]{segAttachment->setValueAsCompleteGesture(float(i));};
                    b->setTooltip(tooltip); addAndMakeVisible(*b); segments.push_back(std::move(b));
                }
                segAttachment=std::make_unique<juce::ParameterAttachment>(p,[this](float v){
                    for(size_t i=0;i<segments.size();++i)segments[i]->setToggleState(int(i)==juce::roundToInt(v),juce::dontSendNotification);},nullptr);
                segAttachment->sendInitialUpdate();
            }
            else
            {
                kind=Kind::combo; combo.addItemList(choice->choices,1); addAndMakeVisible(combo);
                comboAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(state,id,combo);
                combo.setTooltip(tooltip);
            }
        }
        else
        {
            kind=Kind::knob; setupSlider(slider,state,p,sliderAttachment,false); addAndMakeVisible(slider);
            setupValueLabel(value,16.f); addAndMakeVisible(value);
            value.onTextChange=[this]{fmt.apply(value.getText());refresh();};
            slider.setTooltip(tooltip+"  (double-click: default, Shift: fine)"); value.setTooltip("Click to type a value");
        }
        refresh();
    }
    void refresh()
    {
        if(kind==Kind::toggle)led.setButtonText(led.getToggleState()?"ON":"OFF");
        else if(kind==Kind::knob && !value.isBeingEdited())value.setText(fmt.format(fmt.current()),juce::dontSendNotification);
    }
    void paint(juce::Graphics& g) override
    {
        const float w=float(getWidth());
        if(kind==Kind::knob) caps(g,title,{92,16,w-94,16},dim().brighter(.1f),juce::Justification::centredLeft,10.f);
        else
        {
            caps(g,title,{4,2,w-8,16},dim().brighter(.1f),juce::Justification::centredLeft,10.f);
            if(kind==Kind::segment)
            {
                auto r=juce::Rectangle<float>(0,26,w,40);
                g.setColour(well()); g.fillRoundedRectangle(r,20); g.setColour(edge()); g.drawRoundedRectangle(r.reduced(.5f),20,1);
            }
        }
    }
    void resized() override
    {
        const int w=getWidth();
        slider.setBounds(2,2,80,80);
        value.setBounds(90,36,w-92,28);
        combo.setBounds(0,26,w,40);
        led.setBounds(0,26,juce::jmin(w,150),40);
        if(!segments.empty())
        {
            const int segW=(w-6)/int(segments.size());
            for(size_t i=0;i<segments.size();++i)segments[i]->setBounds(3+int(i)*segW,26,segW,40);
        }
    }
    juce::String getID() const {return id;}
private:
    enum class Kind { knob, toggle, segment, combo };
    juce::RangedAudioParameter& param; ParamText fmt; juce::String title,id; Kind kind=Kind::knob;
    juce::Slider slider; juce::Label value; juce::ComboBox combo; juce::TextButton led;
    std::vector<std::unique_ptr<juce::TextButton>> segments;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> sliderAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> comboAttachment;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> buttonAttachment;
    std::unique_ptr<juce::ParameterAttachment> segAttachment;
};

// ---------------------------------------------------------------- preset selector
class PresetBox final : public juce::Component, public juce::SettableTooltipClient
{
public:
    std::function<void()> onPick;
    juce::String name;
    void paint(juce::Graphics& g) override
    {
        auto r=getLocalBounds().toFloat().reduced(.5f);
        g.setColour(juce::Colour(0xff12161d)); g.fillRoundedRectangle(r,12);
        g.setColour(edge()); g.drawRoundedRectangle(r,12,1);
        caps(g,"Preset",{18,10,120,14},dim(),juce::Justification::centredLeft,9.5f);
        text(g,name,{18,26,r.getWidth()-100,24},15.5f,hover?goldLight():ink(),juce::Justification::centredLeft,true);
    }
    void mouseUp(const juce::MouseEvent& e) override { if(e.x<getWidth()-80 && onPick)onPick(); }
    void mouseEnter(const juce::MouseEvent&) override { hover=true; repaint(); }
    void mouseExit(const juce::MouseEvent&) override { hover=false; repaint(); }
private: bool hover=false;
};

// ---------------------------------------------------------------- centre display maths
namespace display
{
    // Bar fraction of a division name such as "1/8", "1/4D", "1/8T", "2 bars".
    inline double barsFor(const juce::String& choice)
    {
        auto t=choice.toLowerCase().replace("bars","").replace("bar","").trim();
        double mul=1;
        if(t.endsWithChar('t')){mul=2.0/3.0;t=t.dropLastCharacters(1);}
        else if(t.endsWithChar('d')){mul=1.5;t=t.dropLastCharacters(1);}
        double v=t.contains("/") ? t.upToFirstOccurrenceOf("/",false,false).getDoubleValue()/juce::jmax(1.0,t.fromFirstOccurrenceOf("/",false,false).getDoubleValue())
                                 : t.getDoubleValue();
        return juce::jmax(1.0/64,v)*mul;
    }
    inline float niceSpan(float seconds)
    {
        for(float v:{.5f,1.f,2.f,3.f,4.f,5.f,8.f,10.f,15.f,20.f,30.f,45.f,60.f,90.f})if(v>=seconds)return v;
        return 120.f;
    }
    inline juce::String timeLabel(float t)
    {
        if(t>0 && t<1)return juce::String(juce::roundToInt(t*1000))+"ms";
        return juce::String(t,t==std::floor(t)?0:1)+"s";
    }
    inline juce::String freqLabel(float f)
    { return f>=1000 ? juce::String(f/1000.f,f>=10000?0:(std::fmod(f,1000.f)==0?0:2))+"k" : juce::String(juce::roundToInt(f)); }
    inline float smoothStep(float e0,float e1,float x){const float t=juce::jlimit(0.f,1.f,(x-e0)/(e1-e0));return t*t*(3-2*t);}
}

// ---------------------------------------------------------------- editor
class Editor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    static constexpr int baseW=1100, baseH=720;
    using Meters=std::function<std::array<float,2>()>;

    Editor(juce::AudioProcessor& processor,juce::AudioProcessorValueTreeState& parameters,Spec configuration,
           tak::license::PluginLicense& lic,Meters output={})
        : AudioProcessorEditor(processor),proc(processor),state(parameters),spec(std::move(configuration)),
          license(lic),look(spec.accent),meters(std::move(output)),tooltip(this,600)
    {
        setOpaque(true); setLookAndFeel(&look);
        canvas.painter=[this](juce::Graphics& g){paintCanvas(g);};
        canvas.overPainter=[this](juce::Graphics& g){paintNotice(g);};
        addAndMakeVisible(canvas);

        previous.getProperties().set("style","arrow"); next.getProperties().set("style","arrow");
        gear.getProperties().set("style","icon"); power.getProperties().set("style","power");
        for(auto* c:std::initializer_list<juce::Component*>{&presetBox,&previous,&next,&gear,&power,&viewport})canvas.addAndMakeVisible(c);
        viewport.setViewedComponent(&content,false); viewport.setScrollBarsShown(true,false); viewport.setScrollBarThickness(10);

        presetBox.onPick=[this]{showPresetMenu();};
        previous.onClick=[this]{stepPreset(-1);}; next.onClick=[this]{stepPreset(1);};
        gear.onClick=[this]{showSettingsMenu();}; gear.setTooltip(vn("Bản quyền, lưu / mở preset"));
        power.setClickingTogglesState(true); power.setTooltip("Bypass");
        if(state.getParameter("bypass"))
            bypassAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(state,"bypass",power);
        else power.setVisible(false);

        if(spec.screen==Screen::reverb && spec.eq!=EqModel::none)
            for(int i=0;i<2;++i)
            {
                auto& b=i==0?decayChip:eqChip;
                b.setButtonText(i==0?"Decay":"EQ"); b.getProperties().set("style","chip");
                b.onClick=[this,i]{setEqView(i==1);};
                canvas.addAndMakeVisible(b);
            }

        for(auto* id:{&spec.heroLeft,&spec.heroRight})
            if(id->isNotEmpty())
                if(auto* p=state.getParameter(*id))
                { heroes.push_back(std::make_unique<HeroKnob>(state,*p,spec)); canvas.addAndMakeVisible(*heroes.back()); }

        // every host parameter stays reachable: anything not placed goes to a MORE page
        std::set<juce::String> covered{spec.heroLeft,spec.heroRight,"bypass"};
        for(auto& group:spec.groups){juce::StringArray kept;for(auto& id:group.ids)if(!covered.count(id)){kept.add(id);covered.insert(id);}group.ids=kept;}
        Group extra{"MORE","Additional engine controls",{}};
        for(auto* parameter:proc.getParameters())
            if(auto* ranged=dynamic_cast<juce::RangedAudioParameter*>(parameter))
                if(covered.count(ranged->paramID)==0)extra.ids.add(ranged->paramID);
        if(!extra.ids.isEmpty())spec.groups.push_back(extra);
        for(size_t i=0;i<spec.groups.size();++i)
        {
            auto tab=std::make_unique<juce::TextButton>(spec.groups[i].name);
            tab->getProperties().set("style","seg"); tab->setComponentID("page"+juce::String(int(i)));
            tab->onClick=[this,i]{selectGroup(int(i));};
            canvas.addAndMakeVisible(*tab); tabs.push_back(std::move(tab));
        }
        license.ensureAutomaticTrial();
        setResizable(true,true);
        if(auto* c=getConstrainer()){c->setFixedAspectRatio(double(baseW)/baseH);}
        setResizeLimits(baseW*8/10,baseH*8/10,baseW*3/2,baseH*3/2);
        setSize(baseW,baseH);
        layoutCanvas();
        selectGroup(0); syncPreset(); timerCallback(); startTimerHz(30);
    }
    ~Editor() override
    {
        stopTimer(); juce::PopupMenu::dismissAllActiveMenus(); chooser.reset();
        licensePanel.reset(); overlay.reset();
        bypassAttachment.reset(); controls.clear(); heroes.clear(); viewport.setViewedComponent(nullptr,false); setLookAndFeel(nullptr);
    }
    void paint(juce::Graphics& g) override { g.fillAll(bg()); }
    void resized() override
    {
        const auto s=juce::AffineTransform::scale(float(getWidth())/float(baseW));
        canvas.setBounds(0,0,baseW,baseH); canvas.setTransform(s);
        if(overlay!=nullptr){overlay->setBounds(0,0,baseW,baseH);overlay->setTransform(s);}
    }
    // Lets QA tools / screenshots open the license panel.
    void openLicensePanel() { showLicensePanel(); }
protected:
    using Visual=std::function<void(juce::Graphics&,juce::Rectangle<float>,juce::Colour)>;
    void setVisual(Visual v){visual=std::move(v);}           // kept for compatibility (not drawn)
    void setMotionMeter(std::function<float()> m){motion=std::move(m);}
    void setTempoSource(std::function<float()> t){tempo=std::move(t);}   // tempo the delay really uses (host or manual)
private:
    struct Canvas final : juce::Component
    {
        std::function<void(juce::Graphics&)> painter, overPainter;
        void paint(juce::Graphics& g) override {if(painter)painter(g);}
        void paintOverChildren(juce::Graphics& g) override {if(overPainter)overPainter(g);}
    };

    juce::Rectangle<float> mainPanel() const { return {22,104,1056,594}; }
    juce::Rectangle<float> screen() const    { return {290,128,520,262}; }
    juce::Rectangle<float> tabStrip() const  { return {290,412,520,46}; }
    juce::Rectangle<float> plotArea() const  { const auto r=screen(); return {r.getX()+46,r.getY()+42,r.getWidth()-46-62,r.getHeight()-42-62}; }

    void layoutCanvas()
    {
        const int shift=power.isVisible()?0:64;
        presetBox.setBounds(baseW-494+shift,20,330,60);
        previous.setBounds(baseW-244+shift,34,34,32); next.setBounds(baseW-210+shift,34,34,32);
        gear.setBounds(baseW-150+shift,22,58,58); power.setBounds(baseW-86,22,58,58);
        if(heroes.size()>0)heroes[0]->setBounds(34,124,240,330);
        if(heroes.size()>1)heroes[1]->setBounds(826,124,240,330);
        const auto t=tabStrip();
        const int n=int(tabs.size()); const float tw=(t.getWidth()-8)/juce::jmax(1,n);
        for(int i=0;i<n;++i)tabs[size_t(i)]->setBounds(juce::roundToInt(t.getX()+4+i*tw),int(t.getY()),juce::roundToInt(tw),int(t.getHeight()));
        viewport.setBounds(46,482,1012,178);
        const auto s=screen();
        decayChip.setBounds(int(s.getRight())-174,int(s.getY())+10,55,22);
        eqChip.setBounds(int(s.getRight())-119,int(s.getY())+10,55,22);
    }

    // ------------------------------------------------------------ static artwork
    void paintCanvas(juce::Graphics& g)
    {
        const float W=float(baseW);
        { juce::ColourGradient back(juce::Colour(0xff141924),0,0,bg(),0,float(baseH),false); g.setGradientFill(back); g.fillAll(); }
        juce::Rectangle<float> logo(28,22,56,56);
        g.setColour(gold().withAlpha(.18f)); g.fillEllipse(logo.expanded(5));
        { juce::ColourGradient f(goldLight(),logo.getX(),logo.getY(),goldDeep(),logo.getRight(),logo.getBottom(),false); g.setGradientFill(f); g.fillEllipse(logo); }
        {
            juce::Path wave; const auto c=logo.getCentre();
            const float xs[]={-15,-9,-5,-1,3,7,11,15}, ys[]={0,0,-9,10,-13,6,0,0};
            for(int i=0;i<8;++i){auto p=juce::Point<float>(c.x+xs[i],c.y+ys[i]);if(i==0)wave.startNewSubPath(p);else wave.lineTo(p);}
            g.setColour(juce::Colour(0xff1c1710)); g.strokePath(wave,juce::PathStrokeType(2.4f,juce::PathStrokeType::mitered,juce::PathStrokeType::rounded));
        }
        // wordmark: "T" cream, "-" gold, rest cream (same as the compressors)
        {
            const auto f=font(31,true); g.setFont(f);
            auto rest=spec.name.startsWith("T-")?spec.name.substring(2):spec.name;
            float tx=98;
            for(auto [s,col]:{std::pair<juce::String,juce::Colour>{"T",ink()},{"-",gold()},{rest,ink()}})
            { g.setColour(col); g.drawText(s,juce::Rectangle<float>(tx,18,600,38),juce::Justification::centredLeft,false); tx+=juce::GlyphArrangement::getStringWidth(f,s)+.5f; }
        }
        caps(g,statusText,{99,56,560,18},statusColour,juce::Justification::centredLeft,11.f);

        const auto mp=mainPanel();
        g.setColour(juce::Colours::black.withAlpha(.35f)); g.fillRoundedRectangle(mp.translated(0,4),20);
        { juce::ColourGradient f(juce::Colour(0xff181d26),0,mp.getY(),juce::Colour(0xff12161d),0,mp.getBottom(),false); g.setGradientFill(f); g.fillRoundedRectangle(mp,20); }
        g.setColour(edge()); g.drawRoundedRectangle(mp.reduced(.5f),20,1);
        g.setColour(edge().withAlpha(.7f)); g.drawHorizontalLine(470,46,W-46);

        drawScreen(g,screen());
        const auto t=tabStrip();
        g.setColour(well()); g.fillRoundedRectangle(t,t.getHeight()*.5f);
        g.setColour(edge()); g.drawRoundedRectangle(t.reduced(.5f),t.getHeight()*.5f,1);
        if(activeGroup>=0 && activeGroup<int(spec.groups.size()))
        {
            const auto& group=spec.groups[size_t(activeGroup)];
            const float fy=mp.getBottom()-30;
            g.setColour(edge().withAlpha(.6f)); g.drawHorizontalLine(int(fy-8),46,W-46);
            caps(g,group.name,{46,fy,120,18},gold(),juce::Justification::centredLeft,9.5f);
            text(g,group.description,{46+12+group.name.length()*9.f,fy,420,18},11.f,dim(),juce::Justification::centredLeft);
            caps(g,"Double-click reset"+sep()+"Shift fine"+sep()+"Click value to type",{W-460,fy,414,18},dim().withAlpha(.75f),juce::Justification::centredRight,9.f);
        }
    }
    void paintNotice(juce::Graphics& g)
    {
        if(licensed)return;
        g.setColour(juce::Colour(0xff12161d)); g.fillRect(juce::Rectangle<float>(40,656,1020,36));   // hide the footer hints
        const juce::Rectangle<float> strip(300,660,500,28);
        g.setColour(juce::Colours::black.withAlpha(.78f)); g.fillRoundedRectangle(strip,14);
        g.setColour(gold().withAlpha(.6f)); g.drawRoundedRectangle(strip.reduced(.5f),14,1);
        text(g,vn("Chưa kích hoạt · Bấm ⚙ → Bản quyền & Kích hoạt"),strip,12.5f,gold(),juce::Justification::centred,true);
    }

    // ------------------------------------------------------------ centre display
    float plain(const juce::String& id,float fallback) const
    { if(id.isEmpty())return fallback; if(auto* p=state.getRawParameterValue(id))return p->load(); return fallback; }
    bool flag(const juce::String& id) const { return plain(id,0)>.5f; }
    juce::String choiceText(const juce::String& id) const
    {
        if(auto* c=dynamic_cast<juce::AudioParameterChoice*>(state.getParameter(id)))return c->getCurrentChoiceName();
        return {};
    }
    void grid(juce::Graphics& g,juce::Rectangle<float> P,float x) const { g.setColour(gold().withAlpha(.12f)); g.drawVerticalLine(juce::roundToInt(x),P.getY(),P.getBottom()); }
    void hgrid(juce::Graphics& g,juce::Rectangle<float> P,float y) const { g.setColour(gold().withAlpha(.12f)); g.drawHorizontalLine(juce::roundToInt(y),P.getX(),P.getRight()); }

    void drawScreen(juce::Graphics& g,juce::Rectangle<float> r)
    {
        g.saveState();
        juce::Path clip; clip.addRoundedRectangle(r,14); g.reduceClipRegion(clip);
        { juce::ColourGradient f(juce::Colour(0xff3b2d18),r.getCentreX(),r.getBottom()-30,juce::Colour(0xff0d0c0a),r.getX(),r.getY(),true);
          g.setGradientFill(f); g.fillRect(r); }
        const auto P=plotArea();
        if(spec.screen==Screen::delay) drawEchoes(g,r,P);
        else if(eqView) drawEq(g,r,P);
        else drawDecay(g,r,P);
        drawOutMeter(g,P);
        text(g,spec.tag,{r.getX()+20,r.getBottom()-50,200,40},27.f,gold(),juce::Justification::centredLeft,true,.12f);
        caps(g,"T Studio"+sep()+spec.engine,{r.getRight()-300,r.getBottom()-31,284,18},gold().withAlpha(.75f),juce::Justification::centredRight,9.5f);
        if(chipsShown()) // chip track behind the DECAY / EQ buttons
        {
            const juce::Rectangle<float> t(r.getRight()-176,r.getY()+8,114,26);
            g.setColour(well().withAlpha(.85f)); g.fillRoundedRectangle(t,13);
            g.setColour(gold().withAlpha(.3f)); g.drawRoundedRectangle(t.reduced(.5f),13,1);
        }
        g.restoreState();
        g.setColour(gold().withAlpha(.32f)); g.drawRoundedRectangle(r.reduced(.5f),14,1.2f);
    }
    bool chipsShown() const { return spec.screen==Screen::reverb && spec.eq!=EqModel::none; }
    float headlineRight() const { return screen().getRight()-(chipsShown()?186.f:70.f); }

    void drawDecay(juce::Graphics& g,juce::Rectangle<float> r,juce::Rectangle<float> P)
    {
        const float rt=juce::jmax(.05f,plain(spec.decayID,2.f));
        const float preMs=plain(spec.preDelayID,0.f), pre=juce::jmax(0.f,preMs*.001f);
        const float density=juce::jlimit(0.f,100.f,plain(spec.densityID,60.f));
        const float span=display::niceSpan(pre+rt*1.15f);
        auto X=[&](float t){return P.getX()+t/span*P.getWidth();};
        auto Y=[&](float db){return P.getY()+(-db/60.f)*P.getHeight();};
        for(float db:{0.f,-20.f,-40.f,-60.f}){hgrid(g,P,Y(db));text(g,juce::String(int(db)),{P.getX()-40,Y(db)-7,32,14},10.f,dim(),juce::Justification::centredRight,true);}
        for(int i=0;i<=4;++i){const float t=span*i/4;grid(g,P,X(t));text(g,display::timeLabel(t),{X(t)-30,P.getBottom()+6,60,14},10.f,dim(),juce::Justification::centred,true);}
        auto curveDb=[&](float t,int i){const float att=.04f;float db=-60.f*(t-pre)/rt;db-=(1-juce::jmin(1.f,(t-pre)/att))*14.f;
            db+=(std::sin(i*.9f)*.6f+std::sin(i*2.3f)*.35f)*std::exp(-i/60.f);return juce::jlimit(-60.f,0.f,db);};
        juce::Path line,fill; fill.startNewSubPath(X(pre),Y(-60));
        for(int i=0;i<=300;++i){const float t=pre+i/300.f*(span-pre);const auto p=juce::Point<float>(X(t),Y(curveDb(t,i)));
            fill.lineTo(p);if(i==0)line.startNewSubPath(p);else line.lineTo(p);}
        fill.lineTo(X(span),Y(-60)); fill.closeSubPath();
        { juce::ColourGradient f(gold().withAlpha(.42f),0,P.getY(),gold().withAlpha(.02f),0,P.getBottom(),false); g.setGradientFill(f); g.fillPath(fill); }
        g.setColour(gold().withAlpha(.25f)); g.strokePath(line,juce::PathStrokeType(5.f));
        g.setColour(gold()); g.strokePath(line,juce::PathStrokeType(2.f));
        // early reflections
        const int n=int(5+density/14); const float erSpan=juce::jmin(span*.12f,juce::jmax(.04f,rt*.06f));
        juce::Random rnd(7);
        for(int k=0;k<n;++k){const float t=pre+erSpan*(k+.3f+rnd.nextFloat()*.5f)/n;const float h=-3-k*(26.f/n)-rnd.nextFloat()*4;
            g.setColour(goldLight().withAlpha(.9f)); g.drawLine(X(t),Y(-60),X(t),Y(h),1.5f); g.fillEllipse(X(t)-2,Y(h)-2,4,4);}
        if(pre>.003f)
        {
            const float dash[]={3,3}; g.setColour(goldLight().withAlpha(.55f));
            g.drawDashedLine(juce::Line<float>(X(0),P.getY()+10.5f,X(pre),P.getY()+10.5f),dash,2,1.f);
            if(X(pre)-P.getX()>26)caps(g,"pre",{X(pre)-26,P.getY()+13,24,10},goldLight().withAlpha(.7f),juce::Justification::centredRight,7.5f);
        }
        if(pre+rt<span)
        {
            const float dash[]={2,3}; g.setColour(hot());
            g.drawDashedLine(juce::Line<float>(X(pre+rt),Y(-60),X(pre+rt),Y(-45)),dash,2,1.f);
            caps(g,"RT60",{X(pre+rt)+4,Y(-52)-6,50,12},hot(),juce::Justification::centredLeft,8.f);
        }
        caps(g,"Decay"+sep()+"RT60",{r.getX()+16,r.getY()+12,200,16},gold().withAlpha(.85f),juce::Justification::centredLeft,9.5f);
        const auto head=juce::String(rt,2)+" s"+sep()+"PRE "+juce::String(juce::roundToInt(preMs))+" ms";
        text(g,head,{r.getX()+150,r.getY()+10,headlineRight()-(r.getX()+150),20},12.f,goldLight(),juce::Justification::centredRight,true);
    }

    void drawEq(juce::Graphics& g,juce::Rectangle<float> r,juce::Rectangle<float> P)
    {
        auto fx=[&](float f){return P.getX()+std::log(f/20.f)/std::log(1000.f)*P.getWidth();};
        auto Yr=[&](float ratio){return P.getY()+P.getHeight()*(1-std::log(ratio/.1f)/std::log(100.f));};
        auto Ydb=[&](float db){return P.getY()+(12-db)/42.f*P.getHeight();};
        for(float f:{20.f,100.f,1000.f,10000.f,20000.f}){grid(g,P,fx(f));text(g,display::freqLabel(f),{fx(f)-24,P.getBottom()+6,48,14},10.f,dim(),juce::Justification::centred,true);}
        for(float k:{.2f,1.f,5.f}){hgrid(g,P,Yr(k));text(g,juce::String(k,k<1?1:0)+"x",{P.getX()-44,Yr(k)-7,38,14},10.f,dim(),juce::Justification::centredRight,true);}

        // per-model curves: decay-time ratio across frequency, optional EQ response in dB
        std::function<float(float)> ratio; std::function<float(float)> eqDb;
        struct Node{float f,r;juce::String label;}; std::vector<Node> nodes;
        struct Mark{float f;juce::String label;bool cut;}; std::vector<Mark> marks;
        auto sm=[](float lo,float hi,float f){return display::smoothStep(std::log(lo),std::log(hi),std::log(f));};
        if(spec.eq==EqModel::threeBand) // T-Verb
        {
            const float lo=plain("loratio",1),mid=plain("midratio",1),hi=plain("hiratio",1),xlo=plain("crosslo",800),xhi=plain("crosshi",4000);
            const float lc=plain("locut",20),hc=plain("hicut",20000);
            ratio=[=](float f){const float a=display::smoothStep(std::log(xlo/1.6f),std::log(xlo*1.6f),std::log(f)),b=display::smoothStep(std::log(xhi/1.6f),std::log(xhi*1.6f),std::log(f));
                return std::exp(std::log(lo)*(1-a)+std::log(mid)*(a-b)+std::log(hi)*b);};
            eqDb=[=](float f){const float a=f/lc,b=f/hc;const float hp=a*a/std::sqrt(std::pow(1-a*a,2.f)+std::pow(a*1.414f,2.f));
                const float lp=1/std::sqrt(std::pow(1-b*b,2.f)+std::pow(b*1.414f,2.f));return 20*std::log10(juce::jmax(1e-6f,hp*lp));};
            nodes={{xlo/3,lo,"lo"},{std::sqrt(xlo*xhi),mid,"mid"},{xhi*1.9f,hi,"hi"}};
            marks={{xlo,"X "+display::freqLabel(xlo),false},{xhi,"X "+display::freqLabel(xhi),false},{lc,"LO CUT "+display::freqLabel(lc),true},{hc,"HI CUT "+display::freqLabel(hc),true}};
        }
        else if(spec.eq==EqModel::shelves) // T-RVerb
        {
            const float lfc=plain("lfCut",300),lfr=plain("lfRatio",1),hfc=plain("hfCut",4500),hfr=plain("hfRatio",1);
            const float lsf=plain("eqLowFreq",200),lsg=plain("eqLowGain",0),hsf=plain("eqHighFreq",2500),hsg=plain("eqHighGain",0);
            ratio=[=](float f){const float a=sm(lfc/1.6f,lfc*1.6f,f),b=sm(hfc/1.6f,hfc*1.6f,f);return std::exp(std::log(lfr)*(1-a)+std::log(hfr)*b);};
            eqDb=[=](float f){return lsg*(1-sm(lsf/2.f,lsf*2.f,f))+hsg*sm(hsf/2.f,hsf*2.f,f);};
            nodes={{lfc/3,lfr,"lf"},{std::sqrt(lfc*hfc),1.f,"mid"},{juce::jmin(18000.f,hfc*1.9f),hfr,"hf"}};
            marks={{lfc,"LF "+display::freqLabel(lfc),false},{hfc,"HF "+display::freqLabel(hfc),false},
                   {lsf,"LOW SHELF "+juce::String(lsg,1)+" dB",true},{hsf,"HIGH SHELF "+juce::String(hsg,1)+" dB",true}};
        }
        else // T-PANTHEON: bass multiplier below bassFreq, HF damping above `damping`
        {
            const float bb=plain("bassBoost",1),bf=plain("bassFreq",400),damp=plain("damping",4000);
            ratio=[=](float f){const float a=sm(bf/1.6f,bf*1.6f,f);const float hf=1.f/std::sqrt(1+std::pow(f/damp,2.f));return std::exp(std::log(bb)*(1-a))*juce::jmax(.1f,hf);};
            nodes={{bf/3,bb,"bass"},{std::sqrt(bf*damp),1.f,"mid"},{juce::jmin(18000.f,damp*2.2f),juce::jmax(.1f,1.f/std::sqrt(1+4.84f)),"damp"}};
            marks={{bf,"BASS "+display::freqLabel(bf),false},{damp,"DAMPING "+display::freqLabel(damp),true}};
        }
        if(eqDb)
        {
            juce::Path fill,line; fill.startNewSubPath(P.getX(),P.getBottom());
            for(int i=0;i<=300;++i){const float f=20*std::pow(1000.f,i/300.f);const auto p=juce::Point<float>(fx(f),juce::jmin(P.getBottom(),Ydb(juce::jmax(-30.f,eqDb(f)))));
                fill.lineTo(p);if(i==0)line.startNewSubPath(p);else line.lineTo(p);}
            fill.lineTo(P.getRight(),P.getBottom()); fill.closeSubPath();
            juce::ColourGradient f(gold().withAlpha(.20f),0,P.getY(),gold().withAlpha(.02f),0,P.getBottom(),false); g.setGradientFill(f); g.fillPath(fill);
            g.setColour(gold().withAlpha(.55f)); g.strokePath(line,juce::PathStrokeType(1.3f));
        }
        juce::Path rl;
        for(int i=0;i<=300;++i){const float f=20*std::pow(1000.f,i/300.f);const auto p=juce::Point<float>(fx(f),Yr(juce::jlimit(.1f,10.f,ratio(f))));if(i==0)rl.startNewSubPath(p);else rl.lineTo(p);}
        g.setColour(gold().withAlpha(.3f)); g.strokePath(rl,juce::PathStrokeType(6.f));
        g.setColour(goldLight()); g.strokePath(rl,juce::PathStrokeType(2.2f));
        int cutRow=0;
        for(const auto& m:marks)
        {
            const float x=fx(juce::jlimit(20.f,20000.f,m.f)); const float dash[]={2,3};
            if(m.cut){g.setColour(hot());g.drawDashedLine(juce::Line<float>(x,P.getY(),x,P.getBottom()),dash,2,1.f);
                const bool right=x>P.getCentreX();
                text(g,m.label,{right?x-160:x+5,P.getY()+4+14.f*float(cutRow++),155,12},9.5f,hot(),right?juce::Justification::centredRight:juce::Justification::centredLeft,true);}
            else{g.setColour(dim());g.drawDashedLine(juce::Line<float>(x,P.getY()+P.getHeight()*.62f,x,P.getBottom()-16),dash,2,1.f);
                text(g,m.label,{x-40,P.getBottom()-14,80,12},9.5f,dim(),juce::Justification::centred,true);}
        }
        for(const auto& n:nodes)
        {
            const auto p=juce::Point<float>(fx(juce::jlimit(20.f,20000.f,n.f)),Yr(juce::jlimit(.1f,10.f,n.r)));
            drawGlowDot(g,p,4.5f,gold());
            caps(g,n.label,{p.x-30,p.y-30,60,12},gold().withAlpha(.85f),juce::Justification::centred,8.f);
            text(g,juce::String(n.r,2)+"x",{p.x-30,p.y-20,60,14},11.f,goldLight(),juce::Justification::centred,true);
        }
        text(g,vn("━ decay ratio")+(eqDb?vn("   ▮ eq"):juce::String()),{P.getX()+6,P.getBottom()-14,200,12},9.f,goldLight().withAlpha(.85f),juce::Justification::centredLeft,true);
        caps(g,"Damping"+sep()+"EQ",{r.getX()+16,r.getY()+12,200,16},gold().withAlpha(.85f),juce::Justification::centredLeft,9.5f);
    }

    void drawEchoes(juce::Graphics& g,juce::Rectangle<float> r,juce::Rectangle<float> P)
    {
        const bool sync=flag("dlySync");
        const float live=tempo?tempo():0.f;
        const float bpm=juce::jlimit(20.f,500.f,live>0?live:plain("dlyTempo",120));
        const float fb=juce::jlimit(0.f,.99f,plain("dlyFeedback",33)*.01f);
        auto side=[&](bool left){double bars=display::barsFor(choiceText(left?"dlyLXTime":"dlyRXTime"));
            if(flag(left?"dlyLDot":"dlyRDot"))bars*=1.5; if(flag(left?"dlyLTri":"dlyRTri"))bars*=2.0/3.0; return float(bars*4*60/bpm);};
        const float tl=side(true),tr=side(false);
        const float span=juce::jmax(tl,tr)*6.5f;
        auto X=[&](float t){return P.getX()+t/span*P.getWidth();};
        const float mid=P.getCentreY();
        hgrid(g,P,mid); for(int i=0;i<=8;++i)grid(g,P,P.getX()+i/8.f*P.getWidth());
        text(g,"L",{P.getX()-24,P.getY()+2,14,14},10.f,dim(),juce::Justification::centredRight,true);
        text(g,"R",{P.getX()-24,P.getBottom()-16,14,14},10.f,dim(),juce::Justification::centredRight,true);
        for(int i=0;i<=4;++i){const float t=span*i/4;text(g,juce::String(juce::roundToInt(t*1000))+"ms",{P.getX()+i/4.f*P.getWidth()-30,P.getBottom()+6,60,14},10.f,dim(),juce::Justification::centred,true);}
        g.setColour(ink().withAlpha(.75f)); g.fillRoundedRectangle(X(0)-2,P.getY()+6,4,P.getHeight()-12,2);
        auto draw=[&](float T,bool up,bool on)
        {
            float lvl=1;
            for(int k=1;X(T*k)<P.getRight();++k)
            {
                lvl=k==1?1.f:lvl*fb; if(lvl<.02f)break;
                const float h=(P.getHeight()*.5f-8)*lvl, x=X(T*k);
                const juce::Rectangle<float> bar(x-3,up?mid-h:mid,6,h);
                g.setOpacity(1.f);
                if(on){g.setColour(gold().withAlpha(.25f));g.fillRoundedRectangle(bar.expanded(3),5);}
                juce::ColourGradient f(up?goldLight():goldDeep(),0,bar.getY(),up?goldDeep():goldLight(),0,bar.getBottom(),false);
                f.multiplyOpacity(on?1.f:.18f); g.setGradientFill(f); g.fillRoundedRectangle(bar,3);
            }
        };
        draw(tl,true,flag("dlyLOn")); draw(tr,false,flag("dlyROn"));
        caps(g,"Echo pattern",{r.getX()+16,r.getY()+12,200,16},gold().withAlpha(.85f),juce::Justification::centredLeft,9.5f);
        auto shortName=[](juce::String s){return s.replace(" bars","").replace(" Bar","");};
        const auto head="L "+shortName(choiceText("dlyLXTime"))+sep()+"R "+shortName(choiceText("dlyRXTime"))+sep()+"FB "+juce::String(juce::roundToInt(fb*100))+"%"+sep()+juce::String(bpm,bpm==std::floor(bpm)?0:1)+(sync?" BPM HOST":" BPM");
        text(g,head,{r.getX()+220,r.getY()+10,r.getRight()-70-(r.getX()+220),20},12.f,goldLight(),juce::Justification::centredRight,true);
        if(motion)
        {
            const float v=juce::jlimit(-1.f,1.f,motion());
            const float lx=r.getX()+128;
            caps(g,"LFO",{lx,r.getY()+12,30,16},gold().withAlpha(.85f),juce::Justification::centredLeft,9.5f);
            g.setColour(gold().withAlpha(.25f)); g.drawHorizontalLine(int(r.getY()+20),lx+30,lx+80);
            drawGlowDot(g,{lx+55+v*22,r.getY()+20},3.f,gold());
        }
    }

    void drawOutMeter(juce::Graphics& g,juce::Rectangle<float> P)
    {
        const float mx=P.getRight()+18, my=P.getY(), mh=P.getHeight();
        caps(g,"Out",{mx-4,my-16,40,12},gold().withAlpha(.75f),juce::Justification::centredLeft,8.f);
        for(int ch=0;ch<2;++ch)
        {
            const float lv=level[size_t(ch)];
            for(int i=0;i<22;++i)
            {
                const float cell=mh/22.f, y=my+mh-(i+1)*cell;
                const bool lit=float(i)/22.f<lv;
                g.setColour(lit?(i>18?hot():gold()):juce::Colour(0xe62a303b));
                g.fillRoundedRectangle(mx+ch*12,y+1,8,cell-2.2f,1.5f);
            }
        }
        text(g,"L",{mx-2,my+mh+4,12,12},9.f,dim(),juce::Justification::centred,true);
        text(g,"R",{mx+10,my+mh+4,12,12},9.f,dim(),juce::Justification::centred,true);
    }

    void setEqView(bool eq)
    {
        eqView=eq && chipsShown();
        decayChip.setToggleState(!eqView,juce::dontSendNotification); eqChip.setToggleState(eqView,juce::dontSendNotification);
        canvas.repaint();
    }

    // ------------------------------------------------------------ pages, presets, license
    void selectGroup(int index)
    {
        if(index<0||index>=int(spec.groups.size()))return;
        controls.clear(); activeGroup=index;
        for(size_t i=0;i<tabs.size();++i)tabs[i]->setToggleState(int(i)==index,juce::dontSendNotification);
        for(const auto& id:spec.groups[size_t(index)].ids)
            if(auto* param=state.getParameter(id))
            { auto c=std::make_unique<Control>(state,*param,spec); content.addAndMakeVisible(*c); controls.push_back(std::move(c)); }
        viewport.setViewPosition(0,0); layoutControls();
        setEqView(spec.groups[size_t(index)].name=="TONE");   // the TONE page shows the damping / EQ curve
    }
    void layoutControls()
    {
        const int columns=4,gapX=24,gapY=10,cellH=84;
        const int width=viewport.getWidth()-viewport.getScrollBarThickness()-4;
        const int cellW=(width-gapX*(columns-1))/columns;
        const int rows=(int(controls.size())+columns-1)/columns;
        content.setSize(width,juce::jmax(viewport.getHeight(),rows*cellH+juce::jmax(0,rows-1)*gapY));
        for(size_t i=0;i<controls.size();++i)controls[i]->setBounds(int(i)%columns*(cellW+gapX),int(i)/columns*(cellH+gapY),cellW,cellH);
    }
    void stepPreset(int direction)
    {
        const int count=proc.getNumPrograms(); if(count<1)return;
        customPreset.clear(); proc.setCurrentProgram((proc.getCurrentProgram()+direction+count)%count); syncPreset();
    }
    void syncPreset()
    {
        lastProgram=proc.getCurrentProgram();
        presetBox.name=customPreset.isNotEmpty()?customPreset:proc.getProgramName(lastProgram);
        presetBox.setTooltip(presetBox.name); presetBox.repaint();
    }
    void showPresetMenu()
    {
        juce::PopupMenu menu;
        for(int i=0;i<proc.getNumPrograms();++i)menu.addItem(i+1,proc.getProgramName(i),true,customPreset.isEmpty()&&i==proc.getCurrentProgram());
        menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&presetBox).withMinimumWidth(presetBox.getWidth()),
            [safe=juce::Component::SafePointer<Editor>(this)](int r){ if(safe && r>0){safe->customPreset.clear();safe->proc.setCurrentProgram(r-1);safe->syncPreset();} });
    }
    void showSettingsMenu()
    {
        juce::PopupMenu menu;
        menu.addItem(1,vn("Bản quyền & Kích hoạt..."));
        menu.addSeparator();
        menu.addItem(2,vn("Lưu preset..."));
        menu.addItem(3,vn("Mở preset..."));
        menu.addSeparator();
        menu.addItem(4,spec.name+" "+tak::product::version+sep()+juce::String::fromUTF8(tak::product::name),false,false);
        menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&gear),
            [safe=juce::Component::SafePointer<Editor>(this)](int r){ if(!safe)return; if(r==1)safe->showLicensePanel(); else if(r==2||r==3)safe->presetFile(r==2); });
    }
    void showLicensePanel()
    {
        struct Dim final : juce::Component { void paint(juce::Graphics& g) override { g.fillAll(juce::Colours::black.withAlpha(.62f)); } };
        auto safe=juce::Component::SafePointer<Editor>(this);
        overlay=std::make_unique<Dim>();
        licensePanel=std::make_unique<TLicensePanel>(
            [safe]{ return safe ? safe->license.snapshot() : tak::license::Snapshot{}; },
            [safe](const juce::String& t){ if(safe) safe->license.activate(t); },
            [safe]{ if(safe) safe->license.startTrial(); },
            [safe]{ juce::MessageManager::callAsync([safe]{ if(safe){ safe->licensePanel.reset(); safe->overlay.reset(); } }); });
        overlay->addAndMakeVisible(*licensePanel);
        licensePanel->setBounds(120,120,860,506);
        addAndMakeVisible(*overlay);
        resized();
    }
    void presetFile(bool writing)
    {
        chooser=std::make_unique<juce::FileChooser>(writing?"Save T Studio preset":"Load T Studio preset",juce::File(),
            writing?"*.tfxpreset":"*.tfxpreset;*.xml;*."+spec.legacyExtension);
        const int flags=writing?(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting)
                               :(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles);
        chooser->launchAsync(flags,[safe=juce::Component::SafePointer<Editor>(this),writing](const juce::FileChooser& fc)
        {
            if(!safe || fc.getResult()==juce::File())return;
            auto file=fc.getResult();bool ok=false;
            if(writing)
            {
                file=file.withFileExtension("tfxpreset");
                juce::XmlElement root("TStudioPreset");root.setAttribute("plugin",safe->proc.getName());root.setAttribute("version",1);
                if(auto xml=safe->state.copyState().createXml())root.addChildElement(xml.release());
                ok=root.writeTo(file);
            }
            else if(auto xml=juce::XmlDocument::parse(file))
            {
                const juce::XmlElement* payload=xml.get();
                if(xml->hasTagName("TStudioPreset"))
                    payload=matchesPresetPlugin(safe->spec,xml->getStringAttribute("plugin"),safe->proc.getName())?xml->getFirstChildElement():nullptr;
                if(payload)
                {
                    auto restored=juce::ValueTree::fromXml(*payload);
                    bool compatible=restored.isValid() && restored.hasType(safe->state.state.getType());
                    int known=0;
                    for(const auto& child:restored){auto id=child.getProperty("id").toString();if(id.isNotEmpty()){if(!safe->state.getParameter(id))compatible=false;else ++known;}}
                    if(compatible && known>0){safe->state.replaceState(restored);ok=true;}
                }
            }
            if(ok){safe->customPreset=file.getFileNameWithoutExtension();safe->syncPreset();}
            else juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,"Preset",writing?"Could not save this file.":"This preset is not compatible with this plugin.");
        });
    }
    void timerCallback() override
    {
        if(proc.getCurrentProgram()!=lastProgram){customPreset.clear();syncPreset();}
        for(auto& c:controls)c->refresh();
        for(auto& h:heroes)h->refresh();
        // license status in the header (same wording as the compressors)
        const auto snap=license.snapshot();
        juce::String status="T Studio"+sep()+spec.subtitle; auto colour=gold();
        if(!snap.allowed){status=snap.trialStarted?vn("HẾT HẠN DÙNG THỬ"):vn("CHƯA KÍCH HOẠT");colour=juce::Colour(0xfff0928a);}
        else if(!snap.activated && snap.trialStarted)status=vn("DÙNG THỬ · CÒN ")+juce::String(snap.daysLeft)+vn(" NGÀY");
        const bool nowLicensed=snap.allowed||snap.fingerprint.isEmpty();
        if(status!=statusText||colour!=statusColour||nowLicensed!=licensed)
        { statusText=status; statusColour=colour; licensed=nowLicensed; canvas.repaint(); }
        // output meter ballistics (0 dBFS at the top, -48 dB at the bottom)
        std::array<float,2> v{{0,0}}; if(meters)v=meters();
        if(!spec.stereoMeter)v[1]=v[0];
        for(size_t c=0;c<2;++c)
        {
            const float target=juce::jlimit(0.f,1.f,(juce::Decibels::gainToDecibels(juce::jmax(0.f,v[c]),-60.f)+48.f)/48.f);
            level[c]+=(target-level[c])*(target>level[c]?.5f:.12f);
        }
        canvas.repaint(screen().getSmallestIntegerContainer().expanded(2));
    }

    juce::AudioProcessor& proc; juce::AudioProcessorValueTreeState& state; Spec spec;
    tak::license::PluginLicense& license;
    Look look; Meters meters; Visual visual; std::function<float()> motion,tempo; juce::TooltipWindow tooltip;
    Canvas canvas; PresetBox presetBox;
    juce::TextButton previous{"<"},next{">"},gear,power,decayChip,eqChip;
    juce::Viewport viewport; juce::Component content;
    std::vector<std::unique_ptr<HeroKnob>> heroes;
    std::vector<std::unique_ptr<juce::TextButton>> tabs;
    std::vector<std::unique_ptr<Control>> controls;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;
    std::unique_ptr<juce::FileChooser> chooser;
    std::unique_ptr<juce::Component> overlay;
    std::unique_ptr<TLicensePanel> licensePanel;
    juce::String customPreset,statusText; juce::Colour statusColour=gold();
    int activeGroup=-1,lastProgram=-1; bool eqView=false,licensed=true;
    std::array<float,2> level{{0,0}};
};
}
