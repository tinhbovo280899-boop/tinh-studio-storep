#pragma once
#include "StudioEditor.h"
namespace tstudio_ui
{
inline Spec verbSpec()
{
    Spec s;s.name="T-Verb";s.subtitle="Long reverb";s.number="01";s.legacyExtension="tverb";s.accent=gold();
    s.heroLeft="decay";s.heroRight="wet";s.tag="VERB";s.engine="Room design";
    s.preDelayID="predelay";s.densityID="density";s.eq=EqModel::threeBand;
    s.groups={
        {"SPACE","Room model, timing and reflection structure",{"type","size","predelay","diffusion","density","attack","spread"}},
        {"TONE","Three-band damping and crossover frequencies",{"loratio","midratio","hiratio","crosslo","crosshi","locut","hicut"}},
        {"MOTION","Width, modulation and internal echoes",{"width","mod","echoint","echosize"}},
        {"OUTPUT","Dry / wet balance and engine quality",{"dry","dryon","weton","quality","bitdepth"}}};
    s.labels={{"type","Room model"},{"decay","Decay"},{"dry","Dry level"},{"wet","Wet level"},{"dryon","Dry signal"},{"weton","Wet signal"},{"crosslo","Low crossover"},{"crosshi","High crossover"},{"echoint","Echo intensity"},{"echosize","Echo size"},{"mod","Modulation"},{"bitdepth","Bit depth"}};
    s.units={{"size","m"},{"width","deg"}};return s;
}
inline Spec rverbSpec()
{
    Spec s;s.decayID="time";s.stereoMeter=false;s.name="T-RVerb";s.subtitle="Short reverb";s.number="02";s.legacyExtension="trverb";s.accent=gold();
    s.heroLeft="time";s.heroRight="wetDry";s.tag="RVB";s.engine="Reflection design";
    s.preDelayID="preDelay";s.densityID="diffusion";s.eq=EqModel::shelves;
    s.groups={
        {"SPACE","Reverb model, timing and diffusion",{"reverbType","size","preDelay","diffusion","decay"}},
        {"TONE","Frequency-dependent decay and output shelves",{"lfCut","lfRatio","hfCut","hfRatio","eqLowFreq","eqLowGain","eqHighFreq","eqHighGain"}},
        {"OUTPUT","Early reflections, tail and input gain",{"erLevel","revLevel","inGain"}}};
    s.labels={{"time","Reverb time"},{"wetDry","Wet / Dry"}};
    return s;
}
inline Spec pantheonSpec()
{
    Spec s;s.decayID="rt60";s.name="T-PANTHEON";s.legacyNames={"T-PHANGHEO"};s.subtitle="Chamber reverb";s.number="03";s.legacyExtension="pantheon";s.accent=gold();
    s.heroLeft="rt60";s.heroRight="mix";s.tag="ROOM";s.engine="Stereo chamber";
    s.preDelayID="preDelay";s.densityID="diffusion";s.eq=EqModel::chamber;
    s.groups={
        {"SPACE","Reverb model, chamber dimensions and diffusion",{"reverbType","roomSize","preDelay","diffusion"}},
        {"TONE","High-frequency damping and low-frequency contour",{"damping","bassBoost","bassFreq"}},
        {"ECHO","Regeneration, spread and independent stereo echoes",{"regen","delay","spread","echoTimeL","echoLevelL","echoTimeR","echoLevelR"}},
        {"OUTPUT","Input and output level",{"inputLevel","level"}}};
    s.units={{"roomSize","m"},{"rt60","s"},{"preDelay","ms"},{"diffusion","%"},{"damping","Hz"},{"bassBoost","x"},{"bassFreq","Hz"},{"regen","%"},{"delay","ms"},{"spread","%"},{"echoTimeL","ms"},{"echoTimeR","ms"},{"echoLevelL","dB"},{"echoLevelR","dB"},{"inputLevel","dB"},{"level","dB"},{"mix","%"}};
    s.labels={{"rt60","Reverb time"},{"level","Output level"}};return s;
}
inline Spec delaySpec()
{
    Spec s;s.name="T-LIQUID DELAY";s.legacyNames={"T-LIQUI DELAY"};s.screen=Screen::delay;s.subtitle="Stereo delay";s.number="04";s.legacyExtension="ldelay";s.accent=gold();s.delay=true;
    s.heroLeft="dlyFeedback";s.heroRight="mix";s.tag="ECHO";s.engine="Rhythmic motion";
    s.groups={
        {"TIME","Tempo, stereo divisions and delay lines",{"dlyTempo","dlySync","dlyLXTime","dlyRXTime","dlyLOn","dlyROn"}},
        {"RHYTHM","Independent dotted and triplet timing",{"dlyLDot","dlyLTri","dlyRDot","dlyRTri"}},
        {"TONE","Filtering, resonance and drive placement",{"filterOn","lowCut","highCut","resonance","overdrive","inLoop","hdFilter"}},
        {"MOTION","LFO waveform, speed and depth",{"lfoOn","lfoSync","lfoRate","lfoDepth","lfoWave"}},
        {"OUTPUT","Signal order, gain and width",{"fxMode","inputLevel","outputLevel","stereoWidth","peakLimit"}}};
    s.labels={{"dlyTempo","Manual tempo"},{"dlySync","Host tempo"},{"dlyLXTime","Left division"},{"dlyRXTime","Right division"},{"dlyFeedback","Feedback"},{"dlyLOn","Left delay"},{"dlyROn","Right delay"},{"dlyLDot","Left dotted"},{"dlyRDot","Right dotted"},{"dlyLTri","Left triplet"},{"dlyRTri","Right triplet"},{"inLoop","Filter in loop"},{"filterOn","Filter enabled"},{"hdFilter","HD filter"},{"lfoOn","LFO enabled"},{"lfoSync","LFO tempo sync"},{"lfoRate","LFO rate"},{"lfoDepth","LFO depth"},{"lfoWave","LFO waveform"},{"fxMode","Signal order"},{"peakLimit","Peak limiter"}};
    s.units={{"dlyTempo","BPM"},{"dlyFeedback","%"},{"lowCut","Hz"},{"highCut","Hz"},{"resonance","%"},{"overdrive","%"},{"lfoRate","Hz"},{"lfoDepth","%"},{"stereoWidth","%"},{"inputLevel","dB"},{"outputLevel","dB"},{"mix","%"}};return s;
}
}
