// T Studio "hardware" editor kit: black brushed panel, light-orange accents, machined knobs.
// Header-only, shared by every T Studio plugin except T-AutoKey / T-AutoTune.
//
// A plugin editor derives from thw::Editor and lays its face out in design coordinates
// (the same numbers as the approved mock-ups). Everything static (panel, rails, section
// frames, engraved captions, knob scales) is drawn once into a cached image at the screen's
// pixel density; knobs cache their machined body, so a value change only redraws the
// pointer/arc of that one knob. Parameters that are not placed on the face are collected
// automatically in the "THÊM" panel, so no feature is lost.
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include "TStudioFonts.h"
#include "licensing/PluginLicense.h"
#include "licensing/LicensePanel.h"
#include <cmath>
#include <functional>
#include <map>
#include <memory>
#include <set>
#include <vector>

namespace thw
{
using juce::Colour;
using juce::String;

// ---------------------------------------------------------------- palette
inline Colour orange()      { return Colour (0xfff7b26a); }
inline Colour orangeLight() { return Colour (0xffffd3a3); }
inline Colour orangeDeep()  { return Colour (0xffe07a2e); }
inline Colour lcdText()     { return Colour (0xffffbe7d); }
inline Colour cream()       { return Colour (0xffd9d1c5); }
inline Colour creamBright() { return Colour (0xffece4d8); }
inline Colour dim()         { return Colour (0xff9a9286); }
inline Colour dimDark()     { return Colour (0xff6f685e); }
inline Colour railTop()     { return Colour (0xff2a2b2f); }
inline Colour railBot()     { return Colour (0xff16171a); }
inline Colour well()        { return Colour (0xff070707); }
inline Colour red()         { return Colour (0xfff0928a); }
inline String vn (const char* s) { return String::fromUTF8 (s); }
// Doi thuong hieu (ThuongHieu.json -> namePrefix): "T-Verb" -> "LCH-Verb". Mac dinh "T-" giu nguyen.
inline String brandName (const String& n)
{
    const auto prefix = String::fromUTF8 (tak::product::namePrefix);
    return (prefix != "T-" && n.startsWith ("T-")) ? prefix + n.substring (2) : n;
}
inline String brandLogo()      { return String::fromUTF8 (tak::product::brandLogo); }
inline String brandPublisher() { return String::fromUTF8 (tak::product::publisher); }

// ---------------------------------------------------------------- fonts
inline juce::Typeface::Ptr faceFor (int weight)
{
    // Created once and intentionally never destroyed: a static Typeface::Ptr would be
    // released while the DLL unloads, after JUCE has shut down (crash/hang on exit or scan).
    static auto& semi  = *new juce::Typeface::Ptr (juce::Typeface::createSystemTypefaceFor (TStudioFonts::InterSemiBold_otf,  (size_t) TStudioFonts::InterSemiBold_otfSize));
    static auto& bold  = *new juce::Typeface::Ptr (juce::Typeface::createSystemTypefaceFor (TStudioFonts::InterBold_otf,      (size_t) TStudioFonts::InterBold_otfSize));
    static auto& heavy = *new juce::Typeface::Ptr (juce::Typeface::createSystemTypefaceFor (TStudioFonts::InterExtraBold_otf, (size_t) TStudioFonts::InterExtraBold_otfSize));
    return weight >= 8 ? heavy : weight == 7 ? bold : semi;
}
inline juce::Font font (float size, int weight = 7, float track = 0.0f)
{
    return juce::Font (juce::FontOptions (faceFor (weight)).withPointHeight (size).withKerningFactor (size > 0 ? track / size : 0.0f));
}
inline float textWidth (const juce::Font& f, const String& s) { return juce::GlyphArrangement::getStringWidth (f, s); }

// Text centred vertically on y. align: 0 centre on x, -1 starts at x, +1 ends at x.
inline void text (juce::Graphics& g, const String& s, float x, float y, float size, Colour c, int weight = 7, int align = 0, float track = 0.0f)
{
    g.setColour (c);
    g.setFont (font (size, weight, track));
    const float w = 2000.0f;
    juce::Rectangle<float> r (align == 0 ? x - w * 0.5f : align < 0 ? x : x - w, y - size, w, size * 2.0f);
    g.drawText (s, r, align == 0 ? juce::Justification::centred : align < 0 ? juce::Justification::centredLeft : juce::Justification::centredRight, false);
}
// Engraved caption: dark shadow under cream text.
inline void engrave (juce::Graphics& g, const String& s, float x, float y, float size, float track = 1.5f, int align = 0, Colour c = cream())
{
    thw::text (g, s, x, y + 1.0f, size, juce::Colours::black.withAlpha (0.7f), 8, align, track);
    thw::text (g, s, x, y, size, c, 8, align, track);
}

// ---------------------------------------------------------------- static drawing
inline void brushed (juce::Graphics& g, juce::Rectangle<float> r)
{
    g.setGradientFill (juce::ColourGradient (Colour (0xff1e1e21), 0, r.getY(), Colour (0xff0f0f11), 0, r.getBottom(), false));
    g.fillRect (r);
    juce::Random rnd (7);
    for (int i = 0; i < (int) (r.getWidth() * r.getHeight() / 700.0f); ++i)
    {
        const float y = r.getY() + rnd.nextFloat() * r.getHeight(), x = r.getX() + rnd.nextFloat() * r.getWidth();
        const float l = 40.0f + rnd.nextFloat() * 260.0f;
        g.setColour (juce::Colours::white.withAlpha (rnd.nextFloat() * 0.035f));
        g.drawLine (x, y, juce::jmin (r.getRight(), x + l), y, 0.6f);
    }
    juce::ColourGradient sheen (orange().withAlpha (0.07f), r.getCentreX(), r.getY() + r.getHeight() * 0.05f,
                                orange().withAlpha (0.0f), r.getCentreX() + r.getWidth() * 0.7f, r.getY(), true);
    g.setGradientFill (sheen);
    g.fillRect (r);
}
inline void screw (juce::Graphics& g, float x, float y)
{
    g.setGradientFill (juce::ColourGradient (Colour (0xfff2f2f0), x - 2, y - 2, Colour (0xff77736c), x + 4, y + 4, true));
    g.fillEllipse (x - 5.5f, y - 5.5f, 11.0f, 11.0f);
    g.setColour (juce::Colours::black.withAlpha (0.45f));
    g.drawLine (x - 3.5f, y - 1.5f, x + 3.5f, y + 1.5f, 1.2f);
}
inline void logo (juce::Graphics& g, float x, float y, float r)
{
    g.setGradientFill (juce::ColourGradient (Colour (0xffffd09a), x - r, y - r, orangeDeep(), x + r, y + r, false));
    g.fillEllipse (x - r, y - r, r * 2, r * 2);
    const float k = r / 17.0f;
    const float pts[][2] = { { -11, 1 }, { -6, -5 }, { -2, 5 }, { 3, -9 }, { 7, 3 }, { 12, -3 } };
    juce::Path p;
    p.startNewSubPath (x + pts[0][0] * k, y + pts[0][1] * k);
    for (int i = 1; i < 6; ++i) p.lineTo (x + pts[i][0] * k, y + pts[i][1] * k);
    g.setColour (Colour (0xff15161a));
    g.strokePath (p, juce::PathStrokeType (1.9f * k, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
}
inline void lcdFrame (juce::Graphics& g, juce::Rectangle<float> r)
{
    g.setColour (Colour (0xff070707));
    g.fillRoundedRectangle (r, 4.0f);
    g.setColour (orange().withAlpha (0.28f));
    g.drawRoundedRectangle (r.reduced (0.5f), 4.0f, 1.0f);
}
inline void sectionFrame (juce::Graphics& g, juce::Rectangle<float> r, const String& title)
{
    g.setColour (juce::Colours::black.withAlpha (0.25f));
    g.fillRoundedRectangle (r.translated (0, 2), 10.0f);
    g.setColour (juce::Colours::white.withAlpha (0.035f));
    g.fillRoundedRectangle (r, 10.0f);
    g.setColour (juce::Colours::white.withAlpha (0.08f));
    g.drawRoundedRectangle (r.reduced (0.5f), 10.0f, 1.0f);
    if (title.isNotEmpty()) engrave (g, title, r.getX() + 14, r.getY() + 16, 10.5f, 2.5f, -1);
}
inline void screenFrame (juce::Graphics& g, juce::Rectangle<float> r)
{
    g.setColour (well());
    g.fillRoundedRectangle (r, 8.0f);
    g.setColour (orange().withAlpha (0.18f));
    g.drawRoundedRectangle (r.reduced (0.5f), 8.0f, 1.0f);
}
inline void screenGrid (juce::Graphics& g, juce::Rectangle<float> r)
{
    g.setColour (orange().withAlpha (0.07f));
    for (int i = 1; i < 8; ++i) g.drawVerticalLine (juce::roundToInt (r.getX() + r.getWidth() * (float) i / 8.0f), r.getY() + 6, r.getBottom() - 6);
    for (int i = 1; i < 4; ++i) g.drawHorizontalLine (juce::roundToInt (r.getY() + r.getHeight() * (float) i / 4.0f), r.getX() + 6, r.getRight() - 6);
}
inline float knobAngle (float u) { return -juce::MathConstants<float>::pi * 0.75f + u * juce::MathConstants<float>::pi * 1.5f; }   // 0 = 12 o'clock
inline juce::Point<float> polar (float cx, float cy, float r, float a) { return { cx + r * std::sin (a), cy - r * std::cos (a) }; }

// printed scale around a knob: ticks + labels spread evenly from min to max
inline void knobScale (juce::Graphics& g, float cx, float cy, float R, const juce::StringArray& labels)
{
    const int n = labels.size();
    for (int i = 0; i <= 40; ++i)
    {
        const bool major = n > 1 && (i % (40 / (n - 1))) == 0;
        const float a = knobAngle ((float) i / 40.0f);
        g.setColour (cream().withAlpha (major ? 0.9f : 0.55f));
        g.drawLine (juce::Line<float> (polar (cx, cy, R + 6, a), polar (cx, cy, R + (major ? 13.0f : 9.0f), a)), major ? 1.6f : 0.8f);
    }
    for (int i = 0; i < n; ++i)
    {
        const auto p = polar (cx, cy, R + 24, knobAngle (n > 1 ? (float) i / (float) (n - 1) : 0.5f));
        thw::text (g, labels[i], p.x, p.y, 10.5f, cream(), 8);
    }
}

// machined knob body (everything but the pointer and value arc)
inline void drawKnobBody (juce::Graphics& g, float cx, float cy, float R, float cap)
{
    {   // drop + contact shadow
        juce::Path s; s.addEllipse (cx - R * 0.98f, cy + R * 0.04f - R * 0.98f, R * 1.96f, R * 1.96f);
        juce::DropShadow (juce::Colours::black.withAlpha (0.75f), juce::roundToInt (R * 0.45f), { 0, juce::roundToInt (R * 0.18f) }).drawForPath (g, s);
    }
    g.setGradientFill (juce::ColourGradient::vertical (Colour (0xff3b3c40), cy - R, Colour (0xff050506), cy + R));
    {
        juce::ColourGradient sk (Colour (0xff3b3c40), cx, cy - R, Colour (0xff050506), cx, cy + R, false);
        sk.addColour (0.5, Colour (0xff161619));
        g.setGradientFill (sk);
    }
    g.fillEllipse (cx - R, cy - R, R * 2, R * 2);
    // knurling, lit from above
    const int n = juce::jmax (36, juce::roundToInt (R * 2.2f));
    for (int i = 0; i < n; ++i)
    {
        const float a = (float) i / (float) n * juce::MathConstants<float>::twoPi;
        const float lit = 0.5f + 0.5f * std::cos (a + 0.6f);
        const float ux = std::sin (a), uy = -std::cos (a);
        g.setColour (juce::Colours::white.withAlpha (0.04f + 0.22f * lit * lit * lit));
        g.drawLine (cx + ux * R * 0.80f, cy + uy * R * 0.80f, cx + ux * R * 0.985f, cy + uy * R * 0.985f, juce::jmax (0.8f, R * 0.025f));
        const float b = a + juce::MathConstants<float>::pi / (float) n;
        const float vx = std::sin (b), vy = -std::cos (b);
        g.setColour (juce::Colours::black.withAlpha (0.55f));
        g.drawLine (cx + vx * R * 0.80f, cy + vy * R * 0.80f, cx + vx * R * 0.985f, cy + vy * R * 0.985f, juce::jmax (0.6f, R * 0.015f));
    }
    {   // glossy bevel + sheen
        juce::ColourGradient hl (juce::Colours::white.withAlpha (0.8f), cx - R, cy - R, juce::Colours::white.withAlpha (0.0f), cx + R * 0.3f, cy + R * 0.3f, false);
        hl.addColour (0.5, juce::Colours::white.withAlpha (0.05f));
        g.setGradientFill (hl);
        g.drawEllipse (cx - R * 0.985f, cy - R * 0.985f, R * 1.97f, R * 1.97f, juce::jmax (1.2f, R * 0.05f));
        g.saveState();
        juce::Path clip; clip.addEllipse (cx - R * 0.98f, cy - R * 0.98f, R * 1.96f, R * 1.96f);
        g.reduceClipRegion (clip);
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.28f), cx - R * 0.45f, cy - R * 0.55f,
                                                 juce::Colours::white.withAlpha (0.0f), cx - R * 0.45f + R * 0.75f, cy - R * 0.55f, true));
        g.fillRect (cx - R, cy - R, R * 2, R * 2);
        g.restoreState();
    }
    const float cr = R * cap;
    if (cr > 2.0f)
    {
        g.setColour (Colour (0xff0b0b0d));
        g.fillEllipse (cx - cr * 1.1f, cy - cr * 1.1f, cr * 2.2f, cr * 2.2f);
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.18f), cx, cy - cr * 1.1f, juce::Colours::white.withAlpha (0.0f), cx, cy + cr * 1.1f, false));
        g.drawEllipse (cx - cr * 1.1f, cy - cr * 1.1f, cr * 2.2f, cr * 2.2f, 1.0f);
        g.saveState();
        juce::Path c; c.addEllipse (cx - cr, cy - cr, cr * 2, cr * 2);
        g.reduceClipRegion (c);
        {
            // v1.2.1: black anodised cap (was bright spun silver, too glaring on a dark panel)
            juce::ColourGradient base (Colour (0xff3a3b40), cx - cr * 0.35f, cy - cr * 0.45f, Colour (0xff0c0c0e), cx - cr * 0.35f + cr * 1.25f, cy - cr * 0.45f, true);
            base.addColour (0.55, Colour (0xff1c1d20));
            g.setGradientFill (base);
            g.fillRect (cx - cr, cy - cr, cr * 2, cr * 2);
        }
        // soft brushed reflections: same two-lobe pattern as before, but faint
        const int wedges = 72;
        for (int k = 0; k < wedges; ++k)
        {
            const float t0 = (float) k / wedges, t1 = (float) (k + 1) / wedges;
            const float cval = std::cos ((t0 + t1) * 0.5f * juce::MathConstants<float>::pi * 4.0f);
            const float w = juce::jmax (0.0f, cval), d = juce::jmax (0.0f, -cval);
            const Colour col = w >= d ? juce::Colours::white.withAlpha (0.075f * w * w) : juce::Colours::black.withAlpha (0.30f * d * d);
            const float a0 = -0.9f + t0 * juce::MathConstants<float>::twoPi + juce::MathConstants<float>::halfPi;
            const float a1 = -0.9f + t1 * juce::MathConstants<float>::twoPi + juce::MathConstants<float>::halfPi;
            juce::Path wedge;
            wedge.startNewSubPath (cx, cy);
            wedge.addCentredArc (cx, cy, cr, cr, 0.0f, a0, a1 + 0.01f, false);
            wedge.closeSubPath();
            g.setColour (col);
            g.fillPath (wedge);
        }
        for (float r = cr * 0.15f; r < cr; r += juce::jmax (0.9f, cr / 26.0f))
        {
            g.setColour (((int) std::round (r * 7.0f) % 2) ? juce::Colours::white.withAlpha (0.02f) : juce::Colours::black.withAlpha (0.05f));
            g.drawEllipse (cx - r, cy - r, r * 2, r * 2, 0.6f);
        }
        g.restoreState();
        g.setColour (juce::Colours::black.withAlpha (0.6f));
        g.drawEllipse (cx - cr, cy - cr, cr * 2, cr * 2, 1.0f);
        juce::Path rim; rim.addCentredArc (cx, cy, cr - 0.8f, cr - 0.8f, 0.0f, -2.2f, -0.5f, true);
        g.setColour (juce::Colours::white.withAlpha (0.22f));
        g.strokePath (rim, juce::PathStrokeType (1.0f));
    }
}

inline float physicalScale (juce::Graphics& g) { return juce::jlimit (0.25f, 8.0f, g.getInternalContext().getPhysicalPixelScaleFactor()); }

// cache of knob bodies keyed by size/cap/screen scale (message thread only)
inline const juce::Image& knobBodyImage (float R, float cap, float scale)
{
    // Heap-allocated on purpose: a static map of images would be destroyed when the
    // DLL unloads, after JUCE has shut down. Software images: no GPU/Direct2D
    // resources shared between plugin windows.
    static auto& cache = *new std::map<juce::String, juce::Image>();
    const auto key = String (R, 1) + "|" + String (cap, 2) + "|" + String (juce::roundToInt (scale * 100));
    auto it = cache.find (key);
    if (it == cache.end())
    {
        if (cache.size() > 96) cache.clear();
        const float half = R * 1.45f;
        const int px = juce::jmax (1, (int) std::ceil (half * 2 * scale));
        juce::Image img (juce::Image::ARGB, px, px, true, juce::SoftwareImageType());
        {
            juce::Graphics ig (img);
            ig.addTransform (juce::AffineTransform::scale (scale));
            drawKnobBody (ig, half, half, R, cap);
        }
        it = cache.emplace (key, img).first;
    }
    return it->second;
}

// ---------------------------------------------------------------- value text
inline String niceNumber (double v)
{
    const double a = std::abs (v);
    if (std::abs (v - std::round (v)) < 1.0e-6 && a < 100000) return String ((int) std::round (v));
    return String (v, a >= 100 ? 0 : a >= 10 ? 1 : 2);
}
// Parameter text for the LCDs: host text tidied up, unit appended.
inline String paramText (juce::RangedAudioParameter& p, const String& unit = {})
{
    auto t = p.getCurrentValueAsText().trim();
    const auto u = unit.isNotEmpty() ? unit : p.getLabel().trim();
    if (t.isNotEmpty() && t.containsOnly ("0123456789.-+ ") && t.containsAnyOf ("0123456789"))
    {
        const double v = t.getDoubleValue();
        t = (u == "dB" && std::abs (v) < 100) ? String (v, 1) : niceNumber (v);
    }
    if (u.isNotEmpty() && ! t.endsWithIgnoreCase (u) && t.containsAnyOf ("0123456789")) t << " " << u;
    return t;
}

// ---------------------------------------------------------------- look & feel (menus, combo boxes, text entry)
class Look final : public juce::LookAndFeel_V4
{
public:
    Look()
    {
        setColour (juce::PopupMenu::backgroundColourId, Colour (0xff141416));
        setColour (juce::PopupMenu::textColourId, creamBright());
        setColour (juce::PopupMenu::headerTextColourId, orange());
        setColour (juce::PopupMenu::highlightedBackgroundColourId, orange().withAlpha (0.25f));
        setColour (juce::PopupMenu::highlightedTextColourId, creamBright());
        setColour (juce::TextEditor::backgroundColourId, well());
        setColour (juce::TextEditor::textColourId, lcdText());
        setColour (juce::TextEditor::outlineColourId, orange().withAlpha (0.6f));
        setColour (juce::TextEditor::focusedOutlineColourId, orange());
        setColour (juce::TextEditor::highlightColourId, orange().withAlpha (0.35f));
        setColour (juce::CaretComponent::caretColourId, orangeLight());
        setColour (juce::ComboBox::textColourId, creamBright());
        setColour (juce::TooltipWindow::backgroundColourId, Colour (0xff141416));
        setColour (juce::TooltipWindow::textColourId, creamBright());
        setColour (juce::TooltipWindow::outlineColourId, orange().withAlpha (0.4f));
    }
    juce::Typeface::Ptr getTypefaceForFont (const juce::Font& f) override
    {
        return faceFor (f.isBold() ? 8 : 7);
    }
    juce::Font getPopupMenuFont() override { return font (14.0f, 7); }
    void drawPopupMenuBackground (juce::Graphics& g, int w, int h) override
    {
        g.fillAll (Colour (0xff141416));
        g.setColour (orange().withAlpha (0.35f));
        g.drawRect (0, 0, w, h, 1);
    }
    void drawComboBox (juce::Graphics&, int, int, bool, int, int, int, int, juce::ComboBox&) override {}
    void positionComboBoxText (juce::ComboBox&, juce::Label& l) override { l.setBounds (0, 0, 0, 0); }
};
inline Look& look() { static auto& l = *new Look(); return l; }   // never destroyed at DLL unload (see faceFor)

// ---------------------------------------------------------------- controls
// Knob attached to a parameter. Static scale is drawn in the face plate; this draws arc + body + pointer.
class Knob final : public juce::Slider
{
public:
    Knob (float radius, float capRatio, bool showArc = true) : R (radius), cap (capRatio), arc (showArc)
    {
        setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        setMouseDragSensitivity (R >= 40 ? 300 : 220);
        setVelocityModeParameters (0.3, 1, 0.0, true, juce::ModifierKeys::shiftModifier);   // Shift = fine
        setScrollWheelEnabled (true);
    }
    void paint (juce::Graphics& g) override
    {
        const float cx = getWidth() * 0.5f, cy = getHeight() * 0.5f;
        const float u = (float) valueToProportionOfLength (getValue());
        if (arc)
        {
            juce::Path a;
            a.addCentredArc (cx, cy, R + 3.5f, R + 3.5f, 0.0f, knobAngle (0.0f), knobAngle (juce::jlimit (0.0f, 1.0f, u)), true);
            g.setColour (orange().withAlpha (0.22f));
            g.strokePath (a, juce::PathStrokeType (juce::jmax (2.5f, R * 0.06f) + 4.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour (orange());
            g.strokePath (a, juce::PathStrokeType (juce::jmax (2.5f, R * 0.06f), juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        const float scale = physicalScale (g);
        const auto& body = knobBodyImage (R, cap, scale);
        const float half = R * 1.45f;
        g.drawImage (body, juce::Rectangle<float> (cx - half, cy - half, half * 2, half * 2));
        const float a = knobAngle (u), cr = R * cap;
        // pointer runs from inside the dark cap out to the knurled skirt (warm orange, no white glare)
        const float p0 = cr > 2.0f ? cr * 0.42f : R * 0.35f, p1 = R * 0.95f;
        const auto s = polar (cx, cy, p0, a), e = polar (cx, cy, p1, a), e2 = polar (cx, cy, p1 - 1, a);
        g.setColour (juce::Colours::black.withAlpha (0.7f));
        g.drawLine (juce::Line<float> (s, e), juce::jmax (3.0f, R * 0.1f));
        g.setColour (orangeLight());
        g.drawLine (juce::Line<float> (s, e2), juce::jmax (1.8f, R * 0.055f));
    }
    float R, cap; bool arc;
};

// Value display. Click to type a value; Enter applies it, Esc cancels.
class ValueBox final : public juce::Component
{
public:
    std::function<String()> textFn;
    std::function<void (const String&)> onType;
    float fontSize = 13.0f;
    Colour colour = lcdText();
    void refresh() { const auto t = textFn ? textFn() : String(); if (t != shown) { shown = t; repaint(); } }
    void paint (juce::Graphics& g) override
    {
        lcdFrame (g, getLocalBounds().toFloat());
        if (! editor) thw::text (g, shown, getWidth() * 0.5f, getHeight() * 0.5f + 0.5f, fontSize, colour, 7);
    }
    void mouseUp (const juce::MouseEvent& e) override
    {
        if (! onType || e.mouseWasDraggedSinceMouseDown()) return;
        editor = std::make_unique<juce::TextEditor>();
        editor->setLookAndFeel (&look());
        editor->setFont (font (fontSize, 7));
        editor->setJustification (juce::Justification::centred);
        editor->setText (shown.upToFirstOccurrenceOf (" ", false, false), false);
        editor->setSelectAllWhenFocused (true);
        editor->setIndents (2, juce::jmax (0, (getHeight() - (int) fontSize - 4) / 2));
        editor->onReturnKey = [this] { const auto t = editor->getText(); close(); if (onType) onType (t); };
        editor->onEscapeKey = [this] { close(); };
        editor->onFocusLost = [this] { close(); };
        addAndMakeVisible (*editor);
        editor->setBounds (getLocalBounds());
        editor->grabKeyboardFocus();
        repaint();
    }
private:
    void close() { juce::MessageManager::callAsync ([safe = juce::Component::SafePointer<ValueBox> (this)] { if (safe) { safe->editor.reset(); safe->repaint(); } }); }
    String shown;
    std::unique_ptr<juce::TextEditor> editor;
};

// Lit push button for a bool parameter (or an action when no parameter).
class LedButton final : public juce::Button
{
public:
    explicit LedButton (const String& label) : juce::Button (label) { setClickingTogglesState (true); }
    bool momentary = false;
    void paintButton (juce::Graphics& g, bool over, bool) override
    {
        const auto r = getLocalBounds().toFloat();
        const bool on = getToggleState() && ! momentary;
        g.setColour (Colour (0xff202124));
        g.fillRoundedRectangle (r, 5.0f);
        g.setColour (on ? orange().withAlpha (0.85f) : juce::Colours::white.withAlpha (over ? 0.25f : 0.13f));
        g.drawRoundedRectangle (r.reduced (0.5f), 5.0f, 1.0f);
        const float ly = r.getCentreY();
        if (on)
        {
            g.setColour (lcdText().withAlpha (0.35f));
            g.fillEllipse (13 - 7, ly - 7, 14, 14);
        }
        g.setColour (on ? lcdText() : Colour (0xff4a4740));
        g.fillEllipse (13 - 3.5f, ly - 3.5f, 7, 7);
        thw::text (g, getButtonText(), r.getCentreX() + 7, ly + 0.5f, 10.0f, on ? orangeLight() : Colour (0xffbdb6aa), 8, 0, 1.2f);
    }
};

// Segmented selector for a choice parameter.
class Segmented final : public juce::Component
{
public:
    Segmented (juce::RangedAudioParameter& p, juce::StringArray l, float segW)
        : labels (std::move (l)), w (segW), attachment (p, [this] (float v) { index = juce::roundToInt (v); repaint(); }) { attachment.sendInitialUpdate(); }
    void paint (juce::Graphics& g) override
    {
        for (int i = 0; i < labels.size(); ++i)
        {
            const juce::Rectangle<float> r ((float) i * w, 0, w - 4, (float) getHeight());
            const bool on = i == index;
            g.setColour (on ? Colour (0xff3b2a1a) : Colour (0xff1d1e21));
            g.fillRoundedRectangle (r, 4.0f);
            g.setColour (on ? orange().withAlpha (0.9f) : juce::Colours::white.withAlpha (0.13f));
            g.drawRoundedRectangle (r.reduced (0.5f), 4.0f, 1.0f);
            thw::text (g, labels[i], r.getCentreX(), r.getCentreY() + 0.5f, 10.5f, on ? orangeLight() : dim(), 8);
        }
    }
    void mouseDown (const juce::MouseEvent& e) override
    {
        const int i = juce::jlimit (0, labels.size() - 1, (int) (e.position.x / w));
        attachment.setValueAsCompleteGesture ((float) i);
    }
    juce::StringArray labels; float w; int index = 0;
    juce::ParameterAttachment attachment;
};

// Drop-down for a choice parameter.
class Select final : public juce::ComboBox
{
public:
    Select() { setLookAndFeel (&look()); setMouseCursor (juce::MouseCursor::PointingHandCursor); }
    ~Select() override { setLookAndFeel (nullptr); }
    void paint (juce::Graphics& g) override
    {
        const auto r = getLocalBounds().toFloat();
        g.setColour (Colour (0xff1b1c1f));
        g.fillRoundedRectangle (r, 6.0f);
        g.setColour (juce::Colours::white.withAlpha (0.13f));
        g.drawRoundedRectangle (r.reduced (0.5f), 6.0f, 1.0f);
        thw::text (g, getText(), r.getCentreX() - 6, r.getCentreY() + 0.5f, 11.5f, creamBright(), 7);
        thw::text (g, vn ("▾"), r.getRight() - 12, r.getCentreY() + 0.5f, 9.0f, orange(), 8);
    }
};

// Vertical fader with a machined cap.
class Fader final : public juce::Slider
{
public:
    Fader()
    {
        setSliderStyle (juce::Slider::LinearVertical);
        setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
        setVelocityModeParameters (0.3, 1, 0.0, true, juce::ModifierKeys::shiftModifier);
        setSliderSnapsToMousePosition (false);
    }
    // the slider spans the cap travel: track top/bottom at 18 px inside
    void paint (juce::Graphics& g) override
    {
        const float x = getWidth() * 0.5f, top = 18.0f, bot = getHeight() - 18.0f;
        g.setColour (Colour (0xff050506));
        g.fillRoundedRectangle (x - 3, top, 6, bot - top, 3.0f);
        g.setColour (juce::Colours::white.withAlpha (0.08f));
        g.drawRoundedRectangle (x - 3, top, 6, bot - top, 3.0f, 1.0f);
        const float u = (float) valueToProportionOfLength (getValue());
        const float yv = bot - (bot - top) * u;
        juce::Path cap; cap.addRoundedRectangle (x - 20, yv - 18, 40, 36, 5.0f);
        juce::DropShadow (juce::Colours::black.withAlpha (0.6f), 8, { 0, 4 }).drawForPath (g, cap);
        juce::ColourGradient cg (Colour (0xfff4f3f0), 0, yv - 18, Colour (0xffd8d6d1), 0, yv + 18, false);
        cg.addColour (0.45, Colour (0xffb9b7b2)); cg.addColour (0.55, Colour (0xff8e8c87));
        g.setGradientFill (cg);
        g.fillPath (cap);
        g.setColour (Colour (0xff1b1b1b));
        g.fillRect (x - 18, yv - 1.2f, 36.0f, 2.4f);
    }
};

// Analogue VU meter (needle with ballistics). source() returns dB on the VU scale (-20 .. +3).
class VuMeter final : public juce::Component
{
public:
    std::function<float()> source;
    String caption = "VU";
    void tick()
    {
        const float target = source ? juce::jlimit (-22.0f, 4.0f, source()) : -22.0f;
        value += (target - value) * 0.25f;
        if (std::abs (value - shown) > 0.02f) { shown = value; repaint(); }
    }
    static float angleFor (float db)
    {
        static const float t[][2] = { { -20, -0.82f }, { -10, -0.5f }, { -7, -0.33f }, { -5, -0.2f }, { -3, -0.06f }, { -2, 0.02f }, { -1, 0.11f }, { 0, 0.21f }, { 1, 0.33f }, { 2, 0.46f }, { 3, 0.6f } };
        if (db <= t[0][0]) return t[0][1] - (t[0][0] - db) * 0.01f;
        for (int i = 0; i < 10; ++i)
            if (db <= t[i + 1][0]) { const float u = (db - t[i][0]) / (t[i + 1][0] - t[i][0]); return t[i][1] + u * (t[i + 1][1] - t[i][1]); }
        return 0.6f;
    }
    void paint (juce::Graphics& g) override
    {
        const float scale = physicalScale (g);
        const int pw = juce::roundToInt (getWidth() * scale), ph = juce::roundToInt (getHeight() * scale);
        if (face.getWidth() != pw || face.getHeight() != ph)
        {
            face = juce::Image (juce::Image::ARGB, juce::jmax (1, pw), juce::jmax (1, ph), true);
            juce::Graphics fg (face); fg.addTransform (juce::AffineTransform::scale (scale)); paintFace (fg);
        }
        g.drawImage (face, getLocalBounds().toFloat());
        auto f = faceRect();
        g.saveState();
        g.reduceClipRegion (f.toNearestInt());
        const float R1 = juce::jmin (f.getWidth() * 0.42f, f.getHeight() * 0.95f);
        const float pcx = f.getCentreX(), pcy = f.getBottom() + R1 * 0.2f;
        const float a = angleFor (shown);
        g.setColour (Colour (0xffb3261e));
        g.drawLine (juce::Line<float> (polar (pcx, pcy, R1 * 0.3f, a), polar (pcx, pcy, R1 + 12, a)), 1.6f);
        g.restoreState();
    }
private:
    juce::Rectangle<float> faceRect() const { return getLocalBounds().toFloat().reduced (18, 16); }
    void paintFace (juce::Graphics& g)
    {
        const auto b = getLocalBounds().toFloat();
        juce::Path box; box.addRoundedRectangle (b.reduced (2), 10.0f);
        g.setGradientFill (juce::ColourGradient::vertical (Colour (0xff55575c), b.getY(), Colour (0xff1d1e21), b.getBottom()));
        g.fillPath (box);
        const auto f = faceRect();
        g.setGradientFill (juce::ColourGradient (Colour (0xfffff6d8), f.getCentreX(), f.getBottom() - f.getHeight() * 0.1f,
                                                 Colour (0xffe7d9a8), f.getCentreX() + f.getWidth() * 0.7f, f.getY(), true));
        g.fillRoundedRectangle (f, 4.0f);
        g.saveState(); g.reduceClipRegion (f.toNearestInt());
        const float R1 = juce::jmin (f.getWidth() * 0.42f, f.getHeight() * 0.95f);
        const float pcx = f.getCentreX(), pcy = f.getBottom() + R1 * 0.2f;
        juce::Path arcA; arcA.addCentredArc (pcx, pcy, R1, R1, 0, angleFor (-20), angleFor (0), true);
        g.setColour (Colour (0xff1d1d1d)); g.strokePath (arcA, juce::PathStrokeType (1.6f));
        juce::Path arcB; arcB.addCentredArc (pcx, pcy, R1 + 2, R1 + 2, 0, angleFor (0), angleFor (3), true);
        g.setColour (Colour (0xffc0261b)); g.strokePath (arcB, juce::PathStrokeType (4.0f));
        for (int d : { -20, -10, -7, -5, -3, -1, 0, 1, 2, 3 })
        {
            const float a = angleFor ((float) d);
            const auto c = d > 0 ? Colour (0xffc0261b) : Colour (0xff1d1d1d);
            g.setColour (c);
            g.drawLine (juce::Line<float> (polar (pcx, pcy, R1, a), polar (pcx, pcy, R1 + 10, a)), 1.5f);
            const auto p = polar (pcx, pcy, R1 + 20, a);
            thw::text (g, String (d), p.x, p.y, 10.5f, c, 8);
        }
        thw::text (g, caption, f.getCentreX(), f.getBottom() - 22, 13.0f, Colour (0xff1d1d1d), 8, 0, 2.0f);
        g.restoreState();
    }
    juce::Image face;
    float value = -22.0f, shown = -99.0f;
};

// LED bar meter. source() returns 0..1.
class LedMeter final : public juce::Component
{
public:
    std::function<float()> source;
    void tick()
    {
        const float t = source ? juce::jlimit (0.0f, 1.0f, source()) : 0.0f;
        level += (t - level) * (t > level ? 0.5f : 0.12f);
        const int lit = juce::roundToInt (level * 200);
        if (lit != shown) { shown = lit; repaint(); }
    }
    void paint (juce::Graphics& g) override
    {
        const auto r = getLocalBounds().toFloat();
        g.setColour (well()); g.fillRoundedRectangle (r, 3.0f);
        const int n = (int) (r.getHeight() / 7.0f);
        for (int i = 0; i < n; ++i)
        {
            const float yy = r.getBottom() - 4 - (float) (i + 1) * 7 + 2;
            const float f = (float) i / (float) n;
            const bool on = f < level;
            const auto c = f > 0.85f ? Colour (0xffe8412a) : f > 0.65f ? Colour (0xffffb347) : Colour (0xffffd34d);
            g.setColour (on ? c : juce::Colours::white.withAlpha (0.05f));
            g.fillRect (r.getX() + 3, yy, r.getWidth() - 6, 5.0f);
        }
    }
    float level = 0; int shown = -1;
};

// Free-drawn live display (spectra, curves, taps...). paintFn draws in local coordinates.
class Screen final : public juce::Component
{
public:
    std::function<void (juce::Graphics&, juce::Rectangle<float>)> paintFn;
    std::function<void (const juce::MouseEvent&)> onDrag, onDown, onUp;
    std::function<void (const juce::MouseEvent&, const juce::MouseWheelDetails&)> onWheel;
    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat();
        screenFrame (g, r);
        screenGrid (g, r);
        g.saveState(); g.reduceClipRegion (getLocalBounds().reduced (2));
        if (paintFn) paintFn (g, r);
        g.restoreState();
    }
    void mouseDown (const juce::MouseEvent& e) override { if (onDown) onDown (e); }
    void mouseDrag (const juce::MouseEvent& e) override { if (onDrag) onDrag (e); }
    void mouseUp (const juce::MouseEvent& e) override { if (onUp) onUp (e); }
    void mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& w) override { if (onWheel) onWheel (e, w); }
};

// Bat-handle toggle switch for a bool parameter.
class ToggleSwitch final : public juce::Button
{
public:
    ToggleSwitch() : juce::Button ("switch") { setClickingTogglesState (true); }
    void paintButton (juce::Graphics& g, bool, bool) override
    {
        const float x = getWidth() * 0.5f, y = getHeight() * 0.5f;
        const bool up = ! getToggleState();
        g.setGradientFill (juce::ColourGradient (Colour (0xfff5f5f3), x - 3, y - 3, Colour (0xff77746e), x + 9, y + 9, true));
        g.fillEllipse (x - 12, y - 12, 24, 24);
        g.setColour (Colour (0xff2c2c2e)); g.fillEllipse (x - 5, y - 5, 10, 10);
        const float ty = up ? y - 21 : y + 21;
        g.setGradientFill (juce::ColourGradient (Colour (0xfff4f4f2), x - 4, 0, Colour (0xff7b7973), x + 4, 0, false));
        g.drawLine (x, y, x, ty, 6.0f);
        g.setColour (Colour (0xffe6e5e2)); g.fillEllipse (x - 4.5f, ty - 4.5f, 9, 9);
    }
};

// ---------------------------------------------------------------- screen helpers
inline float freqX (juce::Rectangle<float> r, float f, float pad = 10.0f)
{ return r.getX() + pad + (r.getWidth() - 2 * pad) * std::log10 (juce::jlimit (20.0f, 20000.0f, f) / 20.0f) / 3.0f; }
inline void freqLabels (juce::Graphics& g, juce::Rectangle<float> r, std::initializer_list<std::pair<float, const char*>> marks, float pad = 10.0f)
{ for (auto& m : marks) thw::text (g, m.second, juce::jmin (freqX (r, m.first, pad), r.getRight() - 18), r.getBottom() - 10, 9.5f, Colour (0xff8f897f), 7); }
// 256 log-spaced bins 20 Hz .. 20 kHz (tkit::SpectrumAnalyser layout)
inline void spectrum (juce::Graphics& g, juce::Rectangle<float> r, const float* db, int n, Colour c, bool fill, float lo = -84.0f, float hi = 0.0f, float pad = 10.0f)
{
    juce::Path p;
    const float x0 = r.getX() + pad, w = r.getWidth() - 2 * pad, y0 = r.getY() + 14, h = r.getHeight() - 34;
    for (int i = 0; i < n; ++i)
    {
        const float x = x0 + w * (float) i / (float) (n - 1);
        const float y = y0 + h * (1.0f - juce::jlimit (0.0f, 1.0f, (db[i] - lo) / (hi - lo)));
        if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
    }
    if (fill)
    {
        juce::Path f (p); f.lineTo (x0 + w, y0 + h); f.lineTo (x0, y0 + h); f.closeSubPath();
        g.setGradientFill (juce::ColourGradient (c.withAlpha (0.45f), 0, y0, c.withAlpha (0.05f), 0, y0 + h, false));
        g.fillPath (f);
    }
    g.setColour (c); g.strokePath (p, juce::PathStrokeType (1.6f));
}
// curve f(t) t=0..1 -> 0..1 (bottom..top), optional gradient fill
inline void curve (juce::Graphics& g, juce::Rectangle<float> r, std::function<float (float)> f, bool fill)
{
    juce::Path p;
    for (int i = 0; i <= 200; ++i)
    {
        const float t = (float) i / 200.0f, x = r.getX() + t * r.getWidth(), y = r.getBottom() - juce::jlimit (0.0f, 1.0f, f (t)) * r.getHeight();
        if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
    }
    if (fill)
    {
        juce::Path q (p); q.lineTo (r.getRight(), r.getBottom()); q.lineTo (r.getX(), r.getBottom()); q.closeSubPath();
        g.setGradientFill (juce::ColourGradient (orangeLight().withAlpha (0.5f), 0, r.getY(), orangeDeep().withAlpha (0.08f), 0, r.getBottom(), false));
        g.fillPath (q);
    }
    g.setColour (orangeLight()); g.strokePath (p, juce::PathStrokeType (2.0f));
}
inline void glowDot (juce::Graphics& g, float x, float y, float r = 5.0f)
{
    g.setColour (orangeLight().withAlpha (0.3f)); g.fillEllipse (x - r * 2, y - r * 2, r * 4, r * 4);
    g.setColour (Colour (0xffffe0c2)); g.fillEllipse (x - r, y - r, r * 2, r * 2);
}

// Gradient bar meter (yellow -> orange -> red). source() returns 0..1; optional peak line.
class BarMeter final : public juce::Component
{
public:
    std::function<float()> source;
    bool fromTop = false;   // gain reduction style
    void tick()
    {
        const float t = source ? juce::jlimit (0.0f, 1.0f, source()) : 0.0f;
        level += (t - level) * (t > level ? 0.55f : 0.15f);
        peak = juce::jmax (level, peak - 0.006f);
        const int k = juce::roundToInt (level * 300) * 1000 + juce::roundToInt (peak * 300);
        if (k != shown) { shown = k; repaint(); }
    }
    void paint (juce::Graphics& g) override
    {
        const auto r = getLocalBounds().toFloat();
        g.setColour (well()); g.fillRoundedRectangle (r, 3.0f);
        const auto in = r.reduced (3);
        if (fromTop)
        {
            const float h = in.getHeight() * level;
            g.setGradientFill (juce::ColourGradient (Colour (0xffffb347), 0, in.getY(), orangeDeep(), 0, in.getY() + juce::jmax (1.0f, h), false));
            g.fillRect (in.withHeight (h));
            return;
        }
        const float h = in.getHeight() * level;
        juce::ColourGradient gr (Colour (0xffffd34d), 0, in.getBottom(), Colour (0xffe8412a), 0, in.getY(), false);
        gr.addColour (0.6, Colour (0xffff9a2e));
        g.setGradientFill (gr);
        g.fillRect (in.withTop (in.getBottom() - h));
        g.setColour (juce::Colours::white.withAlpha (0.1f)); g.fillRect (in.withWidth (in.getWidth() * 0.3f));
        g.setColour (Colour (0xffffe08a)); g.fillRect (in.getX(), in.getBottom() - in.getHeight() * peak, in.getWidth(), 2.0f);
    }
    float level = 0, peak = 0; int shown = -1;
};

// Value handle that slides along a vertical meter (limiter threshold / ceiling).
class HandleSlider final : public juce::Component
{
public:
    HandleSlider (juce::RangedAudioParameter& p, bool invertedDirection)
        : param (p), inverted (invertedDirection), attachment (p, [this] (float) { repaint(); }) { attachment.sendInitialUpdate(); setMouseCursor (juce::MouseCursor::UpDownResizeCursor); }
    std::function<String()> textFn;
    float norm() const { return param.getValue(); }
    float yFor (float u) const { const float t = 18, b = (float) getHeight() - 18; return inverted ? t + u * (b - t) : b - u * (b - t); }
    void paint (juce::Graphics& g) override
    {
        const float cx = getWidth() * 0.5f, y = yFor (norm());
        juce::Path box; box.addRoundedRectangle (cx - 44, y - 16, 88, 32, 6.0f);
        juce::DropShadow (juce::Colours::black.withAlpha (0.45f), 8, { 0, 3 }).drawForPath (g, box);
        g.setGradientFill (juce::ColourGradient::vertical (Colour (0xff4a4b50), y - 16, Colour (0xff1d1e22), y + 16));
        g.fillPath (box);
        g.setColour (orange().withAlpha (0.85f)); g.strokePath (box, juce::PathStrokeType (1.2f));
        g.setColour (well()); g.fillRoundedRectangle (cx - 33, y - 10, 66, 20, 4.0f);
        thw::text (g, textFn ? textFn() : String(), cx, y + 0.5f, 13.0f, orangeLight(), 8);
        juce::Path l, r;
        l.addTriangle (cx - 45, y, cx - 38, y - 5, cx - 38, y + 5);
        r.addTriangle (cx + 45, y, cx + 38, y - 5, cx + 38, y + 5);
        g.setColour (orange()); g.fillPath (l); g.fillPath (r);
    }
    void mouseDown (const juce::MouseEvent& e) override { startU = norm(); startY = e.position.y; attachment.beginGesture(); }
    void mouseDrag (const juce::MouseEvent& e) override
    {
        const float span = (float) getHeight() - 36;
        float du = (e.position.y - startY) / span * (e.mods.isShiftDown() ? 0.2f : 1.0f);
        if (! inverted) du = -du;
        attachment.setValueAsPartOfGesture (param.convertFrom0to1 (juce::jlimit (0.0f, 1.0f, startU + du)));
    }
    void mouseUp (const juce::MouseEvent&) override { attachment.endGesture(); }
    void mouseDoubleClick (const juce::MouseEvent&) override { attachment.setValueAsCompleteGesture (param.convertFrom0to1 (param.getDefaultValue())); }
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails& w) override
    { attachment.setValueAsCompleteGesture (param.convertFrom0to1 (juce::jlimit (0.0f, 1.0f, norm() + (inverted ? -w.deltaY : w.deltaY) * 0.05f))); }
    void refreshText() { const auto t = textFn ? textFn() : String(); if (t != shownText) { shownText = t; repaint(); } }
private:
    juce::RangedAudioParameter& param; bool inverted;
    juce::ParameterAttachment attachment;
    float startU = 0, startY = 0; String shownText;
};


// Horizontal slider whose handle is the value box (T-Verb style). Click the handle to type a value.
class HSlider final : public juce::Component, public juce::SettableTooltipClient
{
public:
    HSlider (juce::RangedAudioParameter& p, float handleWidth)
        : param (p), hw (handleWidth), attachment (p, [this] (float) { repaint(); })
    { attachment.sendInitialUpdate(); setMouseCursor (juce::MouseCursor::LeftRightResizeCursor); }
    std::function<String()> textFn;
    std::function<void (const String&)> onType;
    float norm() const { return param.getValue(); }
    float trackW() const { return (float) getWidth() - 20.0f; }
    float handleX() const { return juce::jlimit (0.0f, (float) getWidth() - hw, 10.0f + trackW() * norm() - hw * 0.5f); }
    void paint (juce::Graphics& g) override
    {
        const float y = 16.0f, w = trackW(), fx = 10.0f + w * norm();
        g.setColour (Colour (0xff070708)); g.fillRoundedRectangle (10, y - 3, w, 6, 3.0f);
        g.setColour (juce::Colours::white.withAlpha (0.08f)); g.drawLine (13, y + 3.5f, 7 + w, y + 3.5f, 1.0f);
        if (fx > 12.0f)
        {
            g.setGradientFill (juce::ColourGradient (orangeDeep().withAlpha (0.8f), 10, 0, orangeLight(), fx, 0, false));
            g.fillRoundedRectangle (11, y - 2, fx - 12, 4, 2.0f);
        }
        g.setColour (dimDark());
        for (int i = 0; i <= 10; ++i) g.fillRect (10 + w * (float) i / 10.0f - 0.5f, y + 8, 1.0f, i % 5 ? 4.0f : 7.0f);
        if (editor) return;
        const float hx = handleX();
        juce::Path box; box.addRoundedRectangle (hx, y - 13, hw, 26, 6.0f);
        juce::DropShadow (juce::Colours::black.withAlpha (0.45f), 7, { 0, 3 }).drawForPath (g, box);
        g.setGradientFill (juce::ColourGradient::vertical (Colour (0xff4a4b50), y - 13, Colour (0xff1d1e22), y + 13));
        g.fillPath (box);
        g.setColour (orange().withAlpha (0.85f)); g.strokePath (box, juce::PathStrokeType (1.1f));
        thw::text (g, shownText, hx + hw * 0.5f, y + 0.5f, 12.0f, orangeLight(), 8);
    }
    void mouseDown (const juce::MouseEvent& e) override { startU = norm(); startX = e.position.x; attachment.beginGesture(); }
    void mouseDrag (const juce::MouseEvent& e) override
    {
        const float du = (e.position.x - startX) / trackW() * (e.mods.isShiftDown() ? 0.2f : 1.0f);
        attachment.setValueAsPartOfGesture (param.convertFrom0to1 (juce::jlimit (0.0f, 1.0f, startU + du)));
    }
    void mouseUp (const juce::MouseEvent& e) override
    {
        attachment.endGesture();
        if (e.mouseWasDraggedSinceMouseDown() || ! onType || e.getNumberOfClicks() > 1) return;
        const float hx = handleX();
        if (e.position.x < hx || e.position.x > hx + hw) return;
        editor = std::make_unique<juce::TextEditor>();
        editor->setLookAndFeel (&look());
        editor->setFont (font (12.0f, 7));
        editor->setJustification (juce::Justification::centred);
        editor->setText (shownText.upToFirstOccurrenceOf (" ", false, false), false);
        editor->setSelectAllWhenFocused (true);
        editor->onReturnKey = [this] { const auto t = editor->getText(); close(); if (onType) onType (t); };
        editor->onEscapeKey = [this] { close(); };
        editor->onFocusLost = [this] { close(); };
        addAndMakeVisible (*editor);
        editor->setBounds (juce::roundToInt (hx), 3, juce::roundToInt (hw), 26);
        editor->grabKeyboardFocus();
        repaint();
    }
    void mouseDoubleClick (const juce::MouseEvent&) override { attachment.setValueAsCompleteGesture (param.convertFrom0to1 (param.getDefaultValue())); }
    void mouseWheelMove (const juce::MouseEvent&, const juce::MouseWheelDetails& w) override
    { attachment.setValueAsCompleteGesture (param.convertFrom0to1 (juce::jlimit (0.0f, 1.0f, norm() + (w.deltaX != 0 ? w.deltaX : w.deltaY) * 0.05f))); }
    void refreshText() { const auto t = textFn ? textFn() : paramText (param); if (t != shownText) { shownText = t; repaint(); } }
private:
    void close() { juce::MessageManager::callAsync ([safe = juce::Component::SafePointer<HSlider> (this)] { if (safe) { safe->editor.reset(); safe->repaint(); } }); }
    juce::RangedAudioParameter& param; float hw;
    juce::ParameterAttachment attachment;
    float startU = 0, startX = 0; String shownText;
    std::unique_ptr<juce::TextEditor> editor;
};


// Grid of lit buttons for a choice parameter (e.g. reverb types).
class ChoiceGrid final : public juce::Component
{
public:
    ChoiceGrid (juce::RangedAudioParameter& p, juce::StringArray l, int columns, float cellW, float cellH, float gapX, float gapY)
        : labels (std::move (l)), cols (columns), cw (cellW), ch (cellH), gx (gapX), gy (gapY),
          attachment (p, [this] (float v) { index = juce::roundToInt (v); repaint(); }) { attachment.sendInitialUpdate(); }
    void paint (juce::Graphics& g) override
    {
        for (int i = 0; i < labels.size(); ++i)
        {
            const auto r = cell (i);
            const bool on = i == index;
            g.setColour (on ? Colour (0xff3b2a1a) : Colour (0xff1d1e21)); g.fillRoundedRectangle (r, 5.0f);
            g.setColour (on ? orange().withAlpha (0.9f) : juce::Colours::black.withAlpha (0.5f)); g.drawRoundedRectangle (r.reduced (0.5f), 5.0f, 1.0f);
            thw::text (g, labels[i], r.getCentreX(), r.getCentreY() + 0.5f, 10.5f, on ? orangeLight() : dim(), 8);
        }
    }
    void mouseDown (const juce::MouseEvent& e) override
    {
        for (int i = 0; i < labels.size(); ++i)
            if (cell (i).contains (e.position)) { attachment.setValueAsCompleteGesture ((float) i); return; }
    }
private:
    juce::Rectangle<float> cell (int i) const { return { (float) (i % cols) * (cw + gx), (float) (i / cols) * (ch + gy), cw, ch }; }
    juce::StringArray labels; int cols; float cw, ch, gx, gy; int index = 0;
    juce::ParameterAttachment attachment;
};

// ---------------------------------------------------------------- the editor
class Editor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    struct Info { String name, subtitle; int width = 980, height = 600; String presetExtension = "tfxpreset"; juce::StringArray legacyNames = {}; };
    static Info branded (Info i) { i.name = brandName (i.name); return i; }

    Editor (juce::AudioProcessor& p, juce::AudioProcessorValueTreeState& s, tak::license::PluginLicense& l, Info i)
        : juce::AudioProcessorEditor (p), proc (p), state (s), license (l), info (branded (std::move (i)))
    {
        setLookAndFeel (&look());
        license.ensureAutomaticTrial();
        face.owner = this;
        addAndMakeVisible (face);
        face.setSize (info.width, info.height);
        presetBox.owner = this;
        face.addAndMakeVisible (presetBox);
        presetBox.setBounds (info.width - 300, 15, 200, 28);
        face.addAndMakeVisible (gear);
        gear.setBounds (info.width - 78, 13, 32, 32);
        gear.onClick = [this] { showSettingsMenu(); };
        badge.owner = this;
        badge.setComponentID ("licenseBadge");
        face.addAndMakeVisible (badge);
        badge.setBounds (info.width - 178, info.height - 34, 156, 24);
        tooltip.setLookAndFeel (&look());
    }
    ~Editor() override
    {
        stopTimer();
        if (sizeReady && info.width > 0)
        {
            const double scale = (double) getWidth() / (double) info.width;
            if (std::abs (scale - uiSettings().getDoubleValue (sizeKey(), (double) defaultScale)) > 0.005)
            {
                uiSettings().setValue (sizeKey(), scale);
                uiSettings().saveIfNeeded();
            }
        }
        for (auto& v : selects) v->setLookAndFeel (nullptr);
        setLookAndFeel (nullptr);
    }

    // ---- preset source: host programs unless a plugin overrides these
    std::function<int()> presetCount = [this] { return proc.getNumPrograms(); };
    std::function<String (int)> presetName = [this] (int i) { return proc.getProgramName (i); };
    std::function<int()> currentPreset = [this] { return proc.getCurrentProgram(); };
    std::function<void (int)> loadPreset = [this] (int i) { proc.setCurrentProgram (i); };
    std::function<String()> presetLabel;   // optional override of the shown name

    void openLicensePanel() { showLicensePanel(); }
    bool isLicensedNow() const { const auto s = license.snapshot(); return s.allowed || s.fingerprint.isEmpty(); }

protected:
    // ---- layout API (design coordinates, same as the mock-ups) ----------------------------
    juce::RangedAudioParameter* param (const String& id) const { return state.getParameter (id); }
    void plate (std::function<void (juce::Graphics&)> f) { plateOps.push_back (std::move (f)); }
    void section (float x, float y, float w, float h, const String& title = {})
    { plate ([=] (juce::Graphics& g) { sectionFrame (g, { x, y, w, h }, title); }); }
    void caption (const String& s, float x, float y, float size = 11.0f, float track = 1.5f, int align = 0)
    { plate ([=] (juce::Graphics& g) { engrave (g, s, x, y, size, track, align); }); }
    void infoItem (const String& label, std::function<String()> value) { infos.push_back ({ label, std::move (value), {} }); }

    ValueBox& valueBox (juce::RangedAudioParameter* p, juce::Rectangle<int> r, float size, std::function<String()> fmt = {}, std::function<float (const String&)> parse = {})
    {
        auto v = std::make_unique<ValueBox>();
        v->fontSize = size;
        if (p)
        {
            v->textFn = fmt ? fmt : [p] { return paramText (*p); };
            v->onType = [p, parse] (const String& t)
            {
                const float norm = parse ? p->convertTo0to1 (parse (t)) : p->getValueForText (t);
                p->beginChangeGesture(); p->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, norm)); p->endChangeGesture();
            };
        }
        else v->textFn = fmt;
        face.addAndMakeVisible (*v);
        v->setBounds (r);
        values.push_back (std::move (v));
        return *values.back();
    }

    Knob& knobFor (const String& id, float cx, float cy, float R, float cap, bool arc = true)
    {
        auto k = std::make_unique<Knob> (R, cap, arc);
        const int half = (int) std::ceil (juce::jmax (R * 1.45f, R + 12.0f));
        face.addAndMakeVisible (*k);
        k->setBounds (juce::roundToInt (cx) - half, juce::roundToInt (cy) - half, half * 2, half * 2);
        if (auto* p = param (id))
        {
            sliderAtt.push_back (std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (state, id, *k));
            k->setDoubleClickReturnValue (true, p->convertFrom0to1 (p->getDefaultValue()));
            k->setTooltip (p->getName (64));
            covered.insert (id);
        }
        knobs.push_back (std::move (k));
        return *knobs.back();
    }
    // big knob: printed scale, caption and value box under it (JS: HW.big)
    Knob& big (const String& id, float cx, float cy, float R, const String& label, juce::StringArray scale,
               std::function<String()> fmt = {}, std::function<float (const String&)> parse = {})
    {
        plate ([=] (juce::Graphics& g) { knobScale (g, cx, cy, R, scale); engrave (g, label, cx, cy + R + 44, 12.5f, 2.5f); });
        auto& k = knobFor (id, cx, cy, R, 0.6f);
        valueBox (param (id), { juce::roundToInt (cx - 42), juce::roundToInt (cy + R + 56), 84, 24 }, 13.0f, fmt, parse);
        return k;
    }
    // small knob with min/max and value box (JS: HW.small)
    Knob& small (const String& id, float cx, float cy, float R, const String& label, const String& minL = {}, const String& maxL = {},
                 std::function<String()> fmt = {}, std::function<float (const String&)> parse = {}, float lcdW = 68.0f)
    {
        plate ([=] (juce::Graphics& g)
        {
            if (minL.isNotEmpty() || maxL.isNotEmpty())
            {
                const auto a = polar (cx, cy, R + 12, knobAngle (0)), b = polar (cx, cy, R + 12, knobAngle (1));
                thw::text (g, minL, a.x, a.y + 6, 8.5f, dim(), 8);
                thw::text (g, maxL, b.x, b.y + 6, 8.5f, dim(), 8);
            }
            engrave (g, label, cx, cy + R + 46, 9.5f, 1.2f);
        });
        auto& k = knobFor (id, cx, cy, R, 0.58f);
        valueBox (param (id), { juce::roundToInt (cx - lcdW * 0.5f), juce::roundToInt (cy + R + 14), juce::roundToInt (lcdW), 20 }, lcdW < 60 ? 10.0f : 11.5f, fmt, parse);
        return k;
    }
    struct RowItem { String id, label, minL, maxL; std::function<String()> fmt = {}; };
    void row (float x0, float y, float dx, float R, std::vector<RowItem> items)
    {
        for (size_t i = 0; i < items.size(); ++i)
            small (items[i].id, x0 + (float) i * dx, y, R, items[i].label, items[i].minL, items[i].maxL, items[i].fmt);
    }
    LedButton& button (const String& id, float x, float y, float w, const String& label, float h = 26)
    {
        auto b = std::make_unique<LedButton> (label);
        face.addAndMakeVisible (*b);
        b->setBounds (juce::roundToInt (x), juce::roundToInt (y), juce::roundToInt (w), juce::roundToInt (h));
        if (id.isNotEmpty() && param (id))
        {
            buttonAtt.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (state, id, *b));
            b->setTooltip (param (id)->getName (64));
            covered.insert (id);
        }
        else { b->setClickingTogglesState (false); b->momentary = true; }
        buttons.push_back (std::move (b));
        return *buttons.back();
    }
    Segmented& seg (const String& id, float x, float y, juce::StringArray labels, float w, const String& title = {})
    {
        if (title.isNotEmpty()) caption (title, x + (float) labels.size() * w * 0.5f, y - 14, 10.0f);
        auto s = std::make_unique<Segmented> (*param (id), labels, w);
        face.addAndMakeVisible (*s);
        s->setBounds (juce::roundToInt (x), juce::roundToInt (y), juce::roundToInt (w * (float) labels.size()), 26);
        covered.insert (id);
        segs.push_back (std::move (s));
        return *segs.back();
    }
    Select& select (const String& id, float x, float y, float w, const String& title = {}, juce::StringArray labels = {})
    {
        if (title.isNotEmpty()) caption (title, x + w * 0.5f, y - 14, 10.0f);
        auto c = std::make_unique<Select>();
        if (auto* ch = dynamic_cast<juce::AudioParameterChoice*> (param (id)))
            c->addItemList (labels.isEmpty() ? ch->choices : labels, 1);
        face.addAndMakeVisible (*c);
        c->setBounds (juce::roundToInt (x), juce::roundToInt (y), juce::roundToInt (w), 28);
        comboAtt.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (state, id, *c));
        covered.insert (id);
        selects.push_back (std::move (c));
        return *selects.back();
    }
    // vertical fader; marks are parameter values printed beside the track
    Fader& fader (const String& id, float x, float top, float bot, const String& label, std::vector<std::pair<String, float>> marks,
                  std::function<String()> fmt = {}, bool lcdAbove = true)
    {
        auto* p = param (id);
        plate ([=] (juce::Graphics& g)
        {
            if (label.isNotEmpty()) engrave (g, label, x, top - 44, 11.0f, 2.0f);
            for (auto& m : marks)
            {
                const float u = p ? p->convertTo0to1 (m.second) : 0.0f;
                const float yy = bot - (bot - top) * u;
                g.setColour (cream().withAlpha (0.8f)); g.fillRect (x + 12, yy - 0.7f, 10.0f, 1.4f);
                thw::text (g, m.first, x + 27, yy, 10.0f, cream(), 8, -1);
            }
        });
        auto f = std::make_unique<Fader>();
        face.addAndMakeVisible (*f);
        f->setBounds (juce::roundToInt (x - 22), juce::roundToInt (top - 18), 44, juce::roundToInt (bot - top + 36));
        if (p)
        {
            sliderAtt.push_back (std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (state, id, *f));
            f->setDoubleClickReturnValue (true, p->convertFrom0to1 (p->getDefaultValue()));
            f->setTooltip (p->getName (64));
            covered.insert (id);
        }
        if (lcdAbove) valueBox (p, { juce::roundToInt (x - 38), juce::roundToInt (top - 34), 76, 22 }, 12.0f, fmt);
        faders.push_back (std::move (f));
        return *faders.back();
    }
    VuMeter& vu (float cx, float cy, float w, float h, const String& cap, std::function<float()> src)
    {
        auto v = std::make_unique<VuMeter>();
        v->caption = cap; v->source = std::move (src);
        face.addAndMakeVisible (*v);
        v->setBounds (juce::roundToInt (cx - w * 0.5f), juce::roundToInt (cy - h * 0.5f), juce::roundToInt (w), juce::roundToInt (h));
        plate ([=] (juce::Graphics& g)
        {
            juce::Path s; s.addRoundedRectangle (cx - w * 0.5f, cy - h * 0.5f, w, h, 10.0f);
            juce::DropShadow (juce::Colours::black.withAlpha (0.5f), 14, { 0, 6 }).drawForPath (g, s);
        });
        vus.push_back (std::move (v));
        return *vus.back();
    }
    LedMeter& led (float x, float y, float w, float h, std::function<float()> src, const String& label = {})
    {
        auto m = std::make_unique<LedMeter>();
        m->source = std::move (src);
        face.addAndMakeVisible (*m);
        m->setBounds (juce::roundToInt (x), juce::roundToInt (y), juce::roundToInt (w), juce::roundToInt (h));
        if (label.isNotEmpty()) plate ([=] (juce::Graphics& g) { thw::text (g, label, x + w * 0.5f, y + h + 12, 8.5f, dim(), 8, 0, 1.0f); });
        leds.push_back (std::move (m));
        return *leds.back();
    }
    Screen& screen (float x, float y, float w, float h, std::function<void (juce::Graphics&, juce::Rectangle<float>)> fn)
    {
        auto s = std::make_unique<Screen>();
        s->paintFn = std::move (fn);
        face.addAndMakeVisible (*s);
        s->setBounds (juce::roundToInt (x), juce::roundToInt (y), juce::roundToInt (w), juce::roundToInt (h));
        screens.push_back (std::move (s));
        return *screens.back();
    }
    ToggleSwitch& toggle (const String& id, float x, float y, const String& topLabel, const String& bottomLabel)
    {
        plate ([=] (juce::Graphics& g)
        {
            engrave (g, topLabel, x, y - 40, 10.0f, 1.5f);
            engrave (g, bottomLabel, x, y + 42, 10.0f, 1.5f);
        });
        auto t = std::make_unique<ToggleSwitch>();
        face.addAndMakeVisible (*t);
        t->setBounds (juce::roundToInt (x - 16), juce::roundToInt (y - 30), 32, 60);
        buttonAtt.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (state, id, *t));
        covered.insert (id);
        toggles.push_back (std::move (t));
        return *toggles.back();
    }
    void markCovered (const String& id) { covered.insert (id); }
    // factory presets kept by the plugin itself (index tracked here)
    void useFactoryPresets (int count, std::function<String (int)> name, std::function<void (int)> load)
    {
        presetCount = [count] { return count; };
        presetName = std::move (name);
        currentPreset = [this] { return factoryIndex; };
        loadPreset = [this, load] (int i) { factoryIndex = i; load (i); };
    }
    int factoryIndex = -1;
    static float dbfsToVu (float db) { return db + 18.0f; }
    BarMeter& bar (float x, float y, float w, float h, std::function<float()> src, bool fromTop = false)
    {
        auto m = std::make_unique<BarMeter>();
        m->source = std::move (src); m->fromTop = fromTop;
        face.addAndMakeVisible (*m);
        m->setBounds (juce::roundToInt (x), juce::roundToInt (y), juce::roundToInt (w), juce::roundToInt (h));
        bars.push_back (std::move (m));
        return *bars.back();
    }
    // horizontal value-handle slider: caption above-left, track from x to x + w at y
    HSlider& hslider (const String& id, float x, float y, float w, const String& label,
                      std::function<String()> fmt = {}, std::function<float (const String&)> parse = {}, float handleW = 78.0f)
    {
        auto* p = param (id);
        if (label.isNotEmpty()) plate ([=] (juce::Graphics& g) { engrave (g, label, x, y - 26, 10.5f, 1.2f, -1); });
        auto h = std::make_unique<HSlider> (*p, handleW);
        h->textFn = std::move (fmt);
        h->onType = [p, parse] (const String& t)
        {
            const float norm = parse ? p->convertTo0to1 (parse (t)) : p->getValueForText (t);
            p->beginChangeGesture(); p->setValueNotifyingHost (juce::jlimit (0.0f, 1.0f, norm)); p->endChangeGesture();
        };
        h->setTooltip (p->getName (64));
        face.addAndMakeVisible (*h);
        h->setBounds (juce::roundToInt (x - 10), juce::roundToInt (y - 16), juce::roundToInt (w + 20), 34);
        covered.insert (id);
        hsliders.push_back (std::move (h));
        return *hsliders.back();
    }
    ChoiceGrid& grid (const String& id, float x, float y, juce::StringArray labels, int cols, float cw, float ch, float gx, float gy)
    {
        auto c = std::make_unique<ChoiceGrid> (*param (id), labels, cols, cw, ch, gx, gy);
        face.addAndMakeVisible (*c);
        const int rows = (labels.size() + cols - 1) / cols;
        c->setBounds (juce::roundToInt (x), juce::roundToInt (y), juce::roundToInt ((float) cols * (cw + gx)), juce::roundToInt ((float) rows * (ch + gy)));
        covered.insert (id);
        grids.push_back (std::move (c));
        return *grids.back();
    }
    HandleSlider& handle (const String& id, float cx, float top, float bot, bool inverted, std::function<String()> fmt)
    {
        auto h = std::make_unique<HandleSlider> (*param (id), inverted);
        h->textFn = std::move (fmt);
        face.addAndMakeVisible (*h);
        h->setBounds (juce::roundToInt (cx - 48), juce::roundToInt (top - 18), 96, juce::roundToInt (bot - top + 36));
        covered.insert (id);
        handles.push_back (std::move (h));
        return *handles.back();
    }
    // big knob whose printed labels sit at given normalised positions
    Knob& bigAt (const String& id, float cx, float cy, float R, const String& label, std::vector<std::pair<String, float>> marks,
                 std::function<String()> fmt = {}, std::function<float (const String&)> parse = {})
    {
        plate ([=] (juce::Graphics& g)
        {
            for (int i = 0; i <= 40; ++i)
            {
                const float a = knobAngle ((float) i / 40.0f);
                g.setColour (cream().withAlpha (0.55f));
                g.drawLine (juce::Line<float> (polar (cx, cy, R + 6, a), polar (cx, cy, R + 9, a)), 0.8f);
            }
            for (auto& m : marks)
            {
                const float a = knobAngle (m.second);
                g.setColour (cream().withAlpha (0.9f));
                g.drawLine (juce::Line<float> (polar (cx, cy, R + 6, a), polar (cx, cy, R + 13, a)), 1.6f);
                const auto p = polar (cx, cy, R + 24, a);
                thw::text (g, m.first, p.x, p.y, 10.5f, cream(), 8);
            }
            engrave (g, label, cx, cy + R + 44, 12.5f, 2.5f);
        });
        auto& k = knobFor (id, cx, cy, R, 0.6f);
        valueBox (param (id), { juce::roundToInt (cx - 42), juce::roundToInt (cy + R + 56), 84, 24 }, 13.0f, fmt, parse);
        return k;
    }
    // labels taken from the parameter's own text at evenly spaced positions
    std::vector<std::pair<String, float>> marksFromParam (const String& id, int n, bool everyOther = false)
    {
        auto compact = [] (double v)
        {
            const double a = std::abs (v);
            if (a >= 10.0) return String (juce::roundToInt (v));
            const double r = std::round (v * 10.0) / 10.0;
            return std::abs (r - std::round (r)) < 1.0e-6 ? String ((int) std::round (r)) : String (r, 1);
        };
        std::vector<std::pair<String, float>> m;
        if (auto* p = param (id))
        {
            bool bipolar = false;
            for (int i = 0; i < n; ++i)
            {
                const auto t = p->getText ((float) i / (float) (n - 1), 16).trim();
                if (t.startsWithChar ('-')) bipolar = true;
            }
            for (int i = 0; i < n; ++i)
            {
                if (everyOther && (i % 2) != 0) continue;
                const float u = (float) i / (float) (n - 1);
                auto t = p->getText (u, 16).trim();
                const auto num = t.initialSectionContainingOnly ("0123456789.-+");
                const auto rest = t.substring (num.length()).trim();
                if (num.isNotEmpty() && num != "-" && num != "+")
                {
                    const double v = num.getDoubleValue();
                    if (rest.startsWithIgnoreCase ("k")) t = compact (v) + "k";
                    else if (std::abs (v) >= 1000.0) t = compact (v / 1000.0) + "k";
                    else t = (bipolar && v > 0.0 ? "+" : "") + compact (v);
                }
                else t = t.upToFirstOccurrenceOf (" ", false, false);
                m.push_back ({ t, u });
            }
        }
        return m;
    }
    // formatter helpers
    std::function<String()> unit (const String& id, const String& u) { auto* p = param (id); return [p, u] { return p ? paramText (*p, u) : String(); }; }
    std::function<String()> percent01 (const String& id) { auto* p = param (id); return [p] { return p ? String (juce::roundToInt (p->convertFrom0to1 (p->getValue()) * 100.0f)) + " %" : String(); }; }
    static float parsePercent01 (const String& t) { return t.getFloatValue() / 100.0f; }
    float value (const String& id) const { if (auto* v = state.getRawParameterValue (id)) return v->load(); return 0.0f; }

    // call at the end of the derived constructor
    void finish()
    {
        juce::StringArray extra;
        for (auto* p : proc.getParameters())
            if (auto* wp = dynamic_cast<juce::AudioProcessorParameterWithID*> (p))
                if (! covered.count (wp->paramID) && state.getParameter (wp->paramID) != nullptr) extra.add (wp->paramID);
        moreIds = extra;
        if (! moreIds.isEmpty())
        {
            face.addAndMakeVisible (more);
            more.setButtonText (vn ("THÊM"));
            more.setBounds (info.width - 264, info.height - 34, 76, 24);
            more.setTooltip (vn ("Các nút khác của plugin"));
            more.onClick = [this] { showMore(); };
        }
        setResizable (true, true);
        if (auto* c = getConstrainer()) c->setFixedAspectRatio ((double) info.width / info.height);
        setResizeLimits (info.width / 2, info.height / 2, info.width * 3 / 2, info.height * 3 / 2);
        // v1.2.1: open smaller (85 %) and never taller/wider than the screen, so the
        // DAW's plugin window always keeps its title bar on screen and can be dragged.
        // The size the user drags to is remembered per plugin.
        const float scale = juce::jlimit (0.5f, fitScale(), (float) uiSettings().getDoubleValue (sizeKey(), (double) defaultScale));
        setSize (juce::roundToInt ((float) info.width * scale), juce::roundToInt ((float) info.height * scale));
        sizeReady = true;
        syncPreset();
        timerCallback();
        startTimerHz (30);
    }
    // per-frame hook for plugin-specific animation
    virtual void tick() {}

    static constexpr float defaultScale = 0.85f;
    // Largest scale that fits the work area of the screen (minus room for the DAW's title bar and toolbar).
    float fitScale() const
    {
        juce::Rectangle<int> area (1280, 680);
        if (auto* d = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay()) area = d->userArea;
        const float sw = (float) (area.getWidth() - 40) / (float) info.width;
        const float sh = (float) (area.getHeight() - 140) / (float) info.height;
        return juce::jlimit (0.5f, 1.5f, juce::jmin (sw, sh));
    }
    String sizeKey() const { return "scale_" + info.name.removeCharacters (" "); }
    static juce::PropertiesFile& uiSettings()
    {
        static auto* file = []
        {
            juce::PropertiesFile::Options o;
            o.applicationName = "UI"; o.filenameSuffix = ".settings"; o.folderName = "T Studio";
            o.osxLibrarySubFolder = "Application Support"; o.storageFormat = juce::PropertiesFile::storeAsXML;
            o.millisecondsBeforeSaving = -1;   // saved explicitly when an editor closes
            return new juce::PropertiesFile (o);   // never destroyed at DLL unload
        }();
        return *file;
    }
    bool sizeReady = false;

    void resized() override
    {
        const float s = (float) getWidth() / (float) info.width;
        face.setTransform (juce::AffineTransform::scale (s));
        if (overlay)
        {
            overlay->setBounds (getLocalBounds());
            layoutOverlay();
        }
    }

    juce::AudioProcessor& proc;
    juce::AudioProcessorValueTreeState& state;
    tak::license::PluginLicense& license;
    Info info;

    // ---------------------------------------------------------------- internals
    struct Face final : public juce::Component
    {
        Editor* owner = nullptr;
        juce::Image plateImage;
        void paint (juce::Graphics& g) override
        {
            const float scale = physicalScale (g);
            const int pw = juce::roundToInt ((float) getWidth() * scale), ph = juce::roundToInt ((float) getHeight() * scale);
            if (plateImage.getWidth() != pw || plateImage.getHeight() != ph)
            {
                plateImage = juce::Image (juce::Image::ARGB, juce::jmax (1, pw), juce::jmax (1, ph), true, juce::SoftwareImageType());
                juce::Graphics pg (plateImage);
                pg.addTransform (juce::AffineTransform::scale (scale));
                owner->paintPlate (pg);
            }
            g.setImageResamplingQuality (juce::Graphics::lowResamplingQuality);
            g.drawImage (plateImage, getLocalBounds().toFloat());
            owner->paintDynamicFace (g);
        }
    };
    struct PresetBox final : public juce::Component
    {
        Editor* owner = nullptr; String name;
        void paint (juce::Graphics& g) override
        {
            const auto r = getLocalBounds().toFloat();
            g.setColour (Colour (0xff0c0d10)); g.fillRoundedRectangle (r, 6.0f);
            g.setColour (juce::Colours::white.withAlpha (0.08f)); g.drawRoundedRectangle (r.reduced (0.5f), 6.0f, 1.0f);
            {
                // long preset names shrink, then get cut with an ellipsis, so they never run into the arrows
                const float room = r.getWidth() - 46.0f;
                float sz = 12.0f;
                while (sz > 9.5f && juce::GlyphArrangement::getStringWidth (font (sz, 7), name) > room) sz -= 0.5f;
                String shown = name;
                while (shown.length() > 3 && juce::GlyphArrangement::getStringWidth (font (sz, 7), shown + "...") > room) shown = shown.dropLastCharacters (1);
                if (shown != name) shown = shown.trimEnd() + "...";
                thw::text (g, shown, r.getCentreX(), r.getCentreY() + 0.5f, sz, creamBright(), 7);
            }
            thw::text (g, vn ("‹"), 12, r.getCentreY(), 16.0f, orange(), 8);
            thw::text (g, vn ("›"), r.getRight() - 12, r.getCentreY(), 16.0f, orange(), 8);
        }
        void mouseUp (const juce::MouseEvent& e) override
        {
            if (e.position.x < 26) owner->stepPreset (-1);
            else if (e.position.x > getWidth() - 26) owner->stepPreset (1);
            else owner->showPresetMenu();
        }
    };
    struct Gear final : public juce::Button
    {
        Gear() : juce::Button ("gear") { setMouseCursor (juce::MouseCursor::PointingHandCursor); }
        void paintButton (juce::Graphics& g, bool over, bool) override
        {
            const float cx = getWidth() * 0.5f, cy = getHeight() * 0.5f;
            juce::Path p;
            for (int i = 0; i < 32; ++i)
            {
                const float a = (float) i / 32.0f * juce::MathConstants<float>::twoPi - 0.19f;
                const bool t = (i % 4 == 1 || i % 4 == 2); const float r = t ? 10.0f : 7.6f;
                const juce::Point<float> pt (cx + r * std::cos (a), cy + r * std::sin (a));
                if (i == 0) p.startNewSubPath (pt); else p.lineTo (pt);
            }
            p.closeSubPath(); p.addEllipse (cx - 3.6f, cy - 3.6f, 7.2f, 7.2f); p.setUsingNonZeroWinding (false);
            g.setColour (over ? orangeLight() : orange()); g.fillPath (p);
        }
    };
    struct Badge final : public juce::Component, public juce::SettableTooltipClient
    {
        Editor* owner = nullptr; String text_; Colour dot = Colour (0xff7bd88f);
        Badge() { setMouseCursor (juce::MouseCursor::PointingHandCursor); setTooltip (vn ("Bản quyền & Kích hoạt")); }
        void paint (juce::Graphics& g) override
        {
            const auto r = getLocalBounds().toFloat().reduced (0.5f);
            g.setColour (Colour (0xe614161a)); g.fillRoundedRectangle (r, 12.0f);
            g.setColour (orange().withAlpha (0.5f)); g.drawRoundedRectangle (r, 12.0f, 1.0f);
            g.setColour (dot); g.fillEllipse (14 - 3.5f, r.getCentreY() - 3.5f, 7, 7);
            thw::text (g, text_, r.getCentreX() + 7, r.getCentreY() + 0.5f, 9.5f, creamBright(), 8, 0, 1.0f);
        }
        void mouseUp (const juce::MouseEvent&) override { owner->showLicensePanel(); }
    };
    struct MoreButton final : public juce::Button
    {
        MoreButton() : juce::Button ("more") {}
        void paintButton (juce::Graphics& g, bool over, bool) override
        {
            const auto r = getLocalBounds().toFloat().reduced (0.5f);
            g.setColour (Colour (0xff202124)); g.fillRoundedRectangle (r, 12.0f);
            g.setColour (orange().withAlpha (over ? 0.9f : 0.5f)); g.drawRoundedRectangle (r, 12.0f, 1.0f);
            thw::text (g, getButtonText(), r.getCentreX(), r.getCentreY() + 0.5f, 9.5f, orangeLight(), 8, 0, 1.2f);
        }
    };

    void paintPlate (juce::Graphics& g)
    {
        const float W = (float) info.width, H = (float) info.height;
        juce::Path outline; outline.addRoundedRectangle (0, 0, W, H, 14.0f);
        g.saveState(); g.reduceClipRegion (outline);
        brushed (g, { 0, 0, W, H });
        g.setGradientFill (juce::ColourGradient::vertical (railTop(), 0, railBot(), 58));
        g.fillRect (0.0f, 0.0f, W, 58.0f);
        g.setColour (orange().withAlpha (0.85f)); g.fillRect (0.0f, 58.0f, W, 2.0f);
        logo (g, 36, 29, 17);
        thw::text (g, brandLogo(), 62, 29, 12.0f, orange(), 8, -1, 2.5f);
        thw::text (g, info.name.toUpperCase(), W * 0.5f, 24, 22.0f, Colour (0xfff3efe8), 8, 0, 5.0f);
        thw::text (g, info.subtitle.toUpperCase(), W * 0.5f, 44, 9.0f, Colour (0xff8f897f), 8, 0, 3.0f);
        screw (g, 14, 76); screw (g, W - 14, 76); screw (g, 14, H - 58); screw (g, W - 14, H - 58);
        g.setGradientFill (juce::ColourGradient::vertical (Colour (0xff232428), H - 44, Colour (0xff141518), H));
        g.fillRect (0.0f, H - 44, W, 44.0f);
        g.setColour (orange().withAlpha (0.6f)); g.fillRect (0.0f, H - 44, W, 1.5f);
        for (auto& op : plateOps) op (g);
        g.restoreState();
    }
    void paintDynamicFace (juce::Graphics& g)
    {
        // bottom-rail info values
        const float H = (float) info.height;
        float x = 24;
        for (auto& i : infos)
        {
            const auto lf = font (9.0f, 8, 2.0f), vf = font (11.0f, 8);
            thw::text (g, i.label, x, H - 22, 9.0f, Colour (0xff8f897f), 8, -1, 2.0f);
            const float lw = textWidth (lf, i.label);
            thw::text (g, i.shown, x + lw + 10, H - 22, 11.0f, creamBright(), 8, -1);
            x += lw + textWidth (vf, i.shown) + 40;
        }
    }

    void timerCallback() override
    {
        tick();
        for (auto& v : values) v->refresh();
        for (auto& v : vus) v->tick();
        for (auto& m : leds) m->tick();
        for (auto& m : bars) m->tick();
        for (auto& h : handles) h->refreshText();
        for (auto& h : hsliders) h->refreshText();
        for (auto& s : screens) if (s->isShowing()) s->repaint();
        bool infoChanged = false;
        for (auto& i : infos) { const auto t = i.value ? i.value() : String(); if (t != i.shown) { i.shown = t; infoChanged = true; } }
        if (infoChanged) face.repaint (0, info.height - 44, info.width - 270, 44);
        if (presetLabelNow() != presetBox.name) syncPreset();
        const auto snap = license.snapshot();
        String status = vn ("ĐÃ KÍCH HOẠT"); Colour dot (0xff7bd88f);
        if (! snap.allowed) { status = snap.trialStarted ? vn ("HẾT HẠN DÙNG THỬ") : vn ("CHƯA KÍCH HOẠT"); dot = red(); }
        else if (! snap.activated && snap.trialStarted) { status = vn ("DÙNG THỬ · ") + String (snap.daysLeft) + vn (" NGÀY"); dot = orange(); }
        if (status != badge.text_ || dot != badge.dot) { badge.text_ = status; badge.dot = dot; badge.repaint(); }
    }

    String presetLabelNow()
    {
        if (customPreset.isNotEmpty()) return customPreset;
        if (presetLabel) return presetLabel();
        const int n = presetCount ? presetCount() : 0, i = currentPreset ? currentPreset() : -1;
        auto s = (n > 0 && juce::isPositiveAndBelow (i, n)) ? presetName (i) : String();
        return s.isNotEmpty() ? s : vn ("Mặc định");
    }
    void syncPreset() { presetBox.name = presetLabelNow(); presetBox.repaint(); }
    void stepPreset (int d)
    {
        const int n = presetCount(); if (n < 1) return;
        customPreset.clear(); loadPreset ((juce::jmax (0, currentPreset()) + d + n) % n); syncPreset();
    }
    void showPresetMenu()
    {
        juce::PopupMenu m;
        const int n = presetCount(), cur = currentPreset();
        for (int i = 0; i < n; ++i) m.addItem (i + 1, presetName (i), true, customPreset.isEmpty() && i == cur);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&presetBox).withMinimumWidth (presetBox.getWidth()),
            [safe = juce::Component::SafePointer<Editor> (this)] (int r) { if (safe && r > 0) { safe->customPreset.clear(); safe->loadPreset (r - 1); safe->syncPreset(); } });
    }
    void showSettingsMenu()
    {
        juce::PopupMenu m;
        m.addItem (1, vn ("Bản quyền & Kích hoạt..."));
        m.addSeparator();
        m.addItem (2, vn ("Lưu preset..."));
        m.addItem (3, vn ("Mở preset..."));
        if (! moreIds.isEmpty()) { m.addSeparator(); m.addItem (4, vn ("Các nút khác (THÊM)...")); }
        m.addSeparator();
        m.addItem (9, info.name + "  " + String (tak::product::version), false, false);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&gear),
            [safe = juce::Component::SafePointer<Editor> (this)] (int r)
            {
                if (! safe) return;
                if (r == 1) safe->showLicensePanel();
                else if (r == 2 || r == 3) safe->presetFile (r == 2);
                else if (r == 4) safe->showMore();
            });
    }
    void presetFile (bool writing)
    {
        chooser = std::make_unique<juce::FileChooser> ((writing ? "Save " : "Load ") + brandPublisher() + " preset", juce::File(),
                                                       writing ? "*.tfxpreset" : "*.tfxpreset;*.xml;*." + info.presetExtension);
        const int flags = writing ? (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles | juce::FileBrowserComponent::warnAboutOverwriting)
                                  : (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles);
        chooser->launchAsync (flags, [safe = juce::Component::SafePointer<Editor> (this), writing] (const juce::FileChooser& fc)
        {
            if (! safe || fc.getResult() == juce::File()) return;
            auto file = fc.getResult(); bool ok = false;
            if (writing)
            {
                file = file.withFileExtension ("tfxpreset");
                juce::XmlElement root ("TStudioPreset"); root.setAttribute ("plugin", safe->proc.getName()); root.setAttribute ("version", 1);
                if (auto xml = safe->state.copyState().createXml()) root.addChildElement (xml.release());
                ok = root.writeTo (file);
            }
            else if (auto xml = juce::XmlDocument::parse (file))
            {
                const juce::XmlElement* payload = xml.get();
                if (xml->hasTagName ("TStudioPreset"))
                    { const auto who = xml->getStringAttribute ("plugin"); payload = (who == safe->proc.getName() || safe->info.legacyNames.contains (who)) ? xml->getFirstChildElement() : nullptr; }
                if (payload)
                {
                    auto restored = juce::ValueTree::fromXml (*payload);
                    bool compatible = restored.isValid() && restored.hasType (safe->state.state.getType());
                    int known = 0;
                    for (const auto& child : restored)
                    {
                        const auto id = child.getProperty ("id").toString();
                        if (id.isNotEmpty()) { if (! safe->state.getParameter (id)) compatible = false; else ++known; }
                    }
                    if (compatible && known > 0) { safe->state.replaceState (restored); ok = true; }
                }
            }
            if (ok) { safe->customPreset = file.getFileNameWithoutExtension(); safe->syncPreset(); }
            else juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon, "Preset",
                                                         writing ? "Could not save this file." : "This preset is not compatible with this plugin.");
        });
    }

    // overlays: license panel and the "THÊM" (more controls) panel
    struct Dim final : juce::Component
    {
        std::function<void()> onClick;
        void paint (juce::Graphics& g) override { g.fillAll (juce::Colours::black.withAlpha (0.62f)); }
        void mouseUp (const juce::MouseEvent& e) override { if (e.eventComponent == this && onClick) onClick(); }
    };
    void closeOverlay()
    {
        juce::MessageManager::callAsync ([safe = juce::Component::SafePointer<Editor> (this)]
        { if (safe) { safe->licensePanel.reset(); safe->morePanel.reset(); safe->overlay.reset(); } });
    }
    void showLicensePanel()
    {
        morePanel.reset(); overlay.reset();
        auto safe = juce::Component::SafePointer<Editor> (this);
        overlay = std::make_unique<Dim>();
        licensePanel = std::make_unique<TLicensePanel> (
            [safe] { return safe ? safe->license.snapshot() : tak::license::Snapshot{}; },
            [safe] (const String& t) { if (safe) safe->license.activate (t); },
            [safe] { if (safe) safe->license.startTrial(); },
            [safe] { if (safe) safe->closeOverlay(); });
        overlay->addAndMakeVisible (*licensePanel);
        addAndMakeVisible (*overlay);
        resized();
    }
    void layoutOverlay()
    {
        const auto r = getLocalBounds().toFloat();
        if (licensePanel)
        {
            const float w = juce::jmin (r.getWidth() - 40.0f, (r.getHeight() - 40.0f) * 680.0f / 400.0f);
            licensePanel->setBounds (juce::Rectangle<float> (w, w * 400.0f / 680.0f).withCentre (r.getCentre()).toNearestInt());
        }
        if (morePanel)
        {
            const float s = (float) getWidth() / (float) info.width;
            morePanel->setTransform (juce::AffineTransform::scale (s));
            morePanel->setTopLeftPosition (juce::roundToInt ((info.width - morePanel->getWidth()) * 0.5f), juce::roundToInt ((info.height - morePanel->getHeight()) * 0.5f));
        }
    }
    struct MorePanel final : juce::Component
    {
        String title;
        void paint (juce::Graphics& g) override
        {
            const auto r = getLocalBounds().toFloat();
            g.setColour (Colour (0xff151517)); g.fillRoundedRectangle (r, 12.0f);
            g.setColour (orange().withAlpha (0.6f)); g.drawRoundedRectangle (r.reduced (0.5f), 12.0f, 1.0f);
            engrave (g, title, 20, 22, 12.0f, 2.5f, -1);
        }
        std::vector<std::unique_ptr<juce::Component>> owned;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sa;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> ba;
        std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> ca;
        std::vector<ValueBox*> boxes;
    };
    void showMore()
    {
        if (moreIds.isEmpty()) return;
        licensePanel.reset(); overlay.reset();
        auto panel = std::make_unique<MorePanel>();
        panel->title = info.name.toUpperCase() + vn ("  ·  CÁC NÚT KHÁC");
        const int cols = 5, cellW = 150, cellH = 118;
        const int rows = (moreIds.size() + cols - 1) / cols;
        panel->setSize (cols * cellW + 40, rows * cellH + 70);
        for (int i = 0; i < moreIds.size(); ++i)
        {
            auto* p = state.getParameter (moreIds[i]);
            const int cx = 20 + (i % cols) * cellW + cellW / 2, top = 48 + (i / cols) * cellH;
            auto name = std::make_unique<juce::Label> (String(), p->getName (40));
            name->setFont (font (9.5f, 8, 1.0f)); name->setColour (juce::Label::textColourId, cream());
            name->setJustificationType (juce::Justification::centred);
            name->setBounds (cx - cellW / 2 + 4, top + 88, cellW - 8, 18);
            panel->addAndMakeVisible (*name); panel->owned.push_back (std::move (name));
            if (dynamic_cast<juce::AudioParameterBool*> (p))
            {
                auto b = std::make_unique<LedButton> (vn ("BẬT"));
                b->setBounds (cx - 50, top + 30, 100, 28);
                panel->ba.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (state, moreIds[i], *b));
                panel->addAndMakeVisible (*b); panel->owned.push_back (std::move (b));
            }
            else if (auto* ch = dynamic_cast<juce::AudioParameterChoice*> (p))
            {
                auto c = std::make_unique<Select>();
                c->addItemList (ch->choices, 1);
                c->setBounds (cx - 66, top + 30, 132, 28);
                panel->ca.push_back (std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (state, moreIds[i], *c));
                panel->addAndMakeVisible (*c); panel->owned.push_back (std::move (c));
            }
            else
            {
                auto k = std::make_unique<Knob> (22.0f, 0.58f);
                k->setBounds (cx - 32, top + 4, 64, 64);
                k->setDoubleClickReturnValue (true, p->convertFrom0to1 (p->getDefaultValue()));
                panel->sa.push_back (std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (state, moreIds[i], *k));
                panel->addAndMakeVisible (*k); panel->owned.push_back (std::move (k));
                auto v = std::make_unique<ValueBox>();
                v->fontSize = 11.0f;
                v->textFn = [p] { return paramText (*p); };
                v->onType = [p] (const String& t) { p->beginChangeGesture(); p->setValueNotifyingHost (p->getValueForText (t)); p->endChangeGesture(); };
                v->setBounds (cx - 40, top + 66, 80, 20);
                panel->boxes.push_back (v.get());
                panel->addAndMakeVisible (*v); panel->owned.push_back (std::move (v));
            }
        }
        auto close = std::make_unique<MoreButton>();
        close->setButtonText (vn ("ĐÓNG"));
        close->setBounds (panel->getWidth() - 96, 10, 76, 24);
        close->onClick = [this] { closeOverlay(); };
        panel->addAndMakeVisible (*close); panel->owned.push_back (std::move (close));
        auto dim = std::make_unique<Dim>();
        dim->onClick = [this] { closeOverlay(); };
        overlay = std::move (dim);
        morePanel = std::move (panel);
        overlay->addAndMakeVisible (*morePanel);
        addAndMakeVisible (*overlay);
        moreTimer.f = [this] { if (morePanel) for (auto* b : morePanel->boxes) b->refresh(); };
        moreTimer.startTimerHz (15);
        resized();
    }
    struct Lambda final : juce::Timer { std::function<void()> f; void timerCallback() override { if (f) f(); } };

    Face face;
    PresetBox presetBox;
    Gear gear;
    Badge badge;
    MoreButton more;
    juce::TooltipWindow tooltip { this, 600 };
    std::vector<std::function<void (juce::Graphics&)>> plateOps;
    struct InfoItem { String label; std::function<String()> value; String shown; };
    std::vector<InfoItem> infos;
    std::vector<std::unique_ptr<Knob>> knobs;
    std::vector<std::unique_ptr<ValueBox>> values;
    std::vector<std::unique_ptr<LedButton>> buttons;
    std::vector<std::unique_ptr<Segmented>> segs;
    std::vector<std::unique_ptr<Select>> selects;
    std::vector<std::unique_ptr<Fader>> faders;
    std::vector<std::unique_ptr<VuMeter>> vus;
    std::vector<std::unique_ptr<LedMeter>> leds;
    std::vector<std::unique_ptr<BarMeter>> bars;
    std::vector<std::unique_ptr<HandleSlider>> handles;
    std::vector<std::unique_ptr<HSlider>> hsliders;
    std::vector<std::unique_ptr<ChoiceGrid>> grids;
    std::vector<std::unique_ptr<Screen>> screens;
    std::vector<std::unique_ptr<ToggleSwitch>> toggles;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAtt;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAtt;
    std::set<String> covered;
    juce::StringArray moreIds;
    String customPreset;
    std::unique_ptr<juce::FileChooser> chooser;
    std::unique_ptr<juce::Component> overlay;
    std::unique_ptr<TLicensePanel> licensePanel;
    std::unique_ptr<MorePanel> morePanel;
    Lambda moreTimer;
};
} // namespace thw
