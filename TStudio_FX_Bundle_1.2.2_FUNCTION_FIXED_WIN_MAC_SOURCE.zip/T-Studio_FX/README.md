# T Studio FX Bundle 1.2.2

Mã nguồn đầy đủ cho **T-Verb, T-RVerb, T-PANTHEON và T-LIQUID DELAY**, kèm JUCE và script build/tạo bộ cài Windows/macOS.

**Đọc [DOC_TRUOC_1_2_2.md](DOC_TRUOC_1_2_2.md) trước khi build.** Gói chưa chứa plugin hoặc bộ cài Windows/macOS đã biên dịch native.

T-PANTHEON sửa lựa chọn màu vang, RT60, Damping/Bass Boost, chuyển đầu đọc và reset; thêm FX SEND giữ wet-only khi đổi preset. LIQUID Delay có nhánh HD thực, giữ tiếng Classic khi HD tắt. T-Verb kèm bản chặn NaN đã gửi trước; engine T-Verb và T-RVerb giữ nguyên.

- Windows: `1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat`; chỉ build: `2_CHI_BUILD_WINDOWS.bat`.
- macOS: `1_BUILD_VA_TAO_BO_CAI_MAC.command`.
- Giữ/copy đúng `config/public_key.txt` của hệ cấp key anh đang dùng trước khi build. File đầu vào đang trống và được giữ nguyên. Không có private key hay công cụ cấp key trong ZIP.
- Dùng AUX: bật **FX SEND 100% WET**, chỉnh lượng vang bằng Send/Return. Dùng insert: tắt FX SEND rồi chỉnh Mix.

Đã kiểm tra nguồn trên Linux/JUCE 8.0.12, có ASan/UBSan cho mã DSP mới và số đo trước/sau. [Validation](Validation/) chứa log, số liệu và giới hạn. Màu tiếng đổi theo DSP đã sửa; giữ bản plugin cũ nếu cần tái hiện bản mix cũ chính xác. Chưa kiểm tra Cubase 15 Windows, ASIO, EXE/PKG hay nghe vocal thật của đợt này.

![Editor QA](Validation/PANTHEON_EDITOR_QA.png)

![Số đo trước/sau](Validation/PANTHEON_BEFORE_AFTER.png)

Đây là sáu voicing của mạng Chamber trong dự án, chưa xác nhận tương đương thuật toán bản hãng. ID/thứ tự tham số và cơ chế license giữ nguyên; project cũ thiếu cờ FX Send mở ở Insert. Rủi ro worker license kẹt I/O vẫn thuộc giới hạn đã nêu trong báo cáo audit trước.
