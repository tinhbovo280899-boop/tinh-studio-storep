#include <juce_audio_utils/juce_audio_utils.h>
#include "TDelayProcessor.h"
#include <filesystem>
#include <fstream>
#include <cstdio>
#include <random>
static void set(TDelayAudioProcessor&p,const char*id,float value){auto*q=p.getAPVTS().getParameter(id);q->setValueNotifyingHost(q->convertTo0to1(value));}
int main(int argc,char**argv){try{
    juce::ScopedJuceInitialiser_GUI init;tak::license::PluginLicense proof;proof.ensureAutomaticTrial();
    for(int i=0;i<200&&!proof.isAllowed();++i)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
    if(!proof.isAllowed()||argc<2)return 2;std::filesystem::path root=argv[1];std::filesystem::create_directories(root);
    for(double fs:{44100.,48000.,96000.})for(int mode:{0,2,5})for(int lfo:{0,1})for(int hd:{0,1}){
        TDelayAudioProcessor p;set(p,"mix",100);set(p,"fxMode",float(mode));set(p,"hdFilter",float(hd));
        set(p,"dlyFeedback",35);set(p,"dlySync",0);set(p,"dlyTempo",120);set(p,"lowCut",150);set(p,"highCut",4500);
        set(p,"resonance",10);set(p,"overdrive",30);set(p,"lfoOn",float(lfo));set(p,"lfoDepth",35);set(p,"inLoop",0);
        p.setPlayConfigDetails(2,2,fs,256);p.prepareToPlay(fs,256);const int frames=int(fs*2);
        juce::AudioBuffer<float>b(2,256);juce::MidiBuffer midi;std::vector<float>a(size_t(frames)*2);
        std::mt19937 rng(74);std::uniform_real_distribution<float>noise(-.02f,.02f);
        for(int off=0;off<frames;off+=256){int n=std::min(256,frames-off);b.setSize(2,n,false,false,true);
            for(int i=0;i<n;++i){double t=(off+i)/fs;float x=t<.8?float(.08*std::sin(2*juce::MathConstants<double>::pi*197*t)) +noise(rng):0;
                b.setSample(0,i,x);b.setSample(1,i,t<.8?float(.06*std::sin(2*juce::MathConstants<double>::pi*311*t))+noise(rng):0);}
            p.processBlock(b,midi);for(int i=0;i<n;++i)for(int c=0;c<2;++c){float x=b.getSample(c,i);if(!std::isfinite(x))return 3;a[size_t(off+i)*2+c]=x;}
        }
        auto name=std::to_string(int(fs))+"_"+std::to_string(mode)+"_"+std::to_string(lfo)+"_"+std::to_string(hd)+".f32";
        std::ofstream file(root/name,std::ios::binary);file.write(reinterpret_cast<const char*>(a.data()),std::streamsize(a.size()*sizeof(float)));
    }std::puts("DELAY RENDERS PASS: 36 cases");return 0;
}catch(...){return 4;}}
