from pathlib import Path
import concurrent.futures,json,os,subprocess,time,uuid
ROOT=Path(__file__).resolve().parents[1]
BUILD=ROOT/'build-cmake'
plan=json.loads((ROOT/'logs/ctest-plan.json').read_text())
jobs=[]
for test in plan['tests']:
    if test['name']=='LicenseTestHomeReset':continue # every process gets its own store instead
    working=next((x['value'] for x in test.get('properties',[]) if x['name']=='WORKING_DIRECTORY'),str(BUILD))
    jobs.append((test['name'],test['command'],working))
for target in ['TPantheon','TLiquidDelay','TVerb','TRVerb']:
    for kind in ['Audit','Signal']:
        name=kind+'_'+target;jobs.append((name,[str(BUILD/name)],str(BUILD)))

def run(job):
    name,command,cwd=job;store=ROOT/'runtime'/(name+'-'+uuid.uuid4().hex);store.mkdir()
    env=os.environ.copy()
    # Do not apply CTest's HOME override. Redirect only this test's license,
    # application data and caches into task-owned directories.
    env.update({'DISPLAY':'','TSTUDIO_AUDIT_ROOT':str(store),'TSTUDIO_TEST_ISOLATED_HOME':'1',
        'XDG_CONFIG_HOME':str(store/'config'),'XDG_DATA_HOME':str(store/'data'),'XDG_CACHE_HOME':str(store/'cache'),
        'APPDATA':str(store/'AppData'),'LOCALAPPDATA':str(store/'LocalAppData')})
    if name=='TPantheon_ProcessorTests':env['TSTUDIO_QA_SNAPSHOT']=str(ROOT/'logs/PANTHEON_1_2_2_QA.png')
    start=time.monotonic()
    try:p=subprocess.run(command,cwd=cwd,env=env,capture_output=True,text=True,timeout=150);code=p.returncode;output=p.stdout+p.stderr
    except subprocess.TimeoutExpired as error:code=124;output=str(error)
    (ROOT/'logs'/(name+'.log')).write_text(output)
    result={'test':name,'exit_code':code,'seconds':round(time.monotonic()-start,3),'isolated_store':True}
    if name.startswith('Signal_') and code==0:
        data=json.loads(output.split('AUDIT_JSON ',1)[1].splitlines()[0]);(ROOT/'logs'/(name+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
        result.update({'normal_nonfinite':sum(x['steady_nonfinite']+sum(q['nonfinite'] for q in x['parameter_sweep']) for x in data['sample_rates']),
            'recovery_nonfinite':sum(x['nonfinite_after_invalid_input'] for x in data['sample_rates']),
            'reset_nonfinite':sum(x['nonfinite_after_reset'] for x in data['sample_rates']),
            'observed_cpp_new':sum(x['steady_cpp_allocations']+sum(q['cpp_allocations'] for q in x['parameter_sweep']) for x in data['sample_rates'])})
    if code:result['tail']=output[-2000:]
    print(json.dumps(result),flush=True);return result

with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:results=list(pool.map(run,jobs))
(ROOT/'validation-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'executables':len(results),'failed_or_skipped':sum(x['exit_code']!=0 for x in results)}))
raise SystemExit(1 if any(x['exit_code']!=0 or x.get('normal_nonfinite',0) or x.get('recovery_nonfinite',0) or x.get('reset_nonfinite',0) for x in results) else 0)
