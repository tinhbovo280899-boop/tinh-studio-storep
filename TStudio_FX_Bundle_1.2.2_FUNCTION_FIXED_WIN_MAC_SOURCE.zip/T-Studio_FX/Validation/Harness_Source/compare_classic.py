from pathlib import Path
import concurrent.futures,json,os,shlex,subprocess,uuid
import numpy as np
ROOT=Path(__file__).resolve().parents[1]

def run(version):
    build=Path('/workspace/vst-31-review-20261031/build/fx') if version=='original' else ROOT/'build-cmake'
    commands=json.loads((build/'compile_commands.json').read_text())
    sample=next(x for x in commands if x['file'].endswith('/TDelayProcessor.cpp'))
    args=shlex.split(sample['command']);obj=ROOT/'build'/('DelayCompare_'+version+'.o')
    args[args.index('-o')+1]=str(obj);args[args.index('-c')+1]=str(ROOT/'qa/delay_render.cpp')
    header=Path('/workspace/vst-31-review-20261031/working/fx/plugins/T-LiquidDelay/Source') if version=='original' else ROOT/'qa/project/plugins/T-LiquidDelay/Source'
    args[1:1]=['-I'+str(header)];subprocess.run(args,cwd=build,check=True,capture_output=True,text=True)
    link=shlex.split((build/'CMakeFiles/Signal_TLiquidDelay.dir/link.txt').read_text())
    link=[str(obj) if x.endswith('/qa/signal.cpp.o') else x for x in link if not x.startswith('-Wl,--dependency-file=')]
    binary=ROOT/'build'/('DelayCompare_'+version);link[link.index('-o')+1]=str(binary)
    subprocess.run(link,cwd=build,check=True,capture_output=True,text=True)
    store=ROOT/'runtime'/('classic-'+version+'-'+uuid.uuid4().hex);store.mkdir()
    env=os.environ.copy();env.update({'DISPLAY':'','TSTUDIO_AUDIT_ROOT':str(store),'XDG_CONFIG_HOME':str(store/'config'),'XDG_DATA_HOME':str(store/'data'),'XDG_CACHE_HOME':str(store/'cache')})
    render=ROOT/'renders'/('delay-'+version)
    p=subprocess.run([str(binary),str(render)],env=env,capture_output=True,text=True,timeout=120)
    (ROOT/'logs'/('DelayCompare_'+version+'.log')).write_text(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError(p.stdout+p.stderr)
    return render

with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:paths=list(pool.map(run,['original','fixed']))
rows=[]
for original in sorted(paths[0].glob('*_0.f32')):
    fixed=paths[1]/original.name
    a=np.fromfile(original,dtype='<f4');b=np.fromfile(fixed,dtype='<f4')
    hd=np.fromfile(fixed.with_name(fixed.stem[:-1]+'1.f32'),dtype='<f4')
    before=np.fromfile(original.with_name(original.stem[:-1]+'1.f32'),dtype='<f4')
    row={'case':original.stem[:-2],'classic_max_difference':float(np.max(np.abs(a-b))),
         'original_hd_max_difference':float(np.max(np.abs(a-before))),
         'fixed_hd_max_difference':float(np.max(np.abs(b-hd)))}
    assert row['classic_max_difference']<1.e-6,row
    assert row['original_hd_max_difference']==0,row
    assert row['fixed_hd_max_difference']>1.e-6,row
    rows.append(row)
result={'classic_comparison_cases':len(rows),'maximum_classic_difference':max(x['classic_max_difference'] for x in rows),'rows':rows,
        'scope':'Source processors, 44.1/48/96 kHz, 3 routing orders, LFO off/on, HD off/on; same deterministic input and normal QA license.'}
(ROOT/'classic-compatibility-results.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
