PROJECT-LICENSE.txt is the license named by the SPDX headers in shared/licensing
(the shared T Studio license code, identical to the Vocal Pack / Compressor Bundle copy).
JUCE-LICENSE.md records the included framework license notice; docs/THIRD_PARTY_NOTICES.md
lists the other third-party notices. FONT_LICENSE_Inter.txt covers the embedded Inter font.
These documents are copyright/source licenses, not activation mechanisms.
