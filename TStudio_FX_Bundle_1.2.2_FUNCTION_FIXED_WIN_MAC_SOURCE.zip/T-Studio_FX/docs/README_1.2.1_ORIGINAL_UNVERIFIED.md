# T Studio FX Bundle

Four effects, one installer: **T-Verb**, **T-RVerb**, **T-PANTHEON** and **T-LIQUID DELAY**
(VST3; VST3 + AU on macOS). Gold/black T Studio editors (`plugins/common`) and the
**shared T Studio license**: same key, same 7-day trial and same store as T-AutoKey,
T-AutoTune, T-1176 and T-LA2a (productId `TVOCALPACK`, brand `TSTUDIO`). A machine
activated in any T Studio plugin unlocks all four effects. See `HUONG_DAN.txt` (Vietnamese).

Keep this folder next to `T-Studio_VocalPack`; the build scripts copy its
`config/public_key.txt` and refuse to build if productId/brand differ.
`config/public_key.txt` ships EMPTY on purpose.

- Windows: `1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat` -> `Installers/TStudio_FX_1.2.1_Windows_x64_Setup.exe`
  (Visual Studio C++, CMake 3.22+, Inno Setup 6.3+). `2_CHI_BUILD_WINDOWS.bat` builds/tests only.
- macOS: `1_BUILD_VA_TAO_BO_CAI_MAC.command` -> `Installers/TStudio_FX_1.2.1_macOS_universal.pkg`
  (Xcode Command Line Tools, CMake 3.22+).

## Source layout

- `plugins/T-Verb`, `plugins/T-RVerb`, `plugins/T-Pantheon`, `plugins/T-LiquidDelay`: processors, DSP, tests.
- `plugins/common/HwKit.h`: giao diện phần cứng mặt đen / cam nhạt (dùng chung với T-Studio_Plugins); mỗi plugin có `HwEditor.h`.
  `StudioEditor.h` / `StudioSpecs.h` là giao diện cũ, vẫn để lại nhưng không còn dùng.
- `shared/licensing`: byte-identical copy of the Compressor Bundle license code.
- `third_party/JUCE`: JUCE 8.0.12. `Resources/Fonts`: embedded Inter.
- `Installer/TStudioFX.iss`, `tools/windows.ps1`, `tools/mac.sh`: build, stage and package.
- `BUNDLE_INFO.json`: product codes and SHA-256 of the DSP sources.

## Behaviour

- Not activated / trial over: the plugin does not process; host audio passes through
  (T-Verb/T-RVerb crossfade to their latency-aligned dry path, like host bypass).
- Host scan/prepare never starts the trial; opening the editor or the first audio does.
- Header shows `DÙNG THỬ · CÒN N NGÀY`, `HẾT HẠN DÙNG THỬ` or `CHƯA KÍCH HOẠT`;
  gear menu: Bản quyền & Kích hoạt, Lưu preset, Mở preset.

## Identity changes from the free bundle

T-PHANGHEO is now **T-PANTHEON** (`TxSt`/`Tpnt`, `com.tstudio.tpantheon`) and T-LIQUI DELAY
is now **T-LIQUID DELAY** (`TxSt`/`Tlqd`, `com.tstudio.tliquiddelay`). DAWs treat them as
new plugins; `.tfxpreset` files saved by the old names still load. T-Verb and T-RVerb keep
their codes. Parameter IDs and DSP are unchanged.

## Developer checks

```sh
cmake -S . -B build/dev -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build/dev --config Release
ctest --test-dir build/dev -C Release --output-on-failure
```

DSP regressions never need a license. Processor tests run the real license gate: on
Linux/macOS CTest gives them an isolated HOME and starts a fresh trial there; on Windows
they need an activated/trial machine, otherwise they report SKIPPED.
`-DTAK_BUILD_PROCESSOR_QA=ON` (Linux) adds `TVerbQA`, `TRVerbQA`, `TPantheonQA`, `TLiquidQA`.
See `VALIDATION.txt` for what was checked and its limits.
