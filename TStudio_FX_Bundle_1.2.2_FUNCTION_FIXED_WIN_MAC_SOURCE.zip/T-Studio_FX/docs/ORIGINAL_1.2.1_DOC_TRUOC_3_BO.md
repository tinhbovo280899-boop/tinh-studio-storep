# T Studio: gom thành 3 bộ

| Zip | Thư mục | Gồm |
|---|---|---|
| T-Studio_VocalPack.zip | `T-Studio_VocalPack` | T-AutoKey, T-AutoTune (Tuner mới), tool sinh key |
| T-Studio_FX.zip | `T-Studio_FX` | T-Verb, T-RVerb, T-PANTHEON, T-LIQUID DELAY |
| T-Studio_Plugins.zip | `T-Studio_Plugins` | 15 plugin còn lại, 1 bộ cài chung |

## Sắp xếp trên máy

Đặt 3 thư mục cạnh nhau, ví dụ:

```
D:\TStudio\T-Studio_VocalPack
D:\TStudio\T-Studio_FX
D:\TStudio\T-Studio_Plugins
```

Bộ FX và bộ Plugins tự lấy public key từ thư mục `T-Studio_VocalPack` nằm cạnh. Không cần sinh key mới.

## QUAN TRỌNG: khóa bản quyền

Các zip **không chứa khóa**: `config/public_key.txt` để trống, không có `KhoaBanQuyen`.

- **T-Studio_VocalPack:** KHÔNG giải nén đè lên chỗ khác rồi bấm sinh key. Làm 1 trong 2 cách:
  - **Cách 1 (dễ nhất):** chép thư mục `KhoaBanQuyen` và file `config\public_key.txt` từ thư mục
    VocalPack cũ (Desktop\VSTNT…) sang thư mục `T-Studio_VocalPack` mới.
  - **Cách 2:** chép đè các file trong zip lên thư mục VocalPack cũ đang dùng.

  Nếu bấm `1_SINH_KEY` ở thư mục mới mà chưa có `KhoaBanQuyen`, nó sẽ tạo **cặp khóa MỚI**.
  Khi đó key đã bán sẽ không dùng được với bản build mới, nên phải chép khóa cũ sang trước.
- **T-Studio_FX và T-Studio_Plugins:** chỉ cần nằm cạnh `T-Studio_VocalPack` là xong.
- **Mac:** làm y như vậy với thư mục và khóa riêng trên Mac.

## Bộ T-Studio_Plugins (mới gộp)

- **Vocal:** T-BE, T-Comp, T-DeNoise, T-EQ, T-Pitch, T-Limiter.
- **Mix / Master:** T-API550, T-Manny-EQ, T-HDelay, T-NS1, T-Vitamin.
- **Tách từ T-CLA-2A:**
  - T-Opto (Gain + Peak Reduction);
  - T-Compander (Threshold + Makeup);
  - T-TapeFlanger (Rate + Depth);
  - T-Mod (Speed + Mix).
- **T-CLA-2A đã bỏ:** bộ cài tự xóa file cũ.

Khi cài:
- Một bộ cài chung, khách tích chọn plugin muốn cài (Mac: bấm Customize).
- Windows: nếu máy có "T Studio 6 VST Bundle" hoặc "T Studio Vocal Bundle" cũ, bộ cài tự gỡ trước.
  Key và dùng thử giữ nguyên.

Mã plugin của 11 con cũ giữ nguyên, nên project cũ mở bình thường. Riêng project cũ dùng T-CLA-2A sẽ báo
thiếu plugin; thay bằng T-Opto / T-Compander / T-TapeFlanger / T-Mod tương ứng.
