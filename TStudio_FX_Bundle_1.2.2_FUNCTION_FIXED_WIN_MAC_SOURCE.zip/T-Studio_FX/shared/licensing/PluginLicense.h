// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "ProductConfig.h"

namespace tak::license {
// Drop-in license for any T Studio plugin. Same store, key and trial as
// T-AutoKey/T-AutoTune: activating any one of them unlocks this plugin too.
//
// v1.2.1 (DAW freeze fix): every instance of a plugin used to start its own
// license thread that polled the disk every second, and destroying a plugin
// waited 3 s for that thread and then KILLED it by force (TerminateThread).
// A thread killed in the middle of a file/registry call can leave the heap or
// a Windows lock held, which freezes the whole DAW when a VST is removed.
//
// Now all instances inside one plugin file share ONE worker (SharedLicenseService).
// Adding or removing a plugin only changes a reference count; the worker stops
// cleanly (never killed) when the last instance of that plugin file goes away.
// The audio thread still only reads an atomic flag through isAllowed().
class SharedLicenseService : private juce::Thread {
public:
    SharedLicenseService() : juce::Thread("TStudioLicense") { startThread(juce::Thread::Priority::low); }
    ~SharedLicenseService() override {
        signalThreadShouldExit(); notify();
        // poll() is short and checks nothing slow, so this returns in milliseconds.
        // The long timeout only exists so the thread is never killed by force.
        stopThread(30000);
    }
    bool isAllowed() const noexcept { return manager.isAllowed(); }
    Snapshot snapshot() const { return manager.snapshot(); }
    void activate(const juce::String& text) { manager.requestActivation(text); pollNow(); }
    void startTrial() { manager.requestTrial(); pollNow(); }
    void requestAutomaticTrial() noexcept {
        if (!automaticRequested.exchange(true, std::memory_order_relaxed)) { manager.requestAutomaticTrial(); pollRequested.store(true); }
    }
    void pollNow() { pollRequested.store(true); notify(); }
private:
    void run() override {
        juce::int64 next = 0;
        while (!threadShouldExit()) {
            const auto now = juce::Time::getCurrentTime().toMilliseconds();
            if (pollRequested.exchange(false) || now >= next || now < next - 60000) { manager.poll(now); next = now + 1000; }
            wait(200);
        }
    }
    LicenseManager manager { productConfiguration(), productStore() };
    std::atomic<bool> pollRequested { true }, automaticRequested { false };
};

class PluginLicense {
public:
    PluginLicense() = default;
    bool isAllowed() const noexcept { return service->isAllowed(); }
    Snapshot snapshot() const { return service->snapshot(); }
    void activate(const juce::String& text) { service->activate(text); }
    void startTrial() { service->startTrial(); }
    // Host scanning alone never starts the trial: call from the editor and
    // from the first non-empty audio block.
    void ensureAutomaticTrial() noexcept {
        if (!automaticRequested.exchange(true, std::memory_order_relaxed)) service->requestAutomaticTrial();
    }
private:
    juce::SharedResourcePointer<SharedLicenseService> service;
    std::atomic<bool> automaticRequested { false };
    JUCE_DECLARE_NON_COPYABLE(PluginLicense)
};
}
