// SPDX-License-Identifier: AGPL-3.0-or-later
#include "LicenseManager.h"
#include <algorithm>
#include <cmath>

namespace tak::license {
namespace {
juce::String vn(const char* s) {return juce::String::fromUTF8(s);}
constexpr juce::int64 dayMs=86400000LL;
constexpr int flagTampered=1,flagActivated=2;

// Mixed into the trial signature key. Stored XOR-ed so it is not a plain
// string in the binary. This only raises the bar for hand-editing the trial
// files; the license keys themselves are protected by RSA signatures.
juce::String pepper() {
    static const unsigned char enc[]={0x0e,0x77,0x29,0x35,0x3e,0x2f,0x32,0x38,0x77,0x14,0x29,0x32,0x3c,0x34,0x33,0x77,0x0e,0x29,0x32,0x3b,0x37,0x77,0x6b,0x69,0x6c,0x6e,0x77,0x09,0x32,0x33,0x34,0x77,0x3f,0x3e,0x2e,0x34,0x77,0x0b,0x34,0x39,0x3b,0x37};
    juce::String s;for(auto b:enc)s<<juce::String::charToString(juce::juce_wchar(b^0x5a));return s;
}
juce::String storeHash(const Configuration& c) {
    const auto t=c.productId+"|"+c.brandId+"|cache";
    return juce::SHA256(t.toRawUTF8(),size_t(t.getNumBytesAsUTF8())).toHexString().substring(0,20);
}
bool isInteger(const juce::var& v) {return v.isInt()||v.isInt64();}
}

StorePaths StorePaths::under(const juce::File& root,const juce::String& storeName) {
    StorePaths p;const auto product=root.getChildFile(storeName);
    p.license=product.getChildFile("license.taklic");
    p.activationHistory=product.getChildFile("activated-once.txt");
    p.trialRecords.add(product.getChildFile("trial-state.json"));
    p.trialRecords.add(root.getChildFile("TrialState").getChildFile(storeName+".json"));
    p.trialRecords.add(root.getChildFile(".cache").getChildFile(storeName+".dat"));
    p.trialRecords.add(root.getChildFile("Shared").getChildFile("."+storeName+".dat"));
    return p;
}

StorePaths StorePaths::forProduct(const Configuration& config) {
    auto appData=juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory);
   #if JUCE_MAC
    appData=appData.getChildFile("Application Support");
   #endif
    const auto storeName=config.productId+"-"+config.brandId;
    const auto root=appData.getChildFile("T Studio").getChildFile("Licenses");
    StorePaths p;const auto product=root.getChildFile(storeName);const auto h=storeHash(config);
    p.license=product.getChildFile("license.taklic");
    p.activationHistory=product.getChildFile("activated-once.txt");
    p.trialRecords.add(product.getChildFile("trial-state.json"));
    p.trialRecords.add(root.getChildFile("TrialState").getChildFile(storeName+".json"));
   #if JUCE_WINDOWS
    p.trialRecords.add(juce::File::getSpecialLocation(juce::File::windowsLocalAppData).getChildFile("T Studio").getChildFile("cache").getChildFile(h+".dat"));
    p.trialRecords.add(juce::File::getSpecialLocation(juce::File::commonApplicationDataDirectory).getChildFile("T Studio").getChildFile("cache").getChildFile(h+".dat"));
    p.registryKey="HKEY_CURRENT_USER\\Software\\T Studio\\Cache\\"+h;
   #elif JUCE_MAC
    const auto home=juce::File::getSpecialLocation(juce::File::userHomeDirectory);
    p.trialRecords.add(home.getChildFile("Library/Caches/com.tstudio.cache").getChildFile(h+".dat"));
    p.trialRecords.add(juce::File("/Users/Shared/T Studio/.cache").getChildFile(h+".dat"));
   #else
    p.trialRecords.add(juce::File::getSpecialLocation(juce::File::userHomeDirectory).getChildFile(".cache/tstudio").getChildFile(h+".dat"));
   #endif
    return p;
}

LicenseManager::LicenseManager(Configuration c,StorePaths p,juce::StringArray ids,std::vector<LegacyLicense> legacy)
    :config(std::move(c)),paths(std::move(p)),machines(std::move(ids)),legacyLicenses(std::move(legacy)) {
    state.status=vn("Đang kiểm tra bản quyền...");
}
void LicenseManager::requestActivation(const juce::String& token) {
    const juce::ScopedLock sl(lock);pendingActivation=token.substring(0,32769);
}
Snapshot LicenseManager::snapshot() const {const juce::ScopedLock sl(lock);return state;}
void LicenseManager::publish(Snapshot s) {
    allowed.store(s.allowed,std::memory_order_release);const juce::ScopedLock sl(lock);state=std::move(s);
}

juce::String LicenseManager::trialSecret() const {
    const auto t=pepper()+"|"+config.productId+"|"+config.brandId+"|"+config.publicKey;
    return juce::SHA256(t.toRawUTF8(),size_t(t.getNumBytesAsUTF8())).toHexString();
}
juce::String LicenseManager::encodeTrial(const Trial& t) const {
    const int flags=(t.tampered?flagTampered:0)|(t.activatedOnce?flagActivated:0);
    const auto message="v2|"+juce::String(t.first)+"|"+juce::String(t.seen)+"|"+juce::String(flags)+"|"+config.productId+"|"+config.brandId;
    auto* obj=new juce::DynamicObject;
    obj->setProperty("v",2);obj->setProperty("first",t.first);obj->setProperty("seen",t.seen);obj->setProperty("flags",flags);
    obj->setProperty("sig",hmacSha256Hex(trialSecret(),message));
    return juce::JSON::toString(juce::var(obj),true);
}
bool LicenseManager::decodeTrial(const juce::String& text,Trial& out) const {
    if(text.length()>4096)return false;
    const auto value=juce::JSON::parse(text);auto* obj=value.getDynamicObject();if(!obj)return false;
    const auto v=obj->getProperty("v"),f=obj->getProperty("first"),s=obj->getProperty("seen"),fl=obj->getProperty("flags"),sig=obj->getProperty("sig");
    if(!isInteger(v)||int(v)!=2||!isInteger(f)||!isInteger(s)||!isInteger(fl)||!sig.isString())return false;
    out.first=juce::int64(f);out.seen=juce::int64(s);const int flags=int(fl);
    if(out.first<=0||out.seen<out.first||flags<0||flags>3)return false;
    const auto message="v2|"+juce::String(out.first)+"|"+juce::String(out.seen)+"|"+juce::String(flags)+"|"+config.productId+"|"+config.brandId;
    if(sig.toString()!=hmacSha256Hex(trialSecret(),message))return false;
    out.tampered=(flags&flagTampered)!=0;out.activatedOnce=(flags&flagActivated)!=0;
    return true;
}
juce::String LicenseManager::readRegistry() const {
   #if JUCE_WINDOWS
    if(paths.registryKey.isNotEmpty())return juce::WindowsRegistry::getValue(paths.registryKey,{});
   #endif
    return {};
}
void LicenseManager::writeRegistry(const juce::String& text) const {
   #if JUCE_WINDOWS
    if(paths.registryKey.isNotEmpty())juce::WindowsRegistry::setValue(paths.registryKey,text.removeCharacters("\r\n"));
   #else
    juce::ignoreUnused(text);
   #endif
}

LicenseManager::Trial LicenseManager::readTrial() const {
    Trial result;
    auto merge=[&](const juce::String& text,bool countMirror){
        if(countMirror)++result.mirrorsFound;
        result.exists=true;
        Trial one;
        if(!decodeTrial(text,one)){result.tampered=true;return;} // edited, copied or forged record
        if(countMirror)++result.mirrorsValid;
        result.first=result.valid?std::min(result.first,one.first):one.first;
        result.seen=std::max(result.seen,one.seen);
        result.tampered=result.tampered||one.tampered;
        result.activatedOnce=result.activatedOnce||one.activatedOnce;
        result.valid=true;
    };
    for(const auto& file:paths.trialRecords){
        if(!file.existsAsFile())continue;
        merge(file.getSize()<=4096?file.loadFileAsString():juce::String(),true);
    }
    const auto reg=readRegistry();if(reg.isNotEmpty())merge(reg,false);
    return result;
}
bool LicenseManager::writeTrial(const Trial& t,juce::String& error) {
    const auto text=encodeTrial(t);bool any=false;error.clear();
    for(const auto& file:paths.trialRecords){
        juce::String e;
        if(atomicWrite(file,text,e))any=true;
        else if(error.isEmpty())error=e;
    }
    writeRegistry(text);
    return any;
}

Verification LicenseManager::cachedVerify(const juce::File& file,const Configuration& cfg,KeyCache& cache,juce::int64 now) const {
    if(!file.existsAsFile()||file.getSize()>32768){cache={};return {};}
    const auto stamp=juce::String(file.getSize())+"|"+juce::String(file.getLastModificationTime().toMilliseconds());
    if(stamp!=cache.stamp||now<cache.checkedMs||now-cache.checkedMs>=keyRecheckMs){
        cache.stamp=stamp;cache.checkedMs=now;cache.result=verify(file.loadFileAsString(),cfg,machines,now);
        return cache.result;
    }
    // Same key file as last time: only the clock-dependent checks can change.
    auto r=cache.result;
    if(r.valid&&r.claims.expiresMs>0&&now>=r.claims.expiresMs){r.valid=false;r.error="License has expired";}
    return r;
}

void LicenseManager::poll(juce::int64 now) {
    if(machines.isEmpty())machines=machineHashes();
    juce::String incoming;{const juce::ScopedLock sl(lock);incoming.swapWith(pendingActivation);}
    const bool automaticTrial=automaticTrialRequested.exchange(false);
    const bool explicitTrial=trialRequested.exchange(false);
    const bool userAction=incoming.isNotEmpty()||explicitTrial||automaticTrial;
    Snapshot next;next.fingerprint=machines.joinIntoString("\n");next.request=requestText(config,machines);

    Trial trial;
    if(userAction||!trialCached||now<trialReadMs||now-trialReadMs>=trialRereadMs){trial=readTrial();trialReadMs=now;}
    else trial=cachedTrial;
    if(trial.valid)maxObservedMs=std::max(maxObservedMs,trial.seen);

    // Clock checks. Time never runs backwards for the trial: elapsed time is
    // measured against the latest moment ever recorded on this machine.
    const bool clockBehind=trial.valid&&now+rollbackToleranceMs<maxObservedMs;
    const bool beforeBuild=config.buildEpochMs>0&&now<config.buildEpochMs-buildToleranceMs;
    auto effectiveNow=std::max({now,maxObservedMs,config.buildEpochMs});
    maxObservedMs=effectiveNow;
    bool mustPersist=false;
    if(trial.exists&&!trial.valid)trial.tampered=true;
    if(trial.exists&&(clockBehind||beforeBuild)&&!trial.tampered){trial.tampered=true;mustPersist=true;}
    if(trial.exists&&trial.tampered&&trial.mirrorsValid<trial.mirrorsFound)mustPersist=true;

    if(incoming.isNotEmpty()){
        const auto checked=verify(incoming,config,machines,effectiveNow);
        juce::String error;
        if(checked.valid){
            lastAction=atomicWrite(paths.license,incoming.trim(),error,true)?vn("Đã kích hoạt thành công."):vn("Không lưu được key: ")+error;
            keyCache={};
        }else{
            bool savedLegacy=false;
            for(const auto& legacy:legacyLicenses){
                if(!verify(incoming,legacy.config,machines,effectiveNow).valid)continue;
                lastAction=atomicWrite(legacy.file,incoming.trim(),error,true)?vn("Đã kích hoạt key cũ: ")+legacy.label:vn("Không lưu được key: ")+error;
                savedLegacy=true;legacyCache.clear();break;
            }
            if(!savedLegacy)lastAction=vn("Key không hợp lệ: ")+checked.error;
        }
    }

    const bool history=paths.activationHistory.existsAsFile()||trial.activatedOnce;
    const bool canStartTrial=config.trialDays>0&&!trial.exists&&!history&&!paths.license.existsAsFile();
    if(explicitTrial||(automaticTrial&&canStartTrial)){
        if(config.trialDays<=0)lastAction=vn("Sản phẩm này không có thời gian dùng thử.");
        else if(history||paths.license.existsAsFile())lastAction=vn("Máy đã dùng key; nhập key mới để gia hạn.");
        else if(trial.exists)lastAction=trial.tampered?vn("Bản dùng thử đã kết thúc trên máy này."):vn("Máy này đã dùng thử rồi.");
        else if(beforeBuild)lastAction=vn("Ngày giờ của máy không đúng. Chỉnh lại ngày giờ rồi mở lại plugin.");
        else{
            Trial started;started.exists=started.valid=true;started.first=started.seen=effectiveNow;juce::String error;
            if(writeTrial(started,error)){trial=started;trial.mirrorsFound=trial.mirrorsValid=paths.trialRecords.size();lastAction=vn("Đã bắt đầu dùng thử.");lastPersistMs=lastPersistAttemptMs=effectiveNow;}
            else lastAction=vn("Không lưu được ngày dùng thử: ")+error;
        }
    }

    const auto verified=cachedVerify(paths.license,config,keyCache,effectiveNow);
    Verification legacyVerified;juce::String legacyLabel;
    if(!verified.valid){
        if(legacyCache.size()!=legacyLicenses.size())legacyCache.assign(legacyLicenses.size(),KeyCache{});
        for(size_t i=0;i<legacyLicenses.size();++i){
            legacyVerified=cachedVerify(legacyLicenses[i].file,legacyLicenses[i].config,legacyCache[i],effectiveNow);
            if(legacyVerified.valid){legacyLabel=legacyLicenses[i].label;break;}
        }
    }

    auto describeKey=[&](const Verification& v){
        next.allowed=next.activated=true;next.owner=v.claims.owner;next.perpetual=v.claims.expiresMs==0;
        next.daysLeft=next.perpetual?0:int(std::ceil(double(v.claims.expiresMs-effectiveNow)/double(dayMs)));
        next.status=next.perpetual?vn("Đã kích hoạt · Vĩnh viễn"):vn("Đã kích hoạt · Còn ")+juce::String(next.daysLeft)+vn(" ngày");
    };
    if(verified.valid||legacyVerified.valid){
        // Only a pack key marks the machine as licensed; an old single-product
        // T-AutoKey key leaves the pack trial available for T-AutoTune.
        if(verified.valid&&!paths.activationHistory.existsAsFile()){juce::String ignored;atomicWrite(paths.activationHistory,"1",ignored);}
        if(verified.valid&&!trial.activatedOnce){
            // Mark the machine as licensed so deleting the key never re-opens a trial.
            if(!trial.valid){trial.first=effectiveNow-juce::int64(config.trialDays+1)*dayMs;trial.seen=effectiveNow;}
            trial.exists=true;trial.activatedOnce=true;mustPersist=true;
        }
        describeKey(verified.valid?verified:legacyVerified);
        if(!verified.valid){next.legacy=true;next.status+=vn(" · ")+legacyLabel;}
    }else if(trial.exists&&config.trialDays>0&&!history){
        next.trialStarted=true;
        if(trial.tampered){
            next.tampered=true;next.allowed=false;next.daysLeft=0;
            next.status=vn("Đã hết thời gian dùng thử");
            if(lastAction.isEmpty())lastAction=vn("Phát hiện ngày giờ máy bị chỉnh lùi hoặc dữ liệu dùng thử bị sửa. Bản dùng thử đã kết thúc; nhập key để tiếp tục.");
        }else{
            next.daysLeft=std::max(0,int(std::ceil(config.trialDays-double(effectiveNow-trial.first)/double(dayMs))));
            next.allowed=next.daysLeft>0;
            next.status=next.allowed?vn("Dùng thử · Còn ")+juce::String(next.daysLeft)+vn(" ngày"):vn("Đã hết thời gian dùng thử");
        }
    }else if(history&&!verified.valid){
        next.status=vn("Key đã hết hạn hoặc bị xóa · Nhập key mới");
    }else if(beforeBuild){
        next.status=vn("Ngày giờ của máy không đúng");
        if(lastAction.isEmpty())lastAction=vn("Chỉnh lại ngày giờ của máy cho đúng rồi mở lại plugin.");
    }else next.status=vn("Chưa kích hoạt · Nhập key hoặc bắt đầu dùng thử");
    next.trialAvailable=canStartTrial&&!beforeBuild&&!trial.exists;
    if(machines.isEmpty()){next.allowed=false;next.status=vn("Không đọc được mã máy");}

    // Persist the latest time seen (also after expiry) and heal deleted mirrors.
    // Rate limited: a mirror that cannot be written (e.g. a locked ProgramData
    // folder) must not cause a disk write every second.
    const bool due=mustPersist||trial.mirrorsFound<paths.trialRecords.size()||effectiveNow-lastPersistMs>=persistEveryMs;
    if(trial.exists&&due&&(mustPersist||effectiveNow-lastPersistAttemptMs>=retryWriteMs||effectiveNow<lastPersistAttemptMs)){
        Trial record=trial;
        if(!record.valid){record.first=effectiveNow;record.valid=true;}
        record.seen=std::max(record.seen,effectiveNow);
        juce::String error;lastPersistAttemptMs=effectiveNow;
        if(writeTrial(record,error)){
            lastPersistMs=effectiveNow;
            const auto keepTampered=trial.tampered;trial=record;trial.tampered=keepTampered;
            trial.mirrorsFound=trial.mirrorsValid=paths.trialRecords.size();
            trialReadMs=0; // read back what really landed on disk at the next poll
        }
    }
    cachedTrial=trial;trialCached=true;

    next.details=lastAction;if(next.details.isEmpty()&&verified.error.isNotEmpty()&&paths.license.existsAsFile())next.details=verified.error;
    next.details+=vn("\nTệp bản quyền: ")+paths.license.getFullPathName();
    publish(std::move(next));
}
}
