// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <juce_core/juce_core.h>
#include <juce_cryptography/juce_cryptography.h>

namespace tak::license {
struct Configuration {
    juce::String productId, brandId, name, publicKey;
    int trialDays = 7;
    juce::int64 buildEpochMs = 0; // clock earlier than this (minus 2 days) is treated as tampered
};
struct Claims {
    juce::String owner, productId, brandId;
    juce::int64 issuedMs = 0, expiresMs = 0;
    juce::StringArray machines;
};
struct Verification {
    bool valid = false;
    Claims claims;
    juce::String error;
};
juce::String shortHash(const juce::String&);
bool validMachineHash(const juce::String&);
juce::StringArray machineHashes();
juce::String requestText(const Configuration&,const juce::StringArray&);
juce::StringArray parseRequest(const juce::String&,const Configuration&,juce::String& error,const juce::StringArray& alsoAcceptProducts={});
bool createKeyPair(juce::String& publicKey,juce::String& privateKey,juce::String& error);
juce::String sign(const Claims&,const juce::String& privateKey,juce::String& error);
Verification verify(const juce::String& token,const Configuration&,const juce::StringArray& localMachines,juce::int64 nowMs);
juce::String hmacSha256Hex(const juce::String& key,const juce::String& message);
bool atomicWrite(const juce::File&,const juce::String&,juce::String& error,bool privateFile=false);
}
