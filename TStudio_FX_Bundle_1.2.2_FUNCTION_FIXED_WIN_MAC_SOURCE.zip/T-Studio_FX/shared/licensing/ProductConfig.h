// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "LicenseManager.h"
#include "LicenseBrand.generated.h"
namespace tak::license {
// One configuration for the whole pack: T-AutoKey and T-AutoTune read and
// write the same license and trial store, so one key (or one trial) covers both.
inline Configuration productConfiguration() {
    return {product::productId,product::brandId,juce::String::fromUTF8(product::name),product::publicKey,product::trialDays,juce::int64(product::buildEpochMs)};
}
inline StorePaths productStore() {return StorePaths::forProduct(productConfiguration());}
// Keys issued earlier for T-AutoKey alone keep unlocking T-AutoKey only.
inline std::vector<LegacyLicense> legacyAutoKeyLicenses() {
    const juce::String id(product::legacyAutoKeyProductId);
    if(id.isEmpty()||id==product::productId)return {};
    auto cfg=productConfiguration();cfg.productId=id;cfg.name="T-AutoKey";cfg.trialDays=0;
    return {LegacyLicense{cfg,StorePaths::forProduct(cfg).license,juce::String::fromUTF8("key T-AutoKey cũ (chỉ T-AutoKey)")}};
}
}
