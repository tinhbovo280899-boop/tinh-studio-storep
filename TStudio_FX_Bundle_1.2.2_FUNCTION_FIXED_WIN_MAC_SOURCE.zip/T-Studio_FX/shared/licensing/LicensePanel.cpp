// SPDX-License-Identifier: AGPL-3.0-or-later
#include "LicensePanel.h"
#include "ProductConfig.h"
namespace {juce::String vn(const char* s){return juce::String::fromUTF8(s);}}

TLicensePanel::TLicensePanel(Read r,std::function<void(const juce::String&)> a,std::function<void()> t,std::function<void()> c)
    :read(std::move(r)),activate(std::move(a)),trial(std::move(t)) {
    addAndMakeVisible(content);
    auto addLabel=[&](juce::Label& l,const juce::String& text,float size){l.setText(text,juce::dontSendNotification);l.setFont(juce::Font(juce::FontOptions(size)));l.setColour(juce::Label::textColourId,juce::Colour(0xffeee8db));content.addAndMakeVisible(l);};
    addLabel(title,vn("BẢN QUYỀN · ")+juce::String::fromUTF8(tak::product::name),20);
    addLabel(status,{},12);addLabel(machineTitle,vn("MÃ MÁY / PHIẾU KÍCH HOẠT"),11);addLabel(keyTitle,vn("DÁN KEY HOẶC NHẬP FILE .taklic"),11);
    addLabel(details,{},11);details.setJustificationType(juce::Justification::topLeft);
    addLabel(contact,juce::String::fromUTF8(tak::product::contactNote),11);
    addLabel(scope,juce::String::fromUTF8(tak::product::scopeNote),11);
    scope.setColour(juce::Label::textColourId,juce::Colour(0xffe9c27a));
    for(auto* editor:{&request,&key}){editor->setMultiLine(true);editor->setReturnKeyStartsNewLine(true);editor->setFont(juce::Font(juce::FontOptions(11)));editor->setColour(juce::TextEditor::backgroundColourId,juce::Colour(0xff11141a));editor->setColour(juce::TextEditor::textColourId,juce::Colour(0xffeee8db));content.addAndMakeVisible(editor);}
    request.setReadOnly(true);key.setTextToShowWhenEmpty(vn("Dán mã bản quyền được cấp cho máy này..."),juce::Colour(0xff9399a4));
    auto button=[&](juce::TextButton& b,const juce::String& text){b.setButtonText(text);b.setColour(juce::TextButton::buttonColourId,juce::Colour(0xff272b35));b.setColour(juce::TextButton::textColourOffId,juce::Colour(0xffe9c27a));content.addAndMakeVisible(b);};
    button(closeButton,"X");closeButton.onClick=std::move(c);
    button(copyRequest,vn("CHÉP MÃ MÁY"));copyRequest.onClick=[this]{juce::SystemClipboard::copyTextToClipboard(request.getText());};
    button(saveRequest,vn("XUẤT PHIẾU .txt"));saveRequest.onClick=[this]{exportRequest();};
    button(importKey,vn("NHẬP FILE"));importKey.onClick=[this]{chooseLicense();};
    button(activateButton,vn("KÍCH HOẠT"));activateButton.onClick=[this]{activate(key.getText());};
    button(trialButton,vn("THỬ TỰ ĐỘNG"));trialButton.onClick=[this]{trial();};trialButton.setTooltip(vn("Dùng thử tự bắt đầu khi mở plugin hoặc đưa audio vào lần đầu. Không cần bấm nút này."));
    setSize(680,400);timerCallback();startTimerHz(4);
}
void TLicensePanel::timerCallback(){
    const auto s=read();status.setText(s.status+(s.owner.isNotEmpty()?" · "+s.owner:juce::String()),juce::dontSendNotification);
    details.setText(s.details,juce::dontSendNotification);
    details.setColour(juce::Label::textColourId,s.tampered?juce::Colour(0xfff0928a):juce::Colour(0xffeee8db));
    if(request.getText()!=s.request)request.setText(s.request,false);
    trialButton.setEnabled(s.trialAvailable&&s.fingerprint.isNotEmpty());
    copyRequest.setEnabled(s.fingerprint.isNotEmpty());saveRequest.setEnabled(s.fingerprint.isNotEmpty());
}
void TLicensePanel::paint(juce::Graphics& g){g.fillAll(juce::Colour(0xff0b0e14));g.setColour(juce::Colour(0xffe9c27a));g.fillRect(20,10,getWidth()-40,2);}
void TLicensePanel::resized(){
    content.setBounds(0,0,680,400);content.setTransform(juce::AffineTransform::scale(getWidth()/680.f,getHeight()/400.f));
    title.setBounds(20,16,580,30);closeButton.setBounds(625,16,35,30);status.setBounds(20,49,640,25);
    machineTitle.setBounds(20,76,260,18);keyTitle.setBounds(300,76,360,18);request.setBounds(20,98,260,112);key.setBounds(300,98,360,112);
    scope.setBounds(20,256,640,18);
    copyRequest.setBounds(20,220,120,32);saveRequest.setBounds(148,220,132,32);importKey.setBounds(300,220,100,32);activateButton.setBounds(408,220,112,32);trialButton.setBounds(528,220,132,32);
    details.setBounds(20,276,640,74);contact.setBounds(20,355,640,28);
}
void TLicensePanel::chooseLicense(){
    chooser=std::make_unique<juce::FileChooser>(vn("Chọn file bản quyền ")+juce::String::fromUTF8(tak::product::name),juce::File::getSpecialLocation(juce::File::userDocumentsDirectory),"*.taklic;*.txt");
    chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles,[safe=juce::Component::SafePointer<TLicensePanel>(this)](const juce::FileChooser& c){if(!safe)return;const auto f=c.getResult();if(f.existsAsFile()&&f.getSize()<=32768)safe->key.setText(f.loadFileAsString(),false);});
}
void TLicensePanel::exportRequest(){
    chooser=std::make_unique<juce::FileChooser>(vn("Xuất phiếu mã máy để gửi người bán"),juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile(juce::File::createLegalFileName(juce::String::fromUTF8(tak::product::name)).replaceCharacter(' ','-')+"_MaMay.txt"),"*.txt");
    chooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting,[safe=juce::Component::SafePointer<TLicensePanel>(this)](const juce::FileChooser& c){if(!safe)return;const auto f=c.getResult();if(f==juce::File())return;juce::String error;if(!tak::license::atomicWrite(f,safe->request.getText(),error))safe->details.setText(vn("Không xuất được phiếu: ")+error,juce::dontSendNotification);});
}
