// SPDX-License-Identifier: AGPL-3.0-or-later
#include "LicenseCodec.h"
#include <array>
#include <filesystem>
#include <fstream>
#if JUCE_WINDOWS
 #ifndef NOMINMAX
  #define NOMINMAX 1
 #endif
 #include <windows.h>
 #include <bcrypt.h>
#elif JUCE_MAC
 #include <Security/SecRandom.h>
#else
 #include <sys/random.h>
#endif

namespace tak::license {
namespace {
bool secureRandom(void* destination,size_t bytes) {
   #if JUCE_WINDOWS
    return BCryptGenRandom(nullptr,static_cast<PUCHAR>(destination),static_cast<ULONG>(bytes),BCRYPT_USE_SYSTEM_PREFERRED_RNG)==0;
   #elif JUCE_MAC
    return SecRandomCopyBytes(kSecRandomDefault,bytes,static_cast<uint8_t*>(destination))==errSecSuccess;
   #else
    auto* out=static_cast<unsigned char*>(destination);size_t done=0;
    while(done<bytes){const auto n=::getrandom(out+done,bytes-done,0);if(n<0){if(errno==EINTR)continue;return false;}if(n==0)return false;done+=size_t(n);}return true;
   #endif
}
bool keyParts(const juce::String& text,juce::BigInteger& exponent,juce::BigInteger& modulus) {
    const auto pieces=juce::StringArray::fromTokens(text.trim(),",","");
    if(pieces.size()!=2)return false;
    for(const auto& p:pieces)if(p.isEmpty()||p.length()>2048||!p.containsOnly("0123456789abcdefABCDEF"))return false;
    exponent.parseString(pieces[0],16);modulus.parseString(pieces[1],16);
    const int bits=modulus.getHighestBit()+1;
    return exponent>1&&exponent<modulus&&bits>=2047&&bits<=4096&&modulus[0];
}
juce::BigInteger encodedMessage(const juce::String& message,int bytes) {
    // EMSA-PKCS1-v1_5 SHA-256, RFC 8017 section 9.2. Compare the entire
    // encoded block on verification; never accept a partial ASN.1 prefix.
    const juce::String digestInfo="3031300d060960864801650304020105000420";
    const auto digest=juce::SHA256(message.toRawUTF8(),size_t(message.getNumBytesAsUTF8())).toHexString();
    const auto hex=juce::String("0001")+juce::String::repeatedString("ff",bytes-54)+"00"+digestInfo+digest;
    juce::BigInteger value;value.parseString(hex,16);return value;
}
bool validIdentifier(const juce::String& s) {return s.isNotEmpty()&&s.length()<=64&&s.containsOnly("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-");}
bool validOwner(const juce::String& s) {if(s.trim().isEmpty()||s.length()>128)return false;for(auto c:s)if(c<32||c==127)return false;return true;}
bool validClaims(const Claims& c) {
    if(!validOwner(c.owner)||!validIdentifier(c.productId)||!validIdentifier(c.brandId)||c.issuedMs<=0||c.expiresMs<0||(c.expiresMs>0&&c.expiresMs<=c.issuedMs)||c.machines.isEmpty()||c.machines.size()>32)return false;
    for(const auto& s:c.machines)if(!validMachineHash(s))return false;return true;
}
juce::String payloadFor(const Claims& c) {
    auto* obj=new juce::DynamicObject;obj->setProperty("schema",1);obj->setProperty("product",c.productId);obj->setProperty("brand",c.brandId);
    obj->setProperty("owner",c.owner);obj->setProperty("issued",c.issuedMs);obj->setProperty("expires",c.expiresMs);
    juce::Array<juce::var> ids;for(const auto& id:c.machines)ids.add(id);obj->setProperty("machines",ids);
    return juce::JSON::toString(juce::var(obj),true);
}
bool signedInteger(const juce::var& v){return v.isInt()||v.isInt64();}
}

juce::String shortHash(const juce::String& s) {
    auto h=juce::SHA256(s.toRawUTF8(),size_t(s.getNumBytesAsUTF8())).toHexString().toUpperCase().substring(0,12);
    return h.substring(0,4)+"-"+h.substring(4,8)+"-"+h.substring(8,12);
}
bool validMachineHash(const juce::String& s) {return s.length()==14&&s[4]=='-'&&s[9]=='-'&&s.removeCharacters("-").length()==12&&s.removeCharacters("-").containsOnly("0123456789ABCDEF");}
juce::StringArray machineHashes() {
    using F=juce::SystemStats::MachineIdFlags;
    const auto flags=static_cast<F>(int(F::uniqueId)|int(F::macAddresses)|int(F::fileSystemId));
    juce::StringArray hashes;for(const auto& s:juce::SystemStats::getMachineIdentifiers(flags))if(s.isNotEmpty())hashes.add(shortHash(s));
    hashes.removeDuplicates(false);return hashes;
}
juce::String requestText(const Configuration& c,const juce::StringArray& machines) {
    return c.name+" activation request\nProduct: "+c.productId+"\nBrand: "+c.brandId+"\n\n"+machines.joinIntoString("\n")+"\n";
}
juce::StringArray parseRequest(const juce::String& text,const Configuration& c,juce::String& error,const juce::StringArray& alsoAccept) {
    error.clear();juce::StringArray ids;if(text.length()>16384){error="Request too large";return {};}
    for(auto line:juce::StringArray::fromLines(text)){
        line=line.trim();
        if(line.startsWith("Product:")&&line.fromFirstOccurrenceOf(":",false,false).trim()!=c.productId&&!alsoAccept.contains(line.fromFirstOccurrenceOf(":",false,false).trim())){error="Request belongs to another product";return {};}
        if(line.startsWith("Brand:")&&line.fromFirstOccurrenceOf(":",false,false).trim()!=c.brandId){error="Request belongs to another brand";return {};}
        if(validMachineHash(line.toUpperCase()))ids.add(line.toUpperCase());
    }
    ids.removeDuplicates(false);if(ids.isEmpty()||ids.size()>32){error="No valid machine identifiers";return {};}return ids;
}
bool createKeyPair(juce::String& publicKey,juce::String& privateKey,juce::String& error) {
    error.clear();publicKey.clear();privateKey.clear();
    for(int attempt=0;attempt<16;++attempt){
        std::array<int,32> seeds{};if(!secureRandom(seeds.data(),sizeof(seeds))){error="Operating system random source failed";return false;}
        auto p=juce::Primes::createProbablePrime(1024,40,seeds.data(),16);
        auto q=juce::Primes::createProbablePrime(1024,40,seeds.data()+16,16);if(p==q)continue;
        const auto modulus=p*q;if(modulus.getHighestBit()!=2047)continue;--p;--q;const auto phi=p*q;const juce::BigInteger exponent(65537);
        if(!exponent.findGreatestCommonDivisor(phi).isOne())continue;
        auto d=exponent;d.inverseModulo(phi);
        publicKey=exponent.toString(16)+","+modulus.toString(16);privateKey=d.toString(16)+","+modulus.toString(16);return true;
    }
    error="Could not generate an RSA key pair";return false;
}
juce::String sign(const Claims& claims,const juce::String& privateText,juce::String& error) {
    error.clear();if(!validClaims(claims)){error="Invalid customer, duration or machine identifiers";return {};}
    juce::BigInteger exponent,modulus;if(!keyParts(privateText,exponent,modulus)){error="Invalid private key";return {};}
    const int bytes=(modulus.getHighestBit()+8)/8;const auto payload=payloadFor(claims);auto value=encodedMessage(payload,bytes);
    if(!juce::RSAKey(privateText).applyToValue(value)){error="Signing failed";return {};}
    return "TAK1."+juce::Base64::toBase64(payload.toRawUTF8(),size_t(payload.getNumBytesAsUTF8()))+"."+value.toString(16,bytes*2);
}
Verification verify(const juce::String& text,const Configuration& cfg,const juce::StringArray& local,juce::int64 now) {
    Verification result;auto fail=[&](const char* message){result.error=message;return result;};
    if(text.length()>32768||cfg.publicKey.isEmpty())return fail("License verifier is not configured");
    const auto compact=text.trim().removeCharacters("\r\n\t ");const auto parts=juce::StringArray::fromTokens(compact,".","");
    if(parts.size()!=3||parts[0]!="TAK1")return fail("Invalid license format");
    juce::BigInteger exponent,modulus;if(!keyParts(cfg.publicKey,exponent,modulus)||exponent!=juce::BigInteger(65537))return fail("Invalid public key");
    const int bytes=(modulus.getHighestBit()+8)/8;
    if(parts[2].length()!=bytes*2||!parts[2].containsOnly("0123456789abcdefABCDEF"))return fail("Invalid signature");
    juce::MemoryOutputStream decoded;if(parts[1].length()>16000||!juce::Base64::convertFromBase64(decoded,parts[1])||decoded.getDataSize()>8192)return fail("Invalid payload");
    const auto payload=juce::String::fromUTF8(static_cast<const char*>(decoded.getData()),int(decoded.getDataSize()));
    if(size_t(payload.getNumBytesAsUTF8())!=decoded.getDataSize())return fail("Invalid UTF-8 payload");
    juce::BigInteger signature;signature.parseString(parts[2],16);if(signature<=0||signature>=modulus)return fail("Invalid signature range");
    if(!juce::RSAKey(cfg.publicKey).applyToValue(signature)||signature!=encodedMessage(payload,bytes))return fail("Signature does not match");
    const auto data=juce::JSON::parse(payload);auto* obj=data.getDynamicObject();if(!obj)return fail("Invalid license data");
    if(!obj->getProperty("schema").isInt()||int(obj->getProperty("schema"))!=1)return fail("Unsupported license version");
    for(const auto* field:{"product","brand","owner"})if(!obj->getProperty(field).isString())return fail("Invalid license text field");
    if(!signedInteger(obj->getProperty("issued"))||!signedInteger(obj->getProperty("expires")))return fail("Invalid license date");
    Claims c;c.productId=obj->getProperty("product").toString();c.brandId=obj->getProperty("brand").toString();c.owner=obj->getProperty("owner").toString();
    c.issuedMs=juce::int64(obj->getProperty("issued"));c.expiresMs=juce::int64(obj->getProperty("expires"));
    auto* ids=obj->getProperty("machines").getArray();if(!ids)return fail("Invalid machine identifiers");
    for(const auto& id:*ids){if(!id.isString())return fail("Invalid machine identifier");c.machines.add(id.toString());}c.machines.removeDuplicates(false);
    if(!validClaims(c))return fail("Invalid license claims");
    if(c.productId!=cfg.productId||c.brandId!=cfg.brandId)return fail("License belongs to another product or brand");
    if(now<=0||c.issuedMs>now+86400000LL)return fail("License issue date is in the future");
    if(c.expiresMs>0&&now>=c.expiresMs)return fail("License has expired");
    int matches=0;auto uniqueLocal=local;uniqueLocal.removeDuplicates(false);for(const auto& id:uniqueLocal)if(c.machines.contains(id))++matches;
    if(matches<juce::jmin(2,c.machines.size()))return fail("License belongs to another machine");
    result.valid=true;result.claims=c;return result;
}
juce::String hmacSha256Hex(const juce::String& keyText,const juce::String& message) {
    // RFC 2104 HMAC with SHA-256 (block size 64 bytes).
    juce::MemoryBlock key(keyText.toRawUTF8(),size_t(keyText.getNumBytesAsUTF8()));
    if(key.getSize()>64)key=juce::SHA256(key).getRawData();
    key.ensureSize(64,true);
    juce::MemoryBlock inner,outer;
    for(size_t i=0;i<64;++i){const auto b=static_cast<const unsigned char*>(key.getData())[i];const unsigned char ib=b^0x36,ob=b^0x5c;inner.append(&ib,1);outer.append(&ob,1);}
    inner.append(message.toRawUTF8(),size_t(message.getNumBytesAsUTF8()));
    outer.append(juce::SHA256(inner).getRawData().getData(),32);
    return juce::SHA256(outer).toHexString();
}
bool atomicWrite(const juce::File& file,const juce::String& text,juce::String& error,bool privateFile) {
    error.clear();const auto parent=file.getParentDirectory();auto created=parent.createDirectory();if(created.failed()){error=created.getErrorMessage();return false;}
    const auto temporary=parent.getNonexistentChildFile(file.getFileName()+".tmp-"+juce::Uuid().toString(),{},false);
    struct Cleanup {juce::File file;~Cleanup(){file.deleteFile();}}cleanup{temporary};
    {juce::FileOutputStream stream(temporary);if(stream.failedToOpen()){error=stream.getStatus().getErrorMessage();return false;}
     stream.write(text.toRawUTF8(),size_t(text.getNumBytesAsUTF8()));stream.flush();if(stream.getStatus().failed()){error=stream.getStatus().getErrorMessage();return false;}}
    if(privateFile){std::error_code ec;std::filesystem::permissions(std::filesystem::u8path(temporary.getFullPathName().toStdString()),std::filesystem::perms::owner_read|std::filesystem::perms::owner_write,std::filesystem::perm_options::replace,ec);if(ec){error=ec.message();return false;}}
   #if JUCE_WINDOWS
    if(!MoveFileExW(temporary.getFullPathName().toWideCharPointer(),file.getFullPathName().toWideCharPointer(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)){error="Cannot replace file (Windows "+juce::String(int(GetLastError()))+")";return false;}
   #else
    std::error_code ec;std::filesystem::rename(std::filesystem::u8path(temporary.getFullPathName().toStdString()),std::filesystem::u8path(file.getFullPathName().toStdString()),ec);if(ec){error=ec.message();return false;}
   #endif
    return true;
}
}
