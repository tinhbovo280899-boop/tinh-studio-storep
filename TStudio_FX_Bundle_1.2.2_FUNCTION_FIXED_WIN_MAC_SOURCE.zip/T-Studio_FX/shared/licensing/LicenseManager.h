// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "LicenseCodec.h"
#include <atomic>
#include <vector>

namespace tak::license {

// One trial state for the whole pack. The same record is mirrored to several
// places so deleting one folder neither resets nor extends the trial.
struct StorePaths {
    juce::File license;                 // license.taklic of the pack
    juce::File activationHistory;       // written once any key was ever valid here
    juce::Array<juce::File> trialRecords; // signed trial mirrors (first = primary)
    juce::String registryKey;           // Windows only: HKCU path of one more mirror
    static StorePaths forProduct(const Configuration&);
    static StorePaths under(const juce::File& root,const juce::String& storeName); // tests / portable
};

// An older single-product key that keeps working for one plugin only
// (existing T-AutoKey customers). Verified with its own product id.
struct LegacyLicense {
    Configuration config;
    juce::File file;
    juce::String label;
};

struct Snapshot {
    bool allowed=false,activated=false,perpetual=false,trialStarted=false,trialAvailable=false,tampered=false,legacy=false;
    int daysLeft=0;
    juce::String status,details,owner,fingerprint,request;
};

// Construct without opening files. poll() and destruction are worker-side;
// the audio callback only reads isAllowed(), an atomic boolean.
class LicenseManager {
public:
    LicenseManager(Configuration,StorePaths,juce::StringArray testMachines={},std::vector<LegacyLicense> legacy={});
    void poll(juce::int64 nowMs=juce::Time::getCurrentTime().toMilliseconds());
    bool isAllowed() const noexcept {return allowed.load(std::memory_order_acquire);}
    void requestActivation(const juce::String&);
    void requestTrial() noexcept {trialRequested.store(true);}
    void requestAutomaticTrial() noexcept {automaticTrialRequested.store(true);}
    Snapshot snapshot() const;
    const Configuration& configuration() const noexcept {return config;}

    // Trial record helpers (public for tests).
    struct Trial {bool exists=false,valid=false,tampered=false,activatedOnce=false;juce::int64 first=0,seen=0;int mirrorsFound=0,mirrorsValid=0;};
    Trial readTrial() const;
    static constexpr juce::int64 rollbackToleranceMs = 60LL*60LL*1000LL;   // 1 hour
    static constexpr juce::int64 buildToleranceMs   = 2LL*86400000LL;      // 2 days
private:
    bool writeTrial(const Trial&,juce::String&);
    juce::String encodeTrial(const Trial&) const;
    bool decodeTrial(const juce::String&,Trial&) const;
    juce::String trialSecret() const;
    juce::String readRegistry() const;
    void writeRegistry(const juce::String&) const;
    void publish(Snapshot);
    // v1.2.1: poll() runs every second, so it must be cheap. The signed key is
    // re-verified only when its file changes (or every 10 minutes), the trial
    // mirrors are re-read every 15 seconds, and the trial timestamp is written
    // at most every 10 minutes instead of every minute.
    struct KeyCache {juce::String stamp;Verification result;juce::int64 checkedMs=0;};
    Verification cachedVerify(const juce::File&,const Configuration&,KeyCache&,juce::int64 now) const;
    Configuration config;StorePaths paths;juce::StringArray machines;std::vector<LegacyLicense> legacyLicenses;
    std::atomic<bool> allowed{false},trialRequested{false},automaticTrialRequested{false};
    mutable juce::CriticalSection lock;
    juce::String pendingActivation,lastAction;
    Snapshot state;
    juce::int64 maxObservedMs=0,lastPersistMs=0,lastPersistAttemptMs=0,trialReadMs=0;
    Trial cachedTrial;bool trialCached=false;
    mutable KeyCache keyCache;mutable std::vector<KeyCache> legacyCache;
public:
    static constexpr juce::int64 trialRereadMs   = 15000;          // re-read trial mirrors
    static constexpr juce::int64 keyRecheckMs    = 10LL*60LL*1000LL; // re-verify an unchanged key
    static constexpr juce::int64 persistEveryMs  = 10LL*60LL*1000LL; // refresh the "seen" timestamp
    static constexpr juce::int64 retryWriteMs    = 60000;          // after a failed mirror write
};
}
