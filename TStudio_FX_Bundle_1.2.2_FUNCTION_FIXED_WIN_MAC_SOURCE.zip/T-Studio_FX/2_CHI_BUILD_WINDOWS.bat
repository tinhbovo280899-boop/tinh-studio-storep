@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\windows.ps1" -Action Build
set "BUNDLE_EXIT=%errorlevel%"
if not "%BUNDLE_EXIT%"=="0" echo [LOI] Xem log trong build\logs.
pause
exit /b %BUNDLE_EXIT%
