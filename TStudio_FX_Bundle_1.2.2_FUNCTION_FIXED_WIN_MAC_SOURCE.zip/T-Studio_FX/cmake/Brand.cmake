# ---- Doi thuong hieu (ThuongHieu.json) -------------------------------------------------
# Dung chung cho ca 5 bo VST. Mac dinh (publisher "T Studio", namePrefix "T-") giu NGUYEN
# ten plugin, ma hang (manufacturer code), bundle ID va bo cai nhu cu.
#
#   namePrefix        "T-"        -> "LCH-": T-Verb -> LCH-Verb (ten file .vst3, ten trong DAW, tieu de giao dien)
#   publisher         "T Studio"  -> ten hang hien trong DAW, bo cai, thu muc cai dat
#   brandLogo         ""          -> chu logo goc trai giao dien (trong = publisher viet HOA)
#   manufacturerCode  ""          -> 4 ky tu, chu dau VIET HOA (vd "Lchs"). Trong = giu ma cu khi la
#                                    T Studio; thuong hieu khac thi tu sinh tu publisher.
#   bundleIdPrefix    ""          -> vd "com.lchstudio". Trong = giu ID cu khi la T Studio;
#                                    thuong hieu khac thi tu dung "com.<publisher viet thuong>".
#
# Dung duoc ca trong project lan cmake -P (VerifyStage.cmake): neu chua co TAK_BRAND_JSON thi
# tu doc ThuongHieu.json o thu muc cha cua cmake/.
if(NOT DEFINED TAK_BRAND_JSON)
    file(READ "${CMAKE_CURRENT_LIST_DIR}/../ThuongHieu.json" TAK_BRAND_JSON)
endif()
if(NOT DEFINED TAK_publisher)
    string(JSON TAK_publisher GET "${TAK_BRAND_JSON}" publisher)
endif()

function(_tak_brand_field out key default)
    string(JSON _type ERROR_VARIABLE _err TYPE "${TAK_BRAND_JSON}" "${key}")
    if(_err OR NOT _type STREQUAL "STRING")
        set(${out} "${default}" PARENT_SCOPE)
        return()
    endif()
    string(JSON _value GET "${TAK_BRAND_JSON}" "${key}")
    string(STRIP "${_value}" _value)
    set(${out} "${_value}" PARENT_SCOPE)
endfunction()

_tak_brand_field(TAK_namePrefix namePrefix "T-")
_tak_brand_field(TAK_brandLogo brandLogo "")
_tak_brand_field(TAK_manufacturerCode manufacturerCode "")
_tak_brand_field(TAK_bundleIdPrefix bundleIdPrefix "")
string(STRIP "${TAK_publisher}" TAK_publisher)
if(TAK_brandLogo STREQUAL "")
    string(TOUPPER "${TAK_publisher}" TAK_brandLogo)
endif()

if(TAK_publisher STREQUAL "")
    message(FATAL_ERROR "ThuongHieu.json: publisher khong duoc de trong")
endif()
if(NOT TAK_publisher MATCHES "^[A-Za-z0-9 ._&-]+$")
    message(FATAL_ERROR "ThuongHieu.json: publisher chi dung chu khong dau, so, khoang trang, . _ & - (dang la '${TAK_publisher}')")
endif()
if(NOT TAK_namePrefix MATCHES "^[A-Za-z0-9 ._-]*$")
    message(FATAL_ERROR "ThuongHieu.json: namePrefix chi dung chu khong dau, so, khoang trang, . _ - (dang la '${TAK_namePrefix}')")
endif()

# Thuong hieu goc = T Studio voi tien to T-: giu nguyen moi ten / ID / bo cai.
if(TAK_publisher STREQUAL "T Studio" AND TAK_namePrefix STREQUAL "T-")
    set(TAK_IS_ORIGINAL_BRAND ON)
else()
    set(TAK_IS_ORIGINAL_BRAND OFF)
endif()

string(REGEX REPLACE "[^A-Za-z0-9]" "" TAK_publisherAlnum "${TAK_publisher}")
string(TOLOWER "${TAK_publisherAlnum}" TAK_publisherLower)
if(TAK_publisherAlnum STREQUAL "")
    message(FATAL_ERROR "ThuongHieu.json: publisher phai co it nhat mot chu hoac so")
endif()

if(NOT TAK_manufacturerCode STREQUAL "")
    if(NOT TAK_manufacturerCode MATCHES "^[A-Z][A-Za-z0-9][A-Za-z0-9][A-Za-z0-9]$")
        message(FATAL_ERROR "ThuongHieu.json: manufacturerCode phai dung 4 ky tu chu/so, ky tu dau VIET HOA (vd \"Lchs\"), dang la '${TAK_manufacturerCode}'")
    endif()
    set(TAK_mfrOverride "${TAK_manufacturerCode}")
elseif(NOT TAK_IS_ORIGINAL_BRAND)
    # Tu sinh tu publisher: "LCH Studio" -> "Lchs". Nen dat manufacturerCode rieng trong ThuongHieu.json.
    string(SUBSTRING "${TAK_publisherAlnum}xxxx" 0 4 _code)
    string(SUBSTRING "${_code}" 0 1 _first)
    string(SUBSTRING "${_code}" 1 3 _rest)
    string(TOUPPER "${_first}" _first)
    string(TOLOWER "${_rest}" _rest)
    if(NOT _first MATCHES "^[A-Z]$")
        set(_first "X")
    endif()
    set(TAK_mfrOverride "${_first}${_rest}")
    if(NOT CMAKE_SCRIPT_MODE_FILE)
        message(WARNING "ThuongHieu.json chua co manufacturerCode: tu dung '${TAK_mfrOverride}'. Nen dat 4 ky tu rieng (vd \"Lchs\") va GIU CO DINH cho moi lan build.")
    endif()
else()
    set(TAK_mfrOverride "")
endif()

if(NOT TAK_bundleIdPrefix STREQUAL "")
    if(NOT TAK_bundleIdPrefix MATCHES "^[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)+$")
        message(FATAL_ERROR "ThuongHieu.json: bundleIdPrefix dang 'com.tenhang' (chu khong dau, so, dau cham), dang la '${TAK_bundleIdPrefix}'")
    endif()
    set(TAK_bundleOverride "${TAK_bundleIdPrefix}")
elseif(NOT TAK_IS_ORIGINAL_BRAND)
    set(TAK_bundleOverride "com.${TAK_publisherLower}")
else()
    set(TAK_bundleOverride "")
endif()

# "T-Verb" -> "<namePrefix>Verb". Ten khong bat dau bang "T-" giu nguyen.
function(tak_brand_name out name)
    if(name MATCHES "^T-(.*)$")
        set(${out} "${TAK_namePrefix}${CMAKE_MATCH_1}" PARENT_SCOPE)
    else()
        set(${out} "${name}" PARENT_SCOPE)
    endif()
endfunction()

function(tak_brand_manufacturer out code)
    if(TAK_mfrOverride STREQUAL "")
        set(${out} "${code}" PARENT_SCOPE)
    else()
        set(${out} "${TAK_mfrOverride}" PARENT_SCOPE)
    endif()
endfunction()

# "com.tstudio.tverb" -> "<bundleIdPrefix>.tverb"
function(tak_brand_bundle_id out id)
    if(TAK_bundleOverride STREQUAL "")
        set(${out} "${id}" PARENT_SCOPE)
    else()
        string(REGEX REPLACE "^.*\\." "" _leaf "${id}")
        set(${out} "${TAK_bundleOverride}.${_leaf}" PARENT_SCOPE)
    endif()
endfunction()

# COMPANY_NAME: T Studio giu ten hang cu cua tung plugin (vd T-EQ = "NT Studio"); thuong hieu khac = publisher.
function(tak_brand_company out company)
    if(TAK_IS_ORIGINAL_BRAND AND NOT company STREQUAL "")
        set(${out} "${company}" PARENT_SCOPE)
    else()
        set(${out} "${TAK_publisher}" PARENT_SCOPE)
    endif()
endfunction()

foreach(item IN ITEMS namePrefix brandLogo)
    string(REPLACE "\\" "\\\\" TAK_${item}_CPP "${TAK_${item}}")
    string(REPLACE "\"" "\\\"" TAK_${item}_CPP "${TAK_${item}_CPP}")
endforeach()
set(TAK_NAME_PREFIX_CPP "${TAK_namePrefix_CPP}")
set(TAK_BRAND_LOGO_CPP "${TAK_brandLogo_CPP}")

if(NOT CMAKE_SCRIPT_MODE_FILE)
    if(TAK_IS_ORIGINAL_BRAND)
        message(STATUS "Thuong hieu: T Studio (goc) - giu nguyen ten va ID plugin")
    else()
        message(STATUS "Thuong hieu: ${TAK_publisher} | tien to '${TAK_namePrefix}' | ma hang ${TAK_mfrOverride} | bundle ${TAK_bundleOverride}.*")
    endif()
endif()
