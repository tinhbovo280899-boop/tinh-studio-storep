#!/bin/bash
bundle_root="$(cd "$(dirname "$0")" && pwd)"
/bin/bash "$bundle_root/tools/mac.sh" all 'arm64;x86_64'
result=$?
if [[ $result -ne 0 ]]; then echo '[ERROR] Check build/logs.'; fi
read -r -p 'Press Return to close...' _reply
exit "$result"
