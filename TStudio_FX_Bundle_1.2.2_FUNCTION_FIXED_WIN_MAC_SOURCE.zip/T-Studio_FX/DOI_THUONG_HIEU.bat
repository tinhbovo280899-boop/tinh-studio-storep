@echo off
setlocal
rem Doi ten hang / tien to plugin / logo / ma hang / ma key cho BO NAY (ghi ThuongHieu.json).
rem Doc them: HUONG_DAN_DOI_THUONG_HIEU.txt
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\DoiThuongHieu.ps1"
set "BRAND_EXIT=%errorlevel%"
pause
exit /b %BRAND_EXIT%
