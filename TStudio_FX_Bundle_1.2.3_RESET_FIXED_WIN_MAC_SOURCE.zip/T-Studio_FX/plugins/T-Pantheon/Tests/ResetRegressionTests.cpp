#include "dsp/PhoenixChamber.h"
#include <cstdio>

namespace {
int failures = 0;
struct Settings {
    int type;
    float size, rt, spread, damping, bass, bassHz, diffusion, regen,
          delay, pre, echoDbL, echoMsL, echoDbR, echoMsR;
};
constexpr Settings initial { 0,38,2.03f,83,2080,1.2f,381,65,0,14,0,-60,0,-60,0 };
constexpr Settings first   { 1,24,3,43,500,2.1f,120,25,20,40,50,-20,63,-30,93 };
constexpr Settings final   { 4,64,.7f,90,12000,.4f,880,83,10,19,150,-12,123,-18,211 };

void configure(tpantheon::PhoenixChamber& c, const Settings& s)
{
    c.setParameters(s.type,s.size,s.rt,s.spread,s.damping,s.bass,s.bassHz,
                    s.diffusion,s.regen,s.delay,s.pre,100,0,
                    s.echoDbL,s.echoMsL,s.echoDbR,s.echoMsR,1);
}
void warm(tpantheon::PhoenixChamber& c, int samples)
{
    for (int i=0;i<samples;++i) {
        float l,r;
        c.processStereoSample(.04f*std::sin(i*.037f),.03f*std::cos(i*.021f),l,r);
    }
}
void check(bool ok, const char* message)
{
    if (!ok) { ++failures; std::printf("FAIL: %s\n",message); }
}
}

int main()
{
    int cases=0;
    for (double sr : {8000.,32000.,44100.,48000.,96000.,192000.})
        for (int scenario=0;scenario<4;++scenario) {
            tpantheon::PhoenixChamber changed, fresh;
            changed.prepare(sr);
            configure(changed,initial);
            warm(changed,int(sr*.05));
            Settings target=first;
            configure(changed,first);
            warm(changed,10); // still inside the 20 ms read-head transition
            if (scenario==1 || scenario==2) {
                configure(changed,final); // queued, not active yet
                target=final;
                if (scenario==2) {
                    target.pre=219; target.size=13; target.rt=1.4f;
                    configure(changed,target); // coalesced again
                }
            }
            if (scenario==3) {
                // Finish geometry, then change only the wet tone. Reset must
                // clear both filter memory and the old coefficient ramp.
                warm(changed,int(sr*.03));
                target.damping=15700; target.bass=.2f; target.bassHz=3700;
                configure(changed,target);
                warm(changed,10);
            }
            changed.reset();
            configure(changed,target); // typical host repeats unchanged params
            fresh.prepare(sr);
            configure(fresh,target);
            fresh.reset();

            double maxError=0;
            for (int i=0;i<int(sr*.65);++i) {
                const float input=i==0?.1f:0.f;
                float al,ar,bl,br;
                changed.processStereoSample(input,input,al,ar);
                fresh.processStereoSample(input,input,bl,br);
                check(std::isfinite(al)&&std::isfinite(ar),"reset render finite");
                maxError=std::max(maxError,std::abs(double(al)-bl));
                maxError=std::max(maxError,std::abs(double(ar)-br));
            }
            check(maxError==0,"reset matches a fresh engine with latest settings");
            changed.reset();
            changed.reset(); // repeated reset is safe
            for (int i=0;i<128;++i) {
                float l,r; changed.processStereoSample(0,0,l,r);
                check(l==0&&r==0,"reset flushes the entire wet tail");
            }
            std::printf("RESET sr=%.0f scenario=%d max_fresh_difference=%.9g\n",sr,scenario,maxError);
            ++cases;
        }
    std::printf("PANTHEON RESET: %d cases, %d failures\n",cases,failures);
    return failures?1:0;
}
