# T Studio FX 1.2.3 — vá reset sau khi rà lại 1.2.2

Gói gồm mã nguồn đầy đủ của T-Verb, T-RVerb, T-PANTHEON và T-LIQUID DELAY, JUCE và script build/tạo bộ cài. Chưa có VST3/AU/EXE/PKG Windows/macOS đã biên dịch native.

## Lỗi đã tái hiện và sửa

**PANTHEON:** khi đang nối chéo đầu đọc, lần chỉnh tiếp theo chỉ được xếp chờ. Reset của 1.2.2 xóa cờ chờ nhưng chưa đưa giá trị mới nhất vào đầu đọc. Host gửi lại cùng giá trị cũng không phát hiện thay đổi nữa. Bản này áp dụng giá trị đang chờ trước khi xóa tank; reset đồng thời đưa hệ số Damping/Bass đang làm mượt về đúng đích hiện tại.

Ví dụ ở 48 kHz: chỉnh Pre-delay 0 → 50 → 150 ms rồi reset ngay giữa chuyển tiếp. Wet đầu tiên của 1.2.2 xuất hiện ở 50,625 ms; 1.2.3 và engine mới cùng cài đặt đều ở 150,625 ms, đầu ra khớp từng mẫu. Đây là thời điểm phản xạ đầu tiên trong bài thử, không phải độ trễ mic–tai nghe hay latency báo DAW.

**LIQUID Delay:** processor chưa override `AudioProcessor::reset()`. Lệnh reset trực tiếp của host vì thế không xóa buffer; chỉ release/prepare mới xóa. Bản này dùng chung reset cho delay, bộ lọc Classic/HD, drive, limiter, LFO, chuyển tiếp HD và các meter âm lượng. Trong bài thử 48 kHz, đỉnh đuôi cũ sau reset giảm từ 0,175 xuống đúng 0. Reset trực tiếp và release/prepare đều được thử riêng.

JUCE VST3 gọi `reset()` khi host gửi `setProcessing(false)`. Chưa xác nhận Cubase 15 gọi đường này vào mọi tình huống stop/thay plugin; không coi bài thử nguồn là lần chạy Cubase thực tế.

## Kết quả đợt này

- 25 chương trình kiểm tra nguồn đạt, không skip: 17 test dự án và 8 test vòng đời/tín hiệu.
- 24 ca PANTHEON ở 8/32/44,1/48/96/192 kHz: reset giữa chuyển đầu đọc, nhiều lần chỉnh dồn, đổi màu lọc, reset lặp. Đầu ra sau reset đều khớp engine mới cùng cài đặt.
- 12 ca LIQUID ở 32/44,1/48/96 kHz: block 7/128, Classic/HD, filter, LFO và chuyển HD đang dở. Không còn đuôi cũ; tín hiệu mới sau reset khớp processor mới cùng cài đặt.
- Chính các bài thử reset mới chạy trên 1.2.2 đã báo lỗi, rồi đạt trên 1.2.3. Log trước/sau nằm trong `Validation/`.
- Test nguồn cũ về RT60, sáu màu vang, Damping/Bass, HD filter, preset/state/editor và 68 kiểm tra license tiếp tục đạt. Kết quả sanitizer của đợt này ghi trong `Validation/RESULTS_SUMMARY.json`.

Nguồn licensing, public key, ID/thứ tự tham số và tên/index preset được giữ như 1.2.2. Dữ liệu đo rộng hơn của 1.2.2 nằm riêng ở `Validation/previous_1_2_2/`; đó là kết quả lịch sử, không tính là phép đo mới của đợt này. Các thay đổi tiếng vang/HD từ 1.2.2 vẫn có trong gói.

## Phần còn nên cải thiện

Level của PANTHEON vẫn nhận bước gain tức thời. Bài thử nhảy 0 → −36 dB ở đỉnh sine 250 Hz, biên độ 0,1, cho bước mẫu khoảng 0,09836. Mix/Input/Echo cũng đang nhận giá trị trực tiếp theo mã nguồn. Nên thêm ramp cho các nút này nếu cần kéo/automation thật êm; đây là phần chưa sửa trong 1.2.3. Bài thử bước gain không chứng minh có click ở mọi preset giữ nguyên.

FX SEND vẫn giữ wet-only khi DSP đang được phép chạy. Hết trial/chưa được phép xử lý trả dry theo chính sách hiện tại; bypass của host cũng có thể trả dry. Trên AUX, mute return là cách tắt hiệu ứng mà không cộng thêm vocal khô. License worker còn timeout dừng 30 giây nếu I/O bị kẹt; chưa tái hiện tình huống đó và chưa kết luận nó là nguyên nhân đơ Cubase trên máy anh.

## Build và dùng

1. Giải nén vào thư mục mới, ví dụ `D:\VST\T-Studio_FX`.
2. Copy đúng **public key của hệ cấp key đang dùng** vào `config/public_key.txt`. File đầu vào hiện đang trống; bản này giữ nguyên. Không có private key/công cụ cấp key trong ZIP.
3. Windows: chạy `1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat` (Visual Studio C++ Desktop Development, CMake 3.22+, Inno Setup). Chỉ build: `2_CHI_BUILD_WINDOWS.bat`.
4. macOS: chạy `1_BUILD_VA_TAO_BO_CAI_MAC.command`, cần Xcode Command Line Tools và CMake.
5. Đóng Cubase trước khi thay plugin đã biên dịch. Với PANTHEON trên AUX, bật **FX SEND 100% WET**, chỉnh lượng vang ở Send/Return. Dùng insert thì tắt FX SEND rồi chỉnh Mix. State cũ thiếu cờ routing vẫn mở ở Insert.

Kiểm tra đợt này dùng harness nguồn JUCE 8.0.12 trên Linux với store trial QA riêng. Chưa chạy DLL trong Cubase 15 Windows, ASIO hay bộ cài Windows/macOS; chưa có bài nghe vocal thực tế cho bản này. Không khẳng định đã hết mọi tình huống đơ DAW hoặc tương đương thuật toán hãng.
