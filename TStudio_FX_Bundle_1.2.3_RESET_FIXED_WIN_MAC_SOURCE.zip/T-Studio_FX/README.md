# T Studio FX Bundle 1.2.3

Mã nguồn đầy đủ cho **T-Verb, T-RVerb, T-PANTHEON và T-LIQUID DELAY**, kèm JUCE và script build/tạo bộ cài Windows/macOS.

Đọc [DOC_TRUOC_1_2_3.md](DOC_TRUOC_1_2_3.md) trước khi build. ZIP chưa chứa plugin/bộ cài Windows/macOS đã biên dịch native. Copy đúng public key đang dùng vào `config/public_key.txt`; file đầu vào trống được giữ nguyên.

Bản này sửa PANTHEON mất giá trị đầu đọc đang chờ khi reset và LIQUID chưa xóa đuôi khi host gọi reset. Giữ các sửa chức năng của 1.2.2. **25 chương trình kiểm tra nguồn đạt**, gồm bài thử reset mới trên nhiều sample rate; chi tiết, số liệu và giới hạn trong [Validation](Validation/).

- Windows: `1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat`; chỉ build: `2_CHI_BUILD_WINDOWS.bat`.
- macOS: `1_BUILD_VA_TAO_BO_CAI_MAC.command`.
- PANTHEON trên AUX: bật **FX SEND 100% WET**, chỉnh lượng vang bằng Send/Return. Insert: tắt FX SEND rồi chỉnh Mix.
- Level/Mix chưa có ramp bổ sung; license shutdown khi I/O bị kẹt và chạy Cubase 15 Windows vẫn cần kiểm chứng riêng.

ID/thứ tự tham số và license giữ nguyên. Chưa chạy native Windows/macOS/ASIO hoặc nghe vocal thật trong đợt này. Tài liệu 1.2.2 và `Validation/previous_1_2_2/` là lịch sử phiên bản trước.
