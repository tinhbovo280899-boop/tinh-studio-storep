# Reset verification, 1.2.3

The new portable PANTHEON ResetRegressionTests and expanded LIQUID ProcessorRegressionTests are included under plugins/. Both reproduce failures against immutable 1.2.2 source/libraries. The same suites then pass with 1.2.3. Before*.log intentionally contain failures; they are the baseline controls.

New production plugin source/header bytes match the files compiled in the QA project. The Linux adapter imports an existing JUCE 8.0.12 runtime, instead of compiling native VST3/AU wrappers. Only the QA copy redirects license StorePaths to TSTUDIO_AUDIT_ROOT. Production licensing and public config remain byte-identical to 1.2.2 and keep normal paths.

Each test runs with a unique task-owned license/application-data store. No real trial state or owner private key is used. The runner ignores CTest's existing HOME-changing fixture/environment and keeps HOME unchanged.

The 48 kHz probes in qa/ print the first wet sample after queued Pre-delay edits/reset, output gain step, and residual delay tail after reset versus fresh/release-prepare controls. First-wet timing includes the early reflection; it is not device latency. Their complete outputs are in before/after-probe-results.json.

ASan/UBSan: the complete PANTHEON header DSP is instrumented, plus the LIQUID changed production processor and its regression harness. Existing JUCE/GUI/license objects are not instrumented; ASAN_OPTIONS detect_leaks=0:halt_on_error=1 and UBSAN_OPTIONS halt_on_error=1:print_stacktrace=1. This is not a whole-DAW sanitizer run.

The source-only lifecycle/signal harnesses cover four plugins at 48/96 kHz, including editor disposal under the UI lock. They do not emulate Windows message loops, native DLL unload, ASIO or every Cubase operation. A blocked license I/O path was not induced. No inference that every DAW freeze is fixed follows from these checks.
