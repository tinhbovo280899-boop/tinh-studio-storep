#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include "TDelayProcessor.h"
#include <cstdio>
static void set(TDelayAudioProcessor&p,const char*id,float v){auto*q=p.getAPVTS().getParameter(id);q->setValueNotifyingHost(q->convertTo0to1(v));}
static void configure(TDelayAudioProcessor&p){for(auto id:{"filterOn","lfoOn","peakLimit","dlySync","inLoop"})set(p,id,0);set(p,"overdrive",0);set(p,"mix",100);set(p,"dlyFeedback",50);set(p,"dlyTempo",120);set(p,"dlyLOn",1);set(p,"dlyROn",1);p.setPlayConfigDetails(2,2,48000,128);p.prepareToPlay(48000,128);}
static double silence(TDelayAudioProcessor&p,int blocks){double peak=0;juce::AudioBuffer<float>b(2,128);juce::MidiBuffer midi;for(int k=0;k<blocks;++k){b.clear();p.processBlock(b,midi);peak=std::max(peak,double(b.getMagnitude(0,128)));}return peak;}
int main(){
    juce::ScopedJuceInitialiser_GUI init;tak::license::PluginLicense proof;proof.ensureAutomaticTrial();
    for(int i=0;i<150&&!proof.isAllowed();++i)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
    if(!proof.isAllowed())return 2;
    TDelayAudioProcessor p;configure(p);juce::AudioBuffer<float>b(2,128);juce::MidiBuffer midi;
    for(int k=0;k<250;++k){for(int i=0;i<128;++i){float x=.1f*std::sin((k*128+i)*.0287979327f);b.setSample(0,i,x);b.setSample(1,i,x);}p.processBlock(b,midi);}
    p.reset();const double after=silence(p,400);
    TDelayAudioProcessor fresh;configure(fresh);const double reference=silence(fresh,400);
    p.releaseResources();p.prepareToPlay(48000,128);const double reprepare=silence(p,400);
    std::printf("DELAY_RESET after_reset_peak=%.9g fresh_peak=%.9g after_release_prepare_peak=%.9g license_allowed=%d\n",after,reference,reprepare,int(proof.isAllowed()));
    return 0;
}
