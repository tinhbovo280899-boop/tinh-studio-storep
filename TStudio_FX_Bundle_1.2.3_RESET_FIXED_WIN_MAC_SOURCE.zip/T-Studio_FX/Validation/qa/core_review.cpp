#include "dsp/PhoenixChamber.h"
#include <cstdio>
#include <vector>
#include <cmath>
static void config(tpantheon::PhoenixChamber&c,float pre,float mix=100,float level=0)
{c.setParameters(0,38,2.03f,83,2080,1.2f,381,65,0,14,pre,mix,level,-60,0,-60,0,1);}
static void zeros(tpantheon::PhoenixChamber&c,int n){for(int i=0;i<n;++i){float l,r;c.processStereoSample(0,0,l,r);}}
static std::vector<float> impulse(tpantheon::PhoenixChamber&c){std::vector<float>a(24000);for(int i=0;i<24000;++i){float l,r;c.processStereoSample(i==0?.1f:0,i==0?.1f:0,l,r);a[size_t(i)]=l;}return a;}
static double onset(const std::vector<float>&a){for(size_t i=0;i<a.size();++i)if(std::abs(a[i])>1.e-8)return i/48.;return -1;}
int main(){
    tpantheon::PhoenixChamber changed,fresh;
    changed.prepare(48000);config(changed,0);zeros(changed,2000);
    config(changed,50);zeros(changed,10);config(changed,150);
    changed.reset();config(changed,150);auto a=impulse(changed);
    fresh.prepare(48000);config(fresh,150);fresh.reset();auto b=impulse(fresh);
    double delta=0;for(size_t i=0;i<a.size();++i)delta=std::max(delta,std::abs(double(a[i])-b[i]));
    std::printf("RESET_PENDING requested_pre_ms=150 observed_after_reset_ms=%.9f fresh_reference_ms=%.9f max_difference=%.9g\n",onset(a),onset(b),delta);
    tpantheon::PhoenixChamber gain;gain.prepare(48000);config(gain,12,0,0);float last=0,out=0,right=0;
    for(int i=0;i<4848;++i){gain.processStereoSample(float(.1*std::sin(2*juce::MathConstants<double>::pi*250*i/48000)),0,out,right);last=out;}
    config(gain,12,0,-36);const float x=float(.1*std::sin(2*juce::MathConstants<double>::pi*250*4848/48000));gain.processStereoSample(x,0,out,right);
    std::printf("LEVEL_STEP previous=%.9g next=%.9g sample_step=%.9g natural_input_step=%.9g\n",last,out,std::abs(out-last),std::abs(x-last));
    return 0;
}
