#ifndef BundleVersion
  #define BundleVersion "1.2.3"
#endif
#ifndef StageDir
  #define StageDir AddBackslash(SourcePath) + "..\dist\windows"
#endif

; Doi thuong hieu: tools\windows.ps1 truyen cac gia tri nay tu ThuongHieu.json (mac dinh = T Studio).
#ifndef BrandPrefix
  #define BrandPrefix "T-"
#endif
#ifndef Publisher
  #define Publisher "T Studio"
#endif
#ifndef FilePrefix
  #define FilePrefix "TStudio"
#endif
#ifndef AppIdValue
  #define AppIdValue "{{5C1E7A42-8B3D-4F0E-9A61-2D7B4E9C1F38}"
#endif

[Setup]
AppId={#AppIdValue}
AppName={#Publisher} FX Bundle
AppVersion={#BundleVersion}
AppPublisher={#Publisher}
DefaultDirName={autopf}\{#Publisher}\FX Bundle
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\Installers
OutputBaseFilename={#FilePrefix}_FX_{#BundleVersion}_Windows_x64_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UninstallDisplayName={#Publisher} FX Bundle ({#BrandPrefix}Verb + {#BrandPrefix}RVerb + {#BrandPrefix}PANTHEON + {#BrandPrefix}LIQUID DELAY)

[Files]
Source: "{#StageDir}\VST3\{#BrandPrefix}Verb.vst3\*"; DestDir: "{commoncf64}\VST3\{#BrandPrefix}Verb.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\{#BrandPrefix}RVerb.vst3\*"; DestDir: "{commoncf64}\VST3\{#BrandPrefix}RVerb.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\{#BrandPrefix}PANTHEON.vst3\*"; DestDir: "{commoncf64}\VST3\{#BrandPrefix}PANTHEON.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\{#BrandPrefix}LIQUID DELAY.vst3\*"; DestDir: "{commoncf64}\VST3\{#BrandPrefix}LIQUID DELAY.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\HUONG_DAN.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs

[Messages]
WelcomeLabel2=Bo cai chep 4 plugin VST3: {#BrandPrefix}Verb, {#BrandPrefix}RVerb, {#BrandPrefix}PANTHEON va {#BrandPrefix}LIQUID DELAY. Hay dong DAW truoc khi cai.
FinishedLabel=Da cai 4 plugin FX. Dung thu 7 ngay chung voi cac plugin {#Publisher} khac. Neu may da kich hoat {#BrandPrefix}AutoTune/{#BrandPrefix}AutoKey/{#BrandPrefix}1176/{#BrandPrefix}LA2a thi 4 plugin nay tu mo khoa. Banh rang > Ban quyen & Kich hoat de nhap key.
