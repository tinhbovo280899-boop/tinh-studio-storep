#include "WavesS1DSP.h"
#include "WavesVocalBenderDSP.h"
#include <cstdio>
#include <limits>
#include <vector>
#include <random>
using namespace WavesDSP;
static int checks=0,failures=0;
#define CHECK(x) do{++checks;if(!(x)){if(failures<20)std::printf("FAIL %d %s\n",__LINE__,#x);++failures;}}while(false)
static constexpr double pi=3.14159265358979323846;
static float energy(const std::vector<float>& x,int begin=0){double e=0;for(size_t i=size_t(begin);i<x.size();++i)e+=x[i]*x[i];return float(std::sqrt(e/(x.size()-begin)));}
static float amplitude(const std::vector<float>& x,double hz,double sr,int start){double a=0,b=0;for(int i=start;i<int(x.size());++i){double phase=2*pi*hz*i/sr;double win=.5-.5*std::cos(2*pi*(i-start)/(x.size()-start-1));a+=x[size_t(i)]*win*std::cos(phase);b+=x[size_t(i)]*win*std::sin(phase);}return float(4*std::hypot(a,b)/(x.size()-start));}
int main(){
 for(double sr:{8000.,44100.,48000.,96000.,192000.,384000.}){
  WavesS1StereoImager s;s.prepare(sr);S1Parameters p;p.shuffle=1;p.component=S1ComponentMode::Imager;s.setParameters(p);s.reset();
  constexpr int n=4096;std::vector<float>l(n),r(n),ol(n),orr(n);for(int i=0;i<n;++i){l[size_t(i)]=float(.2*std::sin(i*.07));r[size_t(i)]=float(.11*std::cos(i*.11));}
  s.processBlock(l.data(),r.data(),ol.data(),orr.data(),n);for(int i=0;i<n;++i){CHECK(std::abs(ol[size_t(i)]-l[size_t(i)])<2e-7f);CHECK(std::abs(orr[size_t(i)]-r[size_t(i)])<2e-7f);}
  p.width=0;s.setParameters(p);s.reset();s.processBlock(l.data(),r.data(),ol.data(),orr.data(),n);for(int i=0;i<n;++i)CHECK(std::abs(ol[size_t(i)]-.5f*(l[size_t(i)]+r[size_t(i)]))<2e-7f&&std::abs(ol[size_t(i)]-orr[size_t(i)])<2e-7f);
  p.width=1;p.invertLeft=true;p.swapLR=true;s.setParameters(p);s.reset();s.processBlock(l.data(),r.data(),ol.data(),orr.data(),n);for(int i=0;i<n;++i){CHECK(std::abs(ol[size_t(i)]-r[size_t(i)])<2e-7f);CHECK(std::abs(orr[size_t(i)]+l[size_t(i)])<2e-7f);}
  p={};p.shuffle=1;p.component=S1ComponentMode::Imager;p.outputMS=true;s.setParameters(p);s.reset();s.processBlock(l.data(),r.data(),ol.data(),orr.data(),n);
  p.outputMS=false;p.inputMode=S1InputMode::MidSideToStereo;s.setParameters(p);s.reset();s.processBlock(ol.data(),orr.data(),ol.data(),orr.data(),n);for(int i=0;i<n;++i){CHECK(std::abs(ol[size_t(i)]-l[size_t(i)])<2e-7f);CHECK(std::abs(orr[size_t(i)]-r[size_t(i)])<2e-7f);}
  for(double shuffle:{1.,1.001,1.4,3.})for(double trim:{-3.,0.,3.}){
   p={};p.component=S1ComponentMode::Shuffler;p.shuffle=shuffle;p.bassTrimDb=trim;s.setParameters(p);auto* c=s.getTargetCoefs();const double gm=std::sqrt(.5*(1/(shuffle*shuffle)+1))*std::pow(10.,trim/20);
   for(int band=0;band<2;++band){const int k=4+3*band;CHECK(std::abs(2*(c[k]+c[k+1])/(1+c[k+2])-gm*(band?shuffle:1))<1e-7);CHECK(std::abs(2*(c[k]-c[k+1])/(1-c[k+2])-1)<1e-7);CHECK(std::abs(c[k+2])<1);}
  }
 }
 for(float st:{-24.f,-12.f,-5.f,0.f,5.f,12.f,24.f})CHECK(std::abs(WavesVocalBenderDSP::wavesPadePow2(st/12)-std::exp2(st/12))<2e-6f);
 for(double sr:{8000.,44100.,48000.,96000.,192000.}){
  int n=int(sr*.65);std::vector<float>x(size_t(n),0),y(size_t(n),0),z(size_t(n),0),r(size_t(n),0),o(size_t(n),0);
  for(int i=0;i<n;++i){double ph=2*pi*220*i/sr;x[size_t(i)]=float(.2*std::sin(ph)+.1*std::sin(2*ph+.3)+.05*std::sin(3*ph+.7));r[size_t(i)]=-x[size_t(i)];}
  WavesVocalBenderDSP a,b;a.prepare(sr);b.prepare(sr);a.processBlockMono(x.data(),y.data(),n);CHECK(x==y);CHECK(std::abs(a.getDetectedFreqHz()-220)<2);
  VocalBenderParameters p;p.pitchSemitones=5;a.setParameters(p);b.setParameters(p);a.reset();b.reset();a.processBlockMono(x.data(),y.data(),n);for(int off=0;off<n;off+=37)b.processBlockMono(x.data()+off,z.data()+off,std::min(37,n-off));CHECK(y==z);
  const double target=220*std::exp2(5./12);const int start=int(sr*.25);CHECK(amplitude(y,target,sr,start)>.045f);CHECK(amplitude(y,target,sr,start)>2*amplitude(y,220,sr,start));
  // Linked grains retain channel polarity; the detector must not cancel anti-phase input.
  a.reset();a.processBlockStereo(x.data(),r.data(),y.data(),o.data(),n);CHECK(a.isVoiced());CHECK(std::abs(a.getDetectedFreqHz()-220)<2);for(int i=0;i<n;++i)CHECK(std::abs(y[size_t(i)]+o[size_t(i)])<1e-6f);
  std::fill(z.begin(),z.end(),0);a.reset();a.processBlockStereo(z.data(),x.data(),y.data(),o.data(),n);CHECK(a.isVoiced());CHECK(energy(y)<1e-9f);CHECK(energy(o)>.01f);
  // Down-octave must contain the 110 Hz subharmonic; variable window normalization erased it.
  p.pitchSemitones=-12;a.setParameters(p);a.reset();a.processBlockMono(x.data(),y.data(),n);CHECK(amplitude(y,110,sr,start)>.01f);
  p={};p.formantSemitones=-4;a.setParameters(p);a.reset();a.processBlockMono(x.data(),y.data(),n);CHECK(energy(y)>.01f);CHECK(amplitude(y,220,sr,start)>.01f);
  // Mix 0 and neutral are exactly dry, without delay or envelope gain riding.
  p.mix=0;a.setParameters(p);a.reset();a.processBlockMono(x.data(),y.data(),n);CHECK(x==y);
  p.mix=1;p.pitchSemitones=5;a.setParameters(p);a.reset();x[3]=std::numeric_limits<float>::quiet_NaN();x[5]=std::numeric_limits<float>::infinity();a.processBlockMono(x.data(),y.data(),n);for(auto v:y)CHECK(std::isfinite(v));
  a.reset();b.setParameters(p);b.reset();std::fill(x.begin(),x.end(),0);a.processBlockMono(x.data(),y.data(),n);CHECK(energy(y)==0);CHECK(!a.isVoiced());
 }
 // Hostile saved values are bounded before any indexing or coefficient generation.
 {WavesVocalBenderDSP v;v.prepare(std::numeric_limits<double>::infinity());VocalBenderParameters p;p.lfoRateHz=std::numeric_limits<float>::quiet_NaN();p.pitchSemitones=std::numeric_limits<float>::infinity();v.setParameters(p);float x[256]={},y[256]={};v.processBlockMono(x,y,256);for(float f:y)CHECK(std::isfinite(f));}
 {WavesS1StereoImager s;S1Parameters p;p.width=std::numeric_limits<double>::quiet_NaN();p.gainDb=std::numeric_limits<double>::infinity();s.setParameters(p);float x[256]={},y[256]={};x[3]=std::numeric_limits<float>::quiet_NaN();s.processBlock(x,x,y,y,256);for(float f:y)CHECK(std::isfinite(f));}
 std::printf("CORE: %d checks, %d failures\n",checks,failures);return failures?1:0;
}
