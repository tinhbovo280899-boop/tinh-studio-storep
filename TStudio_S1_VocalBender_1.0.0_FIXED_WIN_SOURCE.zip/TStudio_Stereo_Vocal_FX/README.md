# T Studio — Stereo & Vocal FX 1.0.0

Gói mã nguồn sửa hai DSP trong `Waves_S1_And_VocalBender_100_Exact_DSP_GUI.zip`.

| Mã nguồn gửi vào | Tên VST3 sau khi build | Bus hỗ trợ |
| --- | --- | --- |
| S1 Stereo Imager/Shuffler/M/S | T-StereoSpace | Stereo → Stereo |
| Vocal Bender pitch/formant | T-VocalBend | Mono → Mono; Stereo → Stereo |

**Đây là mã nguồn kèm BAT xuất VST3 Windows x64, chưa phải bộ cài hay binary Windows dựng sẵn.** Đã build và nạp VST3 trên Linux. Chưa chạy MSVC/Cubase 15 Windows hoặc macOS. Đây là bản sửa C++ được gửi vào, không xác nhận thuật toán/âm thanh/giao diện giống 100% Waves.

## Build trên Windows

1. Giải nén toàn bộ ZIP vào thư mục mới. Giữ nguyên `third_party`, `Source`, `plugins` và `tools`.
2. Có Visual Studio 2022/2019/2026 với **Desktop development with C++**, MSVC x64 và Windows SDK; CMake từ 3.22 trở lên. Script cũng tìm CMake có sẵn trong Visual Studio. JUCE 8.0.12 đã kèm mã nguồn, không cần tải dependency khi build.
3. Bấm **`1_BUILD_AND_EXPORT_WINDOWS.bat`**. Chờ dòng `BUILD AND EXPORT COMPLETE`.
4. Script mở `_EXPORT/Build-.../VST3`, chứa **hai thư mục `.vst3` hoàn chỉnh**. Đường dẫn gần nhất nằm trong `_EXPORT/LATEST_EXPORT.txt`.
5. Đóng Cubase rồi chép cả hai thư mục vào `C:Program FilesCommon FilesVST3`. Mở Cubase, quét lại plugin. Không lấy riêng binary bên trong thư mục `.vst3`.

Khi lỗi, xem `_BUILD_LOGS/<lần build>/configure.log` và `build.log`. Script báo lỗi nếu thiếu một sản phẩm, CMake thất bại hoặc binary không phải PE32+ x64; không ghi đè bản xuất thành công trước đó.

## T-StereoSpace

Preset `Neutral`: Width 1, Bass Spread 1, Gain 0 dB, không đổi pha/kênh — giữ nguyên stereo.

- **Width**: 0 thu về mono, 1 nguyên bản, >1 tăng phần Side. Không tạo stereo từ một nguồn mono hoàn toàn giống nhau ở L/R.
- **Processor**: Imager dùng Width/Rotation/Asymmetry; Bass Shuffler thêm Bass Spread/Frequency/Trim; M/S Matrix thực hiện biến đổi `(L+R)/√2`, `(L−R)/√2`.
- **Input Encoded M/S** chỉ dùng khi đầu vào thực sự là Mid/Side. **Encode Output M/S** dùng cho bước xử lý M/S tiếp theo. Ở M/S Matrix, hai lựa chọn này không dùng vì ma trận đã thực hiện phép đổi cơ sở.
- Invert Output L/R và Swap Outputs áp dụng lên kênh đầu ra, sau phần xử lý âm thanh. Có làm mượt để giảm tiếng tách khi chuyển.
- Các nút Width/Shuffle/Rotation không có tác dụng trong M/S Matrix; các nút Bass Spread/Frequency/Trim chỉ có tác dụng trong Bass Shuffler.
- 8 preset T Studio mới, có `Vocal FX Spread`. Đây không phải bộ preset hãng chuyển đổi.

## T-VocalBend

Đây là hiệu ứng **dịch cao độ/formant sáng tạo**, không phải Auto-Tune tự chỉnh Key/Scale.

- Pitch ±12 semitone, Fine ±100 cents. +12 tương ứng ×2, −12 tương ứng ×0.5.
- Formant đổi màu giọng; Link lấy giá trị Pitch làm dịch Formant, thay cho núm Formant độc lập.
- Flatten ép cao độ vào một nốt MIDI 36–84 khi nhận được giọng có cao độ; 60 = MIDI C4 theo chuẩn MIDI (tên octave có thể khác trong DAW).
- LFO Rate/Depth và Envelope Depth có thể điều chế Pitch/Formant.
- Neutral giữ nguyên tín hiệu. Mix 0% là dry nguyên bản. Dùng FX Send/AUX thì chọn **Mix 100%**.
- Stereo dùng chung hạt dịch âm cho hai kênh, tránh phá tương quan L/R; bộ dò không cộng L+R để tránh mất cao độ khi hai kênh ngược pha.
- 9 preset T Studio mới. LFO được reset cùng bộ xử lý, không đồng bộ tempo DAW trong bản này.

**Độ trễ:** không đặt hàng đợi lookahead cố định cho host (host báo 0 sample). Điều đó không có nghĩa tín hiệu đang dịch Pitch/Formant có độ trễ âm học bằng 0: hạt PSOLA đọc âm thanh đã qua, tuổi hạt thay đổi theo chu kỳ giọng/thiết lập. Neutral/Mix 0 là dry tức thời. Mix ở giữa khi đang dịch âm tạo hiệu ứng trộn hai giọng, không phải phép trộn wet/dry đã bù một độ trễ cố định.

## Thay đổi và kiểm tra

Xem `Validation/REVIEW.md`, kết quả JSON, log và ảnh giao diện trong `Validation`. Không có activation/license checker của plugin trong wrapper này. Các thông báo giấy phép của JUCE và SDK vẫn đi kèm trong `third_party`.

`Reference/ORIGINAL_UPLOAD.zip` giữ nguyên file anh gửi, gồm ảnh/XML/disassembly và mã cũ. Phần này chỉ để đối chiếu, không được BAT/CMake sử dụng. UI mới là giao diện native T Studio với toàn bộ tham số DSP thực sự có trong C++ được nối trực tiếp vào host. Những menu/tính năng khác chỉ có trong XML/ảnh gốc nhưng thiếu DSP không được dựng thành nút giả.

S1 và Vocal Bender mới có ID riêng. Không tự thay thế hoặc đọc state của plugin hãng hay các bản T Studio cũ.
