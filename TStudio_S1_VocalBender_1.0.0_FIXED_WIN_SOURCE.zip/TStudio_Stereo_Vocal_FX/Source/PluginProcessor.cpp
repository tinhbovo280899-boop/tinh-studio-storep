#include "PluginProcessor.h"
#include <limits>
namespace studio {
juce::String parameterText(const ParameterSpec& s,float v){
 v=juce::jlimit(0.f,1.f,v);
 if(s.kind==Kind::Choice){const auto names=juce::StringArray::fromTokens(s.choices,"|","");return names[juce::jlimit(0,names.size()-1,juce::roundToInt(v*float(names.size()-1)))];}
 if(s.kind==Kind::Switch)return v>=.5f?"On":"Off";
 if(s.kind==Kind::Legacy)return "Stored only";
 float real=realValue(s,v);if(std::abs(real)<s.step*.1f)real=0;if(juce::String(s.unit)=="%")return juce::String(real*100,1)+" %";
 return juce::String(real,s.step>=1?0:s.step>=.1f?1:2)+" "+s.unit;
}

juce::AudioProcessorValueTreeState::ParameterLayout PluginProcessor::makeLayout(){
 juce::AudioProcessorValueTreeState::ParameterLayout layout;
 for(const auto& s:parameterSpecs){
  if(s.kind==Kind::Switch){layout.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{s.id,1},s.label,s.defaultValue>=.5f));continue;}
  float step=s.step/(s.maximum-s.minimum);
  layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{s.id,1},s.label,juce::NormalisableRange<float>(0,1,step),s.defaultValue,
   juce::AudioParameterFloatAttributes().withStringFromValueFunction([s](float v,int){return parameterText(s,v);})
    .withValueFromStringFunction([s](const juce::String& text){
     if(s.kind==Kind::Choice){auto names=juce::StringArray::fromTokens(s.choices,"|","");int i=names.indexOf(text);if(i>=0)return float(i)/float(names.size()-1);}
     float real=text.getFloatValue();if(juce::String(s.unit)=="%")real*=.01f;
     return juce::jlimit(0.f,1.f,(real-s.minimum)/(s.maximum-s.minimum));
    })));
 }
 return layout;
}
PluginProcessor::PluginProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),state(*this,nullptr,"TStudioStereoVocalFX",makeLayout()){
 for(size_t i=0;i<values.size();++i)values[i]=state.getRawParameterValue(parameterSpecs[i].id);
}
bool PluginProcessor::isBusesLayoutSupported(const BusesLayout& b) const {
 #if TSTUDIO_PRODUCT==0
 return b.getMainInputChannelSet()==juce::AudioChannelSet::stereo()&&b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo();
 #else
 return b.getMainInputChannelSet()==b.getMainOutputChannelSet()&&(b.getMainOutputChannelSet()==juce::AudioChannelSet::mono()||b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo());
 #endif
}
float PluginProcessor::parameter(int i) const noexcept {const auto x=values[size_t(i)]->load(std::memory_order_relaxed);return std::isfinite(x)?juce::jlimit(0.f,1.f,x):parameterSpecs[size_t(i)].defaultValue;}
float PluginProcessor::parameter(const juce::String& id) const noexcept {for(int i=0;i<parameterCount;++i)if(id==parameterSpecs[size_t(i)].id)return parameter(i);return 0;}
bool PluginProcessor::powered() const noexcept {return parameter(dspParameterCount-1)>=.5f;}
double PluginProcessor::getTailLengthSeconds() const {return .1;}
void PluginProcessor::prepareToPlay(double sampleRate,int block){
 const double sr=std::isfinite(sampleRate)&&sampleRate>=8000&&sampleRate<=384000?sampleRate:48000.;
 dry.setSize(2,std::max(512,block),false,true,true);engine.prepare(sr);for(auto& s:controls)s.reset(sr,.020);bypassRamp.reset(sr,.020);setLatencySamples(0);reset();
}
void PluginProcessor::setEngineParameters(){
 std::array<float,dspParameterCount> v{};for(size_t i=0;i<v.size();++i)v[i]=controls[i].getCurrentValue();
 v.back()=1;
 setCore(engine,v);
}
void PluginProcessor::reset(){
 for(int i=0;i<dspParameterCount;++i)controls[size_t(i)].setCurrentAndTargetValue(parameter(i));
 setEngineParameters();engine.reset();controlRemaining=0;bypassRamp.setCurrentAndTargetValue(hostBypass||parameter(parameterCount-1)>=.5f||!powered()?1.f:0.f);
 inputDb=-100;outputDb=-100;detectedHz=0;gainReductionDb=0;vuDb=-100;needleFrame=0;inputFrameL=0;inputFrameR=0;

}
void PluginProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&){
 juce::ScopedNoDenormals noDenormals;const int channels=std::min(2,buffer.getNumChannels()),frames=buffer.getNumSamples();if(channels<1||frames<=0)return;if(dry.getNumSamples()==0){buffer.clear();return;}
 for(int c=getTotalNumInputChannels();c<buffer.getNumChannels();++c)buffer.clear(c,0,frames);
 for(int i=0;i<dspParameterCount;++i){const auto v=parameter(i);auto& s=controls[size_t(i)];const auto k=parameterSpecs[size_t(i)].kind;
  constexpr bool immediate=false;
  if(immediate||k==Kind::Switch||k==Kind::Choice||k==Kind::Legacy)s.setCurrentAndTargetValue(v);else s.setTargetValue(v);
 }
 bypassRamp.setTargetValue(hostBypass||parameter(parameterCount-1)>=.5f||!powered()?1.f:0.f);float inputPeak=0,outputPeak=0;
 for(int start=0;start<frames;){
  if(controlRemaining==0){setEngineParameters();controlRemaining=32;}const int n=std::min({frames-start,controlRemaining,dry.getNumSamples()});
  for(int c=0;c<channels;++c){auto* src=buffer.getWritePointer(c,start);auto* dst=dry.getWritePointer(c);for(int i=0;i<n;++i){float x=std::isfinite(src[i])?juce::jlimit(-64.f,64.f,src[i]):0;src[i]=dst[i]=x;inputPeak=std::max(inputPeak,std::abs(x));}}
  #if TSTUDIO_PRODUCT==0
  // Stereo-only host bus; a direct mono test uses duplicate input and folds output.
  if(channels==1){dry.copyFrom(1,0,dry,0,0,n);engine.processBlock(buffer.getReadPointer(0,start),dry.getReadPointer(1),buffer.getWritePointer(0,start),dry.getWritePointer(1),n);}
  else engine.processBlock(buffer.getReadPointer(0,start),buffer.getReadPointer(1,start),buffer.getWritePointer(0,start),buffer.getWritePointer(1,start),n);
  #else
  if(channels==1)engine.processBlockMono(buffer.getReadPointer(0,start),buffer.getWritePointer(0,start),n);
  else engine.processBlockStereo(buffer.getReadPointer(0,start),buffer.getReadPointer(1,start),buffer.getWritePointer(0,start),buffer.getWritePointer(1,start),n);
  #endif
  for(int i=0;i<n;++i){const auto b=bypassRamp.getNextValue();for(int c=0;c<channels;++c){auto* dst=buffer.getWritePointer(c,start);dst[i]+=(dry.getSample(c,i)-dst[i])*b;outputPeak=std::max(outputPeak,std::abs(dst[i]));}}
  for(auto& s:controls){s.skip(n);}
  start+=n;controlRemaining-=n;
 }
 inputDb.store(juce::Decibels::gainToDecibels(inputPeak,-100.f),std::memory_order_relaxed);outputDb.store(juce::Decibels::gainToDecibels(outputPeak,-100.f),std::memory_order_relaxed);
 #if TSTUDIO_PRODUCT==1
 detectedHz=engine.isVoiced()?engine.getDetectedFreqHz():0;
 #endif
}
void PluginProcessor::processBlockBypassed(juce::AudioBuffer<float>& b,juce::MidiBuffer& m){hostBypass=true;processBlock(b,m);hostBypass=false;}
void PluginProcessor::setCurrentProgram(int i){if(i<0||i>=presetCount)return;const auto v=presetValues(i);for(int j=0;j<dspParameterCount;++j)if(auto* param=state.getParameter(parameterSpecs[size_t(j)].id))param->setValueNotifyingHost(v[size_t(j)]);currentProgram=i;}
const juce::String PluginProcessor::getProgramName(int i){return i>=0&&i<presetCount?juce::String::fromUTF8(presetName(i)):juce::String{};}
void PluginProcessor::getStateInformation(juce::MemoryBlock& destination){auto tree=state.copyState();tree.setProperty("product",productName,nullptr);tree.setProperty("factoryPreset",currentProgram.load(),nullptr);auto xml=tree.createXml();copyXmlToBinary(*xml,destination);}
void PluginProcessor::setStateInformation(const void* data,int size){if(auto xml=getXmlFromBinary(data,size)){if(!xml->hasTagName(state.state.getType().toString()))return;auto tree=juce::ValueTree::fromXml(*xml);if(tree.getProperty("product").toString()!=productName)return;int index=int(tree.getProperty("factoryPreset",defaultPreset));state.replaceState(tree);currentProgram=juce::jlimit(0,presetCount-1,index);}}
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new studio::PluginProcessor;}
