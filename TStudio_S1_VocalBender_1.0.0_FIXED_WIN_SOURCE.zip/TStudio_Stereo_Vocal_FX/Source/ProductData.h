#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <array>
namespace studio {
enum class Kind {Float,Switch,Choice,Legacy};
struct ParameterSpec {const char* id;const char* label;Kind kind;float defaultValue,minimum,maximum,step;const char* unit;const char* choices;};
inline float realValue(const ParameterSpec& p,float v){return p.minimum+v*(p.maximum-p.minimum);}
}
#if TSTUDIO_PRODUCT == 0
#include "../plugins/Stereo/core/WavesS1DSP.h"
namespace studio {
using Core=WavesDSP::WavesS1StereoImager;
inline constexpr const char* productName="T-StereoSpace";
inline constexpr int dspParameterCount=14,parameterCount=15,defaultPreset=0,presetCount=8;
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
{"gain","Output",Kind::Float,0.666666667f,-24.000000000f,12.000000000f,0.100000000f,"dB",""},
{"width","Width",Kind::Float,0.250000000f,0.000000000f,4.000000000f,0.010000000f,"x",""},
{"shuffle","Bass Spread",Kind::Float,0.000000000f,1.000000000f,3.000000000f,0.010000000f,"x",""},
{"frequency","Spread Frequency",Kind::Float,0.333333333f,350.000000000f,1400.000000000f,1.000000000f,"Hz",""},
{"rotation","Rotation",Kind::Float,0.500000000f,-45.000000000f,45.000000000f,0.100000000f,"deg",""},
{"asymmetry","Asymmetry",Kind::Float,0.500000000f,-90.000000000f,90.000000000f,0.100000000f,"deg",""},
{"bass_trim","Bass Trim",Kind::Float,0.500000000f,-3.000000000f,3.000000000f,0.100000000f,"dB",""},
{"swap","Swap Outputs",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"invert_l","Invert Output L",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"invert_r","Invert Output R",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"output_ms","Encode Output M/S",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"input_mode","Input",Kind::Choice,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"","Stereo L/R|Encoded M/S"},
{"mode","Processor",Kind::Choice,1.000000000f,0.000000000f,2.000000000f,1.000000000f,"","M/S Matrix|Imager|Bass Shuffler"},
{"power","Power",Kind::Switch,1.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"bypass","Bypass",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
}};
inline constexpr std::array<const char*,presetCount> presetNames {{"Neutral","Vocal FX Spread","Narrow","Wide","M/S Decode","M/S Encode","M/S Matrix","Bass Shuffler"}};
inline const std::array<std::array<float,dspParameterCount>,presetCount> factoryValues {{
{{0.666666667f,0.250000000f,0.000000000f,0.333333333f,0.500000000f,0.500000000f,0.500000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f,1.000000000f}},
{{0.666666667f,0.337500000f,0.200000000f,0.285714286f,0.500000000f,0.500000000f,0.416666667f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f,1.000000000f}},
{{0.666666667f,0.150000000f,0.000000000f,0.333333333f,0.500000000f,0.500000000f,0.500000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f,1.000000000f}},
{{0.666666667f,0.425000000f,0.000000000f,0.333333333f,0.500000000f,0.500000000f,0.500000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f,1.000000000f}},
{{0.666666667f,0.250000000f,0.000000000f,0.333333333f,0.500000000f,0.500000000f,0.500000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f,0.500000000f,1.000000000f}},
{{0.666666667f,0.250000000f,0.000000000f,0.333333333f,0.500000000f,0.500000000f,0.500000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f,0.000000000f,0.500000000f,1.000000000f}},
{{0.666666667f,0.250000000f,0.000000000f,0.333333333f,0.500000000f,0.500000000f,0.500000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f}},
{{0.666666667f,0.287500000f,0.500000000f,0.333333333f,0.500000000f,0.500000000f,0.500000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,0.000000000f,1.000000000f,1.000000000f}},
}};
inline const char* presetName(int i){return presetNames[size_t(i)];}
inline std::array<float,dspParameterCount> presetValues(int i){return factoryValues[size_t(i)];}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v){
 auto r=[&](int i){return realValue(parameterSpecs[size_t(i)],v[size_t(i)]);};
 WavesDSP::S1Parameters p;p.gainDb=r(0);p.width=r(1);p.shuffle=r(2);p.shuffleFreq=r(3);p.rotationDeg=r(4);p.asymmetryDeg=r(5);p.bassTrimDb=r(6);p.swapLR=v[7]>=.5f;p.invertLeft=v[8]>=.5f;p.invertRight=v[9]>=.5f;p.outputMS=v[10]>=.5f;p.inputMode=WavesDSP::S1InputMode(juce::roundToInt(r(11)));p.component=WavesDSP::S1ComponentMode(juce::roundToInt(r(12)));core.setParameters(p);
}
}
#endif
#if TSTUDIO_PRODUCT == 1
#include "../plugins/Bender/core/WavesVocalBenderDSP.h"
namespace studio {
using Core=WavesDSP::WavesVocalBenderDSP;
inline constexpr const char* productName="T-VocalBend";
inline constexpr int dspParameterCount=13,parameterCount=14,defaultPreset=0,presetCount=9;
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
{"pitch","Pitch",Kind::Float,0.500000000f,-12.000000000f,12.000000000f,0.010000000f,"st",""},
{"formant","Formant",Kind::Float,0.500000000f,-12.000000000f,12.000000000f,0.010000000f,"st",""},
{"fine","Fine Tune",Kind::Float,0.500000000f,-100.000000000f,100.000000000f,1.000000000f,"cents",""},
{"mix","Mix",Kind::Float,1.000000000f,0.000000000f,1.000000000f,0.001000000f,"%",""},
{"flatten","Flatten",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"note","Flatten Note (MIDI)",Kind::Float,0.500000000f,36.000000000f,84.000000000f,1.000000000f,"MIDI",""},
{"link","Link Formant to Pitch",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"lfo_rate","LFO Rate",Kind::Float,0.248120301f,0.050000000f,20.000000000f,0.010000000f,"Hz",""},
{"lfo_pitch","LFO > Pitch",Kind::Float,0.500000000f,-12.000000000f,12.000000000f,0.010000000f,"st",""},
{"lfo_formant","LFO > Formant",Kind::Float,0.500000000f,-12.000000000f,12.000000000f,0.010000000f,"st",""},
{"env_pitch","Envelope > Pitch",Kind::Float,0.500000000f,-12.000000000f,12.000000000f,0.010000000f,"st",""},
{"env_formant","Envelope > Formant",Kind::Float,0.500000000f,-12.000000000f,12.000000000f,0.010000000f,"st",""},
{"power","Power",Kind::Switch,1.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
{"bypass","Bypass",Kind::Switch,0.000000000f,0.000000000f,1.000000000f,1.000000000f,"",""},
}};
inline constexpr std::array<const char*,presetCount> presetNames {{"Neutral","Octave Up","Octave Down","Fifth Up","Deep Formant","Bright Formant","Robot C3","Slow Pitch Motion","FX Send Fifth"}};
inline const std::array<std::array<float,dspParameterCount>,presetCount> factoryValues {{
{{0.500000000f,0.500000000f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{1.000000000f,0.500000000f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{0.000000000f,0.500000000f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{0.791666667f,0.500000000f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{0.500000000f,0.333333333f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{0.500000000f,0.625000000f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{0.500000000f,0.500000000f,0.500000000f,1.000000000f,1.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{0.500000000f,0.500000000f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.037593985f,0.512500000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
{{0.791666667f,0.416666667f,0.500000000f,1.000000000f,0.000000000f,0.500000000f,0.000000000f,0.248120301f,0.500000000f,0.500000000f,0.500000000f,0.500000000f,1.000000000f}},
}};
inline const char* presetName(int i){return presetNames[size_t(i)];}
inline std::array<float,dspParameterCount> presetValues(int i){return factoryValues[size_t(i)];}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v){
 auto r=[&](int i){return realValue(parameterSpecs[size_t(i)],v[size_t(i)]);};
 WavesDSP::VocalBenderParameters p;p.pitchSemitones=r(0);p.formantSemitones=r(1);p.fineTuneCents=r(2);p.mix=r(3);p.flattenEnabled=v[4]>=.5f;p.flattenNoteMidi=r(5);p.formantLink=v[6]>=.5f;p.lfoRateHz=r(7);p.lfoToPitchSt=r(8);p.lfoToFormantSt=r(9);p.envToPitchSt=r(10);p.envToFormantSt=r(11);core.setParameters(p);
}
}
#endif
