#include "PluginProcessor.h"
namespace studio {
class StudioLook final:public juce::LookAndFeel_V4 {
public:
 StudioLook(){setColour(juce::Slider::rotarySliderFillColourId,juce::Colour(0xff50dbc7));setColour(juce::Slider::rotarySliderOutlineColourId,juce::Colour(0xff343d49));setColour(juce::Slider::textBoxTextColourId,juce::Colour(0xffe8eff4));setColour(juce::Slider::textBoxBackgroundColourId,juce::Colour(0xff151c24));setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);setColour(juce::ComboBox::backgroundColourId,juce::Colour(0xff202a36));setColour(juce::TextButton::buttonOnColourId,juce::Colour(0xff166d64));}
 void drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float value,float from,float to,juce::Slider&) override {
  auto r=juce::Rectangle<float>(float(x),float(y),float(w),float(h)).reduced(8);auto diameter=std::min(r.getWidth(),r.getHeight());r=r.withSizeKeepingCentre(diameter,diameter);auto inner=r.reduced(7);
  g.setColour(juce::Colour(0xff080d13));g.fillEllipse(r.translated(0,3));g.setGradientFill(juce::ColourGradient(juce::Colour(0xff434d59),inner.getTopLeft(),juce::Colour(0xff202630),inner.getBottomRight(),false));g.fillEllipse(inner);
  juce::Path track;track.addCentredArc(r.getCentreX(),r.getCentreY(),diameter*.5f-2,diameter*.5f-2,0,from,to,true);g.setColour(juce::Colour(0xff3c4855));g.strokePath(track,juce::PathStrokeType(3));
  juce::Path active;active.addCentredArc(r.getCentreX(),r.getCentreY(),diameter*.5f-2,diameter*.5f-2,0,from,from+value*(to-from),true);g.setColour(juce::Colour(0xff50dbc7));g.strokePath(active,juce::PathStrokeType(3));
  const float a=from+value*(to-from);auto c=r.getCentre();g.drawLine(c.x+std::sin(a)*diameter*.26f,c.y-std::cos(a)*diameter*.26f,c.x+std::sin(a)*diameter*.36f,c.y-std::cos(a)*diameter*.36f,3);
 }
};
class Editor final:public juce::AudioProcessorEditor,private juce::Timer {
 using SliderAttachment=juce::AudioProcessorValueTreeState::SliderAttachment;using ButtonAttachment=juce::AudioProcessorValueTreeState::ButtonAttachment;using ComboAttachment=juce::AudioProcessorValueTreeState::ComboBoxAttachment;
 PluginProcessor& processor;StudioLook look;juce::ComboBox presets;juce::Label meters,help;
 std::array<std::unique_ptr<juce::Component>,parameterCount> controls;std::array<std::unique_ptr<juce::Label>,parameterCount> labels;
 std::vector<std::unique_ptr<SliderAttachment>> sliders;std::vector<std::unique_ptr<ButtonAttachment>> buttons;std::vector<std::unique_ptr<ComboAttachment>> combos;
public:
 Editor(PluginProcessor& p):AudioProcessorEditor(p),processor(p){setLookAndFeel(&look);
  for(int i=0;i<presetCount;++i){presets.addItem(presetName(i),i+1);}
  presets.setSelectedId(p.getCurrentProgram()+1,juce::dontSendNotification);presets.onChange=[this]{processor.setCurrentProgram(presets.getSelectedId()-1);};addAndMakeVisible(presets);
  for(int i=0;i<parameterCount;++i){const auto& s=parameterSpecs[size_t(i)];
   labels[size_t(i)]=std::make_unique<juce::Label>();auto& label=*labels[size_t(i)];label.setText(s.label,juce::dontSendNotification);label.setJustificationType(juce::Justification::centred);label.setFont(juce::FontOptions(13));addAndMakeVisible(label);
   if(s.kind==Kind::Switch){auto b=std::make_unique<juce::TextButton>(s.label);b->setClickingTogglesState(true);auto* raw=b.get();controls[size_t(i)]=std::move(b);buttons.push_back(std::make_unique<ButtonAttachment>(p.state,s.id,*raw));label.setVisible(false);}
   else if(s.kind==Kind::Choice){auto box=std::make_unique<juce::ComboBox>();box->addItemList(juce::StringArray::fromTokens(s.choices,"|",""),1);auto* raw=box.get();controls[size_t(i)]=std::move(box);combos.push_back(std::make_unique<ComboAttachment>(p.state,s.id,*raw));}
   else {auto slider=std::make_unique<juce::Slider>();slider->setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);slider->setTextBoxStyle(juce::Slider::TextBoxBelow,false,112,24);slider->setRange(0,1,s.step/(s.maximum-s.minimum));slider->setDoubleClickReturnValue(true,s.defaultValue);slider->textFromValueFunction=[s](double value){return parameterText(s,float(value));};slider->valueFromTextFunction=[s](const juce::String& text){float real=text.getFloatValue();if(juce::String(s.unit)=="%")real*=.01f;return double(juce::jlimit(0.f,1.f,(real-s.minimum)/(s.maximum-s.minimum)));};auto* raw=slider.get();controls[size_t(i)]=std::move(slider);sliders.push_back(std::make_unique<SliderAttachment>(p.state,s.id,*raw));}
   auto& control=*controls[size_t(i)];control.setComponentID("param_"+juce::String(s.id));addAndMakeVisible(control);
  }
  meters.setFont(juce::FontOptions(13));meters.setJustificationType(juce::Justification::centred);addAndMakeVisible(meters);
  #if TSTUDIO_PRODUCT==0
  help.setText("Stereo insert / FX return  |  Width 1 = original  |  M/S input needs an encoded source",juce::dontSendNotification);
  #else
  help.setText("Creative pitch & formant effect  |  Neutral = original  |  FX Send: Mix 100%",juce::dontSendNotification);
  #endif
  help.setFont(juce::FontOptions(12));help.setJustificationType(juce::Justification::centred);help.setColour(juce::Label::textColourId,juce::Colour(0xff9faebe));addAndMakeVisible(help);setSize(820,590);timerCallback();startTimerHz(20);
 }
 ~Editor() override {stopTimer();setLookAndFeel(nullptr);}
 void paint(juce::Graphics& g) override {g.fillAll(juce::Colour(0xff10161e));g.setColour(juce::Colour(0xff1c2531));g.fillRoundedRectangle(16,75,788,444,14);g.setColour(juce::Colour(0xff50dbc7));g.setFont(juce::FontOptions(25,juce::Font::bold));g.drawText(productName,28,16,340,35,juce::Justification::centredLeft);g.setColour(juce::Colour(0xffa2afbd));g.setFont(juce::FontOptions(12));g.drawText("T STUDIO  /  STEREO & VOCAL FX",29,49,350,16,juce::Justification::centredLeft);}
 void resized() override {
  presets.setBounds(494,22,300,34);meters.setBounds(24,523,772,24);help.setBounds(24,554,772,22);
  #if TSTUDIO_PRODUCT==0
  const std::array<juce::Rectangle<int>,parameterCount> bounds {{{35,110,128,157},{184,110,166,157},{374,110,128,157},{527,110,128,157},{35,312,128,150},{184,312,128,150},{334,312,128,150},{640,358,145,30},{640,400,145,30},{640,442,145,30},{477,442,145,30},{477,318,145,32},{477,377,145,32},{666,113,115,32},{666,159,115,32}}};
  #else
  const std::array<juce::Rectangle<int>,parameterCount> bounds {{{35,112,165,167},{216,112,165,167},{397,112,128,167},{541,112,128,167},{677,220,110,30},{677,300,110,130},{622,456,165,30},{35,326,128,157},{184,326,128,157},{333,326,128,157},{477,326,128,157},{622,326,0,0},{677,113,110,32},{677,159,110,32}}};
  #endif
  for(int i=0;i<parameterCount;++i){auto b=bounds[size_t(i)];controls[size_t(i)]->setBounds(b);labels[size_t(i)]->setBounds(b.getX(),b.getY()-23,b.getWidth(),22);}
  #if TSTUDIO_PRODUCT==1
  // All modulation controls remain visible; envelope formant occupies its own dial.
  dynamic_cast<juce::Slider*>(controls[5].get())->setSliderStyle(juce::Slider::LinearHorizontal);
  controls[4]->setBounds(685,201,110,25);
  controls[5]->setBounds(685,251,110,44);labels[5]->setBounds(685,229,110,22);
  controls[10]->setBounds(477,326,128,157);labels[10]->setBounds(477,303,128,22);
  controls[11]->setBounds(622,326,128,157);labels[11]->setBounds(622,303,128,22);
  controls[6]->setBounds(35,488,225,24);
  #endif
 }
 void timerCallback() override {if(presets.getSelectedId()!=processor.getCurrentProgram()+1)presets.setSelectedId(processor.getCurrentProgram()+1,juce::dontSendNotification);
  juce::String text="IN  "+juce::String(processor.inputDb.load(),1)+" dBFS     OUT  "+juce::String(processor.outputDb.load(),1)+" dBFS";
  #if TSTUDIO_PRODUCT==1
  const auto hz=processor.detectedHz.load();text+="     INPUT PITCH  "+(hz>0?juce::String(hz,1)+" Hz":juce::String("--"));
  #endif
  meters.setText(text,juce::dontSendNotification);
 }
};
juce::AudioProcessorEditor* PluginProcessor::createEditor(){return new Editor(*this);}
}
