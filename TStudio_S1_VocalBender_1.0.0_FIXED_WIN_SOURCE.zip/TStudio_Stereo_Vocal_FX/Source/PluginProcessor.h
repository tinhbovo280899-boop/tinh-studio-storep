#pragma once
#include "ProductData.h"
namespace studio {
juce::String parameterText(const ParameterSpec&,float);
class PluginProcessor final:public juce::AudioProcessor {
public:
 PluginProcessor();
 void prepareToPlay(double,int) override;
 void releaseResources() override {reset();}
 void reset() override;
 using juce::AudioProcessor::processBlock;
 using juce::AudioProcessor::processBlockBypassed;
 void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
 void processBlockBypassed(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
 bool isBusesLayoutSupported(const BusesLayout&) const override;
 juce::AudioProcessorEditor* createEditor() override;
 bool hasEditor() const override {return true;}
 const juce::String getName() const override {return productName;}
 bool acceptsMidi() const override {return false;}
 bool producesMidi() const override {return false;}
 bool isMidiEffect() const override {return false;}
 double getTailLengthSeconds() const override;
 int getNumPrograms() override {return presetCount;}
 int getCurrentProgram() override {return currentProgram.load();}
 void setCurrentProgram(int) override;
 const juce::String getProgramName(int) override;
 void changeProgramName(int,const juce::String&) override {}
 void getStateInformation(juce::MemoryBlock&) override;
 void setStateInformation(const void*,int) override;
 juce::AudioProcessorParameter* getBypassParameter() const override {return state.getParameter("bypass");}
 float parameter(int) const noexcept;
 float parameter(const juce::String&) const noexcept;
 bool powered() const noexcept;
 juce::AudioProcessorValueTreeState state;
 std::atomic<float> inputDb{-100},outputDb{-100},gainReductionDb{0},vuDb{-100},detectedHz{0};
 std::atomic<int> needleFrame{0},inputFrameL{0},inputFrameR{0};
private:
 static juce::AudioProcessorValueTreeState::ParameterLayout makeLayout();
 void setEngineParameters();
 Core engine;
 std::array<std::atomic<float>*,parameterCount> values{};
 std::array<juce::SmoothedValue<float>,dspParameterCount> controls;
 juce::SmoothedValue<float> bypassRamp;
 juce::AudioBuffer<float> dry;
 std::atomic<int> currentProgram{defaultPreset};
 int controlRemaining=0;bool hostBypass=false;
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(PluginProcessor)
};
}
