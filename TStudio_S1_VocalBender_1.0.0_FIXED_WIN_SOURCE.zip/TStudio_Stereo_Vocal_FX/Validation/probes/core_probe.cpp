#include "WavesS1DSP.h"
#include "WavesVocalBenderDSP.h"
#include <fstream>
#include <iostream>
#include <string>
#include <vector>
#include <cmath>
int main(int argc,char**argv){
 using namespace WavesDSP;
 std::string dir=argc>1?argv[1]:".";
 WavesS1StereoImager s; S1Parameters p;p.component=S1ComponentMode::Imager;p.width=1;s.setParameters(p);s.prepare(48000);
 std::cout<<"S1 neutral matrix:";for(int k=0;k<4;k++)std::cout<<" "<<s.getTargetCoefs()[k];std::cout<<"\n";
 for(float st:{-12.f,-5.f,0.f,5.f,12.f})std::cout<<"pow2 "<<st<<" "<<WavesVocalBenderDSP::wavesPadePow2(st/12)<<" expected "<<std::exp2(st/12)<<"\n";
 int N=48000*2;std::vector<float>x(N),y(N);for(int i=0;i<N;++i){double ph=6.283185307179586*220*i/48000.;x[i]=.2f*std::sin(ph)+.1f*std::sin(2*ph+.3)+.05f*std::sin(3*ph+.7);}
 for(float pitch:{-12.f,-5.f,0.f,5.f,12.f}){WavesVocalBenderDSP v;v.prepare(48000);VocalBenderParameters b;b.pitchSemitones=pitch;v.setParameters(b);v.reset();v.processBlockMono(x.data(),y.data(),N);std::ofstream f(dir+"/pitch_"+std::to_string(int(pitch))+".f32",std::ios::binary);f.write((char*)y.data(),N*4);std::cout<<"VB "<<pitch<<" F0 "<<v.getDetectedFreqHz()<<"\n";}
 std::ofstream f(dir+"/input.f32",std::ios::binary);f.write((char*)x.data(),N*4);
}
