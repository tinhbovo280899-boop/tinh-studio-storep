from pathlib import Path
import subprocess,json,hashlib
r=Path(__file__).resolve().parents[1];result=[];binaries=[]
for target,name,modes in [('TStereoSpace','T-StereoSpace',['stereo','duplicate-stereo']),('TVocalBend','T-VocalBend',['stereo','mono','duplicate-stereo'])]:
 binary=r/f'build/native-linux/{target}_artefacts/Release/VST3/{name}.vst3/Contents/x86_64-linux/{name}.so';binaries.append(dict(product=name,sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),bytes=binary.stat().st_size))
 for mode in modes:
  for active in [False,True]:
   if active and mode=='stereo':continue
   args=[str(r/'build/native_host_probe'),str(binary)]+([] if mode=='stereo' else [mode]);
   if active:args+=['pitch5' if target=='TVocalBend' else 'width15']
   run=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=60)
   key=target+'-'+mode+('-active' if active else '-neutral');(r/'logs'/('native-host-'+key+'.log')).write_text(run.stdout)
   result.append(dict(product=name,mode=mode,active=active,exit_code=run.returncode,rate_cases=run.stdout.count('VST3 ')))
   print(key,'exit',run.returncode);assert run.returncode==0,run.stdout
run=subprocess.run([str(r/'build/native_host_probe'),str(r/'build/native-linux/TStereoSpace_artefacts/Release/VST3/T-StereoSpace.vst3/Contents/x86_64-linux/T-StereoSpace.so'),'mono'],capture_output=True,text=True)
assert run.returncode==10,run.stdout
result.append(dict(product='T-StereoSpace',mode='mono',expected_rejection=True,exit_code=run.returncode))
(r/'native-results.json').write_text(json.dumps({'scope':'Real Linux x86_64 VST3, full JUCE SDK wrapper; 44.1/48/96 kHz, variable 64/128 blocks; active host parameter queues exercise Width and Pitch +5 st. Not Windows or Cubase.','rate_configurations':sum(x.get('rate_cases',0) for x in result),'results':result,'binaries':binaries},indent=2)+'\n')
