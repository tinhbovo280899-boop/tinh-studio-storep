"""Contract tests for the Windows export script; mock PE headers are QA only.
This deliberately does not claim to compile/load any native Windows plugin.
"""
import hashlib, json, os, pathlib, shutil, subprocess

root=pathlib.Path(__file__).resolve().parents[1]
project=root/'fixed/TStudio_Stereo_Vocal_FX'
pwsh=pathlib.Path('/workspace/vst-31-review-20261031/tools/powershell/pwsh')
cmake=pathlib.Path('/workspace/vst-31-review-20261031/tools/cmake/data/bin/cmake')
work=root/'qa/builder-contract'
work.mkdir(parents=True,exist_ok=True)
environment=os.environ.copy()
for key,part in [('XDG_CACHE_HOME','cache'),('XDG_CONFIG_HOME','config'),('XDG_DATA_HOME','data'),('DOTNET_CLI_HOME','dotnet')]:
    path=work/part;path.mkdir(exist_ok=True);environment[key]=str(path)
fake=work/'mock cmake.py'
fake.write_text('''#!/usr/bin/python3
import json, os, pathlib, struct, sys
args=sys.argv[1:]
with open(os.environ['TSTUDIO_QA_CMAKE_CALLS'],'a') as f:f.write(json.dumps(args)+'\\n')
mode=os.environ['TSTUDIO_QA_CMAKE_SCENARIO']
if args==['--version']:
 print('cmake version '+('3.21.0' if mode=='old-version' else '4.4.0'));sys.exit(0)
if '-S' in args:
 if mode=='configure-fail':print('Intentional QA configure failure');sys.exit(23)
 pathlib.Path(args[args.index('-B')+1]).mkdir(parents=True,exist_ok=True)
 print('QA configure complete');sys.exit(0)
if '--build' in args:
 if mode=='build-fail':print('Intentional QA build failure');sys.exit(24)
 build=pathlib.Path(args[1])
 for i,(target,name) in enumerate([('TStereoSpace','T-StereoSpace'),('TVocalBend','T-VocalBend')]):
  if mode=='missing-product' and i==1:continue
  bundle=build/(target+'_artefacts/Release/VST3')/(name+'.vst3')
  dest=bundle/'Contents/x86_64-win'/(name+'.vst3');dest.parent.mkdir(parents=True,exist_ok=True)
  data=bytearray(256);data[0:2]=b'MZ';struct.pack_into('<I',data,60,128)
  data[128:132]=b'PE\\0\\0';struct.pack_into('<H',data,132,0x14c if mode=='wrong-architecture' else 0x8664)
  struct.pack_into('<H',data,152,0x10b if mode=='wrong-architecture' else 0x20b)
  if mode=='invalid-binary' and i==1:data[0:2]=b'XX'
  dest.write_bytes(data)
  resources=bundle/'Contents/Resources';resources.mkdir(parents=True,exist_ok=True)
  (resources/'qa-resource.txt').write_text('QA ONLY - not a real Windows plugin')
 print('QA build complete');sys.exit(0)
print('Unexpected mock invocation');sys.exit(25)
''')
fake.chmod(0o755)
results=[]
def invoke(case,path,scenario='success',plan=False,real_cmake=False):
    env=environment.copy();env['TSTUDIO_QA_CMAKE_SCENARIO']=scenario
    env['TSTUDIO_QA_CMAKE_CALLS']=str(work/(case+'-calls.jsonl'))
    args=[str(pwsh),'-NoLogo','-NoProfile','-File',str(project/'tools/Build-Windows.ps1'),
          '-ProjectDirectory',str(path),'-CMakePath',str(cmake if real_cmake else fake),'-Generator','Visual Studio 17 2022','-Parallel','3']
    if plan:args+=['-PlanOnly']
    run=subprocess.run(args,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=90)
    (root/'logs'/('windows-builder-'+case+'.log')).write_text(run.stdout)
    return run
def fixture(case):
    path=work/('Project spaced tiếng Việt '+case)
    if path.exists():shutil.rmtree(path)
    (path/'third_party/JUCE').mkdir(parents=True)
    (path/'CMakeLists.txt').write_text('# QA mock only\n')
    (path/'third_party/JUCE/CMakeLists.txt').write_text('# QA mock only\n')
    shutil.copyfile(project/'BUNDLE_INFO.json',path/'BUNDLE_INFO.json')
    return path

run=invoke('real-plan',project,plan=True,real_cmake=True)
assert run.returncode==0,run.stdout
plan=json.loads(run.stdout)
assert plan['architecture']=='x64' and plan['configure'][plan['configure'].index('-A')+1]=='x64'
assert all(t in plan['build'] for t in ['TStereoSpace_VST3','TVocalBend_VST3','Release'])
assert '-DBUILD_TESTING=OFF' in plan['configure'] and '-DTSTUDIO_USE_INSTALLED_JUCE=OFF' in plan['configure']
results.append({'case':'real-project-plan','passed':True,'native_windows_compile':False})

for scenario in ['configure-fail','build-fail','missing-product','wrong-architecture','invalid-binary','old-version']:
    path=fixture(scenario);run=invoke(scenario,path,scenario)
    assert run.returncode!=0 and 'BUILD FAILED' in run.stdout and 'BUILD AND EXPORT COMPLETE' not in run.stdout,(scenario,run.stdout)
    assert not (path/'_EXPORT').exists(),scenario
    results.append({'case':scenario,'passed':True,'exit_code':run.returncode})

path=fixture('success')
destinations=[]
for i in range(2):
    run=invoke('success-'+str(i),path)
    assert run.returncode==0 and 'BUILD AND EXPORT COMPLETE' in run.stdout,run.stdout
    out=path/'_EXPORT'
    folder=pathlib.Path((out/'LATEST_EXPORT.txt').read_text(encoding='utf-8-sig').strip())
    assert folder.is_dir()
    assert sorted(p.name for p in folder.iterdir())==['T-StereoSpace.vst3','T-VocalBend.vst3']
    manifest=json.loads((folder.parent/'EXPORT_MANIFEST.json').read_text(encoding='utf-8-sig'))
    assert len(manifest['files'])==4
    for entry in manifest['files']:
        f=folder.parent/entry['path'];assert f.is_file() and f.stat().st_size==entry['bytes'] and hashlib.sha256(f.read_bytes()).hexdigest()==entry['sha256']
    destinations.append(folder)
    assert len(list(out.glob('Build-*')))==i+1 and not list(out.glob('.staging-*'))
assert destinations[0]!=destinations[1] and all(x.is_dir() for x in destinations)
results.append({'case':'success-export-full-bundles-manifest-and-repeat-preserves-previous','passed':True,'native_windows_compile':False})

# A subsequent build failure must leave an existing valid export untouched.
before={p.relative_to(path/'_EXPORT').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (path/'_EXPORT').rglob('*') if p.is_file()}
run=invoke('failure-after-success',path,'build-fail')
after={p.relative_to(path/'_EXPORT').as_posix():hashlib.sha256(p.read_bytes()).hexdigest() for p in (path/'_EXPORT').rglob('*') if p.is_file()}
assert run.returncode!=0 and before==after
results.append({'case':'failure-keeps-prior-export','passed':True})
(root/'windows-builder-results.json').write_text(json.dumps({'scope':'PowerShell 7 on Linux; CMake/PE mock contract tests, not native Windows build','results':results},indent=2)+'\n')
print('Windows builder:',len(results),'contract cases passed. Native Windows build not executed.')
