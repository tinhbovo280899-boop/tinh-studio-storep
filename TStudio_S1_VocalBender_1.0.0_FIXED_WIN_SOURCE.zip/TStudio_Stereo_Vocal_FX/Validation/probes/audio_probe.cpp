#include "WavesVocalBenderDSP.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <chrono>
#include <string>
#include <cmath>
int main(int argc,char** argv){if(argc<6)return 2;double sr=std::stod(argv[2]),f0=std::stod(argv[3]);WavesDSP::VocalBenderParameters p;p.pitchSemitones=std::stof(argv[4]);p.formantSemitones=std::stof(argv[5]);if(argc>6)p.flattenEnabled=std::stoi(argv[6])!=0;
 int n=int(sr*1.5);std::vector<float>x(size_t(n),0),y(size_t(n),0);for(int i=0;i<n;++i){double v=0;for(int h=1;h<=int(8000/f0)&&h*f0<sr*.45;++h){double freq=h*f0;double form=.08+.8*std::exp(-.5*std::pow((freq-850)/180,2))+.5*std::exp(-.5*std::pow((freq-2400)/350,2));v+=form/std::sqrt(h)*std::sin(6.283185307179586*freq*i/sr+.17*h);}x[size_t(i)]=float(.18*v);}
 WavesDSP::WavesVocalBenderDSP v;v.prepare(sr);v.setParameters(p);v.reset();auto t=std::chrono::steady_clock::now();for(int off=0;off<n;off+=64)v.processBlockMono(x.data()+off,y.data()+off,std::min(64,n-off));auto elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-t).count();std::ofstream f(argv[1],std::ios::binary);f.write((char*)y.data(),n*4);std::cout<<"{\"detected_hz\":"<<v.getDetectedFreqHz()<<",\"voiced\":"<<v.isVoiced()<<",\"render_seconds\":"<<elapsed<<",\"audio_seconds\":1.5}\n";
}
