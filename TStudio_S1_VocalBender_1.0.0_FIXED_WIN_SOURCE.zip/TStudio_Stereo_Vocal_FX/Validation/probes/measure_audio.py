import numpy as np,subprocess,json
from pathlib import Path
r=Path(__file__).resolve().parents[1];out=r/'qa/audio';out.mkdir(exist_ok=True)
results=[]
cases=[(48000,220,p,0,0) for p in [-12,-5,0,5,12]]+[(48000,220,0,f,0) for f in [-6,6]]+[(48000,220,0,0,1)]+[(sr,f0,5,0,0) for sr in [44100,96000,192000] for f0 in [85,220,660]]
for version in ['baseline','fixed']:
 for sr,f0,pitch,formant,flatten in cases:
  path=out/f'{version}-{sr}-{f0}-{pitch}-{formant}-{flatten}.f32'
  run=subprocess.run([str(r/'build'/('audio_'+version)),str(path),str(sr),str(f0),str(pitch),str(formant),str(flatten)],capture_output=True,text=True,check=True);entry=json.loads(run.stdout)
  x=np.fromfile(path,np.float32);y=x[int(sr*.5):];a=np.abs(np.fft.rfft(y*np.hanning(len(y))));freq=np.fft.rfftfreq(len(y),1/sr);ps=a*a
  entry.update(version=version,sample_rate=sr,input_hz=f0,pitch_st=pitch,formant_st=formant,flatten=flatten,peak=float(np.max(np.abs(x))),rms=float(np.sqrt(np.mean(y*y))),dc=float(np.mean(y)),spectral_centroid_hz=float(np.sum(ps*freq)/max(np.sum(ps),1e-20)),strongest_non_dc_hz=float(freq[1+np.argmax(a[1:])]),expected_f0_hz=float(261.625565 if flatten else f0*2**(pitch/12)))
  target=entry['expected_f0_hz'];ratios=[]
  # Dominant spectral peak can be a harmonic; compare the harmonic grid around expected F0.
  for h in range(1,8):
   k=np.argmin(abs(freq-target*h));ratios.append(float(np.max(a[max(0,k-1):k+2])))
  entry['target_harmonic_amplitudes']=ratios;results.append(entry)
(r/'audio-results.json').write_text(json.dumps({'scope':'Synthetic voiced harmonic signals, 1.5 seconds, 64-sample blocks. CPU wall time is environment-specific, not a Windows/Cubase benchmark. Strongest harmonic is not necessarily F0.','cases':results},indent=2)+'\n')
for v in results:
 if v['sample_rate']==48000:print(v['version'],v['pitch_st'],v['formant_st'],v['flatten'],'peak Hz',v['strongest_non_dc_hz'],'centroid',round(v['spectral_centroid_hz']),'rms',round(v['rms'],4),'detector',v['detected_hz'])
