Đây là ZIP gốc anh gửi, giữ nguyên để đối chiếu mã nguồn/ảnh/XML/disassembly.
Phần Reference không được biên dịch, giải nén hoặc thực thi bởi BAT/CMake.
Các dòng “100% Exact / Zero latency” trong tài liệu gốc là mô tả của bản gốc, không phải kết luận của đợt kiểm tra này.
Giao diện chạy trong VST3 mới được vẽ trực tiếp bằng JUCE, mang tên T Studio. Ảnh giao diện hãng trong ZIP gốc không được dùng để giả thành plugin chính hãng.
