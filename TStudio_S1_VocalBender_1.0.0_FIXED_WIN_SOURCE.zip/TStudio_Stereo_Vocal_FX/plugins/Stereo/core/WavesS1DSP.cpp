// Corrected matrix and first-order shuffler from the submitted C++ implementation.
// This revision is tested for its stated mappings; manufacturer equivalence is unverified.
#include "WavesS1DSP.h"
#include <cstring>
namespace WavesDSP {
namespace {constexpr double pi=3.14159265358979323846,k=.7071067811865475244;
double finite(double x,double lo,double hi,double def){return std::isfinite(x)?std::clamp(x,lo,hi):def;}
float clean(float x){return std::isfinite(x)?std::clamp(x,-64.f,64.f):0.f;}}
WavesS1StereoImager::WavesS1StereoImager(){prepare(44100);}
void WavesS1StereoImager::prepare(double sr){m_sampleRate=finite(sr,8000,384000,44100);m_smoothAlpha=1-std::exp(-1/(.005*m_sampleRate));updateDSPCoefs();reset();}
void WavesS1StereoImager::reset(){m_midX1=m_midY1=m_sideX1=m_sideY1=0;m_meters={};std::copy(m_targetCoefs,m_targetCoefs+10,m_currentCoefs);std::copy(m_outputTarget,m_outputTarget+4,m_outputCurrent);m_shuffleBlend=m_params.component==S1ComponentMode::Shuffler?1:0;}
void WavesS1StereoImager::setParameters(const S1Parameters& p){m_params=p;
 m_params.gainDb=finite(p.gainDb,-24,12,0);m_params.width=finite(p.width,0,4,1);m_params.shuffle=finite(p.shuffle,1,3,1.4);
 m_params.shuffleFreq=finite(p.shuffleFreq,350,1400,700);m_params.rotationDeg=finite(p.rotationDeg,-45,45,0);m_params.asymmetryDeg=finite(p.asymmetryDeg,-90,90,0);m_params.bassTrimDb=finite(p.bassTrimDb,-3,3,0);
 if(int(p.component)<0||int(p.component)>2)m_params.component=S1ComponentMode::Shuffler;
 if(int(p.inputMode)<0||int(p.inputMode)>1)m_params.inputMode=S1InputMode::StereoToStereo;
 updateDSPCoefs();}
void WavesS1StereoImager::updateDSPCoefs(){
 const double g=std::pow(10.,m_params.gainDb*.05),w=m_params.width;
 const double a=(45-m_params.rotationDeg)*pi/180,b=a+m_params.asymmetryDeg*pi/180;
 const double n=g*(w>1?std::sqrt(.5*(1+.6/(w*w))/1.6):k);
 double m00=n*(std::cos(a)+w*std::sin(b)),m01=n*(std::cos(a)-w*std::sin(b));
 double m10=n*(std::sin(a)-w*std::cos(b)),m11=n*(std::sin(a)+w*std::cos(b));
 if(m_params.component==S1ComponentMode::MSMatrix){m00=m01=m10=g*k;m11=-g*k;}
 else if(m_params.inputMode==S1InputMode::MidSideToStereo){const double u=m00,v=m01,z=m10,t=m11;m00=k*(u+v);m01=k*(u-v);m10=k*(z+t);m11=k*(z-t);}
 double o00=1,o01=0,o10=0,o11=1;
 if(m_params.outputMS&&m_params.component!=S1ComponentMode::MSMatrix){o00=o01=o10=k;o11=-k;}
 if(m_params.invertLeft){o00=-o00;o01=-o01;}if(m_params.invertRight){o10=-o10;o11=-o11;}
 if(m_params.swapLR){std::swap(o00,o10);std::swap(o01,o11);}
 m_outputTarget[0]=o00;m_outputTarget[1]=o01;m_outputTarget[2]=o10;m_outputTarget[3]=o11;
 m_targetCoefs[0]=m00;m_targetCoefs[1]=m01;m_targetCoefs[2]=m10;m_targetCoefs[3]=m11;
 const double s=m_params.shuffle,trim=std::pow(10.,m_params.bassTrimDb*.05),gm=std::sqrt(.5*(1/(s*s)+1))*trim;
 auto shelf=[&](double gain,int index){const double w0=-2*pi*m_params.shuffleFreq/m_sampleRate,beta=-(gain-1)/(gain+1);
  const double pole=(beta-std::cos(w0))/((1-beta*std::cos(w0))-std::sqrt(std::max(0.,1-beta*beta))*std::sin(w0));
  const double sum=.5*(gain+1),diff=.5*(gain-1);
  // H(0)=gain, H(pi)=+1. The original numerator terms were interchanged.
  m_targetCoefs[index]=.5*(sum+pole*diff);m_targetCoefs[index+1]=.5*(diff+pole*sum);m_targetCoefs[index+2]=pole;};
 shelf(gm,4);shelf(gm*s,7);
 m_msCoefs[0]=m_msCoefs[1]=m_msCoefs[2]=float(k);
}
void WavesS1StereoImager::processBlock(const float* l,const float* r,float* ol,float* or_,int count){
 if(count<=0||!l||!r||!ol||!or_)return;
 for(int i=0;i<count;++i){const double x=clean(l[i]),y=clean(r[i]);
  for(int j=0;j<10;++j)m_currentCoefs[j]+=m_smoothAlpha*(m_targetCoefs[j]-m_currentCoefs[j]);
  const auto* c=m_currentCoefs;double u=c[0]*x+c[1]*y,v=c[2]*x+c[3]*y;
  const double mid=u+v,side=u-v;
  const double mo=c[4]*mid+c[5]*m_midX1-c[6]*m_midY1,so=c[7]*side+c[8]*m_sideX1-c[9]*m_sideY1;
  m_midX1=mid;m_midY1=mo;m_sideX1=side;m_sideY1=so;
  m_shuffleBlend+=m_smoothAlpha*((m_params.component==S1ComponentMode::Shuffler?1.:0.)-m_shuffleBlend);
  u+=m_shuffleBlend*(mo+so-u);v+=m_shuffleBlend*(mo-so-v);
  for(int j=0;j<4;++j)m_outputCurrent[j]+=m_smoothAlpha*(m_outputTarget[j]-m_outputCurrent[j]);
  const double preL=u,preR=v;u=m_outputCurrent[0]*preL+m_outputCurrent[1]*preR;v=m_outputCurrent[2]*preL+m_outputCurrent[3]*preR;
  ol[i]=float(u);or_[i]=float(v);m_meters.peakLeft=std::max(m_meters.peakLeft,float(std::abs(u)));m_meters.peakRight=std::max(m_meters.peakRight,float(std::abs(v)));
  if(std::abs(u)>1.){m_meters.clipLeft=1;}
  if(std::abs(v)>1.){m_meters.clipRight=1;}
 }
}
} // namespace WavesDSP
