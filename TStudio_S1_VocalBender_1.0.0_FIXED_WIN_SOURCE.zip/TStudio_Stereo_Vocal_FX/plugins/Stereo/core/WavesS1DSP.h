#pragma once
// ============================================================================
// WavesS1DSP.h — Corrective revision of submitted C++ implementation of Waves S1.bundle
// Disassembled from:
//   - S1.bundle/Contents/Linux64/XLMC:
//       * S1MSproc  (0x1100 .. 0x14f5) — S1 MS Matrix (MSXS)
//       * S1NSHproc (0x1500 .. 0x19f1) — S1 Imager (NSHS)
//       * S1SHproc  (0x1a00 .. 0x2262) — S1 Shuffler (NIDS / S148)
//   - S1.bundle/Contents/Win64/S1.dll:
//       * cS1_ALG::CalcShufflerCoefs (0x180024840 .. 0x180024bdb)
//       * cS1_ALG::CalcImagerMatrix  (0x180024be0 .. 0x18002516b)
// ============================================================================

#include <cmath>
#include <cstdint>
#include <algorithm>

namespace WavesDSP {

enum class S1InputMode : int {
    StereoToStereo = 0, // L/R input -> L/R output
    MidSideToStereo = 1 // M/S input -> L/R output (0x180024e74)
};

enum class S1ComponentMode : int {
    MSMatrix = 0, // S1MSproc  (0x1100)
    Imager   = 1, // S1NSHproc (0x1500)
    Shuffler = 2  // S1SHproc  (0x1a00)
};

struct S1Parameters {
    double gainDb       = 0.0;   // PARAM_GAIN       [-24.0 .. +12.0 dB], offset 0xb0
    double width        = 1.0;   // PARAM_WIDTH      [0.0 .. 4.0],        offset 0x6b0
    double shuffle      = 1.40;  // PARAM_SHUFFLE    [1.0 .. 3.0],        offset 0xcb0
    double shuffleFreq  = 700.0; // PARAM_SF         [350.0 .. 1400.0 Hz],offset 0x12b0
    double rotationDeg  = 0.0;   // PARAM_ROTATION   [-45.0 .. +45.0 deg],offset 0x18b0
    double asymmetryDeg = 0.0;   // PARAM_ASYMMETRY  [-90.0 .. +90.0 deg],offset 0x1eb0
    double bassTrimDb   = 0.0;   // PARAM_BASE_TRIM  [-3.0 .. +3.0 dB],   offset 0x66b0
    bool   swapLR       = false; // PARAM_SWAP_LR    offset 0x4eb0
    bool   invertLeft   = false; // PARAM_PHASE_LEFT offset 0x54b0
    bool   invertRight  = false; // PARAM_PHASE_RIGHT offset 0x5ab0
    bool   outputMS     = false; // PARAM_MS_OUT     offset 0x60b0
    S1InputMode inputMode = S1InputMode::StereoToStereo;
    S1ComponentMode component = S1ComponentMode::Shuffler;
};

struct S1MeterState {
    float clipLeft  = 0.0f; // [rsi + 0x00] in S1NSHproc / [rsi + 0x18] in S1SHproc
    float clipRight = 0.0f; // [rsi + 0x04] in S1NSHproc / [rsi + 0x1c] in S1SHproc
    float peakLeft  = 0.0f; // [rsi + 0x08] in S1NSHproc / [rsi + 0x20] in S1SHproc
    float peakRight = 0.0f; // [rsi + 0x0c] in S1NSHproc / [rsi + 0x24] in S1SHproc
};

class WavesS1StereoImager {
public:
    WavesS1StereoImager();

    void prepare(double sampleRate);
    void reset();

    void setParameters(const S1Parameters& params);
    const S1Parameters& getParameters() const { return m_params; }

    // Corrected matrix/shuffler; output polarity and swap apply to complete output.
    void processBlock(const float* inL, const float* inR,
                      float* outL, float* outR,
                      int numSamples);

    const S1MeterState& getMeters() const { return m_meters; }
    void clearClipIndicators() { m_meters.clipLeft = 0.0f; m_meters.clipRight = 0.0f; }

    // Inspect internal calculated target coefficients (for unit testing / verification)
    const double* getTargetCoefs() const { return m_targetCoefs; }

private:
    void updateDSPCoefs();

    double m_sampleRate = 44100.0;
    S1Parameters m_params;

    // Target coefficients r8[0..9] (computed in S1.dll @ 0x180024840 & 0x180024be0)
    // Index mapping for S1SHproc (0x1a00):
    //   [0] = m00 (LL matrix gain)
    //   [1] = m01 (RL matrix gain)
    //   [2] = m10 (LR matrix gain)
    //   [3] = m11 (RR matrix gain)
    //   [4] = b0_Mid  (0.5 * Mid shelving filter b0)
    //   [5] = b1_Mid  (0.5 * Mid shelving filter b1)
    //   [6] = a1_Mid  (Mid shelving filter pole a1)
    //   [7] = b0_Side (0.5 * Side Blumlein shuffler shelving b0)
    //   [8] = b1_Side (0.5 * Side Blumlein shuffler shelving b1)
    //   [9] = a1_Side (Side Blumlein shuffler shelving pole a1)
    double m_targetCoefs[10] = {0.0};

    // Smoothed per-sample coefficients rax[0..9] in S1SHproc / rax[0..3] in S1NSHproc
    double m_currentCoefs[10] = {0.0};

    // One-pole smoothing factor [r8 + 0x30] in S1SHproc / [r8 + 0x18] in S1NSHproc
    double m_smoothAlpha = 0.005;

    // Filter state memory rsi[0..5] in S1SHproc (0x1a00):
    //   m_midX1  = [rsi + 0x00] (previous Mid input)
    //   m_midY1  = [rsi + 0x04] (previous Mid output)
    //   m_sideX1 = [rsi + 0x0c] (previous Side input)
    //   m_sideY1 = [rsi + 0x10] (previous Side output)
    double m_midX1  = 0.0f;
    double m_midY1  = 0.0f;
    double m_sideX1 = 0.0f;
    double m_sideY1 = 0.0f;

    // MSXS (S1MSproc @ 0x1100) coefficients r9[0..2]
    float m_msCoefs[3] = {0.70710678f, 0.70710678f, 0.70710678f};

    double m_outputCurrent[4]={1,0,0,1},m_outputTarget[4]={1,0,0,1};
    double m_shuffleBlend=1;
    S1MeterState m_meters;
};

} // namespace WavesDSP
