#pragma once
// ============================================================================
// WavesVocalBenderDSP.h — Corrective revision of submitted C++ implementation of Waves Vocal Bender
// Disassembled from:
//   - Vocal Bender.bundle/Contents/Linux64/XLMC:
//       * ProcessType<float, double, CDVec2, 1>::VocalBenderProcess (0x46e0 .. 0x8890)
//       * nsPitchModuleVoices_Process::DetectPitch<float>           (0xe300 .. 0xf7a8)
//       * nsPitchModuleVoices_Process::extractPitchInfoFromFFT<float> (0x145b0 .. 0x14faf)
//       * nsPitchModuleVoices_Process::TestDecimatedPitch<float>    (0x14fb0 .. 0x156b1)
//       * nsPitchModuleVoices_Process::CreateNewDelayInstance<float> (0x156c0 .. 0x16d4f)
// ============================================================================

#include <cmath>
#include <cstdint>
#include <vector>
#include <array>
#include <algorithm>

namespace WavesDSP {

struct VocalBenderParameters {
    float pitchSemitones   = 0.0f;  // PARAM_PITCH      [-12.0 .. +12.0 st]
    float formantSemitones = 0.0f;  // PARAM_FORMANT    [-12.0 .. +12.0 st]
    float fineTuneCents    = 0.0f;  // PARAM_FINE_TUNE  [-100.0 .. +100.0 cents]
    float mix              = 1.0f;  // PARAM_MIX        [0.0 .. 1.0] (0..100%)
    bool  flattenEnabled   = false; // PARAM_FLATTEN    Flatten input pitch to target note
    float flattenNoteMidi  = 60.0f; // PARAM_FLATTEN_NOTE [36 .. 84 MIDI note, default C3=60]
    bool  formantLink      = false; // Link Formant knob to Pitch knob

    // Internal LFO / Envelope Modulation (SequencersStep @ 0xf7b0 & Mod Matrix @ 0x5fb0..0x6a35)
    float lfoRateHz        = 5.0f;  // LFO 1 Rate (Hz)
    float lfoToPitchSt     = 0.0f;  // LFO -> Pitch depth (semitones)
    float lfoToFormantSt   = 0.0f;  // LFO -> Formant depth (semitones)
    float envToPitchSt     = 0.0f;  // Amplitude Envelope -> Pitch depth (semitones)
    float envToFormantSt   = 0.0f;  // Amplitude Envelope -> Formant depth (semitones)
};

// Submitted 32-voice PSOLA Grain Bank structure (stPSOLA<float> @ [r14 + 0x5d48 .. 0x6130])
struct stPSOLA {
    static constexpr int kNumGrains   = 32; // r15 = -0x80 .. 0 step 4 (0x6b68..0x6b8e)
    static constexpr int kSincTaps    = 33; // Taps 0..32 (0x6c0d..0x7287)
    static constexpr int kSincPhases  = 256; // 0x43204 = 256.0f sub-sample phases

    int   bufferSize       = 8192;          // [rsi + 0x00] ([r14 + 0x5d48])
    int   bufferMask       = 8191;          // [rsi + 0x04] ([r14 + 0x5d4c])
    int   writePos         = 0;             // [rsi + 0x08] ([r14 + 0x5d50])
    int   analysisWritePos = 0;             // [rsi + 0x0c] ([r14 + 0x5d54])
    int   dpllAnchorPos    = 0;             // [rsi + 0x10] ([r14 + 0x5d58])
    int   currentGrainIdx  = 0;             // [rsi + 0x14] ([r14 + 0x5d5c])
    int   prevGrainIdx     = 0;             // [rsi + 0x18] ([r14 + 0x5d60])

    float currentPitchRatio   = 1.0f;       // [rsi + 0x24] ([r14 + 0x5d6c])
    float currentFormantRatio = 1.0f;       // [rsi + 0x2c] ([r14 + 0x5d74])
    float lastPeriodSamples   = 100.0f;     // [rsi + 0x38] ([r14 + 0x5d80])
    float grainCountdown      = 0.0f;       // [rsi + 0x44] ([r14 + 0x5d8c])
    float baseWindowStep      = 0.0f;       // [rsi + 0x50] ([r14 + 0x5d98])
    float initialWindowPhase  = -3.1415927f;// [rsi + 0x58] ([r14 + 0x5da0])
    int   unvoicedCounter     = 0;          // [rsi + 0x5c] ([r14 + 0x5da4])

    // Per-grain arrays (32 grains):
    std::array<float, kNumGrains> initialDelay{}; // [rsi + 0x60]  ([r14 + 0x5db4])
    std::array<float, kNumGrains> delaySamples{}; // [rsi + 0xe0]  ([r14 + 0x5e34])
    std::array<float, kNumGrains> windowPhase{};  // [rsi + 0x160] ([r14 + 0x5f34])
    std::array<float, kNumGrains> windowStep{};   // [rsi + 0x1e0] ([r14 + 0x5fb4])
    std::array<float, kNumGrains> delayStep{};    // [rsi + 0x260] ([r14 + 0x6034])
    std::array<int,   kNumGrains> activeState{};  // [rsi + 0x2e0] ([r14 + 0x60b4])

    int   peakPolarity = 1; // [rsi + 0x468] (1 = positive peak, 0 = negative trough)
};

// Digital Phase-Locked Loop state (DPLL<float> passed to CreateNewDelayInstance @ 0x156c0)
struct DPLLState {
    float phaseOffset   = 0.0f;
    float lockedPeriod  = 100.0f;
    bool  wasVoiced     = false;
};

// Biquad Filter State (used at 0x5941..0x5e1c and 0x7ddc..0x7e3b)
struct BiquadDF2 {
    double b0 = 1.0, b1 = 0.0, b2 = 0.0;
    double a1 = 0.0, a2 = 0.0;
    double x1 = 0.0, x2 = 0.0;
    double y1 = 0.0, y2 = 0.0;

    void reset() { x1 = x2 = y1 = y2 = 0.0; }

    inline float process(float in) {
        const double x = static_cast<double>(in);
        const double y = b0 * x + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2;
        x2 = x1; x1 = x;
        y2 = y1; y1 = y;
        return static_cast<float>(y);
    }
};

class WavesVocalBenderDSP {
public:
    WavesVocalBenderDSP();

    void prepare(double sampleRate);
    void reset();

    void setParameters(const VocalBenderParameters& params);
    const VocalBenderParameters& getParameters() const { return m_params; }

    // Process mono/stereo audio; zero fixed host lookahead, variable causal grain age.
    // Neutral and Mix=0 paths are exact dry. Active pitch/formant is not zero-delay.
    void processBlockMono(const float* in, float* out, int numSamples);
    void processBlockStereo(const float* inL, const float* inR,
                            float* outL, float* outR, int numSamples);

    float getDetectedPeriodSamples() const { return m_detectedPeriod; }
    float getDetectedFreqHz() const {
        return (m_detectedPeriod > 1.0f) ? static_cast<float>(m_sampleRate / m_detectedPeriod) : 0.0f;
    }
    bool isVoiced() const { return m_isVoiced; }

    // Semitone ratio helper (corrected to exp2, preserving the public API name).
    static float wavesPadePow2(float xOctaves);

private:
    // 1. DetectPitch<float> (0xe300..0xf7a8) + extractPitchInfoFromFFT<float> (0x145b0..0x14faf)
    bool detectPitchStep(float cleanInSample, float lpPitchSample);

    // 2. TestDecimatedPitch<float> (0x14fb0..0x156b1)
    //    Solves 2x2 Linear Least-Squares Regression on 8x-decimated pitch buffer
    bool testDecimatedPitch(float candidatePeriod, float maxAllowedError,
                            int writeIdx, int decimation, float& outRefinedPeriod) const;

    // 3. CreateNewDelayInstance<float> (0x156c0..0x16d4f)
    //    DPLL pitch-mark lock + PSOLA grain initialization
    void createNewDelayInstance(float pitchRatio, float formantRatio,
                                float periodSamples, float dpllSearchWidth);

    // 4. Read 33-tap polyphase windowed-sinc fractional delay (0x6ba5..0x7287)
    float readPolyphaseSinc(int baseIdx, float delaySamples) const;

    void initPolyphaseSincTable();
    void initBiquadFilters();

    double m_sampleRate = 44100.0;
    float  m_oversampleScale = 1.0f; // [rbx + 0x48d0] (sampleRate / 44100.0f)
    float  m_invOversample   = 1.0f; // [rsp + 0x160]

    VocalBenderParameters m_params;
    float m_effectBlend = 0.0f,m_blendAlpha=.002f;
    float m_analysisEnergyL=0,m_analysisEnergyR=0;bool m_analyseRight=false;
    float m_dcX=0,m_dcY=0,m_dcXR=0,m_dcYR=0,m_dcPole=.998f;

    // Circular audio & pitch analysis buffers
    std::vector<float> m_audioBuffer;      // r13 circular buffer (size 8192)
    std::vector<float> m_pitchRawBuffer;   // [rsp + 0x258] circular buffer (size 4096)
    std::vector<float> m_pitchLpBuffer;    // [rsp + 0x250] lowpass pitch buffer (size 4096)
    std::vector<float> m_dpllSearchBuffer; // [rsp + 0x138] bandpass pitch-mark buffer (size 8192)
    int m_pitchBufIdx  = 0;                // [r14 + 0x6220]
    int m_pitchBufMask = 4095;             // [r14 + 0x6224] - 1

    // 33-tap x 256-phase Windowed-Sinc table (rbp @ [rax + 0x360])
    std::vector<float> m_sincTable;

    // Pre/Post Biquad filters from VocalBenderProcess (0x5941..0x5e1c, 0x7ddc..0x7e3b)
    BiquadDF2 m_preEmphasisFilter;    // [r14 + 0x5b70..0x5b88]
    BiquadDF2 m_dpllBandpassFilter;   // [r14 + 0x5ae0..0x5af8]
    BiquadDF2 m_envDetectFilter1;     // [r14 + 0x5a90..0x5aa8]
    BiquadDF2 m_envDetectFilter2;     // [r14 + 0x5aa0..0x5ab8]
    BiquadDF2 m_pitchLowpassFilter;   // [r14 + 0x5ac0..0x5ad8]
    BiquadDF2 m_periodSmoothFilter;   // [r14 + 0x5b00..0x5b18]
    BiquadDF2 m_postDeEmphasisFilter; // [r14 + 0x5b90..0x5ba8]

    // Dual-Envelope Input/Output Peak Matcher ([r14 + 0x5b60..0x5b68], 0x7480..0x7d51)
    double m_outEnvState = 0.001; // [r14 + 0x5b60]
    double m_inEnvState  = 0.001; // [r14 + 0x5b68]

    // Input amplitude envelope follower ([r14 + 0x5b20], [r14 + 0x6244])
    double m_inputLevelEnv = 0.0;
    float  m_modEnvValue   = 0.0f;
    float  m_lfoPhase      = 0.0f;

    // Smoothed pitch & formant ratios ([r14 + 0x5b48], [r14 + 0x5b58])
    double m_smoothedPitchBase   = 1.0;
    double m_smoothedFormantBase = 1.0;

    // Pitch detector state (sPitchAnalysisStates<float> @ [r14 + 0x5c50])
    int   m_analysisHopCounter = 0;
    int   m_analysisHopSize    = 64;
    float m_detectedPeriod     = 100.0f; // [r14 + 0x6230]
    float m_smoothedPeriod     = 100.0f;
    bool  m_isVoiced           = false;

    stPSOLA   m_psola;
    DPLLState m_dpll;

    // Second channel instance for true stereo processing (VocalBenderProcS @ 0x88d0)
    std::vector<float> m_audioBufferR;
    BiquadDF2 m_preEmphasisFilterR;
    BiquadDF2 m_postDeEmphasisFilterR;
    double m_outEnvStateR = 0.001;
    double m_inEnvStateR  = 0.001;
};

} // namespace WavesDSP
