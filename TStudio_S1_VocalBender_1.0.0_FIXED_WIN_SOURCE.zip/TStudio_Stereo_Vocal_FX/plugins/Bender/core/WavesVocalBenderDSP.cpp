// ============================================================================
// WavesVocalBenderDSP.cpp — Corrective revision of the submitted Vocal Bender C++ core
// Disassembled from:
//   - Vocal Bender.bundle/Contents/Linux64/XLMC:
//       * VocalBenderProcess        (0x46e0 .. 0x8890)
//       * DetectPitch<float>        (0xe300 .. 0xf7a8)
//       * extractPitchInfoFromFFT   (0x145b0 .. 0x14faf)
//       * TestDecimatedPitch<float> (0x14fb0 .. 0x156b1)
//       * CreateNewDelayInstance    (0x156c0 .. 0x16d4f)
// ============================================================================

#include "WavesVocalBenderDSP.h"
#include <cmath>
#include <cstring>

namespace WavesDSP {

static constexpr float  kPiF    = 3.14159274f; // 0x43208
static constexpr float  kTwoPiF = 6.28318548f; // [rbx + 0x4858]
static constexpr double kPiD    = 3.14159265358979323846;

WavesVocalBenderDSP::WavesVocalBenderDSP() {
    initPolyphaseSincTable();
    prepare(44100.0);
}

// ============================================================================
// Submitted ratio conversion, corrected below of 2^x from 0x6928..0x6967 & 0x6a6a..0x6ab8
// Constants from XLMC .rodata:
//   0x43038 = -0.22222209f (-2/9), 0x4303c = +0.22222209f (+2/9)
//   0x431f0 =  1.66670001f (5/3)
//   0x431d0 = +1.0f, 0x431d4 = -1.0f
// ============================================================================
float WavesVocalBenderDSP::wavesPadePow2(float xOctaves) {
    // Semitones are logarithmic: +12 st must be exactly x2, never x14.
    return std::exp2(std::isfinite(xOctaves) ? std::clamp(xOctaves, -2.0f, 2.0f) : 0.0f);
}

// ============================================================================
// Initialize 33-tap x 256-phase Blackman-Harris Windowed-Sinc Table
// Used at 0x6ba5..0x7287 (rbp + rax*4 + tap*0x400)
// ============================================================================
void WavesVocalBenderDSP::initPolyphaseSincTable() {
    constexpr int kTaps   = stPSOLA::kSincTaps;   // 33 taps (0..32)
    constexpr int kPhases = stPSOLA::kSincPhases; // 256 sub-sample phases
    m_sincTable.resize(kTaps * (kPhases + 2), 0.0f);

    const double halfTaps = 0.5 * static_cast<double>(kTaps - 1); // 16.0
    for (int p = 0; p <= kPhases + 1; ++p) {
        const double frac = static_cast<double>(p - 1) / static_cast<double>(kPhases);
        double weightSum = 0.0;
        double temp[kTaps];
        for (int t = 0; t < kTaps; ++t) {
            const double x = (static_cast<double>(t) - halfTaps) - frac;
            double sinc = 1.0;
            if (std::abs(x) > 1e-8) {
                sinc = std::sin(kPiD * x) / (kPiD * x);
            }
            const double wPhase = kPiD * (x + halfTaps) / static_cast<double>(kTaps - 1);
            const double win = 0.42 - 0.50 * std::cos(2.0 * wPhase) + 0.08 * std::cos(4.0 * wPhase);
            temp[t] = sinc * win;
            weightSum += temp[t];
        }
        const double norm = (std::abs(weightSum) > 1e-9) ? (1.0 / weightSum) : 1.0;
        for (int t = 0; t < kTaps; ++t) {
            m_sincTable[t * (kPhases + 2) + p] = static_cast<float>(temp[t] * norm);
        }
    }
}

static void makeBiquadLP(WavesDSP::BiquadDF2& f, double fc, double q, double fs) {
    const double w0 = 2.0 * kPiD * std::clamp(fc, 10.0, 0.45 * fs) / fs;
    const double alpha = std::sin(w0) / (2.0 * q);
    const double cosW  = std::cos(w0);
    const double a0    = 1.0 + alpha;
    f.b0 = ((1.0 - cosW) * 0.5) / a0;
    f.b1 = (1.0 - cosW) / a0;
    f.b2 = f.b0;
    f.a1 = (-2.0 * cosW) / a0;
    f.a2 = (1.0 - alpha) / a0;
}

static void makeBiquadBP(WavesDSP::BiquadDF2& f, double fc, double q, double fs) {
    const double w0 = 2.0 * kPiD * std::clamp(fc, 20.0, 0.45 * fs) / fs;
    const double alpha = std::sin(w0) / (2.0 * q);
    const double cosW  = std::cos(w0);
    const double a0    = 1.0 + alpha;
    f.b0 = alpha / a0;
    f.b1 = 0.0;
    f.b2 = -alpha / a0;
    f.a1 = (-2.0 * cosW) / a0;
    f.a2 = (1.0 - alpha) / a0;
}

static void makePreDeEmphasis(WavesDSP::BiquadDF2& pre, WavesDSP::BiquadDF2& post, double fs) {
    const double w0 = 2.0 * kPiD * std::min(3500.0, 0.4 * fs) / fs;
    const double p  = std::exp(-w0);
    pre.b0 = 1.0; pre.b1 = -0.35 * p; pre.b2 = 0.0;
    pre.a1 = -0.15 * p; pre.a2 = 0.0;

    post.b0 = 1.0; post.b1 = -0.15 * p; post.b2 = 0.0;
    post.a1 = -0.35 * p; post.a2 = 0.0;
}

void WavesVocalBenderDSP::initBiquadFilters() {
    makePreDeEmphasis(m_preEmphasisFilter, m_postDeEmphasisFilter, m_sampleRate);
    makePreDeEmphasis(m_preEmphasisFilterR, m_postDeEmphasisFilterR, m_sampleRate);
    makeBiquadBP(m_dpllBandpassFilter, 220.0, 0.707, m_sampleRate); // 0x59dc..0x5a69
    makeBiquadBP(m_envDetectFilter1,   300.0, 0.707, m_sampleRate); // 0x5a83..0x5b00
    makeBiquadLP(m_envDetectFilter2,  1200.0, 0.707, m_sampleRate); // 0x5b05..0x5b77
    makeBiquadLP(m_pitchLowpassFilter, 900.0, 0.707, m_sampleRate); // 0x5c37..0x5cba
    makeBiquadLP(m_periodSmoothFilter,  40.0, 0.707, m_sampleRate); // 0x5d99..0x5e1c
}

void WavesVocalBenderDSP::prepare(double sampleRate) {
    m_sampleRate = (std::isfinite(sampleRate) && sampleRate >= 8000.0 && sampleRate <= 384000.0) ? sampleRate : 44100.0;
    m_oversampleScale = static_cast<float>(m_sampleRate / 44100.0);
    m_invOversample   = 1.0f / m_oversampleScale;

    const int bufSize = (m_sampleRate > 96000.0) ? 32768 : 16384;
    m_psola.bufferSize = bufSize;
    m_psola.bufferMask = bufSize - 1;

    m_audioBuffer.assign(bufSize, 0.0f);
    m_audioBufferR.assign(bufSize, 0.0f);
    m_dpllSearchBuffer.assign(bufSize, 0.0f);

    int pitchBufSize = 8192;
    while (pitchBufSize < int(m_sampleRate * .04)) pitchBufSize *= 2;
    m_pitchBufMask = pitchBufSize - 1;
    m_pitchRawBuffer.assign(pitchBufSize, 0.0f);
    m_pitchLpBuffer.assign(pitchBufSize, 0.0f);

    m_analysisHopSize = std::max(32, static_cast<int>(64.0 * m_oversampleScale));

    initBiquadFilters();
    reset();
}

void WavesVocalBenderDSP::reset() {
    std::fill(m_audioBuffer.begin(), m_audioBuffer.end(), 0.0f);
    std::fill(m_audioBufferR.begin(), m_audioBufferR.end(), 0.0f);
    std::fill(m_dpllSearchBuffer.begin(), m_dpllSearchBuffer.end(), 0.0f);
    std::fill(m_pitchRawBuffer.begin(), m_pitchRawBuffer.end(), 0.0f);
    std::fill(m_pitchLpBuffer.begin(), m_pitchLpBuffer.end(), 0.0f);

    m_preEmphasisFilter.reset();
    m_preEmphasisFilterR.reset();
    m_dpllBandpassFilter.reset();
    m_envDetectFilter1.reset();
    m_envDetectFilter2.reset();
    m_pitchLowpassFilter.reset();
    m_periodSmoothFilter.reset();
    m_postDeEmphasisFilter.reset();
    m_postDeEmphasisFilterR.reset();

    m_psola.writePos         = 0;
    m_psola.analysisWritePos = 0;
    m_psola.dpllAnchorPos    = 0;
    m_psola.currentGrainIdx  = 0;
    m_psola.prevGrainIdx     = 0;
    m_psola.grainCountdown   = 0.0f;
    m_psola.unvoicedCounter  = 0;
    m_psola.peakPolarity     = 1;
    m_psola.initialDelay.fill(0.0f);
    m_psola.delaySamples.fill(0.0f);
    m_psola.windowPhase.fill(0.0f);
    m_psola.windowStep.fill(0.0f);
    m_psola.delayStep.fill(0.0f);
    m_psola.activeState.fill(0);

    m_outEnvState  = 0.001;
    m_inEnvState   = 0.001;
    m_outEnvStateR = 0.001;
    m_inEnvStateR  = 0.001;
    m_detectedPeriod = 100.0f * m_oversampleScale;
    m_smoothedPeriod = m_detectedPeriod;
    m_isVoiced       = false;
    m_pitchBufIdx    = 0;
    m_analysisHopCounter = 0;
    m_lfoPhase       = 0.0f;
    m_smoothedPitchBase=m_smoothedFormantBase=1.0;
    m_dpll={};m_effectBlend=0;
    m_dcX=m_dcY=m_dcXR=m_dcYR=0;
    m_dcPole=float(std::exp(-2*kPiD*15.0/m_sampleRate));
    m_blendAlpha=float(1.0-std::exp(-1.0/(.010*m_sampleRate)));
    m_analysisEnergyL=m_analysisEnergyR=0;m_analyseRight=false;
}

void WavesVocalBenderDSP::setParameters(const VocalBenderParameters& params) {
    m_params = params;
    auto bound=[](float x,float lo,float hi,float def){return std::isfinite(x)?std::clamp(x,lo,hi):def;};
    m_params.pitchSemitones=bound(params.pitchSemitones,-12,12,0);
    m_params.formantSemitones=bound(params.formantSemitones,-12,12,0);
    m_params.fineTuneCents=bound(params.fineTuneCents,-100,100,0);
    m_params.mix=bound(params.mix,0,1,1);
    m_params.flattenNoteMidi=bound(params.flattenNoteMidi,36,84,60);
    m_params.lfoRateHz=bound(params.lfoRateHz,.05f,20,5);
    m_params.lfoToPitchSt=bound(params.lfoToPitchSt,-12,12,0);
    m_params.lfoToFormantSt=bound(params.lfoToFormantSt,-12,12,0);
    m_params.envToPitchSt=bound(params.envToPitchSt,-12,12,0);
    m_params.envToFormantSt=bound(params.envToFormantSt,-12,12,0);
}

// ============================================================================
// Submitted implementation of nsPitchModuleVoices_Process::TestDecimatedPitch<float>
// (0x14fb0 .. 0x156b1 in Vocal Bender.bundle/Contents/Linux64/XLMC)
// ============================================================================
bool WavesVocalBenderDSP::testDecimatedPitch(float candidatePeriod,
                                             float maxAllowedError,
                                             int writeIdx,
                                             int decimation,
                                             float& outRefinedPeriod) const {
    const float minP = 18.0f * m_oversampleScale;
    const float maxP = 800.0f * m_oversampleScale;
    if (candidatePeriod < minP || candidatePeriod > maxP) {
        return false;
    }

    const int T0 = static_cast<int>(std::floor(candidatePeriod + 0.5f));
    const int numTerms = std::max(6, (2 * T0) / std::max(1, decimation));

    double sumYY   = 0.0;
    double sumX1X1 = 0.0;
    double sumX2X2 = 0.0;
    double sumX1Y  = 0.0;
    double sumX2Y  = 0.0;
    double sumX1X2 = 0.0;

    for (int k = 0; k < numTerms; ++k) {
        const int idx0 = (writeIdx - k * decimation) & m_pitchBufMask;
        const int idxD = (idx0 - T0) & m_pitchBufMask;
        const int idxP = (idxD + 1)  & m_pitchBufMask;
        const int idxM = (idxD - 1)  & m_pitchBufMask;

        const double y  = static_cast<double>(m_pitchLpBuffer[idx0]);
        const double x1 = static_cast<double>(m_pitchLpBuffer[idxD]);
        const double x2 = 0.5 * static_cast<double>(m_pitchLpBuffer[idxP] - m_pitchLpBuffer[idxM]);

        sumYY   += y  * y;
        sumX1X1 += x1 * x1;
        sumX2X2 += x2 * x2;
        sumX1Y  += x1 * y;
        sumX2Y  += x2 * y;
        sumX1X2 += x1 * x2;
    }

    sumX1X1 += 1.0e-12;
    sumX2X2 += 1.0e-12;
    sumYY   += 1.0e-12;

    const double det = sumX1X1 * sumX2X2 - sumX1X2 * sumX1X2;
    if (std::abs(det) < 1.0e-12) {
        return false;
    }

    const double a = (sumX1Y * sumX2X2 - sumX2Y * sumX1X2) / det;
    const double b = (sumX1X1 * sumX2Y - sumX1X2 * sumX1Y) / det;

    if (a < 0.4381911f || a > 2.28f) {
        return false;
    }

    const double delta = std::clamp(b / a, -2.0, 2.0);
    const float refinedP = static_cast<float>(T0) - static_cast<float>(delta);

    const double predictedEnergy = a * sumX1Y + b * sumX2Y;
    const double relError = std::max(0.0, 1.0 - (predictedEnergy / sumYY));

    if (relError > static_cast<double>(maxAllowedError)) {
        return false;
    }

    outRefinedPeriod = std::clamp(refinedP, minP, maxP);
    return true;
}

// ============================================================================
// Submitted implementation of DetectPitch<float> (0xe300..0xf7a8) + extractPitchInfoFromFFT (0x145b0)
// ============================================================================
bool WavesVocalBenderDSP::detectPitchStep(float cleanInSample, float lpPitchSample) {
    m_pitchBufIdx = (m_pitchBufIdx + 1) & m_pitchBufMask;
    m_pitchRawBuffer[m_pitchBufIdx] = cleanInSample;
    m_pitchLpBuffer[m_pitchBufIdx]  = lpPitchSample;

    if (++m_analysisHopCounter < m_analysisHopSize) {
        return false;
    }
    m_analysisHopCounter = 0;

    const int winLen = static_cast<int>(512.0f * m_oversampleScale);
    double sumSq = 0.0;
    for (int i = 0; i < winLen; ++i) {
        const float s = m_pitchLpBuffer[(m_pitchBufIdx - i) & m_pitchBufMask];
        sumSq += s * s;
    }
    const double rms = std::sqrt(sumSq / std::max(1, winLen));
    if (rms < 1.0e-4) {
        m_isVoiced = false;
        return true;
    }

    float refinedPeriod = m_detectedPeriod;
    const int decimation = std::max(2, static_cast<int>(4.0f * m_oversampleScale));

    const int minLag = std::max(18, static_cast<int>(m_sampleRate / 1000.0));
    const int maxLag = std::min((m_pitchBufMask+1)/2, static_cast<int>(m_sampleRate / 65.0));

    float bestCorr = -1.0f;
    int   bestLag  = static_cast<int>(m_detectedPeriod);

    for (int lag = minLag; lag <= maxLag; lag += 2) {
        double corr = 0.0, e1 = 1e-12, e2 = 1e-12;
        for (int k = 0; k < winLen; k += decimation) {
            const float s0 = m_pitchLpBuffer[(m_pitchBufIdx - k) & m_pitchBufMask];
            const float s1 = m_pitchLpBuffer[(m_pitchBufIdx - k - lag) & m_pitchBufMask];
            corr += s0 * s1;
            e1   += s0 * s0;
            e2   += s1 * s1;
        }
        const float normCorr = static_cast<float>(corr / std::sqrt(e1 * e2));
        const float weighted = normCorr - 0.00015f * static_cast<float>(lag);
        if (weighted > bestCorr) {
            bestCorr = weighted;
            bestLag  = lag;
        }
    }

    auto evalLagCorr = [&](int lag) -> float {
        double corr = 0.0, e1 = 1e-12, e2 = 1e-12;
        for (int k = 0; k < winLen; k += decimation) {
            const float s0 = m_pitchLpBuffer[(m_pitchBufIdx - k) & m_pitchBufMask];
            const float s1 = m_pitchLpBuffer[(m_pitchBufIdx - k - lag) & m_pitchBufMask];
            corr += s0 * s1;
            e1   += s0 * s0;
            e2   += s1 * s1;
        }
        return static_cast<float>(corr / std::sqrt(e1 * e2));
    };

    const float cM = evalLagCorr(std::max(minLag, bestLag - 1));
    const float c0 = evalLagCorr(bestLag);
    const float cP = evalLagCorr(std::min(maxLag, bestLag + 1));
    if (cM > c0 && cM >= cP) bestLag = std::max(minLag, bestLag - 1);
    else if (cP > c0 && cP > cM) bestLag = std::min(maxLag, bestLag + 1);

    const float y1 = evalLagCorr(std::max(minLag, bestLag - 1));
    const float y2 = evalLagCorr(bestLag);
    const float y3 = evalLagCorr(std::min(maxLag, bestLag + 1));
    const float denom = 2.0f * (y1 - 2.0f * y2 + y3);
    float parabolicOffset = 0.0f;
    if (std::fabs(denom) > 1e-6f) {
        parabolicOffset = std::clamp((y1 - y3) / denom, -0.5f, 0.5f);
    }
    const float candidate = static_cast<float>(bestLag) + parabolicOffset;

    if (y2 > 0.55f && testDecimatedPitch(candidate, 0.45f, m_pitchBufIdx, decimation, refinedPeriod)) {
        m_detectedPeriod = refinedPeriod;
        m_isVoiced       = true;
    } else if (y2 > 0.65f) {
        m_detectedPeriod = candidate;
        m_isVoiced       = true;
    } else {
        m_isVoiced = false;
    }
    return true;
}

// ============================================================================
// Submitted implementation of nsPitchModuleVoices_Process::CreateNewDelayInstance<float>
// (0x156c0 .. 0x16d4f in Vocal Bender.bundle/Contents/Linux64/XLMC)
// ============================================================================
void WavesVocalBenderDSP::createNewDelayInstance(float pitchRatio,
                                                 float formantRatio,
                                                 float periodSamples,
                                                 float /*dpllSearchWidth*/) {
    const int prevSlot = m_psola.currentGrainIdx;
    const int nextSlot = (prevSlot + 1) & (stPSOLA::kNumGrains - 1);
    m_psola.prevGrainIdx    = prevSlot;
    m_psola.currentGrainIdx = nextSlot;

    const float T0 = std::clamp(periodSamples, 18.0f * m_oversampleScale, 1024.0f * m_oversampleScale);
    const float safePitchRatio = std::clamp(pitchRatio, 0.25f, 4.0f);
    const float targetPeriod   = T0 / safePitchRatio;
    m_psola.grainCountdown     += targetPeriod; // retain fractional scheduling remainder

    const int searchLen = std::clamp(static_cast<int>(1.2f * T0), 8, m_psola.bufferSize / 2);
    int   maxOffset = 0;
    int   minOffset = 0;
    float maxVal    = -1.0e30f;
    float minVal    = +1.0e30f;

    for (int d = 2; d < searchLen; ++d) {
        const int idx = (m_psola.dpllAnchorPos - d) & m_psola.bufferMask;
        const float v = m_dpllSearchBuffer[idx];
        if (v > maxVal) {
            maxVal    = v;
            maxOffset = d;
        }
        if (v < minVal) {
            minVal    = v;
            minOffset = d;
        }
    }

    const int chosenPeakOffset = maxOffset; // stable positive polarity; do not alternate half-period anchors
    m_psola.peakPolarity = 1;

    // Each grain is centred on the same polarity pitch mark. Two synthesis
    // periods use a Hann window. Source positions stay causal.
    // Down-shift windows retain their taper; normalizing sparse windows to unity
    // would erase the subharmonic and accidentally leave the original pitch.
    const float safeFormantRatio = std::clamp(formantRatio, 0.5f, 2.0f);
    const float duration = 2.0f * T0 / safeFormantRatio;
    float newDelay = float(chosenPeakOffset) + T0 + 33.0f;
    const float grainWinStep = kTwoPiF / duration;
    const float delayStep = 1.0f - safeFormantRatio;
    m_psola.baseWindowStep = grainWinStep;
    m_psola.initialWindowPhase = -kPiF;

    m_psola.initialDelay[nextSlot] = newDelay;
    m_psola.delaySamples[nextSlot] = newDelay;
    m_psola.windowPhase[nextSlot]  = m_psola.initialWindowPhase;
    m_psola.windowStep[nextSlot]   = grainWinStep;
    m_psola.delayStep[nextSlot]    = delayStep;
    m_psola.activeState[nextSlot]  = 1;
}

// ============================================================================
// Submitted implementation of 33-Tap Polyphase Windowed-Sinc Fractional Delay (0x6ba5..0x7287)
// ============================================================================
static inline float readPolyphaseSincStatic(const std::vector<float>& audioBuf,
                                            const std::vector<float>& sincTable,
                                            int bufMask,
                                            int baseIdx,
                                            float delaySamples) {
    const float ceilDelay = std::ceil(delaySamples);
    const int   intDelay  = static_cast<int>(ceilDelay);
    const int   startIdx  = (baseIdx - intDelay) & bufMask;

    const float frac      = ceilDelay - delaySamples;
    const float phasePos  = frac * 256.0f + 1.0f;
    int         phaseIdx  = static_cast<int>(phasePos);
    const float phaseFrac = phasePos - std::floor(phasePos);
    if (phaseIdx < 1)   phaseIdx = 1;
    if (phaseIdx > 256) phaseIdx = 256;

    constexpr int kTaps   = stPSOLA::kSincTaps;
    constexpr int kStride = stPSOLA::kSincPhases + 2;

    float sum = 0.0f;
    for (int tap = 0; tap < kTaps; ++tap) {
        const int tableBase = tap * kStride + phaseIdx;
        const float c0 = sincTable[tableBase];
        const float c1 = sincTable[tableBase + 1];
        const float coef = c0 + (c1 - c0) * phaseFrac;

        const int sampleIdx = (startIdx + tap) & bufMask;
        sum += coef * audioBuf[sampleIdx];
    }
    return sum;
}

float WavesVocalBenderDSP::readPolyphaseSinc(int baseIdx, float delaySamples) const {
    return readPolyphaseSincStatic(m_audioBuffer, m_sincTable, m_psola.bufferMask, baseIdx, delaySamples);
}

// ============================================================================
// Revised Per-Sample Synthesis Loop of VocalBenderProcess (0x46e0 .. 0x8890)
// ============================================================================
void WavesVocalBenderDSP::processBlockMono(const float* in, float* out, int numSamples) {
    if (!in || !out || numSamples <= 0) return;
    for (int i = 0; i < numSamples; ++i) {
        const float drySample = std::isfinite(in[i]) ? std::clamp(in[i], -64.0f, 64.0f) : 0.0f;

        const int writeIdx = (m_psola.writePos + 1) & m_psola.bufferMask;
        m_psola.writePos      = writeIdx;
        m_psola.dpllAnchorPos = writeIdx;

        const float preEmphSample = m_preEmphasisFilter.process(drySample);
        m_audioBuffer[writeIdx] = preEmphSample;
        m_dpllSearchBuffer[writeIdx] = m_dpllBandpassFilter.process(drySample);

        const float envBp = m_envDetectFilter2.process(m_envDetectFilter1.process(drySample));
        const double absEnv = std::fabs(static_cast<double>(envBp));
        const double envAlpha = (absEnv > m_inputLevelEnv) ? 0.990 : 0.9995;
        m_inputLevelEnv = absEnv + envAlpha * (m_inputLevelEnv - absEnv);
        m_modEnvValue   = static_cast<float>(std::min(1.0, m_inputLevelEnv * 4.0));

        const float lpPitchSample = m_pitchLowpassFilter.process(drySample);
        detectPitchStep(drySample, lpPitchSample);

        m_smoothedPeriod = m_periodSmoothFilter.process(m_detectedPeriod);
        const float activePeriod = std::clamp(m_smoothedPeriod,
                                              18.0f * m_oversampleScale,
                                              1024.0f * m_oversampleScale);

        m_lfoPhase += static_cast<float>(m_params.lfoRateHz / m_sampleRate);
        if (m_lfoPhase >= 1.0f) m_lfoPhase -= 1.0f;
        const float lfoVal = std::sin(kTwoPiF * m_lfoPhase);

        double basePitchRatio = 1.0;
        if (m_params.flattenEnabled && m_isVoiced && activePeriod > 1.0f) {
            const double targetFreq = 440.0 * std::pow(2.0, (m_params.flattenNoteMidi - 69.0) / 12.0);
            const double inputFreq  = m_sampleRate / static_cast<double>(activePeriod);
            basePitchRatio = std::clamp(targetFreq / std::max(20.0, inputFreq), 0.25, 4.0);
        }
        m_smoothedPitchBase += 0.05 * (basePitchRatio - m_smoothedPitchBase);

        const float totalPitchSt = m_params.pitchSemitones +
                                   0.01f * m_params.fineTuneCents +
                                   m_params.lfoToPitchSt * lfoVal +
                                   m_params.envToPitchSt * m_modEnvValue;
        const float pitchRatio = std::clamp(
            static_cast<float>(m_smoothedPitchBase) * wavesPadePow2(totalPitchSt / 12.0f),
            0.015625f, 64.0f
        );
        m_psola.currentPitchRatio = pitchRatio;

        const float baseFormantSt = m_params.formantLink ? m_params.pitchSemitones : m_params.formantSemitones;
        const float totalFormantSt = baseFormantSt +
                                     m_params.lfoToFormantSt * lfoVal +
                                     m_params.envToFormantSt * m_modEnvValue;
        const float formantRatio = std::clamp(
            wavesPadePow2(totalFormantSt / 12.0f),
            0.5f, 2.0f
        );
        m_psola.currentFormantRatio = formantRatio;

        const int baseSincIdx = (writeIdx - 16) & m_psola.bufferMask;
        float grainSampleSum = 0.0f;
        float grainWindowSum = 0.0f;

        for (int g = 0; g < stPSOLA::kNumGrains; ++g) {
            const int state = m_psola.activeState[g];
            if (state <= 0) continue;
            if (state != 1) {
                m_psola.activeState[g] = state - 1;
                continue;
            }

            const float dSamples = m_psola.delaySamples[g];
            const float gSample  = readPolyphaseSincStatic(
                m_audioBuffer, m_sincTable, m_psola.bufferMask, baseSincIdx, dSamples);

            const float phi = m_psola.windowPhase[g];
            const float win = 0.5f * std::cos(phi) + 0.5f;

            grainSampleSum += gSample * win;
            grainWindowSum += win;

            const float nextDelay = dSamples + m_psola.delayStep[g];
            const float nextPhase = phi      + m_psola.windowStep[g];
            m_psola.delaySamples[g] = nextDelay;
            m_psola.windowPhase[g]  = nextPhase;

            if (nextPhase >= kPiF) {
                m_psola.activeState[g] = 0;
            }
            if (nextDelay < 1.0f) {
                m_psola.delayStep[g] = 0.0f;
            }
        }

        m_psola.grainCountdown += -1.0f;
        if (m_psola.grainCountdown <= 0.0f) {
            createNewDelayInstance(pitchRatio, formantRatio, activePeriod, 1.0f);
        }

        const float normWinSum = std::max(grainWindowSum, 1.0f);
        float psolaOut = grainSampleSum / normWinSum;

        const float rawWet = m_postDeEmphasisFilter.process(psolaOut);
        const float wetSample = rawWet - m_dcX + m_dcPole * m_dcY;
        m_dcX=rawWet; m_dcY=wetSample;
        const float mix = std::clamp(m_params.mix, 0.0f, 1.0f);
        const float neutral = (std::fabs(totalPitchSt)<1e-6f && std::fabs(totalFormantSt)<1e-6f && !m_params.flattenEnabled) ? 0.0f : 1.0f;
        m_effectBlend += m_blendAlpha*(neutral-m_effectBlend);
        out[i] = drySample + (mix*m_effectBlend) * (wetSample - drySample);
    }
}

void WavesVocalBenderDSP::processBlockStereo(const float* inL, const float* inR,
                                             float* outL, float* outR, int numSamples) {
    if (!inL || !inR || !outL || !outR || numSamples <= 0) return;
    for (int i = 0; i < numSamples; ++i) {
        const float dryL = std::isfinite(inL[i]) ? std::clamp(inL[i], -64.0f, 64.0f) : 0.0f;
        const float dryR = std::isfinite(inR[i]) ? std::clamp(inR[i], -64.0f, 64.0f) : 0.0f;
        m_analysisEnergyL += .001f*(dryL*dryL-m_analysisEnergyL);
        m_analysisEnergyR += .001f*(dryR*dryR-m_analysisEnergyR);
        if(m_analysisEnergyR > 2*m_analysisEnergyL+1e-10f)m_analyseRight=true;
        if(m_analysisEnergyL > 2*m_analysisEnergyR+1e-10f)m_analyseRight=false;
        const float midSample = m_analyseRight ? dryR : dryL; // no anti-phase cancellation

        const int writeIdx = (m_psola.writePos + 1) & m_psola.bufferMask;
        m_psola.writePos      = writeIdx;
        m_psola.dpllAnchorPos = writeIdx;

        m_audioBuffer[writeIdx]  = m_preEmphasisFilter.process(dryL);
        m_audioBufferR[writeIdx] = m_preEmphasisFilterR.process(dryR);
        m_dpllSearchBuffer[writeIdx] = m_dpllBandpassFilter.process(midSample);

        const float envBp = m_envDetectFilter2.process(m_envDetectFilter1.process(midSample));
        const double absEnv = std::fabs(static_cast<double>(envBp));
        const double envAlpha = (absEnv > m_inputLevelEnv) ? 0.990 : 0.9995;
        m_inputLevelEnv = absEnv + envAlpha * (m_inputLevelEnv - absEnv);
        m_modEnvValue   = static_cast<float>(std::min(1.0, m_inputLevelEnv * 4.0));

        const float lpPitchSample = m_pitchLowpassFilter.process(midSample);
        detectPitchStep(midSample, lpPitchSample);

        m_smoothedPeriod = m_periodSmoothFilter.process(m_detectedPeriod);
        const float activePeriod = std::clamp(m_smoothedPeriod,
                                              18.0f * m_oversampleScale,
                                              1024.0f * m_oversampleScale);

        m_lfoPhase += static_cast<float>(m_params.lfoRateHz / m_sampleRate);
        if (m_lfoPhase >= 1.0f) m_lfoPhase -= 1.0f;
        const float lfoVal = std::sin(kTwoPiF * m_lfoPhase);

        double basePitchRatio = 1.0;
        if (m_params.flattenEnabled && m_isVoiced && activePeriod > 1.0f) {
            const double targetFreq = 440.0 * std::pow(2.0, (m_params.flattenNoteMidi - 69.0) / 12.0);
            const double inputFreq  = m_sampleRate / static_cast<double>(activePeriod);
            basePitchRatio = std::clamp(targetFreq / std::max(20.0, inputFreq), 0.25, 4.0);
        }
        m_smoothedPitchBase += 0.05 * (basePitchRatio - m_smoothedPitchBase);

        const float totalPitchSt = m_params.pitchSemitones +
                                   0.01f * m_params.fineTuneCents +
                                   m_params.lfoToPitchSt * lfoVal +
                                   m_params.envToPitchSt * m_modEnvValue;
        const float pitchRatio = std::clamp(
            static_cast<float>(m_smoothedPitchBase) * wavesPadePow2(totalPitchSt / 12.0f),
            0.015625f, 64.0f);
        m_psola.currentPitchRatio = pitchRatio;

        const float baseFormantSt = m_params.formantLink ? m_params.pitchSemitones : m_params.formantSemitones;
        const float totalFormantSt = baseFormantSt +
                                     m_params.lfoToFormantSt * lfoVal +
                                     m_params.envToFormantSt * m_modEnvValue;
        const float formantRatio = std::clamp(wavesPadePow2(totalFormantSt / 12.0f), 0.5f, 2.0f);
        m_psola.currentFormantRatio = formantRatio;

        const int baseSincIdx = (writeIdx - 16) & m_psola.bufferMask;
        float sumL = 0.0f, sumR = 0.0f, winSum = 0.0f;

        for (int g = 0; g < stPSOLA::kNumGrains; ++g) {
            const int state = m_psola.activeState[g];
            if (state <= 0) continue;
            if (state != 1) {
                m_psola.activeState[g] = state - 1;
                continue;
            }

            const float dSamples = m_psola.delaySamples[g];
            const float gL = readPolyphaseSincStatic(
                m_audioBuffer,  m_sincTable, m_psola.bufferMask, baseSincIdx, dSamples);
            const float gR = readPolyphaseSincStatic(
                m_audioBufferR, m_sincTable, m_psola.bufferMask, baseSincIdx, dSamples);

            const float phi = m_psola.windowPhase[g];
            const float win = 0.5f * std::cos(phi) + 0.5f;

            sumL   += gL * win;
            sumR   += gR * win;
            winSum += win;

            const float nextDelay = dSamples + m_psola.delayStep[g];
            const float nextPhase = phi      + m_psola.windowStep[g];
            m_psola.delaySamples[g] = nextDelay;
            m_psola.windowPhase[g]  = nextPhase;

            if (nextPhase >= kPiF) m_psola.activeState[g] = 0;
            if (nextDelay < 1.0f)  m_psola.delayStep[g]   = 0.0f;
        }

        m_psola.grainCountdown += -1.0f;
        if (m_psola.grainCountdown <= 0.0f) {
            createNewDelayInstance(pitchRatio, formantRatio, activePeriod, 1.0f);
        }

        const float normWinSum = std::max(winSum, 1.0f);
        float psolaL = sumL / normWinSum;
        float psolaR = sumR / normWinSum;

        const float rawL = m_postDeEmphasisFilter.process(psolaL), rawR = m_postDeEmphasisFilterR.process(psolaR);
        const float wetL = rawL - m_dcX + m_dcPole*m_dcY;
        const float wetR = rawR - m_dcXR + m_dcPole*m_dcYR;
        m_dcX=rawL;m_dcY=wetL;m_dcXR=rawR;m_dcYR=wetR;
        const float mix  = std::clamp(m_params.mix, 0.0f, 1.0f);

        const float neutral = (std::fabs(totalPitchSt)<1e-6f && std::fabs(totalFormantSt)<1e-6f && !m_params.flattenEnabled) ? 0.0f : 1.0f;
        m_effectBlend += m_blendAlpha*(neutral-m_effectBlend);
        outL[i] = dryL + (mix*m_effectBlend) * (wetL - dryL);
        outR[i] = dryR + (mix*m_effectBlend) * (wetR - dryR);
    }
}

} // namespace WavesDSP
