# Third-party notices

The submitted DSP implementation and original reference data originate from the user upload, retained at Reference/ORIGINAL_UPLOAD.zip. Statements of binary equivalence in that archive have not been established by this revision.

JUCE 8.0.12 is vendored at third_party/JUCE. Its original licence and third-party notices remain intact; see third_party/JUCE/LICENSE.md and the notices in its modules. JUCE is offered under its original commercial/GPL terms. Bundled Steinberg VST3 SDK notices remain under JUCE/modules/juce_audio_processors_headless/format_types/VST3_SDK.

The new native T Studio UI does not embed the submitted manufacturer logos or skin images. No third-party plugin executable, activation secret or private signing key is added to the build.
