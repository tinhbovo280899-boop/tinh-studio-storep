@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\windows.ps1" -Action InitKeys
set "TAK_RC=%errorlevel%"
if not "%TAK_RC%"=="0" echo FAILED. See build_logs for details.
pause
exit /b %TAK_RC%
