# T-Verb — thêm lựa chọn mềm nhẹ cho FX Send

Giữ nguyên engine, default và 20 preset trước đó. Thêm cuối danh sách:

**Vocal Mềm Nhẹ - Giữ Đuôi - FX Send**

Giữ Type Smooth, Decay 3,506 s, Room 40 m, Width 160°, Attack 7%, Spread 10%, Density 80%, Modulation 10%. Đổi Predelay 70→35 ms, Diffusion 70→80%, Hi Cut 9819→9000 Hz, Hi Ratio 0,60→0,58. Dry -∞, Wet +0,84 dB như bản mặc định; chỉnh lượng vang bằng Send/Return.

Phép đo xung trước đó cho thấy Diffusion 80% giảm đỉnh phản xạ khoảng 3,52 dB và giữ gần nguyên thời gian suy giảm; đây không phải xác nhận preset nghe mềm hơn trên mọi vocal. Không thêm saturator/limiter hoặc thay topology để ép màu.

Các build helper/license/installer cũ được giữ. CMake bổ sung ưu tiên JUCE_DIR khi chủ động dùng JUCE đã cài. Cách build theo README gốc và menu đi kèm.

## Phạm vi xác minh

ZIP là mã nguồn dành cho Windows/macOS, chưa phải plugin hoặc bộ cài Windows/macOS đã biên dịch. Kiểm thử native hiện thực hiện trên Linux; xem TEST_RESULTS_BATCH sau khi đóng gói. Chưa có bản vocal của anh để xác nhận cảm giác mềm/quyện. Không tuyên bố tương đương 1:1 thuật toán của hãng; các comment địa chỉ/nguồn tham khảo cũ không phải kết quả xác minh đó.

Giữ plugin ID, ID tham số và các preset cũ theo thứ tự ban đầu. Preset FX Send được thêm cuối danh sách; preset mới không tự áp lên project cũ. Sao lưu project/plugin trước khi thay bản để nghe A/B.
