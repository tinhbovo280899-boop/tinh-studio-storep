; Customer installer: only verified VST3 payload and documentation.
#include "generated\Config.iss"
#define ExportDir SourcePath + "\..\_EXPORT_WIN"
[Setup]
AppId={#MyAppId}
AppName={#MyName}
AppVersion={#MyVersion}
AppPublisher={#MyPublisher}
DefaultDirName={commonappdata}\{#MyPublisher}\{#MyName}
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes
RestartApplications=no
OutputDir=..\Output
OutputBaseFilename=Setup_{#MyName}_{#MyVersion}_Win64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#MyName} VST3
LicenseFile=..\LICENSE
[Files]
Source: "{#ExportDir}\VST3\{#MyBundle}\*"; DestDir: "{commoncf64}\VST3\{#MyBundle}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#ExportDir}\HUONG_DAN_KHACH.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ExportDir}\LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion
[Messages]
WelcomeLabel1=Chao mung den voi bo cai {#MyName}
WelcomeLabel2=Bo cai chep VST3 vao thu muc plugin he thong.%n%nHay dong Cubase va cac DAW truoc khi cap nhat.
FinishedLabel=Da cai {#MyName}. Mo DAW, quet lai VST3 neu can, bam BAN QUYEN trong plugin de kich hoat.
; License/trial files are outside the install tree and survive an uninstall.
