@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
if "%~1"=="" (
    echo Keo tep Auto-Tune.vst3, WAV hoac ZIP len bieu tuong file BAT nay.
    echo Hay giai nen cong cu ra thu muc truoc khi dung.
    pause
    exit /b 1
)
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0CHIA_FILE_GUI_EM.ps1" -SourcePath "%~f1" -OutputRoot "%~dp0."
set "TRANSFER_RC=%errorlevel%"
echo.
pause
exit /b %TRANSFER_RC%
