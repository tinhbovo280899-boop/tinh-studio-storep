﻿param(
    [Parameter(Mandatory=$true)][string]$SourcePath,
    [string]$OutputRoot=$PSScriptRoot,
    [ValidateRange(1,30)][int]$PartSizeMB=20
)
$ErrorActionPreference='Stop'
$temporaryArchive=$null
$inputStream=$null
$fullHasher=$null
try {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $source=Get-Item -LiteralPath $SourcePath
    $payloadName=$source.Name
    $payloadKind='file'
    $payloadPath=$source.FullName
    if ($source.PSIsContainer) {
        if (-not $source.Name.EndsWith('.vst3',[StringComparison]::OrdinalIgnoreCase)) {
            throw 'Chi keo tep hoac thu muc plugin .vst3 vao cong cu.'
        }
        $temporaryArchive=Join-Path ([IO.Path]::GetTempPath()) ('vst3-transfer-'+[Guid]::NewGuid().ToString('N')+'.zip')
        Write-Host 'Dang dong goi thu muc VST3...'
        [IO.Compression.ZipFile]::CreateFromDirectory($source.FullName,$temporaryArchive,[IO.Compression.CompressionLevel]::Optimal,$true)
        $payloadPath=$temporaryArchive
        $payloadName=$source.Name+'.zip'
        $payloadKind='vst3_bundle_zip'
    }
    $inputStream=[IO.File]::Open($payloadPath,[IO.FileMode]::Open,[IO.FileAccess]::Read,[IO.FileShare]::Read)
    if ($inputStream.Length -eq 0) { throw 'Tep rong, khong co du lieu de gui.' }
    $group=[Guid]::NewGuid().ToString('N').Substring(0,8)
    $safeName=[regex]::Replace($source.Name,'[^A-Za-z0-9._-]','_')
    if ($safeName.Length -gt 45) {$safeName=$safeName.Substring(0,45)}
    $outputDirectory=Join-Path $OutputRoot ('GUI_EM_'+$safeName+'_'+$group)
    [void][IO.Directory]::CreateDirectory($outputDirectory)
    $partLimit=[long]$PartSizeMB*1024*1024
    $buffer=New-Object byte[] (1024*1024)
    $parts=[Collections.Generic.List[object]]::new()
    $fullHasher=[Security.Cryptography.SHA256]::Create()
    $sourceLength=$inputStream.Length
    $partIndex=0
    while ($inputStream.Position -lt $sourceLength) {
        $partIndex++
        $offset=$inputStream.Position
        $partLength=[Math]::Min($partLimit,$sourceLength-$offset)
        $zipName=('GUI_EM_{0}_{1:D3}.zip' -f $group,$partIndex)
        $entryName=('payload.part{0:D3}' -f $partIndex)
        $zipPath=Join-Path $outputDirectory $zipName
        $zipStream=$null;$archive=$null;$entryStream=$null
        $partHasher=[Security.Cryptography.SHA256]::Create()
        try {
            $zipStream=[IO.File]::Open($zipPath,[IO.FileMode]::CreateNew,[IO.FileAccess]::Write,[IO.FileShare]::None)
            $archive=[IO.Compression.ZipArchive]::new($zipStream,[IO.Compression.ZipArchiveMode]::Create,$true)
            $entryStream=$archive.CreateEntry($entryName,[IO.Compression.CompressionLevel]::NoCompression).Open()
            $remaining=$partLength
            while ($remaining -gt 0) {
                $wanted=[int][Math]::Min([long]$buffer.Length,$remaining)
                $read=$inputStream.Read($buffer,0,$wanted)
                if ($read -le 0) { throw 'Tep thay doi hoac khong doc du du lieu.' }
                $entryStream.Write($buffer,0,$read)
                [void]$partHasher.TransformBlock($buffer,0,$read,$buffer,0)
                [void]$fullHasher.TransformBlock($buffer,0,$read,$buffer,0)
                $remaining-=$read
            }
            [void]$partHasher.TransformFinalBlock([byte[]]@(),0,0)
            $digest=[BitConverter]::ToString($partHasher.Hash).Replace('-','').ToLowerInvariant()
            $parts.Add([ordered]@{index=$partIndex;zip_name=$zipName;entry_name=$entryName;offset_bytes=$offset;size_bytes=$partLength;sha256=$digest})
        } finally {
            if ($null -ne $entryStream) {$entryStream.Dispose()}
            if ($null -ne $archive) {$archive.Dispose()}
            if ($null -ne $zipStream) {$zipStream.Dispose()}
            $partHasher.Dispose()
        }
        Write-Host ('Da tao '+$zipName)
    }
    [void]$fullHasher.TransformFinalBlock([byte[]]@(),0,0)
    $fullDigest=[BitConverter]::ToString($fullHasher.Hash).Replace('-','').ToLowerInvariant()
    $manifest=[ordered]@{version=1;group_id=$group;payload_name=$payloadName;payload_kind=$payloadKind;size_bytes=$sourceLength;sha256=$fullDigest;part_limit_bytes=$partLimit;parts=$parts.ToArray()}
    $manifestPath=Join-Path $outputDirectory ('GUI_EM_'+$group+'_manifest.json')
    [IO.File]::WriteAllText($manifestPath,($manifest|ConvertTo-Json -Depth 6),[Text.UTF8Encoding]::new($false))
    Write-Host ''
    Write-Host ('XONG: '+$outputDirectory)
    Write-Host ('Gui tat ca '+$partIndex+' tep ZIP va tep manifest.json trong thu muc nay.')
    Write-Host 'Tep goc duoc doc, khong thay doi; cong cu khong tu tai tep len mang.'
} catch {
    [Console]::Error.WriteLine('LOI: '+$_.Exception.Message)
    exit 1
} finally {
    if ($null -ne $inputStream) {$inputStream.Dispose()}
    if ($null -ne $fullHasher) {$fullHasher.Dispose()}
    if ($null -ne $temporaryArchive -and [IO.File]::Exists($temporaryArchive)) {[IO.File]::Delete($temporaryArchive)}
}
