"""Reassemble the helper's parts and verify every byte. Python 3, no extra packages."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import zipfile


def leaf(value):
    if not isinstance(value, str) or not value or value in (".", "..") or "/" in value or "\\" in value:
        raise ValueError("Invalid file name in manifest")
    return value


def sha(value):
    if not isinstance(value, str) or not re.fullmatch("[0-9a-f]{64}", value):
        raise ValueError("Invalid SHA256 in manifest")
    return value


def join(manifest_path, output=None):
    manifest_path = Path(manifest_path)
    if manifest_path.stat().st_size > 1024 * 1024:
        raise ValueError("Manifest too large")
    meta = json.loads(manifest_path.read_text(encoding="utf-8-sig"))
    if meta.get("version") != 1:
        raise ValueError("Unsupported manifest version")
    name = leaf(meta["payload_name"])
    expected_hash = sha(meta["sha256"])
    expected_size = meta["size_bytes"]
    if not isinstance(expected_size, int) or not 0 < expected_size <= 4 * 1024**3:
        raise ValueError("Unsupported payload size")
    parts = meta["parts"]
    if not isinstance(parts, list) or not parts:
        raise ValueError("No parts")
    output = Path(output) if output else manifest_path.parent / "GHEP_LAI" / name
    output.parent.mkdir(parents=True, exist_ok=True)
    if output.exists():
        raise FileExistsError("Output already exists: " + str(output))
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(dir=output.parent, prefix=".ghep-", delete=False) as target:
            temp_name = target.name
            total = 0
            full_hash = hashlib.sha256()
            for index, part in enumerate(parts, 1):
                if part["index"] != index or part["offset_bytes"] != total:
                    raise ValueError("Part order or offset mismatch")
                length = part["size_bytes"]
                if not isinstance(length, int) or not 0 < length <= 30 * 1024**2 or total + length > expected_size:
                    raise ValueError("Invalid part size")
                part_hash = hashlib.sha256()
                with zipfile.ZipFile(manifest_path.parent / leaf(part["zip_name"])) as archive:
                    if len(archive.infolist()) != 1:
                        raise ValueError("Each part ZIP must contain one payload")
                    info = archive.getinfo(part["entry_name"])
                    if info.file_size != length:
                        raise ValueError("Part length mismatch")
                    count = 0
                    with archive.open(info) as source:
                        while chunk := source.read(min(1024**2, length - count + 1)):
                            count += len(chunk)
                            if count > length:
                                raise ValueError("Part exceeds declared length")
                            target.write(chunk)
                            part_hash.update(chunk)
                            full_hash.update(chunk)
                    if count != length or part_hash.hexdigest() != sha(part["sha256"]):
                        raise ValueError("Part integrity check failed")
                total += length
            if total != expected_size or full_hash.hexdigest() != expected_hash:
                raise ValueError("Full payload integrity check failed")
        # Atomically refuse an existing destination. The temporary file is on the same filesystem.
        os.link(temp_name, output)
        return output
    finally:
        if temp_name is not None:
            Path(temp_name).unlink(missing_ok=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("manifest")
    parser.add_argument("--output")
    args = parser.parse_args()
    print(join(args.manifest, args.output))
