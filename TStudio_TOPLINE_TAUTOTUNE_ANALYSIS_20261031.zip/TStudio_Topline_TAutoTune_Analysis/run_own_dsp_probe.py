"""Measure the submitted T-AutoTune channel DSP, without loading a vendor DLL.

The algorithm body is copied verbatim. Only a JUCE-free declaration/stub and
public access for observations are supplied by this standalone diagnostic.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path(sys.argv[1]) if len(sys.argv) > 1 else Path('/workspace/vst-license-autotune-review-20261030/working-fixed/T-Studio_VocalPack/AutoTune/Source')
OUT = ROOT / 'own_probe'
OUT.mkdir(exist_ok=True)
h = (SOURCE / 'TAutoTuneProcessor.h').read_text()
c = (SOURCE / 'TAutoTuneProcessor.cpp').read_text()
declaration = h[h.index('class TAutoTuneChannelDSP'):h.index('class TAutoTuneProcessor final')]
declaration = declaration.replace('private:', 'public:')
body = c[c.index('void TAutoTuneChannelDSP::prepare'):c.index('juce::StringArray TAutoTuneProcessor::getInputTypeNames')]
assert 'juce::' not in body
assert set(re.findall(r'TAutoTuneProcessor::(\w+)', body)) == {'kNoteRemoved', 'kNoteBypassed'}
constants = re.search(r'enum NoteState \{ ([^}]+) \};', h).group(1)
core = '''#include <array>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <random>
#include <string>
#include <vector>
static constexpr double kPi = 3.14159265358979323846;
class TAutoTuneProcessor { public: enum NoteState { ''' + constants + ''' }; };
'''
main = r'''
float tick(TAutoTuneChannelDSP& d, float x, double mix, int noteState=1,
           double retune=20., double transpose=0., bool formant=false) {
    std::array<int,12> states{}; states.fill(noteState);
    std::array<int,12> cents{};
    return d.processSample(x,1,0,2,states,cents,false,formant,100.,false,
       transpose,0.,50.,retune,0.,0.,0.,false,0,5.5,500.,500.,30.,0.,30.,70.,mix,-1);
}
int main(int argc,char** argv) {
    if(argc!=2) return 2;
    std::string out=argv[1];
    std::cout << std::setprecision(12);
    std::cout << "{\"latency\":[";
    bool first=true;
    for(double fs : {44100.,48000.,96000.,192000.}) {
        for(double mix : {0.,50.,100.}) {
            TAutoTuneChannelDSP d; d.prepare(fs);
            for(int i=0;i<int(fs*.5);i++) tick(d,0.f,mix);
            std::vector<float> y(int(fs*.08));
            int pulse=100;
            for(int i=0;i<int(y.size());i++) y[i]=tick(d,i==pulse?.1f:0.f,mix);
            int peak=0;
            for(int i=1;i<int(y.size());i++) if(std::abs(y[i])>std::abs(y[peak])) peak=i;
            if(!first) std::cout << ','; first=false;
            std::cout << "{\"sample_rate\":"<<fs<<",\"mix\":"<<mix
               <<",\"peak_lag_samples\":"<<(peak-pulse)
               <<",\"peak_lag_ms\":"<<1000.*(peak-pulse)/fs
               <<",\"wet_read_delay_samples\":"<<d.relDelayA<<'}';
        }
    }
    std::cout << "],\"level\":[";
    first=true;
    for(double db : {-40.,-24.,-12.,-6.}) {
        TAutoTuneChannelDSP d; d.prepare(48000.);
        double amp=std::pow(10.,db/20.), ei=0.,eo=0.;
        std::mt19937 rng(20261031); std::uniform_real_distribution<float> unif(-1.f,1.f);
        std::vector<float> x(96000),y(x.size());
        for(int n=0;n<int(x.size());n++) {
            x[n]=float(amp)*unif(rng); y[n]=tick(d,x[n],100.);
        }
        for(int n=24000;n<95000;n++) {ei+=double(x[n-264])*x[n-264]; eo+=double(y[n])*y[n];}
        if(!first) std::cout << ','; first=false;
        std::cout << "{\"input_peak_dbfs\":"<<db<<",\"output_to_input_db\":"<<10.*std::log10(eo/ei)<<'}';
    }
    std::cout << "],\"delay_tracks\":[";
    first=true;
    for(double hz : {110.,220.,440.}) {
        TAutoTuneChannelDSP d; d.prepare(48000.);
        double phase=0.,dmin=1e9,dmax=-1e9; int voiced=0;
        for(int n=0;n<96000;n++) {
            phase+=2*kPi*hz/48000.;
            float x=float(.10*std::sin(phase)+.03*std::sin(2*phase)+.01*std::sin(3*phase));
            tick(d,x,100.,0,20.,.25);
            if(n>=48000) {dmin=std::min(dmin,d.relDelayA);dmax=std::max(dmax,d.relDelayA);voiced+=d.voicedState;}
        }
        if(!first) std::cout << ','; first=false;
        std::cout << "{\"input_hz\":"<<hz<<",\"min_wet_read_delay_samples\":"<<dmin
            <<",\"max_wet_read_delay_samples\":"<<dmax<<",\"voiced_samples\":"<<voiced<<'}';
    }
    std::cout << "],\"retune_half_time\":[";
    first=true;
    for(double fs : {48000.,96000.,192000.}) {
        TAutoTuneChannelDSP d; d.prepare(fs);
        int warm=int(fs);
        auto tone=[fs](int n) {return float(.1*std::sin(2*kPi*220.*n/fs)+.03*std::sin(2*kPi*440.*n/fs));};
        for(int n=0;n<warm;n++) tick(d,tone(n),100.);
        double start=d.smoothedPitchRatio;
        int hit=-1;
        for(int n=0;n<int(fs*.5);n++) {
            tick(d,tone(n+warm),100.,1,20.,12.);
            if(d.smoothedPitchRatio>=start+(2.-start)*.5) {hit=n+1;break;}
        }
        if(!first) std::cout << ','; first=false;
        std::cout << "{\"sample_rate\":"<<fs<<",\"retune_parameter_ms\":20,\"half_time_samples\":"<<hit
            <<",\"half_time_ms\":"<<1000.*hit/fs<<",\"voiced\":"<<(d.voicedState?"true":"false")<<'}';
    }
    std::cout << "],\"mix_response\":[";
    first=true;
    for(double fs : {48000.,96000.}) {
        for(double mix : {50.,100.}) {
            for(double hz : {100.,187.5,300.,500.,1000.,1500.,3000.,6000.}) {
                TAutoTuneChannelDSP d; d.prepare(fs);
                for(int n=0;n<int(fs*.5);n++) tick(d,0.f,mix);
                double ei=0.,eo=0.;
                for(int n=0;n<int(fs*.4);n++) {
                    float x=float(.1*std::sin(2*kPi*hz*n/fs));
                    float y=tick(d,x,mix);
                    if(n>=int(fs*.2)) {ei+=double(x)*x; eo+=double(y)*y;}
                }
                if(!first) std::cout << ','; first=false;
                std::cout << "{\"sample_rate\":"<<fs<<",\"mix\":"<<mix
                    <<",\"frequency_hz\":"<<hz<<",\"gain_db\":"
                    <<std::max(-200.,10.*std::log10(std::max(1e-30,eo/ei)))<<'}';
            }
        }
    }
    std::cout << "]}\n";
}
'''
cpp = OUT / 'own_dsp_probe.cpp'
cpp.write_text(core + declaration + body + main)
exe = OUT / 'own_dsp_probe'
subprocess.run(['g++', '-std=c++17', '-O2', str(cpp), '-o', str(exe)], check=True)
result = subprocess.run([str(exe), str(OUT)], capture_output=True, text=True, check=True)
data = json.loads(result.stdout)
data['method'] = {
    'original_cpp_sha256': hashlib.sha256((SOURCE/'TAutoTuneProcessor.cpp').read_bytes()).hexdigest(),
    'original_header_sha256': hashlib.sha256((SOURCE/'TAutoTuneProcessor.h').read_bytes()).hexdigest(),
    'channel_algorithm_body_sha256': hashlib.sha256(body.encode()).hexdigest(),
    'scope': 'Standalone original channel DSP; not Cubase, native VST3, or Topline execution.',
    'neutral_setup': 'All notes bypassed, Formant off, synthetic vibrato off, transpose zero, 0.5 s warmup.',
    'level_setup': 'Neutral setup, 48 kHz, 100% wet, deterministic bounded noise; aligned to 264 samples.',
    'tracks_setup': 'All notes active chromatic, Formant off, +0.25 semitone transpose; synthetic harmonic tones.',
    'mix_setup': 'Neutral setup; 0.5 s silence warmup then 0.4 s sine, measure last 0.2 s; dB floor -200.',
    'retune_setup': '1 s harmonic 220 Hz warmup, all notes bypassed, Formant off; transpose jumps 0 to +12, measure smoothedPitchRatio half-time at retune 20 ms.',
}
(OUT / 'metrics.json').write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(data, indent=2))
