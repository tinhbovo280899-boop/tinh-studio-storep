#pragma once
namespace tak::product {
inline constexpr const char* name = "PantheonII";
inline constexpr const char* publisher = "Lexicon";
inline constexpr const char* version = "1.0.0";
inline constexpr const char* brandId = "PANTHEONII";
inline constexpr const char* productId = "PANTHEONII";
inline constexpr const char* publicKey = "10001,97185986301edfe0d964c5b31584becc5e182b651f2cc3dc3ffb9fa2df8542fc60d691d0e71b0c2b3c4bda8e95af31a7bf4c520132062ea9d64edb67753e11c0e6764dc5a18dc16eb3d48b9266475815452abf3e56bc20b39b13c02f7da020a6da04fa495687b0db113a2a9075504e36df8831ab38b02eed4d3ccad64c31bf6192dcd49d6df121608c36a89aecae0859dcc94d216e1182f5b9ed29a7691d382f75d68025d4ca8654255a8d59582c8909c1301aa92751311fd91614828c077f0fb4ee6305576598a88d38ba3398c0392527ccbde0a5a52d7c59396517728254681cde0b4744cac1f914b54e6d700b797056e05ec77f3bf1f74119dd739826d6f5";
inline constexpr const char* contactNote = "Gọi / Zalo 0329575243 để mua key hoặc hỗ trợ kỹ thuật.";
inline constexpr int trialDays = 7;
}
