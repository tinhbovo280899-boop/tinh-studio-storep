#include "TPantheonProcessor.h"
#include "TPantheonEditor.h"

namespace tpantheon
{

// Exact 36 Factory Presets extracted from unpacked PantheonII.dll (0x51078..0x51a08)
// Preset 00 matches the user's exact Cubase screenshot ("Large Hall" with 15% Mix, Room Size 38m, RT60 2.03s, Predelay 12ms, Damping 2.08kHz, Spread 83%, Diffusion 65%, Bass Boost 1.2x, Bass Freq 381Hz, Delay 14ms)
// Note on normVals indices in PantheonII.dll preset table:
//   [0]=ReverbType, [1]=Damping, [2]=RT60, [3]=Spread, [4]=RoomSize, [5]=BassBoost, [6]=BassFreq,
//   [7]=Diffusion, [8]=Mix, [9]=PreDelay, [10]=Delay, [11]=Level, [12]=InputLevel, [13]=EchoLvlL, [14]=EchoTimeL, [15]=EchoLvlR
static const std::vector<PantheonPreset> kPresets = {
    { "Large Hall",                                                  0, {{ 0.0f, 0.3214f, 0.3188f, 0.83f, 0.4679f, 0.30f,  0.2598f, 0.65f, 1.00f, 0.0117f, 0.4947f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "01. Large Hall (Dai Sanh Lon - 36% Mix)",                     0, {{ 0.0f, 0.3214f, 0.3188f, 0.83f, 0.4679f, 0.30f,  0.2598f, 0.65f, 0.36f, 0.0117f, 0.4947f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "02. Vocal Hall (Sanh Vocal Ballad)",                          0, {{ 0.0f, 0.3500f, 0.2988f, 0.72f, 0.7679f, 0.45f,  0.3197f, 0.65f, 0.22f, 0.0092f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "03. Lead Vocal Room (Vang Ngan Vocal Chuan)",                 2, {{ 0.4f, 0.5385f, 0.3526f, 0.60f, 0.6566f, 0.00f,  0.1887f, 0.86f, 0.28f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.45f,   0.1033f, 0.45f   }} },
    { "04. Vocal Plate (Lexicon Short Plate)",                       3, {{ 0.6f, 0.3750f, 0.2382f, 1.00f, 0.7303f, 0.075f, 0.4042f, 1.00f, 0.25f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.35f,   0.1600f, 0.35f   }} },
    { "05. Hit Vocal (Vang Ngan Day Giong)",                         5, {{ 1.0f, 1.0000f, 0.1804f, 0.24f, 0.8040f, 0.00f,  0.1816f, 1.00f, 0.30f, 0.0083f, 0.4934f, 1.0f, 1.0f, 0.55f,   0.0575f, 0.55f   }} },
    { "06. Vocal Spread (Mo Rong Stereo Vocal)",                     5, {{ 1.0f, 1.0000f, 0.1404f, 0.30f, 0.7940f, 0.10f,  0.3198f, 0.55f, 0.30f, 0.0092f, 0.3334f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "07. Vocal Slap (Slapback Chamber)",                           5, {{ 1.0f, 1.0000f, 0.1804f, 0.32f, 0.8040f, 0.525f, 0.1711f, 1.00f, 0.28f, 0.0083f, 0.4934f, 1.0f, 1.0f, 0.60f,   0.0575f, 0.60f   }} },
    { "08. Wide Vox (Vang Ngan Stereo Rong)",                        5, {{ 1.0f, 0.3889f, 0.2604f, 0.84f, 1.0000f, 0.30f,  0.4000f, 0.75f, 0.25f, 0.0083f, 0.00f,   1.0f, 1.0f, 0.45f,   0.0125f, 0.45f   }} },
    { "09. Small Plate (Plate Ngan Sach)",                           3, {{ 0.6f, 0.3125f, 0.1782f, 0.48f, 0.7603f, 0.25f,  0.8472f, 1.00f, 0.32f, 0.0233f, 0.00f,   1.0f, 1.0f, 0.35f,   0.1600f, 0.35f   }} },
    { "10. Small Chamber (Buong Vang Ngan)",                         1, {{ 0.2f, 0.4333f, 0.3190f, 0.65f, 0.6878f, 0.35f,  0.3900f, 0.80f, 0.26f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "11. Bright Ambience (Khong Gian Sang)",                       4, {{ 0.8f, 0.6250f, 0.3470f, 1.00f, 0.7545f, 0.25f,  0.1917f, 0.65f, 0.25f, 0.0233f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "12. Slight Ambience (Ambience Sieu Ngan)",                    4, {{ 0.8f, 0.4500f, 0.2870f, 1.00f, 0.7545f, 0.30f,  0.4468f, 0.65f, 0.24f, 0.0233f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "13. Mid Ambience (Khong Gian Trung)",                         4, {{ 0.8f, 0.7000f, 0.2400f, 1.00f, 0.4945f, 0.25f,  0.1716f, 0.65f, 0.28f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.50f,   0.0480f, 0.50f   }} },
    { "14. Small Room (Phong Thu Nho)",                              2, {{ 0.4f, 0.4308f, 0.3526f, 0.55f, 0.5066f, 0.25f,  0.3198f, 0.61f, 0.28f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "15. Medium Room (Phong Vua Am Ap)",                           2, {{ 0.4f, 0.4615f, 0.3426f, 0.60f, 0.5066f, 0.25f,  0.3198f, 0.86f, 0.30f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "16. Large Room (Phong Lon)",                                  2, {{ 0.4f, 0.5385f, 0.3726f, 0.60f, 0.6566f, 0.25f,  0.3198f, 0.86f, 0.32f, 0.1333f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "17. Tiled Room (Phong Gach Sang)",                            2, {{ 0.4f, 0.5308f, 0.3426f, 0.60f, 0.7166f, 0.25f,  0.2063f, 0.65f, 0.23f, 0.0167f, 0.3333f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "18. Guitar Room (Phong Acoustic/Guitar)",                     2, {{ 0.4f, 0.4308f, 0.3526f, 0.60f, 0.5466f, 0.25f,  0.3299f, 0.67f, 0.30f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "19. Medium Plate (Plate Trung Binh)",                         3, {{ 0.6f, 0.3750f, 0.2882f, 0.79f, 0.7303f, 0.30f,  0.4190f, 1.00f, 0.30f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.45f,   0.1600f, 0.45f   }} },
    { "20. Large Plate (Plate Dai Muot)",                            5, {{ 1.0f, 0.3333f, 0.3504f, 0.79f, 0.7240f, 0.30f,  0.4150f, 1.00f, 0.28f, 0.0083f, 0.00f,   1.0f, 1.0f, 0.45f,   0.0167f, 0.45f   }} },
    { "21. Soft Chamber (Buong Vang Mem)",                           1, {{ 0.2f, 0.7000f, 0.4290f, 0.62f, 0.5178f, 0.40f,  0.2826f, 0.65f, 0.30f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "22. Wide Chamber (Buong Vang Rong)",                          1, {{ 0.2f, 0.4667f, 0.3190f, 1.00f, 0.6378f, 0.48f,  0.3598f, 0.65f, 0.32f, 0.2033f, 0.3300f, 1.0f, 1.0f, 0.40f,   0.0800f, 0.40f   }} },
    { "23. Double Chamber (Buong Vang Kep)",                         1, {{ 0.2f, 0.4333f, 0.3190f, 0.75f, 0.6878f, 0.40f,  0.3900f, 0.80f, 0.30f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.40f,   0.8167f, 0.40f   }} },
    { "24. Large Chamber (Buong Vang Lon)",                          1, {{ 0.2f, 0.3000f, 0.4490f, 0.76f, 0.6578f, 0.40f,  0.3599f, 0.85f, 0.32f, 0.0967f, 0.2309f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "25. Snare Chamber (Vang Ngan Snare/Drum)",                    5, {{ 1.0f, 1.0000f, 0.1304f, 1.00f, 0.5840f, 0.525f, 0.1711f, 1.00f, 0.30f, 0.0083f, 0.2774f, 1.0f, 1.0f, 0.50f,   0.0000f, 0.50f   }} },
    { "26. Nonlinear 120ms (Vang Ngan Gate 120ms)",                  5, {{ 1.0f, 0.3528f, 0.2600f, 0.70f, 0.7240f, 0.25f,  0.2922f, 0.76f, 0.28f, 0.0000f, 0.00f,   1.0f, 1.0f, 0.40f,   0.1000f, 0.40f   }} },
    { "27. Nonlinear 200ms (Vang Ngan Gate 200ms)",                  5, {{ 1.0f, 0.3889f, 0.2000f, 0.70f, 0.7240f, 0.25f,  0.2922f, 0.68f, 0.28f, 0.0000f, 0.00f,   1.0f, 1.0f, 0.40f,   0.1667f, 0.40f   }} },
    { "28. Small Hall (Sanh Nho)",                                   0, {{ 0.0f, 0.3536f, 0.3088f, 0.65f, 0.5679f, 0.30f,  0.2397f, 0.52f, 0.30f, 0.0108f, 0.2847f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "29. Medium Hall (Sanh Vua)",                                  0, {{ 0.0f, 0.3607f, 0.3288f, 0.81f, 0.5179f, 0.30f,  0.2399f, 0.60f, 0.32f, 0.0108f, 0.4600f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "30. Choir Hall (Sanh Hop Xuong)",                             0, {{ 0.0f, 0.3571f, 0.2788f, 0.74f, 0.4379f, 0.375f, 0.2999f, 0.65f, 0.34f, 0.0333f, 0.2600f, 1.0f, 1.0f, 0.40f,   0.0167f, 0.40f   }} },
    { "31. Concert Hall (Hoa Nhac Giao Huong)",                      0, {{ 0.0f, 0.8036f, 0.2888f, 0.75f, 0.7179f, 0.50f,  0.2899f, 1.00f, 0.35f, 0.0092f, 0.4800f, 1.0f, 1.0f, 0.45f,   0.0008f, 0.45f   }} },
    { "32. Echo Hall (Sanh Vang + Echo)",                            0, {{ 0.0f, 0.8036f, 0.1888f, 0.60f, 0.4879f, 0.575f, 0.1689f, 0.87f, 0.35f, 0.0125f, 0.4500f, 1.0f, 1.0f, 0.45f,   0.5708f, 0.45f   }} },
    { "33. Deep Blue Hall (Sanh Sau Tham)",                          0, {{ 0.0f, 0.3214f, 0.3488f, 0.95f, 0.6579f, 0.45f,  0.2120f, 0.70f, 0.35f, 0.0083f, 0.5347f, 1.0f, 1.0f, 0.40f,   0.0608f, 0.40f   }} },
    { "34. Stadium PA Echo (San Van Dong)",                          5, {{ 1.0f, 0.3361f, 0.2500f, 1.00f, 0.7240f, 0.25f,  0.2922f, 1.00f, 0.38f, 0.1667f, 0.7372f, 1.0f, 1.0f, 0.55f,   0.0000f, 0.55f   }} }
};

} // namespace tpantheon

const std::vector<tpantheon::PantheonPreset>& TPantheonAudioProcessor::getFactoryPresets()
{
    return tpantheon::kPresets;
}

juce::AudioProcessorValueTreeState::ParameterLayout TPantheonAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // 6 Reverb Types from PantheonII.dll (0x040342..0x040370)
    juce::StringArray reverbTypes { "Hall", "Chamber", "Room", "Plate", "Ambience", "Custom" };
    params.push_back(std::make_unique<juce::AudioParameterChoice>("reverbType", "Reverb Type", reverbTypes, 0));

    // 16 Core PhoenixChamber Parameters matching the exact Cubase screenshot defaults
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "roomSize", "Room Size", juce::NormalisableRange<float>(4.0f, 76.0f, 0.5f), 38.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "rt60", "RT60", juce::NormalisableRange<float>(0.10f, 6.59f, 0.01f), 2.03f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "spread", "Spread", juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 83.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "damping", "Damping", juce::NormalisableRange<float>(500.0f, 20000.0f, 10.0f, 0.4f), 2080.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "bassBoost", "Bass Boost", juce::NormalisableRange<float>(0.1f, 2.5f, 0.05f), 1.2f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "bassFreq", "Bass Frequency", juce::NormalisableRange<float>(60.0f, 2500.0f, 1.0f, 0.45f), 381.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "diffusion", "Diffusion", juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 65.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "regen", "Regen", juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "delay", "Delay", juce::NormalisableRange<float>(0.0f, 250.0f, 0.5f), 14.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "preDelay", "Pre-delay", juce::NormalisableRange<float>(0.0f, 250.0f, 0.5f), 12.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "mix", "Mix", juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "level", "Level", juce::NormalisableRange<float>(-36.0f, 6.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoLevelL", "Echo Level Left", juce::NormalisableRange<float>(-60.0f, 0.0f, 0.5f), -60.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoTimeL", "Echo Time Left", juce::NormalisableRange<float>(0.0f, 600.0f, 1.0f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoLevelR", "Echo Level Right", juce::NormalisableRange<float>(-60.0f, 0.0f, 0.5f), -60.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoTimeR", "Echo Time Right", juce::NormalisableRange<float>(0.0f, 600.0f, 1.0f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "inputLevel", "Input Level", juce::NormalisableRange<float>(-24.0f, 12.0f, 0.1f), 0.0f));

    return { params.begin(), params.end() };
}

TPantheonAudioProcessor::TPantheonAudioProcessor()
    : TPantheonAudioProcessor(tak::license::StorePaths::forProduct(tak::license::productConfiguration()))
{
}

TPantheonAudioProcessor::TPantheonAudioProcessor(const tak::license::StorePaths& paths)
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "TPantheonParameters", createParameterLayout()),
      licenseManager(tak::license::productConfiguration(),
                     paths,
                     {}, true)
{
    refreshLicenseState();
    setCurrentProgram(0);
}

void TPantheonAudioProcessor::refreshLicenseState()
{
    licenseManager.poll();
    pluginUnlocked.store(licenseManager.isAllowed(), std::memory_order_relaxed);
}

void TPantheonAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    juce::ignoreUnused(samplesPerBlock);
    chamber.prepare(sampleRate);
}

void TPantheonAudioProcessor::releaseResources()
{
    chamber.reset();
}

bool TPantheonAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    const auto in  = layouts.getMainInputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return in == out || in == juce::AudioChannelSet::mono();
}

int TPantheonAudioProcessor::getNumPrograms()
{
    return static_cast<int>(tpantheon::kPresets.size());
}

const juce::String TPantheonAudioProcessor::getProgramName(int index)
{
    if (index >= 0 && index < static_cast<int>(tpantheon::kPresets.size()))
        return juce::String::fromUTF8(tpantheon::kPresets[static_cast<size_t>(index)].name);
    return {};
}

void TPantheonAudioProcessor::changeProgramName(int, const juce::String&) {}

void TPantheonAudioProcessor::setCurrentProgram(int index)
{
    if (index < 0 || index >= static_cast<int>(tpantheon::kPresets.size()))
        return;
    currentPresetIndex = index;
    const auto& p = tpantheon::kPresets[static_cast<size_t>(index)];

    auto setPlain = [this](const char* id, float plainVal)
    {
        if (auto* param = apvts.getParameter(id))
            param->setValueNotifyingHost(param->convertTo0to1(plainVal));
    };

    setPlain("reverbType", static_cast<float>(p.reverbType));

    const float roomMeters = std::round(4.0f + p.normVals[4] * 72.0f);
    const float rt60Sec    = std::round(juce::jlimit(0.10f, 6.59f, p.normVals[2] * 6.3676f) * 100.0f) * 0.01f;
    const float spreadPct  = std::round(p.normVals[3] * 100.0f);
    const float dampHz     = std::round(30.0f + std::pow(juce::jlimit(0.0f, 1.0f, p.normVals[1]), 2.0f) * 19845.4f);
    const float bassMult   = std::round((0.6f + p.normVals[5] * 2.0f) * 20.0f) * 0.05f;
    const float bassHz     = std::round(60.0f + std::pow(juce::jlimit(0.0f, 1.0f, p.normVals[6]), 2.0f) * 4756.0f);
    const float diffPct    = p.normVals[7] * 100.0f;
    const float mixPct     = p.normVals[8] * 100.0f;
    const float preDlyMs   = std::round(p.normVals[9] * 1025.6f);
    const float dlyMs      = std::round(p.normVals[10] * 28.3f);
    const float echoLDb    = (p.normVals[13] <= 0.001f) ? -60.0f : (-60.0f + p.normVals[13] * 60.0f);
    const float echoRDb    = (p.normVals[15] <= 0.001f) ? -60.0f : (-60.0f + p.normVals[15] * 60.0f);
    const float echoTLMs   = p.normVals[14] * 600.0f;
    const float echoTRMs   = juce::jlimit(0.0f, 600.0f, p.normVals[14] * 600.0f * 1.25f);

    setPlain("roomSize",   roomMeters);
    setPlain("rt60",       rt60Sec);
    setPlain("spread",     spreadPct);
    setPlain("damping",    dampHz);
    setPlain("bassBoost",  bassMult);
    setPlain("bassFreq",   bassHz);
    setPlain("diffusion",  diffPct);
    setPlain("regen",      0.0f);
    setPlain("preDelay",   preDlyMs);
    setPlain("delay",      dlyMs);
    setPlain("mix",        mixPct);
    setPlain("level",      0.0f);
    setPlain("inputLevel", 0.0f);
    setPlain("echoLevelL", echoLDb);
    setPlain("echoTimeL",  echoTLMs);
    setPlain("echoLevelR", echoRDb);
    setPlain("echoTimeR",  echoTRMs);
}

void TPantheonAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    for (int i = getTotalNumInputChannels(); i < getTotalNumOutputChannels(); ++i)
        buffer.clear(i, 0, numSamples);

    if (numSamples <= 0 || numChannels <= 0)
        return;

    if (!licenseManager.isAllowed())
    {
        buffer.clear();
        meterOutL.store(0.0f);
        meterOutR.store(0.0f);
        return;
    }

    const int reverbType     = static_cast<int>(apvts.getRawParameterValue("reverbType")->load());
    const float roomSize     = apvts.getRawParameterValue("roomSize")->load();
    const float rt60         = apvts.getRawParameterValue("rt60")->load();
    const float spread       = apvts.getRawParameterValue("spread")->load();
    const float damping      = apvts.getRawParameterValue("damping")->load();
    const float bassBoost    = apvts.getRawParameterValue("bassBoost")->load();
    const float bassFreq     = apvts.getRawParameterValue("bassFreq")->load();
    const float diffusion    = apvts.getRawParameterValue("diffusion")->load();
    const float regen        = apvts.getRawParameterValue("regen")->load();
    const float delayMs      = apvts.getRawParameterValue("delay")->load();
    const float preDelayMs   = apvts.getRawParameterValue("preDelay")->load();
    const float mixPct       = apvts.getRawParameterValue("mix")->load();
    const float levelDb      = apvts.getRawParameterValue("level")->load();
    const float echoLvlLDb   = apvts.getRawParameterValue("echoLevelL")->load();
    const float echoTimeLMs  = apvts.getRawParameterValue("echoTimeL")->load();
    const float echoLvlRDb   = apvts.getRawParameterValue("echoLevelR")->load();
    const float echoTimeRMs  = apvts.getRawParameterValue("echoTimeR")->load();
    const float inDb         = apvts.getRawParameterValue("inputLevel")->load();
    const float inLinear     = juce::Decibels::decibelsToGain(inDb);

    chamber.setParameters(
        reverbType,
        roomSize,
        rt60,
        spread,
        damping,
        bassBoost,
        bassFreq,
        diffusion,
        regen,
        delayMs,
        preDelayMs,
        mixPct,
        levelDb,
        echoLvlLDb,
        echoTimeLMs,
        echoLvlRDb,
        echoTimeRMs,
        inLinear
    );

    float* chL = buffer.getWritePointer(0);
    float* chR = (numChannels > 1) ? buffer.getWritePointer(1) : chL;

    float peakL = 0.0f, peakR = 0.0f;
    for (int i = 0; i < numSamples; ++i)
    {
        const float inL = std::isfinite(chL[i]) ? chL[i] : 0.0f;
        const float inR = getTotalNumInputChannels() > 1 && numChannels > 1 ? (std::isfinite(chR[i]) ? chR[i] : 0.0f) : inL;
        float outL = 0.0f, outR = 0.0f;

        chamber.processStereoSample(inL, inR, outL, outR);

        outL = juce::jlimit(-1.5f, 1.5f, outL);
        outR = juce::jlimit(-1.5f, 1.5f, outR);
        chL[i] = outL;
        if (numChannels > 1)
            chR[i] = outR;

        peakL = std::max(peakL, std::fabs(outL));
        peakR = std::max(peakR, std::fabs(outR));
    }

    meterOutL.store(peakL, std::memory_order_relaxed);
    meterOutR.store(peakR, std::memory_order_relaxed);
}

juce::AudioProcessorEditor* TPantheonAudioProcessor::createEditor()
{
    return new TPantheonAudioProcessorEditor(*this);
}

void TPantheonAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty("factoryPresetIndex", currentPresetIndex.load(), nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void TPantheonAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
    {
        auto state=juce::ValueTree::fromXml(*xmlState);
        currentPresetIndex.store(juce::jlimit(0,getNumPrograms()-1,static_cast<int>(state.getProperty("factoryPresetIndex",0))));
        apvts.replaceState(state);
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new TPantheonAudioProcessor();
}

double TPantheonAudioProcessor::getTailLengthSeconds() const
{
    const double rt = apvts.getRawParameterValue("rt60")->load();
    const double regen = apvts.getRawParameterValue("regen")->load() * 0.0095;
    const double delay = apvts.getRawParameterValue("delay")->load() * .001;
    const double repeats = regen > 0.0 ? std::max(0.0, std::log(1.e-6) / std::log(std::min(.95,regen))) : 0.0;
    const double pre = apvts.getRawParameterValue("preDelay")->load() * .001;
    const double echo = std::max(apvts.getRawParameterValue("echoTimeL")->load(),apvts.getRawParameterValue("echoTimeR")->load()) * .001;
    return pre + echo + 2.0 * rt + repeats * (delay + .02);
}
