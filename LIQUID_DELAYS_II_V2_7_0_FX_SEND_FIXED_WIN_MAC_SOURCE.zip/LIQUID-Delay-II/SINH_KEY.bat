@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ===========================================
echo  SINH KHOA VA KEY BAN QUYEN PANTHEON II
echo  (Dung OwnerLicenseTool da build, xac minh TAK1 truoc khi xuat key)
echo ===========================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\sinh_key.ps1" -Root "%~dp0." %*
set RC=%errorlevel%
echo.
if %RC%==0 (
    echo [OK] Thuc hien thanh cong!
) else (
    echo [LOI] Co loi xay ra trong qua trinh sinh key.
)
pause
exit /b %RC%
