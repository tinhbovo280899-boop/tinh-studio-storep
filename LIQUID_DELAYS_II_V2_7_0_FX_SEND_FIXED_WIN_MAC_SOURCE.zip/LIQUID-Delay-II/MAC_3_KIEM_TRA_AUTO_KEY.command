#!/bin/bash
printf "%s\n" "This reverb/delay project does not implement Auto-Key. No files were changed."
