# LIQUID DELAYS II 2.7.0 — ghi chú

## Đã sửa

- Bỏ ép sample rate lên 44,1 kHz: delay 100 ms tại 32 kHz trước đây thực tế 137,8125 ms; hiện tính theo rate thật. Áp dụng tương tự cho filter, LFO và meter.
- Chặn NaN/Inf trước recursive state trong delay/filter/overdrive/limiter.
- Tách envelope overdrive L/R để hai kênh giống nhau không bị xử lý khác do thứ tự gọi.
- Sửa ánh xạ cutoff: Hz đang hiển thị và Hz đưa vào filter dùng cùng khoảng; chặn dưới Nyquist.
- LFO dùng cadence 16 mẫu liên tục, không khởi động lại theo đầu block host; kiểm tra block 7 và 128 cho cùng kết quả.
- Host không có BPM thì dùng dlyTempo thay vì tự lấy 120 BPM.
- Meter tính trị tuyệt đối, phản ánh cả tín hiệu âm.
- Sửa mono→stereo và bypass; khi tắt delay không còn bị cộng input hai lần bởi InLoop.
- Lưu chỉ số factory preset cùng state; báo tail theo delay/feedback thay 4 giây cố định.
- Tách DSP ra Source/dsp/DelayComponents.h, sửa brand-sync, build, installer và thêm test.

## Giới hạn thật của mã nguồn

- Delay vẫn giới hạn khoảng 9,99 giây như buffer gốc; nhịp rất dài ở BPM thấp bị giới hạn. 100% feedback có thể không suy giảm; tail báo host tối đa 600 giây là giới hạn hữu hạn, không phải lời hứa đuôi âm đã tắt ở mức feedback này.
- hdFilter là tham số đã lưu nhưng chưa có nhánh DSP riêng trong source.
- InLoop hiện giữ ý nghĩa cộng tín hiệu trực tiếp vào wet output khi delay bật; chưa phải một đường feedback có filter/drive theo cách nhiều plugin delay khác dùng. Không tuyên bố đã tái tạo đúng chức năng InLoop của sản phẩm hãng khi chưa có đối chiếu.

## Kết quả kiểm thử

DSP: 7 sample rate 8–192 kHz, vị trí echo và feedback, reset, NaN/Inf, LFO, filter, stereo drive và limiter. Processor: mono→stereo, âm lượng/meter âm, fallback BPM, bypass, delay-off/InLoop, 13 preset, state/editor và block-size invariance của LFO. Thêm test codec license. Xem TEST_RESULTS.

Hướng dẫn build, cấp license và giới hạn xác minh nằm trong README.md.
