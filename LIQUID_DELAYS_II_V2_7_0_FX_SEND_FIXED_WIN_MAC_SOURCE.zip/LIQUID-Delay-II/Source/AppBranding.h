#pragma once
// Generated from ThuongHieu.json.
namespace AppBranding {
inline constexpr const char* kAppDisplayName = "Liquid Delays II";
inline constexpr const char* kBrandWord1 = "LIQUID";
inline constexpr const char* kBrandWord2 = "DELAYS II";
inline constexpr const char* kBrandSubtitle = "NOMAD FACTORY RETRO TUBE DELAY";
inline constexpr const char* kSplashLine2 = "NOMAD FACTORY / NT STUDIO";
inline constexpr const char* kPublisher = "Nomad Factory";
inline constexpr const char* kAppVersion = "2.7.0";
inline constexpr const char* kExeName = "Liquid Delays II.exe";
inline constexpr const char* kSetupName = "Setup_Liquid_Delays_II";
inline constexpr const char* kLicenseBrand = "LIQUIDDELAYS";
inline constexpr const char* kContactPhone = "0329575243";
inline constexpr const char* kContactNote = "Gọi / Zalo để mua bản quyền, gia hạn hoặc hỗ trợ kỹ thuật.";
inline constexpr const char* kAppDataDirName = "Liquid Delays II";
inline constexpr int kTrialDays = 7;
}
