#pragma once
#include <cstddef>
namespace BinaryData {
    extern const char* bg_skin_png;
    const int bg_skin_pngSize = 104291;
    extern const char* knob_large_png;
    const int knob_large_pngSize = 4416;
    extern const char* routing_display_png;
    const int routing_display_pngSize = 3617;
    extern const char* lfo_meter_png;
    const int lfo_meter_pngSize = 1897;
    extern const char* switch_panel_png;
    const int switch_panel_pngSize = 4419;
}
