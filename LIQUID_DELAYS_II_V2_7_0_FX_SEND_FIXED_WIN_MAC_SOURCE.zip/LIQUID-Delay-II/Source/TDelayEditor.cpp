#include "TDelayEditor.h"
#include "BinaryData.h"

TDelayLookAndFeel::TDelayLookAndFeel()
{
    knobLargeImage   = juce::ImageCache::getFromMemory(BinaryData::knob_large_png,   BinaryData::knob_large_pngSize);
    switchPanelImage = juce::ImageCache::getFromMemory(BinaryData::switch_panel_png, BinaryData::switch_panel_pngSize);
    modeDisplayImage = juce::ImageCache::getFromMemory(BinaryData::lfo_meter_png,    BinaryData::lfo_meter_pngSize);

    setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff0b141e));
    setColour(juce::PopupMenu::textColourId, juce::Colour(0xff00f0b8));
    setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff183854));
}

void TDelayLookAndFeel::drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
                                         float sliderPos, float minSliderPos, float maxSliderPos,
                                         const juce::Slider::SliderStyle, juce::Slider& slider)
{
    juce::ignoreUnused(sliderPos, minSliderPos, maxSliderPos);
    const auto tag = slider.getProperties()["styleTag"].toString();
    const double val = slider.getValue();
    const double minV = slider.getMinimum();
    const double maxV = slider.getMaximum();
    const float norm = static_cast<float>(slider.valueToProportionOfLength(juce::jlimit(minV, maxV, val)));

    if (tag == "lcd")
    {
        // Right-panel dark LCD digital readout (Input Level, Output Level, Mix)
        g.setColour(juce::Colour(0xffd8e6f2));
        g.setFont(juce::Font(juce::FontOptions(13.0f, juce::Font::plain)));
        g.drawText(slider.getTextFromValue(val), x, y, width, height, juce::Justification::centred, false);
        return;
    }

    // Metallic parameter box (86x51):
    // 1. Value readout in the lower half of the metallic box (x+2..x+74, y+22..y+46)
    g.setColour(juce::Colour(0xff101824));
    g.setFont(juce::Font(juce::FontOptions(13.2f, juce::Font::plain)));
    juce::String dispText = slider.getTextFromValue(val);
    g.drawText(dispText, x + 2, y + 21, width - 14, 24, juce::Justification::centred, false);

    // 2. Right-side vertical bar track (x + width - 9, y + 4, w = 5, h = 43)
    const int barX = x + width - 9;
    const int barY = y + 4;
    const int barW = 5;
    const int barH = height - 8;

    // White interior track background (matching Screenshot 2026-10-27 193841.jpg)
    g.setColour(juce::Colour(0xfff2f6fa));
    g.fillRect(barX, barY, barW, barH);

    // Colored fill from bottom
    juce::Colour fillCol = slider.findColour(juce::Slider::trackColourId);
    int fillH = juce::roundToInt(norm * static_cast<float>(barH));
    if (tag == "overdrive" && fillH < 3)
        fillH = 3; // Red baseline indicator when Overdrive is Off, matching screenshot
    else if (tag == "tempo" && dispText == "SYNC")
        fillH = 6; // Red baseline indicator when Tempo is in SYNC mode, matching screenshot

    fillH = juce::jlimit(0, barH, fillH);
    if (fillH > 0)
    {
        g.setColour(fillCol);
        g.fillRect(barX, barY + barH - fillH, barW, fillH);
    }
}

void TDelayLookAndFeel::drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                                         bool, bool)
{
    const auto tag = button.getProperties()["btnType"].toString();
    const bool on = button.getToggleState();
    auto b = button.getLocalBounds();

    if (tag == "pillOn")
    {
        // Black pill "ON" button: when OFF, background skin already shows light-blue "ON".
        // When ON, draw black pill interior with bright yellow "ON" text matching screenshot!
        if (on)
        {
            g.setColour(juce::Colour(0xff05080c));
            g.fillRoundedRectangle(b.toFloat().reduced(1.0f, 1.0f), 4.0f);
            g.setColour(juce::Colour(0xfffff000));
            g.setFont(juce::Font(juce::FontOptions(9.5f, juce::Font::bold)));
            g.drawText("ON", b, juce::Justification::centred, false);
        }
        return;
    }

    if (tag == "lfoSyncOval")
    {
        // Draw from knob_large_png (54x62: top 54x31 = OFF grey, bottom 54x31 = ON green)
        if (knobLargeImage.isValid())
        {
            const int srcY = on ? 31 : 0;
            g.drawImage(knobLargeImage, 0, 0, b.getWidth(), b.getHeight(), 0, srcY, 54, 31);
        }
        return;
    }

    if (tag == "peakLimiterOval")
    {
        // When OFF, bg_skin_png already shows grey metallic Peak Limiter oval.
        // When ON (default in screenshot), draw glowing sky-blue oval with "Peak\nLimiter"
        if (on)
        {
            auto rf = b.toFloat().reduced(1.0f);
            juce::ColourGradient grad(juce::Colour(0xffcceeff), rf.getCentreX(), rf.getY(),
                                      juce::Colour(0xff62b4f6), rf.getCentreX(), rf.getBottom(), false);
            g.setGradientFill(grad);
            g.fillRoundedRectangle(rf, 14.5f);
            g.setColour(juce::Colour(0xff2c5880));
            g.drawRoundedRectangle(rf, 14.5f, 1.2f);

            g.setColour(juce::Colour(0xff081828));
            g.setFont(juce::Font(juce::FontOptions(11.5f, juce::Font::plain)));
            g.drawFittedText("Peak\nLimiter", b.reduced(4, 2), juce::Justification::centred, 2);
        }
        return;
    }

    if (tag == "bypassSwitch")
    {
        // switch_panel_png is 78x44: top half (y=0..22) = OFF silver "Bypass", bottom half (y=22..44) = ON yellow "Bypass"
        if (switchPanelImage.isValid())
        {
            const int srcY = on ? 22 : 0;
            g.drawImage(switchPanelImage, 0, 0, b.getWidth(), b.getHeight(), 0, srcY, 78, 22);
        }
        return;
    }

    if (tag == "triDot")
    {
        // Small "3" or "." button next to note divisions: when ON, highlight in bright yellow
        if (on)
        {
            g.setColour(juce::Colour(0xff05080c));
            g.fillRoundedRectangle(b.toFloat().reduced(1.5f), 2.5f);
            g.setColour(juce::Colour(0xfffff000));
            g.setFont(juce::Font(juce::FontOptions(10.5f, juce::Font::bold)));
            g.drawText(button.getButtonText(), b, juce::Justification::centred, false);
        }
        return;
    }
}

void TDelayLookAndFeel::drawComboBox(juce::Graphics& g, int width, int height, bool,
                                     int, int, int, int, juce::ComboBox& box)
{
    const auto tag = box.getProperties()["comboType"].toString();
    if (tag == "presetLcd")
    {
        g.setColour(juce::Colour(0xff081018));
        g.fillRect(1, 1, width - 2, height - 2);
        g.setColour(juce::Colour(0xff00f0b8));
        g.setFont(juce::Font(juce::FontOptions(13.0f, juce::Font::bold)));
        g.drawText(box.getText(), 4, 0, width - 8, height, juce::Justification::centred, false);
        return;
    }

    if (tag == "fxModeLcd")
    {
        if (modeDisplayImage.isValid())
            g.drawImage(modeDisplayImage, 0, 0, width, height, 0, 0, modeDisplayImage.getWidth(), modeDisplayImage.getHeight());
        g.setColour(juce::Colour(0xff8ec4e8));
        g.setFont(juce::Font(juce::FontOptions(11.5f, juce::Font::plain)));
        g.drawText(box.getText(), 18, 0, width - 40, height, juce::Justification::centred, false);
        return;
    }
}

TDelayAudioProcessorEditor::TDelayAudioProcessorEditor(TDelayAudioProcessor& p)
    : AudioProcessorEditor(&p),
      audioProcessor(p),
      licenseOverlay(
          [this]() { return audioProcessor.getLicenseManager().snapshot(); },
          [this](const juce::String& k) { audioProcessor.getLicenseManager().requestActivation(k); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { audioProcessor.getLicenseManager().requestTrial(); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { licenseOverlay.setVisible(false); updateLicenseBadge(); repaint(); }
      )
{
    setLookAndFeel(&customLookAndFeel);
    bgSkinImage         = juce::ImageCache::getFromMemory(BinaryData::bg_skin_png,         BinaryData::bg_skin_pngSize);
    routingDisplayImage = juce::ImageCache::getFromMemory(BinaryData::routing_display_png, BinaryData::routing_display_pngSize);

    // Top Preset Bar (Save, <, Preset LCD, >, Utility)
    const auto& presets = TDelayAudioProcessor::getFactoryPresets();
    for (int i = 0; i < static_cast<int>(presets.size()); ++i)
        presetBox.addItem(juce::String::fromUTF8(presets[static_cast<size_t>(i)].name), i + 1);
    presetBox.getProperties().set("comboType", "presetLcd");
    presetBox.setSelectedId(audioProcessor.getCurrentProgram() + 1, juce::dontSendNotification);
    presetBox.onChange = [this]
    {
        int idx = presetBox.getSelectedId() - 1;
        if (idx >= 0)
        {
            audioProcessor.setCurrentProgram(idx);
            repaint();
        }
    };
    addAndMakeVisible(presetBox);

    for (auto* b : { &saveBtn, &prevPreBtn, &nextPreBtn, &utilityBtn })
    {
        b->setAlpha(0.0f); // Invisible hit-boxes over the exact skin buttons
        addAndMakeVisible(*b);
    }

    prevPreBtn.onClick = [this]
    {
        int n = presetBox.getNumItems();
        if (n > 0)
        {
            int cur = presetBox.getSelectedId() - 1;
            int prev = (cur - 1 + n) % n;
            presetBox.setSelectedId(prev + 1, juce::sendNotification);
        }
    };
    nextPreBtn.onClick = [this]
    {
        int n = presetBox.getNumItems();
        if (n > 0)
        {
            int cur = presetBox.getSelectedId() - 1;
            int next = (cur + 1) % n;
            presetBox.setSelectedId(next + 1, juce::sendNotification);
        }
    };
    saveBtn.onClick = [this]
    {
        int cur = presetBox.getSelectedId() - 1;
        if (cur >= 0)
            audioProcessor.setCurrentProgram(cur);
    };
    utilityBtn.onClick = [this]
    {
        audioProcessor.refreshLicenseState();
        licenseOverlay.setVisible(!licenseOverlay.isVisible());
        if (licenseOverlay.isVisible())
            licenseOverlay.toFront(true);
        resized();
    };

    // FX Mode Routing Box at bottom (Mode: Drive -> Filters -> Delays)
    fxModeBox.getProperties().set("comboType", "fxModeLcd");
    fxModeBox.addItemList({
        "Filters -> Drive -> Delays",
        "Filters -> Delays -> Drive",
        "Delays -> Drive -> Filters",
        "Delays -> Filters -> Drive",
        "Drive -> Delays -> Filters",
        "Drive -> Filters -> Delays"
    }, 1);
    addAndMakeVisible(fxModeBox);
    fxModeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "fxMode", fxModeBox);

    // Hidden ComboBoxes for APVTS sync & LFO wave attachments
    juce::StringArray syncNames;
    for (const auto& d : tdelay::kSyncDivisions)
        syncNames.add(d.label);
    dlyLXTimeBox.addItemList(syncNames, 1);
    dlyRXTimeBox.addItemList(syncNames, 1);
    dlyLXTimeBox.onChange = [this] { repaint(); };
    dlyRXTimeBox.onChange = [this] { repaint(); };
    dlyLXTimeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "dlyLXTime", dlyLXTimeBox);
    dlyRXTimeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "dlyRXTime", dlyRXTimeBox);

    lfoWaveBox.addItemList({ "Sine", "Triangle", "Pulse", "Saw Up", "Saw Down" }, 1);
    lfoWaveBox.onChange = [this] { repaint(); };
    lfoWaveAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "lfoWave", lfoWaveBox);

    // 6 Black "ON" Pill Toggle Buttons
    for (auto* btn : { &filterOnBtn, &inLoopBtn, &lfoOnBtn, &dlySyncBtn, &dlyLOnBtn, &dlyROnBtn })
    {
        btn->getProperties().set("btnType", "pillOn");
        addAndMakeVisible(*btn);
    }
    inLoopBtn.setTooltip("Adds an immediate processed signal to the wet output. Keep Off for an echo-only FX Send return.");
    fxModeBox.setTooltip("Filters and drive are outside the delay feedback loop. The stored HDFilter parameter has no separate DSP mode in this edition.");
    dlyLOnBtn.setTooltip("When Off, this channel passes its input through. Keep both delays On for an echo-only FX Send return.");
    dlyROnBtn.setTooltip("When Off, this channel passes its input through. Keep both delays On for an echo-only FX Send return.");
    dlySyncBtn.onClick = [this] { dlyTempoSlider.repaint(); };

    // 2 Oval Toggle Buttons (LFO Sync & Peak Limiter)
    lfoSyncBtn.getProperties().set("btnType", "lfoSyncOval");
    peakLimitBtn.getProperties().set("btnType", "peakLimiterOval");
    addAndMakeVisible(lfoSyncBtn);
    addAndMakeVisible(peakLimitBtn);

    // Master Bypass Switch
    bypassBtn.getProperties().set("btnType", "bypassSwitch");
    addAndMakeVisible(bypassBtn);

    // Triplet ("3") and Dotted (".") Toggle Buttons
    for (auto* btn : { &dlyLTriBtn, &dlyLDotBtn, &dlyRTriBtn, &dlyRDotBtn })
    {
        btn->getProperties().set("btnType", "triDot");
        addAndMakeVisible(*btn);
    }

    auto& apvts = audioProcessor.getAPVTS();
    dlyLOnAtt    = std::make_unique<ButtonAttachment>(apvts, "dlyLOn",    dlyLOnBtn);
    dlyROnAtt    = std::make_unique<ButtonAttachment>(apvts, "dlyROn",    dlyROnBtn);
    dlySyncAtt   = std::make_unique<ButtonAttachment>(apvts, "dlySync",   dlySyncBtn);
    inLoopAtt    = std::make_unique<ButtonAttachment>(apvts, "inLoop",    inLoopBtn);
    dlyLDotAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyLDot",   dlyLDotBtn);
    dlyRDotAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyRDot",   dlyRDotBtn);
    dlyLTriAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyLTri",   dlyLTriBtn);
    dlyRTriAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyRTri",   dlyRTriBtn);
    filterOnAtt  = std::make_unique<ButtonAttachment>(apvts, "filterOn",  filterOnBtn);
    lfoOnAtt     = std::make_unique<ButtonAttachment>(apvts, "lfoOn",     lfoOnBtn);
    lfoSyncAtt   = std::make_unique<ButtonAttachment>(apvts, "lfoSync",   lfoSyncBtn);
    peakLimitAtt = std::make_unique<ButtonAttachment>(apvts, "peakLimit", peakLimitBtn);
    bypassAtt    = std::make_unique<ButtonAttachment>(apvts, "bypass",    bypassBtn);

    // 9 Metallic Parameter Box Sliders + 3 Right-Panel LCD Sliders
    setupBoxSlider(lowCutSlider,      juce::Colour(0xff00c838), "box");
    setupBoxSlider(resonanceSlider,   juce::Colour(0xffff9c00), "box");
    setupBoxSlider(highCutSlider,     juce::Colour(0xff00c838), "box");
    setupBoxSlider(overdriveSlider,   juce::Colour(0xffe62020), "overdrive");
    setupBoxSlider(lfoRateSlider,     juce::Colour(0xfff000e0), "box");
    setupBoxSlider(lfoDepthSlider,    juce::Colour(0xff0088ff), "box");
    setupBoxSlider(stereoWidthSlider, juce::Colour(0xff8ed2f4), "box");
    setupBoxSlider(dlyTempoSlider,    juce::Colour(0xffe62020), "tempo");
    setupBoxSlider(dlyFeedbackSlider, juce::Colour(0xffe8d800), "box");

    setupBoxSlider(inputLevelSlider,  juce::Colours::transparentBlack, "lcd");
    setupBoxSlider(outputLevelSlider, juce::Colours::transparentBlack, "lcd");
    setupBoxSlider(mixSlider,         juce::Colours::transparentBlack, "lcd");

    dlyTempoAtt    = std::make_unique<SliderAttachment>(apvts, "dlyTempo",    dlyTempoSlider);
    dlyFeedbackAtt = std::make_unique<SliderAttachment>(apvts, "dlyFeedback", dlyFeedbackSlider);
    lowCutAtt      = std::make_unique<SliderAttachment>(apvts, "lowCut",      lowCutSlider);
    resonanceAtt   = std::make_unique<SliderAttachment>(apvts, "resonance",   resonanceSlider);
    highCutAtt     = std::make_unique<SliderAttachment>(apvts, "highCut",     highCutSlider);
    overdriveAtt   = std::make_unique<SliderAttachment>(apvts, "overdrive",   overdriveSlider);
    lfoRateAtt     = std::make_unique<SliderAttachment>(apvts, "lfoRate",     lfoRateSlider);
    lfoDepthAtt    = std::make_unique<SliderAttachment>(apvts, "lfoDepth",    lfoDepthSlider);
    inputLevelAtt  = std::make_unique<SliderAttachment>(apvts, "inputLevel",  inputLevelSlider);
    outputLevelAtt = std::make_unique<SliderAttachment>(apvts, "outputLevel", outputLevelSlider);
    stereoWidthAtt = std::make_unique<SliderAttachment>(apvts, "stereoWidth", stereoWidthSlider);
    mixAtt         = std::make_unique<SliderAttachment>(apvts, "mix",         mixSlider);

    // Exact text formatting matching Screenshot 2026-10-27 193841.jpg:
    lowCutSlider.textFromValueFunction = [](double v) { return juce::String(v, 2) + " Hz"; };
    resonanceSlider.textFromValueFunction = [](double v) { return juce::String(v, 1) + " %"; };
    highCutSlider.textFromValueFunction = [](double v) {
        return (v >= 1000.0) ? (juce::String(v * 0.001, 2) + " Khz") : (juce::String(v, 1) + " Hz");
    };
    overdriveSlider.textFromValueFunction = [](double v) {
        return (v < 0.05) ? juce::String("Off") : (juce::String(v, 1) + " %");
    };
    lfoRateSlider.textFromValueFunction = [](double v) { return juce::String(v, 2) + " Hz"; };
    lfoDepthSlider.textFromValueFunction = [](double v) { return juce::String(v, 1) + " %"; };
    stereoWidthSlider.textFromValueFunction = [](double v) { return juce::String(v, 1) + " %"; };
    dlyTempoSlider.textFromValueFunction = [this](double v) {
        const bool syncOn = audioProcessor.getAPVTS().getRawParameterValue("dlySync")->load() > 0.5f;
        return syncOn ? juce::String("SYNC") : juce::String(v, 1);
    };
    dlyFeedbackSlider.textFromValueFunction = [](double v) { return juce::String(v, 1) + " %"; };
    inputLevelSlider.textFromValueFunction  = [](double v) { return juce::String(v, 1) + " dB"; };
    outputLevelSlider.textFromValueFunction = [](double v) { return juce::String(v, 1) + " dB"; };
    mixSlider.textFromValueFunction         = [](double v) { return juce::String(v, 1) + " %"; };

    for (auto* s : { &lowCutSlider, &resonanceSlider, &highCutSlider, &overdriveSlider,
                     &lfoRateSlider, &lfoDepthSlider, &stereoWidthSlider,
                     &dlyTempoSlider, &dlyFeedbackSlider,
                     &inputLevelSlider, &outputLevelSlider, &mixSlider })
    {
        s->updateText();
    }

    addChildComponent(licenseOverlay);
    if (!audioProcessor.isPluginUnlocked())
        licenseOverlay.setVisible(true);

    updateLicenseBadge();
    setSize(666, 484);
    startTimerHz(30);
}

TDelayAudioProcessorEditor::~TDelayAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
}

void TDelayAudioProcessorEditor::setupBoxSlider(juce::Slider& s, juce::Colour barCol, const juce::String& styleTag)
{
    s.setSliderStyle(juce::Slider::LinearVertical);
    s.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    s.setColour(juce::Slider::trackColourId, barCol);
    s.getProperties().set("styleTag", styleTag);
    addAndMakeVisible(s);
}

int TDelayAudioProcessorEditor::syncIndexToNoteRow(int syncIdx) const noexcept
{
    // Map kSyncDivisions index (0..21) to the 6 rows of routing_display_png:
    // Row 0 = "1" (1 Bar = idx 12..21)
    // Row 1 = "2" (1/2 Bar = idx 8..11)
    // Row 2 = "4" (1/4 Bar = idx 5..7)
    // Row 3 = "8" (1/8 Bar = idx 2..4)
    // Row 4 = "16" (1/16 Bar = idx 1)
    // Row 5 = "32" (1/32 Bar = idx 0)
    if (syncIdx <= 0) return 5;
    if (syncIdx == 1 || syncIdx == 3) return 4;
    if (syncIdx >= 2 && syncIdx <= 4) return 3;
    if (syncIdx >= 5 && syncIdx <= 7) return 2;
    if (syncIdx >= 8 && syncIdx <= 11) return 1;
    return 0;
}

int TDelayAudioProcessorEditor::noteRowToSyncIndex(int row) const noexcept
{
    switch (juce::jlimit(0, 5, row))
    {
        case 0: return 12; // 1 Bar
        case 1: return 10; // 1/2 Bar
        case 2: return 7;  // 1/4 Bar
        case 3: return 4;  // 1/8 Bar
        case 4: return 1;  // 1/16 Bar
        default: return 0; // 1/32 Bar
    }
}

void TDelayAudioProcessorEditor::mouseDown(const juce::MouseEvent& e)
{
    const auto pt = e.getPosition();

    // 1. Check 5 LFO Waveform Buttons (x=276..296, y=201..266)
    if (pt.x >= 275 && pt.x <= 297 && pt.y >= 200 && pt.y <= 267)
    {
        const int waveIdx = juce::jlimit(0, 4, (pt.y - 201) / 13);
        if (auto* param = audioProcessor.getAPVTS().getParameter("lfoWave"))
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(waveIdx)));
        repaint();
        return;
    }

    // 2. Check L-Delay 6 Note Division Buttons (x=164..259, y=364..390)
    if (pt.x >= 164 && pt.x < 260 && pt.y >= 363 && pt.y <= 392)
    {
        const int noteCol = juce::jlimit(0, 5, (pt.x - 164) / 16);
        const int syncIdx = noteRowToSyncIndex(noteCol);
        if (auto* param = audioProcessor.getAPVTS().getParameter("dlyLXTime"))
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(syncIdx)));
        repaint();
        return;
    }

    // 3. Check R-Delay 6 Note Division Buttons (x=370..465, y=364..390)
    if (pt.x >= 370 && pt.x < 466 && pt.y >= 363 && pt.y <= 392)
    {
        const int noteCol = juce::jlimit(0, 5, (pt.x - 370) / 16);
        const int syncIdx = noteRowToSyncIndex(noteCol);
        if (auto* param = audioProcessor.getAPVTS().getParameter("dlyRXTime"))
            param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(syncIdx)));
        repaint();
        return;
    }
}

void TDelayAudioProcessorEditor::updateLicenseBadge()
{
}

void TDelayAudioProcessorEditor::timerCallback()
{
    // Repaint LFO meter and In/Out stereo LED meters
    repaint(314, 175, 20, 122);
    repaint(558, 218, 82, 210);
}

void TDelayAudioProcessorEditor::paint(juce::Graphics& g)
{
    // 1. Draw 100% original Nomad Factory Liquid Delays II 666x484 faceplate skin
    if (bgSkinImage.isValid())
        g.drawImageAt(bgSkinImage, 0, 0);
    else
        g.fillAll(juce::Colour(0xff1c3048));

    auto& apvts = audioProcessor.getAPVTS();

    // 2. Draw L-Delay & R-Delay 6 Note Division Sprites (routing_display_png: 95x150 = 6 rows of 95x25)
    if (routingDisplayImage.isValid())
    {
        const int lSyncIdx = static_cast<int>(apvts.getRawParameterValue("dlyLXTime")->load());
        const int rSyncIdx = static_cast<int>(apvts.getRawParameterValue("dlyRXTime")->load());
        const int lRow = syncIndexToNoteRow(lSyncIdx);
        const int rRow = syncIndexToNoteRow(rSyncIdx);

        g.drawImage(routingDisplayImage, 164, 364, 95, 25, 0, lRow * 25, 95, 25);
        g.drawImage(routingDisplayImage, 370, 364, 95, 25, 0, rRow * 25, 95, 25);
    }

    // 3. Draw Selected LFO Waveform in Bright Yellow (x=276..296, y=201..266)
    const int lfoWave = static_cast<int>(apvts.getRawParameterValue("lfoWave")->load());
    const int waveY[5] = { 201, 214, 228, 241, 255 };
    if (lfoWave >= 0 && lfoWave < 5)
    {
        const int wy = waveY[lfoWave];
        g.setColour(juce::Colour(0xff05080c));
        g.fillRoundedRectangle(277.0f, static_cast<float>(wy + 1), 18.0f, 9.0f, 3.5f);

        g.setColour(juce::Colour(0xfffff000));
        juce::Path wp;
        const float cx = 286.0f;
        const float cy = static_cast<float>(wy) + 5.5f;
        if (lfoWave == 0) // Sine
        {
            wp.startNewSubPath(cx - 5.5f, cy);
            wp.cubicTo(cx - 2.5f, cy - 4.5f, cx - 0.5f, cy - 4.5f, cx, cy);
            wp.cubicTo(cx + 0.5f, cy + 4.5f, cx + 2.5f, cy + 4.5f, cx + 5.5f, cy);
        }
        else if (lfoWave == 1) // Triangle
        {
            wp.startNewSubPath(cx - 5.5f, cy + 2.5f);
            wp.lineTo(cx, cy - 3.0f);
            wp.lineTo(cx + 5.5f, cy + 2.5f);
        }
        else if (lfoWave == 2) // Pulse
        {
            wp.startNewSubPath(cx - 5.5f, cy + 2.5f);
            wp.lineTo(cx - 5.5f, cy - 2.5f);
            wp.lineTo(cx, cy - 2.5f);
            wp.lineTo(cx, cy + 2.5f);
            wp.lineTo(cx + 5.5f, cy + 2.5f);
            wp.lineTo(cx + 5.5f, cy - 2.5f);
        }
        else if (lfoWave == 3) // Saw Up
        {
            wp.startNewSubPath(cx - 5.5f, cy + 2.5f);
            wp.lineTo(cx + 5.0f, cy - 2.5f);
            wp.lineTo(cx + 5.0f, cy + 2.5f);
        }
        else // Saw Down
        {
            wp.startNewSubPath(cx - 5.0f, cy + 2.5f);
            wp.lineTo(cx - 5.0f, cy - 2.5f);
            wp.lineTo(cx + 5.5f, cy + 2.5f);
        }
        g.strokePath(wp, juce::PathStrokeType(1.3f));
    }

    // 4. Draw Vertical LFO Meter Red Indicator Tick (x=319..327, y=185..285, center y=235)
    const bool lfoOn = apvts.getRawParameterValue("lfoOn")->load() > 0.5f;
    const float lfoVal = lfoOn ? audioProcessor.getLfoMeter() : 0.0f;
    const int lfoTickY = juce::roundToInt(235.0f - juce::jlimit(-1.0f, 1.0f, lfoVal) * 46.0f);
    g.setColour(juce::Colour(0xffff2222));
    g.fillRect(320, lfoTickY - 1, 6, 2);

    // 5. Draw Stereo In / Out Vertical LED Meters (In: x=562..582, Out: x=615..635, y=222..422)
    auto drawMeterColumn = [&](int colX, float levelLin)
    {
        const float dB = juce::Decibels::gainToDecibels(juce::jmax(1.0e-4f, levelLin), -60.0f);
        const float norm = juce::jlimit(0.0f, 1.0f, (dB + 60.0f) / 60.0f);
        const int totalSegs = 50;
        const int litSegs = juce::roundToInt(norm * static_cast<float>(totalSegs));
        for (int s = 0; s < litSegs; ++s)
        {
            const int segY = 420 - (s + 1) * 4;
            if (s >= 46)
                g.setColour(juce::Colour(0xffff3333)); // Clip/Peak top LEDs
            else if (s >= 38)
                g.setColour(juce::Colour(0xff00e5ff)); // Upper cyan LEDs
            else
                g.setColour(juce::Colour(0xff2b88ff)); // Classic Nomad blue LEDs
            g.fillRect(colX, segY, 6, 2);
        }
    };

    drawMeterColumn(562, audioProcessor.getInputLevelL());
    drawMeterColumn(575, audioProcessor.getInputLevelR());
    drawMeterColumn(616, audioProcessor.getOutputLevelL());
    drawMeterColumn(629, audioProcessor.getOutputLevelR());
}

void TDelayAudioProcessorEditor::resized()
{
    // Top Preset Bar (Save, <, Preset LCD, >, Utility)
    saveBtn.setBounds(123, 20, 41, 19);
    prevPreBtn.setBounds(165, 20, 18, 19);
    presetBox.setBounds(184, 20, 174, 19);
    nextPreBtn.setBounds(359, 20, 18, 19);
    utilityBtn.setBounds(378, 20, 41, 19);

    // 6 Black "ON" Pill Toggle Buttons
    filterOnBtn.setBounds(61,  91,  21, 11);
    inLoopBtn.setBounds(390,   63,  21, 11);
    lfoOnBtn.setBounds(78,     197, 21, 11);
    dlySyncBtn.setBounds(63,   325, 21, 11);
    dlyLOnBtn.setBounds(212,   325, 21, 11);
    dlyROnBtn.setBounds(412,   325, 21, 11);

    // 2 Oval Buttons (Sync & Peak Limiter)
    lfoSyncBtn.setBounds(203,   187, 54, 31);
    peakLimitBtn.setBounds(397, 187, 54, 31);

    // 9 Metallic Parameter Boxes (86x51)
    lowCutSlider.setBounds(89,       83,  86, 51);
    resonanceSlider.setBounds(189,   83,  86, 51);
    highCutSlider.setBounds(289,     83,  86, 51);
    overdriveSlider.setBounds(389,   83,  86, 51);

    lfoRateSlider.setBounds(71,      233, 86, 51);
    lfoDepthSlider.setBounds(171,    233, 86, 51);
    stereoWidthSlider.setBounds(395, 233, 86, 51);

    dlyTempoSlider.setBounds(62,     343, 86, 51);
    dlyFeedbackSlider.setBounds(279, 343, 86, 51);

    // L-Delay & R-Delay Triplet ("3") and Dotted (".") Buttons
    dlyLTriBtn.setBounds(260, 364, 15, 13);
    dlyLDotBtn.setBounds(260, 377, 15, 13);
    dlyRTriBtn.setBounds(466, 364, 15, 13);
    dlyRDotBtn.setBounds(466, 377, 15, 13);

    // Bottom Mode Routing Box & Master Bypass Switch
    fxModeBox.setBounds(323, 443, 171, 16);
    bypassBtn.setBounds(561, 445, 78,  22);

    // Right Panel Dark LCD Readout Sliders (Input Level, Output Level, Mix)
    inputLevelSlider.setBounds(562,  79,  76, 19);
    outputLevelSlider.setBounds(562, 121, 76, 19);
    mixSlider.setBounds(562,         163, 76, 19);

    licenseOverlay.setBounds(getLocalBounds());
}
