#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
namespace reference_tdelay
{

// Exact 22 Tempo Sync Divisions decompiled from Liquid Delays II x64.dll (0x1800050e0..0x180005257 & 0x18007aba0..0x18007ac98)
struct SyncDivisionInfo
{
    const char* label;
    double wholeBarRatio; // fraction of a 4/4 bar (4 beats)
    double beatDivisor;   // divisor used in 0x18000e293 (vtable+0x560)
};

static constexpr std::array<SyncDivisionInfo, 22> kSyncDivisions = {{
    { "1/32 Bar",  1.0 / 32.0,  8.0       },
    { "1/16 Bar",  1.0 / 16.0,  4.0       },
    { "1/8T Bar",  1.0 / 12.0,  3.0       },
    { "1/16D Bar", 3.0 / 32.0,  8.0 / 3.0 },
    { "1/8 Bar",   1.0 / 8.0,   2.0       },
    { "1/4T Bar",  1.0 / 6.0,   1.5       },
    { "1/8D Bar",  3.0 / 16.0,  4.0 / 3.0 },
    { "1/4 Bar",   1.0 / 4.0,   1.0       },
    { "1/2T Bar",  1.0 / 3.0,   0.75      },
    { "1/4D Bar",  3.0 / 8.0,   2.0 / 3.0 },
    { "1/2 Bar",   1.0 / 2.0,   0.5       },
    { "1/2D Bar",  3.0 / 4.0,   1.0 / 3.0 },
    { "1 Bar",     1.0,         0.25      },
    { "2T Bar",    4.0 / 3.0,   0.1875    },
    { "1D Bar",    1.5,         1.0 / 6.0 },
    { "2 bars",    2.0,         0.125     },
    { "4T bars",   8.0 / 3.0,   3.0 / 32.0},
    { "3 bars",    3.0,         1.0 / 12.0},
    { "4 bars",    4.0,         0.0625    },
    { "5 bars",    5.0,         0.05      },
    { "6 bars",    6.0,         1.0 / 24.0},
    { "8 bars",    8.0,         0.03125   }
}};

// Decompiled CBrickWallLimiter from Liquid Delays II x64.dll (0x180004560..0x1800046ee & 0x18000ecbd..0x18000ef51)
class CBrickWallLimiter
{
public:
    CBrickWallLimiter()
    {
        // Build exact 32768-entry reciprocal lookup table (0x180004560..0x18000464a)
        lut.resize(32770, 1.0f);
        for (int i = 0; i < 32769; ++i)
        {
            const float val = static_cast<float>(i) * 0.000244140625f; // i / 4096.0f (0x18007a910)
            lut[static_cast<size_t>(i)] = (val <= 1.0f) ? 1.0f : (1.0f / val);
        }
    }

    void prepare(double sampleRate)
    {
        sr = std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0;
        // Exact formula from 0x1800046a0: releaseMs = 75.0f (0x18007b7fc), 1.0 - pow(0.001, 1.0 / (75.0 * sr / 1000.0))
        const double releaseSamples = (75.0 * sr) / 1000.0;
        releaseCoeff = 1.0 - std::pow(0.001, 1.0 / std::max(1.0, releaseSamples));
        reset();
    }

    void reset()
    {
        // 0x180004690: envL = 1.0f, envR = 1.0f
        envGain[0] = 1.0f;
        envGain[1] = 1.0f;
    }

    // Exact cubic soft-clipper + LUT brickwall envelope from 0x18000ecbd..0x18000ee75
    inline float processSample(int ch, float x, bool enabled) noexcept
    {
        x = std::isfinite(x) ? x : 0.0f;
        if (!enabled)
            return x;

        // 1. Cubic soft-clipper: x = x - (x^3) * (1/6) (0x18000ecd5..0x18000ed0d, 0x18007b9bc = 0.166666672f)
        x = juce::jlimit(-1.73205f, 1.73205f, x);
        x = x - (x * x * x) * 0.166666672f;

        // 2. LUT index lookup: min(abs(x) * 4096.0f, 32760.0f) (0x18000ed1b..0x18000ed98)
        const float scaled = std::min(std::fabs(x) * 4096.0f, 32760.0f);
        const int idx = static_cast<int>(scaled);
        const float frac = scaled - static_cast<float>(idx);
        const float targetGain = lut[static_cast<size_t>(idx)]
                               + frac * (lut[static_cast<size_t>(idx + 1)] - lut[static_cast<size_t>(idx)]);

        // 3. Envelope follower with instant attack and exponential release (0x18000eda6..0x18000ee1e)
        float& env = envGain[ch & 1];
        if (env > targetGain)
        {
            env = targetGain;
        }
        else
        {
            env = static_cast<float>(static_cast<double>(env)
                + static_cast<double>(targetGain - env) * releaseCoeff);
        }

        const float out = x * env;
        return (out + 1.0e-18f) - 1.0e-18f;
    }

private:
    double sr = 44100.0;
    double releaseCoeff = 0.002;
    std::vector<float> lut;
    std::array<float, 2> envGain {{ 1.0f, 1.0f }};
};

// Decompiled COverdrive from Liquid Delays II x64.dll (0x180005750..0x1800059dd)
class COverdrive
{
public:
    void prepare(double sampleRate)
    {
        juce::ignoreUnused(sampleRate);
        reset();
        setDrive(0.0f);
    }

    void reset()
    {
        for (int c = 0; c < 2; ++c)
        {
            writePos[c] = 0;
            ring[c].fill(0.0f);
        }
        envFollower.fill(0.0);
    }

    // Exact decompiled equations from 0x1800057f0..0x180005869
    void setDrive(float normDrive) noexcept
    {
        normDrive = juce::jlimit(0.0f, 1.0f, normDrive);
        driveAmount = normDrive;
        // [rbx+0x20]: exp((normDrive * -25.0f) * 0.11512925465) = 10^(-25 * normDrive / 20)
        threshold = std::exp(static_cast<double>(normDrive * -25.0f) * 0.11512925465);
        // [rbx+0x28]: powf(1.0f - normDrive, 10.0f) * 0.6f + 0.4f
        makeupGain = static_cast<double>(std::pow(1.0f - normDrive, 10.0f) * 0.6f + 0.4f);
    }

    // Exact decompiled sample processor from 0x180005870..0x18000593a
    inline float processSample(int ch, float x) noexcept
    {
        // Bypassed when driveAmount <= 0.01 (0x18000de5d: comisd xmm9, [0x18007aa98])
        if (driveAmount <= 0.01f)
            return x;

        x = std::isfinite(x) ? x : 0.0f;
        auto& envelope = envFollower[static_cast<size_t>(ch & 1)];
        const double absX = std::fabs(static_cast<double>(x));
        if (absX > envelope)
            envelope = absX;
        else
            envelope = envelope * 0.01 + absX;

        const double denom = (threshold >= envelope) ? threshold : envelope;
        const float gain = static_cast<float>((1.0 / std::max(1.0e-12, denom)) * makeupGain);

        const int c = ch & 1;
        const int wp = writePos[c] & 0x0f;
        const float xClean = std::isfinite(x) ? (x + 1.0e-18f) - 1.0e-18f : 0.0f;
        ring[c][static_cast<size_t>(wp)] = xClean;
        const float delayed = ring[c][static_cast<size_t>(wp & 0x0f)];
        writePos[c] = (wp + 1) & 0x0f;

        const float out = gain * delayed;
        return (out + 1.0e-18f) - 1.0e-18f;
    }

private:
    float driveAmount = 0.0f;
    double threshold = 1.0;
    double makeupGain = 1.0;
    std::array<double, 2> envFollower {{ 0.0, 0.0 }};
    std::array<std::array<float, 16>, 2> ring {};
    std::array<int, 2> writePos {{ 0, 0 }};
};

// Decompiled CPassFilters from Liquid Delays II x64.dll (0x180005a10..0x180005ea6)
class CPassFilters
{
public:
    void prepare(double sampleRate)
    {
        sr = std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0;
        reset();
    }

    void reset()
    {
        // 0x180005a20: clear state arrays and set cached w0/res to -1.0
        x1.fill(0.0); x2.fill(0.0);
        y1.fill(0.0); y2.fill(0.0);
        svfState1.fill(0.0f);
        svfState2.fill(0.0f);
        lastW0 = -1.0;
        lastResDB = -1.0;
    }

    // Exact decompiled filter setup from 0x180005b80..0x180005cf8
    void setFilterFromNormalized(double cutoffNorm, double resDB, double sampleRate, double minHz, double maxHz) noexcept
    {
        sr = std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0;
        minHz = std::max(22.0, std::min(minHz, sr * 0.45));
        maxHz = std::max(minHz + 1.0, std::min(maxHz, sr * 0.49));

        // Exponential mapping: minHz * 2^(cutoffNorm * log2(maxHz / minHz)) (0x180005c09..0x180005c5c)
        const float ratio = static_cast<float>(maxHz / minHz);
        const double logRatio = (static_cast<double>(std::log(ratio)) * juce::jlimit(0.0, 1.0, cutoffNorm))
                              / static_cast<double>(std::log(2.0f));
        const double freqHz = std::max(minHz, static_cast<double>(std::pow(2.0f, static_cast<float>(logRatio)) * static_cast<float>(minHz)));

        resDB = juce::jlimit(-20.0, 20.0, resDB);
        const double w0 = std::min(0.99, (freqHz * 2.0) / sr);

        if (w0 != lastW0 || resDB != lastResDB)
        {
            calcBiquadCoeffs(w0, resDB);
            lastW0 = w0;
            lastResDB = resDB;
        }
    }

    // Helper when caller passes Hz and Resonance % directly
    void setCoefficients(double cutoffHz, double resonancePct, bool isHighPass) noexcept
    {
        highPassMode = isHighPass;
        const double minHz = isHighPass ? 22.0 : 501.13635;
        const double maxHz = isHighPass ? 11025.0 : 22050.0;
        const double clampedHz = juce::jlimit(minHz, maxHz, cutoffHz);
        const double norm = std::log(clampedHz / minHz) / std::log(maxHz / minHz);
        const double resDB = juce::jlimit(0.0, 100.0, resonancePct) * 0.2; // 0..20 dB (0x18000e136)
        setFilterFromNormalized(norm, resDB, sr, minHz, maxHz);
    }

    // Exact decompiled biquad processor from 0x180005d00..0x180005dc3 (vtable+0x20)
    inline float processSample(int ch, float inSample, bool isHighPass) noexcept
    {
        inSample = std::isfinite(inSample) ? inSample : 0.0f;
        const int c = ch & 1;
        const double prevX1 = x1[c];
        const double prevY1 = y1[c];

        double acc = static_cast<double>(inSample) * b0
                   + prevX1 * b1
                   + x2[c] * b2
                   - prevY1 * a1
                   - y2[c] * a2;

        x2[c] = prevX1;
        y2[c] = prevY1;

        const float xClean = (inSample + 1.0e-18f) - 1.0e-18f;
        const float yClean = (static_cast<float>(acc) + 1.0e-18f) - 1.0e-18f;

        x1[c] = static_cast<double>(xClean);
        y1[c] = static_cast<double>(yClean);

        // 0x180005d82..0x180005dbb: when isHighPass (xmm3 >= 0.5f), returns (inSample - prevY1)!
        if (isHighPass)
        {
            const float hpOut = static_cast<float>(static_cast<double>(inSample) - prevY1);
            return (hpOut + 1.0e-18f) - 1.0e-18f;
        }
        return yClean;
    }

private:
    // Exact decompiled coefficient calculation from 0x180005a80..0x180005b7b (vtable+0x10)
    void calcBiquadCoeffs(double w0, double resDB) noexcept
    {
        const double omega = w0 * 3.14159265359;
        const double damp  = std::pow(10.0, resDB * -0.05) * 0.5 * std::sin(omega);
        const double beta  = 0.5 * (1.0 - damp) / (1.0 + damp);
        const double halfPlusBeta = beta + 0.5;
        const double gamma = halfPlusBeta * std::cos(omega);
        const double alpha = (halfPlusBeta - gamma) * 0.25;

        b0 = 2.0 * alpha;
        b1 = 4.0 * alpha;
        b2 = 2.0 * alpha;
        a1 = -2.0 * gamma;
        a2 = 2.0 * beta;
    }

    double sr = 44100.0;
    bool highPassMode = false;
    double b0 = 1.0, b1 = 0.0, b2 = 0.0, a1 = 0.0, a2 = 0.0;
    double lastW0 = -1.0, lastResDB = -1.0;
    std::array<double, 2> x1 {{ 0.0, 0.0 }}, x2 {{ 0.0, 0.0 }};
    std::array<double, 2> y1 {{ 0.0, 0.0 }}, y2 {{ 0.0, 0.0 }};
    std::array<float, 2> svfState1 {{ 0.0f, 0.0f }}, svfState2 {{ 0.0f, 0.0f }};
};

// Decompiled CLFO from Liquid Delays II x64.dll (0x180004aa0..0x180005710)
// Generates unipolar [0.0 .. depthNorm] 2048-point wavetables used to sweep Low Cut, High Cut & Resonance
class CLFO
{
public:
    CLFO()
    {
        buildWavetables(0.0f);
    }

    void prepare(double sampleRate)
    {
        sr = std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0;
        reset();
    }

    void reset()
    {
        phase[0] = 0.0;
        phase[1] = 0.0;
    }

    void setParameters(float rateHz, float depthNorm, float waveNorm, bool syncEnabled, float syncRateNorm) noexcept
    {
        rate = static_cast<double>( rateHz );
        depth = juce::jlimit(0.0f, 1.0f, depthNorm);
        waveParam = juce::jlimit(0.0f, 1.0f, waveNorm);
        syncMode = syncEnabled ? 1.0f : 0.0f;

        // 0x1800050e0: sync multiplier switch table (0..22)
        const int syncIdx = juce::jlimit(0, 21, static_cast<int>(syncRateNorm * 22.0f));
        static constexpr std::array<double, 22> kLfoSyncMult = {{
            0.125, 1.0 / 7.0, 1.0 / 6.0, 0.2, 0.25, 1.0 / 3.0, 0.375, 0.5,
            2.0 / 3.0, 0.75, 1.0, 4.0 / 3.0, 2.0, 8.0 / 3.0, 3.0, 4.0,
            16.0 / 3.0, 6.0, 8.0, 32.0 / 3.0, 12.0, 16.0
        }};
        syncMultiplier = kLfoSyncMult[static_cast<size_t>(syncIdx)] * 0.25;
    }

    // Exact decompiled CLFO::processSample from 0x1800052c0..0x1800053a3
    inline float tick(int ch = 0) noexcept
    {
        const int c = ch & 1;
        double inc = rate / sr;
        if (syncMode > 0.5f)
            inc *= syncMultiplier;

        phase[c] += inc;
        if (phase[c] >= 1.0)
            phase[c] -= 1.0;
        if (phase[c] < 0.0)
            phase[c] += 1.0;

        const int waveSel = static_cast<int>(waveParam * 4.0f);
        const int tblIdx  = juce::jlimit(0, 2047, static_cast<int>(phase[c] * 2048.0));

        float raw = 0.0f;
        switch (waveSel)
        {
            case 0:  raw = tableSine[static_cast<size_t>(tblIdx)];     break;
            case 1:  raw = tableTriangle[static_cast<size_t>(tblIdx)]; break;
            case 2:  raw = tablePulse[static_cast<size_t>(tblIdx)];    break;
            case 3:  raw = tableSawUp[static_cast<size_t>(tblIdx)];    break;
            default: raw = tableSawDown[static_cast<size_t>(tblIdx)];  break;
        }

        lastOut = juce::jlimit(0.0f, 1.0f, raw * depth);
        return lastOut;
    }

private:
    // Exact wavetable construction from 0x18000548b..0x1800056c9 & 0x180004aa0
    void buildWavetables(float rateNorm) noexcept
    {
        for (int i = 0; i < 2048; ++i)
        {
            // Sine: 0.5 * (sin(((i / 2048.0 - 0.25) * 2.0) * pi) + 1.0)
            const float phaseVal = (static_cast<float>(i) * 0.00048828125f - 0.25f) * 2.0f * 3.14159274f;
            tableSine[static_cast<size_t>(i)] = (std::sin(phaseVal) + 1.0f) * 0.5f;

            // Triangle: 0..1024 -> i / 1024.0, 1024..2048 -> 1.0 - (i - 1024) / 1024.0
            if (i < 1024)
                tableTriangle[static_cast<size_t>(i)] = static_cast<float>(i) * 0.0009765625f;
            else
                tableTriangle[static_cast<size_t>(i)] = 1.0f - static_cast<float>(i - 1024) * 0.0009765625f;
        }

        // Pulse, SawUp, SawDown with anti-click edge ramps (0x180004aa0)
        const int rampLen = std::max(1, 16 - static_cast<int>(rateNorm * -240.99f));
        const int halfEnd = std::max(0, 1024 - rampLen);
        const int fullEnd = std::max(1024, 2048 - rampLen);

        for (int i = 0; i < 2048; ++i)
        {
            if (i < halfEnd)
                tablePulse[static_cast<size_t>(i)] = 1.0f;
            else if (i < 1024)
                tablePulse[static_cast<size_t>(i)] = 1.0f - static_cast<float>(i - halfEnd) / static_cast<float>(rampLen);
            else if (i < fullEnd)
                tablePulse[static_cast<size_t>(i)] = 0.0f;
            else
                tablePulse[static_cast<size_t>(i)] = static_cast<float>(i - fullEnd) / static_cast<float>(rampLen);

            if (i < fullEnd)
            {
                tableSawUp[static_cast<size_t>(i)]   = static_cast<float>(i) / static_cast<float>(fullEnd);
                tableSawDown[static_cast<size_t>(i)] = static_cast<float>(2047 - i) / 2047.0f;
            }
            else
            {
                tableSawUp[static_cast<size_t>(i)]   = 1.0f - static_cast<float>(i - fullEnd) / static_cast<float>(rampLen);
                tableSawDown[static_cast<size_t>(i)] = static_cast<float>(i - fullEnd) / static_cast<float>(rampLen);
            }
        }
    }

    double sr = 44100.0;
    std::array<double, 2> phase {{ 0.0, 0.0 }};
    double rate = 1.0;
    double syncMultiplier = 0.25;
    float depth = 0.5f;
    float waveParam = 0.0f;
    float syncMode = 0.0f;
    float lastOut = 0.0f;

    std::array<float, 2048> tableSine {};
    std::array<float, 2048> tableTriangle {};
    std::array<float, 2048> tablePulse {};
    std::array<float, 2048> tableSawUp {};
    std::array<float, 2048> tableSawDown {};
};

// Decompiled CDelayLine from Liquid Delays II x64.dll (0x180004720..0x1800049ee)
class CDelayLine
{
public:
    void prepare(double sampleRate)
    {
        sr = std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0;
        // 0x18000493d: maxSamples = (int)(sr * 10.0) (0x18007a990 = 10.0)
        maxSamples = std::max(4, static_cast<int>(std::ceil(sr * 10.0)) + 2);
        for (int c = 0; c < 2; ++c)
        {
            buffer[c].assign(static_cast<size_t>(maxSamples), 0.0f);
            writePos[c] = 0;
            delaySamples[c] = static_cast<float>(sr * 0.25);
            onOff[c] = 1.0f;
        }
        feedback = 0.33f;
    }

    void reset()
    {
        for (int c = 0; c < 2; ++c)
        {
            std::fill(buffer[c].begin(), buffer[c].end(), 0.0f);
            writePos[c] = 0;
        }
    }

    // Exact decompiled parameter setter from 0x1800047c0..0x180004842
    void setChannelOnOff(int ch, bool enabled) noexcept
    {
        onOff[ch & 1] = enabled ? 1.0f : 0.0f;
    }

    void setTargetDelayMs(int ch, double delayMs) noexcept
    {
        const double samps = sr * 0.001 * std::max(0.0, delayMs);
        delaySamples[ch & 1] = static_cast<float>(juce::jlimit(1.0, static_cast<double>(maxSamples - 2), samps));
    }

    void setFeedback(float fbNorm) noexcept
    {
        feedback = juce::jlimit(0.0f, 1.0f, fbNorm);
    }

    // Exact decompiled CDelayLine::processSample from 0x180004850..0x1800048dc
    // Reads delayed sample `xmm2 = buf[readIdx]`, writes `delayed * feedback + x` into `buf[writeIdx]`,
    // and returns `delayed` (or `x` if channel delay is switched Off).
    inline float processSample(int ch, float x) noexcept
    {
        const int c = ch & 1;
        const float xClean = std::isfinite(x) ? (x + 1.0e-18f) - 1.0e-18f : 0.0f;
        const int dSamps = juce::jlimit(1, maxSamples - 1, static_cast<int>(delaySamples[c]));
        const int wIdx = writePos[c];

        int rIdx = wIdx - dSamps;
        if (rIdx < 0)
            rIdx += maxSamples;
        if (rIdx >= maxSamples)
            rIdx -= maxSamples;

        auto& buf = buffer[c];
        const float stored = buf[static_cast<size_t>(rIdx)];
        const float delayed = std::isfinite(stored) ? stored : 0.0f;
        buf[static_cast<size_t>(wIdx)] = delayed * feedback + xClean;

        if (++writePos[c] >= maxSamples)
            writePos[c] = 0;

        if (onOff[c] == 0.0f)
            return xClean;

        return (delayed + 1.0e-18f) - 1.0e-18f;
    }

private:
    double sr = 44100.0;
    int maxSamples = 441000;
    std::array<std::vector<float>, 2> buffer;
    std::array<int, 2> writePos {{ 0, 0 }};
    std::array<float, 2> delaySamples {{ 11025.0f, 22050.0f }};
    std::array<float, 2> onOff {{ 1.0f, 1.0f }};
    float feedback = 0.33f;
};

struct FactoryPreset
{
    const char* name;
    int fxMode;         // 0..5
    float inputDb;      // -24..+24
    float outputDb;     // -24..+24
    float mixPct;       // 0..100
    bool dlyLOn;
    bool dlyROn;
    bool dlySync;
    int dlyLXTime;      // 0..21
    int dlyRXTime;      // 0..21
    bool dlyLDot;
    bool dlyRDot;
    bool dlyLTri;
    bool dlyRTri;
    float dlyTempo;     // 40..500
    float dlyFeedback;  // 0..100
    bool inLoop;
    bool filterOn;
    bool hdFilter;
    float lowCutHz;     // 22..11025
    float highCutHz;    // 501..22050
    float resonancePct; // 0..100
    float overdrivePct; // 0..100
    bool lfoOn;
    bool lfoSync;
    float lfoRateHz;    // 0.05..22
    float lfoDepthPct;  // 0..100
    int lfoWave;        // 0..4
    float stereoWidth;  // 0..100
    bool peakLimit;
};

} // namespace reference_tdelay
