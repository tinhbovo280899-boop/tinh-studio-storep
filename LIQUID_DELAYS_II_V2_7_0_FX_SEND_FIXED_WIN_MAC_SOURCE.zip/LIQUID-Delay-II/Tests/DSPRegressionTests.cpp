#include "dsp/DelayComponents.h"
#include <cstdio>
#include <limits>
#include <cmath>
#include <vector>
static int failures=0;
#define CHECK(x) do { if(!(x)){std::printf("FAIL line %d: %s\n",__LINE__,#x);++failures;} }while(0)

int main(){int cases=0;
 for(double sr:{8000.,16000.,32000.,44100.,48000.,96000.,192000.}){
  tdelay::CDelayLine d;d.prepare(sr);d.setFeedback(.5f);d.setTargetDelayMs(0,100);d.setTargetDelayMs(1,150);
  int firstL=-1,firstR=-1;for(int i=0;i<int(sr*.5);++i){float l=d.processSample(0,i==0?1.f:0.f),r=d.processSample(1,i==0?1.f:0.f);CHECK(std::isfinite(l)&&std::isfinite(r));if(l>.9f&&firstL<0)firstL=i;if(r>.9f&&firstR<0)firstR=i;if(i==int(sr*.2))CHECK(std::abs(l-.5f)<1e-6);}
  CHECK(firstL==int(sr*.1));CHECK(firstR==int(sr*.15));d.reset();CHECK(d.processSample(0,0)==0);
  d.processSample(0,std::numeric_limits<float>::quiet_NaN());for(int i=0;i<int(sr*.2);++i)CHECK(std::isfinite(d.processSample(0,0)));
  tdelay::CLFO lfo;lfo.prepare(sr);lfo.setParameters(1,1,0,false,0);float maximum=0;for(int i=0;i<int(sr);++i){float v=lfo.tick();CHECK(v>=0&&v<=1);maximum=std::max(maximum,v);}CHECK(maximum>.999f);
  tdelay::CPassFilters hp,lp;hp.prepare(sr);lp.prepare(sr);hp.setCoefficients(11025,100,true);lp.setCoefficients(22050,100,false);
  for(int i=0;i<8192;++i){float x=i==20?std::numeric_limits<float>::infinity():.1f*std::sin(i*.7f);CHECK(std::isfinite(lp.processSample(0,hp.processSample(0,x,true),false)));}
  ++cases;
 }
 tdelay::COverdrive drive;drive.prepare(48000);drive.setDrive(.5f);
 for(int i=0;i<1000;++i){float x=.4f*std::sin(i*.17f);CHECK(std::abs(drive.processSample(0,x)-drive.processSample(1,x))<1e-7);}
 drive.processSample(0,std::numeric_limits<float>::quiet_NaN());CHECK(std::isfinite(drive.processSample(0,.1f)));
 tdelay::CBrickWallLimiter lim;lim.prepare(48000);for(int i=-10000;i<=10000;++i)CHECK(std::abs(lim.processSample(i&1,i*.01f,true))<=1.000001f);
 CHECK(std::isfinite(lim.processSample(0,std::numeric_limits<float>::quiet_NaN(),true)));
 std::printf("Delay DSP: %d rate cases + stereo drive/limiter; %d failures\n",cases,failures);return failures?1:0;
}
