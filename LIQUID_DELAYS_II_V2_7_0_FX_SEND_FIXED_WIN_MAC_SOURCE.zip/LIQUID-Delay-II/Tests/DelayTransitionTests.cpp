#include "dsp/DelayComponents.h"
#include "DelayReference.h"
#include <cstdio>
#include <cmath>
#include <random>
#include <limits>
static int failures=0;
#define CHECK(x) do{if(!(x)){std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;}}while(0)
int main(){
 {tdelay::CDelayLine a;reference_tdelay::CDelayLine b;a.prepare(48000);b.prepare(48000);a.setTargetDelayMs(0,100);b.setTargetDelayMs(0,100);a.setFeedback(.5);b.setFeedback(.5);double error=0;for(int i=0;i<96000;++i){float x=i<48000?float(.1*std::sin(i*.2)):0;error=std::max(error,std::abs(double(a.processSample(0,x))-b.processSample(0,x)));}CHECK(error<1e-8);std::printf("Static delay original comparison max error %.9g\n",error);}
 for(double sr:{8000.,32000.,44100.,48000.,96000.,192000.}){tdelay::CDelayLine d;d.prepare(sr);d.setTargetDelayMs(0,100);d.setFeedback(0);double steady=0,changed=0;float prev=0;const int change=int(sr*.5);
  for(int i=0;i<int(sr);++i){if(i==change)d.setTargetDelayMs(0,135);const float y=d.processSample(0,float(.2*std::sin(2*3.14159265358979323846*997*i/sr)));const double jump=std::abs(double(y)-prev);if(i>int(.25*sr)&&i<change)steady=std::max(steady,jump);if(i>=change&&i<change+int(.025*sr))changed=std::max(changed,jump);prev=y;CHECK(std::isfinite(y));}
  std::printf("sr %.0f steady %.9g transition %.9g\n",sr,steady,changed);CHECK(changed<=steady+.0015);
 }
 {tdelay::CDelayLine d;d.prepare(48000);d.setFeedback(.9f);for(int i=0;i<96000;++i){if(i%11==0)d.setTargetDelayMs(0,1+(i%800));CHECK(std::isfinite(d.processSample(0,float(.01*std::sin(i*.13)))));}}
 {tdelay::CDelayLine d;d.prepare(48000);d.setFeedback(std::numeric_limits<float>::quiet_NaN());d.setTargetDelayMs(0,1);double energy=0;for(int i=0;i<1000;++i){const float v=d.processSample(0,i==0?.2f:0);CHECK(std::isfinite(v));energy+=double(v)*v;}CHECK(energy>0);}
 std::printf("Delay transitions: %d failures\n",failures);return failures?1:0;
}
