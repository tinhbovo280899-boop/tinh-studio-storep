# LIQUID DELAYS II — đổi delay êm hơn, preset FX Send

- Khi Time/BPM đổi sau khi audio đã chạy, dùng hai đầu đọc chuyển trộn tuyến tính trong 20 ms thay vì nhảy đầu đọc ngay. Feedback lấy mẫu đã trộn; không cấp buffer mới trong audio callback. Thay đổi tới dồn dập được xếp về target mới nhất sau transition hiện tại.
- Khi khởi tạo/reset, target được nhận ngay nên vị trí echo cũ không bị trễ thêm 20 ms. Ở delay cố định, output được đối chiếu với line gốc.
- Giữ nguyên 13 preset cũ, thứ tự routing, chất filter/drive và feedback. Thêm Vocal Support - FX Send và Vocal Slap - FX Send, Mix 100%, InLoop Off, hai delay On, LFO/Drive tắt.
- Thêm tooltip giải thích InLoop và channel Off có thể đưa tiếng trực tiếp vào wet return; helper Windows build cả test transition mới trước khi chạy ctest.

## Các chức năng giữ đúng phạm vi cũ

HDFilter vẫn là tham số lưu state, chưa có DSP riêng; không thêm chế độ mới vào nó. Filter/drive nằm ngoài feedback, nên không tự lọc tối thêm qua mỗi vòng. Hai line stereo không chuyển feedback qua lại như ping-pong thật. Các mục này được ghi rõ thay vì âm thầm đổi chất tiếng theo tên preset.

Với FX Send muốn chỉ có echo: Mix 100%, InLoop Off, cả L/R On. Dùng send/return để chỉnh lượng. Tắt một channel Delay sẽ cho channel đó passthrough theo thiết kế cũ.

Feedback 100% có thể không tắt đuôi; delay rất dài ở BPM thấp vẫn bị giới hạn khoảng 9,99 s. Việc crossfade giảm bước nhảy đầu đọc, không chứng minh mọi cách automation/BPM trên mọi vocal đều không có click.

Cách build/installer theo README và menu gốc. Bỏ LTO bắt buộc để giảm bộ nhớ lúc build/link; không đổi công thức DSP đang chạy ổn định.

## Phạm vi xác minh

ZIP là mã nguồn dành cho Windows/macOS, chưa phải plugin hoặc bộ cài Windows/macOS đã biên dịch. Kiểm thử native hiện thực hiện trên Linux; xem TEST_RESULTS_BATCH sau khi đóng gói. Chưa có bản vocal của anh để xác nhận cảm giác mềm/quyện. Không tuyên bố tương đương 1:1 thuật toán của hãng; các comment địa chỉ/nguồn tham khảo cũ không phải kết quả xác minh đó.

Giữ plugin ID, ID tham số và các preset cũ theo thứ tự ban đầu. Preset FX Send được thêm cuối danh sách; preset mới không tự áp lên project cũ. Sao lưu project/plugin trước khi thay bản để nghe A/B.
