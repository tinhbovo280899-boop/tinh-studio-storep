#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
found=0
for bundle in "$ROOT"/_EXPORT_MAC/apps/*.app "$ROOT"/_EXPORT_MAC/vst3/*.vst3 "$ROOT"/_EXPORT_MAC/au/*.component; do
    [[ -d "$bundle" ]] || continue
    found=1
    executable="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$bundle/Contents/Info.plist")"
    lipo -verify_arch arm64 x86_64 "$bundle/Contents/MacOS/$executable"
    /usr/bin/codesign --verify --strict "$bundle"
    printf 'OK: %s (arm64 + x86_64, signature verified)\n' "$(basename "$bundle")"
done
if [[ "$found" != 1 ]]; then printf 'No export found; run MAC_1 first.\n' >&2; exit 1; fi
