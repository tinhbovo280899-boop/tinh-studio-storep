#include "Installer\ThuongHieu.iss"
#define MyBuildDir "XuatBan"
#if FileExists(AddBackslash(SourcePath) + "Resources\logo.ico")
  #define MyIcon "Resources\logo.ico"
#else
  #define MyIcon "Resources\logo_macdinh.ico"
#endif

[Setup]
AppId={#MyAppId}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppVerName={#MyAppName} {#MyAppVersion}
AppPublisher={#MyAppPublisher}
VersionInfoProductName={#MyAppName}
VersionInfoDescription={#MyAppName} Setup
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
DefaultDirName={commoncf64}\VST3\{#MyVst3Name}.vst3
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
UsePreviousAppDir=yes
CloseApplications=yes
RestartApplications=no
OutputDir=Output
OutputBaseFilename={#MySetupName}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
SetupIconFile={#MyIcon}
UninstallDisplayName={#MyAppName}
LicenseFile=Installer\DIEU_KHOAN_SU_DUNG.txt

[Languages]
Name: "vi"; MessagesFile: "compiler:Default.isl"

[Messages]
SetupAppTitle=Cài đặt
SetupWindowTitle=Cài đặt %1
UninstallAppTitle=Gỡ cài đặt
UninstallAppFullTitle=Gỡ %1
ButtonBack=< &Quay lại
ButtonNext=&Tiếp >

[InstallDelete]
Type: filesandordirs; Name: "{commoncf64}\VST3\{#MyVst3Name}.vst3\{#MyVst3Name}.vst3"
Type: filesandordirs; Name: "{commoncf64}\VST3\{#MyVst3Name}.vst3\Contents"
Type: files; Name: "{commoncf64}\VST3\{#MyVst3Name}.vst3\*.dll"

[Dirs]
Name: "{commoncf64}\VST3\{#MyVst3Name}.vst3"; Permissions: users-modify
Name: "{userappdata}\LiquidDelaysII"; Permissions: users-modify

[Files]
Source: "{#MyBuildDir}\{#MyVst3Name}.vst3\*"; DestDir: "{commoncf64}\VST3\{#MyVst3Name}.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#MyBuildDir}\HUONG_DAN_KHACH.txt"; DestDir: "{userappdata}\LiquidDelaysII"; Flags: ignoreversion
