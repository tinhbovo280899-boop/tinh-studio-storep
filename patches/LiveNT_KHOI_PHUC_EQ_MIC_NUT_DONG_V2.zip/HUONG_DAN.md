# LiveNT – khôi phục EQ Míc và tinh chỉnh nút đóng

Bản vá dựa trên Source.zip mới nhất anh gửi, SHA-256:
25fb3b8c55a496a27da86d23437d21aa07da0656e3b84d9a7f5e15f5d9f87d37

## Cách áp dụng

- Giữ một bản sao dự án hiện tại.
- Giải nén vào thư mục gốc dự án, chép đè 5 file trong Source rồi build lại.
- Giữ thư viện/SDK và các file khác trong bộ dự án đầy đủ của anh.
- Đây là bản vá source; chưa có file EXE hoặc bộ cài đã build.

## Đã sửa

- Chuột phải MÍC: khôi phục EQ Manny gồm Trầm / Ấm / Rõ lời / Sáng, Cắt ù,
  Nâng cao và Về preset; giữ Giảm ồn. Không đưa comp trở lại popup.
- EQ nối vào VST Manny Marroquin EQ theo cơ chế Tự tìm/Chọn tay đã có ở Cài đặt
  > Gán nút > VST điều khiển. Nếu chưa có EQ thì hiện hướng dẫn gán; Giảm ồn vẫn
  dùng được. Chọn Không dùng EQ sẽ giữ phần EQ ẩn theo lựa chọn đó.
- Nút đóng: biểu tượng nguồn đỏ thường trực, nền dịu, viền mảnh và nét gọn.
  Cùng một renderer cho giao diện đầy đủ và thu gọn; hover/press đổi nhẹ nền.
- Căn chiều cao nhóm nút cửa sổ với nút thao tác cùng hàng. Giữ callback hỏi
  lưu/thoát hiện có.
- Sửa tooltip và hướng dẫn trong app theo chức năng được khôi phục.

## Kiểm tra và giới hạn

- PASS 43 kiểm tra độc lập: callback chỉnh đúng từng dải EQ, NumericMap và
  setParam thật từ source, Cắt ù, Về preset, cùng tồn tại Giảm ồn, xử lý khi
  gỡ plugin/thiếu EQ hoặc chọn Không dùng EQ. Đối tượng VST/UI và tìm plugin là
  mô phỏng; không phải kiểm thử Waves/Windows thật. Chạy ASan + UBSan; tắt
  LeakSanitizer do môi trường.
- Render thân hàm vẽ nút thật qua graphics adapter để xem idle/hover/pressed/
  disabled trên nền xanh/tối/sáng. PNG kèm theo là ảnh minh họa renderer,
  không phải ảnh chạy ứng dụng JUCE hoàn chỉnh.
- Chỉ sửa 5 file liệt kê trong MANIFEST.json. Các thuật toán audio/scanner trong
  Source.zip mới nhất của anh được giữ nguyên.
- Chưa build/chạy toàn bộ DAW do thiếu bộ JUCE đã vá, module CMake và SDK/test
  của dự án đầy đủ. Chưa xác nhận DPI, native editor và audio trên Windows.

Bản này sửa lỗi mất menu và hình thức nút đóng. Chưa sửa những lỗi thuật toán
đã đánh giá riêng: dry/wet giảm ồn lệch trễ, skip WaveShell VST2 khi có VST3,
cache kết quả kiểm tra plugin chưa an toàn và khóa chờ probe trên UI.
Không coi bản vá giao diện này là bản xác nhận toàn bộ DAW đã ổn định.

## Thử sau khi build

1. Chuột phải Míc với Manny EQ ở ô đang dùng: bốn dải hoạt động và vẫn có
   Giảm ồn. Kiểm tra Cắt ù/Nâng cao, lưu/mở lại dự án và gán EQ sang ô khác.
2. Gỡ hoặc bypass EQ: không crash; thiếu EQ có hướng dẫn gán, Giảm ồn vẫn có.
3. Kiểm tra nút đóng khi đứng yên/rê/nhấn ở ngang/dọc/thu gọn, theme đang dùng
   và Windows scale 100/125/150 %. Hủy trong hộp hỏi lưu phải giữ app mở.
