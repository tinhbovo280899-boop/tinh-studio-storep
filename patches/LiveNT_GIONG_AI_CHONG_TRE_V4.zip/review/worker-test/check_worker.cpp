#include "NativeWorker.hpp"
#include "engine/VoiceEngine.h"
#include <chrono>
#include <iostream>
#include <string>
#include <thread>
#include <vector>
using namespace std::chrono_literals;
static void drain(rvc::NativeWorker& w) { float out[8192]; while(w.popOutput(out,8192)) {} }
static bool waitState(rvc::NativeWorker& w) {
    for(int i=0;i<1000;++i) {
        if(w.isReady() || w.status()==rvc::kStatusError) return true;
        std::this_thread::sleep_for(1ms);
    }
    return false;
}
int main(int argc,char** argv) {
    if(argc!=2) return 2;
    std::string mode=argv[1];
    rvc::NativeWorker w("test-models","test-runtime");
    w.setSampleRate(48000); w.setParameter(rvc::kParamBlockMs,40);
    w.setPath(rvc::kStateModelPath,mode.c_str()); w.setOffline(mode=="offline"); w.setEnabled(true);
    if(!waitState(w)) return 3;
    const auto initial=w.latencyFrames();
    if(w.isReady()) {
        drain(w);
        std::vector<float> x(w.blockFrames(),.25f);
        for(int k=0;k<10 && w.isReady();++k) {
            int before=tvocal::completed.load();
            if(w.pushInput(x.data(),x.size())!=x.size()) return 4;
            for(int n=0;n<200 && tvocal::completed.load()==before && w.isReady();++n) std::this_thread::sleep_for(1ms);
            std::this_thread::sleep_for(2ms); drain(w);
        }
    }
    bool stopped=!w.isReady();
    const auto status=w.status();
    const auto finalLatency=w.latencyFrames();
    std::string msg=w.statusText(), info=w.voiceInfo();
    bool offlineRestart=true;
    if(mode=="slow") {
        w.setOffline(true); w.restartStream();
        offlineRestart=waitState(w) && w.isReady();
    }
    std::cout << "{\"mode\":\""<<mode<<"\",\"initial_frames\":"<<initial<<",\"final_frames\":"<<finalLatency
              <<",\"stopped\":"<<(stopped?"true":"false")<<",\"status\":"<<status
              <<",\"offline_restart\":"<<(offlineRestart?"true":"false")
              <<",\"explains_overload\":"<<(msg.find("không kịp")!=std::string::npos?"true":"false")
              <<",\"explains_gpu_fallback\":"<<(info.find("CUDA DLL absent")!=std::string::npos?"true":"false")<<"}\n";
}
