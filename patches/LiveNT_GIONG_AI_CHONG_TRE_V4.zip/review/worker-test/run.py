from pathlib import Path
import argparse, json, os, shutil, subprocess
root=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Test actual NativeWorker scheduling with stub inference; no AI models used.')
parser.add_argument('--baseline',type=Path,help='Optional original Source/VoiceAI directory for before/after regression comparison.')
args=parser.parse_args()
sources={'after':root.parent.parent/'Source'/'VoiceAI'}
if args.baseline: sources={'before':args.baseline,**sources}
results={}
for label,src in sources.items():
    build=root/label
    (build/'engine').mkdir(parents=True,exist_ok=True)
    for name in ('NativeWorker.cpp','NativeWorker.hpp','RvcParameters.hpp','SpscRing.hpp'):
        shutil.copy2(src/name,build/name)
    for name in ('OrtRuntime.h','VoiceEngine.h'): shutil.copy2(root/'engine'/name,build/'engine'/name)
    shutil.copy2(root/'check_worker.cpp',build/'check_worker.cpp')
    cmd=['g++','-std=c++17','-pthread','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer',str(build/'NativeWorker.cpp'),str(build/'check_worker.cpp'),'-o',str(build/'check_worker')]
    subprocess.run(cmd,check=True)
    results[label]=[]
    for mode in ('fast','slow','warm-spike','runtime-spike','slowdown','offline','fallback'):
        out=subprocess.run([str(build/'check_worker'),mode],check=True,capture_output=True,text=True,env={**os.environ,'ASAN_OPTIONS':'detect_leaks=0'})
        results[label].append(json.loads(out.stdout))
by={k:{row['mode']:row for row in v} for k,v in results.items()}
a=by['after']
if 'before' in by:
    b=by['before']
    assert b['slow']['initial_frames']==12480, b['slow'] # 260 ms despite a 40 ms processing block
    assert b['warm-spike']['initial_frames']==17760, b['warm-spike']
assert a['slow']['stopped'] and a['slow']['final_frames']==0 and a['slow']['explains_overload']
assert a['slow']['offline_restart']
assert a['warm-spike']['initial_frames']==2880 and not a['warm-spike']['stopped']
assert not a['fast']['stopped'] and a['fast']['initial_frames']==a['fast']['final_frames']==2880
assert not a['runtime-spike']['stopped'] and a['runtime-spike']['initial_frames']==a['runtime-spike']['final_frames']
assert a['slowdown']['stopped'] and a['slowdown']['final_frames']==0 and a['slowdown']['explains_overload']
assert not a['offline']['stopped'] and a['offline']['final_frames']>0
assert a['fallback']['explains_gpu_fallback']
(root/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
print('PASS: seven fixed worker scenarios passed with ASan/UBSan (stub inference). Baseline compared if supplied.')
