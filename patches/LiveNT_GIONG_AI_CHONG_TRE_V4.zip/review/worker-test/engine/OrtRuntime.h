#pragma once
#include <string>
namespace tvocal::ort {
inline bool ensureLoaded(const std::string&, std::string&) { return true; }
inline bool cudaAvailable() { return true; }
}
