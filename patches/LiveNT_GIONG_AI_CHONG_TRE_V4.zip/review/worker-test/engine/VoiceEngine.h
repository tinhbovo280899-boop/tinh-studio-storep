#pragma once
// Test double: supplies deterministic inference timings, not an AI model.
#include <algorithm>
#include <atomic>
#include <string>
namespace tvocal {
inline std::atomic<int> completed {0};
struct EngineSettings { int sampleRate=48000; double blockMs=120, crossfadeMs=20, extraMs=350; };
struct EngineParams { float pitch=0, formant=0, indexRate=0, rmsMix=.5f, threshold=-60; int f0Method=0; };
enum class Provider {Cpu, DirectML, Cuda};
class VoiceEngine {
    std::string mode; bool gpu=false, live=false; int b=1920, warmCalls=0, calls=0; double ms=5;
public:
    void load(const std::string&, const std::string&, const std::string& voice, Provider p, int) {
        mode=voice; gpu=p!=Provider::Cpu && mode!="fallback"; completed=0;
    }
    void configure(const EngineSettings& s) { b=int(s.sampleRate*s.blockMs/1000); live=false; warmCalls=calls=0; }
    void loadIndex(const std::string&) {}
    void reset() { live=true; calls=0; }
    int blockFrames() const { return b; }
    bool usingGpu() const { return gpu; }
    std::string voiceInfo() const { return "TEST DOUBLE"; }
    const char* gpuProviderName() const { return gpu?"CUDA":"CPU"; }
    std::string gpuFallbackReason() const { return mode=="fallback"?"TEST: CUDA DLL absent":""; }
    double effectiveCrossfadeMs() const { return 20; }
    void process(const float* in, float* out, const EngineParams&) {
        int n=live?++calls:++warmCalls;
        ms=(mode=="slow" || mode=="offline")?200:5;
        if(mode=="warm-spike" && !live && n==3) ms=300;
        if(mode=="slowdown" && live) ms=200;
        if(mode=="runtime-spike" && live && n==2) ms=800;
        for(int i=0;i<b;++i) out[i]=-.8f*in[i];
        if(live) completed.fetch_add(1);
    }
    double lastInferMs() const { return ms; }
    double contentMs() const { return ms/4; }
    double f0Ms() const { return ms/4; }
    double encoderMs() const { return ms/4; }
    double decoderMs() const { return ms/4; }
};
}
