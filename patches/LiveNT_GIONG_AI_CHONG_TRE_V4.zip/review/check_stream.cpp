#include "../Source/VoiceAI/VoiceStream.h"
#include <cassert>
#include <deque>
#include <iostream>
#include <random>
struct ScheduledWorker {
    struct Job { size_t due; std::vector<float> samples; };
    size_t B, T, delay, clock=0, lastFinish=0;
    std::deque<float> input, output;
    std::deque<Job> jobs;
    ScheduledWorker(size_t b,size_t t,size_t d):B(b),T(t),delay(d),output(d,0.f) {}
    bool isReady() const {return true;}
    uint32_t generation() const {return 1;}
    size_t latencyFrames() const {return delay;}
    size_t pushInput(const float* p,size_t n) {
        input.insert(input.end(),p,p+n); clock+=n;
        while(input.size()>=B) {
            Job j; j.due=lastFinish=std::max(clock,lastFinish)+T;
            for(size_t i=0;i<B;++i) {j.samples.push_back(-.8f*input.front());input.pop_front();}
            jobs.push_back(std::move(j));
        }
        while(!jobs.empty() && jobs.front().due<=clock) {
            const auto& x=jobs.front().samples; output.insert(output.end(),x.begin(),x.end()); jobs.pop_front();
        }
        return n;
    }
    size_t popOutput(float* p,size_t n) {
        n=std::min(n,output.size()); for(size_t i=0;i<n;++i) {p[i]=output.front();output.pop_front();} return n;
    }
};
int main() {
    constexpr int sr=48000, block=128, frames=sr*5;
    std::vector<float> original(frames);
    std::mt19937 rng(66); std::uniform_real_distribution<float> noise(-.1f,.1f);
    for(auto& v:original) v=noise(rng);
    for(bool slow:{false,true}) {
        size_t delay=slow?46560:8640; // old worker: B=120 ms, T=800 ms -> 970 ms; T=40 -> 180 ms
        ScheduledWorker w(5760,slow?38400:1920,delay);
        livent::voiceai::VoiceStream stream;stream.prepare(sr,block);
        auto out=original; double sum=0; size_t count=0,late=0;
        for(int t=0;t<frames;t+=block) {
            int n=std::min(block,frames-t);stream.process(out.data()+t,nullptr,n,w,false);
            if(t<sr*2) continue;
            if(stream.fallback==2) ++late;
            for(int i=0;i<n;++i) {
                float expected=(slow?1.f:-.8f)*original[t+i-delay];
                double e=out[t+i]-expected;sum+=e*e;++count;
            }
        }
        double rms=std::sqrt(sum/count);
        std::cout<<(slow?"overloaded":"fast")<<": latency_ms="<<1000.*delay/sr<<", late_callbacks="<<late<<", rms_error="<<rms<<"\n";
        assert(rms<1e-7);
        assert(slow?late>500:late==0);
    }
    std::cout<<"PASS: actual VoiceStream returns delayed original audio under sustained simulated AI overload; fast simulated conversion stays aligned.\n";
}
