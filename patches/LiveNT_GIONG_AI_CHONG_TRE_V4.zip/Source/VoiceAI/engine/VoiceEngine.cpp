#include "VoiceEngine.h"
#include "OrtRuntime.h"
#include <onnxruntime_cxx_api.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <stdexcept>

#include <cstdlib>
#include <fstream>

namespace tvocal {
namespace {

// Debug: TVOCAL_DUMP=<dir> writes intermediate arrays per block (tests only).
thread_local int gDumpBlock = 0;
void dump (const char* name, const void* data, size_t bytes)
{
    const char* dir = std::getenv ("TVOCAL_DUMP");
    if (! dir) return;
    std::ofstream f (std::string (dir) + "/" + std::to_string (gDumpBlock) + "_" + name + ".bin", std::ios::binary);
    f.write (static_cast<const char*> (data), static_cast<std::streamsize> (bytes));
}
template <typename T> void dumpv (const char* name, const std::vector<T>& v) { dump (name, v.data(), v.size() * sizeof (T)); }

constexpr double kPi = 3.14159265358979323846;

Ort::SessionOptions makeOptions (bool gpu, int threads)
{
    Ort::SessionOptions so;
    so.SetGraphOptimizationLevel (GraphOptimizationLevel::ORT_ENABLE_ALL);
    // Inside a DAW: ONNX Runtime's worker threads must not spin (busy-wait) between runs, or the four
    // sessions keep several CPU cores at 100 % and the host's audio and GUI threads stutter.
    so.AddConfigEntry ("session.intra_op.allow_spinning", "0");
    so.AddConfigEntry ("session.inter_op.allow_spinning", "0");
    // On the GPU the CPU only runs small shape ops: one thread is enough.
    so.SetIntraOpNumThreads (gpu ? 1 : threads);
    so.SetInterOpNumThreads (1);
    if (gpu)
    {
        so.DisableMemPattern();
        so.SetExecutionMode (ExecutionMode::ORT_SEQUENTIAL);
    }
    return so;
}

#ifdef _WIN32
std::wstring widen (const std::string& s)
{
    std::wstring w;
    // UTF-8 -> UTF-16 (paths may contain Vietnamese)
    for (size_t i = 0; i < s.size();)
    {
        uint32_t c = static_cast<unsigned char> (s[i]);
        int n = c < 0x80 ? 0 : (c >> 5) == 6 ? 1 : (c >> 4) == 14 ? 2 : 3;
        c = n == 0 ? c : n == 1 ? (c & 0x1f) : n == 2 ? (c & 0x0f) : (c & 0x07);
        for (int k = 1; k <= n && i + k < s.size(); ++k) c = (c << 6) | (static_cast<unsigned char> (s[i + k]) & 0x3f);
        i += static_cast<size_t> (n + 1);
        if (c >= 0x10000) { c -= 0x10000; w.push_back (static_cast<wchar_t> (0xd800 + (c >> 10))); w.push_back (static_cast<wchar_t> (0xdc00 + (c & 0x3ff))); }
        else w.push_back (static_cast<wchar_t> (c));
    }
    return w;
}
#endif

std::unique_ptr<Ort::Session> openFile (Ort::Env& env, const std::string& path, Ort::SessionOptions& so)
{
#ifdef _WIN32
    return std::make_unique<Ort::Session> (env, widen (path).c_str(), so);
#else
    return std::make_unique<Ort::Session> (env, path.c_str(), so);
#endif
}

Ort::Value tensorF (std::vector<float>& data, const std::vector<int64_t>& shape)
{
    static Ort::MemoryInfo mem = Ort::MemoryInfo::CreateCpu (OrtArenaAllocator, OrtMemTypeDefault);
    return Ort::Value::CreateTensor<float> (mem, data.data(), data.size(), shape.data(), shape.size());
}
Ort::Value tensorI (std::vector<int64_t>& data, const std::vector<int64_t>& shape)
{
    static Ort::MemoryInfo mem = Ort::MemoryInfo::CreateCpu (OrtArenaAllocator, OrtMemTypeDefault);
    return Ort::Value::CreateTensor<int64_t> (mem, data.data(), data.size(), shape.data(), shape.size());
}

std::vector<float> runOne (Ort::Session& s, const std::vector<const char*>& names, std::vector<Ort::Value>& inputs,
                           const char* outName, std::vector<int64_t>* outShape = nullptr)
{
    auto out = s.Run (Ort::RunOptions { nullptr }, names.data(), inputs.data(), inputs.size(), &outName, 1);
    auto info = out[0].GetTensorTypeAndShapeInfo();
    if (outShape) *outShape = info.GetShape();
    const float* p = out[0].GetTensorData<float>();
    return { p, p + info.GetElementCount() };
}

} // namespace

VoiceEngine::VoiceEngine() { deterministic_ = std::getenv ("TVOCAL_DETERMINISTIC") != nullptr; }
VoiceEngine::~VoiceEngine() = default;

void VoiceEngine::load (const std::string& contentVecOnnx, const std::string& rmvpeOnnx, const std::string& voicePth, Provider provider, int threads)
{
    model_ = RvcModel::fromPth (voicePth);
    g_ = model_->speakerEmbedding (0);
    if (! env_) env_ = std::make_unique<Ort::Env> (ORT_LOGGING_LEVEL_WARNING, "tvocal");

    gpu_ = false;
    cuda_ = false;
    const bool tryGpu = (provider == Provider::Cuda && ort::cudaAvailable())
                     || (provider == Provider::DirectML && ort::directMLAvailable());
    gpuFallbackReason_.clear();
    if (provider != Provider::Cpu && ! tryGpu)
        gpuFallbackReason_ = provider == Provider::Cuda ? "CUDA không khả dụng trong bộ chạy AI đang nạp."
                                                       : "DirectML không khả dụng trong bộ chạy AI đang nạp.";
    std::string lastError;
    for (int attempt = 0; attempt < 2; ++attempt)
    {
        const bool gpu = tryGpu && attempt == 0;
        try
        {
            Ort::SessionOptions so = makeOptions (gpu, threads);
            if (gpu && ! (provider == Provider::Cuda ? ort::appendCUDA (so, 0)
                                                      : ort::appendDirectML (so, 0)))
            {
                gpuFallbackReason_ = "Không khởi tạo được GPU provider. Kiểm tra DLL CUDA/cuDNN hoặc DirectML và driver.";
                continue;
            }
            // CPU fallback uses its own session options; no GPU EP gets silently attached.
            cv_ = openFile (*env_, contentVecOnnx, so);
            if (model_->config().version == "v1")
            {
                bool projection = false;
                Ort::AllocatorWithDefaultOptions alloc;
                for (size_t i=0;i<cv_->GetOutputCount();++i)
                {
                    const auto name=cv_->GetOutputNameAllocated(i,alloc);
                    if (std::string(name.get())=="feats256") projection=true;
                }
                if (!projection) throw std::runtime_error("ContentVec thiếu feats256 cho giọng RVC v1. Hãy chạy lại chuẩn bị AI và đổi lại contentvec.onnx.");
            }
            rmvpe_ = openFile (*env_, rmvpeOnnx, so);
            const std::string encBytes = model_->buildEncFlow();
            const std::string decBytes = model_->buildDecoder();
            enc_ = std::make_unique<Ort::Session> (*env_, encBytes.data(), encBytes.size(), so);
            dec_ = std::make_unique<Ort::Session> (*env_, decBytes.data(), decBytes.size(), so);
            gpu_ = gpu;
            cuda_ = gpu && provider == Provider::Cuda;
            return;
        }
        catch (const Ort::Exception& e)
        {
            lastError = e.what();
            if (gpu) gpuFallbackReason_ = lastError;
            cv_.reset(); rmvpe_.reset(); enc_.reset(); dec_.reset();
        }
    }
    throw std::runtime_error ("Không mở được mô hình AI: " + lastError);
}

void VoiceEngine::loadIndex (const std::string& path)
{
    if (path.empty()) { index_.reset(); return; }
    auto idx = std::make_unique<FeatureIndex>();
    idx->load (path);
    if (model_ && idx->dim() != model_->config().phoneDim)
        throw std::runtime_error ("File .index không khớp với giọng (" + std::to_string (idx->dim()) + " chiều, giọng cần "
                                  + std::to_string (model_->config().phoneDim) + ").");
    index_ = std::move (idx);
}

std::string VoiceEngine::voiceInfo() const
{
    if (! model_) return {};
    const auto& c = model_->config();
    return c.version + " · " + std::to_string (c.sampleRate / 1000) + "k" + (c.f0 ? "" : " · không cao độ");
}

void VoiceEngine::configure (const EngineSettings& s)
{
    sr_ = s.sampleRate;
    zc_ = std::max (1, sr_ / 100);
    auto frames = [&] (double ms) { return static_cast<int> (std::lround (ms / 1000.0 * sr_ / zc_)) * zc_; };
    blockFrame_ = frames (s.blockMs);
    blockFrame16k_ = 160 * blockFrame_ / zc_;
    crossfadeFrame_ = frames (s.crossfadeMs);
    solaBufferFrame_ = std::min (crossfadeFrame_, 4 * zc_);
    solaSearchFrame_ = zc_;
    extraFrame_ = frames (s.extraMs);
    const int total = extraFrame_ + crossfadeFrame_ + solaSearchFrame_ + blockFrame_;
    inputWav_.assign (static_cast<size_t> (total), 0.f);
    inputWavRes_.assign (static_cast<size_t> (160 * total / zc_), 0.f);
    rmsBuffer_.assign (static_cast<size_t> (4 * zc_), 0.f);
    solaBuffer_.assign (static_cast<size_t> (solaBufferFrame_), 0.f);
    skipHead_ = extraFrame_ / zc_;
    returnLength_ = (blockFrame_ + solaBufferFrame_ + solaSearchFrame_) / zc_;
    fadeIn_.resize (static_cast<size_t> (solaBufferFrame_));
    fadeOut_.resize (fadeIn_.size());
    for (int i = 0; i < solaBufferFrame_; ++i)
    {
        const double t = solaBufferFrame_ > 1 ? static_cast<double> (i) / (solaBufferFrame_ - 1) : 0.0;
        const double s2 = std::sin (0.5 * kPi * t);
        fadeIn_[static_cast<size_t> (i)] = static_cast<float> (s2 * s2);
        fadeOut_[static_cast<size_t> (i)] = 1.f - fadeIn_[static_cast<size_t> (i)];
    }
    toIn16k_.setup (sr_, 16000);
    toHost_.setup (model_ ? model_->config().sampleRate : sr_, sr_);
    cachePitch_.assign (1024, 0);
    cachePitchf_.assign (1024, 0.f);
}

void VoiceEngine::reset()
{
    std::fill (inputWav_.begin(), inputWav_.end(), 0.f);
    std::fill (inputWavRes_.begin(), inputWavRes_.end(), 0.f);
    std::fill (rmsBuffer_.begin(), rmsBuffer_.end(), 0.f);
    std::fill (solaBuffer_.begin(), solaBuffer_.end(), 0.f);
    std::fill (cachePitch_.begin(), cachePitch_.end(), 0);
    std::fill (cachePitchf_.begin(), cachePitchf_.end(), 0.f);
    rng_.seed (1234);
}

// ---------------------------------------------------------------- one block (rvc_worker.process)
void VoiceEngine::process (const float* in, float* out, const EngineParams& p)
{
    const auto t0 = std::chrono::steady_clock::now();
    const size_t B = static_cast<size_t> (blockFrame_);
    std::vector<float> indata (in, in + B);

    if (p.threshold > -60.f)
    {
        std::vector<float> gated (rmsBuffer_);
        gated.insert (gated.end(), indata.begin(), indata.end());
        std::vector<float> r = dsp::rms (gated.data(), gated.size(), 4 * zc_, zc_);
        r.erase (r.begin(), r.begin() + std::min<size_t> (2, r.size()));
        std::copy (gated.end() - 4 * zc_, gated.end(), rmsBuffer_.begin());
        std::vector<float> g2 (gated.begin() + (2 * zc_ - zc_ / 2), gated.end());
        const std::vector<float> db = dsp::amplitudeToDb (r);
        for (size_t i = 0; i < db.size(); ++i)
            if (db[i] < p.threshold)
                for (size_t k = i * static_cast<size_t> (zc_); k < std::min (g2.size(), (i + 1) * static_cast<size_t> (zc_)); ++k) g2[k] = 0.f;
        // like RVC's realtime GUI: the gate looks 2 hops ahead, so it rewrites the last 2 * zc samples too
        indata.assign (g2.begin() + zc_ / 2, g2.end());
    }

    std::copy (inputWav_.begin() + static_cast<std::ptrdiff_t> (B), inputWav_.end(), inputWav_.begin());
    const size_t nw = std::min (indata.size(), inputWav_.size());
    std::copy (indata.end() - static_cast<std::ptrdiff_t> (nw), indata.end(), inputWav_.end() - static_cast<std::ptrdiff_t> (nw));
    const size_t B16 = static_cast<size_t> (blockFrame16k_);
    std::copy (inputWavRes_.begin() + static_cast<std::ptrdiff_t> (B16), inputWavRes_.end(), inputWavRes_.begin());
    const size_t rsIn = B + 2 * static_cast<size_t> (zc_);
    std::vector<float> res = toIn16k_.process (inputWav_.data() + inputWav_.size() - rsIn, rsIn);
    res.erase (res.begin(), res.begin() + std::min<size_t> (160, res.size()));
    std::copy (res.end() - static_cast<std::ptrdiff_t> (B16), res.end(), inputWavRes_.end() - static_cast<std::ptrdiff_t> (B16));

    dumpv ("inres", inputWavRes_);
    std::vector<float> wav = infer (p);
    dumpv ("infer", wav);
    if (! toHost_.identity()) wav = toHost_.process (wav.data(), wav.size());

    if (p.rmsMix < 1.f)
    {
        const float* tail = inputWav_.data() + extraFrame_;
        const size_t n = std::min (wav.size(), inputWav_.size() - static_cast<size_t> (extraFrame_));
        std::vector<float> r1 = dsp::rms (tail, n, 4 * zc_, zc_);
        std::vector<float> r2 = dsp::rms (wav.data(), wav.size(), 4 * zc_, zc_);
        r1 = dsp::interpLinear (r1.data(), r1.size(), wav.size() + 1, true);
        r2 = dsp::interpLinear (r2.data(), r2.size(), wav.size() + 1, true);
        const float expMix = 1.f - p.rmsMix;
        if (std::abs (expMix - 0.5f) < 1e-4f)
        {
            for (size_t i = 0; i < wav.size(); ++i)
                wav[i] *= std::sqrt (r1[i] / std::max (r2[i], 1e-3f));
        }
        else
        {
            for (size_t i = 0; i < wav.size(); ++i)
                wav[i] *= std::pow (r1[i] / std::max (r2[i], 1e-3f), expMix);
        }
    }

    // SOLA
    const int L = solaBufferFrame_, S = solaSearchFrame_;
    int best = 0;
    double bestScore = -1e300;
    for (int o = 0; o <= S; ++o)
    {
        double nom = 0, den = 0;
        for (int k = 0; k < L; ++k) { const double x = wav[static_cast<size_t> (o + k)]; nom += x * solaBuffer_[static_cast<size_t> (k)]; den += x * x; }
        const double score = nom / std::sqrt (den + 1e-8);
        if (score > bestScore) { bestScore = score; best = o; }
    }
    float* w = wav.data() + best;
    for (int k = 0; k < L; ++k) w[k] = w[k] * fadeIn_[static_cast<size_t> (k)] + solaBuffer_[static_cast<size_t> (k)] * fadeOut_[static_cast<size_t> (k)];
    std::copy (w + blockFrame_, w + blockFrame_ + L, solaBuffer_.begin());
    std::copy (w, w + blockFrame_, out);
    ++gDumpBlock;
    lastInferMs_ = std::chrono::duration<double, std::milli> (std::chrono::steady_clock::now() - t0).count();
}

// ---------------------------------------------------------------- rtrvc.RVC.infer
std::vector<float> VoiceEngine::contentVec (const std::vector<float>& wav16k)
{
    std::vector<float> src (wav16k);
    std::vector<int64_t> shape = { 1, static_cast<int64_t> (src.size()) };
    std::vector<Ort::Value> in;
    in.push_back (tensorF (src, shape));
    const bool v1 = model_->config().version == "v1";
    std::vector<int64_t> outShape;
    return runOne (*cv_, { "source" }, in, v1 ? "feats256" : "feats", &outShape);
}

std::vector<float> VoiceEngine::rmvpeF0 (const float* x, size_t n)
{
    int frames = 0;
    std::vector<float> mel = mel_.compute (x, n, frames);
    const int padded = 32 * ((frames - 1) / 32 + 1);
    std::vector<float> melP (static_cast<size_t> (dsp::RmvpeMel::kMels * padded), 0.f);
    for (int m = 0; m < dsp::RmvpeMel::kMels; ++m)
        std::copy (mel.begin() + m * frames, mel.begin() + (m + 1) * frames, melP.begin() + m * padded);
    std::vector<Ort::Value> in;
    in.push_back (tensorF (melP, { 1, dsp::RmvpeMel::kMels, padded }));
    Ort::AllocatorWithDefaultOptions alloc;
    const auto inName = rmvpe_->GetInputNameAllocated (0, alloc);
    const auto outName = rmvpe_->GetOutputNameAllocated (0, alloc);
    std::vector<int64_t> shape;
    std::vector<float> hidden = runOne (*rmvpe_, { inName.get() }, in, outName.get(), &shape);
    return dsp::rmvpeDecode (hidden.data(), frames);
}

void VoiceEngine::f0Post (std::vector<float>& f0, float key, std::vector<int64_t>& coarse) const
{
    // fill unvoiced frames by linear interpolation (np.interp semantics: edges hold)
    std::vector<size_t> voiced;
    for (size_t i = 0; i < f0.size(); ++i) if (f0[i] != 0.f) voiced.push_back (i);
    if (! voiced.empty())
        for (size_t i = 0; i < f0.size(); ++i)
        {
            if (f0[i] != 0.f) continue;
            auto it = std::lower_bound (voiced.begin(), voiced.end(), i);
            if (it == voiced.begin()) f0[i] = f0[*it];
            else if (it == voiced.end()) f0[i] = f0[voiced.back()];
            else { const size_t b = *it, a = *(it - 1); f0[i] = f0[a] + (f0[b] - f0[a]) * static_cast<float> (i - a) / static_cast<float> (b - a); }
        }
    const float ratio = static_cast<float> (std::pow (2.0, key / 12.0));
    const double melMin = 1127.0 * std::log (1.0 + 50.0 / 700.0), melMax = 1127.0 * std::log (1.0 + 1100.0 / 700.0);
    coarse.resize (f0.size());
    for (size_t i = 0; i < f0.size(); ++i)
    {
        f0[i] *= ratio;
        double m = 1127.0 * std::log (1.0 + static_cast<double> (f0[i]) / 700.0);
        if (m > 0) m = (m - melMin) * 254.0 / (melMax - melMin) + 1.0;
        m = std::min (255.0, std::max (1.0, m));
        coarse[i] = static_cast<int64_t> (std::nearbyint (m));
    }
}

std::vector<float> VoiceEngine::infer (const EngineParams& p)
{
    const RvcConfig& cfg = model_->config();
    const int phoneDim = cfg.phoneDim;
    const size_t N = inputWavRes_.size();
    const size_t pLen = N / 160;

    // Trim redundant far-left history before ContentVec and TextEncoder while preserving
    // full causal receptive field for ContentVec, 6-layer windowed self-attention (window=10), and flow.
    const bool dumping = std::getenv ("TVOCAL_DUMP") != nullptr;
    const int head = skipHead_, length = returnLength_;
    const int flowHead = dumping ? std::max (head - 24, 0) : std::max (head - 16, 0);
    const int decHead = head - flowHead;
    const int encHead = dumping ? 0 : std::max (0, (flowHead - 20) & ~1);
    const size_t pLenSub = pLen - static_cast<size_t> (encHead);

    // Instrument CPU-wall inference stages to make bottlenecks measurable on RTX 3060+.
    // These timings may include CPU/GPU synchronization; they are NOT audio end-to-end latency.
    const auto stage0 = std::chrono::steady_clock::now();
    contentMs_ = f0Ms_ = encoderMs_ = decoderMs_ = 0.0;
    // ContentVec features on active causal window [encHead * 160 .. N)
    std::vector<float> feats;
    if (encHead > 0)
    {
        std::vector<float> cvSlice (inputWavRes_.begin() + static_cast<std::ptrdiff_t> (encHead * 160), inputWavRes_.end());
        feats = contentVec (cvSlice);
    }
    else
    {
        feats = contentVec (inputWavRes_);
    }
    contentMs_ = std::chrono::duration<double, std::milli> (std::chrono::steady_clock::now() - stage0).count();
    const size_t T0 = feats.size() / static_cast<size_t> (phoneDim);
    feats.insert (feats.end(), feats.end() - phoneDim, feats.end());   // torch.cat((feats, feats[:, -1:]), 1)
    const size_t T = T0 + 1;

    // .index retrieval on frames >= (skipHead_ - encHead) // 2 (rtrvc.infer)
    if (p.indexRate > 0.f && hasIndex())
    {
        const int k = 8;
        int64_t ids[8];
        float dist[8];
        double wts[8];
        std::vector<float> blended (static_cast<size_t> (phoneDim));
        const size_t tStart = static_cast<size_t> (std::max (0, (skipHead_ - encHead) / 2));
        for (size_t t = tStart; t < T; ++t)
        {
            float* f = feats.data() + t * static_cast<size_t> (phoneDim);
            index_->search (f, k, ids, dist);
            bool ok = true;
            for (int j = 0; j < k; ++j) ok = ok && ids[j] >= 0;
            if (! ok) continue;
            double wsum = 0;
            for (int j = 0; j < k; ++j)
            {
                const double inv = 1.0 / std::max (static_cast<double> (dist[j]), 1e-12);
                wts[j] = inv * inv;
                wsum += wts[j];
            }
            std::fill (blended.begin(), blended.end(), 0.f);
            for (int j = 0; j < k; ++j)
            {
                const float* __restrict v = index_->vector (ids[j]);
                const float wj = static_cast<float> (wts[j] / wsum);
                for (int c = 0; c < phoneDim; ++c) blended[static_cast<size_t> (c)] += v[c] * wj;
            }
            const float ir = p.indexRate, omir = 1.f - p.indexRate;
            for (int c = 0; c < phoneDim; ++c) f[c] = blended[static_cast<size_t> (c)] * ir + omir * f[c];
        }
    }

    // x2 nearest upsample (F.interpolate scale_factor=2), cut to pLenSub
    std::vector<float> phone (pLenSub * static_cast<size_t> (phoneDim));
    for (size_t t = 0; t < pLenSub; ++t)
    {
        const size_t s = std::min (t / 2, T - 1);
        std::copy (feats.begin() + static_cast<std::ptrdiff_t> (s * phoneDim), feats.begin() + static_cast<std::ptrdiff_t> ((s + 1) * phoneDim),
                   phone.begin() + static_cast<std::ptrdiff_t> (t * phoneDim));
    }

    const double factor = std::pow (2.0, p.formant / 12.0);
    const int returnLength2 = static_cast<int> (std::ceil (returnLength_ * factor));
    std::vector<int64_t> pitch;
    std::vector<float> pitchf;
    if (cfg.f0)
    {
        const auto f0Start = std::chrono::steady_clock::now();
        int f0Frame = blockFrame16k_ + (dumping ? 800 : 640);
        f0Frame = 5120 * ((f0Frame - 1) / 5120 + 1) - 160;
        f0Frame = std::min<int> (f0Frame, static_cast<int> (N));
        std::vector<float> f0 = rmvpeF0 (inputWavRes_.data() + N - static_cast<size_t> (f0Frame), static_cast<size_t> (f0Frame));
        std::vector<int64_t> coarse;
        dumpv ("f0raw", f0);
        f0Post (f0, p.pitch - p.formant, coarse);
        const int shift = blockFrame16k_ / 160;
        std::copy (cachePitch_.begin() + shift, cachePitch_.end(), cachePitch_.begin());
        std::copy (cachePitchf_.begin() + shift, cachePitchf_.end(), cachePitchf_.begin());
        const int P = static_cast<int> (f0.size());
        // cache[4 - P :] = pitch[3 : -1]   (P - 4 values)
        for (int k = 0; k < P - 4; ++k)
        {
            cachePitch_[static_cast<size_t> (1024 - (P - 4) + k)] = coarse[static_cast<size_t> (3 + k)];
            cachePitchf_[static_cast<size_t> (1024 - (P - 4) + k)] = f0[static_cast<size_t> (3 + k)];
        }
        pitch.assign (cachePitch_.end() - static_cast<std::ptrdiff_t> (pLenSub), cachePitch_.end());
        pitchf.assign (cachePitchf_.end() - static_cast<std::ptrdiff_t> (pLen), cachePitchf_.end());
        for (auto& v : pitchf) v = static_cast<float> (v * returnLength2 / static_cast<double> (returnLength_));
        f0Ms_ = std::chrono::duration<double, std::milli> (std::chrono::steady_clock::now() - f0Start).count();
    }

    // synthesizer: encoder + flow on frames >= flowHead, decoder on [head, head + length)
    const int T2 = static_cast<int> (pLen) - flowHead;
    const int ic = cfg.interChannels;
    std::vector<float> noise (static_cast<size_t> (ic * T2), 0.f);
    if (! deterministic_)
    {
        std::normal_distribution<float> nd (0.f, 1.f);
        for (auto& v : noise) v = nd (rng_) * 0.66666f;
    }
    std::vector<int64_t> skip = { flowHead - encHead };
    std::vector<float> gv = g_;
    std::vector<Ort::Value> in;
    std::vector<const char*> names;
    in.push_back (tensorF (phone, { 1, static_cast<int64_t> (pLenSub), phoneDim })); names.push_back ("phone");
    if (cfg.f0) { in.push_back (tensorI (pitch, { 1, static_cast<int64_t> (pLenSub) })); names.push_back ("pitch"); }
    in.push_back (tensorF (gv, { 1, cfg.ginChannels, 1 })); names.push_back ("g");
    in.push_back (tensorI (skip, { 1 })); names.push_back ("skip");
    in.push_back (tensorF (noise, { 1, ic, T2 })); names.push_back ("noise");
    std::vector<int64_t> zShape;
    dumpv ("phone", phone); dumpv ("pitch", pitch); dumpv ("pitchf", pitchf);
    const auto encoderStart = std::chrono::steady_clock::now();
    std::vector<float> zAll = runOne (*enc_, names, in, "z", &zShape);
    encoderMs_ = std::chrono::duration<double, std::milli> (std::chrono::steady_clock::now() - encoderStart).count();

    // z[:, :, dec_head : dec_head + length]
    std::vector<float> z (static_cast<size_t> (ic * length));
    for (int c = 0; c < ic; ++c)
        std::copy (zAll.begin() + c * T2 + decHead, zAll.begin() + c * T2 + decHead + length, z.begin() + c * length);

    const int upp = cfg.upp();
    std::vector<float> sine;
    if (cfg.f0)
    {
        // SineGen (harmonic_num 0): phase accumulation per frame, as RVC's _f02sine
        const double srD = cfg.sampleRate;
        sine.assign (static_cast<size_t> (length * upp), 0.f);
        double acc = 0.0;                       // fmod-cumulated phase of previous frames
        const auto [lw, lb] = model_->sourceLinear();       // har = tanh(l_linear(sine))
        std::normal_distribution<double> nd (0.0, 1.0);
        for (int f = 0; f < length; ++f)
        {
            const double f0 = pitchf[static_cast<size_t> (head + f)];
            const double step = f0 / srD;
            for (int k = 0; k < upp; ++k)
            {
                const double rad = step * (k + 1) + acc;
                const double uv = f0 > 0.0 ? 1.0 : 0.0;
                double s = std::sin (2.0 * kPi * rad) * 0.1;
                const double nAmp = uv * 0.003 + (1.0 - uv) * 0.1 / 3.0;
                const double nz = deterministic_ ? 0.0 : nAmp * nd (rng_);
                sine[static_cast<size_t> (f * upp + k)] = static_cast<float> (std::tanh (lw * (s * uv + nz) + lb));
            }
            const double last = step * upp;
            const double radTail = std::fmod (last + 0.5, 1.0) - 0.5;
            acc = std::fmod (acc + radTail, 1.0);
        }
    }
    // formant: decoder runs on return_length2 frames (linear resize of z and the excitation)
    if (returnLength2 != length)
    {
        std::vector<float> zr (static_cast<size_t> (ic * returnLength2));
        for (int c = 0; c < ic; ++c)
        {
            auto row = dsp::interpLinear (z.data() + c * length, static_cast<size_t> (length), static_cast<size_t> (returnLength2), false);
            std::copy (row.begin(), row.end(), zr.begin() + c * returnLength2);
        }
        z.swap (zr);
        if (cfg.f0) sine = dsp::interpLinear (sine.data(), sine.size(), static_cast<size_t> (returnLength2 * upp), false);
    }
    in.clear(); names.clear();
    in.push_back (tensorF (z, { 1, ic, returnLength2 })); names.push_back ("z");
    if (cfg.f0) { in.push_back (tensorF (sine, { 1, 1, static_cast<int64_t> (sine.size()) })); names.push_back ("har"); }
    in.push_back (tensorF (gv, { 1, cfg.ginChannels, 1 })); names.push_back ("g");
    dumpv ("z", z); dumpv ("har", sine);
    const auto decoderStart = std::chrono::steady_clock::now();
    std::vector<float> audio = runOne (*dec_, names, in, "audio");
    decoderMs_ = std::chrono::duration<double, std::milli> (std::chrono::steady_clock::now() - decoderStart).count();

    const int unit = cfg.sampleRate / 100;
    const int uppRes = static_cast<int> (std::floor (factor * cfg.sampleRate / 100.0));
    if (uppRes != unit)
    {
        dsp::Resampler r (uppRes, unit);
        const size_t n = std::min (audio.size(), static_cast<size_t> (length * uppRes));
        audio = r.process (audio.data(), n);
    }
    return audio;
}

} // namespace tvocal
