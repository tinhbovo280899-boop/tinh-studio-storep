#pragma once
// Native T-VOCAL voice conversion engine: ContentVec + RMVPE + RVC voice, all on ONNX Runtime.
// process() is a line-by-line port of the realtime path T-VOCAL used through Python
// (rvc_worker.RVCStreamEngine.process + infer/rtrvc.RVC.infer): same buffers, same resamplers,
// same pitch cache, same SOLA crossfade. Not realtime-safe itself: run it on a worker thread.
#include "Dsp.h"
#include "FeatureIndex.h"
#include "RvcModel.h"
#include <memory>
#include <random>
#include <string>
#include <vector>

namespace Ort { struct Env; struct Session; struct SessionOptions; }

namespace tvocal {

struct EngineSettings {
    int sampleRate = 48000;
    double blockMs = 130.0, crossfadeMs = 80.0, extraMs = 1000.0;
};

struct EngineParams {
    float pitch = 12.f;       // semitones
    float formant = 0.f;      // semitones
    float indexRate = 0.f;
    float rmsMix = 0.5f;
    float threshold = -60.f;  // dB
    int f0Method = 0;         // RMVPE only; FCPE requires an actual additional model implementation
};

enum class Provider { Cpu, DirectML, Cuda };

class VoiceEngine {
public:
    VoiceEngine();
    ~VoiceEngine();

    // Loads the shared models (ContentVec, RMVPE) and one voice. Throws std::exception with a
    // user-facing (Vietnamese) message.
    void load (const std::string& contentVecOnnx, const std::string& rmvpeOnnx, const std::string& voicePth,
               Provider provider = Provider::Cpu, int threads = 4);
    void configure (const EngineSettings& settings);
    // Optional .index (RVC "added_*.index"); empty path removes it. Throws on bad files.
    void loadIndex (const std::string& path);
    bool hasIndex() const { return index_ && ! index_->empty(); }
    int blockFrames() const { return blockFrame_; }
    int latencyFrames() const { return 2 * blockFrame_; }
    int voiceSampleRate() const { return model_ ? model_->config().sampleRate : 0; }
    double effectiveCrossfadeMs() const { return 1000.0 * solaBufferFrame_ / std::max (1, sr_); }
    std::string voiceInfo() const;
    bool usingGpu() const { return gpu_; }
    const char* gpuProviderName() const { return gpu_ ? (cuda_ ? "CUDA" : "DirectML") : "CPU"; }
    const std::string& gpuFallbackReason() const { return gpuFallbackReason_; }

    // in / out: exactly blockFrames() mono samples
    void process (const float* in, float* out, const EngineParams& p);
    void reset();
    double lastInferMs() const { return lastInferMs_; }
    double contentMs() const { return contentMs_; }
    double f0Ms() const { return f0Ms_; }
    double encoderMs() const { return encoderMs_; }
    double decoderMs() const { return decoderMs_; }

    // Tests: removes the random parts (flow noise, NSF noise / phase) so results are reproducible.
    void setDeterministic (bool d) { deterministic_ = d; }

private:
    std::vector<float> infer (const EngineParams& p);
    std::vector<float> contentVec (const std::vector<float>& wav16k);
    std::vector<float> rmvpeF0 (const float* x, size_t n);
    void f0Post (std::vector<float>& f0, float keyShift, std::vector<int64_t>& coarse) const;

    std::unique_ptr<Ort::Env> env_;
    std::unique_ptr<Ort::Session> cv_, rmvpe_, enc_, dec_;
    std::unique_ptr<RvcModel> model_;
    std::unique_ptr<FeatureIndex> index_;
    std::vector<float> g_;
    bool gpu_ = false, cuda_ = false, deterministic_ = false;
    std::string gpuFallbackReason_;

    // stream state (names follow rvc_worker.py)
    int sr_ = 48000, zc_ = 480, blockFrame_ = 0, blockFrame16k_ = 0, crossfadeFrame_ = 0;
    int solaBufferFrame_ = 0, solaSearchFrame_ = 0, extraFrame_ = 0, skipHead_ = 0, returnLength_ = 0;
    std::vector<float> inputWav_, inputWavRes_, rmsBuffer_, solaBuffer_, fadeIn_, fadeOut_;
    std::vector<int64_t> cachePitch_;
    std::vector<float> cachePitchf_;
    dsp::Resampler toIn16k_, toHost_;
    dsp::RmvpeMel mel_;
    std::mt19937 rng_ { 1234 };
    double lastInferMs_ = 0.0;
    double contentMs_ = 0.0, f0Ms_ = 0.0, encoderMs_ = 0.0, decoderMs_ = 0.0;
};

} // namespace tvocal
