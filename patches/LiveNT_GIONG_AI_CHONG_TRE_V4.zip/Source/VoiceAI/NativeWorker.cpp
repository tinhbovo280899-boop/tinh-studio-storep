#include "NativeWorker.hpp"
#include "engine/OrtRuntime.h"
#include "engine/VoiceEngine.h"

#include <algorithm>
#include <chrono>
#ifdef _WIN32
 #ifndef NOMINMAX
  #define NOMINMAX
 #endif
 #include <windows.h>
 #include <timeapi.h>
 #pragma comment(lib, "winmm.lib")
#endif
#include <cmath>
#include <exception>

namespace rvc {

NativeWorker::NativeWorker (std::string resourceDir, std::string runtimeDir)
    : resourceDir_ (std::move (resourceDir)), runtimeDir_ (std::move (runtimeDir))
{
    for (auto& p : parameters_) p.store (0.0f);
    parameters_[kParamPitch].store (12.0f);
    parameters_[kParamRmsMix].store (0.5f);
    parameters_[kParamThreshold].store (-60.0f);
    parameters_[kParamBlockMs].store (120.0f);
    parameters_[kParamCrossfadeMs].store (20.0f);
    parameters_[kParamExtraMs].store (350.0f);
    thread_ = std::thread (&NativeWorker::threadMain, this);
}

NativeWorker::~NativeWorker()
{
    stopRequested_.store (true, std::memory_order_release);
    if (thread_.joinable()) thread_.join();
}

void NativeWorker::setEnabled (bool enabled) noexcept
{
    if (enabled_.exchange (enabled, std::memory_order_acq_rel) != enabled)
    {
        ready_.store(false);
        if (enabled) status_.store(kStatusStarting, std::memory_order_release);
        configVersion_.fetch_add (1, std::memory_order_release);
    }
}

void NativeWorker::setSampleRate (double sampleRate) noexcept
{
    if (std::abs (sampleRate_.load (std::memory_order_relaxed) - sampleRate) > 0.5)
    {
        sampleRate_.store (sampleRate, std::memory_order_relaxed);
        configVersion_.fetch_add (1, std::memory_order_release);
    }
}

void NativeWorker::setParameter (ParameterId id, float value) noexcept
{
    if (id >= kParameterCount) return;
    const float old = parameters_[id].exchange (value, std::memory_order_relaxed);
    if ((id == kParamBlockMs || id == kParamCrossfadeMs || id == kParamExtraMs) && std::abs (old - value) > 0.01f)
        configVersion_.fetch_add (1, std::memory_order_release);
}

void NativeWorker::setPath (StateId id, const char* value)
{
    if (! value) return;
    {
        std::lock_guard<std::mutex> lock (pathsMutex_);
        if (id == kStateModelPath) { if (paths_.model == value) return; paths_.model = value; }
        else if (id == kStateIndexPath) { if (paths_.index == value) return; paths_.index = value; }
        else return;   // RVC folder / Python are not used any more
    }
    if (id == kStateModelPath)   // a new index only needs a reconfigure, the voice stays loaded
        modelVersion_.fetch_add (1, std::memory_order_release);
    configVersion_.fetch_add (1, std::memory_order_release);
}

void NativeWorker::setUseGpu (bool gpu) noexcept
{
    {
        std::lock_guard<std::mutex> lock (pathsMutex_);
        if (paths_.gpu == gpu && ! gpuFailed_.load()) return;
        paths_.gpu = gpu;
    }
    gpuFailed_.store (false);   // the user asked again: give the GPU another try
    modelVersion_.fetch_add (1, std::memory_order_release);
    configVersion_.fetch_add (1, std::memory_order_release);
}

std::size_t NativeWorker::pushInput (const float* samples, std::size_t count) noexcept
{
    ioUsers_.fetch_add(1);
    if (!ready_.load()) { ioUsers_.fetch_sub(1); return 0; }
    const std::size_t pushed = inputRing_.push (samples, count);
    ioUsers_.fetch_sub(1);
    if (pushed != count) droppedBlocks_.fetch_add (1, std::memory_order_relaxed);
    return pushed;
}

std::size_t NativeWorker::popOutput (float* samples, std::size_t count) noexcept
{
    ioUsers_.fetch_add(1);
    if (!ready_.load()) { ioUsers_.fetch_sub(1); return 0; }
    const auto popped = outputRing_.pop(samples,count);
    ioUsers_.fetch_sub(1);
    return popped;
}

std::string NativeWorker::statusText() const { std::lock_guard<std::mutex> l (statusTextMutex_); return statusText_; }
std::string NativeWorker::voiceInfo() const { std::lock_guard<std::mutex> l (statusTextMutex_); return voiceInfo_; }

void NativeWorker::setStatus (int status, const std::string& text)
{
    status_.store (status, std::memory_order_release);
    std::lock_guard<std::mutex> l (statusTextMutex_);
    statusText_ = text;
}

NativeWorker::Paths NativeWorker::pathsSnapshot() const { std::lock_guard<std::mutex> l (pathsMutex_); return paths_; }

uint32_t NativeWorker::calculateBlockFrames() const noexcept
{
    const double sr = sampleRate_.load (std::memory_order_relaxed);
    const double zc = std::max (1.0, std::floor (sr / 100.0));
    const double seconds = parameters_[kParamBlockMs].load (std::memory_order_relaxed) / 1000.0;
    const auto frames = static_cast<uint32_t> (std::round (seconds * sr / zc) * zc);
    return std::clamp<uint32_t> (frames, static_cast<uint32_t> (zc), 131072u);
}

// Latency = one block (the audio has to arrive first) + the time the AI needs for it + a tight safety margin.
uint32_t NativeWorker::latencyFor (int blockFrames, double processMs, double sampleRate) const noexcept
{
    const double margin = 1.05 * processMs + 10.0;   // ms
    const double frames = blockFrames + margin * sampleRate / 1000.0;
    const double zc = std::max (1.0, std::floor (sampleRate / 100.0));   // round up to 10 ms steps
    const double rounded = std::ceil (frames / zc) * zc;
    return static_cast<uint32_t> (std::clamp (rounded, blockFrames + 2.0 * zc, std::max (blockFrames + 2.0 * zc, 4.0 * sampleRate)));
}

bool NativeWorker::rejectSlowRealtime (double processMs)
{
    if (offline_.load (std::memory_order_relaxed)) return false;
    const double blockMs = 1000.0 * blockFrames_.load (std::memory_order_relaxed)
                         / sampleRate_.load (std::memory_order_relaxed);
    if (std::isfinite (processMs) && processMs <= blockMs) return false;
    // More buffering cannot fix a processor whose sustained throughput is below realtime.
    // Stop feeding its queues: the host bypasses AI and removes its reported PDC latency.
    ready_.store (false, std::memory_order_seq_cst);
    latencyFrames_.store (0, std::memory_order_relaxed);
    setStatus (kStatusError, "AI không kịp thời gian thực: "
        + std::to_string (static_cast<int> (std::lround (std::isfinite (processMs) ? processMs : 0.0)))
        + " ms / khối " + std::to_string (static_cast<int> (std::lround (blockMs)))
        + " ms. Đã bỏ qua AI, không giữ trễ AI trên giọng gốc. Giảm NGỮ CẢNH / INDEX, kiểm tra GPU thực tế, rồi tắt/bật GIỌNG để thử lại.");
    return true;
}

// Loads (if needed) and configures the engine; returns false after setting an error status.
bool NativeWorker::prepare (const Paths& paths, bool reloadModel)
{
    bool loading = false;
    const bool wantGpu = paths.gpu && ! gpuFailed_.load();
    try
    {
        if (reloadModel || ! engine_)
        {
            loading = true;
            setStatus (kStatusStarting, "Đang mở bộ chạy AI...");
            std::string error;
            if (! tvocal::ort::ensureLoaded (runtimeDir_, error)) { setStatus (kStatusError, error); return false; }
            setStatus (kStatusLoading, wantGpu ? "Đang nạp giọng mẫu lên card đồ họa..." : "Đang nạp giọng mẫu...");
            auto engine = std::make_unique<tvocal::VoiceEngine>();
            const std::string models = resourceDir_ + "/models/";
            const auto provider = ! wantGpu ? tvocal::Provider::Cpu
                                : tvocal::ort::cudaAvailable() ? tvocal::Provider::Cuda
                                : tvocal::Provider::DirectML;
            engine->load (models + "contentvec.onnx", models + "rmvpe.onnx", paths.model,
                          provider,
                          static_cast<int> (std::max (2u, std::min (4u, std::thread::hardware_concurrency() / 2))));
            engine_ = std::move (engine);
            loadedModel_ = paths.model;
            usingGpu_.store (engine_->usingGpu(), std::memory_order_relaxed);
            std::lock_guard<std::mutex> l (statusTextMutex_);
            voiceInfo_ = engine_->voiceInfo() + " · " + engine_->gpuProviderName();
            if (! engine_->gpuFallbackReason().empty())
                voiceInfo_ += " · GPU không chạy: " + engine_->gpuFallbackReason();
        }
        loading = false;
        tvocal::EngineSettings s;
        s.sampleRate = static_cast<int> (std::lround (sampleRate_.load (std::memory_order_relaxed)));
        s.blockMs = parameters_[kParamBlockMs].load();
        s.crossfadeMs = parameters_[kParamCrossfadeMs].load();
        s.extraMs = parameters_[kParamExtraMs].load();
        engine_->configure (s);
        engine_->loadIndex (paths.index);

        // warm-up block (first GPU run compiles kernels and warms up .index pages), then a clean state
        setStatus (kStatusLoading, "Đang làm nóng bộ xử lý (lần đầu hơi lâu)...");
        const int B = engine_->blockFrames();
        std::vector<float> probe (static_cast<size_t> (B)), out (static_cast<size_t> (B));
        for (int i = 0; i < B; ++i) probe[static_cast<size_t> (i)] = 0.05f * static_cast<float> (std::sin (2.0 * 3.141592653589793 * 220.0 * i / s.sampleRate));
        tvocal::EngineParams p;
        p.pitch = parameters_[kParamPitch].load (std::memory_order_relaxed);
        p.indexRate = parameters_[kParamIndexRate].load (std::memory_order_relaxed);
        p.rmsMix = 0.5f;
        p.formant = parameters_[kParamFormant].load (std::memory_order_relaxed);
        p.threshold = parameters_[kParamThreshold].load (std::memory_order_relaxed);
        p.f0Method = static_cast<int> (std::lround (parameters_[kParamF0Method].load (std::memory_order_relaxed)));
        // Discard kernel compilation, then take the median of three runs so one OS spike
        // neither rejects a usable GPU nor creates a permanent, oversized monitor buffer.
        std::array<double, 3> warmTimes {};
        for (int run = 0; run < 4; ++run)
        {
            engine_->process (probe.data(), out.data(), p);
            if (run > 0) warmTimes[static_cast<size_t> (run - 1)] = engine_->lastInferMs();
        }
        std::sort (warmTimes.begin(), warmTimes.end());
        const double warm = warmTimes[1];
        engine_->reset();

        blockFrames_.store (static_cast<uint32_t> (B), std::memory_order_relaxed);
        inferMs_.store (static_cast<float> (warm), std::memory_order_relaxed);
        if (rejectSlowRealtime (warm)) return false;
        latencyFrames_.store (latencyFor (B, warm, s.sampleRate), std::memory_order_relaxed);
        recentMs_.fill (0.f);
        recentPos_ = 0;
        return true;
    }
    catch (const std::exception& e)
    {
        if (loading)   // a bad index / setting keeps the loaded voice; a failed voice load drops it
        {
            engine_.reset();
            loadedModel_.clear();
        }
        setStatus (kStatusError, e.what());
        return false;
    }
}

void NativeWorker::threadMain()
{
#ifdef _WIN32
    // 1 ms sleeps really are 1 ms (Windows' default timer step is 15.6 ms, which would eat the latency margin)
    timeBeginPeriod (1);
    struct TimerReset { ~TimerReset() { timeEndPeriod (1); } } timerReset;
#endif
    uint64_t activeVersion = 0, activeModel = 0;
    std::vector<float> in, out;
    while (! stopRequested_.load (std::memory_order_acquire))
    {
        const bool enabled = enabled_.load (std::memory_order_acquire);
        const uint64_t version = configVersion_.load (std::memory_order_acquire);
        if (! enabled)
        {
            ready_.store (false, std::memory_order_seq_cst);
            activeVersion = 0;
            setStatus (kStatusOff, "");
            std::this_thread::sleep_for (std::chrono::milliseconds (40));
            continue;
        }
        if (activeVersion != version)
        {
            ready_.store (false, std::memory_order_seq_cst);
            const Paths paths = pathsSnapshot();
            if (paths.model.empty())
            {
                setStatus (kStatusError, "Chưa chọn GIỌNG MẪU (.pth).");
                activeVersion = version;
                continue;
            }
            const uint64_t mv = modelVersion_.load (std::memory_order_acquire);
            activeVersion = version;
            droppedBlocks_.store (0, std::memory_order_relaxed);
            nonFinite_.store (0, std::memory_order_relaxed);
            inferMs_.store (0.0f, std::memory_order_relaxed);
            if (! prepare (paths, mv != activeModel || loadedModel_ != paths.model))
            {
                activeModel = engine_ ? mv : 0;
                continue;   // stays in error until something changes
            }
            activeModel = mv;
            // ready=false prevents new I/O; wait for any operation which already entered.
            while (ioUsers_.load() != 0) std::this_thread::yield();
            inputRing_.resetUnsafe();
            outputRing_.resetUnsafe();
            outputRing_.pushZeros (latencyFrames_.load (std::memory_order_relaxed));
            const char* where = engine_->usingGpu() ? engine_->gpuProviderName()
                              : ! paths.gpu ? "CPU"
                              : gpuFailed_.load() ? "CPU (GPU trả số lỗi nên tự chuyển)"
                              : "CPU (CUDA/DirectML không khả dụng, kiểm tra DLL)";
            setStatus (kStatusReady, std::string ("Sẵn sàng · ") + where
                                     + " · nối mượt " + std::to_string (static_cast<int> (std::lround (engine_->effectiveCrossfadeMs()))) + " ms.");
            generation_.fetch_add (1, std::memory_order_acq_rel);
            ready_.store (true, std::memory_order_release);
        }
        if (status_.load() == kStatusError || ! engine_)
        {
            std::this_thread::sleep_for (std::chrono::milliseconds (40));
            continue;
        }

        const uint32_t frames = blockFrames_.load (std::memory_order_relaxed);
        if (inputRing_.readable() < frames)
        {
            std::this_thread::sleep_for (std::chrono::milliseconds (1));
            continue;
        }
        in.resize (frames); out.resize (frames);
        // Skip expired work to catch up after a transient stall. The fixed playout delay is
        // measured during warm-up; sustained overload is rejected below, not hidden by buffering.
        const bool behind = ! offline_.load (std::memory_order_relaxed)
                         && inputRing_.readable() >= static_cast<size_t> (latencyFrames_.load (std::memory_order_relaxed));
        if (inputRing_.pop (in.data(), frames) != frames) continue;
        if (behind)
        {
            std::fill (out.begin(), out.end(), 0.f);
            outputRing_.push (out.data(), frames);
            droppedBlocks_.fetch_add (1, std::memory_order_relaxed);
            continue;
        }
        tvocal::EngineParams p;
        p.pitch = parameters_[kParamPitch].load (std::memory_order_relaxed);
        p.formant = parameters_[kParamFormant].load (std::memory_order_relaxed);
        p.indexRate = parameters_[kParamIndexRate].load (std::memory_order_relaxed);
        p.rmsMix = parameters_[kParamRmsMix].load (std::memory_order_relaxed);
        p.threshold = parameters_[kParamThreshold].load (std::memory_order_relaxed);
        p.f0Method = static_cast<int> (std::lround (parameters_[kParamF0Method].load (std::memory_order_relaxed)));
        try
        {
            engine_->process (in.data(), out.data(), p);
        }
        catch (const std::exception& e)
        {
            ready_.store (false, std::memory_order_seq_cst);
            setStatus (kStatusError, std::string ("Lỗi khi đổi giọng: ") + e.what());
            continue;
        }
        inferMs_.store (static_cast<float> (engine_->lastInferMs()), std::memory_order_relaxed);
        contentMs_.store (static_cast<float> (engine_->contentMs()), std::memory_order_relaxed);
        pitchMs_.store (static_cast<float> (engine_->f0Ms()), std::memory_order_relaxed);
        encoderMs_.store (static_cast<float> (engine_->encoderMs()), std::memory_order_relaxed);
        decoderMs_.store (static_cast<float> (engine_->decoderMs()), std::memory_order_relaxed);
        // Track recent processing times using the 2nd-highest value (ignoring a single one-off OS scheduling spike)
        recentMs_[recentPos_++ % recentMs_.size()] = static_cast<float> (engine_->lastInferMs());
        if (! offline_.load (std::memory_order_relaxed) && recentPos_ >= 4)
        {
            auto sorted = recentMs_;
            const size_t validCount = std::min (recentPos_, sorted.size());
            std::sort (sorted.begin(), sorted.begin() + static_cast<std::ptrdiff_t> (validCount));
            const double p90 = sorted[validCount >= 3 ? validCount - 2 : validCount - 1];
            double mean = 0.0;
            for (size_t i = 0; i < validCount; ++i) mean += sorted[i] / validCount;
            const double blockMs = 1000.0 * frames / sampleRate_.load (std::memory_order_relaxed);
            // Ignore a single scheduling spike. Repeated slow inference with average time
            // above the block duration cannot catch up, regardless of queue capacity.
            if (p90 > blockMs && rejectSlowRealtime (mean)) continue;
        }
        uint32_t bad = 0;
        for (float& v : out)
            if (! std::isfinite (v)) { v = 0.f; ++bad; }
        if (bad > 0)
        {
            nonFinite_.fetch_add (bad, std::memory_order_relaxed);
            if (engine_->usingGpu() && ! gpuFailed_.exchange (true))
            {
                // NaN / Inf from the GPU: reload the same voice on the CPU
                modelVersion_.fetch_add (1, std::memory_order_release);
                configVersion_.fetch_add (1, std::memory_order_release);
            }
        }
        if (outputRing_.push (out.data(), frames) != frames) droppedBlocks_.fetch_add (1, std::memory_order_relaxed);
    }
}

} // namespace rvc
