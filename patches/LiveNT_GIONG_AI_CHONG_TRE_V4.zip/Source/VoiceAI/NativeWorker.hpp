#pragma once
// T-VOCAL worker thread around the native VoiceEngine (replaces the old Python worker process).
// The audio thread only pushes / pops lock-free rings; loading models and inference run here.
#include "RvcParameters.hpp"
#include "SpscRing.hpp"

#include <array>
#include <atomic>
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

namespace tvocal { class VoiceEngine; }

namespace rvc {

class NativeWorker {
public:
    // resourceDir: folder with models/contentvec.onnx + models/rmvpe.onnx
    // runtimeDir:  folder with tvocal_ort.dll / DirectML.dll (Windows)
    NativeWorker (std::string resourceDir, std::string runtimeDir);
    ~NativeWorker();
    NativeWorker (const NativeWorker&) = delete;
    NativeWorker& operator= (const NativeWorker&) = delete;

    void setEnabled (bool enabled) noexcept;
    void setSampleRate (double sampleRate) noexcept;
    void setParameter (ParameterId id, float value) noexcept;
    void setPath (StateId id, const char* value);
    void setUseGpu (bool gpu) noexcept;

    std::size_t pushInput (const float* samples, std::size_t count) noexcept;
    std::size_t popOutput (float* samples, std::size_t count) noexcept;

    void restartStream() noexcept
    {
        ready_.store(false);
        status_.store(kStatusStarting, std::memory_order_release);
        configVersion_.fetch_add(1, std::memory_order_release);
    }
    bool isReady() const noexcept { return ready_.load (std::memory_order_acquire); }
    int status() const noexcept { return status_.load (std::memory_order_acquire); }
    float inferMs() const noexcept { return inferMs_.load (std::memory_order_relaxed); }
    float contentMs() const noexcept { return contentMs_.load (std::memory_order_relaxed); }
    float pitchMs() const noexcept { return pitchMs_.load (std::memory_order_relaxed); }
    float encoderMs() const noexcept { return encoderMs_.load (std::memory_order_relaxed); }
    float decoderMs() const noexcept { return decoderMs_.load (std::memory_order_relaxed); }
    float droppedBlocks() const noexcept { return static_cast<float> (droppedBlocks_.load (std::memory_order_relaxed)); }
    uint32_t blockFrames() const noexcept { return blockFrames_.load (std::memory_order_relaxed); }
    uint32_t latencyFrames() const noexcept { return latencyFrames_.load (std::memory_order_relaxed); }
    bool usingGpu() const noexcept { return usingGpu_.load (std::memory_order_relaxed); }
    // samples the AI returned as NaN / Inf (replaced by silence); > 0 on GPU switches to CPU automatically
    // bumped every time the worker (re)starts with fresh rings; the audio thread resets its own state then
    uint32_t generation() const noexcept { return generation_.load (std::memory_order_acquire); }
    uint32_t nonFiniteSamples() const noexcept { return nonFinite_.load (std::memory_order_relaxed); }
    // offline rendering: the host waits for every block instead of dropping late ones
    void setOffline (bool offline) noexcept { offline_.store (offline, std::memory_order_relaxed); }
    std::string statusText() const;
    std::string voiceInfo() const;

private:
    struct Paths { std::string model, index; bool gpu = true; };
    void threadMain();
    bool prepare (const Paths& paths, bool reloadModel);
    void setStatus (int status, const std::string& text);
    Paths pathsSnapshot() const;
    uint32_t calculateBlockFrames() const noexcept;
    uint32_t latencyFor (int blockFrames, double processMs, double sampleRate) const noexcept;
    bool rejectSlowRealtime (double processMs);

    static constexpr std::size_t kRingCapacity = 1u << 20;
    SpscFloatRing inputRing_ { kRingCapacity };
    SpscFloatRing outputRing_ { kRingCapacity };

    std::string resourceDir_, runtimeDir_;
    std::array<std::atomic<float>, kParameterCount> parameters_ {};
    std::atomic<unsigned> ioUsers_ { 0 }; // protects ring resets from in-flight callback operations
    std::atomic<bool> enabled_ { false }, stopRequested_ { false }, ready_ { false }, usingGpu_ { false };
    std::atomic<bool> gpuFailed_ { false }, offline_ { false };
    std::atomic<uint32_t> nonFinite_ { 0 }, generation_ { 0 };
    std::atomic<int> status_ { kStatusOff };
    std::atomic<float> inferMs_ { 0.0f };
    std::atomic<float> contentMs_ { 0.f }, pitchMs_ { 0.f }, encoderMs_ { 0.f }, decoderMs_ { 0.f };
    std::atomic<uint32_t> droppedBlocks_ { 0 }, blockFrames_ { 6240 }, latencyFrames_ { 12480 };
    std::atomic<double> sampleRate_ { 48000.0 };
    std::atomic<uint64_t> configVersion_ { 1 }, modelVersion_ { 1 };

    mutable std::mutex pathsMutex_;
    Paths paths_;
    mutable std::mutex statusTextMutex_;
    std::string statusText_, voiceInfo_;

    std::array<float, 16> recentMs_ {};   // last processing times (worker thread only)
    size_t recentPos_ = 0;
    std::unique_ptr<tvocal::VoiceEngine> engine_;
    std::string loadedModel_;
    std::thread thread_;
};

} // namespace rvc
