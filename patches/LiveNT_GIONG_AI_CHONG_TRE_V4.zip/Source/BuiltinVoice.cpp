#include "BuiltinVoice.h"
#include "VoiceAI/VoiceStream.h"
#include "VoiceAI/fast/voice_shift_engine.h"
#include <mutex>
#ifndef LIVENT_ENABLE_VOICE_AI
 #define LIVENT_ENABLE_VOICE_AI 0
#endif
#if LIVENT_ENABLE_VOICE_AI
 #include "VoiceAI/NativeWorker.hpp"
#endif

namespace livent::voiceai
{
struct Voice::Impl
{
    mutable std::mutex settings;
    juce::File model, index;
    bool gpu = true;
    float pitch = 0.f, indexRate = 0.5f;
    int blockMs = 120, contextMs = 350;
    std::atomic<double> rate{48000};
    std::atomic<bool> enabled{false}, exportError{false};
    std::atomic<int> fallback{0};
    std::atomic<float> peakIn{0}, peakWet{0}, peakOut{0};
    std::atomic<uint64_t> late{0};
    VoiceStream stream;
    // 02/11: tai nghe nhanh
    std::atomic<bool> cueOn{false};
    std::atomic<int> cuePair{0};
    std::atomic<float> cueFormant{2.f}, cueVoiceDb{0.f}, cueMusicDb{-3.f}, pitchNow{0.f};
    tvs::VoiceShiftEngine cueShift;
    std::vector<float> cueMono;
    int cueSamples = 0;   // audio thread only
    void captureCue(const juce::AudioBuffer<float>& buffer, int samples, bool shifting) noexcept
    {
        cueSamples = 0;
        if (!cueOn.load(std::memory_order_relaxed) || samples <= 0 || samples > (int) cueMono.size()) return;
        const float* l = buffer.getReadPointer(0);
        const float* r = buffer.getNumChannels() > 1 ? buffer.getReadPointer(1) : l;
        for (int i = 0; i < samples; ++i)
        {
            const float v = 0.5f * (l[i] + r[i]);
            cueMono[(size_t) i] = std::isfinite(v) ? v : 0.f;
        }
        auto s = cueShift.getSettings();
        s.pitchSt = shifting ? juce::jlimit(-12.f, 12.f, pitchNow.load(std::memory_order_relaxed)) : 0.f;
        s.formantSt = shifting ? cueFormant.load(std::memory_order_relaxed) : 0.f;
        s.mixPct = 100.f; s.outDb = 0.f;
        cueShift.setSettings(s);
        cueShift.process(cueMono.data(), cueMono.data(), samples);
        cueSamples = samples;
    }
#if LIVENT_ENABLE_VOICE_AI
    std::unique_ptr<rvc::NativeWorker> owner;
    std::atomic<rvc::NativeWorker*> worker{nullptr}; // published once, stable until Track destruction
    void ensureWorker()
    {
        if (owner) return;
        const auto folder = Voice::dataFolder();
        owner = std::make_unique<rvc::NativeWorker>(folder.getFullPathName().toStdString(),
                  folder.getChildFile("runtime").getFullPathName().toStdString());
        owner->setSampleRate(rate);
        owner->setParameter(rvc::kParamPitch, pitch);
        owner->setParameter(rvc::kParamIndexRate,indexRate);
        owner->setParameter(rvc::kParamBlockMs, static_cast<float>(blockMs));
        owner->setParameter(rvc::kParamCrossfadeMs, 20.f);
        owner->setParameter(rvc::kParamExtraMs, static_cast<float>(contextMs));
        owner->setParameter(rvc::kParamRmsMix, 0.5f);
        owner->setUseGpu(gpu);
        owner->setPath(rvc::kStateModelPath, model.getFullPathName().toRawUTF8());
        owner->setPath(rvc::kStateIndexPath, index.getFullPathName().toRawUTF8());
        worker.store(owner.get(), std::memory_order_release);
    }
#endif
};

Voice::Voice() : impl(std::make_unique<Impl>()) {}
Voice::~Voice() = default;
juce::File Voice::dataFolder()
{
    return juce::File::getSpecialLocation(juce::File::currentExecutableFile).getParentDirectory().getChildFile("VoiceAI");
}
juce::File Voice::bundledModel()
{
    const auto preferred = dataFolder().getChildFile("voices/chiyuki4/chiyuki4.pth");
    if (preferred.existsAsFile()) return preferred;
    const auto files = dataFolder().getChildFile("voices").findChildFiles(juce::File::findFiles, true, "*.pth");
    return files.isEmpty() ? juce::File() : files[0];
}
juce::File Voice::pairedIndex(const juce::File& model)
{
    if (model == juce::File()) return {};
    const auto indexes = model.getParentDirectory().findChildFiles(juce::File::findFiles, false, "added_*.index");
    // Do not silently pick a different voice's index when there are several.
    return indexes.size() == 1 ? indexes[0] : juce::File();
}
void Voice::prepare(double rate, int blockSize)
{
    impl->rate = rate > 0 ? rate : 48000;
    impl->stream.prepare(impl->rate, std::max(4096, blockSize));
    impl->cueMono.assign((size_t) std::max(4096, blockSize), 0.f);
    impl->cueShift.prepare(impl->rate, std::max(4096, blockSize));
    impl->cueSamples = 0;
#if LIVENT_ENABLE_VOICE_AI
    if (auto* w = impl->worker.load(std::memory_order_acquire)) w->setSampleRate(impl->rate);
#endif
}
void Voice::setEnabled(bool on)
{
    std::lock_guard<std::mutex> lock(impl->settings);
#if LIVENT_ENABLE_VOICE_AI
    if (on) impl->ensureWorker();
    impl->enabled.store(on, std::memory_order_release);
    if (auto* w = impl->worker.load(std::memory_order_acquire)) w->setEnabled(on);
#else
    impl->enabled.store(false);
    juce::ignoreUnused(on);
#endif
}
bool Voice::isEnabled() const noexcept { return impl->enabled.load(std::memory_order_acquire); }
void Voice::setModel(const juce::File& file)
{
    std::lock_guard<std::mutex> lock(impl->settings); impl->model = file;
#if LIVENT_ENABLE_VOICE_AI
    if (impl->owner) impl->owner->setPath(rvc::kStateModelPath, file.getFullPathName().toRawUTF8());
#endif
}
void Voice::setIndex(const juce::File& file)
{
    std::lock_guard<std::mutex> lock(impl->settings); impl->index = file;
#if LIVENT_ENABLE_VOICE_AI
    if (impl->owner) impl->owner->setPath(rvc::kStateIndexPath, file.getFullPathName().toRawUTF8());
#endif
}
void Voice::setGpu(bool gpu)
{
    std::lock_guard<std::mutex> lock(impl->settings); impl->gpu = gpu;
#if LIVENT_ENABLE_VOICE_AI
    if (impl->owner) impl->owner->setUseGpu(gpu);
#endif
}
void Voice::setPitch(float value)
{
    value = std::isfinite(value) ? juce::jlimit(-24.f,24.f,value) : 0.f;
    std::lock_guard<std::mutex> lock(impl->settings); impl->pitch = value;
    impl->pitchNow.store(value, std::memory_order_relaxed);
#if LIVENT_ENABLE_VOICE_AI
    if (impl->owner) impl->owner->setParameter(rvc::kParamPitch,value);
#endif
}
void Voice::setIndexRate(float value)
{
    value=std::isfinite(value)?juce::jlimit(0.f,1.f,value):0.5f;
    std::lock_guard<std::mutex> lock(impl->settings);impl->indexRate=value;
#if LIVENT_ENABLE_VOICE_AI
    if(impl->owner)impl->owner->setParameter(rvc::kParamIndexRate,value);
#endif
}
void Voice::setBlockMs(int value)
{
    std::lock_guard<std::mutex> lock(impl->settings); impl->blockMs = juce::jlimit(40,500,value);
#if LIVENT_ENABLE_VOICE_AI
    if (impl->owner) impl->owner->setParameter(rvc::kParamBlockMs,static_cast<float>(impl->blockMs));
#endif
}
void Voice::setContextMs(int value)
{
    std::lock_guard<std::mutex> lock(impl->settings); impl->contextMs = juce::jlimit(200,1500,value);
#if LIVENT_ENABLE_VOICE_AI
    if (impl->owner) impl->owner->setParameter(rvc::kParamExtraMs,static_cast<float>(impl->contextMs));
#endif
}
juce::File Voice::getModel() const { std::lock_guard<std::mutex> lock(impl->settings); return impl->model; }
juce::File Voice::getIndex() const { std::lock_guard<std::mutex> lock(impl->settings); return impl->index; }
bool Voice::getGpu() const { std::lock_guard<std::mutex> lock(impl->settings); return impl->gpu; }
float Voice::getPitch() const { std::lock_guard<std::mutex> lock(impl->settings); return impl->pitch; }
float Voice::getIndexRate() const { std::lock_guard<std::mutex> lock(impl->settings); return impl->indexRate; }
int Voice::getBlockMs() const { std::lock_guard<std::mutex> lock(impl->settings); return impl->blockMs; }
int Voice::getContextMs() const { std::lock_guard<std::mutex> lock(impl->settings); return impl->contextMs; }
bool Voice::isReady() const noexcept
{
#if LIVENT_ENABLE_VOICE_AI
    const auto* w = impl->worker.load(std::memory_order_acquire); return isEnabled() && w && w->isReady();
#else
    return false;
#endif
}
int Voice::latencySamples() const noexcept
{
#if LIVENT_ENABLE_VOICE_AI
    const auto* w = impl->worker.load(std::memory_order_acquire);
    return isEnabled() && w && w->isReady() ? static_cast<int>(w->latencyFrames()) : 0;
#else
    return 0;
#endif
}
void Voice::process(juce::AudioBuffer<float>& buffer, int samples, bool offline, bool allowed)
{
    if (samples <= 0 || buffer.getNumChannels() < 1) return;
    // 02/11: giong nghe nhanh cho tai nghe nguoi hat, lay TRUOC AI (doi tong theo cung cao do voi AI)
    if (!offline) impl->captureCue(buffer, std::min(samples, buffer.getNumSamples()), isEnabled() && allowed);
#if LIVENT_ENABLE_VOICE_AI
    auto* w = impl->worker.load(std::memory_order_acquire);
    if (!w) return;
    const float inputLevel=buffer.getMagnitude(0,0,std::min(samples,buffer.getNumSamples()));
    impl->peakIn.store(std::isfinite(inputLevel)?inputLevel:0.f);
    impl->peakWet.store(0.f); impl->peakOut.store(impl->peakIn.load());
    w->setOffline(offline);
    const bool on = isEnabled() && allowed;
    w->setEnabled(on);
    if (!on) return;
    if (!w->isReady())
    {
        impl->fallback.store(1);
        // On a realtime callback use the untouched mic while loading / after a fault.
        if (offline) impl->exportError.store(true);
        return;
    }
    impl->stream.process(buffer.getWritePointer(0), buffer.getNumChannels()>1 ? buffer.getWritePointer(1) : nullptr,
                         samples, *w, offline);
    impl->peakIn.store(impl->stream.inputPeak); impl->peakWet.store(impl->stream.wetPeak);
    impl->peakOut.store(impl->stream.outputPeak); impl->late.store(impl->stream.lateBlocks);
    impl->fallback.store(impl->stream.fallback);
    if (offline && impl->stream.renderError) impl->exportError.store(true);
#else
    juce::ignoreUnused(buffer, offline, allowed);
#endif
}
juce::String Voice::statusText() const
{
#if LIVENT_ENABLE_VOICE_AI
    if (!isEnabled()) return juce::String::fromUTF8("Đã tắt · mic đi thẳng");
    const auto* w = impl->worker.load(std::memory_order_acquire);
    if (!w) return juce::String::fromUTF8("Chưa mở bộ chạy AI");
    auto text = juce::String::fromUTF8(w->statusText().c_str());
    if (!w->isReady()) return text + juce::String::fromUTF8(" · đang nghe giọng gốc");
    switch (impl->fallback.load())
    {
        case 1: return text + juce::String::fromUTF8(" · đang lấp bộ đệm, nghe giọng gốc");
        case 2: return text + juce::String::fromUTF8(" · thiếu kết quả AI, đang nghe giọng gốc có bù trễ. Kiểm tra thời gian xử lý / khối.");
        case 3: return juce::String::fromUTF8("AI trả im lặng dù có mic · tạm nghe giọng gốc.");
        default: return text;
    }
#else
    return juce::String::fromUTF8("Bản này chưa bật lõi AI. Windows: build bằng 1_BUILD_7_NGAY.bat / 1_BUILD_30_NGAY.bat (không đặt LIVENT_NO_VOICE_AI); macOS chưa hỗ trợ đổi giọng.");
#endif
}
juce::String Voice::metersText() const
{
    auto db=[](float x){return juce::String(juce::Decibels::gainToDecibels(x,-120.f),1);};
    juce::String text = juce::String::fromUTF8("Mức vào / AI / ra: ") + db(impl->peakIn.load()) + " / "
                        + db(impl->peakWet.load()) + " / " + db(impl->peakOut.load()) + " dBFS";
#if LIVENT_ENABLE_VOICE_AI
    if (const auto* w = impl->worker.load(std::memory_order_acquire))
    {
        text += juce::String::fromUTF8("\nXử lý: ") + juce::String(w->inferMs(),1) + " ms / " + juce::String(getBlockMs())
             + juce::String::fromUTF8(" ms mỗi khối · Trễ bộ đệm: ")
             + juce::String(1000.0*latencySamples()/impl->rate,0) + " ms"
             + juce::String::fromUTF8(" · thực tế: ") + (w->usingGpu() ? "GPU" : "CPU")
             + juce::String::fromUTF8("\nDự phòng: ") + juce::String(static_cast<juce::int64>(impl->late.load()))
             + juce::String::fromUTF8(" · khối AI bỏ: ") + juce::String(w->droppedBlocks(),0)
             + juce::String::fromUTF8(" · chạy ") + juce::String::fromUTF8(w->voiceInfo().c_str());
        text += juce::String::fromUTF8("\nChi tiết AI: ContentVec ") + juce::String(w->contentMs(),1)
             + juce::String::fromUTF8(" · RMVPE ") + juce::String(w->pitchMs(),1)
             + juce::String::fromUTF8(" · Encoder ") + juce::String(w->encoderMs(),1)
             + juce::String::fromUTF8(" · Decoder ") + juce::String(w->decoderMs(),1) + " ms";
    }
#endif
    return text;
}
void Voice::setOfflineRendering(bool on)
{
#if LIVENT_ENABLE_VOICE_AI
    auto* w = impl->worker.load(std::memory_order_acquire);
    if (!w) return;
    w->setOffline(on);
    if (!isEnabled()) return;
    const auto old = w->generation();
    w->restartStream();
    if (on)
    {
        impl->exportError.store(false);
        const auto until = std::chrono::steady_clock::now() + std::chrono::seconds(30);
        while ((!w->isReady() || w->generation()==old) && std::chrono::steady_clock::now()<until)
        {
            if (w->status()==rvc::kStatusError) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(2));
        }
        if (!w->isReady() || w->generation()==old) impl->exportError.store(true);
    }
#else
    juce::ignoreUnused(on);
#endif
}
bool Voice::hasExportError() const noexcept { return impl->exportError.load(); }
void Voice::clearExportError() noexcept { impl->exportError.store(false); }
std::unique_ptr<juce::XmlElement> Voice::getState() const
{
    auto x = std::make_unique<juce::XmlElement>("VOICE_AI");
    std::lock_guard<std::mutex> lock(impl->settings);
    x->setAttribute("enabled",isEnabled());
    // Bundled voices relocate with the installation instead of storing the builder's absolute path.
    const auto base = dataFolder();
    const bool bundled = impl->model.isAChildOf(base);
    x->setAttribute("model",bundled ? impl->model.getRelativePathFrom(base) : impl->model.getFullPathName());
    x->setAttribute("bundled",bundled);
    const bool bundledIndex = impl->index.isAChildOf(base);
    x->setAttribute("index",bundledIndex ? impl->index.getRelativePathFrom(base) : impl->index.getFullPathName());
    x->setAttribute("bundledIndex",bundledIndex);
    x->setAttribute("gpu",impl->gpu); x->setAttribute("pitch",impl->pitch); x->setAttribute("indexRate",impl->indexRate);
    x->setAttribute("block",impl->blockMs); x->setAttribute("context",impl->contextMs);
    x->setAttribute("cueOn",getCueOn()); x->setAttribute("cuePair",getCuePair());
    x->setAttribute("cueFormant",getCueFormant()); x->setAttribute("cueVoiceDb",getCueVoiceDb()); x->setAttribute("cueMusicDb",getCueMusicDb());
    return x;
}
void Voice::setState(const juce::XmlElement* x)
{
    setEnabled(false);
    if (!x) return;
    auto path=[&](const char* key,const char* relative) {
        const auto s=x->getStringAttribute(key);
        return s.isEmpty() ? juce::File() : x->getBoolAttribute(relative) ? dataFolder().getChildFile(s) : juce::File(s);
    };
    setModel(path("model","bundled")); setIndex(path("index","bundledIndex"));
    setGpu(x->getBoolAttribute("gpu",true)); setPitch(static_cast<float>(x->getDoubleAttribute("pitch",0)));
    setIndexRate(static_cast<float>(x->getDoubleAttribute("indexRate",0.5)));
    setBlockMs(x->getIntAttribute("block",120)); setContextMs(x->getIntAttribute("context",350));
    setCuePair(x->getIntAttribute("cuePair",0)); setCueFormant(static_cast<float>(x->getDoubleAttribute("cueFormant",2.0)));
    setCueVoiceDb(static_cast<float>(x->getDoubleAttribute("cueVoiceDb",0.0))); setCueMusicDb(static_cast<float>(x->getDoubleAttribute("cueMusicDb",-3.0)));
    setCueOn(x->getBoolAttribute("cueOn",false));
    setEnabled(x->getBoolAttribute("enabled",false));
}
void Voice::setCueOn(bool on) { impl->cueOn.store(on); }
bool Voice::getCueOn() const noexcept { return impl->cueOn.load(); }
void Voice::setCuePair(int pair) { impl->cuePair.store(pair >= 0 && pair < 32 ? pair : -1); }
int Voice::getCuePair() const noexcept { return impl->cuePair.load(); }
void Voice::setCueFormant(float st) { impl->cueFormant.store(std::isfinite(st) ? juce::jlimit(-6.f, 6.f, st) : 2.f); }
float Voice::getCueFormant() const noexcept { return impl->cueFormant.load(); }
void Voice::setCueVoiceDb(float db) { impl->cueVoiceDb.store(std::isfinite(db) ? juce::jlimit(-60.f, 6.f, db) : 0.f); }
float Voice::getCueVoiceDb() const noexcept { return impl->cueVoiceDb.load(); }
void Voice::setCueMusicDb(float db) { impl->cueMusicDb.store(std::isfinite(db) ? juce::jlimit(-60.f, 6.f, db) : -3.f); }
float Voice::getCueMusicDb() const noexcept { return impl->cueMusicDb.load(); }
const float* Voice::takeCueVoice(int samples) noexcept
{
    if (impl->cueSamples != samples || samples <= 0) { impl->cueSamples = 0; return nullptr; }
    impl->cueSamples = 0;
    return impl->cueMono.data();
}
}
