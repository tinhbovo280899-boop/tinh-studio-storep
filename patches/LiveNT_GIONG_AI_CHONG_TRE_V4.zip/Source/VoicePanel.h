#pragma once
#include "Mixer.h"
#include "Theme.h"
#include <vector>

namespace livent::voiceai
{
class Panel final : public juce::Component, private juce::Timer
{
public:
    Panel(Mixer& m, juce::String uuid, std::function<void()> onChangeCallback,
          std::function<juce::StringArray()> outputNames = {}, std::function<int(int)> activatePairFn = {})
        : getOutputNames(std::move(outputNames)), activatePair(std::move(activatePairFn)),
          mixer(m), trackUuid(std::move(uuid)), onChanged(std::move(onChangeCallback))
    {
        title.setText(livent::vn("GIỌNG AI"),juce::dontSendNotification);
        title.setFont(juce::Font(juce::FontOptions(23.f).withStyle("Bold")));
        subtitle.setText(livent::vn("Đổi giọng trên track mic · chuột phải nút GIỌNG để mở bảng này"),juce::dontSendNotification);
        modelLabel.setText(livent::vn("Giọng mẫu"),juce::dontSendNotification);
        indexLabel.setText("Index",juce::dontSendNotification);
        chooseModel.setButtonText(livent::vn("Chọn .pth"));
        chooseIndex.setButtonText(livent::vn("Chọn .index"));
        noIndex.setButtonText(livent::vn("Bỏ index"));
        enabled.setButtonText(livent::vn("Bật đổi giọng"));
        provider.addItem("GPU tự động (CUDA / DirectML)",1); provider.addItem("CPU",2);
        livePreset.setButtonText(livent::vn("Thử LIVE 80 ms"));
        livePreset.setTooltip(livent::vn("Thử nghiệm: 80 ms/300 ms, index 0%. Phải đo thời gian xử lý thực tế trước khi hát live."));
        indexRateLabel.setText(livent::vn("Mức index"),juce::dontSendNotification);
        pitchLabel.setText(livent::vn("Cao độ"),juce::dontSendNotification);
        blockLabel.setText(livent::vn("Khối xử lý"),juce::dontSendNotification);
        contextLabel.setText(livent::vn("Ngữ cảnh"),juce::dontSendNotification);
        auto setup=[](juce::Slider& s,double lo,double hi,double step,const char* unit) {
            s.setRange(lo,hi,step); s.setSliderStyle(juce::Slider::LinearHorizontal);
            s.setTextBoxStyle(juce::Slider::TextBoxRight,false,84,26); s.setTextValueSuffix(unit);
        };
        setup(indexRate,0,100,1," %"); setup(pitch,-24,24,1," st"); setup(block,40,500,10," ms"); setup(context,200,1500,50," ms");
        pitch.setTooltip(livent::vn("0 giữ giai điệu. Chỉnh cao độ theo quãng phù hợp với giọng mẫu."));
        notes.setText(livent::vn("Thử LIVE: khối 80 ms, ngữ cảnh 300 ms, index 0%; tốc độ tùy GPU / model.\n"
                                "CUDA chỉ hoạt động khi đã có bộ DLL GPU chính thức trong VoiceAI/runtime.\n"
                                "AI không kịp sẽ báo lỗi và bỏ qua AI. Trễ hiển thị chưa tính card ASIO."),juce::dontSendNotification);
        notes.setJustificationType(juce::Justification::topLeft);
        status.setJustificationType(juce::Justification::topLeft);
        meters.setMultiLine(true); meters.setReadOnly(true); meters.setScrollbarsShown(true);
        for(auto* c : std::initializer_list<juce::Component*>{&title,&subtitle,&modelLabel,&model,&chooseModel,
             &indexLabel,&index,&chooseIndex,&noIndex,&enabled,&provider,&livePreset,&pitchLabel,&pitch,&blockLabel,&block,
             &contextLabel,&context,&indexRateLabel,&indexRate,&status,&meters,&notes,
             &cueTitle,&cueOn,&cuePairLabel,&cuePair,&cueFormantLabel,&cueFormant,&cueVoiceLabel,&cueVoice,
             &cueMusicLabel,&cueMusic,&cueInfo}) addAndMakeVisible(c);
        setupCue();
        if(auto* v=voice())
        {
            if(v->getModel()==juce::File())
            {
                const auto first=Voice::bundledModel();
                if(first.existsAsFile()) {v->setModel(first);v->setIndex(Voice::pairedIndex(first));}
            }
            auto addFolder=[&](const juce::File& folder) {
                for(const auto& file:folder.findChildFiles(juce::File::findFiles,true,"*.pth"))
                    if(std::find(voices.begin(),voices.end(),file)==voices.end()) voices.push_back(file);
            };
            addFolder(Voice::dataFolder().getChildFile("voices"));
            addFolder(juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("LiveNT/Giong"));
            if(v->getModel()!=juce::File() && std::find(voices.begin(),voices.end(),v->getModel())==voices.end()) voices.push_back(v->getModel());
            for(size_t i=0;i<voices.size();++i)
            {
                model.addItem(voices[i].getFileNameWithoutExtension(),static_cast<int>(i+1));
                if(voices[i]==v->getModel()) model.setSelectedId(static_cast<int>(i+1),juce::dontSendNotification);
            }
            provider.setSelectedId(v->getGpu()?1:2,juce::dontSendNotification);
            enabled.setToggleState(v->isEnabled(),juce::dontSendNotification);
            indexRate.setValue(100*v->getIndexRate(),juce::dontSendNotification);
            pitch.setValue(v->getPitch(),juce::dontSendNotification);
            block.setValue(v->getBlockMs(),juce::dontSendNotification);
            context.setValue(v->getContextMs(),juce::dontSendNotification);
        }
        model.onChange=[this] {
            const int id=model.getSelectedId()-1;
            if(id>=0 && static_cast<size_t>(id)<voices.size()) if(auto* v=voice())
            {v->setModel(voices[static_cast<size_t>(id)]);v->setIndex(Voice::pairedIndex(voices[static_cast<size_t>(id)]));changed();}
        };
        chooseModel.onClick=[this]{choose(false);}; chooseIndex.onClick=[this]{choose(true);};
        noIndex.onClick=[this]{if(auto* v=voice()){v->setIndex({});changed();}};
        enabled.onClick=[this]{if(auto* v=voice()){v->setEnabled(enabled.getToggleState());changed();}};
        provider.onChange=[this]{if(auto* v=voice()){v->setGpu(provider.getSelectedId()==1);changed();}};
        livePreset.onClick=[this]{
            if(auto* v=voice())
            {
                v->setGpu(true);
                v->setIndexRate(0.f);
                v->setBlockMs(80);
                v->setContextMs(300);
                provider.setSelectedId(1,juce::dontSendNotification);
                indexRate.setValue(0,juce::dontSendNotification);
                block.setValue(80,juce::dontSendNotification);
                context.setValue(300,juce::dontSendNotification);
                changed();
            }
        };
        indexRate.onValueChange=[this]{if(auto* v=voice())v->setIndexRate(static_cast<float>(indexRate.getValue()/100.0));};
        indexRate.onDragEnd=[this]{changed();};
        pitch.onDragEnd=[this]{if(auto* v=voice()){v->setPitch(static_cast<float>(pitch.getValue()));changed();}};
        pitch.onValueChange=[this]{if(auto* v=voice())v->setPitch(static_cast<float>(pitch.getValue()));};
        block.onDragEnd=[this]{if(auto* v=voice()){v->setBlockMs(static_cast<int>(block.getValue()));changed();}};
        context.onDragEnd=[this]{if(auto* v=voice()){v->setContextMs(static_cast<int>(context.getValue()));changed();}};
        // Keyboard/text edits commit too; dragging commits only at its end to avoid repeated reloads.
        block.onValueChange=[this]{if(!block.isMouseButtonDown())if(auto* v=voice()){v->setBlockMs(static_cast<int>(block.getValue()));changed();}};
        context.onValueChange=[this]{if(!context.isMouseButtonDown())if(auto* v=voice()){v->setContextMs(static_cast<int>(context.getValue()));changed();}};
        setSize(680,880); startTimerHz(5); timerCallback();
    }
    ~Panel() override {stopTimer();}
    void paint(juce::Graphics& g) override {g.fillAll(Col::panel);}
    void resized() override
    {
        auto r=getLocalBounds().reduced(18);
        title.setBounds(r.removeFromTop(34)); subtitle.setBounds(r.removeFromTop(30)); r.removeFromTop(8);
        auto row=r.removeFromTop(32);modelLabel.setBounds(row.removeFromLeft(88));chooseModel.setBounds(row.removeFromRight(105));row.removeFromRight(8);model.setBounds(row);
        r.removeFromTop(8);row=r.removeFromTop(32);indexLabel.setBounds(row.removeFromLeft(88));noIndex.setBounds(row.removeFromRight(88));row.removeFromRight(6);chooseIndex.setBounds(row.removeFromRight(105));row.removeFromRight(6);index.setBounds(row);
        r.removeFromTop(14);row=r.removeFromTop(32);enabled.setBounds(row.removeFromLeft(195));
        livePreset.setBounds(row.removeFromRight(132));row.removeFromRight(8);provider.setBounds(row);
        auto sliderRow=[&](juce::Label& label,juce::Slider& slider){r.removeFromTop(6);auto rr=r.removeFromTop(getHeight()<620 ? 30 : 36);label.setBounds(rr.removeFromLeft(110));slider.setBounds(rr);};
        sliderRow(pitchLabel,pitch);sliderRow(indexRateLabel,indexRate);sliderRow(blockLabel,block);sliderRow(contextLabel,context);
        r.removeFromTop(12);status.setBounds(r.removeFromTop(getHeight()<780 ? 44 : 56));meters.setBounds(r.removeFromTop(getHeight()<780 ? 56 : 76));
        // 02/11: HAT LIVE 2 DUONG
        r.removeFromTop(12);cueTitle.setBounds(r.removeFromTop(26));
        row=r.removeFromTop(30);cueOn.setBounds(row.removeFromLeft(300));row.removeFromLeft(8);cuePairLabel.setBounds(row.removeFromLeft(96));cuePair.setBounds(row);
        sliderRow(cueFormantLabel,cueFormant);sliderRow(cueVoiceLabel,cueVoice);sliderRow(cueMusicLabel,cueMusic);
        r.removeFromTop(4);cueInfo.setBounds(r.removeFromTop(48));
        r.removeFromTop(6);notes.setBounds(r);
    }
private:
    Voice* voice() const {auto* t=mixer.getTrackByUuid(trackUuid);return t?&t->getVoiceAI():nullptr;}
    void changed(){if(onChanged)onChanged();timerCallback();}
    void choose(bool isIndex)
    {
        const auto safe=juce::Component::SafePointer<Panel>(this);
        chooser=std::make_unique<juce::FileChooser>(isIndex?livent::vn("Chọn index"):livent::vn("Chọn giọng RVC"),juce::File(),isIndex?"*.index":"*.pth");
        chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles,
            [safe,isIndex](const juce::FileChooser& fc) {
                if(!safe || !fc.getResult().existsAsFile())return;
                if(auto* v=safe->voice())
                {
                    if(isIndex)v->setIndex(fc.getResult());
                    else
                    {
                        v->setModel(fc.getResult());v->setIndex(Voice::pairedIndex(fc.getResult()));
                        safe->voices.push_back(fc.getResult());
                        const int id=static_cast<int>(safe->voices.size());
                        safe->model.addItem(fc.getResult().getFileNameWithoutExtension(),id);
                        safe->model.setSelectedId(id,juce::dontSendNotification);
                    }
                    safe->changed();
                }
            });
    }
    void timerCallback() override
    {
        if(auto* v=voice())
        {
            enabled.setToggleState(v->isEnabled(),juce::dontSendNotification);
            status.setText(v->statusText(),juce::dontSendNotification);
            meters.setText(v->metersText(),false);
            index.setText(v->getIndex().existsAsFile()?v->getIndex().getFileName():livent::vn("Không dùng"),juce::dontSendNotification);
            cueOn.setToggleState(v->getCueOn(),juce::dontSendNotification);
            cueInfo.setText(cueStatus(*v),juce::dontSendNotification);
        }
        else {status.setText(livent::vn("Track mic đã đóng. Mở lại GIỌNG trên dự án hiện tại."),juce::dontSendNotification);enabled.setEnabled(false);}
    }
    // ---- 02/11 HAT LIVE 2 DUONG: tai nghe nhanh cho nguoi hat ----------------------------------
    void setupCue()
    {
        cueTitle.setText(livent::vn("HÁT LIVE 2 ĐƯỜNG · TAI NGHE RIÊNG"),juce::dontSendNotification);
        cueTitle.setFont(juce::Font(juce::FontOptions(15.f).withStyle("Bold")));
        cueOn.setButtonText(livent::vn("Tai nghe nhanh: đổi cao độ / màu giọng + beat gốc"));
        cuePairLabel.setText(livent::vn("Cổng tai nghe"),juce::dontSendNotification);
        cueFormantLabel.setText(livent::vn("Màu giọng nghe"),juce::dontSendNotification);
        cueVoiceLabel.setText(livent::vn("Giọng trong tai"),juce::dontSendNotification);
        cueMusicLabel.setText(livent::vn("Beat trong tai"),juce::dontSendNotification);
        auto setup=[](juce::Slider& s,double lo,double hi,double step,const char* unit) {
            s.setRange(lo,hi,step); s.setSliderStyle(juce::Slider::LinearHorizontal);
            s.setTextBoxStyle(juce::Slider::TextBoxRight,false,84,26); s.setTextValueSuffix(unit);
        };
        setup(cueFormant,-6,6,0.5," st"); setup(cueVoice,-30,6,0.5," dB"); setup(cueMusic,-30,6,0.5," dB");
        cueFormant.setTooltip(livent::vn("Chỉ giọng nghe nhanh trong tai: nam -> nữ thường +2..+3. Giọng AI lên live không đổi."));
        cueOn.setTooltip(livent::vn("Người hát nghe beat KHÔNG trễ + giọng đổi tông nhanh trên cổng riêng.\n"
                                    "ÂM THANH RA / bus live / file thu: giọng AI + beat được DAW tự làm trễ cho khớp."));
        cueInfo.setJustificationType(juce::Justification::topLeft);
        cuePair.addItem(livent::vn("Chưa chọn"),1000);
        if(getOutputNames)
        {
            const auto names=getOutputNames();
            for(int p=0;p*2+1<names.size() && p<32;++p)
                cuePair.addItem(names[p*2]+" / "+names[p*2+1],p+1);
        }
        if(auto* v=voice())
        {
            cueFormant.setValue(v->getCueFormant(),juce::dontSendNotification);
            cueVoice.setValue(v->getCueVoiceDb(),juce::dontSendNotification);
            cueMusic.setValue(v->getCueMusicDb(),juce::dontSendNotification);
            cueOn.setToggleState(v->getCueOn(),juce::dontSendNotification);
            const int pair=v->getCuePair();
            cuePair.setSelectedId(pair>=0 && cuePair.indexOfItemId(pair+1)>=0 ? pair+1 : 1000,juce::dontSendNotification);
        }
        cueOn.onClick=[this]{if(auto* v=voice()){v->setCueOn(cueOn.getToggleState());changed();}};
        cuePair.onChange=[this]
        {
            auto* v=voice(); if(!v)return;
            const int id=cuePair.getSelectedId();
            if(id<=0 || id==1000){v->setCuePair(-1);changed();return;}
            const int physical=id-1;
            if(activatePair && activatePair(physical)<0)return;   // driver khong bat duoc cap nay (da bao loi)
            v->setCuePair(physical);changed();
        };
        cueFormant.onValueChange=[this]{if(auto* v=voice())v->setCueFormant(static_cast<float>(cueFormant.getValue()));};
        cueVoice.onValueChange=[this]{if(auto* v=voice())v->setCueVoiceDb(static_cast<float>(cueVoice.getValue()));};
        cueMusic.onValueChange=[this]{if(auto* v=voice())v->setCueMusicDb(static_cast<float>(cueMusic.getValue()));};
        for(auto* s:{&cueFormant,&cueVoice,&cueMusic}) s->onDragEnd=[this]{changed();};
    }
    juce::String cueStatus(Voice& v) const
    {
        if(!v.getCueOn()) return livent::vn("Tắt: tai nghe nghe giống ÂM THANH RA (có giọng AI thì nghe trễ theo AI).");
        if(v.getCuePair()<0) return livent::vn("Chọn cổng tai nghe của người hát (ví dụ OUT 1 / OUT 2).");
        const int compact=mixer.getLiveCueCompactPair();
        if(compact<0) return livent::vn("Cổng tai nghe chưa mở được trên soundcard hiện tại. Chọn lại cổng hoặc kiểm tra driver.");
        if(!v.isEnabled()) return livent::vn("Tai nghe riêng: beat gốc + giọng mộc + vang. Tổng trễ còn tùy driver / ASIO.");
        if(!v.isReady()) return livent::vn("Tai nghe: đổi cao độ / màu giọng bằng DSP, không dùng giọng mẫu AI. Đường live / thu hiện là giọng gốc; xem trạng thái AI phía trên.");
        const double rate=juce::jmax(1.0,mixer.getCurrentSampleRate());
        return livent::vn("Tai nghe: đổi cao độ / màu giọng bằng DSP, không dùng giọng mẫu AI. Đường live / thu có AI và bù trễ (")
             + juce::String(juce::roundToInt(1000.0*v.latencySamples()/rate)) + livent::vn(" ms).");
    }
    std::function<juce::StringArray()> getOutputNames;
    std::function<int(int)> activatePair;
    juce::Label cueTitle,cuePairLabel,cueFormantLabel,cueVoiceLabel,cueMusicLabel,cueInfo;
    juce::ToggleButton cueOn;
    juce::ComboBox cuePair;
    juce::Slider cueFormant,cueVoice,cueMusic;
    Mixer& mixer;juce::String trackUuid;std::function<void()> onChanged;
    std::vector<juce::File> voices;
    std::unique_ptr<juce::FileChooser> chooser;
    juce::Label title,subtitle,modelLabel,indexLabel,index,pitchLabel,blockLabel,contextLabel,indexRateLabel,status,notes;
    juce::ComboBox model,provider;
    juce::TextButton chooseModel,chooseIndex,noIndex,livePreset;
    juce::ToggleButton enabled;
    juce::Slider pitch,indexRate,block,context;
    juce::TextEditor meters;
};
}
