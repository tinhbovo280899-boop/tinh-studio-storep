# LiveNT — vá bộ đệm GIỌNG AI V4

Gói mã nguồn này chỉ áp dụng lên Source.zip mới có BuiltinVoice, VoiceAI/NativeWorker
và đường TAI NGHE NHANH mà anh vừa gửi ngày 05/11/2026. Đây là bản vá quản lý
thời gian thực và hiển thị chẩn đoán, chưa phải xác nhận chất lượng đổi giọng RVC.

## Cài vào dự án

1. Sao lưu dự án đầy đủ hiện tại.
2. Giải nén gói này vào thư mục gốc dự án, chép đè đúng 6 file trong Source/.
3. Build lại bằng cấu hình Windows AI hiện có của dự án. Giữ các file model,
   ONNX Runtime, driver, JUCE và cấu hình CMake của bản đầy đủ.
4. Không chép các bản V1/V2/V3 cũ lên sau bản này: chúng dựa trên source cũ hơn.

Không có EXE/bộ cài trong ZIP. Source.zip gửi lần này không có JUCE, root CMake
và các bộ model/runtime nên không thể build toàn bộ DAW hoặc chạy GPU AI tại đây.
Patch không thay schema dự án .NT, không đổi mặc định pitch/model hoặc routing.

## Vấn đề đã xác nhận trong code

- Khi một khối dài 120 ms mất 800 ms để AI xử lý, bản cũ vẫn cho chạy và đặt bộ
  đệm khoảng 970 ms. AI xử lý chậm hơn tốc độ thu âm nên tăng bộ đệm không thể
  giúp chạy liên tục. VoiceStream bù đoạn thiếu bằng giọng gốc đã làm trễ.
- Một lần chậm bất thường ở lần warm-up cuối có thể tạo độ trễ cố định quá lớn.
  Sau đó bộ đệm còn có thể tăng, không tự giảm; phần chèn thêm lặp một giá trị
  sample, không phải crossfade âm thanh thực sự.
- Chọn GPU trong combobox chỉ là yêu cầu. VoiceEngine có thể chuyển sang CPU
  khi provider/DLL/session GPU lỗi. Trước đây chi tiết lỗi GPU bị mất.
- TAI NGHE NHANH dùng DSP đổi cao độ/formant. Nó không dùng giọng mẫu RVC.

Các điểm này giải thích được hiện tượng giọng gốc bị trễ; chưa đủ thông tin để
kết luận GPU/model cụ thể trên máy anh có vấn đề nào. Cần số Xử lý/khối, Trễ bộ
đệm và tên card để xác định tiếp.

## Thay đổi

- Bỏ lần warm-up đầu, lấy trung vị ba lần tiếp theo để tránh một lần chậm đơn lẻ.
- Nếu tốc độ warm-up ổn định chậm hơn độ dài khối, báo lỗi và bypass AI ngay.
- Khi đang chạy, chỉ dừng AI nếu các lần chậm lặp lại và trung bình vượt độ dài
  khối; bỏ qua một lần chậm đơn lẻ. Không tự kéo dài bộ đệm trong phiên.
- Khi bypass do quá tải, latency AI báo về host bằng 0 để host cập nhật bù trễ.
  Trễ ASIO, driver, VST khác và quá trình chuyển bảng PDC vẫn thuộc DAW hiện có.
- Xuất file offline được phép xử lý chậm. Sửa trạng thái cũ khi restart để có
  thể chuyển từ lỗi realtime sang xuất offline.
- Hiển thị GPU/CPU đã nạp và giữ lý do fallback CPU trong phần thông tin AI.
- Bảng tai nghe nói rõ DSP khác với giọng mẫu AI; bỏ cam kết trễ ~0/~5 ms và
  nhãn LIVE RTX 3060+. Nút thử vẫn đặt 80 ms / 300 ms / index 0% như trước.

Đây không phải tối ưu tốc độ mạng RVC hoặc biến đổi AI thành độ trễ 5 ms.
Nếu AI bị bypass vì chậm, giọng ra vẫn là giọng gốc và bảng sẽ báo rõ.

## Kiểm tra sau khi build

1. Mở chuột phải GIỌNG. Xem trạng thái và dòng GPU/CPU thực tế, không chỉ combobox.
2. Có thể dùng Thử LIVE 80 ms; Xử lý mỗi khối phải nhỏ hơn 80 ms một cách ổn định.
   Nếu chưa kịp, giảm ngữ cảnh/index hoặc kiểm tra runtime GPU. Tắt/bật GIỌNG để đo lại.
3. Với một đoạn giọng thu sẵn, so sánh bật/tắt AI và thử pitch +12 hoặc -12 để
   dễ nhận biết đường xử lý. Nếu AI trả im lặng/thiếu kết quả, bảng sẽ báo dùng
   giọng gốc; chưa thể coi trạng thái đã nạp model là đã đổi giọng thành công.
4. Tai nghe nhanh trên cổng riêng chỉ đổi cao độ/formant bằng DSP. So sánh
   giọng mẫu AI ở đầu ra chính/live, đồng thời tránh bật direct monitor trộn lại.
5. Kiểm tra mở lại dự án, bật/tắt INSERT, đổi model/provider, routing send/FX,
   ASIO 128/256/512 và xuất file; nghe cả đoạn chuyển trạng thái để phát hiện click.

## Kết quả kiểm tra ở môi trường này

- Dùng chính NativeWorker.cpp trước/sau với engine giả cung cấp thời gian xác định:
  7 kịch bản sau sửa đạt, ASan/UBSan không báo lỗi. Không chạy model AI thật.
- Dùng VoiceStream.h thật với worker mô phỏng lịch inference: khối 120 ms,
  xử lý 800 ms, bộ đệm 970 ms trả đúng giọng gốc đã trễ ở đoạn ổn định (sai số
  RMS = 0); 1125 callback phải dự phòng. Ca xử lý kịp vẫn căn đúng kết quả giả.
- NativeWorker.cpp và VoiceEngine.cpp thật qua kiểm tra cú pháp g++ C++17 với
  header ONNX Runtime chính thức 1.20.1, -Wall -Wextra -Wpedantic không cảnh báo.
- Chưa build/chạy giao diện JUCE, Windows ASIO/CUDA/DirectML hoặc nghe RVC thật.
  Các kiểm tra trên xác nhận logic bộ đệm, không chứng minh tốc độ/chất giọng GPU.

Diff, số liệu, mã kiểm tra và SHA-256 nằm kèm gói. Chạy worker test sau khi chép
patch vào source đầy đủ: `python3 review/worker-test/run.py` (Linux, g++, Python 3).
Có thể thêm `--baseline /path/to/original/Source/VoiceAI` để so sánh bản trước.
