#pragma once

#include <array>

#include <JuceHeader.h>
#include "Theme.h"
#include "LaughBoard.h"   // MOC 89: bang tieng cuoi o cua so rieng
#include "Icons.h"
#include "Mixer.h"
#include "MixerUI.h"   // SectionHeader
#include "ToneClient.h"
#include "TonePush.h"
#include "AutoKeyBroadcast.h"   // 31/10: gui tong kieu Auto-Key cho moi Auto-Tune
#include "AutoKeySettings.h"
#include "BuiltinKey.h"   // 12s: T-AutoKey co san tren track NHAC
#include "AutoKeyPlaybackClock.h"
#include "PluginActionButton.h"
#include "Dialogs.h"
#include "ButtonMap.h"   // 01/10: gan nut / num vao track bat ky
#include "PresetBank.h"  // 02/10: preset the loai (Bolero, Nhac tre...)
#include "CustomLiveButtons.h"
#include "PresetPopup.h" // 06/10: bang preset gon
#include "QuickPanel.h"  // 06/10: bang chuot phai Nhac / Vang / Mic
#include "VstControl.h"  // 06/10: EQ mic (Manny Marroquin EQ)
#include "HelpOverlay.h" // 02/10: che do huong dan (nut ?)
#include "AppBranding.h"   // 30/09: o VST / ten nut / bo cuc theo khach
#include "BrowserWatcher.h"
#include "SongLibrary.h"
#include <cmath>    // std::round, std::lround (Moc 37)
#include <optional>

//=============================================================================
/**
    ToneClock -- dai thoi gian cua bai hat, co danh dau cac moc doi tong.

        00:00                                                  05:12
        |=============@=====================@==================|
                      ^ 01:35               ^ 03:48
                 [kim dang chay]

    Kim chay theo SO GIAY THAT ma trinh duyet bao ve, khong phai dong ho tu
    dem cua LiveNT. Nho vay anh tua bai, tam dung, hay phat lai tu dau thi kim
    van bam dung -- dong ho tu dem thi tua mot cai la lech han.
*/
class ToneClock : public juce::Component
{
public:
    /*  BAT BUOC phai co dong nay.

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR o cuoi lop se khai bao
        mot ham dung SAO CHEP (roi xoa no di). Ma theo luat C++, chi can lop
        co BAT KY ham dung nao do nguoi viet khai bao -- ke ca ham dung sao
        chep da bi xoa -- thi trinh bien dich THOI khong tu sinh ham dung
        rong nua.

        Cac lop khac trong file nay khong dinh loi vi chung deu tu viet ham
        dung roi. Rieng ToneClock khong can lam gi luc tao nen em quen mat.  */
    ToneClock() = default;

    struct Mark
    {
        double  seconds = 0.0;
        juce::String key, scale;
        bool    applied = false;
    };

    void setMarks (juce::Array<Mark> newMarks, const juce::String& baseKey,
                   const juce::String& baseScale)
    {
        marks     = std::move (newMarks);
        firstKey  = baseKey;
        firstScale= baseScale;
        position  = 0.0;
        live      = false;
        repaint();
    }

    void clear()
    {
        marks.clear();
        position = 0.0;
        live = false;
        repaint();
    }

    /** Cap nhat kim. live = true nghia la so giay nay la THAT (co the tin). */
    void setPosition (double seconds, bool isLive)
    {
        position = seconds;
        live     = isLive;
        repaint();
    }

    double getPosition() const noexcept   { return position; }
    bool   isLive()      const noexcept   { return live; }
    const juce::String& getFirstKey() const noexcept   { return firstKey; }
    const juce::String& getFirstScale() const noexcept { return firstScale; }

    juce::Array<Mark>& getMarks() noexcept             { return marks; }
    const juce::Array<Mark>& getMarks() const noexcept { return marks; }

    /** Do dai bai: moc cuoi cung cong mot khoang du. Khong biet do dai that
        vi may chu khong bao -- nhung de ve dai thi chi can uoc luong. */
    double getSpan() const
    {
        double last = 60.0;

        for (const auto& m : marks)
            last = juce::jmax (last, m.seconds);

        return juce::jmax (last * 1.25, position * 1.1, 60.0);
    }

    static juce::String mmss (double seconds)
    {
        const int t = juce::jmax (0, (int) seconds);
        return juce::String (t / 60).paddedLeft ('0', 2) + ":"
             + juce::String (t % 60).paddedLeft ('0', 2);
    }

    void paint (juce::Graphics& g) override
    {
        auto area = getLocalBounds().reduced (2, 0);

        auto textRow = area.removeFromTop (14);
        auto barRow  = area.removeFromTop (12);

        //-- Dong chu tren ----------------------------------------------------
        g.setFont (juce::Font (juce::FontOptions (11.0f)));

        if (marks.isEmpty())
        {
            // V5.7: khong hien banner "Bài này giữ nguyên tone" nua.
            juce::ignoreUnused (textRow);
            return;
        }

        g.setColour (live ? juce::Colour (0xff5fd8e0) : Col::textDim);
        g.drawText (mmss (position)
                    + (live ? juce::String() : livent::vn ("   (chưa bắt được thời gian)")),
                    textRow, juce::Justification::centredLeft, false);

        //  Moc ke tiep con bao lau
        for (const auto& m : marks)
        {
            if (m.seconds > position)
            {
                g.setColour (Col::textDim);
                g.drawText (livent::vn ("sắp tới: ") + mmss (m.seconds) + "  ->  " + m.key + " " + m.scale,
                            textRow, juce::Justification::centredRight, false);
                break;
            }
        }

        //-- Dai thoi gian ----------------------------------------------------
        const double span = getSpan();
        auto bar = barRow.toFloat().reduced (0.0f, 3.0f);

        g.setColour (Col::bg);
        g.fillRoundedRectangle (bar, 3.0f);

        //  Phan da phat
        if (live && span > 0.0)
        {
            auto done = bar.withWidth ((float) (bar.getWidth() * juce::jlimit (0.0, 1.0, position / span)));
            g.setColour (Col::accent.withAlpha (0.45f));
            g.fillRoundedRectangle (done, 3.0f);
        }

        //  Cac moc doi tong
        for (const auto& m : marks)
        {
            const float x = bar.getX()
                          + (float) (bar.getWidth() * juce::jlimit (0.0, 1.0, m.seconds / span));

            g.setColour (m.applied ? Col::green : juce::Colour (0xffffd24a));
            g.fillRoundedRectangle (x - 1.5f, bar.getY() - 2.0f, 3.0f, bar.getHeight() + 4.0f, 1.5f);
        }

        //  Kim
        if (live && span > 0.0)
        {
            const float x = bar.getX()
                          + (float) (bar.getWidth() * juce::jlimit (0.0, 1.0, position / span));

            g.setColour (Col::text);
            g.fillRect (x - 0.5f, bar.getY() - 4.0f, 1.0f, bar.getHeight() + 8.0f);
        }
    }

private:
    juce::Array<Mark> marks;
    juce::String firstKey, firstScale;
    double position = 0.0;
    bool   live     = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ToneClock)
};


//=============================================================================
/**
    TonePanel - bang do Key / Scale, nam o DAU danh sach track.

    Hai cach dung:
      1. Dan link YouTube -> bam DO TONE -> may chu VPS2 tra ve -> tu ghi vao
         Auto-Tune cua track anh chon.
      2. Khong co link: bam +/- chon tay roi bam GUI. Thu ngay tai cho.

    Nut AUTO TUNE mo nhanh VST so 1 tren track MIC. Viec xem tham so
    van con duong noi bo/phuc vu debug, khong chiem nut tren Bang dieu khien.
*/
/**
    MOC 89: LaughWindow - cua so rieng chua bang tieng cuoi.

    juce::DocumentWindow ban goc co mot cho hong: closeButtonPressed() KHONG
    LAM GI CA. Bam dau X thi khong co chuyen gi xay ra, nguoi dung tuong app
    treo. Phai tu ke thua va bao ra ngoai - y het ToneWindow o MainComponent.
*/
class LaughWindow : public juce::DocumentWindow
{
public:
    LaughWindow (LaughBoard& boardToShow, std::function<void()> onCloseFn)
        : juce::DocumentWindow (livent::vn ("Tiếng cười"), Col::bg, 0),
          board (boardToShow), onClose (std::move (onCloseFn))
    {
        // V6.0.1: popup thao tác nhanh, không dùng title-bar riêng. Nút CƯỜI trên
        // thanh LiveNT vừa mở vừa đóng nên thêm một thanh tiêu đề nữa chỉ tốn chỗ.
        setUsingNativeTitleBar (false);
        setTitleBarHeight (0);
        setResizable (false, false);
        setDropShadowEnabled (true);
        setAlwaysOnTop (true);
        setBroughtToFrontOnMouseClick (true);

        viewport.setScrollBarsShown (true, false);
        viewport.setScrollBarThickness (10);
        viewport.setViewedComponent (&board, false);
        setContentNonOwned (&viewport, false);
    }

    ~LaughWindow() override
    {
        // Content la member cua chinh window; thao ra truoc khi member bi huy.
        clearContentComponent();
        viewport.setViewedComponent (nullptr, false);
    }

    void setBoardWidth (int width)
    {
        width = juce::jmax (260, width);
        board.setSize (width, board.preferredHeightForWidth (width));
    }

    void closeButtonPressed() override
    {
        if (onClose) onClose();
    }

    bool keyPressed (const juce::KeyPress& k) override
    {
        if (k.getKeyCode() == juce::KeyPress::escapeKey)
        {
            if (onClose) onClose();
            return true;
        }
        return juce::DocumentWindow::keyPressed (k);
    }

private:
    LaughBoard& board;
    juce::Viewport viewport;
    std::function<void()> onClose;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LaughWindow)
};



//=============================================================================
/**
    V4.6: dong ho muc gon cho Bang dieu khien.

    Hai cot nay KHONG tao them duong xu ly am thanh. Chung chi doc gia tri
    meterLevel atomic da co san tren track NHAC / MIC, nen khong chen code vao
    audio callback va khong lam tang do tre. Attack nhay ngay, release roi tu
    tu; khi im lang thi dung repaint de tiet kiem CPU/GPU.
*/
class LiveControlMeter : public juce::Component,
                         private juce::Timer
{
public:
    explicit LiveControlMeter (juce::String captionText)
        : caption (std::move (captionText))
    {
        setInterceptsMouseClicks (false, false);
        startTimerHz (30);
    }

    std::function<float()> getLevelSource;

    void paint (juce::Graphics& g) override
    {
        auto outer = getLocalBounds().toFloat();

        // V6.5.2: nền đồng hồ phải đi theo chủ đề. Màu xanh-đen cố định cũ
        // nhìn như hai cột đen khi người dùng chọn chủ đề sáng.
        g.setColour (Col::panel2);
        g.fillRoundedRectangle (outer, 6.0f);

        g.setColour (Col::accent.withAlpha (0.28f));
        g.drawRoundedRectangle (outer.reduced (0.5f), 6.0f, 1.0f);

        // V0.6.7.9: meter NAM NGANG (bo cuc doc gap num): chu ben trai, vach sang ngang
        if (getWidth() > getHeight() * 2)
        {
            auto a = getLocalBounds().reduced (6, 4);
            auto cap = a.removeFromLeft (40);
            a.removeFromLeft (4);

            constexpr int segs = 24;
            constexpr int gapH = 2;
            const float segW = juce::jmax (2.0f, ((float) a.getWidth() - gapH * (segs - 1)) / (float) segs);
            const float dBh = juce::Decibels::gainToDecibels (displayed, -60.0f);
            const int litH = juce::roundToInt (juce::jlimit (0.0f, 1.0f, juce::jmap (dBh, -60.0f, 0.0f, 0.0f, 1.0f)) * (float) segs);

            for (int i = 0; i < segs; ++i)
            {
                const juce::Colour c = i >= 21 ? Col::red : i >= 17 ? Col::amber : Col::green;
                g.setColour (i < litH ? c : c.withAlpha (0.10f));
                g.fillRoundedRectangle ((float) a.getX() + (float) i * (segW + gapH), (float) a.getY(),
                                        segW, (float) a.getHeight(), 1.5f);
            }

            g.setColour (Col::text);
            g.setFont (juce::Font (juce::FontOptions (10.5f).withStyle ("Bold")));
            g.drawText (caption, cap, juce::Justification::centredLeft, false);
            return;
        }

        auto area = getLocalBounds().reduced (5, 5);
        auto captionArea = area.removeFromBottom (17);
        area.removeFromBottom (3);

        constexpr int segments = 16;
        constexpr int gap = 2;
        const int segH = juce::jmax (2, (area.getHeight() - gap * (segments - 1)) / segments);

        const float dB = juce::Decibels::gainToDecibels (displayed, -60.0f);
        const float prop = juce::jlimit (0.0f, 1.0f,
                          juce::jmap (dB, -60.0f, 0.0f, 0.0f, 1.0f));
        const int lit = juce::roundToInt (prop * (float) segments);

        int y = area.getBottom() - segH;
        for (int i = 0; i < segments; ++i)
        {
            const bool on = i < lit;
            juce::Colour c = i >= 14 ? Col::red
                            : i >= 11 ? Col::amber
                                      : Col::green;

            g.setColour (on ? c : c.withAlpha (0.10f));
            g.fillRoundedRectangle ((float) area.getX(), (float) y,
                                    (float) area.getWidth(), (float) segH, 1.5f);
            y -= segH + gap;
        }

        g.setColour (Col::text);
        g.setFont (juce::Font (juce::FontOptions (10.0f).withStyle ("Bold")));
        g.drawText (caption, captionArea, juce::Justification::centred, false);
    }

private:
    void timerCallback() override
    {
        const float input = juce::jlimit (0.0f, 2.0f,
                            getLevelSource ? getLevelSource() : 0.0f);
        const float before = displayed;

        if (input > displayed)
            displayed = input;
        else
            displayed *= 0.84f;

        if (displayed < 0.0001f)
            displayed = 0.0f;

        if (std::abs (displayed - before) > 0.0001f)
            repaint();
    }

    juce::String caption;
    float displayed = 0.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LiveControlMeter)
};


//=============================================================================
/* V5.7: cum DANG PHAT gon. Ten dai tu chay ngang; hang song phia duoi lay
   lich su peak cua track NHAC (chi doc atomic meterLevel), nen dep ma khong
   chen FFT hay cap phat bo nho vao audio thread. */
class NowPlayingStrip : public juce::Component,
                        private juce::Timer
{
public:
    NowPlayingStrip()
    {
        setInterceptsMouseClicks (false, false);
        startTimerHz (30);
    }

    std::function<float()> getLevelSource;

    void setTitle (juce::String t)
    {
        t = t.trim();
        if (title == t) return;
        title = t;
        marqueePx = 0.0f;
        pauseTicks = 45;
        repaint();
    }

    void setPosition (double seconds, double totalGuess, bool isLive)
    {
        position = juce::jmax (0.0, seconds);
        total = juce::jmax (position, totalGuess);
        live = isLive;
        repaint();
    }

    static juce::String mmss (double seconds)
    {
        const int t = juce::jmax (0, (int) seconds);
        return juce::String (t / 60).paddedLeft ('0', 2) + ":"
             + juce::String (t % 60).paddedLeft ('0', 2);
    }

    juce::String getTimeText() const
    {
        return mmss (position) + " / "
             + (total > position + 1.0 ? mmss (total) : juce::String ("--:--"));
    }

    bool isLivePosition() const noexcept { return live; }
    const juce::String& getTitle() const noexcept { return title; }   // 07/10: thanh trang thai

    /*  14/10: O THONG BAO o thanh duoi. Co thong bao thi ve vien thuoc thay cho ten bai:
          1 = bao nhe (vang nhat)  : "Bài có đổi tông: 5:03 → B Major"
          2 = sap doi tong (vang dam): "Còn 8 giây đổi tông → B Major"
          3 = loi (do)             : "AI NT và AI HC đều lỗi ..." (chi khi CA HAI may chu loi)
          4 = bao xanh             : "✓ Đã dò xong bằng AI NT" (16/10: may chu kia do thay)
        kind 0 / chu rong = tro lai ten bai.  */
    void setNotice (const juce::String& text, int kind)
    {
        if (noticeText == text && noticeKind == kind) return;
        noticeText = text;
        noticeKind = text.isEmpty() ? 0 : kind;
        repaint();
    }

    /*  15/10: O "DANG PHAT" KIEU THE (bang Doc, mau da chot):
            DANG PHAT                         01:12 / 05:40
            That Tinh  [Bb]
            Trinh Dinh Quang      <- co thong bao thi thong bao nam o dong nay
            ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━●━━━   (cham vang = moc doi tong)
        O khong doi chieu cao khi co thong bao -> cac khoi ben duoi khong nhay.  */
    static constexpr int cardHeight = 84;
    void setCardMode (bool on)                   { if (cardMode != on) { cardMode = on; repaint(); } }
    void setKeyBadge (const juce::String& text)  { if (keyBadge != text) { keyBadge = text; repaint(); } }
    void setMarks (const juce::Array<double>& secs)
    {
        if (marks == secs) return;
        marks = secs;
        repaint();
    }

    /** "Ten bai - Ca si" -> { ten bai, ca si }. Khong co dau gach thi ca si rong. */
    static std::pair<juce::String, juce::String> splitTitle (const juce::String& full)
    {
        for (auto* sep : { " - ", " \xe2\x80\x93 ", " | " })
        {
            const auto s = juce::String::fromUTF8 (sep);
            const int i = full.indexOf (s);
            if (i > 0)
                return { full.substring (0, i).trim(), full.substring (i + s.length()).trim() };
        }
        return { full, {} };
    }

    void paintNoticePill (juce::Graphics& g, juce::Rectangle<int> nameArea, float fontSize, float maxPillH)
    {
        const juce::Font f (juce::FontOptions (fontSize).withStyle ("Bold"));
        const auto amber = juce::Colour (0xfff0b429), red = juce::Colour (0xfff05252);
        const auto base = noticeKind == 3 ? red : (noticeKind == 4 ? Col::accent : amber);
        const float textW = juce::GlyphArrangement::getStringWidth (f, noticeText);
        auto pill = nameArea.toFloat().withSizeKeepingCentre ((float) nameArea.getWidth(),
                                                              juce::jmin (maxPillH, (float) nameArea.getHeight()));
        pill.setWidth (juce::jmin (pill.getWidth(), textW + 30.0f));
        const float r = pill.getHeight() * 0.5f;
        if (noticeKind == 2) { g.setColour (base); g.fillRoundedRectangle (pill, r); }
        else
        {
            g.setColour (base.withAlpha (0.16f)); g.fillRoundedRectangle (pill, r);
            g.setColour (base.withAlpha (0.55f)); g.drawRoundedRectangle (pill.reduced (0.5f), r, 1.0f);
        }
        const auto dot = juce::Rectangle<float> (6.0f, 6.0f).withCentre ({ pill.getX() + 12.0f, pill.getCentreY() });
        g.setColour (noticeKind == 2 ? juce::Colour (0xff231a00) : base);
        g.fillEllipse (dot);
        g.setFont (f);
        g.setColour (noticeKind == 2 ? juce::Colour (0xff231a00) : base.brighter (0.25f));
        g.drawText (noticeText, pill.withTrimmedLeft (22.0f).withTrimmedRight (8.0f).toNearestInt(),
                    juce::Justification::centredLeft, true);
    }

    void paintCard (juce::Graphics& g)
    {
        auto card = getLocalBounds().toFloat().reduced (0.5f);
        g.setColour (Col::isLight ? Col::panel2 : Col::panel.darker (0.28f));
        g.fillRoundedRectangle (card, 7.0f);
        g.setColour (Col::line);
        g.drawRoundedRectangle (card, 7.0f, 1.0f);

        auto r = getLocalBounds().reduced (10, 7);

        // Hang 1: DANG PHAT ............ gio
        auto top = r.removeFromTop (14);
        g.setFont (juce::Font (juce::FontOptions (11.0f).withStyle ("SemiBold")));
        g.setColour (live ? Col::accent : Col::text);
        const auto timeText = getTimeText();
        const int timeW = (int) std::ceil (juce::GlyphArrangement::getStringWidth (g.getCurrentFont(), timeText)) + 2;
        g.drawText (timeText, top.removeFromRight (timeW), juce::Justification::centredRight, false);
        g.setFont (juce::Font (juce::FontOptions (9.5f).withStyle ("Bold")).withExtraKerningFactor (0.08f));
        g.setColour (Col::textDim);
        g.drawText (livent::vn ("ĐANG PHÁT"), top, juce::Justification::centredLeft, true);
        r.removeFromTop (3);

        // Hang 2: ten bai (chay chu neu dai) + o tong
        const auto parts = splitTitle (title);
        const auto shown = title.isNotEmpty() ? parts.first : livent::vn ("Chưa có bài hát");
        auto line = r.removeFromTop (20);
        if (title.isNotEmpty() && keyBadge.isNotEmpty())
        {
            const juce::Font bf (juce::FontOptions (10.5f).withStyle ("Bold"));
            const float bw = juce::GlyphArrangement::getStringWidth (bf, keyBadge) + 12.0f;
            const juce::Font tf (juce::FontOptions (15.0f).withStyle ("Bold"));
            const float tw = juce::GlyphArrangement::getStringWidth (tf, shown);
            const float x = (float) line.getX() + juce::jmin (tw + 8.0f, (float) line.getWidth() - bw);
            const auto badge = juce::Rectangle<float> (x, (float) line.getCentreY() - 8.5f, bw, 17.0f);
            g.setColour (Col::accent.withAlpha (0.18f)); g.fillRoundedRectangle (badge, 4.0f);
            g.setColour (Col::accent.withAlpha (0.75f)); g.drawRoundedRectangle (badge.reduced (0.5f), 4.0f, 1.0f);
            g.setColour (Col::isLight ? Col::accent.darker (0.3f) : Col::accent.brighter (0.45f));
            g.setFont (bf);
            g.drawText (keyBadge, badge.toNearestInt(), juce::Justification::centred, false);
            line.setRight ((int) x - 6);
        }
        paintMarqueeTitle (g, line, shown, juce::Font (juce::FontOptions (15.0f).withStyle ("Bold")));
        r.removeFromTop (2);

        // Hang 3: ca si, hoac thong bao (doi tong / may chu loi...)
        auto info = r.removeFromTop (20);
        if (noticeKind != 0)
            paintNoticePill (g, info, 11.0f, 19.0f);
        else if (parts.second.isNotEmpty())
        {
            g.setFont (juce::Font (juce::FontOptions (11.5f)));
            g.setColour (Col::textDim);
            g.drawText (parts.second, info, juce::Justification::centredLeft, true);
        }

        // Thanh tien trinh + cham vang moc doi tong
        auto bar = r.withTrimmedTop (juce::jmax (0, r.getHeight() - 7)).toFloat();
        bar = bar.withSizeKeepingCentre (bar.getWidth(), 3.0f);
        g.setColour (Col::line.withAlpha (0.9f));
        g.fillRoundedRectangle (bar, 1.5f);
        if (total > 1.0)
        {
            const float frac = (float) juce::jlimit (0.0, 1.0, position / total);
            g.setColour (Col::accent);
            g.fillRoundedRectangle (bar.withWidth (juce::jmax (3.0f, bar.getWidth() * frac)), 1.5f);
            g.setColour (juce::Colour (0xfff0b429));
            for (auto s : marks)
                if (s > 0.0 && s < total)
                    g.fillEllipse (juce::Rectangle<float> (7.0f, 7.0f)
                                       .withCentre ({ bar.getX() + bar.getWidth() * (float) (s / total), bar.getCentreY() }));
        }
    }

    void paintMarqueeTitle (juce::Graphics& g, juce::Rectangle<int> nameArea, const juce::String& shown, const juce::Font& titleFont)
    {
        const float titleW = juce::GlyphArrangement::getStringWidth (titleFont, shown);
        const float loopGap = 42.0f;
        scrollActive = titleW > (float) nameArea.getWidth();
        marqueeLimit = juce::jmax (0.0f, titleW + loopGap);

        g.setFont (titleFont);
        g.setColour (title.isNotEmpty() ? Col::text : Col::textDim);

        g.saveState();
        g.reduceClipRegion (nameArea);
        const int w = juce::jmax (nameArea.getWidth(), (int) std::ceil (titleW + 4.0f));
        const int x = nameArea.getX() - (scrollActive ? (int) marqueePx : 0);
        g.drawText (shown, x, nameArea.getY(), w, nameArea.getHeight(), juce::Justification::centredLeft, false);
        if (scrollActive)
            g.drawText (shown, x + (int) std::ceil (titleW + loopGap), nameArea.getY(), w,
                        nameArea.getHeight(), juce::Justification::centredLeft, false);
        g.restoreState();
    }

    /*  V6.3.5: o nay chi ve TEN BAI. Dong ho duoc dua len ngay canh chu
        "Dang phat" o hang caption de tra lai toan bo be ngang cho ten bai. */
    void paint (juce::Graphics& g) override
    {
        if (cardMode)
        {
            paintCard (g);
            return;
        }

        auto nameArea = getLocalBounds();

        if (noticeKind != 0)
        {
            paintNoticePill (g, nameArea, 12.5f, 22.0f);
            return;
        }
        const auto shown = title.isNotEmpty() ? title : livent::vn ("Chưa có bài hát");
        paintMarqueeTitle (g, nameArea, shown, juce::Font (juce::FontOptions (14.0f).withStyle ("Medium")));
    }

private:
    void timerCallback() override
    {
        //  V6.0: chi ve lai khi ten bai dang chay chu - dung yen thi khong ton gi
        if (! scrollActive)
            return;

        if (scrollActive)
        {
            if (pauseTicks > 0) --pauseTicks;
            else
            {
                marqueePx += 0.70f;
                if (marqueeLimit > 0.0f && marqueePx >= marqueeLimit)
                {
                    marqueePx = 0.0f;
                    pauseTicks = 30;
                }
            }
        }
        else
        {
            marqueePx = 0.0f;
        }
        repaint();
    }

    static constexpr int historyCount = 72;
    float history[historyCount] {};
    juce::String title;
    double position = 0.0, total = 0.0;
    bool live = false;
    float marqueePx = 0.0f;
    float marqueeLimit = 0.0f;
    bool scrollActive = false;
    int pauseTicks = 0;
    juce::String noticeText;
    int noticeKind = 0;
    bool cardMode = false;          // 15/10
    juce::String keyBadge;
    juce::Array<double> marks;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (NowPlayingStrip)
};


// V5.8.6: num live co wheel min hon Slider mac dinh.
// Shift + lan chuot = tinh chinh 1/4 toc do.
class LiveFineKnob final : public juce::Slider
{
public:
    void setFineWheelStep (double unitsPerDeltaOne) noexcept
    {
        fineWheelStep = juce::jmax (0.0, unitsPerDeltaOne);
    }

    void mouseWheelMove (const juce::MouseEvent& e,
                         const juce::MouseWheelDetails& wheel) override
    {
        if (! isEnabled() || fineWheelStep <= 0.0)
            return;

        double delta = std::abs (wheel.deltaY) >= std::abs (wheel.deltaX)
                         ? (double) wheel.deltaY : (double) wheel.deltaX;
        if (wheel.isReversed)
            delta = -delta;

        const double fine = e.mods.isShiftDown() ? 0.25 : 1.0;
        double move = delta * fineWheelStep * fine;

        /* 02/10 FIX: num co buoc nhay (vd Flex tune 0..100 buoc 1) ma moi nac
           lan chi cong ~0.5 -> setValue lam tron ve cho cu, num dung im.
           Cong don phan le; chuot co nac thi moi nac it nhat 1 buoc. */
        const double iv = getInterval();
        if (iv > 0.0)
        {
            if (! wheel.isSmooth && std::abs (move) < iv && move != 0.0)
                move = move > 0.0 ? iv : -iv;

            wheelRemainder += move;
            const double steps = wheelRemainder >= 0.0 ? std::floor (wheelRemainder / iv)
                                                       : std::ceil  (wheelRemainder / iv);
            if (steps == 0.0)
                return;
            move = steps * iv;
            wheelRemainder -= move;
        }

        const double next = juce::jlimit (getMinimum(), getMaximum(), getValue() + move);
        setValue (next, juce::sendNotificationSync);
    }

    /** 11h: chuot phai len num -> hop nhap so bang tay. */
    std::function<void()> onAskValue;

    void mouseDown (const juce::MouseEvent& e) override
    {
        askedByPopup = e.mods.isPopupMenu() && onAskValue != nullptr && isEnabled();
        if (askedByPopup) { onAskValue(); return; }
        juce::Slider::mouseDown (e);
    }
    void mouseDrag (const juce::MouseEvent& e) override { if (! askedByPopup) juce::Slider::mouseDrag (e); }
    void mouseUp (const juce::MouseEvent& e) override
    {
        if (askedByPopup) { askedByPopup = false; return; }
        juce::Slider::mouseUp (e);
    }

private:
    double fineWheelStep = 1.0;
    double wheelRemainder = 0.0;
    bool askedByPopup = false;
};

/*  V0.6.7.9e: thanh song NAM NGAY TREN NUT (Tune, Nhac, Mic, Vang, Lofi...).
    Moi nut mot mau rieng. Cung duoc TonePanel poll() tu chung timer 30 Hz voi
    meter canh num - chi ve lai khi muc thay doi, re CPU. Khong bat chuot:
    bam vao van la bam nut ben duoi.  */
class ChipMeter : public juce::Component
{
public:
    explicit ChipMeter (juce::Colour c = juce::Colours::white) : colour (c)
    {
        setInterceptsMouseClicks (false, false);
    }

    std::function<float()> getLevelSource;
    /** 16/10: nguon 2 kenh. Dong ho van MOT khung cung rong mono, ben trong 2 duong. */
    std::function<void (float&, float&)> getStereoSource;
    void setNumLines (int n) noexcept { numLines = n >= 2 ? 2 : 1; repaint(); }
    void setColour (juce::Colour c) { if (colour != c) { colour = c; repaint(); } }

    void poll()
    {
        float vL = 0.0f, vR = 0.0f;
        if (getStereoSource) getStereoSource (vL, vR);
        else vL = vR = (getLevelSource ? getLevelSource() : 0.0f);
        const float v  = juce::jmax (vL, vR);
        const float db = juce::Decibels::gainToDecibels (v, -54.0f);
        const float target = juce::jlimit (0.0f, 1.0f, juce::jmap (db, -54.0f, 0.0f, 0.0f, 1.0f));
        const float next   = target > level ? target : juce::jmax (target, level - 0.04f);

        auto toProp = [] (float lin) { return juce::jlimit (0.0f, 1.0f, juce::jmap (juce::Decibels::gainToDecibels (lin, -54.0f), -54.0f, 0.0f, 0.0f, 1.0f)); };
        const float tL = toProp (vL), tR = toProp (vR);
        const float nL = tL > lvL ? tL : juce::jmax (tL, lvL - 0.04f);
        const float nR = tR > lvR ? tR : juce::jmax (tR, lvR - 0.04f);

        if (next >= peak) { peak = next; peakHold = 18; }
        else if (peakHold > 0) --peakHold;
        else peak = juce::jmax (next, peak - 0.02f);

        if (std::abs (next - level) > 0.004f || std::abs (peak - shownPeak) > 0.004f
            || std::abs (nL - lvL) > 0.004f || std::abs (nR - lvR) > 0.004f)
        {
            level = next;
            lvL = nL; lvR = nR;
            shownPeak = peak;
            repaint();
        }
    }

    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat();

        if (livent::rack::active())
        {
            // 16/10 (12o): kieu D ngang - khung toi, do vao mau chuc nang -> trang, vach dinh trang.
            // Stereo = 2 duong cach nhau 3 px; mono = 1 duong rong cung khung.
            livent::rack::drawMeterFrame (g, r, 2.5f);
            auto inner = r.reduced (2.0f, 1.0f);
            if (numLines == 2)
            {
                const float laneH = juce::jmax (1.5f, (inner.getHeight() - 3.0f) * 0.5f);
                livent::rack::drawMeterLaneH (g, inner.withHeight (laneH), lvL, colour);
                livent::rack::drawMeterLaneH (g, inner.withTop (inner.getBottom() - laneH), lvR, colour);
            }
            else
                livent::rack::drawMeterLaneH (g, inner, level, colour);
            if (shownPeak > 0.02f && level > 0.0f)
            {
                g.setColour (juce::Colours::white);
                g.fillRect (inner.getX() + (inner.getWidth() - 1.5f) * shownPeak, r.getY() + 1.0f, 1.5f, r.getHeight() - 2.0f);
            }
            return;
        }

        const float rad = r.getHeight() * 0.5f;

        g.setColour (colour.withAlpha (Col::isLight ? 0.30f : 0.26f));   // V0.6.7.9f: ranh ro hon luc im
        g.fillRoundedRectangle (r, rad);

        if (level > 0.002f)
        {
            auto f = r.withWidth (juce::jmax (r.getHeight(), r.getWidth() * level));
            if (! Col::isLight)
            {
                g.setColour (colour.withAlpha (0.22f));
                g.fillRoundedRectangle (f.expanded (0.0f, 1.2f), rad + 1.0f);   // quang sang nhe
            }
            g.setGradientFill (juce::ColourGradient (colour.darker (0.25f), f.getX(), 0.0f,
                                                     colour.brighter (0.25f), f.getRight(), 0.0f, false));
            g.fillRoundedRectangle (f, rad);
        }

        if (shownPeak > 0.02f)
        {
            const float x = r.getX() + (r.getWidth() - 2.0f) * shownPeak;
            g.setColour (colour.brighter (0.5f));
            g.fillRect (x, r.getY(), 2.0f, r.getHeight());
        }
    }

private:
    juce::Colour colour;
    float level = 0.0f, peak = 0.0f, shownPeak = 0.0f;
    float lvL = 0.0f, lvR = 0.0f;
    int   numLines = 1;
    int   peakHold = 0;
};

/*  V6.0: thanh meter mong dung canh moi num tren Bang dieu khien.
    Khong co timer rieng - TonePanel goi poll() cho ca 7 cai tu MOT timer,
    va chi ve lai khi muc tieng doi that su.  */
class KnobMeter : public juce::Component
{
public:
    KnobMeter()  { setInterceptsMouseClicks (false, false); }

    std::function<float()> getLevelSource;
    /** 16/10: nguon 2 kenh - van MOT khung, ben trong nhay 2 duong (4 px, cach 4 px) hoac 1 cot rong (mono). */
    std::function<void (float&, float&)> getStereoSource;
    void setNumLines (int n) noexcept { numLines = n >= 2 ? 2 : 1; repaint(); }
    /** 12o: mau chuc nang cua num (kieu D: mau -> trang). */
    void setColour (juce::Colour c) { if (colour != c) { colour = c; repaint(); } }

    void poll()
    {
        float vL = 0.0f, vR = 0.0f;
        if (getStereoSource) getStereoSource (vL, vR);
        else vL = vR = (getLevelSource ? getLevelSource() : 0.0f);
        const float v  = juce::jmax (vL, vR);
        auto follow = [] (float lin, float cur)
        {
            const float db = juce::Decibels::gainToDecibels (lin, -60.0f);
            const float t = juce::jlimit (0.0f, 1.0f, juce::jmap (db, -60.0f, 0.0f, 0.0f, 1.0f));
            return t > cur ? t : juce::jmax (t, cur - 0.035f);
        };
        const float next = follow (v, level);
        const float nL = follow (vL, levelL), nR = follow (vR, levelR);
        const bool  clip   = v >= 0.99f;

        if (next >= peak) { peak = next; peakHold = 45; }          // giu dinh ~1.5 s (30 Hz)
        else if (peakHold > 0) --peakHold;
        else peak = juce::jmax (next, peak - 0.02f);

        if (std::abs (next - level) > 0.004f || clip != clipped
            || std::abs (nL - levelL) > 0.004f || std::abs (nR - levelR) > 0.004f
            || std::abs (peak - shownPeak) > 0.004f)
        {
            level   = next;
            levelL  = nL; levelR = nR;
            shownPeak = peak;
            clipped = clip;
            repaint();
        }
    }

    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat();
        const bool rack = livent::rack::active();
        if (rack)
        {
            // kieu D dung: khung toi ~14 px; stereo 2 lane 4 px cach 4 px; mono 1 cot rong
            livent::rack::drawMeterFrame (g, r, 2.5f);
            auto inner = r.reduced (1.0f, 1.0f);
            if (numLines == 2)
            {
                const float laneW = juce::jmax (2.0f, (inner.getWidth() - 4.0f) * 0.5f);
                livent::rack::drawMeterLaneV (g, inner.withWidth (laneW), levelL, colour);
                livent::rack::drawMeterLaneV (g, inner.withLeft (inner.getRight() - laneW), levelR, colour);
            }
            else
                livent::rack::drawMeterLaneV (g, inner, level, colour);

            if (shownPeak > 0.02f && level > 0.0f)
            {
                g.setColour (juce::Colours::white);
                g.fillRect (inner.getX(), inner.getBottom() - inner.getHeight() * shownPeak - 1.0f, inner.getWidth(), 1.5f);
            }
            if (clipped)
            {
                g.setColour (Col::red);
                g.fillRect (inner.withHeight (2.0f));
            }
            return;
        }

        g.setColour (Col::bg);
        g.fillRoundedRectangle (r, 3.0f);
        g.setColour (Col::line);
        g.drawRoundedRectangle (r.reduced (0.5f), 3.0f, 1.0f);

        auto inner = r.reduced (1.5f);

        auto drawLane = [&] (juce::Rectangle<float> lane, float lv)
        {
            const float h = lane.getHeight() * lv;
            if (h <= 0.5f)
                return;
            g.setColour (Col::green);
            g.fillRoundedRectangle (lane.withTop (lane.getBottom() - h), 2.0f);
        };

        if (numLines == 2)
        {
            auto left = inner.removeFromLeft ((inner.getWidth() - 1.0f) * 0.5f);
            inner.removeFromLeft (1.0f);
            drawLane (left, levelL);
            drawLane (inner, levelR);
        }
        else
            drawLane (inner, level);

        if (clipped)
        {
            g.setColour (Col::red);
            g.fillRect (r.reduced (1.5f).withHeight (3.0f));
        }
    }

private:
    juce::Colour colour { juce::Colour (0xff2f8bff) };
    float level   = 0.0f, levelL = 0.0f, levelR = 0.0f;
    float peak    = 0.0f, shownPeak = 0.0f;
    int   numLines = 1;
    int   peakHold = 0;
    bool  clipped = false;
};

class TonePanel : public juce::Component,
                  private juce::Timer
{
    /*  V0.6.7.9c: nut NGUON cho Tone nhac - bat/tat VST so 1 cua track NHAC
        (plugin doi tone). Ve bieu tuong nguon bang Path, mat nut dung chung
        kieu voi M/m (liveChipStyle) nen hai cot thang hang, dong bo.  */
    class PowerIconButton : public juce::TextButton
    {
    public:
        PowerIconButton() : juce::TextButton ("power") { setButtonText ({}); }

        void paintButton (juce::Graphics& g, bool over, bool down) override
        {
            getLookAndFeel().drawButtonBackground (g, *this, findColour (juce::TextButton::buttonColourId), over, down);

            const bool on = getToggleState();
            auto r = getLocalBounds().toFloat();
            const float d = juce::jmin (r.getWidth(), r.getHeight()) * 0.40f;
            auto c = juce::Rectangle<float> (d, d).withCentre (r.getCentre().translated (0.0f, down ? 1.0f : 0.0f));

            juce::Path p;
            p.addCentredArc (c.getCentreX(), c.getCentreY(), d * 0.5f, d * 0.5f, 0.0f,
                             juce::degreesToRadians (35.0f), juce::degreesToRadians (325.0f), true);
            p.startNewSubPath (c.getCentreX(), c.getY() - d * 0.08f);
            p.lineTo (c.getCentreX(), c.getCentreY());

            const auto colour = ! isEnabled() ? Col::textDim.withAlpha (0.35f)
                              : on            ? Col::accent
                                              : Col::textDim;
            if (on && ! Col::isLight)
            {
                g.setColour (Col::accent.withAlpha (0.22f));
                g.strokePath (p, juce::PathStrokeType (4.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            }
            g.setColour (colour);
            g.strokePath (p, juce::PathStrokeType (1.9f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
    };

    /* V6.1: nut mui ten thu/phong hang 7 num. Tu ve bang Path de khong
       phu thuoc font/emoji cua Windows. */
    class KnobFoldButton : public juce::Button
    {
    public:
        KnobFoldButton() : juce::Button ("knob-fold")
        {
            setWantsKeyboardFocus (false);
        }

        void setExpanded (bool shouldBeExpanded)
        {
            if (expanded != shouldBeExpanded)
            {
                expanded = shouldBeExpanded;
                repaint();
            }
        }

        void setHorizontal (bool shouldBeHorizontal)
        {
            if (horizontal != shouldBeHorizontal)
            {
                horizontal = shouldBeHorizontal;
                repaint();
            }
        }

        void paintButton (juce::Graphics& g, bool over, bool down) override
        {
            auto r = getLocalBounds().toFloat().reduced (1.0f);

            if (over || down)
            {
                g.setColour (Col::raised.interpolatedWith (Col::accent, down ? 0.28f : 0.14f));
                g.fillRoundedRectangle (r, 6.0f);
            }

            g.setColour (over ? Col::accent.brighter (0.15f) : Col::textDim);

            const float cx = r.getCentreX();
            const float cy = r.getCentreY();
            const float dx = 5.0f;
            const float dy = 2.7f;

            juce::Path chevron;

            if (horizontal)
            {
                // Bo cuc doc: hang num mo sang BEN PHAI, nen mui ten cung
                // di trai/phai thay vi tren/duoi.
                if (expanded)
                {
                    chevron.startNewSubPath (cx + dy, cy - dx);
                    chevron.lineTo (cx - dy, cy);
                    chevron.lineTo (cx + dy, cy + dx);
                }
                else
                {
                    chevron.startNewSubPath (cx - dy, cy - dx);
                    chevron.lineTo (cx + dy, cy);
                    chevron.lineTo (cx - dy, cy + dx);
                }
            }
            else if (expanded)
            {
                // Dang mo: ^ = bam de thu gon hang num.
                chevron.startNewSubPath (cx - dx, cy + dy);
                chevron.lineTo (cx, cy - dy);
                chevron.lineTo (cx + dx, cy + dy);
            }
            else
            {
                // Dang thu gon: v = bam de mo lai hang num.
                chevron.startNewSubPath (cx - dx, cy - dy);
                chevron.lineTo (cx, cy + dy);
                chevron.lineTo (cx + dx, cy - dy);
            }

            g.strokePath (chevron, juce::PathStrokeType (1.5f,   // 15/10: net bang cac nut thanh tieu de
                                                         juce::PathStrokeType::curved,
                                                         juce::PathStrokeType::rounded));
        }

    private:
        bool expanded = true;
        bool horizontal = false;
    };

public:
    /** MOC 36: goi sau moi lan bam mot trong bay nut dien. */
    std::function<void()> onLiveStateChanged;

    /*  V4.5: nut AUTO TUNE tren Bang dieu khien chi co mot nhiem vu:
        mo giao dien VST so 1 (slot 0) cua track MIC. Viec mo cua so plugin
        van do MainComponent / PluginWindowManager quan ly de khong tao mot
        duong mo plugin thu hai. */
    std::function<void()> onOpenAutoTune;
    std::function<void()> onButtonNamesChanged;   // 14/10: da doi ten nut (chuot phai)
    std::function<void (Track*, int)> onOpenPluginSlot;     // 06/10: "Mo cua so VST" trong bang EQ
    std::function<void (const juce::String&, const juce::String&, bool)> onSongInfo;   // 07/10
    std::function<void (const juce::String&, int)> onFooterNotice;   // 14/10: o thong bao (xem NowPlayingStrip::setNotice)
    std::function<void()> onOpenButtonMapSettings;          // 06/10: Cai dat > Gan nut
    std::function<void(bool)> onManualDetectChanged;
    std::function<void()> onManualSongChanged;
    std::function<void()> onToneDetectionFailed;
    std::function<void()> onSongChanged;
    bool isManualDetectMode()const noexcept{return manualDetectMode;}
    double getAutoKeyPlaybackSeconds() const
    { return autoKeyPlaybackClock.current (juce::Time::getMillisecondCounterHiRes() / 1000.0); }
    bool followsPluginTone()const noexcept{return pluginToneFollowing && ! automationOwnsTone;}   // 12s: Do khong AI -> DAW giu Key (khong doc nguoc tu VST)
    void beginAutoKeySequence()
    {
        cancelDetectedFlash();
        pluginToneFollowing=true;
        ++toneWriteSerial;pluginToneWriteUntilMs=0;
        resetManualKeyScaleAdjustments();
        syncToneFromPlugin();
        clock.setMarks({},baseKey,baseScale);
    }
    void autoKeySequenceFinished()
    {
        const auto serial=detectRequestSerial;
        juce::Component::SafePointer<TonePanel> safe(this);
        juce::Timer::callAfterDelay(500,[safe,serial]
        {
            if(safe==nullptr || serial!=safe->detectRequestSerial || !safe->followsPluginTone())return;
            if(safe->syncToneFromPlugin())
            {
                safe->showAutoKeyStatus(livent::vn("Đã chạy hết lịch bấm; Key/Scale đang theo VST nhận tone."));
                safe->flashDetectedTone();
                safe->autoSaveDetectedSong();
            }
            else safe->showAutoKeyStatus(livent::vn("Đã chạy hết lịch bấm nhưng chưa đọc được Key/Scale ở track đích."));
        });
    }
    void showAutoKeyStatus(const juce::String& text)
    {statusLabel.setText(text,juce::dontSendNotification);failureNoticeUntilMs=juce::Time::getMillisecondCounter()+3000;}

    /*  ==========  12s: T-AUTOKEY CO SAN (thay tu bam Antares Auto-Key)  ==========
        - Do AI     : AI NT / AI HC do truoc. AI loi / khong ra Key / video khong gui duoc
                      -> T-AutoKey THUC DAY do realtime. Bai moi -> NGU lai, gui AI truoc.
        - Do khong AI: T-AutoKey luon thuc, khong gui may chu. Im 5 giay = doi bai -> do lai.
        T-AutoKey nghe tieng DANG PHAT (sau con nang / ha tong) nen Key nghe duoc da gom
        tong lech -> tru tong lech ra lam Key goc, sendShiftedKey() cong lai nhu duong AI.  */
    bool builtinKeyWanted() const noexcept { return manualDetectMode || builtinFallbackActive; }

    void updateKeyModeTag() { keyModeTag.setText (builtinKeyWanted() ? juce::String ("AK") : juce::String ("AI")); }

    void startBuiltinFallback (const juce::String& why)
    {
        if (manualDetectMode) return;
        builtinFallbackActive = true;
        builtinKeyFirstForSong = true;
        livent::builtinkey::Detector::get().wake();
        updateKeyModeTag();
        showAutoKeyStatus (why + livent::vn (" · T-AutoKey đang dò trên track NHẠC"));
    }

    void stopBuiltinFallback()
    {
        if (! builtinFallbackActive) return;
        builtinFallbackActive = false;
        if (! manualDetectMode) livent::builtinkey::Detector::get().sleep();
        updateKeyModeTag();
    }

    /** Do khong AI: bai moi (link moi / bai trong Danh sach) -> do lai tu dau. */
    void builtinNewSong()
    {
        if (! manualDetectMode || automationOwnsTone) return;
        builtinKeyFirstForSong = true;
        auto& d = livent::builtinkey::Detector::get();
        if (d.isListening()) d.restartAnalysis(); else d.wake();
    }

    void pollBuiltinKey()
    {
        auto& d = livent::builtinkey::Detector::get();
        const bool want = builtinKeyWanted();
        if (want != d.isListening())
        {
            if (want) { builtinKeyFirstForSong = true; d.wake(); }
            else d.sleep();
        }
        if (! want) return;
        // Nhac doi tong (nut +/-, moc doi tong, nap du an...) -> bo du lieu tong cu, nghe lai.
        // Lam TRUOC popKey: Key tinh tu tong cu bi bo (BuiltinKey epoch).
        if (const int shift = semitoneShift(); shift != builtinLastShift)
        {
            builtinLastShift = shift;
            d.restartAnalysis();
        }
        if (d.popSongRestart())
        {
            builtinKeyFirstForSong = true;
            showAutoKeyStatus (livent::vn ("Có nhạc lại · T-AutoKey đang dò tông mới..."));
        }
        int encoded = -1;
        if (d.popKey (encoded)) applyBuiltinKey (encoded);
    }

    void applyBuiltinKey (int encoded)
    {
        if (automationOwnsTone) return;   // bai mo tu Danh sach co tone da luu: giu tone da luu
        static const char* names[] = { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" };
        const int heard = encoded % 12;
        const int original = ((heard - semitoneShift()) % 12 + 12) % 12;
        const juce::String key (names[original]);
        const juce::String scale (encoded >= 12 ? "Minor" : "Major");
        const bool first = builtinKeyFirstForSong;
        builtinKeyFirstForSong = false;
        if (! first && key == baseKey && scale == baseScale) return;
        clock.setMarks ({}, key, scale);
        pushToPlugin (getSelectedTrackId(), key, scale);
        if (first) { flashDetectedTone(); autoSaveDetectedSong(); }
        showAutoKeyStatus (livent::vn ("T-AutoKey: ") + key + " " + scale
                           + (first ? juce::String() : livent::vn (" (đổi tông giữa bài)")));
    }


    /*  MOC 37: tong lech, don vi TONG. De MainComponent luu vao file .NT.

        setToneOffsetSilently() chi dat con so va ve lai o, KHONG dong vao
        plugin. Dung luc DANG NAP du an: luc do track NHAC co the chua nap
        xong plugin, ma co nap xong thi trang thai plugin cung da duoc khoi
        phuc tu file roi -- ghi de len la hong dung cai vua khoi phuc.  */
    float getToneOffsetTong() const   { return toneOffsetTong; }

    // V5.8: hai lenh nay duoc goi tu thanh window tu tao cua LiveNT.
    // Giu logic luu/danh sach o MOT noi trong TonePanel, thanh title chi la nut goi.
    void openSaveSongDialog()       { saveCurrentSongManual(); }
    void openSaveSongMenu (juce::Component* anchor = nullptr) { showSaveSongQuickMenu (anchor); }
    void openSongLibraryWindow()    { showSongLibrary(); }
    void openSongAutoSaveOptions()  { showSongAutoSaveMenu(); }

    // V6.0.1: nút CƯỜI nằm trên thanh menu cạnh DS bài.
    // MainComponent truyền bounds của TOÀN cửa sổ LiveNT theo tọa độ màn hình.
    // Popup luôn nằm NGOÀI DAW: hoặc ngay dưới, hoặc ngay trên; rộng bằng DAW.
    void toggleLaughPanel (juce::Rectangle<int> anchorScreen = {})
    {
        if (laughWindow != nullptr)
            closeLaughPopup();
        else
            openLaughPopup (anchorScreen);
    }

    bool isLaughPanelOpen() const noexcept { return laughWindow != nullptr; }
    void closeLaughPanel() { closeLaughPopup(); }

    // V6.3.5: khi thu gon hang 7 num, co the giu lai hai meter tong NHAC/MIC
    // o hai mep bang dieu khien. Tuy chon nay nam trong menu Hien thi.
    bool isCompactMetersVisible() const noexcept { return compactMetersVisible; }

    // V6.6 FIX: lưu được trạng thái thu gọn/mở rộng 7 núm theo từng project.
    bool areKnobsExpanded() const noexcept { return knobsExpanded; }

    /** 30/09: mui ten thu/mo hang num de MainComponent gan len thanh trang
        thai (khi AppBranding foldArrowOnStatusBar = true). */
    juce::Button& getStatusFoldButton() noexcept { return statusFold; }

    //==========================================================================
    //  01/10: GAN NUT (Cai dat > Gan nut). Luu trong file du an.
    //==========================================================================
    livent::buttonmap::Map&       getButtonMap() noexcept        { return buttonMap; }
    const livent::buttonmap::Map& getButtonMap() const noexcept  { return buttonMap; }

    /** Goi sau khi doi cach gan: to mau lai nut + num ngay. */
    void buttonMapChanged()
    {
        refreshLiveButtons();
        refreshRemoteKnobs();
    }

    //==========================================================================
    //  02/10: PRESET THE LOAI
    //==========================================================================
    livent::presets::Bank& getPresetBank() noexcept { return presetBank; }

    /** Goi khi preset doi (luu / doi ten / nhap) -> MainComponent danh dau du an da sua. */
    std::function<void()> onPresetsChanged;

    /** Sau khi nap du an / du an moi: cap nhat chu tren nut. */
    void presetsReloaded()
    {
        updatePresetButton();
        syncFolkWithPreset();   // 06/10: mo du an dang chon preset Dan ca -> Dorian
    }

    /** 06/10: Dan ca di theo preset dang chon. Doi che do thi gui lai tone. */
    void syncFolkWithPreset()
    {
        const int c = presetBank.current;
        const bool folk = c >= 0 && livent::presets::isFolkName (presetBank[c].name);
        if (TonePush::setFolkScaleActive (folk))
            folkModeChanged();
    }

    /** 06/10: che do Dan ca vua doi -> gui lai tone bai dang hat ngay. */
    void folkModeChanged()
    {
        if (followsPluginTone() && mirroredKey.isNotEmpty())
        {
            const auto current = mirroredScale;
            mirroredScale.clear();          // ep lan doc sau so lai
            if (TonePush::usesFolkScale())
            {
                // Vao Dan ca: nho Scale dang chay roi ghi Dorian (TonePush tu doi)
                if (current.isNotEmpty() && ! current.equalsIgnoreCase (TonePush::folkScaleName()))
                    folkSourceScale = current;
                pushToPluginRaw (getSelectedTrackId(), mirroredKey, current.isNotEmpty() ? current : juce::String ("Major"));
            }
            else
            {
                // Thoat Dan ca: tra lai Scale goc truoc do
                const auto back = folkSourceScale.isNotEmpty() ? folkSourceScale
                                : (current.isNotEmpty() && ! current.equalsIgnoreCase (TonePush::folkScaleName())
                                       ? current : juce::String ("Major"));
                pushToPluginRaw (getSelectedTrackId(), mirroredKey, back);
            }
        }
        else
            sendShiftedKey();
        refreshKeyDisplay();
        updatePresetButton();
    }

    /** Ap preset so i (0..3). Phim tat Ctrl+1..4 goi vao day. */
    void applyPreset (int i)
    {
        if (! juce::isPositiveAndBelow (i, livent::presets::kCount))
            return;
        const auto& p = presetBank[i];
        if (p.isEmpty() && livent::presets::isFolkName (p.name))
        {
            // 06/10: preset Dan ca chua luu thong so van chon duoc - chi doi Scale Dorian
            presetBank.current = i;
            updatePresetButton();
            syncFolkWithPreset();
            statusLabel.setText (livent::vn ("Preset Dân ca: Scale gửi Dorian (preset chưa lưu thông số vang / nút)."),
                                 juce::dontSendNotification);
            if (onPresetsChanged)
                onPresetsChanged();
            return;
        }
        if (p.isEmpty())
        {
            livent::alert (livent::vn ("Preset"),
                           livent::vn ("Preset \"") + p.name + livent::vn ("\" chưa lưu gì.\n\n"
                           "Chỉnh vang / tune / nút như ý, rồi bấm nút Preset > \"Lưu trạng thái hiện tại vào\"."));
            return;
        }

        const auto skipped = livent::presets::apply (mixer, p);
        presetBank.current = i;
        TonePush::setFolkScaleActive (livent::presets::isFolkName (p.name));   // 06/10: Dan ca theo preset

        refreshLiveButtons();
        refreshRemoteKnobs();
        sendShiftedKey();          // Auto-Tune giu dung Key bai dang hat
        updatePresetButton();
        announceChange();
        if (onPresetsChanged)
            onPresetsChanged();

        if (! skipped.isEmpty())
            juce::AlertWindow::showMessageBoxAsync (juce::MessageBoxIconType::WarningIcon,
                livent::vn ("Preset: có VST không khớp"),
                livent::vn ("Đã áp preset \"") + p.name + livent::vn ("\", riêng các ô dưới đây bị bỏ qua "
                "(máy này khác VST hoặc thiếu VST):\n\n") + skipped.joinIntoString ("\n"));
    }

    /** Dich cua nut Tune (de mo dung Auto-Tune). trackId <= 0 = nhu cu. */
    void getTuneTarget (int& trackId, int& slot) const
    {
        trackId = 0; slot = 0;
        const auto b = buttonMap.get ("tune");
        if (b.act == livent::buttonmap::Act::ToggleInsert)
        {
            if (auto* t = boundTrack (b))
            {
                trackId = t->getId();
                slot = b.slot;
            }
            return;
        }
        // 11/10: khong gan nut Tune -> theo muc "Auto-Tune" (tu tim MIC o 1, khong co thi track khac)
        const auto at = livent::vstctl::findAutoTune (mixer, buttonMap, micTrack());
        if (at.track != nullptr)
        {
            trackId = at.track->getId();
            slot = at.slot;
        }
    }

    // V6.5.0: bo cuc DOC danh cho hat live. Cot dieu khien giu gon; hang
    // 7 num mo SANG BEN PHAI, khong day giao dien dai xuong nhu bo cuc ngang.
    bool isVerticalLayout() const noexcept { return verticalLayout; }

    /** V0.6.7.9b: 0 = mau A (Danh sach len thanh tren), 1 = mau B (hang Luu bai | Danh sach rieng). */
    void setVerticalStyle (int style) { verticalStyle = juce::jlimit (0, 1, style); updateChildVisibility(); resized(); repaint(); }
    int  getVerticalStyle() const noexcept { return verticalStyle; }

    void setVerticalLayout (bool on, bool notify = true)
    {
        if (verticalLayout == on)
            return;

        verticalLayout = on;
        knobFoldButton.setHorizontal (verticalLayout);   // doc: num xo sang PHAI (mui ten trai/phai)
        laughBoard.setVerticalLayout (false);   // V0.6.7.9d: doc van dung bang LUOI NGANG, chi dat canh ben
        updateChildVisibility();
        resized();
        repaint();

        if (notify && onHeightChanged)
            onHeightChanged();

        if (notify && onPanelStateChanged)
            onPanelStateChanged();
    }

    int getWantedWidth() const noexcept
    {
        if (! verticalLayout)
            return 640;

        return vColW;   // V0.6.7.9c: doc = 1 cot hep, 6 num gan co dinh ben duoi
    }

    void setKnobsExpanded (bool on, bool notify = true)
    {
        if (knobsExpanded == on)
            return;

        knobsExpanded = on;
        knobFoldButton.setExpanded (knobsExpanded);
        statusFold.setExpanded (knobsExpanded);
        updateChildVisibility();
        resized();
        repaint();

        if (notify && onHeightChanged)
            onHeightChanged();

        if (notify && onPanelStateChanged)
            onPanelStateChanged();
    }

    void setCompactMetersVisible (bool on)
    {
        compactMetersVisible = on;
        saveCompactMetersPreference();
        updateChildVisibility();
        resized();
        repaint();

        if (onHeightChanged)
            onHeightChanged();
    }
    void repositionLaughPanel (juce::Rectangle<int> anchorScreen)
    {
        if (laughWindow != nullptr)
        {
            laughAnchorScreen = anchorScreen;
            positionLaughPopup (anchorScreen);
        }
    }

    void setToneOffsetSilently (float tong)
    {
        toneOffsetTong = juce::jlimit (-6.0f, 6.0f, std::round (tong * 2.0f) / 2.0f);
        updateToneLabel();
    }

    explicit TonePanel (Mixer& m) : mixer (m)
    {
        /*  MOC 79: nut kinh mo co do day - xem GlassLookAndFeel trong Theme.h.

            setLookAndFeel() tu lan xuong HET cac con, nen mot dong nay doi
            toan bo nut trong bang dieu khien. Cac bang khac (Inspector, ban
            tron) khong bi anh huong vi chung khong phai con cua bang nay.  */
        setLookAndFeel (&glassLook);

        /*  V4.6: hai cot song am LUON nam tren Bang dieu khien. Bang F2 la
            cua so rieng, nen khi anh dong F2 hai cot nay van con de nhin
            ngay NHAC/MIC co dang chay hay khong. Chi doc meterLevel da co
            san, khong chen them xu ly vao audio thread. */
        nhacMeter.getLevelSource = [this]
        {
            if (auto* t = nhacTrack())
                return t->getMeterLevel();
            return 0.0f;
        };
        micMeter.getLevelSource = [this]
        {
            if (auto* t = micTrack())
                return t->getMeterLevel();
            return 0.0f;
        };
        addAndMakeVisible (nhacMeter);
        addAndMakeVisible (micMeter);

        /*  V6.0: 7 meter canh 7 num. Tone va Flex tune lay song tu MIC (anh
            chot). Vang dai / Vang ngan / Delay doc muc cua chinh bus FX. Chi
            doc meterLevel co san - khong them viec gi vao audio thread.  */
        auto roleLevel = [this] (Track::Role role)
        {
            return [this, role]
            {
                if (auto* t = mixer.getTrackByRole (role))
                    return t->getMeterLevel();
                return 0.0f;
            };
        };

        // 16/10: stereo = cung khung mono nhung nhay 2 duong (Nhac / Vang dai / Vang ngan / Delay); Mic, Tune, Flex = mono
        auto roleStereo = [this] (Track::Role role)
        {
            return [this, role] (float& l, float& r)
            {
                l = r = 0.0f;
                if (auto* t = mixer.getTrackByRole (role)) { l = t->getMeterLevelL(); r = t->getMeterLevelR(); }
            };
        };
        musicKnobMeter.getStereoSource   = roleStereo (Track::Role::Music);
        reverbLongMeter.getStereoSource  = roleStereo (Track::Role::ReverbLong);
        reverbShortMeter.getStereoSource = roleStereo (Track::Role::ReverbShort);
        delayMeter.getStereoSource       = roleStereo (Track::Role::Delay);
        for (auto* m : { &musicKnobMeter, &reverbLongMeter, &reverbShortMeter, &delayMeter })
            m->setNumLines (2);

        musicKnobMeter.getLevelSource   = roleLevel (Track::Role::Music);
        micKnobMeter.getLevelSource     = roleLevel (Track::Role::Mic);
        reverbLongMeter.getLevelSource  = roleLevel (Track::Role::ReverbLong);
        reverbShortMeter.getLevelSource = roleLevel (Track::Role::ReverbShort);
        delayMeter.getLevelSource       = roleLevel (Track::Role::Delay);
        tuneMeter.getLevelSource        = roleLevel (Track::Role::Mic);
        flexMeter.getLevelSource        = roleLevel (Track::Role::Mic);

        for (auto* m : knobMeters())
            addAndMakeVisible (m);

        //  V0.6.7.9e: song tren nut. Nhac/Mic/Vang doc muc track that; cac nut
        //  hieu ung mic (Tune, Lofi, Remix, Em be, Be) chi nhay khi DANG BAT.
        {
            auto micWhen = [this] (std::function<bool()> isOn)
            {
                return [this, isOn]
                {
                    if (! isOn()) return 0.0f;
                    if (auto* t = micTrack()) return t->getMeterLevel();
                    return 0.0f;
                };
            };
            auto micInsertOn = [this] (int slot)
            {
                return [this, slot]
                {
                    auto* mic = micTrack();
                    if (mic == nullptr) return false;
                    auto& chain = mic->getInserts();
                    return ! chain.isSlotEmpty (slot) && ! chain.isMissing (slot) && ! chain.isBypassed (slot);
                };
            };

            nhacChipMeter.getLevelSource = boundLevel ("nhac", roleLevel (Track::Role::Music));
            nhacChipMeter.getStereoSource = [this, base = nhacChipMeter.getLevelSource] (float& l, float& r)
            {
                if (buttonMap.get ("nhac").isDefault())
                    if (auto* t = nhacTrack()) { l = t->getMeterLevelL(); r = t->getMeterLevelR(); return; }
                l = r = base ? base() : 0.0f;
            };
            nhacChipMeter.setNumLines (2);
            micChipMeter.getLevelSource  = boundLevel ("mic",  roleLevel (Track::Role::Mic));
            vangChipMeter.getLevelSource = boundLevel ("vang", [this]
            {
                float v = 0.0f;
                for (auto role : { Track::Role::ReverbLong, Track::Role::ReverbShort, Track::Role::Delay })
                    if (auto* t = mixer.getTrackByRole (role))
                        v = juce::jmax (v, t->getMeterLevel());
                return v;
            });
            // 12o: chip Vang cung stereo - lay max L / max R cua Vang dai, Vang ngan, Delay
            vangChipMeter.getStereoSource = [this, base = vangChipMeter.getLevelSource] (float& l, float& r)
            {
                if (buttonMap.get ("vang").isDefault())
                {
                    l = r = 0.0f;
                    for (auto role : { Track::Role::ReverbLong, Track::Role::ReverbShort, Track::Role::Delay })
                        if (auto* t = mixer.getTrackByRole (role))
                        {
                            l = juce::jmax (l, t->getMeterLevelL());
                            r = juce::jmax (r, t->getMeterLevelR());
                        }
                    return;
                }
                l = r = base ? base() : 0.0f;
            };
            vangChipMeter.setNumLines (2);
            tuneChipMeter.getLevelSource    = boundLevel ("tune",    micWhen ([this] { return autoTuneInsertOn(); }));
            lofiChipMeter.getLevelSource    = boundLevel ("lofi",    micWhen (micInsertOn (slotLofi())));
            remix1ChipMeter.getLevelSource  = boundLevel ("remix1",  micWhen (micInsertOn (slotRemix1())));
            remix2ChipMeter.getLevelSource  = boundLevel ("remix2",  micWhen (micInsertOn (slotRemix2())));
            babyChipMeter.getLevelSource    = boundLevel ("baby",    micWhen (micInsertOn (slotBaby())));
            harmonyChipMeter.getLevelSource = boundLevel ("harmony", micWhen ([this] { return isHarmonyTriggerAllOn(); }));

            for (auto* m : chipMeters())
                addAndMakeVisible (m);
            for (auto* b : chipMeterButtons())
                b->getProperties().set ("meterBelow", true);
        }

        knobMeterTimer.startTimerHz (30);

        nowPlaying.getLevelSource = [this]
        {
            if (auto* t = nhacTrack()) return t->getMeterLevel();
            return 0.0f;
        };
        addAndMakeVisible (nowPlaying);

        // V6.3.5: dong ho nam canh caption DANG PHAT, khong con chiem be ngang
        // cua ten bai. Ten dai se co nhieu cho hon de chay chu.
        nowPlayingClockLabel.setFont (juce::Font (juce::FontOptions (11.5f).withStyle ("Medium")));
        nowPlayingClockLabel.setJustificationType (juce::Justification::centredRight);
        nowPlayingClockLabel.setColour (juce::Label::textColourId, Col::text);
        nowPlayingClockLabel.setText ("00:00 / --:--", juce::dontSendNotification);
        addAndMakeVisible (nowPlayingClockLabel);

        compactMetersVisible = loadCompactMetersPreference();

        header.setOpen (true, false);
        /*  ==========  MOC 89: BANG DIEU KHIEN GAN CUNG  ==========

            Anh chot bo han viec thu gon. Bang tieng cuoi truoc day song nho
            cho trong luc thu gon, gio da ra cua so rieng (LaughBoard.h) nen
            khong con ly do gi giu cai thu gon nay.

            Giu lai onToggleOpen ben duoi cho chac, phong khi sau nay bat lai.  */
        header.setCollapsible (false);

        header.onToggleOpen = [this]
        {
            updateChildVisibility();

            /*  ==========  MOC 84: PHAI TU XEP LAI CHO NGAY TAI DAY  =======

                Truoc day cho nay chi bao ra ngoai (onHeightChanged) roi tin
                rang MainComponent se doi kich thuoc bang, va viec doi kich
                thuoc do se keo theo TonePanel::resized().

                Tin nham. JUCE chi goi resized() khi kich thuoc THAT SU DOI.
                O trang thai "chi con bang dieu khien" va anh da tung keo mep
                bang bang tay, MainComponent dat lai DUNG kich thuoc cu -
                khong doi mot px nao - nen resized() KHONG chay. Ma dai nut
                tieng cuoi chi duoc cho hien trong resized().

                Ket qua: thu gon bang lai thi moi thu bien mat dung nhu mong
                doi, nhung dai nut tieng cuoi cung khong hien ra.

                Goi thang resized() o day thi khong con phu thuoc vao viec
                cha co doi kich thuoc hay khong. Mot lop tu doi trang thai
                ben trong minh thi phai tu xep lai cho cua minh.  */
            resized();

            if (onHeightChanged)
                onHeightChanged();
        };
        header.setVisible (false);   // V5.7: bo chu "BẢNG ĐIỀU KHIỂN" de tiet kiem chieu cao

        /*  ==========  MOC 75: DOI THANH BANG DIEU KHIEN, NAM NGANG  =======

            Anh chot: bang nay la GIAO DIEN CHINH cua LiveNT - nam ngang tren
            cung, chiem het be ngang cua so. Danh sach track / Insert-Send /
            ban tron tu nay la thu PHU, an hien duoc.

            Hai nut dock trai/phai cua Moc 74 khong con y nghia (khong con
            dock canh man hinh nua) nen da bo.  */

        /*  ==========  MOC 74: HAI NUT THU AM VAO TRONG BANG DIEU KHIEN  ====

            Truoc day hai nut nay nam tren hang menu o dinh cua so, va chi
            hien khi cua so con rong hon 420 px -- keo cua so nho lai mot
            chut la chung bien mat khong bao truoc. Dung nhu anh khong thay.

            Nam trong bang Do Tone thi luon nhin thay duoc, va nam ngay canh
            thu anh dang nhin trong luc hat.  */
        /*  ==========  MOC 89: MOT NUT DUY NHAT CHO THU / DUNG  ==========

            Bam mot lan la thu, bam lan nua la dung. Truoc day la hai nut roi
            nhau: dang hat ma phai nho "nut nao dang bam duoc" la mot nhip
            thua, va ton mat 250 px tren hang tieu de.

            Chu tren nut noi ro dang lam gi: "● THU AM" luc ranh, "■ DUNG
            01:23" luc dang ghi - nhin la biet, khong phai doan.  */
        recButton.setButtonText ({});
        recButton.getProperties().set ("recDot", true);
        recButton.setTooltip (livent::vn ("Bấm để ghi toàn bộ tiếng ra loa; bấm lần nữa để dừng"));
        recButton.setTitle (livent::vn ("Thu âm"));
        recButton.getProperties().set ("solidButton", true);   // MOC 79
        recButton.onClick = [this]
        {
            /*  Hoi thang Mixer chu khong giu mot bien "dang thu" rieng o day.
                Giu bien rieng la co HAI noi cung noi ve mot trang thai, va
                chung se lech nhau vao dung luc khong ai ngo.  */
            if (mixer.isMasterRecording())
            {
                if (onStopRecord)  onStopRecord();
            }
            else
            {
                if (onStartRecord) onStartRecord();
            }
        };
        // V6.4.0: nut Thu Am da duoc dua len thanh tren cua DAW.
        // Giu recButton song de logic/trang thai cu khong bi vo, nhung khong ve nua.
        addChildComponent (recButton);
        recButton.setVisible (false);

        /*  MOC 91: DE HAN CHU, BO BIEU TUONG MAT CUOI.

            Ban Moc 89 ve mot mat cuoi bang Path. Anh xem thay xau - va dung:
            ve mot khuon mat trong 32x32 px bang duong cong tay thi khong bao
            gio dep bang mot chu ro rang. Chu con doc duoc tu xa, mat khong.  */
        // V5.8.7: bỏ nút TIẾNG CƯỜI lớn khỏi hàng điều khiển.
        // Bảng tiếng cười được mở bằng nút CƯỜI trên thanh menu cạnh DS bài.

        // V5.8: TAC HAI KHAI NIEM ma V5.7 vo tinh gop vao nhau.
        //   [-] [C Major] [+] [M/m] = CHI doi Key/Scale, KHONG pitch-shift beat.
        //   BEAT [-] [0.0] [+]      = CHI doi pitch cua track NHẠC (va key thuc
        //                              te gui sang Auto-Tune se bu theo beat).
        keyMinusButton.setButtonText ("-");
        keyPlusButton .setButtonText ("+");
        keyMinusButton.setTooltip (livent::vn ("Hạ Key 1 nửa cung - không đổi pitch track NHẠC"));
        keyPlusButton .setTooltip (livent::vn ("Nâng Key 1 nửa cung - không đổi pitch track NHẠC"));
        keyMinusButton.onClick = [this] { nudgeKey (-1); };
        keyPlusButton .onClick = [this] { nudgeKey ( 1); };
        addAndMakeVisible (keyMinusButton);
        addAndMakeVisible (keyPlusButton);

        keyDisplayButton.setButtonText ("C Major");
        keyDisplayButton.setTooltip (livent::vn ("Bấm để chọn Key/Scale trực tiếp"));
        // 02/10: chuot phai = chon kieu do (AI / tay). Chuot trai = chon tone nhu cu.
        keyDisplayButton.onClick = [this]
        {
            if (juce::Time::getMillisecondCounter() - keyRightClickMs < 1500)
                return;   // vua bam chuot phai -> khong mo menu tone
            showKeyMenu();
        };
        keyDisplayButton.addMouseListener (this, false);
        keyDisplayButton.addAndMakeVisible (keyModeTag);
        keyRollTimer.tick = [this] { tickKeyRoll(); };
        manualDetectMode = loadManualDetectPref();
        updateKeyModeTag();   // 12s: AI / AK
        addAndMakeVisible (keyDisplayButton);

        scaleToggleButton.setButtonText ("M/m");
        scaleToggleButton.setTooltip (livent::vn ("Đổi Major / Minor, giữ nguyên Key"));
        scaleToggleButton.onClick = [this] { toggleScaleManual(); };
        addAndMakeVisible (scaleToggleButton);

        // Hai object van giu de tuong thich code cu, nhung V5.8 dua nut that len
        // thanh window. Khong con chiem cho trong hai hang live.
        saveSongButton.setButtonText (livent::vn ("LƯU BÀI"));
        saveSongButton.setTooltip (livent::vn ("Lưu tên bài, link, Key/Scale, nâng hạ tông và timeline"));
        saveSongButton.onClick = [this] { saveCurrentSongManual(); };
        saveSongButton.addMouseListener (this, false);
        songAutoSaveEnabled = loadSongAutoSavePreference();
        addAndMakeVisible (customButtons);
        customButtons.getLiveState = [this] (const juce::String& action)
        {
            if (auto* b = liveButtonForAction (action)) return std::make_pair (b->isEnabled(), b->getToggleState());
            if (action == "record") return std::make_pair (true, recButton.getToggleState());
            return std::make_pair (true, getCustomUtilityState ? getCustomUtilityState (action) : false);
        };
        customButtons.onLiveAction = [this] (const juce::String& action)
        {
            if (auto* b = liveButtonForAction (action)) { if (b->isEnabled() && b->onClick) b->onClick(); }
            else if (action == "record")
            { if (recButton.getToggleState()) { if (onStopRecord) onStopRecord(); } else if (onStartRecord) onStartRecord(); }
            else if (action == "settings") { if (onOpenSettings) onOpenSettings(); }
            else if (onCustomUtility) onCustomUtility (action);
        };
        customButtons.onOpenEditor = [this] (Track* t, int slot) { if (onOpenPluginSlot) onOpenPluginSlot (t, slot); };
        customButtons.onChanged = [this] { resized(); if (onHeightChanged) onHeightChanged(); announceChange(); };
        addAndMakeVisible (saveSongButton);

        songListButton.setButtonText (livent::vn ("DANH SÁCH"));
        songListButton.onClick = [this] { showSongLibrary(); };
        addAndMakeVisible (songListButton);

        // V0.6.7.9c: nguon VST so 1 track NHAC (canh Tone nhac, bo cuc doc)
        toneVstPowerButton.getProperties().set ("liveChipStyle", true);
        toneVstPowerButton.setWantsKeyboardFocus (false);
        toneVstPowerButton.onClick = [this] { if (! pressBound ("beat")) toggleMusicInsert (0); };
        addChildComponent (toneVstPowerButton);

        // 02/10: nut PRESET (Bolero / Nhac tre...) dau hang ten bai.
        presetButton.getProperties().set ("liveChipStyle", true);
        presetButton.getProperties().set ("preferFullText", true);   // nut nho: thu chu, khong cat ten
        presetButton.setWantsKeyboardFocus (false);
        presetButton.setTooltip (livent::vn ("Preset thể loại: bấm để chọn / lưu.  Phím tắt Ctrl+1 … Ctrl+4"));
        presetButton.onClick = [this] { showPresetMenu(); };
        // 07/10: bang ngang - dai 4 che do ghi san ten (mau P1)
        presetStrip.onApply = [this] (int i) { applyPreset (i); };
        presetStrip.onMenu  = [this] (int i) { showPresetChipMenu (i); };
        addAndMakeVisible (presetStrip);
        addAndMakeVisible (presetButton);
        updatePresetButton();

        // 30/09 (khach VBK): nut chu "Beat" thay bieu tuong nguon.
        setupLiveButton (beatButton, "Beat");
        beatButton.onClick = [this] { if (! pressBound ("beat")) toggleMusicInsert (0); };
        beatButton.setVisible (beatAsText());

        laughBoard.onContentSizeChanged = [this]
        {
            // V6.0.1: bảng tiếng cười là cửa sổ phụ nằm ngoài mép trên/dưới
            // của LiveNT, không che DAW. Khi thêm/xóa tiếng chỉ cần tính lại
            // chiều cao theo đúng bề ngang cửa sổ LiveNT hiện tại.
            if (laughWindow != nullptr)
                positionLaughPopup (laughAnchorScreen);
        };

        //-- Hang link -------------------------------------------------------
        urlBox.setTextToShowWhenEmpty (livent::vn ("Dán link YouTube vào đây..."), Col::textDim);
        urlBox.setColour (juce::TextEditor::backgroundColourId, Col::bg);
        urlBox.onReturnKey = [this] { startDetect(); };
        addAndMakeVisible (urlBox);

        /*  Hang dan link tay THU GON SAN. Binh thuong khong ai dung toi --
            tu bat link chay san roi. Chi khi no khong an moi xo ra dan tay. */
        linkToggle.setButtonText (livent::vn ("Dán link tay  v"));
        linkToggle.setClickingTogglesState (true);
        linkToggle.onClick = [this]
        {
            const bool open = linkToggle.getToggleState();
            linkToggle.setButtonText (open ? livent::vn ("Dán link tay  ^") : livent::vn ("Dán link tay  v"));
            updateChildVisibility();

            if (onHeightChanged)
                onHeightChanged();
        };
        addAndMakeVisible (linkToggle);

        pasteButton.setButtonText (livent::vn ("Dán"));
        pasteButton.onClick = [this]
        {
            urlBox.setText (juce::SystemClipboard::getTextFromClipboard().trim());
        };
        addAndMakeVisible (pasteButton);

        detectButton.setButtonText (livent::vn ("ĐO TONE"));
        detectButton.setColour (juce::TextButton::buttonColourId, Col::accent.darker (0.3f));
        detectButton.getProperties().set ("solidButton", true);    // MOC 79
        detectButton.onClick = [this] { startDetect(); };
        addAndMakeVisible (detectButton);

        //-- Hang chon track -------------------------------------------------
        targetCaption.setFont (juce::Font (juce::FontOptions (11.0f)));
        targetCaption.setColour (juce::Label::textColourId, Col::textDim);
        addAndMakeVisible (targetCaption);
        addAndMakeVisible (targetBox);

        autoTuneButton.setButtonText (livent::vn ("AUTO TUNE"));
        autoTuneButton.setTooltip (livent::vn ("Mở giao diện VST số 1 trên track MÍC"));
        // V5.8: AUTO TUNE la nut truy cap quan trong luc live -> xanh la co dinh,
        // khong de kinh/den nhu V5.7. No khong mang trang thai on/off.
        autoTuneButton.setColour (juce::TextButton::buttonColourId, Col::green.darker (0.38f));
        autoTuneButton.getProperties().set ("solidButton", true);
        autoTuneButton.onClick = [this]
        {
            if (onOpenAutoTune)
                onOpenAutoTune();
        };
        addAndMakeVisible (autoTuneButton);

        /*  V5.2: nut BÈ dieu khien Trigger All cua Harmony Player, KHONG tat
            ca Harmony engine. Cach nay hop live hon: khong rebuild engine nen
            tranh giat/hut am thanh nhu bam nut Harmony Player ON/OFF.

            Nut mac dinh AN; menu Hien thi cho phep bat khi may co Auto-Tune 11. */
        setupLiveButton (harmonyButton, liveButtonName ("harmony"));
        harmonyButton.setTooltip (livent::vn (
            "Bật/tắt bè (Trigger All) trong Auto-Tune - plugin vẫn chạy, không bypass.\n"
            "Mặc định theo Auto-Tune của nút Tune; gán riêng ở Gán nút > Bè > Bật/tắt BÈ trong VST.\n"
            "Lần đầu nếu Auto-Tune không công khai tên Trigger All, LiveNT sẽ tự học núm:\n"
            "để Trigger All TẮT -> bấm BÈ -> bật Trigger All trong Auto-Tune -> bấm BÈ lần nữa."));
        harmonyButton.onClick = [this] { if (! pressBound ("harmony")) toggleHarmonyTriggerAll(); };
        harmonyButton.setVisible (false);

        /*  V4.5: hai cach xu ly tong khi BrowserWatcher thay BAI MOI.
            - GIỮ: de nguyen gia tri +/- hien tai.
            - VỀ 0: tu dua tong ve 0 truoc khi do tone bai moi.
            Lua chon duoc luu rieng trong %APPDATA%\LiveNT, khong gan vao
            tung project. */
        resetToneOnNewSong = loadResetTonePreference();
        {
            const auto f = PluginChain::getSettingsFolder().getChildFile ("auto-vang-music.txt");
            autoVangByMusic = f.existsAsFile() && f.loadFileAsString().trim() == "1";   // 15/10: mac dinh tat
        }
        toneModeButton.onClick = [this]
        {
            resetToneOnNewSong = ! resetToneOnNewSong;
            saveResetTonePreference();
            updateToneModeButton();
        };
        toneModeButton.setTooltip (livent::vn (
            "Bài mới: GIỮ = giữ nguyên nút +/-; VỀ 0 = tự trả pitch về 0 trước khi đo bài mới."));
        updateToneModeButton();
        addAndMakeVisible (toneModeButton);

        //-- Tu bat link tu trinh duyet --------------------------------------
        /*  MAC DINH BAT SAN. Mo LiveNT len la no rinh luon, anh khong phai
            bam gi ca -- dung nhu anh muon.  */
        //-- MOC 37: o doi tong nhac ----------------------------------------
        toneCaption.setText (livent::vn ("BEAT"), juce::dontSendNotification);
        toneCaption.setVisible (true);
        toneCaption.setFont (juce::Font (juce::FontOptions (11.5f).withStyle ("Bold")));
        toneCaption.setColour (juce::Label::textColourId, Col::amber);
        addAndMakeVisible (toneCaption);

        toneMinusButton.setButtonText ("-");
        tonePlusButton .setButtonText ("+");

        /* V6.5.3: hai nut +/- Tone nhac khong dung mau nau/amber co dinh nua.
           Mau co dinh hop theme toi nhung bi choi tren theme sang. Cho hai nut
           dung mau OFF + chu cua CHINH theme, con gia tri tone van la diem nhan. */
        for (auto* b : { &toneMinusButton, &tonePlusButton })
        {
            b->setColour (juce::TextButton::buttonColourId, Col::offButton);
            b->setColour (juce::TextButton::textColourOffId, Col::text);
            b->getProperties().set ("solidButton", true);
            addAndMakeVisible (*b);
        }

        toneMinusButton.onClick = [this] { nudgeTone (-0.5f); };
        tonePlusButton .onClick = [this] { nudgeTone ( 0.5f); };

        toneMinusButton.setTooltip (livent::vn ("Hạ tông nhạc nửa nấc (0.5 tông = 1 nửa cung)"));
        tonePlusButton .setTooltip (livent::vn ("Nâng tông nhạc nửa nấc (0.5 tông = 1 nửa cung)"));
        toneValueLabel .setTooltip (livent::vn ("Tông lệch so với bản gốc.\n"
                                    "Bấm đúp = về 0.\n"
                                    "Chuột phải = xem num của plugin trên track NHAC.\n"
                                    "Đổi cả num Semitones trên track NHAC lẫn Key "
                                    "bắn sang plugin chính cao độ."));

        toneValueLabel.setFont (juce::Font (juce::FontOptions (13.0f)));
        toneValueLabel.setJustificationType (juce::Justification::centred);
        toneValueLabel.setOpaque (false);
        toneValueLabel.setColour (juce::Label::backgroundColourId, juce::Colours::transparentBlack);
        toneValueLabel.setColour (juce::Label::backgroundWhenEditingColourId, Col::bg);
        toneValueLabel.setColour (juce::Label::outlineWhenEditingColourId, Col::line);
        toneValueLabel.setColour (juce::Label::textWhenEditingColourId, Col::text);
        addAndMakeVisible (toneValueLabel);

        /*  Bam dup vao o so = ve 0. Dang dien ma lo bam lech vai nhip thi
            can mot duong ve nhanh, khong the ngoi bam nguoc tung nac.  */
        toneValueLabel.addMouseListener (this, false);

        updateToneLabel();

        //-- MOC 35: bay nut dien -------------------------------------------
        setupLiveButton (vangButton,   livent::vn ("Vang"));
        setupLiveButton (tuneButton,   "Tune");
        setupLiveButton (nhacButton,   livent::vn ("Nhạc"));
        setupLiveButton (micButton,    livent::vn ("Míc"));
        // V6.5.3: LOFI dung CUNG kieu chip/LED voi Be/Remix/Em be.
        // Theme.h tu co font va an LED neu qua hep, khong can bien LOFI thanh
        // mot nut dac biet nua.
        setupLiveButton (lofiButton,   liveButtonName ("lofi"));
        // V6.4.9: LOFI khong con dung forceFullText rieng. Property do lam
        // nut tat sang chu hon cac nut LED ben canh. `preferFullText` chung o
        // setupLiveButton da tu co font/an LED khi hep, nen van hien du "Lofi".
        setupLiveButton (remix1Button, liveButtonName ("remix1"));
        setupLiveButton (remix2Button, liveButtonName ("remix2"));
        setupLiveButton (babyButton,   liveButtonName ("baby"));

        // 14/10: chuot phai Lofi / Remix 1 / Remix 2 / Em be / Be = DOI TEN nut.
        for (auto* id : { "lofi", "remix1", "remix2", "baby", "harmony" })
            if (auto* b = renamableButton (id))
            {
                const juce::String sid (id);
                b->onPopup = [this, sid] { askRenameLiveButton (sid); };
            }

        // 01/10: nut nao da GAN (Cai dat > Gan nut) thi lam theo gan, chua gan = nhu cu.
        vangButton  .onClick = [this] { if (! pressBound ("vang")) toggleMicSends(); };
        nhacButton  .onClick = [this] { if (! pressBound ("nhac")) toggleMonitor (nhacTrack(), nhacButton); };
        micButton   .onClick = [this] { if (! pressBound ("mic"))  toggleMonitor (micTrack(),  micButton); };
        tuneButton  .onClick = [this] { if (! pressBound ("tune")) toggleAutoTuneInsert(); };
        tuneButton.onPopup = [this] { if (onOpenAutoTune) onOpenAutoTune(); };
        // 06/10: chuot phai Nhac / Vang / Mic = bang thanh truot giua man hinh
        nhacButton.onPopup = [this] { openQuickVolume(); };
        vangButton.onPopup = [this] { openQuickVang(); };
        micButton .onPopup = [this] { openQuickVoice(); };
        for (auto* b : { &nhacButton, &vangButton, &micButton })
            b->getProperties().set ("quickPanel", true);
        tuneButton.setTooltip (livent::vn ("Chuột trái: bật/tắt Tune. Chuột phải: mở VST Tune đã gán."));
        /*  Người dùng đếm ô insert từ 1:
            LOFI = ô 12, REMIX1 = ô 13, REMIX2 = ô 14, EM BÉ = ô 15. */
        //  30/09: so o lay tu AppBranding.h (fxSlot...), mac dinh 12/13/14/15.
        lofiButton  .onClick = [this] { if (! pressBound ("lofi"))   toggleMicInsert (slotLofi()); };
        remix1Button.onClick = [this] { if (! pressBound ("remix1")) toggleMicInsert (slotRemix1()); };
        remix2Button.onClick = [this] { if (! pressBound ("remix2")) toggleMicInsert (slotRemix2()); };
        babyButton  .onClick = [this] { if (! pressBound ("baby"))   toggleMicInsert (slotBaby()); };
        {
            auto tip = [] (int n) { return livent::vn ("Bật/tắt VST số ") + juce::String (n) + livent::vn (" trên track MÍC"); };
            lofiButton  .setTooltip (tip (livent::branding::fxSlotLofi));
            remix1Button.setTooltip (tip (livent::branding::fxSlotRemix1));
            remix2Button.setTooltip (tip (livent::branding::fxSlotRemix2));
            babyButton  .setTooltip (tip (livent::branding::fxSlotBaby));
        }

        /*  ==========  V5.8.4: HANG 3 - NUM VAN LIVE  =====================

            Anh muon khong phai mo VST/mixer khi dang cam mic. Sau hang nut
            bat/tat them 7 num dieu khien truc tiep:

              TUNE       -> Retune Speed của Auto-Tune ở ô 1 track MÍC
              FLEX TUNE  -> Flex Tune 0..100 của Auto-Tune ô 1
              VOL NHẠC   -> Volume track NHẠC
              VOL MÍC    -> Volume track MÍC
              VANG DÀI   -> level send MÍC -> bus VANG DÀI
              VANG NGẮN  -> level send MÍC -> bus VANG NGẮN
              DELAY      -> level send MÍC -> bus DELAY

            Tất cả chỉ ghi vào parameter/fader/send đã có, không tạo thêm DSP. */
        setupRemoteKnob (tuneSpeedKnob, tuneSpeedCaption, livent::vn ("Tốc độ tune"), Col::accent);
        setupRemoteKnob (flexTuneKnob, flexTuneCaption, "Flex tune", Col::accent);
        setupRemoteKnob (musicVolumeKnob, musicVolumeCaption, livent::vn ("Nhạc"), Col::accent);
        setupRemoteKnob (micVolumeKnob, micVolumeCaption, livent::vn ("Míc"), Col::accent);
        setupRemoteKnob (reverbLongKnob, reverbLongCaption, livent::vn ("Vang dài"), Col::accent);
        setupRemoteKnob (reverbShortKnob, reverbShortCaption, livent::vn ("Vang ngắn"), Col::accent);
        setupRemoteKnob (delayKnob, delayCaption, "Delay", Col::accent);

        // Retune Speed la parameter normalised 0..1. Chu duoi num lay THANG
        // tu getText() cua plugin, nen plugin hien 50/20 ms/Slow... thi LiveNT
        // hien dung y chang, khong tu doan thang do cua Antares.
        tuneSpeedKnob.setRange (0.0, 1.0, 0.0005);
        // Wheel Windows thuong ~0.1 moi nac -> ~0.01 normalized/nac.
        // Shift + wheel -> ~0.0025, de tinh chinh luc dang hat.
        tuneSpeedKnob.setFineWheelStep (0.10);
        tuneSpeedKnob.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 58, 16);   // 14/10: bam vao o so = go so
        tuneSpeedKnob.valueFromTextFunction = [this] (const juce::String& text)
        {
            // Go dung chu plugin hien (vd "20", "20 ms") -> nho plugin doi ra gia tri 0..1.
            if (auto* p = findRetuneSpeedParameter())
            {
                const float v = p->getValueForText (text.trim());
                if (std::isfinite (v))
                    return (double) juce::jlimit (0.0f, 1.0f, v);
            }
            return juce::jlimit (0.0, 1.0, text.retainCharacters ("0123456789.,").replaceCharacter (',', '.').getDoubleValue() / 100.0);
        };
        tuneSpeedKnob.textFromValueFunction = [this] (double normalised)
        {
            if (auto* p = findRetuneSpeedParameter())
            {
                const auto text = p->getText ((float) normalised, 24).trim();
                if (text.isNotEmpty())
                    return text;
            }

            return juce::String ((int) std::lround (normalised * 100.0));
        };
        tuneSpeedKnob.onValueChange = [this]
        {
            if (updatingRemoteKnobs)
                return;

            if (auto* p = findRetuneSpeedParameter())
            {
                setHostParameter (p, (float) tuneSpeedKnob.getValue());
                // Dang keo thi CHI sua parameter. Rebuild Inspector moi lan
                // mouse move se rat ton CPU; chi bao GUI khi thao tac ket thuc.
                if (! (tuneSpeedKnob.isMouseButtonDown() || quickDragging) && onPluginChanged)
                    onPluginChanged();
            }
        };
        tuneSpeedKnob.onDragEnd = [this]
        {
            if (onPluginChanged) onPluginChanged();
        };

        // FLEX TUNE: người dùng nhìn/thao tác theo thang 0..100.
        // Parameter host vẫn là normalized 0..1 nên chỉ map ở biên UI.
        flexTuneKnob.setRange (0.0, 100.0, 1.0);
        flexTuneKnob.setFineWheelStep (2.0);   // ~0.2 điểm/nấc, Shift ~0.05
        flexTuneKnob.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 58, 16);
        flexTuneKnob.setDoubleClickReturnValue (true, 0.0);
        flexTuneKnob.onValueChange = [this]
        {
            if (updatingRemoteKnobs)
                return;

            if (auto* p = findFlexTuneParameter())
            {
                setHostParameter (p, (float) (flexTuneKnob.getValue() / 100.0));
                if (! (flexTuneKnob.isMouseButtonDown() || quickDragging) && onPluginChanged)
                    onPluginChanged();
            }
        };
        flexTuneKnob.onDragEnd = [this]
        {
            if (onPluginChanged) onPluginChanged();
        };

        auto setupDbKnob = [] (LiveFineKnob& s, double resetValue)
        {
            s.setRange (-60.0, 6.0, 0.1);
            s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 62, 16);
            s.setTextValueSuffix (" dB");
            s.textFromValueFunction = [] (double v)
            {
                return v <= -59.9 ? juce::String ("-inf") : juce::String (v, 1);
            };
            s.valueFromTextFunction = [] (const juce::String& text)
            {
                return text.trim().equalsIgnoreCase ("-inf") ? -60.0
                                                              : text.getDoubleValue();
            };
            s.setDoubleClickReturnValue (true, resetValue);
            // V5.8.7: nhẹ tay hơn nữa: ~0.08 dB/nấc Windows.
            // Giữ Shift còn khoảng ~0.02 dB/nấc để canh live rất mịn.
            s.setFineWheelStep (0.8);
        };

        setupDbKnob (musicVolumeKnob, 0.0);
        setupDbKnob (micVolumeKnob,   0.0);
        setupDbKnob (reverbLongKnob, -6.0);
        setupDbKnob (reverbShortKnob,-6.0);
        setupDbKnob (delayKnob,      -6.0);

        // 11h: chuot phai len num -> nhap so bang tay (dB / 0..100).
        auto addValueEntry = [] (LiveFineKnob& knob, const juce::String& title, const juce::String& unit)
        {
            juce::Component::SafePointer<LiveFineKnob> safeKnob (&knob);
            knob.onAskValue = [safeKnob, title, unit]
            {
                if (safeKnob == nullptr) return;
                livent::askNumber (title, safeKnob->getValue(), safeKnob->getMinimum(), safeKnob->getMaximum(), unit,
                    [safeKnob] (double v)
                    {
                        if (safeKnob == nullptr) return;
                        safeKnob->setValue (v, juce::sendNotificationSync);
                        if (safeKnob->onDragEnd) safeKnob->onDragEnd();
                    });
            };
        };
        addValueEntry (musicVolumeKnob, livent::vn ("Nhạc"),      "dB");
        addValueEntry (micVolumeKnob,   livent::vn ("Míc"),       "dB");
        addValueEntry (reverbLongKnob,  livent::vn ("Vang dài"),  "dB");
        addValueEntry (reverbShortKnob, livent::vn ("Vang ngắn"), "dB");
        addValueEntry (delayKnob,       livent::vn ("Delay"),     "dB");
        addValueEntry (flexTuneKnob,    livent::vn ("Flex tune"), "");

        micVolumeKnob.onValueChange = [this]
        {
            if (updatingRemoteKnobs) return;
            if (! applyBoundKnob ("kMic", micVolumeKnob.getValue()))
                if (auto* t = micTrack()) t->setGainDb ((float) micVolumeKnob.getValue());
            if (! (micVolumeKnob.isMouseButtonDown() || quickDragging)) announceChange();
        };
        micVolumeKnob.onDragEnd = [this] { announceChange(); };

        musicVolumeKnob.onValueChange = [this]
        {
            if (updatingRemoteKnobs) return;
            if (! applyBoundKnob ("kMusic", musicVolumeKnob.getValue()))
                if (auto* t = nhacTrack()) t->setGainDb ((float) musicVolumeKnob.getValue());
            if (! (musicVolumeKnob.isMouseButtonDown() || quickDragging)) announceChange();
        };
        musicVolumeKnob.onDragEnd = [this] { announceChange(); };

        delayKnob.onValueChange = [this]
        {
            if (updatingRemoteKnobs) return;
            if (! applyBoundKnob ("kDelay", delayKnob.getValue()))
                setMicSendLevelToRole (Track::Role::Delay, (float) delayKnob.getValue());
            if (! (delayKnob.isMouseButtonDown() || quickDragging)) announceChange();
        };
        delayKnob.onDragEnd = [this] { announceChange(); };

        reverbLongKnob.onValueChange = [this]
        {
            if (updatingRemoteKnobs) return;
            if (! applyBoundKnob ("kRevLong", reverbLongKnob.getValue()))
                setMicSendLevelToRole (Track::Role::ReverbLong,
                                       (float) reverbLongKnob.getValue());
            if (! (reverbLongKnob.isMouseButtonDown() || quickDragging)) announceChange();
        };
        reverbLongKnob.onDragEnd = [this] { announceChange(); };

        reverbShortKnob.onValueChange = [this]
        {
            if (updatingRemoteKnobs) return;
            if (! applyBoundKnob ("kRevShort", reverbShortKnob.getValue()))
                setMicSendLevelToRole (Track::Role::ReverbShort,
                                       (float) reverbShortKnob.getValue());
            if (! (reverbShortKnob.isMouseButtonDown() || quickDragging)) announceChange();
        };
        reverbShortKnob.onDragEnd = [this] { announceChange(); };

        /* V6.1: mui ten nho nam GIUA hang nut va hang 7 num. Bam mot lan
           thu gon toan bo 7 num; bam lan nua mo lai. MainComponent da co
           onHeightChanged -> cua so tu doi chieu cao, khong de lai khoang
           trong ben duoi. */
        knobFoldButton.setExpanded (knobsExpanded);
        knobFoldButton.setTooltip (livent::vn ("Thu gọn / mở rộng hàng núm chỉnh"));
        knobFoldButton.onClick = [this]
        {
            setKnobsExpanded (! knobsExpanded, true);
        };
        statusFold.setExpanded (knobsExpanded);
        statusFold.setTooltip (livent::vn ("Thu gọn / mở rộng hàng núm chỉnh"));
        statusFold.onClick = [this] { setKnobsExpanded (! knobsExpanded, true); };
        addAndMakeVisible (knobFoldButton);

        refreshRemoteKnobs();
        setupHelpTexts();   // 02/10: loi giai thich cho che do huong dan "?"

        autoButton.setButtonText (livent::vn ("TỰ BẮT LINK: BẬT"));
        autoButton.setClickingTogglesState (true);
        autoButton.setToggleState (true, juce::dontSendNotification);
        autoButton.setColour (juce::TextButton::buttonOnColourId, Col::green.darker (0.35f));
        autoButton.onClick = [this] { toggleAutoWatch(); };
        addAndMakeVisible (autoButton);

        autoShiftButton.setButtonText (livent::vn ("TỰ ĐỔI TÔNG: BẬT"));
        autoShiftButton.setClickingTogglesState (true);
        autoShiftButton.setToggleState (true, juce::dontSendNotification);
        autoShiftButton.setColour (juce::TextButton::buttonOnColourId, Col::green.darker (0.35f));
        autoShiftButton.setTooltip (livent::vn ("Tới phút có đổi tông thì tự bắn Key/Scale mới vào plugin"));
        autoShiftButton.onClick = [this]
        {
            autoShiftButton.setButtonText (autoShiftButton.getToggleState()
                                           ? livent::vn ("TỰ ĐỔI TÔNG: BẬT") : livent::vn ("TỰ ĐỔI TÔNG: TẮT"));
        };
        addAndMakeVisible (autoShiftButton);

        //  MOC 74: nut TACH RA da bi bo han - xem ghi chu o phan nut dock.

        /*  Rinh thay bai moi -> tu dan link vao o va do luon, khong phai bam
            them cai nao. Dung dieu anh muon: mo YouTube len la xong.  */
        watcher.onTick = [this, safeThis = juce::Component::SafePointer<TonePanel> (this)] (BrowserWatcher::Info info)
        {
            if (safeThis == nullptr)
                return;
            // Ten bai luon cap nhat; dai thi NowPlayingStrip tu chay ngang.
            if (info.title.isNotEmpty())
            {
                currentSongTitle = info.title;
                nowPlaying.setTitle (info.title);
            }

            /* Chi ap dong ho/timeline khi dung video dang dung. */
            if (info.videoId != detectedVideoId)
            {
                autoKeyPlaybackClock.reset(); // stop old-song clicks before watcher confirmation
                lastExactSongTickMs = 0; // do not advance markers from the previous video
                return;
            }

            /* FIX 03/10 - dong ho Dò tay:
               - Nguon LiveNT-YouTube / tien ich co tag: dung so giay THAT.
               - Trinh duyet ngoai khong co tag: van cho dong ho chay bang nhip
                 watcher 1 Hz thay vi dung im 00:00. Day la uoc luong nen KHONG
                 tu doi tone timeline theo gio uoc luong (tranh doi sai khi pause/seek). */
            const double nowMs = juce::Time::getMillisecondCounterHiRes();
            double shownSeconds = (double) info.seconds;

            if (info.hasTimeTag)
            {
                fallbackClockVideoId = info.videoId;
                fallbackClockSeconds = shownSeconds;
                fallbackClockLastMs = nowMs;
            }
            else
            {
                if (fallbackClockVideoId != info.videoId || fallbackClockLastMs <= 0.0)
                {
                    fallbackClockVideoId = info.videoId;
                    fallbackClockSeconds = 0.0;
                }
                else
                {
                    // Poll binh thuong 1s; clamp de app bi treo/resume khong nhay vai phut.
                    fallbackClockSeconds += juce::jlimit (0.0, 2.5, (nowMs - fallbackClockLastMs) / 1000.0);
                }

                fallbackClockLastMs = nowMs;
                shownSeconds = fallbackClockSeconds;
            }

            const double totalGuess = (info.knowsLength && info.duration > 0)
                                        ? (double) info.duration : clock.getSpan();
            clock.setPosition (shownSeconds, true);
            nowPlaying.setPosition (shownSeconds, totalGuess, true);
            autoKeyPlaybackClock.update (shownSeconds, nowMs / 1000.0,
                                         info.knowsPlaying, info.playing);

            if (info.hasTimeTag)
            {
                lastExactSongSeconds = shownSeconds;
                lastExactSongTickMs = nowMs;
                exactSongPlaying = info.knowsPlaying && info.playing;
                checkForToneShift (shownSeconds);
            }
            else lastExactSongTickMs = 0; // estimated time is only for the display
        };

        watcher.onNewVideo = [this, safeThis = juce::Component::SafePointer<TonePanel> (this)] (BrowserWatcher::Info info)
        {
            if (safeThis == nullptr)
                return;
            autoVangKeyReady = false;   // 15/10: bai moi -> cho do tong xong moi bat Vang
            const auto link = "https://www.youtube.com/watch?v=" + info.videoId;
            currentSongUrl = link;
            urlBox.setText (link, juce::dontSendNotification);

            /*  V5.8.5: neu bai nay VUA duoc mo tu DANH SACH BAI HAT thi
                Key/Scale/Beat shift DA CO nguoi dung luu. Du lieu da luu la
                nguon co tham quyen cao hon VPS. BrowserWatcher van can bat
                video de lay thoi gian timeline, nhung TUYET DOI khong duoc
                goi prepareForNewSong()/startDetect() roi ghi de tone da luu.

                Giu pinned id trong SUOT bai (khong chi bo qua mot tick): neu
                BrowserWatcher khoi dong lai hoac gui lai onNewVideo cung id,
                tone da luu van khong bi VPS de len. Bam DO TONE bang tay van
                la lenh ro rang cua nguoi dung va se bo pin trong startDetect(). */
            if (libraryToneVideoId.isNotEmpty() && info.videoId == libraryToneVideoId)
            {
                detectedVideoId = info.videoId;
                if (currentSongTitle.isEmpty()) currentSongTitle = info.title;
                nowPlaying.setTitle (currentSongTitle.isNotEmpty() ? currentSongTitle : info.title);
                acceptSavedSongClock (info);
                statusLabel.setText (livent::vn ("Đang dùng tone đã lưu của bài - không hỏi VPS."),
                                     juce::dontSendNotification);
                return;
            }

            if (loadSavedSongMarkers (info)) return;

            // Video that su khac bai da mo tu thu vien -> tro lai che do tu do VPS.
            libraryToneVideoId.clear();
            skipNoticeUntilMs = 0;
            keyDisplayButton.setTooltip (livent::vn ("Bấm để chọn Key/Scale trực tiếp"));
            currentSongTitle = info.title;
            nowPlaying.setTitle (info.title);
            nowPlaying.setPosition (0.0, 0.0, false);

            /*  V4.5: day la diem DUY NHAT BrowserWatcher bao "bai moi".
                Neu chon TỰ VỀ 0 thi reset pitch NHAC truoc, nhung KHONG ban
                Key cu cua bai truoc sang Auto-Tune. Neu chon GIỮ thi chi
                xoa Key/Scale cu, con gia tri +/- van de nguyen. */
            prepareForNewSong();

            if (manualDetectMode)
            {
                // Dò tay khong co callback VPS de gan detectedVideoId. Neu bo
                // dong nay thi onTick thay video "khac bai da do" va dong ho dung im.
                detectedVideoId = info.videoId;
                fallbackClockVideoId = info.videoId;
                fallbackClockSeconds = info.hasTimeTag ? (double) info.seconds : 0.0;
                fallbackClockLastMs = juce::Time::getMillisecondCounterHiRes();
                builtinNewSong();   // 12s
                return;
            }
            startDetect (false);
        };

        /*  30/09: video livestream / dai qua 15 phut -> KHONG gui VPS (VPS treo).
            Nut Tone bai hien "Khong do" vai giay; khach tu chinh tone bang tay. */
        watcher.onSkippedVideo = [this, safeThis = juce::Component::SafePointer<TonePanel> (this)] (BrowserWatcher::Info info)
        {
            if (safeThis == nullptr)
                return;

            if (libraryToneVideoId.isNotEmpty() && info.videoId == libraryToneVideoId)
            {
                detectedVideoId = info.videoId;   // bai mo tu Danh sach: da co tone luu san
                acceptSavedSongClock (info);
                return;
            }

            if (loadSavedSongMarkers (info)) return;

            libraryToneVideoId.clear();
            currentSongTitle = info.title;
            nowPlaying.setTitle (info.title);
            nowPlaying.setPosition (0.0, 0.0, false);

            currentSongUrl = "https://www.youtube.com/watch?v=" + info.videoId;
            urlBox.setText (currentSongUrl, juce::dontSendNotification);
            prepareForNewSong();
            if (manualDetectMode)
            {
                detectedVideoId = info.videoId;
                fallbackClockVideoId = info.videoId;
                fallbackClockSeconds = info.hasTimeTag ? (double) info.seconds : 0.0;
                fallbackClockLastMs = juce::Time::getMillisecondCounterHiRes();
                builtinNewSong();   // 12s
                return;
            }

            const auto why = info.live
                ? livent::vn ("Video đang livestream - không gửi dò tone, hãy chỉnh tone bằng tay.")
                : livent::vn ("Video dài hơn ") + juce::String (BrowserWatcher::maxVideoSecondsForVps / 60)
                  + livent::vn (" phút - không gửi dò tone, hãy chỉnh tone bằng tay.");
            statusLabel.setText (why, juce::dontSendNotification);
            keyDisplayButton.setTooltip (why);
            skipNoticeUntilMs = juce::Time::getMillisecondCounter() + 8000;
            refreshKeyDisplay();
            // 12s: khong gui duoc AI -> T-AutoKey co san do thay (khach van chinh tay duoc)
            skipNoticeUntilMs = 0;
            startBuiltinFallback (info.live ? livent::vn ("Video livestream - không gửi AI")
                                            : livent::vn ("Video dài - không gửi AI"));
        };

        //-- Ket qua ---------------------------------------------------------
        /*  MOC 80: da bo clockLabel ("01:32") theo yeu cau anh - thanh
            ToneClock (clock) ben duoi da tu co thanh truot chay hien vi tri/
            so giay roi, hien them mot o chu rieng ghi lai cung mot con so
            la thua. Ket qua (resultLabel, "C# Minor") gio doi len nam
            NGAY HANG TIEU DE, canh nut THU - xem resized(). Do chuyen len
            hang thap (26-32px) nen giam font tu 24pt xuong 18pt cho vua,
            van la Bold + mau vang de noi bat, chi la nho lai chut.  */
        resultLabel.setFont (juce::Font (juce::FontOptions (18.0f).withStyle ("Bold")));
        resultLabel.setColour (juce::Label::textColourId, juce::Colour (0xffffd24a));
        resultLabel.setJustificationType (juce::Justification::centred);
        addAndMakeVisible (resultLabel);

        /*  MOC 40: to len 11 -> 15.

            Day la dong bao "bai nay giu nguyen tong" hay "toi phut 2:14 doi
            sang F# Minor" -- thu anh phai liec doc duoc TRONG luc dang hat,
            cach man hinh ca met. Co chu 11 la co chu de doc khi ngoi sat man
            hinh, khong phai de doc khi dang cam mic.  */
        statusLabel.setFont (juce::Font (juce::FontOptions (15.0f)));
        statusLabel.setColour (juce::Label::textColourId, Col::textDim);
        statusLabel.setJustificationType (juce::Justification::centred);
        addAndMakeVisible (statusLabel);

        timelineLabel.setFont (juce::Font (juce::FontOptions (14.0f)));   // MOC 40
        timelineLabel.setColour (juce::Label::textColourId, juce::Colour (0xff5fd8e0));
        timelineLabel.setJustificationType (juce::Justification::topLeft);
        addAndMakeVisible (timelineLabel);

        addAndMakeVisible (clock);

        refreshTrackList();
        updateChildVisibility();
        startTimerHz (4);

        /*  MOC 66: truoc day (Moc 33/35) Mac bi KHOA khong cho tu bat may
            rinh, vi luc do BrowserWatcher.h chua co cach doc trinh duyet
            tren Mac (chi Windows co UI Automation). Gio da them duong Mac
            rieng (AppleScript qua NSAppleScript trong BrowserWatcherMac.mm),
            nen ca hai he dieu hanh deu bat may rinh ngay tu dau nhu nhau -
            khong con can #if JUCE_WINDOWS / #else rieng nua.  */
        watcher.startWatching();
    }

    /*  MOC 75: chieu cao mong muon khi bang nam NGANG tren cung.

        MainComponent goi ham nay de biet cat bao nhieu px o mep tren. Rieng
        truong hop MOI THU KHAC DEU DANG AN thi MainComponent bo qua con so
        nay va cho bang chiem tron cua so (xem MainComponent::resized).  */
    /*  ==========  06/10: CHE DO THU GON (mau 1B anh chot)  ==========
        2 hang x 8 o bang nhau, thang cot. Hang tren: [Thu*] [ten bai chu chay]
        [gio] [‹ Key ›] [‹ Tone ›] [Preset] [Cuoi*] [▴ ✕*]  (*: nut cua
        MainComponent dat de len o do). Hang duoi: 8 nut hieu ung.
        Dung lai DUNG cac nut cua bang dieu khien - khong co duong thu hai.  */
    static constexpr int compactCellW = 76, compactCellH = 30, compactGap = 6;
    static int compactGridWidth()  noexcept { return 8 * compactCellW + 7 * compactGap; }
    static int compactGridHeight() noexcept { return 2 * compactCellH + compactGap; }
    static juce::Rectangle<int> compactCell (int row, int col, int span = 1) noexcept
    {
        return { col * (compactCellW + compactGap), row * (compactCellH + compactGap),
                 span * compactCellW + (span - 1) * compactGap, compactCellH };
    }

    void setCompactMode (bool on)
    {
        if (compactMode == on)
            return;
        compactMode = on;
        nowPlayingClockLabel.setJustificationType (on ? juce::Justification::centred
                                                      : juce::Justification::centredRight);
        updateChildVisibility();
        resized();
        repaint();
    }

    bool isCompactMode() const noexcept { return compactMode; }

    int getWantedHeight() const
    {
        // Bo cuc doc giu CHIEU CAO on dinh; 7 num mo sang ben phai.
        if (verticalLayout)
            return verticalWantedHeight();

        // Bo cuc ngang: hang 7 num thu gon/mo theo chieu doc nhu cu.
        // Hang Tone bai / Tone nhac dang nam duoi cua so YouTube -> bot 1 hang.
        const int songRowSaving = songRowHidden ? v6TopSectionHeight + secGap : 0;
        return (knobsExpanded ? v6PanelHeight : v6CollapsedHeight) - songRowSaving;
    }

    //==========================================================================
    //  CUA SO YOUTUBE: khoi Tone bai / Tone nhac / Nguon nam duoi video.
    //  DAW van giu toan bo logic; YouTube chi hien thi va gui lenh bam nut.
    //==========================================================================
    /** An hang [ten bai | Tone bai | Tone nhac | nguon] tren DAW (bo cuc
        ngang) khi hang do dang hien duoi cua so YouTube. */
    void setSongRowHidden (bool hidden)
    {
        if (songRowHidden == hidden)
            return;

        songRowHidden = hidden;
        resized();
        repaint();

        if (onHeightChanged)
            onHeightChanged();
    }

    bool isSongRowHidden() const noexcept { return songRowHidden; }

    /** Trang thai gui sang cua so YouTube (moi dong mot truong). */
    juce::String getRemoteStateText()
    {
        return "key="   + keyDisplayButton.getButtonText() + "\n"
             + "tone="  + toneValueLabel.getText() + "\n"
             + "power=" + juce::String (toneVstPowerButton.getToggleState() ? 1 : 0) + "\n"
             + "powerok=" + juce::String (toneVstPowerButton.isEnabled() ? 1 : 0) + "\n"
             + "powertip=" + toneVstPowerButton.getTooltip().replaceCharacters ("\r\n", "  ") + "\n";
    }

    /** Lenh tu nut tren cua so YouTube. Tra false neu khong phai lenh cua bang nay. */
    bool handleRemoteCommand (const juce::String& cmd)
    {
        if      (cmd == "key-")    nudgeKey (-1);
        else if (cmd == "key+")    nudgeKey ( 1);
        else if (cmd == "scale")   toggleScaleManual();
        else if (cmd == "keymenu") showKeyMenu();
        else if (cmd == "tone-")   nudgeTone (-0.5f);
        else if (cmd == "tone+")   nudgeTone ( 0.5f);
        else if (cmd == "power")   { if (toneVstPowerButton.isEnabled() && ! pressBound ("beat")) toggleMusicInsert (0); }
        else return false;

        return true;
    }

    /** Chieu cao anh tu keo. 0 = tu tinh theo noi dung. */
    int  getManualHeight() const noexcept   { return 0; }
    void setManualHeight (int) noexcept      { manualHeight = 0; }

    /*  MOC 75: bam nut CAI DAT tren bang. MainComponent lo phan hop thoai -
        TonePanel khong biet gi ve cai dat cua app.  */
    std::vector<std::pair<juce::String, juce::Button*>> shortcutButtons()
    {
        return { { "tune", &tuneButton }, { "music", &nhacButton }, { "mic", &micButton },
                 { "reverb", &vangButton }, { "lofi", &lofiButton }, { "remix1", &remix1Button },
                 { "remix2", &remix2Button }, { "baby", &babyButton }, { "harmony", &harmonyButton },
                 { "paste", &pasteButton }, { "detect", &detectButton }, { "autoTune", &autoTuneButton },
                 { "toneMode", &toneModeButton }, { "toneDown", &toneMinusButton }, { "toneUp", &tonePlusButton },
                 { "keyDown", &keyMinusButton }, { "keyUp", &keyPlusButton }, { "key", &keyDisplayButton },
                 { "scale", &scaleToggleButton }, { "songSave", &saveSongButton }, { "songList", &songListButton },
                 { "recordMaster", &recButton }, { "beat", &beatButton }, { "presets", &presetButton },
                 { "auto", &autoButton }, { "autoShift", &autoShiftButton }, { "toneVst", &toneVstPowerButton },
                 { "link", &linkToggle } };
    }
    std::function<void()> onOpenSettings;
    std::function<void (const juce::String&)> onCustomUtility;
    std::function<bool (const juce::String&)> getCustomUtilityState;

    std::function<void()> onHeightChanged;
    std::function<void()> onPanelStateChanged;
    std::function<void(bool)> onLaughPopupChanged;   // V6.0.1: đồng bộ nút CƯỜI khi mở/đóng popup
    std::function<void()> onPluginChanged;

    /*  ==========  MOC 82: DAI NUT TIENG CUOI  ==========

        Anh chot: thu gon bang dieu khien lai thi hien MOT DAI 6-8 nut tieng
        cuoi ngay tren hang tieu de. Bam phat ngay, khong qua bang nao.

        Vi sao dat vao hang tieu de chu khong them mot hang moi: thu gon bang
        la de LAY LAI CHO tren man hinh. Them mot hang nua thi mat dung cai
        vua tiet kiem duoc. Hang tieu de luc thu gon dang trong gan het be
        ngang - do la cho san co, khong ton them px nao.

        File mp3 lay tu %APPDATA%\\TINH DEP TRAI\\tiengcuoi - dung thu muc cua
        tool Python, nen bo tieng cuoi anh dang co chay duoc ngay khong phai
        chep di dau.  */
    /*  ==========  MOC 86: TIM THU MUC TIENG CUOI  ==========

        Tim theo thu tu, lay cho DAU TIEN co that:

          1. <thu muc chua LiveNT.exe>\tiengcuoi
             = C:\Program Files\LiveNT\tiengcuoi khi cai bang bo cai.
             Day la cho CHINH tu Moc 86 - bo cai chep san bo tieng vao day
             nen khach cai xong la co ngay, khong phai tu chep gi.

          2. %APPDATA%\TINH DEP TRAI\tiengcuoi
             Thu muc cua tool Python. Giu lai de may anh dang chay ban dich
             tu ban dev van thay du bo tieng cu.

          3. %APPDATA%\LiveNT\tiengcuoi
             Cho de anh (hoac khach) tu them tieng rieng ma khong dung vao
             Program Files - ghi vao Program Files can quyen quan tri.

        Khong cho nao co thi tra ve cho (1), de dong bao "thieu file" chi
        dung noi anh NEN chep vao.  */
    /*  ==========  MOC 74: THU AM  ==========

        TonePanel chi lo phan NUT. Viec mo file, ghi dia, hoi noi luu... van
        nam nguyen ben MainComponent (startMasterRecording/stopMasterRecording)
        - khong chep sang day, de chi co MOT noi lam viec do.  */
    std::function<void()> onStartRecord;
    std::function<void()> onStopRecord;

    /** MainComponent goi sau khi bat/dung ghi, de hai nut sang/xam dung. */
    void setRecordingActive (bool isRecording)
    {
        //  MOC 89: mot nut, doi chu va doi mau theo trang thai
        //  V6.0: nut vuong nho - cham do khi tat, o vuong + phut:giay khi dang thu
        recButton.setToggleState (isRecording, juce::dontSendNotification);
        recButton.setButtonText (isRecording ? juce::String ("00:00") : juce::String());
        resized();
        repaint();
    }

    //=========================================================================
    //  Luu / nap cung du an  (MainComponent goi)
    //=========================================================================
    bool isPanelOpen()   const   { return header.isOpen(); }
    void setPanelOpen (bool on)  { header.setOpen (on, false); updateChildVisibility(); }

    bool isAutoWatchOn() const   { return autoButton.getToggleState(); }

   #if JUCE_MAC
    /*  MOC 66e: cho MainComponent (menu Studio) doi trinh duyet muon dò -
        chuyen thang xuong BrowserWatcher ben trong. Chuoi rong = tu do doan.  */
    void setPreferredBrowser (const juce::String& appName) { watcher.setPreferredBrowser (appName); }
    juce::String getPreferredBrowser() const                { return watcher.getPreferredBrowser(); }
   #endif

    bool isLinkRowOpen() const   { return linkToggle.getToggleState(); }

    /*  15/10: VANG TU DONG THEO NHAC. Bat thi:
          - DAW do xong Key/Scale bai dang mo + co nhac -> tu BAT nut Vang (Send cua MIC)
            (may chu do tong loi: co nhac lien tuc ~5 giay cung tu bat)
          - track NHAC im ~3 giay (dung / het bai) -> tu TAT nut Vang
        Khach ngoi noi chuyen (khong co nhac) thi giong mic khong bi vang.
        Chi doi luc nhac BAT DAU / DUNG; giua bai bam tay nut Vang van giu dung y anh.
        Mac dinh TAT (may khach phat nhac ngoai DAW thi khong do duoc nhac).  */
    bool isAutoVangByMusic() const noexcept { return autoVangByMusic; }
    void setAutoVangByMusic (bool on)
    {
        autoVangByMusic = on;
        autoVangMusicTicks = autoVangSilentTicks = 0;
        autoVangLastDecision = -1;
        PluginChain::getSettingsFolder().getChildFile ("auto-vang-music.txt").replaceWithText (on ? "1" : "0");
    }

    bool isResetToneOnNewSong() const noexcept { return resetToneOnNewSong; }
    void setResetToneOnNewSong (bool on)
    {
        resetToneOnNewSong = on;
        saveResetTonePreference();
        updateToneModeButton();
    }

    void setLinkRowOpen (bool on)
    {
        linkToggle.setToggleState (on, juce::dontSendNotification);
        linkToggle.setButtonText (on ? livent::vn ("Dán link tay  ^") : livent::vn ("Dán link tay  v"));
        updateChildVisibility();
    }

    void setAutoWatchOn (bool on)
    {
        if (manualDetectMode)
            on = false;   // 02/10: che do Do tay -> luon tat bat link

        /*  MOC 33: du an luu tu may Windows co the ghi "tu bat link = BAT".
            Mo dung du an do tren Mac ma cu the bat theo thi may rinh chay
            khong, va nut lai sang xanh nhu that. Bo qua han tren Mac.  */
       #if JUCE_MAC
        juce::ignoreUnused (on);
       #else
        autoButton.setToggleState (on, juce::dontSendNotification);
        toggleAutoWatch();
       #endif
    }

    int  getTargetTrackId() const   { return getSelectedTrackId(); }

    void setHarmonyButtonVisible (bool shouldShow)
    {
        harmonyButtonAllowed = shouldShow;
        updateChildVisibility();
    }

    bool isHarmonyButtonVisible() const noexcept { return harmonyButtonAllowed; }

    void setTargetTrackId (int id)
    {
        /*  V5.1: project cu co the da luu nham "AM THANH RA" lam dich
            Key/Scale. Day la mot dich vo nghia voi cach dung hat live cua
            LiveNT, va chinh no lam moi lan mo du an o "Ban vao track" lai
            nhay ve AM THANH RA.

            Neu id luu cu tro vao Output/OutputBus/PK thi coi la legacy sai
            va dua ve MIC. Cac track khac van cho phep chon tay nhu cu. */
        if (auto* requested = mixer.getTrackById (id))
        {
            const auto ty = requested->getType();

            if (ty == Track::Type::Output
                || ty == Track::Type::OutputBus
                || ty == Track::Type::PK)
            {
                if (auto* mic = micTrack())
                    id = mic->getId();
            }
        }

        const int at = trackIds.indexOf (id);

        if (at >= 0)
            targetBox.setSelectedId (at + 1, juce::dontSendNotification);
        else if (auto* mic = micTrack())
        {
            const int micAt = trackIds.indexOf (mic->getId());
            if (micAt >= 0)
                targetBox.setSelectedId (micAt + 1, juce::dontSendNotification);
        }
    }

    /** V5.7: dua "Ban Key/Scale vao track" vao menu Studio.
        Track duoc chon van luu bang permanent track id; doi ten/reorder khong anh huong. */
    void showTargetTrackMenu()
    {
        refreshTrackList();

        juce::PopupMenu menu;
        const int current = getSelectedTrackId();

        for (int i = 0; i < trackIds.size(); ++i)
        {
            if (auto* t = mixer.getTrackById (trackIds[i]))
            {
                const auto ty = t->getType();
                if (ty == Track::Type::Output || ty == Track::Type::OutputBus || ty == Track::Type::PK)
                    continue;

                const int id = t->getId();
                menu.addItem (1000 + i, t->getName(), true, id == current);
            }
        }

        juce::Component::SafePointer<TonePanel> safe (this);
        menu.showMenuAsync (livent::menuAtPointer (this), [safe] (int result)
        {
            if (safe == nullptr || result < 1000) return;
            const int at = result - 1000;
            if (juce::isPositiveAndBelow (at, safe->trackIds.size()))
                safe->setTargetTrackId (safe->trackIds[at]);
        });
    }

    void refreshTrackList()
    {
        const int keepId = getSelectedTrackId();

        targetBox.clear (juce::dontSendNotification);
        trackIds.clear();

        for (int i = 0; i < mixer.getNumTracks(); ++i)
        {
            auto* t = mixer.getTrack (i);

            if (t == nullptr)
                continue;

            trackIds.add (t->getId());
            targetBox.addItem (t->getName(), trackIds.size());
        }

        /*  MOC 36: giu nguyen track anh dang chon; chua chon gi thi nhay vao
            MIC.

            Truoc day roi ve muc DAU TIEN, ma muc dau tien la NHAC -- ban
            Key/Scale vao track nhac thi khong co tac dung gi, vi plugin
            chinh cao do nam o track MIC. Moi lan mo app lai phai nho doi
            tay mot lan, quen la ngoi thac mac sao do tone khong an.  */
        int at = trackIds.indexOf (keepId);

        /*  Neu o dang giu la Output/OutputBus/PK (thuong do project cu luu
            nham), KHONG coi no la lua chon mac dinh hop le. Ve MIC. */
        if (auto* kept = mixer.getTrackById (keepId))
        {
            const auto ty = kept->getType();
            if (ty == Track::Type::Output
                || ty == Track::Type::OutputBus
                || ty == Track::Type::PK)
                at = -1;
        }

        if (at < 0)
            if (auto* mic = micTrack())
                at = trackIds.indexOf (mic->getId());

        targetBox.setSelectedId (at >= 0 ? at + 1 : 1, juce::dontSendNotification);
    }

    /*  V6.0: GIAO DIEN PHANG - 3 khoi bo goc (hang tren / nut / num), nhan
        nho nam tren moi nhom, vach mong ngan cach nhom. Chi fillRect +
        drawText: khong gradient, khong vet sang.  */
    void paint (juce::Graphics& g) override
    {
        if (compactMode)
        {
            // 06/10: o thong tin (ten bai, gio, Key, Tone) cung khung voi nut
            for (auto& c : compactInfoCells)
            {
                g.setColour (Col::panel);
                g.fillRoundedRectangle (c.toFloat().reduced (0.5f), 8.0f);
                g.setColour (Col::line);
                g.drawRoundedRectangle (c.toFloat().reduced (0.5f), 8.0f, 1.0f);
            }
            return;
        }

        // 16/10: skin mau 3 - tam nhom chai + man LCD. Chi doi cach ve, bo cuc giu nguyen.
        const bool rack = livent::rack::active();
        if (rack && rackAppliedGen != livent::rack::generation() * 100 + livent::rack::index())
        {
            rackAppliedGen = livent::rack::generation() * 100 + livent::rack::index();   // chi hen 1 lan
            juce::Component::SafePointer<TonePanel> safeRack (this);
            juce::MessageManager::callAsync ([safeRack] { if (safeRack != nullptr) safeRack->applyRackSkinProps(); });
        }

        for (auto sec : { secTop, secChips, secKnobs })
        {
            if (sec.isEmpty())
                continue;

            const auto f = sec.toFloat().reduced (0.5f);
            if (rack)
            {
                livent::rack::drawPlate (g, f, 8.0f);
                continue;
            }
            g.setColour (Col::panel);
            g.fillRoundedRectangle (f, 8.0f);
            g.setColour (Col::line);
            g.drawRoundedRectangle (f, 8.0f, 1.0f);
        }

        g.setColour (rack ? juce::Colours::black.withAlpha (livent::rack::isDark() ? 0.45f : 0.22f) : Col::line);
        for (auto& sep : separators)
            g.fillRect (sep);

        g.setColour (rack ? livent::rack::textDimOnPlate() : Col::textDim);
        g.setFont (juce::Font (juce::FontOptions (12.5f).withStyle ("Medium")));
        for (auto& c : captions)
            g.drawText (c.text, c.area, juce::Justification::centredLeft, true);

        if (! toneValueBox.isEmpty())
        {
            if (rack)
                livent::rack::drawLcdBox (g, toneValueBox.toFloat(), 4.0f);
            else
            {
                g.setColour (Col::bg);
                g.fillRoundedRectangle (toneValueBox.toFloat(), 6.0f);
            }
        }
    }

    //=========================================================================
    //  16/10: SKIN MAU 3 - gan thuoc tinh cho nut / num theo mau da chon
    //=========================================================================
    int rackAppliedGen = -999;

    void applyRackSkinProps()
    {
        rackAppliedGen = livent::rack::generation() * 100 + livent::rack::index();
        const bool on = livent::rack::active();

        struct B { juce::TextButton* b; const char* a; juce::uint32 defaultChip; };
        const B list[] = { { &tuneButton, "tune", 0xfff5b800 },    { &nhacButton, "nhac", 0xff4c8dff },
                           { &micButton, "mic", 0xff2bd4a4 },      { &vangButton, "vang", 0xffa78bfa },
                           { &lofiButton, "lofi", 0xffff9f43 },    { &remix1Button, "remix1", 0xffff5fa2 },
                           { &remix2Button, "remix2", 0xff29c5f6 },{ &babyButton, "baby", 0xff8ee36a },
                           { &harmonyButton, "harmony", 0xffff6b6b } };
        auto meters = chipMeters();
        for (size_t i = 0; i < 9; ++i)
        {
            auto& e = list[i];
            if (on) e.b->getProperties().set ("rackFn", (int) livent::rack::fnColour (e.a).getARGB());
            else    e.b->getProperties().remove ("rackFn");
            meters[i]->setColour (on ? livent::rack::fnColour (e.a) : juce::Colour (e.defaultChip));
            e.b->repaint();
        }

        for (auto* k : { (juce::Slider*) &tuneSpeedKnob, (juce::Slider*) &flexTuneKnob,
                         (juce::Slider*) &musicVolumeKnob, (juce::Slider*) &micVolumeKnob,
                         (juce::Slider*) &reverbLongKnob, (juce::Slider*) &reverbShortKnob,
                         (juce::Slider*) &delayKnob })
        {
            if (on) k->getProperties().set ("rackKnob", true);
            else    k->getProperties().remove ("rackKnob");
            k->repaint();
        }

        // 12o: chu chu thich num - dam, ~12 px, mau chu chinh cua kieu (khong con mau nhat)
        const auto capCol = on ? livent::rack::textOnPlate() : Col::textDim;
        const auto capFont = on ? juce::Font (juce::FontOptions (12.0f).withStyle ("Bold"))
                                : juce::Font (juce::FontOptions (12.5f).withStyle ("Medium"));
        for (auto* l : { &tuneSpeedCaption, &flexTuneCaption, &musicVolumeCaption, &micVolumeCaption,
                         &reverbLongCaption, &reverbShortCaption, &delayCaption })
        {
            l->setColour (juce::Label::textColourId, capCol);
            l->setFont (capFont);
        }

        // 12o: o so (0.0 dB, 20...) thanh man LCD: nen den, chu mau LCD cua kieu, font lon hon
        {
            juce::Slider* ks[] = { (juce::Slider*) &tuneSpeedKnob, (juce::Slider*) &flexTuneKnob,
                                   (juce::Slider*) &musicVolumeKnob, (juce::Slider*) &micVolumeKnob,
                                   (juce::Slider*) &reverbLongKnob, (juce::Slider*) &reverbShortKnob,
                                   (juce::Slider*) &delayKnob };
            for (auto* k : ks)
            {
                k->setColour (juce::Slider::textBoxTextColourId, on ? livent::rack::valueText() : Col::text);      // 12w: theo kieu
                k->setColour (juce::Slider::textBoxBackgroundColourId, on ? livent::rack::valueBoxBg() : Col::bg);
                k->setColour (juce::Slider::textBoxOutlineColourId, on ? livent::rack::valueBoxOutline()
                                                                       : juce::Colours::transparentBlack);
                k->sendLookAndFeelChange();   // tao lai o so de nhan font LCD
            }
        }

        toneValueLabel.setFont (juce::Font (juce::FontOptions (on ? 15.0f : 13.0f).withStyle (on ? "Bold" : "Regular")));
        toneValueLabel.setColour (juce::Label::textColourId, on ? livent::rack::lcdText() : Col::text);

        // 12w: kieu moi - o Key thanh man LCD, +/- va M/m thanh phim cua kieu (kieu Nhom / phang: giu nhu cu)
        {
            const bool ns = on && livent::rack::newStyle();
            for (auto* b : { &keyMinusButton, &keyPlusButton, &scaleToggleButton, &toneMinusButton, &tonePlusButton })
            {
                if (ns) b->getProperties().set ("rackPlain", true); else b->getProperties().remove ("rackPlain");
                b->repaint();
            }
            if (ns) keyDisplayButton.getProperties().set ("rackLcdBtn", true); else keyDisplayButton.getProperties().remove ("rackLcdBtn");
            keyDisplayButton.repaint();
        }

        // 12o: thanh canh num mang mau chuc nang cua tung num
        {
            struct M { KnobMeter* m; const char* a; };
            const M mm[] = { { &musicKnobMeter, "nhac" }, { &micKnobMeter, "mic" }, { &tuneMeter, "tune" },
                             { &flexMeter, "tune" }, { &reverbLongMeter, "vang" }, { &reverbShortMeter, "vang" },
                             { &delayMeter, "vang" } };
            for (auto& e : mm)
                e.m->setColour (livent::rack::fnColour (e.a));
        }
        presetStrip.repaint();
        resized();
        repaint();
    }

public:
    /** 16/10: MainComponent goi khi anh chon mau nen khac trong menu Hien thi. */
    void refreshRackSkin() { rackAppliedGen = -999; applyRackSkinProps(); }
public:


    /*  ==========  MOC 75: BO CUC NGANG (CHE DO MAC DINH)  ==========

        Bang nam ngang tren cung, chiem het be ngang cua so. Cac hang o tren
        cao CO DINH; phan cao con lai bao nhieu thi dai thoi gian (ToneClock)
        an het bay nhieu - nho vay bang dung duoc ca khi chi cao 290 px lan
        khi chiem tron cua so.

        V6.5.0 them resizedVertical() rieng cho che do Live doc; nhanh ngang
        nay giu nguyen de project/nguoi dung cu khong bi doi thao tac.  */
    /*  MOC 79: PHAI go LookAndFeel ra truoc khi bang bi huy.

        JUCE bat loi ngay (jassert) neu mot LookAndFeel bi xoa trong khi con
        component nao do dang tro toi no. glassLook la thanh vien cua chinh
        lop nay, nen thu tu huy la: cac con -> glassLook -> ... Go bang tay o
        day cho chac, khong phu thuoc thu tu khai bao.  */
    ~TonePanel() override
    {
        /* V6.5 SAFETY: dung nguon callback truoc khi cac control con bi huy.
           SafePointer trong cac callback da xep hang se tu thanh nullptr. */
        ++detectRequestSerial;
        watcher.onTick = {};
        watcher.onNewVideo = {};
        mixer.sfx().stopAll();
        laughWindow.reset();
        songLibraryWindow.reset();
        quickWindow.reset();
        setLookAndFeel (nullptr);
    }

    void lookAndFeelChanged() override
    {
        // V6.1.3: mau duoc set truc tiep phai nap lai khi doi theme luc dang mo.
        targetCaption.setColour (juce::Label::textColourId, Col::textDim);
        toneCaption.setColour (juce::Label::textColourId, Col::amber);
        statusLabel.setColour (juce::Label::textColourId, Col::textDim);
        resultLabel.setColour (juce::Label::textColourId, Col::text);
        timelineLabel.setColour (juce::Label::textColourId, Col::accent);
        urlBox.setTextToShowWhenEmpty (livent::vn ("Dán link YouTube vào đây..."), Col::textDim);

        // 12o: kieu rack giu mau chu / LCD cua kieu, khong bi theme ghi de
        const bool rackOn = livent::rack::active();
        for (auto* l : { &tuneSpeedCaption, &flexTuneCaption, &musicVolumeCaption, &micVolumeCaption,
                         &reverbLongCaption, &reverbShortCaption, &delayCaption })
            l->setColour (juce::Label::textColourId, rackOn ? livent::rack::textOnPlate() : Col::textDim);

        for (auto* k : { (juce::Slider*) &tuneSpeedKnob, (juce::Slider*) &flexTuneKnob,
                         (juce::Slider*) &musicVolumeKnob, (juce::Slider*) &micVolumeKnob,
                         (juce::Slider*) &reverbLongKnob, (juce::Slider*) &reverbShortKnob,
                         (juce::Slider*) &delayKnob })
        {
            k->setColour (juce::Slider::textBoxTextColourId, rackOn ? livent::rack::valueText() : Col::text);
            k->setColour (juce::Slider::textBoxBackgroundColourId, rackOn ? livent::rack::valueBoxBg() : Col::bg);
        }
        if (rackOn) toneValueLabel.setColour (juce::Label::textColourId, livent::rack::lcdText());

        detectButton.setColour (juce::TextButton::buttonColourId, Col::accent.darker (0.18f));

        // V6.5.3: +/- Tone nhac bam theo theme, khong giu mau nau cua theme cu.
        for (auto* b : { &toneMinusButton, &tonePlusButton })
        {
            b->setColour (juce::TextButton::buttonColourId, Col::offButton);
            b->setColour (juce::TextButton::textColourOffId, Col::text);
        }

        updateToneModeButton();
        repaint();
    }


    //=========================================================================
    // V6.5.0 - BO CUC DOC
    //
    // Cot trai la cac thao tac live: Dang phat -> Tone bai/Tone nhac ->
    // nut bat/tat hieu ung. Khong co "Mix nhanh": cac muc volume/vang/tune
    // da co 7 num dieu khien truc tiep.
    //
    // Khi mo 7 num, chung xuat hien trong MOT PANE BEN PHAI. Nhu vay cua so
    // dọc van gon khi thu gon va khong bi dai them xuong duoi khi can chinh.
    void resizedVertical()
    {
        /*  V0.6.7.9b: BO CUC DOC THEO Y ANH TINH.

              (thanh tren MainComponent)  Logo + ten
                                          Thu am | Cuoi ...
              [Tone nhac  - 0.0 +        ]
              [Tone bai   - C Major + M/m]
              [Tune  | Nhac  | Mic   ]
              [Vang  | Lofi  | Remix1]     3 nut moi hang
              [Remix2| Em be | ...   ]
              [Luu bai | Danh sach   ]     (mau B)
                                       >  mui ten o mep phai: 6 num xo
                                          sang PHAI (Delay an o che do doc),
                                          tieng cuoi cung mo canh ben.  */
        captions.clear();
        separators.clear();
        secTop = {};
        secChips = {};
        secKnobs = {};
        toneValueBox = {};
        toneCaption.setBounds ({});

        auto outer = getLocalBounds().reduced (outerPadX, outerPadY);
        auto main  = outer;

        auto addCaption = [this] (juce::Rectangle<int> area, const juce::String& text)
        {
            captions.add ({ area, text });
        };

        //-------------------------------------------------------------------- A: Dang phat + Tone nhac + Tone bai
        if (songRowHidden)
        {
            // Khoi nay dang nam duoi cua so YouTube: DAW doc gon lai.
            secTop = {};
            presetStrip.setBounds (main.removeFromTop (28)); main.removeFromTop (8);
            for (auto* c : { (juce::Component*) &nowPlaying, (juce::Component*) &nowPlayingClockLabel,
                             (juce::Component*) &keyMinusButton, (juce::Component*) &keyDisplayButton,
                             (juce::Component*) &keyPlusButton, (juce::Component*) &scaleToggleButton,
                             (juce::Component*) &toneMinusButton, (juce::Component*) &toneValueLabel,
                             (juce::Component*) &tonePlusButton, (juce::Component*) &toneVstPowerButton,
                             (juce::Component*) &beatButton, (juce::Component*) &presetButton })
                c->setBounds ({});
        }
        else
        {
        secTop = main.removeFromTop (verticalSecTopH());
        main.removeFromTop (secGap);
        {
            auto r = secTop.reduced (secPadX, secPadY);

            // 15/10: o "Dang phat" kieu the: gio, ten bai + o tong, ca si / thong bao, thanh tien trinh.
            juce::ignoreUnused (addCaption);
            nowPlayingClockLabel.setBounds ({});
            {
                presetButton.setBounds ({});
                nowPlaying.setCardMode (true);
                nowPlaying.setBounds (r.removeFromTop (NowPlayingStrip::cardHeight));
                r.removeFromTop (8);
                presetStrip.setBounds (r.removeFromTop (28));
            }
            r.removeFromTop (6);

            constexpr int btnW = 30;

            // Tone nhac:  [-] [ 0.0 ] [+]   (khong can chu, nhin la biet)
            auto nhac = r.removeFromTop (vRowH);
            toneMinusButton.setBounds (nhac.removeFromLeft (btnW));    nhac.removeFromLeft (4);
            if (beatAsText()) { placeMusicPower (nhac.removeFromRight (46));  nhac.removeFromRight (4); }   // thang cot M/m
            else              placeMusicPower ({});   // 15/10: bo nut nguon -> o 0.0 dai ra
            tonePlusButton.setBounds (nhac.removeFromRight (btnW));    nhac.removeFromRight (4);
            toneValueBox = nhac;
            toneValueLabel.setBounds (toneValueBox);

            r.removeFromTop (6);

            // Tone bai:  [-] [C Major] [+] [M/m]
            auto bai = r.removeFromTop (vRowH);
            keyMinusButton.setBounds (bai.removeFromLeft (btnW));   bai.removeFromLeft (4);
            scaleToggleButton.setBounds (bai.removeFromRight (46)); bai.removeFromRight (4);
            keyPlusButton.setBounds (bai.removeFromRight (btnW));   bai.removeFromRight (4);
            keyDisplayButton.setBounds (bai);
        }
        }

        //-------------------------------------------------------------------- B: luoi nut 3 cot
        const int rows = verticalGridRows();
        secChips = main.removeFromTop (verticalSecGridH());
        main.removeFromTop (secGap);
        {
            auto r = secChips.reduced (secPadX, secPadY);

            juce::Array<juce::TextButton*> grid { &tuneButton, &nhacButton, &micButton,
                                                  &vangButton, &lofiButton, &remix1Button,
                                                  &remix2Button, &babyButton };
            grid.add (&harmonyButton);   // V0.6.7.9c: doc luon co Be, lap o trong hang 3

            // 30/09 (khach): Vang Nhac Mic / Tune Lofi Remix / Be <Remix 2> Em be
            if (compactVertical())
                grid = { &vangButton, &nhacButton, &micButton,
                         &tuneButton, &lofiButton, &remix1Button,
                         &harmonyButton, &remix2Button, &babyButton };

            saveSongButton.setButtonText (livent::vn ("Lưu bài"));
            songListButton.setButtonText (livent::vn ("Danh sách"));

            saveSongButton.setBounds ({});
            songListButton.setBounds ({});

            const int cellW = (r.getWidth() - vChipGap * 2) / 3;
            const int gridRows = (grid.size() + 2) / 3;

            for (int row = 0; row < gridRows; ++row)
            {
                auto rr = r.removeFromTop (vRowH);
                if (row < rows - 1)
                    r.removeFromTop (vChipGap);

                for (int col = 0; col < 3; ++col)
                {
                    const int i = row * 3 + col;
                    if (i >= grid.size())
                        break;
                    grid[i]->setBounds (col == 2 ? rr : rr.removeFromLeft (cellW));
                    if (col < 2)
                        rr.removeFromLeft (vChipGap);
                }
            }

        }

        //-------------------------------------------------------------------- 6 num gan co dinh (Flex tune an, 30/09)
        nhacMeter.setBounds ({});
        micMeter.setBounds ({});
        knobFoldButton.setBounds ({});
        flexTuneCaption.setBounds ({});
        flexTuneKnob.setBounds ({});
        flexMeter.setBounds ({});

        secKnobs = main.removeFromTop (verticalSecKnobsH());
        if (noVerticalKnobs())
        {
            // 30/09: ban khach khong co num xoay o giao dien Doc.
            for (auto* c : { (juce::Component*) &musicVolumeKnob, (juce::Component*) &micVolumeKnob,
                             (juce::Component*) &tuneSpeedKnob, (juce::Component*) &reverbLongKnob,
                             (juce::Component*) &reverbShortKnob, (juce::Component*) &delayKnob,
                             (juce::Component*) &musicVolumeCaption, (juce::Component*) &micVolumeCaption,
                             (juce::Component*) &tuneSpeedCaption, (juce::Component*) &reverbLongCaption,
                             (juce::Component*) &reverbShortCaption, (juce::Component*) &delayCaption })
                c->setBounds ({});
            for (auto* m : knobMeters())
                m->setBounds ({});
            secKnobs = {};
        }
        else
        {
            auto r = secKnobs.reduced (secPadX - 4, secPadY);

            juce::Slider* knobs[] = { &musicVolumeKnob, &micVolumeKnob, &tuneSpeedKnob,
                                      &reverbLongKnob, &reverbShortKnob, &delayKnob };
            juce::Label* caps[]   = { &musicVolumeCaption, &micVolumeCaption, &tuneSpeedCaption,
                                      &reverbLongCaption, &reverbShortCaption, &delayCaption };
            KnobMeter* meters[]   = { &musicKnobMeter, &micKnobMeter, &tuneMeter,
                                      &reverbLongMeter, &reverbShortMeter, &delayMeter };

            constexpr int cols = 3;
            constexpr int gapX = 4;
            const int cellW = (r.getWidth() - gapX * (cols - 1)) / cols;

            for (int i = 0; i < 6; ++i)
            {
                const int row = i / cols, col = i % cols;
                auto cell = juce::Rectangle<int> (r.getX() + col * (cellW + gapX),
                                                  r.getY() + row * (vKnobCellH + vKnobGapY),
                                                  cellW, vKnobCellH);
                auto knobArea = cell.withTrimmedRight (meterW + 2);
                caps[i]->setBounds (knobArea.removeFromTop (capH));
                knobArea.removeFromTop (1);
                knobs[i]->setBounds (knobArea.withHeight (knobH + valueH));
                meters[i]->setBounds (cell.getRight() - meterW, knobArea.getY() + 2, meterW, knobH - 4);
            }
        }

        // Widget legacy khong chiem dien tich.
        header.setBounds ({});
        targetCaption.setBounds ({}); targetBox.setBounds ({});
        toneModeButton.setBounds ({});
        resultLabel.setBounds ({}); statusLabel.setBounds ({});
        timelineLabel.setBounds ({}); clock.setBounds ({});
        recButton.setBounds ({});
        // (Luu bai / Danh sach da duoc dat trong luoi nut o tren)

        repaint();
        main.removeFromTop (8);
        customButtons.setBounds (main.removeFromTop (customButtons.wantedHeight()));
    }

    /*  ==========  V6.0: BO CUC MOI (mockup da chot)  ==========

        Khoi 1: Thu am | Dang phat .......... | Tone bai | Tone nhac
        Khoi 2: Co ban [Tune Nhac Mic Vang] | Hieu ung [Be Lofi Remix1 Remix2 Em be]
        Khoi 3: Nhac Mic | Vang dai Vang ngan Delay | Toc do tune Flex tune
                (7 num bang nhau, moi num co meter mong ben phai)

        Chieu cao co dinh = v6PanelHeight - getWantedHeight() va resized()
        dung chung mot bo so, khong lech nhau.  */
    void resized() override
    {
        customButtons.setVisible (verticalLayout && ! compactMode);
        if (! verticalLayout || compactMode) customButtons.setBounds ({});
        presetStrip.setBounds ({});   // 07/10: chi bo cuc ngang dung dai che do
        if (compactMode)
        {
            resizedCompact();
            return;
        }

        if (verticalLayout)
        {
            resizedVertical();
            placeChipMeters();   // V0.6.7.9e
            return;
        }

        captions.clear();
        separators.clear();
        secKnobs = {};

        auto outer = getLocalBounds().reduced (outerPadX, outerPadY);

        // V6.3.5: luc thu gon hang 7 num, hai meter tong van con o hai mep
        // de dang hat van biet NHAC/MIC co tin hieu ma khong can mo F2.
        // V0.6.7.9e: bo 2 cot song NHAC/MIC - song da nam ngay tren tung nut.
        const bool showCompactMeters = false;
        juce::ignoreUnused (compactMetersVisible);
        if (showCompactMeters)
        {
            constexpr int compactMeterW = 42;
            constexpr int compactMeterGap = 8;
            auto leftMeter = outer.removeFromLeft (compactMeterW);
            outer.removeFromLeft (compactMeterGap);
            auto rightMeter = outer.removeFromRight (compactMeterW);
            outer.removeFromRight (compactMeterGap);
            nhacMeter.setBounds (leftMeter);
            micMeter.setBounds (rightMeter);
        }
        else
        {
            nhacMeter.setBounds ({});
            micMeter.setBounds ({});
        }
        toneCaption.setBounds ({});

        auto addCaption = [this] (juce::Rectangle<int> capRow, juce::Rectangle<int> cell, const juce::String& t)
        {
            captions.add ({ { cell.getX(), capRow.getY(), cell.getWidth(), capRow.getHeight() }, t });
        };
        juce::ignoreUnused (addCaption);   // V0.6.7.9e: ngang khong con chu nhom

        auto addSeparator = [this] (juce::Rectangle<int> gapArea, juce::Rectangle<int> section)
        {
            separators.add ({ gapArea.getCentreX(), section.getY() + secPadY,
                              1, section.getHeight() - secPadY * 2 });
        };

        //---------------------------------------------------------------- KHOI 1
        if (songRowHidden)
        {
            // Hang nay dang nam duoi cua so YouTube: DAW gon lai mot hang.
            secTop = {};
            for (auto* c : { (juce::Component*) &nowPlaying, (juce::Component*) &nowPlayingClockLabel,
                             (juce::Component*) &keyMinusButton, (juce::Component*) &keyDisplayButton,
                             (juce::Component*) &keyPlusButton, (juce::Component*) &scaleToggleButton,
                             (juce::Component*) &toneMinusButton, (juce::Component*) &toneValueLabel,
                             (juce::Component*) &tonePlusButton, (juce::Component*) &toneVstPowerButton,
                             (juce::Component*) &beatButton, (juce::Component*) &presetButton,
                             (juce::Component*) &recButton, (juce::Component*) &saveSongButton,
                             (juce::Component*) &songListButton })
                c->setBounds ({});
            toneValueBox = {};
        }
        else
        {
        /*  V0.6.7.9d: bo chu "Tone bai / Tone nhac" -> khoi 1 KHONG con hang chu,
            thap hon 20 px. Ten bai hep lai, nhuong cho nut nguon VST so 1 track
            NHAC canh Tone nhac (giong bo cuc doc).
              [ Ten bai ......... 00:00 ] | [-][C Major][+][M/m] | [-][0.0][+][⏻]  */
        secTop = outer.removeFromTop (secPadY * 2 + ctlH);
        outer.removeFromTop (secGap);
        {
            auto row = secTop.reduced (secPadX, secPadY);

            const bool roomy     = row.getWidth() >= 560;          // khi 2 cot meter an
            const int  keyW      = roomy ? 80 : 64;
            const int  valueW    = roomy ? 46 : 40;
            // 15/10: bo nut nguon (tu dong roi) -> o the loai keo gian het cho trong.
            const int  powerW    = beatAsText() ? (roomy ? 56 : 48) : 0;
            const int  mmW       = roomy ? 40 : 36;
            const int  sepSmall  = 13;
            const int  toneBaiW  = ctlH + 4 + keyW + 4 + ctlH + 4 + mmW;
            const int  toneNhacW = ctlH + 4 + valueW + 4 + ctlH + (powerW > 0 ? 4 + powerW : 0);

            recButton.setBounds ({});

            auto nhacCell = row.removeFromRight (toneNhacW);
            addSeparator (row.removeFromRight (sepSmall), secTop);
            auto baiCell  = row.removeFromRight (toneBaiW);
            addSeparator (row.removeFromRight (sepSmall), secTop);

            /*  07/10 (mau C + P1): ten bai + gio da xuong thanh trang thai
                (MainComponent). Nut Preset thay bang dai 4 che do ghi san ten. */
            presetButton.setBounds ({});
            nowPlaying.setCardMode (false);
            nowPlaying.setBounds ({});
            nowPlayingClockLabel.setBounds ({});
            {
                const int w = row.getWidth();   // 15/10: keo gian het hang (truoc: vua chu)
                presetStrip.setBounds (row.removeFromLeft (w).withSizeKeepingCentre (w, juce::jmin (26, row.getHeight())));
            }

            keyMinusButton   .setBounds (baiCell.removeFromLeft (ctlH));  baiCell.removeFromLeft (4);
            keyDisplayButton .setBounds (baiCell.removeFromLeft (keyW));  baiCell.removeFromLeft (4);
            keyPlusButton    .setBounds (baiCell.removeFromLeft (ctlH));  baiCell.removeFromLeft (4);
            scaleToggleButton.setBounds (baiCell);

            toneMinusButton.setBounds (nhacCell.removeFromLeft (ctlH));   nhacCell.removeFromLeft (4);
            toneValueBox = nhacCell.removeFromLeft (valueW);              nhacCell.removeFromLeft (4);
            toneValueLabel.setBounds (toneValueBox);
            tonePlusButton .setBounds (nhacCell.removeFromLeft (ctlH));
            if (beatAsText()) { nhacCell.removeFromLeft (4); placeMusicPower (nhacCell); }
            else              placeMusicPower ({});

            saveSongButton.setBounds ({});
            songListButton.setBounds ({});
        }
        }

        //---------------------------------------------------------------- KHOI 2
        secChips = outer.removeFromTop (secPadY * 2 + ctlH);   // V0.6.7.9e: bo chu Co ban / Hieu ung
        {
            auto r = secChips.reduced (secPadX, secPadY);

            juce::Array<juce::TextButton*> basic = livent::branding::vangFirst
                ? juce::Array<juce::TextButton*> { &vangButton, &tuneButton, &nhacButton, &micButton }
                : juce::Array<juce::TextButton*> { &tuneButton, &nhacButton, &micButton, &vangButton };
            juce::Array<juce::TextButton*> fx;

            if (harmonyButtonAllowed) fx.add (&harmonyButton);
            else                      harmonyButton.setBounds ({});

            fx.addArray (juce::Array<juce::TextButton*> { &lofiButton, &remix1Button, &remix2Button, &babyButton });

            const int nb = basic.size(), nf = fx.size();
            const int avail = r.getWidth() - sepW - chipGap * ((nb - 1) + (nf - 1));
            const int each  = juce::jmax (30, avail / (nb + nf));

            auto basicCell = r.removeFromLeft (each * nb + chipGap * (nb - 1));
            addSeparator (r.removeFromLeft (sepW), secChips);
            auto fxCell = r;



            auto layoutRow = [each] (juce::Rectangle<int> cell, juce::Array<juce::TextButton*>& list)
            {
                for (int i = 0; i < list.size(); ++i)
                {
                    const bool last = (i == list.size() - 1);
                    list[i]->setBounds (cell.removeFromLeft (last ? cell.getWidth() : each));
                    if (! last)
                        cell.removeFromLeft (chipGap);
                }
            };

            layoutRow (basicCell, basic);
            layoutRow (fxCell, fx);
        }

        //---------------------------------------------------------------- MUI TEN THU / MO HANG NUM
        {
            if (foldOnStatusBar())
            {
                // Mui ten nam tren thanh trang thai (MainComponent) -> khong ton hang.
                knobFoldButton.setBounds ({});
                if (knobsExpanded)
                    outer.removeFromTop (secGap);
            }
            auto foldRow = outer.removeFromTop (knobFoldRowH);
            const int bw = 34;
            const int bh = 14;
            knobFoldButton.setBounds (foldRow.getCentreX() - bw / 2,
                                      foldRow.getCentreY() - bh / 2, bw, bh);
        }

        //---------------------------------------------------------------- KHOI 3
        if (knobsExpanded)
        {
            secKnobs = outer.removeFromTop (sectionHeight (knobH + valueH));
            auto r = secKnobs.reduced (secPadX, secPadY);
            auto capRow = r.removeFromTop (capH);
            r.removeFromTop (capGap);

            juce::Slider* knobs[] = { &musicVolumeKnob, &micVolumeKnob,
                                      &reverbLongKnob, &reverbShortKnob, &delayKnob,
                                      &tuneSpeedKnob, &flexTuneKnob };
            juce::Label* caps[]   = { &musicVolumeCaption, &micVolumeCaption,
                                      &reverbLongCaption, &reverbShortCaption, &delayCaption,
                                      &tuneSpeedCaption, &flexTuneCaption };
            auto meters = knobMeters();

            //  Nhom: [0,1] | [2,3,4] | [5,6]  -> 4 khe trong nhom + 2 vach
            const int unitW = juce::jmax (44, (r.getWidth() - 2 * sepW - 4 * unitGap) / 7);
            const int groupEnd[] = { 1, 4, 6 };
            int x = r.getX();

            for (int i = 0; i < 7; ++i)
            {
                const auto unit = juce::Rectangle<int> (x, r.getY(), unitW, r.getHeight());
                auto knobArea   = unit.withTrimmedRight (meterW + 4);

                caps[i]->setBounds (knobArea.getX(), capRow.getY(), knobArea.getWidth(), capH);
                knobs[i]->setBounds (knobArea.withHeight (knobH + valueH));
                meters[(size_t) i]->setBounds (unit.getRight() - meterW, unit.getY() + 2, meterW, knobH - 4);

                x += unitW;

                const bool endOfGroup = (i == groupEnd[0] || i == groupEnd[1]);
                if (endOfGroup)
                {
                    addSeparator ({ x, r.getY(), sepW, r.getHeight() }, secKnobs);
                    x += sepW;
                }
                else if (i < 6)
                {
                    x += unitGap;
                }
            }
        }

        // Cac widget cu van song de giu logic/project compatibility, nhung
        // khong chiem dien tich tren mat chinh.
        header.setBounds ({});
        targetCaption.setBounds ({}); targetBox.setBounds ({});
        toneModeButton.setBounds ({});
        resultLabel.setBounds ({}); statusLabel.setBounds ({});
        timelineLabel.setBounds ({}); clock.setBounds ({});

        chipBarSpill = 4;
        placeChipMeters();   // V0.6.7.9e: song nam tren nut
        chipBarSpill = 0;
        repaint();
    }

private:
    static juce::File compactMetersPreferenceFile()
    {
        // V0.6.7.9f: file MOI cho "song tren nut". File cu compact-meters.txt
        // (2 cot NHAC/MIC) co the dang la "0" tren may anh -> lam song tren nut
        // bi an ngay tu dau. Doi ten de moi may deu BAT san.
        return PluginChain::getSettingsFolder().getChildFile ("chip-meters.txt");
    }

    static bool loadCompactMetersPreference()
    {
        const auto f = compactMetersPreferenceFile();
        // May moi: BAT san, vi dung luc thu gon de biet NHAC/MIC co song.
        return ! f.existsAsFile() || f.loadFileAsString().trim() != "0";
    }

    static void saveCompactMetersPreference (bool on)
    {
        compactMetersPreferenceFile().replaceWithText (on ? "1" : "0");
    }

    void saveCompactMetersPreference() const
    {
        saveCompactMetersPreference (compactMetersVisible);
    }

    static juce::File songAutoSavePreferenceFile()
    {
        return PluginChain::getSettingsFolder().getChildFile ("song-autosave.txt");
    }

    static bool loadSongAutoSavePreference()
    {
        auto f = songAutoSavePreferenceFile();
        return ! f.existsAsFile() || f.loadFileAsString().trim() != "0";
    }

    void saveSongAutoSavePreference() const
    {
        songAutoSavePreferenceFile().replaceWithText (songAutoSaveEnabled ? "1" : "0");
    }

    void showSongAutoSaveMenu()
    {
        juce::PopupMenu m;
        m.addItem (1, livent::vn ("BẬT tự động lưu bài"), true, songAutoSaveEnabled);
        m.addItem (2, livent::vn ("TẮT tự động lưu bài"), true, ! songAutoSaveEnabled);
        juce::Component::SafePointer<TonePanel> safe (this);
        m.showMenuAsync (livent::menuAtPointer (this), [safe] (int r)
        {
            if (safe == nullptr || (r != 1 && r != 2)) return;
            safe->songAutoSaveEnabled = (r == 1);
            safe->saveSongAutoSavePreference();
            safe->saveSongButton.setTooltip (safe->songAutoSaveEnabled
                ? livent::vn ("Lưu bài thủ công. Chuột phải: tự động lưu đang BẬT")
                : livent::vn ("Lưu bài thủ công. Chuột phải: tự động lưu đang TẮT"));
        });
    }

    //=========================================================================
    //  V4.5: GIU / TU VE 0 KHI MO BAI MOI
    //=========================================================================
    static juce::File toneResetPreferenceFile()
    {
        return PluginChain::getSettingsFolder().getChildFile ("tone-reset-new-song.txt");
    }

    static bool loadResetTonePreference()
    {
        const auto f = toneResetPreferenceFile();

        /*  May moi mac dinh TỰ VỀ 0 - an toan hon khi hat live: khong vo tinh
            mang -1 / +1 nua cung cua bai truoc sang bai sau. Ghi "0" de chon
            GIỮ; moi gia tri khac (hoac chua co file) = TỰ VỀ 0. */
        return ! f.existsAsFile() || f.loadFileAsString().trim() != "0";
    }

    void saveResetTonePreference() const
    {
        toneResetPreferenceFile().replaceWithText (resetToneOnNewSong ? "1" : "0");
    }

    void updateToneModeButton()
    {
        toneModeButton.setButtonText (resetToneOnNewSong
                                      ? livent::vn ("BÀI MỚI: 0")
                                      : livent::vn ("BÀI MỚI: GIỮ"));
        toneModeButton.setColour (juce::TextButton::buttonColourId,
                                  resetToneOnNewSong ? Col::green.darker (0.55f)
                                                     : Col::raised);
    }

    void prepareForNewSong()
    {
        clearSongAutomation(); cancelDetectedFlash();
        stopBuiltinFallback();   // 12s: bai moi -> T-AutoKey ngu, gui AI truoc
        if(onSongChanged)onSongChanged();
        ++detectRequestSerial;client.cancel();
        ++toneWriteSerial;pluginToneWriteUntilMs=0;pluginToneFollowing=false;
        mirroredKey.clear();mirroredScale.clear();
        keyShowingDetecting = false;
        keyLanding = false;
        keyFlashUntilMs = 0;
        keyRollTimer.stopTimer();
        keyDisplayButton.setToggleState (false, juce::dontSendNotification);
        detectButton.setButtonText (livent::vn ("ĐO TONE"));
        failureNoticeUntilMs=0;
        /* Key/Scale cu KHONG duoc phep song sot sang bai moi. Gia tri +/- co
           giu hay khong la do nut che do ben tren quyet dinh. */
        baseKey.clear();
        baseScale.clear();
        fallbackClockVideoId.clear();
        fallbackClockSeconds = 0.0;
        fallbackClockLastMs = 0.0;
        autoKeyPlaybackClock.reset();
        resetManualKeyScaleAdjustments();
        lastToneFailure.clear();
        refreshKeyDisplay();

        if (! resetToneOnNewSong)
            return;

        toneOffsetTong = 0.0f;
        updateToneLabel();

        /*  Chi tra num pitch tren track NHAC ve 0. KHONG goi setToneOffset()
            vi ham do con ban lai Key/Scale - luc nay Key/Scale bai moi chua
            do xong, ban Key cu sang Auto-Tune se sai. */
        if (auto* nhac = nhacTrack())
        {
            juce::String ignoredName, ignoredWhy;
            TonePush::setSemitonesOnTrack (*nhac, 0, &ignoredName, &ignoredWhy);
        }

        if (onLiveStateChanged)
            onLiveStateChanged();
    }

    //=========================================================================
    //  MOC 37: O DOI TONG NHAC
    //=========================================================================
    /** Doi tong lech may nua cung. 1 tong = 2 nua cung. */
    int semitoneShift() const   { return (int) std::lround (toneOffsetTong * 2.0f); }

    // V5.7: bang chinh va dock Tieng Cuoi tu tinh chieu cao; bo keo tay/splitter.
    void mouseDrag (const juce::MouseEvent&) override {}
    void mouseUp (const juce::MouseEvent&) override   { resizingPanel = false; }
    void mouseMove (const juce::MouseEvent&) override { setMouseCursor (juce::MouseCursor::NormalCursor); }

    void mouseDoubleClick (const juce::MouseEvent& e) override
    {
        if (e.eventComponent == &toneValueLabel)
            setToneOffset (0.0f);
    }

    void mouseDown (const juce::MouseEvent& e) override
    {
        if (! e.mods.isPopupMenu()) return;
        if (e.eventComponent == &keyDisplayButton || e.eventComponent == &keyModeTag)
        {
            keyRightClickMs = juce::Time::getMillisecondCounter();
            showDetectModeMenu();
            return;
        }
        if (e.eventComponent == &saveSongButton) { showSongAutoSaveMenu(); return; }
        if (e.eventComponent == &toneValueLabel) showNhacParameters();
    }

    void openLaughPopup (juce::Rectangle<int> anchorScreen)
    {
        laughBoard.rescanIfChanged();

        if (anchorScreen.isEmpty())
        {
            // Fallback cho code cu/goi tu noi khac: neo vao mep phai tren cua
            // Fallback: lấy bounds của cửa sổ LiveNT chứa TonePanel.
            if (auto* top = getTopLevelComponent())
                anchorScreen = top->getScreenBounds();
            else
                anchorScreen = getScreenBounds();
        }

        laughAnchorScreen = anchorScreen;

        juce::Component::SafePointer<TonePanel> safe (this);
        laughWindow = std::make_unique<LaughWindow> (laughBoard, [safe]
        {
            // Khong delete LaughWindow ngay ben trong callback cua chinh no.
            // Day sang message queue mot nhip de dong cua so an toan.
            juce::MessageManager::callAsync ([safe]
            {
                if (safe != nullptr)
                    safe->closeLaughPopup();
            });
        });

        positionLaughPopup (anchorScreen);
        laughWindow->setVisible (true);
        laughWindow->toFront (false);
        if (onLaughPopupChanged) onLaughPopupChanged (true);
    }

    void closeLaughPopup()
    {
        if (laughWindow == nullptr)
            return;

        mixer.sfx().stopAll();
        laughWindow.reset();
        laughAnchorScreen = {};
        if (onLaughPopupChanged) onLaughPopupChanged (false);
    }

    void positionLaughPopup (juce::Rectangle<int> anchorScreen)
    {
        if (laughWindow == nullptr)
            return;

        if (anchorScreen.isEmpty())
            anchorScreen = laughAnchorScreen;

        auto& displays = juce::Desktop::getInstance().getDisplays();
        auto* display = displays.getDisplayForRect (anchorScreen);
        if (display == nullptr)
            display = displays.getPrimaryDisplay();

        const auto work = display != nullptr ? display->userArea
                                             : juce::Rectangle<int> (0, 0, 1280, 720);

        constexpr int edgeMargin = 6;
        constexpr int anchorGap  = 4;

        const int maxW = juce::jmax (1, work.getWidth() - edgeMargin * 2);

        if (verticalLayout)
        {
            // V0.6.7.9d: bo cuc DOC -> bang tieng cuoi dang LUOI NGANG (nhu
            // che do ngang) nhung dat BEN TRAI / PHAI cua so, ben nao con cho.
            const int roomRight = juce::jmax (0, work.getRight() - anchorScreen.getRight()
                                                  - anchorGap - edgeMargin);
            const int roomLeft  = juce::jmax (0, anchorScreen.getX() - work.getX()
                                                  - anchorGap - edgeMargin);
            const bool openRight = roomRight >= roomLeft;
            const int room = juce::jmax (260, openRight ? roomRight : roomLeft);

            const int popupW = juce::jmin (maxW, juce::jmin (620, room));
            const int contentH = laughBoard.preferredHeightForWidth (popupW);
            const int popupH = juce::jmin (juce::jmax (1, work.getHeight() - edgeMargin * 2), contentH);

            int x = openRight ? anchorScreen.getRight() + anchorGap
                              : anchorScreen.getX() - anchorGap - popupW;
            const int minX = work.getX() + edgeMargin;
            const int maxX = juce::jmax (minX, work.getRight() - edgeMargin - popupW);
            x = juce::jlimit (minX, maxX, x);

            int y = anchorScreen.getY();
            const int minY = work.getY() + edgeMargin;
            const int maxY = juce::jmax (minY, work.getBottom() - edgeMargin - popupH);
            y = juce::jlimit (minY, maxY, y);

            laughWindow->setBoardWidth (popupW);
            laughWindow->setBounds (x, y, popupW, popupH);
            return;
        }

        // Chế độ ngang giữ đúng hành vi 0.6.4.9: popup rộng bằng DAW và
        // ưu tiên xổ phía trên/dưới.
        const int popupW = juce::jmax (1, juce::jmin (anchorScreen.getWidth(), maxW));

        const int contentH = laughBoard.preferredHeightForWidth (popupW);
        const int below = juce::jmax (0, work.getBottom() - anchorScreen.getBottom() - anchorGap - edgeMargin);
        const int above = juce::jmax (0, anchorScreen.getY() - work.getY() - anchorGap - edgeMargin);

        const bool openBelow = below >= contentH || (above < contentH && below >= above);
        const int available = openBelow ? below : above;
        const int popupH = juce::jmax (1, juce::jmin (contentH, juce::jmax (1, available)));

        int x = anchorScreen.getX();
        const int minX = work.getX() + edgeMargin;
        const int maxX = juce::jmax (minX, work.getRight() - edgeMargin - popupW);
        x = juce::jlimit (minX, maxX, x);

        int y = openBelow ? anchorScreen.getBottom() + anchorGap
                          : anchorScreen.getY() - anchorGap - popupH;
        const int minY = work.getY() + edgeMargin;
        const int maxY = juce::jmax (minY, work.getBottom() - edgeMargin - popupH);
        y = juce::jlimit (minY, maxY, y);

        laughWindow->setBoardWidth (popupW);
        laughWindow->setBounds (x, y, popupW, popupH);
    }

    /*  ==========  MOC 39: XEM NUM CUA TRACK NHAC  ==========

        Bang debug tham so cua track NHAC, mo bang chuot phai vao o doi tong.

        Vi sao can: khi bam +/- ma o Semitones khong nhuc nhich, chi co MOT
        cach biet chac chuyen gi dang xay ra -- nhin danh sach num that ma
        plugin bao ra, kem theo viec LiveNT dang CHON num nao. Bang nay tra
        loi ca hai cau do cung luc.  */
    void showNhacParameters()
    {
        auto* nhac = nhacTrack();

        if (nhac == nullptr)
        {
            livent::alert (livent::vn ("Không thấy track NHẠC"),
                           livent::vn ("Không tìm thấy track hệ thống có vai trò NHẠC. Tên track có thể đổi tự do."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        auto& chain = nhac->getInserts();

        if (chain.getNumUsedSlots() == 0)   // MOC 47: dem plugin THAT
        {
            livent::alert (livent::vn ("Track NHẠC chưa có plugin"),
                           livent::vn ("Hãy đặt plugin dịch giọng (vd SoundShifter) vào "
                           "chuỗi insert của track NHẠC trước."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        juce::String text;

        text << livent::vn ("Tông lệch đang đặt: ") << juce::String (toneOffsetTong, 1)
             << livent::vn (" tông  =  ") << semitoneShift() << livent::vn (" nửa cung\n\n");

        for (int i = 0; i < chain.getNumPlugins(); ++i)
        {
            auto* p = chain.getPlugin (i);

            if (p == nullptr)
                continue;

            juce::String chosen;
            auto* sp = TonePush::findSemitoneParameter (*p, &chosen);

            text << livent::vn ("===== Ô insert ") << (i + 1) << ": " << p->getName() << livent::vn (" =====\n");

            if (sp != nullptr)
                text << livent::vn (">>> LiveNT đang chọn num: \"") << chosen
                     << livent::vn ("\"  (hiện đang ở \"") << sp->getText (sp->getValue(), 32) << "\")\n\n";
            else
                text << livent::vn (">>> LiveNT KHÔNG chọn được num nào ở plugin này.\n\n");

            text << TonePush::listParameterNames (*p) << "\n\n";
        }

        juce::SystemClipboard::copyTextToClipboard (text);

        livent::alert (livent::vn ("Num trên track NHẠC"), text + livent::vn ("\n(Đã chép vào bộ nhớ tạm)"));
    }

    static int normaliseManualKeyShift (int semitones)
    {
        while (semitones >  6) semitones -= 12;
        while (semitones < -5) semitones += 12;
        return semitones;
    }

    int effectiveKeyShift() const noexcept
    {
        return semitoneShift() + manualKeyShiftSemitones;
    }

    juce::String effectiveScale() const
    {
        if(followsPluginTone() && mirroredScale.isNotEmpty())return mirroredScale;
        if (manualScaleOverride.isNotEmpty())
            return manualScaleOverride;

        if (baseScale.isNotEmpty() && ! baseScale.equalsIgnoreCase ("Chromatic"))
            return baseScale;

        return "Major";
    }

    /** 06/10: chu hien tren nut Key/Scale - Dan ca thi Scale luon "Dorian". */
    static juce::String displayScale (const juce::String& scale)
    {
        return TonePush::usesFolkScale() ? juce::String (TonePush::folkScaleName()) : scale;
    }

    juce::String effectiveKey() const
    {
        if(followsPluginTone() && mirroredKey.isNotEmpty())return mirroredKey;
        auto k = baseKey.isNotEmpty() ? baseKey : juce::String ("C");
        const int shift = effectiveKeyShift();
        if (shift != 0)
            if (auto shifted = TonePush::transposeKey (k, shift); shifted.isNotEmpty())
                k = shifted;
        return k;
    }

    void resetManualKeyScaleAdjustments()
    {
        manualKeyShiftSemitones = 0;
        manualScaleOverride.clear();
    }

    void refreshKeyDisplay()
    {
        if (keyShowingDetecting || keyLanding)
            return;   // dang quay so / dang dung lai -> ket thuc se ve dung Key/Scale

        if (skipNoticeUntilMs != 0)
        {
            if (juce::Time::getMillisecondCounter() < skipNoticeUntilMs)
            {
                keyDisplayButton.setButtonText (livent::vn ("Không dò"));
                return;
            }
            skipNoticeUntilMs = 0;
        }

        if(followsPluginTone() && (mirroredKey.isEmpty() || mirroredScale.isEmpty()))
            keyDisplayButton.setButtonText(livent::vn("Chưa đọc được Key/Scale"));
        else keyDisplayButton.setButtonText (effectiveKey() + " " + displayScale (effectiveScale()));
    }

    bool syncToneFromPlugin()
    {
        if(!followsPluginTone())return false;
        if(pluginToneWriteUntilMs!=0 && juce::Time::getMillisecondCounter()<pluginToneWriteUntilMs)return false;
        juce::String key,scale;
        if(!pluginToneReader.read(mixer,toneTarget(),key,scale))
        {
            mirroredKey.clear();mirroredScale.clear();baseKey.clear();baseScale.clear();
            refreshKeyDisplay();return false;
        }
        if(key==mirroredKey && scale==mirroredScale)return true;
        // 06/10: Dan ca - Auto-Key/khach doi tone trong plugin ra Scale khac
        // Dorian thi ghi lai Dorian, Key giu nguyen nhu plugin vua dat.
        const bool folkWrite=TonePush::usesFolkScale()
            && !scale.equalsIgnoreCase(TonePush::folkScaleName());
        if(folkWrite)folkSourceScale=scale;   // nho Scale goc de tra lai khi bo Dan ca
        mirroredKey=key;mirroredScale=scale;
        // Store the inverse of the music offset. Recall reapplies the saved
        // offset exactly once, while the on-screen text preserves the VST spelling.
        baseKey=TonePush::transposeKey(key,-semitoneShift());
        baseScale=scale;
        resetManualKeyScaleAdjustments();
        keyShowingDetecting=keyLanding=false;keyRollTimer.stopTimer();
        resultLabel.setText(key+"   "+scale,juce::dontSendNotification);
        refreshKeyDisplay();
        if(onLiveStateChanged)onLiveStateChanged();
        if(folkWrite)pushToPluginRaw(getSelectedTrackId(),key,scale);
        return true;
    }

    void refreshKeyDetectingState()
    {
        bool detecting = (!manualDetectMode && (watcher.isWaitingForNewVideo() || client.isBusy()))
                      || (builtinKeyWanted() && livent::builtinkey::Detector::get().isSearching());   // 12s
        const auto nowMs = juce::Time::getMillisecondCounter();

        if (detecting)
            lastDetectingMs = nowMs;
        else if (keyShowingDetecting && baseKey.isEmpty() && nowMs - lastDetectingMs < 800)
            detecting = true;   // tat thoang qua (doc file trung luc ghi): giu nguyen, khong nhay

        if (detecting)
        {
            // 02/10: dang do -> o Key nhay tone lien tuc kieu quay so.
            if (! keyShowingDetecting)
            {
                keyShowingDetecting = true;
                keyLanding = false;
                keyRollTimer.startTimer (900);
            }
        }
        else if (keyShowingDetecting)
        {
            keyShowingDetecting = false;
            keyDetectingPhase = 0;

            if (baseKey.isNotEmpty() && skipNoticeUntilMs == 0)
            {
                // Co ket qua: cham dan roi dung dung tone + chop sang.
                keyLanding = false;
                refreshKeyDisplay();

            }
            else
            {
                keyRollTimer.stopTimer();
                refreshKeyDisplay();
            }
        }
        else if (skipNoticeUntilMs != 0 && juce::Time::getMillisecondCounter() >= skipNoticeUntilMs)
        {
            refreshKeyDisplay();   // het 8 giay "Khong do" -> hien lai Key/Scale
        }
    }

    //==========================================================================
    //  02/10: LOI GIAI THICH CHO CHE DO HUONG DAN (nut "?")
    //==========================================================================
    void setupHelpTexts()
    {
        using livent::help::set;
        auto v = [] (const char* s) { return livent::vn (s); };
        const auto r1 = liveButtonName ("remix1");
        const auto r2 = liveButtonName ("remix2");

        set (presetButton, v ("Preset thể loại"),
             v ("Chọn nhanh bộ chỉnh sẵn: Bolero, Nhạc trẻ, Remix... Áp vào là đổi toàn bộ nút, núm và "
                "thông số VST (Auto-Tune, vang...). Lưu: mở Preset > \"Lưu vào preset đang chọn\" hoặc \"Lưu vào đây\". "
                "Phím tắt Ctrl+1 ... Ctrl+4. Không đổi tone nhạc và Key bài đang hát."));
        set (presetStrip, v ("Chế độ (preset)"),
             v ("Đa thể loại / Nhạc trẻ / Bolero / Dân ca. Chuột trái: dùng chế độ (đổi nút, núm, vang, VST). "
                "Chuột phải: Lưu thông số hiện tại vào chế độ đó, Đổi tên, Làm mặc định, Xuất / Nhập. "
                "Chế độ có chữ \"Dân ca\" gửi Scale Dorian. Phím tắt Ctrl+1 ... Ctrl+4."));
        set (nowPlaying, v ("Bài đang phát"),
             v ("Tên bài YouTube đang phát. Dò tone tự động dựa vào bài này (chế độ Dò AI)."));
        set (nowPlayingClockLabel, v ("Thời gian bài"), v ("Đang phát tới đâu / tổng thời lượng bài."));
        set (keyMinusButton, v ("Hạ Tone bài"), v ("Hạ Key bài nửa cung. Chỉ đổi Key gửi cho Auto-Tune, không đổi tông nhạc."));
        set (keyPlusButton,  v ("Nâng Tone bài"), v ("Nâng Key bài nửa cung. Chỉ đổi Key gửi cho Auto-Tune, không đổi tông nhạc."));
        set (keyDisplayButton, v ("Tone bài (Key / Scale)"),
             v ("Key bài đang dùng cho Auto-Tune. Lúc đang dò ô này nhảy liên tục, dò xong dừng đúng tone.\n"
                "• Chuột trái: chọn Key bằng tay.\n"
                "• Chuột phải: chọn cách dò - Dò AI (máy chủ dò; AI hỏng thì T-AutoKey có sẵn tự dò track NHẠC) "
                "hoặc Dò không AI (chỉ T-AutoKey, dò liên tục, nhạc im 5 giây = bài mới). Góc ô hiện AI / AK."));
        set (scaleToggleButton, v ("Thứ / Trưởng"), v ("Đổi Minor (thứ) / Major (trưởng), giữ nguyên nốt gốc."));
        set (toneMinusButton, v ("Hạ tone nhạc"), v ("Hạ tông bản nhạc nửa nấc (qua VST đổi tone ô 1 track NHẠC). Key Auto-Tune tự bù theo."));
        set (tonePlusButton,  v ("Nâng tone nhạc"), v ("Nâng tông bản nhạc nửa nấc. Key Auto-Tune tự bù theo."));
        set (toneValueLabel,  v ("Tone nhạc hiện tại"), v ("Đang lệch bao nhiêu nấc so với bản gốc. Bấm đúp để về 0."));
        set (toneVstPowerButton, v ("Nguồn đổi tone nhạc"), v ("Bật / tắt VST ô 1 track NHẠC (plugin đổi tone)."));
        set (beatButton, v ("Beat"), v ("Bật / tắt VST ô 1 track NHẠC (plugin đổi tone). Sáng màu = đang bật. Tự tắt khi tông = 0 cho đỡ CPU, tự bật khi bấm Tone + / −."));

        set (tuneButton, v ("Tune"), v ("Chuột trái: bật/tắt Tune. Chuột phải: mở VST Tune (mặc định ô 1 track MÍC; đổi được trong Cài đặt > Gán nút)."));
        set (nhacButton, v ("Nhạc"), v ("Chuột trái: bật / tắt tiếng nhạc ra loa.\nChuột phải: bảng âm lượng Nhạc + Míc (nút + / − mỗi lần 0,5 dB)."));
        set (micButton,  v ("Míc"),  v ("Chuột trái: bật / tắt tiếng míc ra loa.\nChuột phải: EQ Trầm / Ấm / Rõ lời / Sáng, Cắt ù và Giảm ồn. Comp và Auto-Tune chỉnh trong VST."));
        set (vangButton, v ("Vang"), v ("Chuột trái: bật / tắt toàn bộ vang + delay của míc. (Cài đặt > Tự động: Vang tự bật khi có nhạc.)\nChuột phải: bảng Vang dài / Vang ngắn / Delay (mỗi lần 0,5 dB)."));
        set (harmonyButton, liveButtonName ("harmony"), v ("Bật / tắt bè trong Auto-Tune (Trigger All) - không tắt plugin. Gán riêng Auto-Tune ở Cài đặt > Gán nút > Bè."));
        set (lofiButton, liveButtonName ("lofi"), v ("Bật / tắt hiệu ứng Lofi (VST ô ") + juce::String (livent::branding::fxSlotLofi) + v (" track MÍC)."));
        set (remix1Button, r1, v ("Bật / tắt hiệu ứng ") + r1 + v (" (VST ô ") + juce::String (livent::branding::fxSlotRemix1) + v (" track MÍC)."));
        set (remix2Button, r2, v ("Bật / tắt hiệu ứng ") + r2 + v (" (VST ô ") + juce::String (livent::branding::fxSlotRemix2) + v (" track MÍC)."));
        set (babyButton, liveButtonName ("baby"), v ("Bật / tắt giọng em bé (VST ô ") + juce::String (livent::branding::fxSlotBaby) + v (" track MÍC)."));
        set (saveSongButton, v ("Lưu bài"), v ("Lưu bài đang phát (link + tone) vào danh sách Bolero / Nhạc trẻ / Yêu thích..."));
        set (songListButton, v ("Danh sách"), v ("Mở danh sách bài đã lưu. Mở bài là phát luôn trong YouTube của DAW."));

        set (musicVolumeKnob, v ("Núm Nhạc"), v ("Âm lượng nhạc. Bấm đúp về mặc định. Chuột phải: nhập số."));
        set (micVolumeKnob,   v ("Núm Míc"),  v ("Âm lượng míc. Bấm đúp về mặc định. Chuột phải: nhập số."));
        set (reverbLongKnob,  v ("Núm Vang dài"),  v ("Mức gửi míc sang vang dài (vang hội trường). Chuột phải: nhập số."));
        set (reverbShortKnob, v ("Núm Vang ngắn"), v ("Mức gửi míc sang vang ngắn (vang phòng). Chuột phải: nhập số."));
        set (delayKnob,       v ("Núm Delay"),     v ("Mức gửi míc sang delay (tiếng lặp). Chuột phải: nhập số."));
        set (tuneSpeedKnob,   v ("Núm Tốc độ tune"), v ("Retune Speed trong Auto-Tune: nhỏ = kéo nốt nhanh (giọng robot), lớn = tự nhiên."));
        set (flexTuneKnob,    v ("Núm Flex tune"),   v ("Flex Tune trong Auto-Tune: càng lớn càng giữ luyến láy tự nhiên. Chuột phải: nhập số."));
        set (knobFoldButton,  v ("Thu / mở núm"), v ("Thu gọn hoặc mở hàng 7 núm chỉnh."));
        set (statusFold,      v ("Thu / mở núm"), v ("Thu gọn hoặc mở hàng 7 núm chỉnh."));
    }

    //==========================================================================
    //  02/10: O KEY "QUAY SO" + CHE DO DO AI / TAY
    //==========================================================================
    struct KeyRollTimer final : public juce::Timer
    {
        std::function<void()> tick;
        void timerCallback() override { if (tick) tick(); }
    };

    /** Chu nho "AI" / "TAY" o goc tren-phai o Key (khong nhan chuot). */
    struct KeyModeTag final : public juce::Component
    {
        KeyModeTag() { setInterceptsMouseClicks (false, false); }
        void setText (const juce::String& t) { text = t; repaint(); }
        void parentSizeChanged() override
        {
            if (auto* p = getParentComponent())
                setBounds (p->getWidth() - 24, 2, 21, 10);
        }
        void paint (juce::Graphics& g) override
        {
            g.setColour (Col::textDim.withAlpha (0.85f));
            g.setFont (juce::Font (juce::FontOptions (8.0f).withStyle ("Bold")));
            g.drawText (text, getLocalBounds(), juce::Justification::centredRight, false);
        }
        juce::String text;
    };

    static const juce::StringArray& rollKeys()
    {
        static const juce::StringArray k { "C Major", "A Minor", "G Major", "E Minor", "D Major", "B Minor",
                                           "A Major", "F# Minor", "E Major", "C# Minor", "B Major", "G# Minor",
                                           "F# Major", "D# Minor", "C# Major", "A# Minor", "G# Major", "F Minor",
                                           "D# Major", "C Minor", "A# Major", "G Minor", "F Major", "D Minor" };
        return k;
    }

    void showNextRollKey()
    {
        // nhay coc (5-11 o) cho nhin nhu quay ngau nhien, khong lap lai lien ke
        keyRollIdx = (keyRollIdx + 5 + juce::Random::getSystemRandom().nextInt (7)) % rollKeys().size();
        keyDisplayButton.setButtonText (rollKeys()[keyRollIdx]);
    }

    void flashDetectedTone()
    {
        autoVangKeyReady = true;   // 15/10: do xong Key/Scale bai nay -> Vang tu dong bat khi co nhac
        keyShowingDetecting = keyLanding = false;
        keyDisplayButton.setToggleState (false, juce::dontSendNotification);
        refreshKeyDisplay(); keyPulseStartMs = juce::Time::getMillisecondCounter();
        keyFlashUntilMs = keyPulseStartMs + 1680;
        keyDisplayButton.getProperties().set ("toneDetectedPulse", true);
        keyDisplayButton.repaint(); keyRollTimer.startTimer (70);
    }
    void cancelDetectedFlash()
    {
        keyFlashUntilMs = 0;
        keyDisplayButton.getProperties().set ("toneDetectedPulse", false); keyDisplayButton.repaint();
    }

    void tickKeyRoll()
    {
        const auto now = juce::Time::getMillisecondCounter();

        if (keyShowingDetecting)
        {
            showNextRollKey();
            return;
        }

        if (keyLanding)
        {
            const auto t = now - keyLandStartMs;
            constexpr juce::uint32 landMs = 900;
            if (t < landMs)
            {
                if (now >= keyNextStepMs)
                {
                    showNextRollKey();
                    keyNextStepMs = now + 60 + (juce::uint32) (t * 0.32f);   // cham dan
                }
                return;
            }

            // Dung dung tone + chop sang
            keyLanding = false;
            refreshKeyDisplay();
            keyDisplayButton.setToggleState (true, juce::dontSendNotification);
            keyFlashUntilMs = now + 450;
            return;
        }

        if (keyFlashUntilMs != 0)
        {
            const bool on = now < keyFlashUntilMs && ((now - keyPulseStartMs) / 280u) % 2u == 0;
            keyDisplayButton.getProperties().set ("toneDetectedPulse", on);
            keyDisplayButton.repaint();
            if (now >= keyFlashUntilMs) { keyFlashUntilMs = 0; keyRollTimer.stopTimer(); }
        }

    }

    static juce::File detectModePrefFile()
    {
        return PluginChain::getSettingsFolder().getChildFile ("key-detect-mode.txt");
    }

    static bool loadManualDetectPref()
    {
        return detectModePrefFile().loadFileAsString().trim().equalsIgnoreCase ("tay");   // 12s: "tay" = Do khong AI (moi he dieu hanh)
    }

    void setManualDetectMode (bool manual)
    {
        cancelDetectedFlash();
        manualDetectMode = manual;
        ++toneWriteSerial;pluginToneWriteUntilMs=0;
        pluginToneFollowing=false;mirroredKey.clear();mirroredScale.clear();
        detectModePrefFile().replaceWithText (manual ? "tay" : "ai");
        builtinFallbackActive = false;
        builtinKeyFirstForSong = true;
        if (manual) livent::builtinkey::Detector::get().wake();
        else        livent::builtinkey::Detector::get().sleep();
        updateKeyModeTag();

       #if JUCE_WINDOWS
        // AI can still be waiting for a server response when the user switches
        // modes. Bind the current link now; do not wait for a new-video event
        // to make the existing song's playback clock eligible.
        if (manual) bindManualClockToLink();
       #endif

        // Both modes watch song changes; only AI mode sends links to the VPS.
        autoButton.setToggleState (! manual, juce::dontSendNotification);
        toggleAutoWatch();

        ++detectRequestSerial;
        client.cancel();
        failureNoticeUntilMs = skipNoticeUntilMs = keyFlashUntilMs = 0;
        keyShowingDetecting = keyLanding = false;
        keyRollTimer.stopTimer();
        keyDisplayButton.setToggleState (false, juce::dontSendNotification);
        detectButton.setButtonText (livent::vn ("ĐO TONE"));
        lastToneFailure.clear();
        statusLabel.setText ({}, juce::dontSendNotification);
        refreshKeyDisplay();
        if (onManualDetectChanged) onManualDetectChanged (manual);
        if (onPanelStateChanged)
            onPanelStateChanged();
    }

    void showDetectModeMenu()
    {
        juce::PopupMenu m;
        m.addSectionHeader (livent::vn ("Cách dò tone bài"));
        m.addItem (1, livent::vn ("Dò AI  (máy chủ dò · AI hỏng thì T-AutoKey tự dò)"), true, ! manualDetectMode);
        m.addItem (2, livent::vn ("Dò không AI  (T-AutoKey dò trên track NHẠC, không qua máy chủ)"), true, manualDetectMode);
        juce::Component::SafePointer<TonePanel> safe (this);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&keyDisplayButton),
                         [safe] (int r)
                         {
                             if (safe == nullptr || r <= 0) return;
                             safe->setManualDetectMode (r == 2);
                         });
    }

    void nudgeKey (int semitones)
    {
        if (baseKey.isEmpty()) baseKey = "C";
        if (baseScale.isEmpty() || baseScale.equalsIgnoreCase ("Chromatic")) baseScale = "Major";

        /*  V6.1.3: KHONG sua baseKey nua. baseKey la tone thuc cua bai /
            timeline. Nut +/- chi tang offset thu cong. Vi vay khi BrowserWatcher
            tick hoac timeline doi tone, offset van duoc cong len tone moi thay
            vi bi keo ve tone goc nhu truoc. */
        manualKeyShiftSemitones = normaliseManualKeyShift (manualKeyShiftSemitones + semitones);

        sendShiftedKey();
        refreshKeyDisplay();
        if (onLiveStateChanged) onLiveStateChanged();
    }

    void showKeyMenu()
    {
        juce::PopupMenu menu;
        static const char* keys[] = { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" };
        const auto currentK = effectiveKey();
        const auto currentS = effectiveScale();

        for (int scaleIndex = 0; scaleIndex < 2; ++scaleIndex)
        {
            const juce::String scale = scaleIndex == 0 ? "Major" : "Minor";
            juce::PopupMenu sub;
            for (int i = 0; i < 12; ++i)
                sub.addItem (100 + scaleIndex * 20 + i, juce::String (keys[i]), true,
                             currentK == keys[i] && currentS == scale);
            menu.addSubMenu (scale, sub);
        }

        juce::Component::SafePointer<TonePanel> safe (this);
        menu.showMenuAsync (livent::menuAtPointer (this), [safe] (int result)
        {
            if (safe == nullptr || result < 100) return;
            const int raw = result - 100;
            const int scaleIndex = raw / 20;
            const int keyIndex = raw % 20;
            if (scaleIndex < 0 || scaleIndex > 1 || keyIndex < 0 || keyIndex >= 12) return;

            static const char* keys2[] = { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" };
            const juce::String targetKey = keys2[keyIndex];

            int rawDelta = 0;
            bool found = false;
            for (int d = 0; d < 12; ++d)
            {
                const auto candidate = TonePush::transposeKey (safe->baseKey.isNotEmpty() ? safe->baseKey : juce::String ("C"), d);
                if (candidate.equalsIgnoreCase (targetKey))
                {
                    rawDelta = d <= 6 ? d : d - 12;
                    found = true;
                    break;
                }
            }

            if (found)
                safe->manualKeyShiftSemitones = TonePanel::normaliseManualKeyShift (rawDelta - safe->semitoneShift());

            safe->manualScaleOverride = scaleIndex == 0 ? "Major" : "Minor";
            safe->sendShiftedKey();
            safe->refreshKeyDisplay();
        });
    }

    void toggleScaleManual()
    {
        if (baseKey.isEmpty()) baseKey = "C";
        if (baseScale.isEmpty() || baseScale.equalsIgnoreCase ("Chromatic")) baseScale = "Major";

        const auto current = effectiveScale();
        manualScaleOverride = current.equalsIgnoreCase ("Major") ? "Minor" : "Major";
        sendShiftedKey();
        refreshKeyDisplay();
        if (onLiveStateChanged) onLiveStateChanged();
    }

    livent::songs::Song makeCurrentSong() const
    {
        livent::songs::Song s;
        s.title = currentSongTitle.trim();
        s.url = currentSongUrl.trim();
        if (s.url.isEmpty()) s.url = urlBox.getText().trim();
        s.videoId = detectedVideoId.isNotEmpty() ? detectedVideoId : livent::songs::compactId (s.url);
        s.key = songAutomationActive ? automationSong.key : (baseKey.isNotEmpty() ? baseKey : juce::String ("C"));
        s.scale = songAutomationActive ? automationSong.scale : (baseScale.isNotEmpty() ? baseScale : juce::String ("Major"));
        s.shiftTong = songAutomationActive ? automationSong.shiftTong : toneOffsetTong;
        s.markers = songAutomationActive ? automationSong.markers : juce::Array<livent::songs::AutomationMarker>();
        s.category = livent::songs::defaultCategory();
        s.collections.add (s.category);
        for (const auto& m : clock.getMarks())
            s.timeline.add ({ m.seconds, m.key, m.scale });
        if (! songAutomationActive)
        {
            const auto library = livent::songs::load(); const int i = livent::songs::findMatch (library, s);
            if (i >= 0) s.markers = library[i].markers;
        }
        return s;
    }

    void autoSaveDetectedSong()
    {
        if (! songAutoSaveEnabled) return;
        if (baseKey.isEmpty() || baseScale.isEmpty() || baseScale.equalsIgnoreCase ("Chromatic")) return;
        auto s = makeCurrentSong();
        if (s.title.isEmpty()) s.title = currentSongTitle.isNotEmpty() ? currentSongTitle : s.videoId;
        if (s.title.isEmpty() && s.videoId.isEmpty()) return;
        livent::songs::upsert (s, true);
        if (songLibraryWindow != nullptr && songLibraryWindow->browser != nullptr)
            songLibraryWindow->browser->refresh();
    }

    void quickSaveCurrentSongTo (const juce::String& collection, bool makeFavorite)
    {
        if(followsPluginTone() && !syncToneFromPlugin())
        {livent::alert(livent::vn("Chưa có Key/Scale"),livent::vn("Không đọc được Key/Scale từ VST nhận tone ở track đích. Kiểm tra Auto-Tune trước khi lưu bài."));return;}
        auto saved = makeCurrentSong();
        const auto library = livent::songs::load();
        const int oldIndex = livent::songs::findMatch (library, saved);

        if (juce::isPositiveAndBelow (oldIndex, library.size()))
        {
            const auto& old = library.getReference (oldIndex);
            saved.collections = old.collections;
            saved.category = old.category;
            saved.favorite = old.favorite;
            livent::songs::normaliseCollections (saved);
        }
        else if (collection.isNotEmpty())
        {
            // Bai moi chon mot danh sach cu the thi khong can chen them
            // "DA THE LOAI" vao truoc no.
            saved.collections.clear();
        }

        const auto cleanCollection = collection.trim();
        if (cleanCollection.isNotEmpty())
            saved.collections.addIfNotAlreadyThere (cleanCollection);
        if (makeFavorite)
            saved.favorite = true;

        if (saved.collections.isEmpty())
            saved.collections.add (livent::songs::defaultCategory());
        saved.category = saved.collections[0];

        if (saved.title.isEmpty()) saved.title = currentSongTitle.trim();
        if (saved.title.isEmpty()) saved.title = saved.videoId.trim();
        if (saved.title.isEmpty())
        {
            livent::alert (livent::vn ("Chưa có bài hát"),
                           livent::vn ("Mở một bài hoặc dò tone trước khi lưu."));
            return;
        }

        if (livent::songs::upsert (saved, false))
        {
            currentSongTitle = saved.title;
            if (songLibraryWindow != nullptr && songLibraryWindow->browser != nullptr)
                songLibraryWindow->browser->refresh();
        }
    }

    void showSaveSongQuickMenu (juce::Component* anchor)
    {
        auto categories = livent::songs::allCollectionNames();
        juce::PopupMenu menu;
        menu.addSectionHeader (livent::vn ("LƯU VÀO DANH SÁCH"));

        constexpr int firstCategoryId = 1000;
        for (int i = 0; i < categories.size(); ++i)
            menu.addItem (firstCategoryId + i, categories[i]);

        menu.addItem (20, livent::vn ("♥  Bài yêu thích"));
        menu.addSeparator();
        menu.addItem (9001, livent::vn ("+ Tạo danh sách mới..."));
        menu.addItem (9002, livent::vn ("Chỉnh chi tiết bài hát..."));

        auto options = livent::menuAtPointer (this);
        if (anchor != nullptr)
            options = options.withTargetComponent (anchor);

        juce::Component::SafePointer<TonePanel> safe (this);
        menu.showMenuAsync (options, [safe, categories, firstCategoryId] (int result)
        {
            if (safe == nullptr || result == 0) return;

            if (result >= firstCategoryId && result < firstCategoryId + categories.size())
            {
                safe->quickSaveCurrentSongTo (categories[result - firstCategoryId], false);
                return;
            }

            if (result == 20)
            {
                safe->quickSaveCurrentSongTo (juce::String(), true);
                return;
            }

            if (result == 9001)
            {
                livent::songs::launchCollectionCreator ([safe] (juce::String name)
                {
                    if (safe == nullptr) return;
                    juce::StringArray one; one.add (name);
                    livent::songs::rememberCollectionNames (one);
                    safe->quickSaveCurrentSongTo (name, false);
                });
                return;
            }

            if (result == 9002)
                safe->saveCurrentSongManual();
        });
    }

    void saveCurrentSongManual()
    {
        if(followsPluginTone() && !syncToneFromPlugin())
        {livent::alert(livent::vn("Chưa có Key/Scale"),livent::vn("Không đọc được Key/Scale từ VST nhận tone ở track đích. Kiểm tra Auto-Tune trước khi lưu bài."));return;}
        auto original = makeCurrentSong();

        // V6.7: neu bai da co trong thu vien thi Luu lai KHONG duoc lam mat
        // danh muc/Yeu thich ma khach da sap xep truoc do. Lay phan to chuc
        // tu ban cu, con Key/Scale/Timeline van lay trang thai live hien tai.
        const auto library = livent::songs::load();
        const int oldIndex = livent::songs::findMatch (library, original);
        if (juce::isPositiveAndBelow (oldIndex, library.size()))
        {
            const auto& old = library.getReference (oldIndex);
            original.category = old.category;
            original.collections = old.collections;
            original.favorite = old.favorite;
            livent::songs::normaliseCollections (original);
        }

        if (original.title.isEmpty()) original.title = currentSongTitle;
        if (original.title.isEmpty() && original.videoId.isEmpty())
        {
            livent::alert (livent::vn ("Chưa có bài hát"), livent::vn ("Mở một bài hoặc dò tone trước khi lưu."));
            return;
        }

        juce::Component::SafePointer<TonePanel> safe (this);
        livent::songs::launchEditor (original, livent::vn ("Lưu bài hát"), [safe] (livent::songs::Song saved)
        {
            if (safe == nullptr) return;
            if (saved.category.isEmpty()) saved.category = livent::vn ("ĐA THỂ LOẠI");
            if (saved.title.isEmpty()) return;

            if (livent::songs::upsert (saved, false))
            {
                /*  V5.8.5: truoc day hop LUU cho sua Key/Scale/Beat shift
                    nhung sau khi bam LUU chi doi moi TEN tren giao dien; DSP
                    van giu tone cu. Ap dung dung noi dung vua luu NGAY LAP
                    TUC de file va am thanh dang nghe khong bao gio lech nhau. */
                safe->clearSongAutomation();
                safe->cancelDetectedFlash();
                safe->currentSongTitle = saved.title;
                safe->currentSongUrl = saved.url;
                safe->detectedVideoId = saved.videoId.isNotEmpty()
                                              ? saved.videoId
                                              : livent::songs::compactId (saved.url);
                safe->libraryToneVideoId = safe->detectedVideoId;

                ++safe->detectRequestSerial;
                safe->client.cancel();
                if (safe->onSongChanged) safe->onSongChanged();

                safe->baseKey = saved.key.isNotEmpty() ? saved.key : juce::String ("C");
                safe->baseScale = saved.scale.isNotEmpty() ? saved.scale : juce::String ("Major");
                safe->resetManualKeyScaleAdjustments();

                const double keepPosition = safe->clock.getPosition();
                const bool keepLive = safe->clock.isLive();
                juce::Array<ToneClock::Mark> marks;
                for (const auto& p : saved.timeline)
                    marks.add ({ p.seconds, p.key, p.scale, false });
                safe->clock.setMarks (marks, safe->baseKey, safe->baseScale);
                safe->clock.setPosition (keepPosition, keepLive);

                // Khac voi NAP PROJECT: day la tone bai hat, phai ghi that
                // Beat shift vao plugin NHAC, khong chi doi con so tren UI.
                safe->setToneOffset (saved.shiftTong);
                safe->activateSongAutomation (saved);
                if (keepLive) safe->checkForToneShift (keepPosition);

                safe->nowPlaying.setTitle (saved.title);
                safe->refreshKeyDisplay();
                if (safe->songLibraryWindow != nullptr && safe->songLibraryWindow->browser != nullptr)
                    safe->songLibraryWindow->browser->refresh();
            }
        });
    }

    void loadSongFromLibrary (const livent::songs::Song& s)
    {
        clearSongAutomation(); cancelDetectedFlash();
        /* Huy/ghe bo ket qua VPS cu neu no dang tren duong ve. Ngoai cancel
           con co serial o callback de chan ca truong hop ket qua da xep hang
           tren MessageManager truoc luc bam MO BAI. */
        ++detectRequestSerial;
        client.cancel();
        ++toneWriteSerial;pluginToneWriteUntilMs=0;pluginToneFollowing=false;
        mirroredKey.clear();mirroredScale.clear();
        if (onSongChanged) onSongChanged();
        keyShowingDetecting = keyLanding = false;
        keyFlashUntilMs = failureNoticeUntilMs = 0;
        keyRollTimer.stopTimer();
        keyDisplayButton.setToggleState (false, juce::dontSendNotification);
        detectButton.setButtonText (livent::vn ("ĐO TONE"));

        currentSongTitle = s.title;
        currentSongUrl = s.url;
        autoKeyPlaybackClock.reset();
        detectedVideoId = s.videoId.isNotEmpty() ? s.videoId : livent::songs::compactId (s.url);
        libraryToneVideoId = detectedVideoId;
        fallbackClockVideoId = detectedVideoId;
        fallbackClockSeconds = 0.0;
        fallbackClockLastMs = juce::Time::getMillisecondCounterHiRes();
        urlBox.setText (s.url, juce::dontSendNotification);
        baseKey = s.key.isNotEmpty() ? s.key : juce::String ("C");
        baseScale = s.scale.isNotEmpty() ? s.scale : juce::String ("Major");
        resetManualKeyScaleAdjustments();

        juce::Array<ToneClock::Mark> marks;
        for (const auto& p : s.timeline) marks.add ({ p.seconds, p.key, p.scale, false });
        clock.setMarks (marks, baseKey, baseScale);
        nowPlaying.setTitle (s.title);
        nowPlaying.setPosition (0.0, clock.getSpan(), false);

        /*  Loi cu: setToneOffsetSilently() chi doi UI, KHONG ghi Semitones
            vao track NHAC. Mo bai da luu -1.0 co the hien -1.0 nhung beat
            van o pitch cua bai truoc. Thu vien bai hat la lenh LIVE nen phai
            ap dung DSP that. setToneOffset() se doi NHAC roi ban Key da dich. */
        setToneOffset (s.shiftTong);
        activateSongAutomation (s);
        refreshKeyDisplay();
        statusLabel.setText (livent::vn ("Đã nạp tone đã lưu của bài - VPS sẽ không ghi đè."),
                             juce::dontSendNotification);
        // Start here also when the selected library song is already playing.
        // The pinned watcher path preserves this queue instead of starting twice.
        if (manualDetectMode && ! automationOwnsTone) builtinNewSong();   // 12s
    }

    void showSongLibrary()
    {
        if (songLibraryWindow == nullptr)
        {
            songLibraryWindow = std::make_unique<livent::songs::Window>();
            juce::Component::SafePointer<TonePanel> safe (this);
            songLibraryWindow->browser->onSongChosen = [safe] (const livent::songs::Song& s)
            {
                if (safe != nullptr) safe->loadSongFromLibrary (s);
            };
            songLibraryWindow->browser->onSongEdited = [safe] (const livent::songs::Song& before, const livent::songs::Song& after)
            {
                if (safe == nullptr) return;
                const bool same = before.videoId.isNotEmpty() ? before.videoId == safe->detectedVideoId
                    : before.title == safe->currentSongTitle;
                if (! same) return;
                const auto position = safe->clock.getPosition(); const bool live = safe->clock.isLive();
                const bool playing = safe->exactSongPlaying;
                safe->loadSongFromLibrary (after); safe->clock.setPosition (position, live);
                if (live)
                {
                    safe->lastExactSongSeconds = position; safe->lastExactSongTickMs = juce::Time::getMillisecondCounterHiRes(); safe->exactSongPlaying = playing;
                    safe->checkForToneShift (position);
                }
            };
        }
        songLibraryWindow->browser->refresh();
        songLibraryWindow->setVisible (true);
        songLibraryWindow->toFront (true);
    }

    void acceptSavedSongClock (const BrowserWatcher::Info& info)
    {
        lastExactSongTickMs = 0;
        if (! info.hasTimeTag || info.videoId != detectedVideoId || info.seconds < 0) return;
        lastExactSongSeconds = (double) info.seconds;
        lastExactSongTickMs = juce::Time::getMillisecondCounterHiRes();
        exactSongPlaying = info.knowsPlaying && info.playing;
        clock.setPosition (lastExactSongSeconds, true);
        nowPlaying.setPosition (lastExactSongSeconds, info.knowsLength ? (double) info.duration : clock.getSpan(), true);
        checkForToneShift (lastExactSongSeconds);
    }

    bool loadSavedSongMarkers (const BrowserWatcher::Info& info)
    {
        if (info.videoId.isEmpty()) return false;
        for (const auto& song : livent::songs::load())
            if (song.videoId == info.videoId && ! song.markers.isEmpty())
            {
                loadSongFromLibrary (song);
                acceptSavedSongClock (info);
                return true;
            }
        return false;
    }

    void nudgeTone (float deltaTong)
    {
        setToneOffset (toneOffsetTong + deltaTong);
    }

    void setToneOffset (float tong)
    {
        //  Chan trong -6 .. +6, va lam tron ve boi cua 0.5
        const float clamped = juce::jlimit (-6.0f, 6.0f, tong);

        toneOffsetTong = std::round (clamped * 2.0f) / 2.0f;

        updateToneLabel();
        applyToneOffset();
    }

    float getToneOffset() const   { return toneOffsetTong; }

    void updateToneLabel()
    {
        toneValueLabel.setText (juce::String (toneOffsetTong, 1),
                                juce::dontSendNotification);

        /*  Ve 0 thi mau xam nhat cho do choi mat; lech thi to mau de anh
            liec mot cai la biet nhac dang khong o tong goc.  */
        toneValueLabel.setColour (juce::Label::textColourId,
                                  toneOffsetTong == 0.0f ? (livent::rack::active() ? livent::rack::lcdText() : Col::text)
                                : toneOffsetTong >  0.0f ? Col::green
                                                         : Col::amber);
        refreshKeyDisplay();
    }

    /*  Bam +/- xong thi lam hai viec, theo dung thu tu nay.  */
    void applyToneOffset()
    {
        //-- 1. Num Semitones cua plugin dich giong tren track NHAC ----------
        juce::String pluginName, whyFailed;
        bool done = false;

        auto* nhac = nhacTrack();

        if (nhac != nullptr)
            done = TonePush::setSemitonesOnTrack (*nhac, semitoneShift(),
                                                  &pluginName, &whyFailed);
        else
            whyFailed = livent::vn ("Không tìm thấy track tên \"NHAC\".");

        if (done)
        {
            /*  Ghi ro DA GHI VAO NUM NAO va num do gio bao bao nhieu.

                Neu LiveNT lai chon nham num (vd trung Cents thay vi
                Semitones) thi nhin dong nay la lo ra ngay, khong phai ngoi
                doan vi sao bam ma khong nghe thay gi doi.  */
            statusLabel.setText (livent::vn ("Tông nhạc ") + juce::String (toneOffsetTong, 1)
                                 + livent::vn (" (") + juce::String (semitoneShift())
                                 + livent::vn (" nửa cung)  ->  ") + pluginName,
                                 juce::dontSendNotification);
        }
        else
        {
            statusLabel.setText (livent::vn ("Không đạt được tông nhạc - bấm vào dòng này để xem vì sao"),
                                 juce::dontSendNotification);

            /*  ==========  MOC 38: NOI RO VI SAO  ==========

                Bam nut ma khong thay gi nhuc nhich la loai loi bi tac nhat:
                khong biet LiveNT co chay khong, co tim thay plugin khong,
                num ten gi. Nen khi hong thi bung han ban tuong trinh: da xet
                plugin nao, num cua no ten gi, gia tri hien tai bao nhieu.

                Chi bung MOT LAN cho moi lan bam, khong bung lien tuc: dang
                dien ma hop thoai nhay lien tuc con te hon la im lang.  */
            if (whyFailed != lastToneFailure)
            {
                lastToneFailure = whyFailed;

                livent::alert (livent::vn ("Chưa đổi được tông nhạc"),
                    livent::vn ("LiveNT không tìm thấy num dịch giọng trên track NHẠC.\n\n")
                    + whyFailed
                    + livent::vn ("\nNếu thấy tên num đúng ở trên mà LiveNT vẫn không nhận, "
                      "gửi lại danh sách này để em thêm cách nhận."),
                    juce::MessageBoxIconType::WarningIcon);
            }
        }

        //-- 2. Ban lai Key da dich sang plugin chinh cao do -----------------
        /*  Chi ban lai khi DA co ket qua do tone. Chua do bai nao ma da ban
            thi khong biet ban not gi -- va ghi bua vao plugin chinh cao do
            giua buoi dien la hong tieng ngay.  */
        if (baseKey.isNotEmpty())
            sendShiftedKey();

        if (onLiveStateChanged)
            onLiveStateChanged();
    }

    /** Hien va ban Key sau khi cong tone NHAC + offset Key thu cong. */
    void sendShiftedKey()
    {
        if (baseKey.isEmpty())
            return;

        const int shift = effectiveKeyShift();
        // An explicit DAW edit computes its requested value from the stored
        // base; the read-only mirrored label must not override that request.
        const auto shifted=TonePush::transposeKey(baseKey,shift);
        const auto shownKey=shifted.isNotEmpty()?shifted:baseKey;
        const auto shownScale=followsPluginTone()
            ? (manualScaleOverride.isNotEmpty()?manualScaleOverride:
               (baseScale.isNotEmpty()?baseScale:juce::String("Major")))
            : effectiveScale();
        const bool manualScale = manualScaleOverride.isNotEmpty();

        juce::String shown = shownKey + "   " + displayScale (shownScale);
        if (shift != 0 || manualScale)
            shown << livent::vn ("   (gốc ") << baseKey << " "
                  << (baseScale.isNotEmpty() ? baseScale : juce::String ("Major")) << ")";

        resultLabel.setText (shown, juce::dontSendNotification);
        keyDisplayButton.setButtonText (shownKey + " " + displayScale (shownScale));
        pushToPluginRaw (getSelectedTrackId(), shownKey, shownScale);
    }

    //=========================================================================
    //  MOC 35: BAY NUT DIEN
    //=========================================================================
    //==========================================================================
    //  14/10: DOI TEN NUT bang chuot phai (Lofi, Remix 1, Remix 2, Em be, Be).
    //  Ten luu theo may trong button-names.xml (ButtonMap.h > names). Cai dat >
    //  Gan nut va danh sach hanh dong nut tuy bien doc cung kho ten nay.
    //==========================================================================
    static juce::String defaultLiveButtonName (const juce::String& id)
    {
        if (id == "lofi")    return "Lofi";
        if (id == "remix1")  return juce::String::fromUTF8 (livent::branding::fxNameRemix1);
        if (id == "remix2")  return juce::String::fromUTF8 (livent::branding::fxNameRemix2);
        if (id == "baby")    return livent::vn ("Em bé");
        if (id == "harmony") return livent::vn ("Bè");
        return id;
    }

    static juce::String liveButtonName (const juce::String& id)
    {
        return livent::buttonmap::names::displayName (id, defaultLiveButtonName (id));
    }

    PluginActionButton* renamableButton (const juce::String& id)
    {
        if (id == "lofi")    return &lofiButton;
        if (id == "remix1")  return &remix1Button;
        if (id == "remix2")  return &remix2Button;
        if (id == "baby")    return &babyButton;
        if (id == "harmony") return &harmonyButton;
        return nullptr;
    }

    void applyLiveButtonNames()
    {
        for (auto* id : { "lofi", "remix1", "remix2", "baby", "harmony" })
            if (auto* b = renamableButton (id))
                b->setButtonText (liveButtonName (id));

        setupHelpTexts();   // loi giai thich "?" co ten nut -> cap nhat theo
        resized();
        repaint();
    }

    void askRenameLiveButton (const juce::String& id)
    {
        auto* w = livent::makeAlert (livent::vn ("Đổi tên nút"),
                                     livent::vn ("Tên mới hiện trên bảng điều khiển và trong Cài đặt > Gán nút. "
                                                 "Để trống rồi bấm Lưu = về tên gốc."),
                                     juce::MessageBoxIconType::NoIcon);
        w->addTextEditor ("name", livent::buttonmap::names::hasCustom (id) ? liveButtonName (id) : juce::String(),
                          livent::vn ("Tên gốc: ") + defaultLiveButtonName (id));
        w->addButton (livent::vn ("Lưu"), 1);
        w->addButton (livent::vn ("Hủy"), 0);
        juce::Component::SafePointer<TonePanel> safe (this);
        livent::centreDialog (w);
        w->enterModalState (true, juce::ModalCallbackFunction::create ([safe, w, id] (int result)
        {
            if (result == 1 && safe != nullptr)
            {
                const auto text = w->getTextEditorContents ("name").trim();
                if (! livent::buttonmap::names::setName (id, text))
                    livent::alert (livent::vn ("Đổi tên nút"), livent::vn ("Không lưu được tên nút."));
                safe->applyLiveButtonNames();
                if (safe->onButtonNamesChanged)
                    safe->onButtonNamesChanged();
            }
            delete w;
        }), false);
    }

    void setupLiveButton (juce::TextButton& b, const juce::String& text)
    {
        b.setButtonText (text);
        b.setClickingTogglesState (false);   // mau do TRANG THAI THAT quyet dinh

        // V6.6: bỏ chấm LED ở toàn bộ dãy nút live để tên nút luôn cân,
        // đồng bộ giữa các nút và không còn trường hợp Lofi bị rút thành L...
        b.getProperties().set ("noLed", true);
        b.getProperties().set ("led", false);

        // V6.5.3: nhom nut live co kieu rieng: nen phang, vien mau nhan khi BAT,
        // chu luon dung mau tuong phan cao. Khong dung textDim de nen sang van
        // sac net, khong co cam giac chu bi mo/xam.
        b.getProperties().set ("liveChipStyle", true);

        // V6.5.2: ưu tiên vẽ ĐỦ tên. Riêng Lofi bỏ LED ở bên trái để bốn
        // ký tự luôn có toàn bộ chiều ngang, không còn bị JUCE rút thành L...
        b.getProperties().set ("preferFullText", true);

        addAndMakeVisible (b);
    }

    /*  To mau nut theo trang thai THAT doc tu mixer, khong theo lan bam cuoi.

        Vi sao khong dung setClickingTogglesState cua JUCE: no tu lat trang
        thai nut moi lan bam, doc lap voi thuc te. Neu anh tat vang bang
        duong khac (bam thang o track MIC chang han) thi nut o day van xanh
        -- nhin nut mot dang, tieng ra mot neo. Dang hat ma nhin nham la
        hong. Nen: mau nut LUON doc tu trang thai that.  */
    static void paintLiveButton (juce::TextButton& b, bool on)
    {
        //  V6.0: khong to xanh/do nua - trang thai that duoc hien bang
        //  toggle state: bat = mau nhan + LED sang, tat = xam.
        b.removeColour (juce::TextButton::buttonColourId);
        b.removeColour (juce::TextButton::textColourOffId);
        // V6.6: dãy nút live đã bỏ LED hoàn toàn, nên trạng thái chỉ còn
        // phân biệt bằng nền/viền/chữ - ổn định hơn trên mọi theme.
        b.getProperties().set ("led", false);

        if (b.getToggleState() != on)
        {
            b.setToggleState (on, juce::dontSendNotification);
            b.repaint();
        }
    }

    /*  v4.3.4: tu khi co bus dau vao logic, trong Mixer co the cung luc co
        "MIC" (Type::Input) va "MIC" (Type::Audio), tuong tu voi NHAC.
        Tim chi theo TEN se bat nham bus dau vao va lam cac nut tren Bang
        dieu khien nhu VANG/TUNE/MIC/NHAC/LOFI/REMIX trong nhu khong hoat
        dong. Tu day shortcut luon khoa ca TEN + LOAI track. */
    /* V5.7: KHONG bam theo ten hien thi. Khach doi "MÍC" thanh bat ky ten nao
       hoac keo track len/xuong thi role van co dinh, nut live van dung track. */
    juce::TextButton* liveButtonForAction (const juce::String& action)
    {
        if (action == "tune") return &tuneButton;
        if (action == "nhac") return &nhacButton;
        if (action == "mic") return &micButton;
        if (action == "vang") return &vangButton;
        if (action == "lofi") return &lofiButton;
        if (action == "remix1") return &remix1Button;
        if (action == "remix2") return &remix2Button;
        if (action == "baby") return &babyButton;
        if (action == "harmony") return &harmonyButton;
        return nullptr;
    }
    Track* micTrack()  const { return mixer.getTrackByRole (Track::Role::Mic); }
    Track* nhacTrack() const { return mixer.getTrackByRole (Track::Role::Music); }

    //=========================================================================
    //  06/10: BANG CHUOT PHAI (Nhac / Vang / Mic) - xem QuickPanel.h
    //
    //  Cac thanh Nhac / Mic / Vang dai / Vang ngan / Delay / Toc do / Flex
    //  di QUA chinh 7 num tren bang (dat gia tri num) -> moi duong da co
    //  (Gan nut, F3, luu du an, preset) chay y nhu xoay num, khong co duong
    //  thu hai. EQ thi ghi thang vao thong so VST Manny (theo ten).
    //=========================================================================
    livent::quick::Column knobColumn (LiveFineKnob& k, const juce::String& name, const juce::String& sub,
                                      double step, std::vector<std::pair<double, juce::String>> ticks)
    {
        livent::quick::Column c;
        c.name = name;
        c.sub = [sub] { return sub; };
        c.minV = k.getMinimum();
        c.maxV = k.getMaximum();
        c.step = step;
        c.defaultV = k.getDoubleClickReturnValue();
        c.ticks = std::move (ticks);
        auto* kp = &k;
        c.available = [kp] { return kp->isEnabled(); };
        c.get = [kp] { return kp->getValue(); };
        c.set = [this, kp] (double v, bool dragging)
        {
            const juce::ScopedValueSetter<bool> guard (quickDragging, dragging);
            kp->setValue (v, juce::sendNotificationSync);
        };
        c.endGesture = [kp] { if (kp->onDragEnd) kp->onDragEnd(); };
        c.text = [kp] (double v) { return kp->getTextFromValue (v); };
        return c;
    }

    static std::vector<std::pair<double, juce::String>> dbTicks()
    {
        return { { 6.0, "+6" }, { 0.0, "0" }, { -12.0, "-12" }, { -24.0, "-24" }, { -42.0, "-42" },
                 { -60.0, juce::String::fromUTF8 ("-\xe2\x88\x9e") } };
    }

    // Changes to built-in noise reduction are part of the saved project.
    void builtinFxEdited()
    {
        if (onPresetsChanged) onPresetsChanged();
    }

    /*  12s: "GIAM ON" thay "NEN GIONG" - giam on co san tren track MIC (truoc VST).
        Khong co den bat / tat: keo ve 0 = Tat (khong tinh, khong tre).  */
    livent::quick::Group noiseGroup()
    {
        livent::quick::Group g;
        g.label = livent::vn ("GIẢM ỒN");
        livent::quick::Column c;
        c.name = livent::vn ("Mức giảm");
        c.sub = [this]
        {
            auto* m = micTrack();
            if (m == nullptr || ! m->getDenoise().isActive()) return livent::vn ("đang tắt");
            if (! m->areAllInsertsOn()) return livent::vn ("INSERT đang tắt");
            const float gr = m->getDenoise().getCurrentReductionDb();
            return gr >= 0.5f ? livent::vn ("giảm ") + juce::String (gr, 1) + " dB" : livent::vn ("đang bật");
        };
        c.minV = 0.0; c.maxV = 100.0; c.step = 5.0; c.defaultV = 50.0;
        c.ticks = { { 100.0, livent::vn ("nhiều") }, { 50.0, "50" }, { 0.0, livent::vn ("tắt") } };
        c.available = [this] { return micTrack() != nullptr; };
        c.get = [this] { auto* m = micTrack(); return m != nullptr ? (double) m->getDenoise().getAmount() : 0.0; };
        c.set = [this] (double v, bool) { if (auto* m = micTrack()) m->getDenoise().setAmount ((float) v); };
        c.endGesture = [this] { builtinFxEdited(); };
        c.text = [] (double v) { return v < 0.5 ? livent::vn ("Tắt") : juce::String ((int) std::lround (v)) + " %"; };
        g.cols.push_back (std::move (c));
        return g;
    }

    void showQuick (livent::quick::Spec spec, juce::Component* anchor)
    {
        quickWindow.reset();
        const int serial = ++quickSerial;
        juce::Component::SafePointer<TonePanel> safe (this);
        quickWindow = std::make_unique<livent::quick::Window> (std::move (spec), getTopLevelComponent(), anchor,
            [safe, serial] { if (safe != nullptr && safe->quickSerial == serial) safe->quickWindow.reset(); });
    }

    //  06/10: "VE PRESET" - tra cac thanh ve dung so da luu trong preset dang chon
    const livent::presets::Preset* currentPresetWithData() const
    {
        if (presetBank.current < 0)
            return nullptr;
        const auto& p = presetBank[presetBank.current];
        return p.isEmpty() ? nullptr : &p;
    }

    juce::String presetSuffix() const
    {
        if (auto* p = currentPresetWithData())
            return livent::vn (" · preset ") + p->name;
        return livent::vn (" · chưa chọn preset");
    }

    static const livent::presets::TrackSnap* snapFor (const livent::presets::Preset& p, const Track* t)
    {
        if (t == nullptr) return nullptr;
        for (const auto& ts : p.tracks)
            if (ts.trackId == t->getId() && (ts.name.isEmpty() || ts.name.equalsIgnoreCase (t->getName())))
                return &ts;
        for (const auto& ts : p.tracks)
            if (ts.name.equalsIgnoreCase (t->getName()))
                return &ts;
        return nullptr;
    }

    /** Muc Send trong preset: track nguon -> track dich (+ o sidechain). */
    std::optional<double> snapSendLevel (const livent::presets::Preset& p, const Track* src, const Track* dst, int dstSlot) const
    {
        auto* ts = snapFor (p, src);
        if (ts == nullptr || dst == nullptr) return std::nullopt;
        for (const auto& ss : ts->sends)
            if (ss.targetSlot == dstSlot
                && (ss.targetId == dst->getId() || ss.targetName.equalsIgnoreCase (dst->getName())))
                return (double) ss.levelDb;
        return std::nullopt;
    }

    /** Gia tri trong preset cho num <id> (theo dung cach gan cua num do). */
    std::optional<double> presetKnobValue (const livent::presets::Preset& p, const char* id,
                                           Track* defaultTrack, Track::Role sendRole) const
    {
        using livent::buttonmap::Act;
        const auto b = buttonMap.get (id);
        if (! b.isDefault())
        {
            auto* t = boundTrack (b);
            if (t == nullptr) return std::nullopt;
            if (b.act == Act::TrackVolume)
            {
                if (auto* ts = snapFor (p, t)) return (double) ts->gainDb;
                return std::nullopt;
            }
            if (b.act == Act::SendLevel)
            {
                const int i = livent::buttonmap::resolveSendIndex (mixer, *t, b);
                if (i < 0) return std::nullopt;
                const auto snd = t->getSend (i);
                return snapSendLevel (p, t, mixer.getTrackById (snd.targetId), snd.targetSlot);
            }
            return std::nullopt;
        }
        if (sendRole == Track::Role::None)
        {
            if (auto* ts = snapFor (p, defaultTrack)) return (double) ts->gainDb;
            return std::nullopt;
        }
        return snapSendLevel (p, micTrack(), mixer.getTrackByRole (sendRole), -1);
    }

    void restoreKnobsFromPreset (std::initializer_list<std::tuple<LiveFineKnob*, const char*, Track*, Track::Role>> items)
    {
        auto* p = currentPresetWithData();
        if (p == nullptr) return;
        for (const auto& [k, id, track, role] : items)
            if (k->isEnabled())
                if (auto v = presetKnobValue (*p, id, track, role))
                {
                    k->setValue (*v, juce::sendNotificationSync);
                    if (k->onDragEnd) k->onDragEnd();
                }
    }

    void openQuickVolume()
    {
        livent::quick::Spec s;
        s.title = livent::vn ("Âm lượng");
        s.sub = livent::vn ("NHẠC · MÍC") + presetSuffix();
        livent::quick::Group g;
        g.cols.push_back (knobColumn (musicVolumeKnob, livent::vn ("Nhạc"), livent::vn ("track NHẠC"), 0.5, dbTicks()));
        g.cols.push_back (knobColumn (micVolumeKnob,   livent::vn ("Míc"),  livent::vn ("track MÍC"),  0.5, dbTicks()));
        s.groups.push_back (std::move (g));
        s.actionText = livent::vn ("Về preset");
        s.actionEnabled = [this] { return currentPresetWithData() != nullptr; };
        s.action = [this]
        {
            restoreKnobsFromPreset ({ { &musicVolumeKnob, "kMusic", nhacTrack(), Track::Role::None },
                                      { &micVolumeKnob,   "kMic",   micTrack(),  Track::Role::None } });
        };
        showQuick (std::move (s), &nhacButton);
    }

    void openQuickVang()
    {
        livent::quick::Spec s;
        s.title = livent::vn ("Vang · Delay");
        s.sub = livent::vn ("Send từ MÍC") + presetSuffix();
        livent::quick::Group g;
        g.cols.push_back (knobColumn (reverbLongKnob,  livent::vn ("Vang dài"),  livent::vn ("hội trường"), 0.5, dbTicks()));
        g.cols.push_back (knobColumn (reverbShortKnob, livent::vn ("Vang ngắn"), livent::vn ("phòng"),      0.5, dbTicks()));
        g.cols.push_back (knobColumn (delayKnob,       "Delay",                  livent::vn ("tiếng lặp"),  0.5, dbTicks()));
        s.groups.push_back (std::move (g));
        s.actionText = livent::vn ("Về preset");
        s.actionEnabled = [this] { return currentPresetWithData() != nullptr; };
        s.action = [this]
        {
            restoreKnobsFromPreset ({ { &reverbLongKnob,  "kRevLong",  nullptr, Track::Role::ReverbLong },
                                      { &reverbShortKnob, "kRevShort", nullptr, Track::Role::ReverbShort },
                                      { &delayKnob,       "kDelay",    nullptr, Track::Role::Delay } });
        };
        showQuick (std::move (s), &vangButton);
    }

    /** Lien ket toi Manny EQ dang mo (song chung voi bang). */
    struct EqLink
    {
        const Mixer* mix = nullptr;
        int trackId = 0, slot = -1;
        juce::AudioPluginInstance* plugin = nullptr;
        juce::AudioProcessorParameter* gain[4] {};
        juce::AudioProcessorParameter* freq[4] {};
        juce::AudioProcessorParameter* inout[4] {};
        juce::AudioProcessorParameter* hp = nullptr;
        juce::AudioProcessorParameter* type4 = nullptr;
        juce::AudioProcessorParameter* phase = nullptr;
        juce::AudioProcessorParameter* bypass = nullptr;
        livent::vstctl::NumericMap gainMap[4], hpMap;

        bool alive() const
        {
            auto* t = mix != nullptr ? mix->getTrackById (trackId) : nullptr;
            return t != nullptr && plugin != nullptr && t->getInserts().getPlugin (slot) == plugin;
        }
    };

    static juce::String hzText (juce::AudioProcessorParameter* p)
    {
        if (p == nullptr) return {};
        const auto raw = p->getText (p->getValue(), 32).trim();
        const double v = livent::vstctl::parseNumber (raw);
        if (std::isnan (v)) return raw;
        if (v >= 1000.0)
        {
            auto t = juce::String (v / 1000.0, 1);
            if (t.endsWith (".0")) t = t.dropLastCharacters (2);
            return t + " kHz";
        }
        return juce::String ((int) std::lround (v)) + " Hz";
    }

    void openQuickVoice()
    {
        using namespace livent::vstctl;
        livent::quick::Spec s;
        s.title = livent::vn ("Giọng hát");

        auto* mic = micTrack();
        const auto found = findMicEq (mixer, buttonMap, mic);
        std::shared_ptr<EqLink> eq;
        if (found.plugin != nullptr && found.track != nullptr)
        {
            eq = std::make_shared<EqLink>();
            eq->mix = &mixer;
            eq->trackId = found.track->getId();
            eq->slot = found.slot;
            eq->plugin = found.plugin;
            for (int i = 0; i < 4; ++i)
            {
                const juce::String n ("Band " + juce::String (i + 1));
                eq->gain[i]  = findParam (found.plugin, (n + " Gain").toRawUTF8());
                eq->freq[i]  = findParam (found.plugin, (n + " Freq").toRawUTF8());
                eq->inout[i] = findParam (found.plugin, (n + " In/Out").toRawUTF8());
                eq->gainMap[i].build (eq->gain[i]);
            }
            eq->hp     = findParam (found.plugin, "High Pass");
            eq->type4  = findParam (found.plugin, "Band 4 Type");
            eq->phase  = findParam (found.plugin, "Phase");
            eq->bypass = findParam (found.plugin, "Bypass");
            eq->hpMap.build (eq->hp);
        }

        juce::String sub = mic != nullptr ? mic->getName() : livent::vn ("MÍC");
        if (eq != nullptr)
        {
            if (found.track != nullptr && found.track != mic)
                sub << livent::vn (" · EQ ở ") << found.track->getName();
            sub << livent::vn (" · EQ ô ") << (eq->slot + 1);
        }
        sub << presetSuffix();
        s.sub = sub;

        static const char* bandNames[] = { "Trầm", "Ấm", "Rõ lời", "Sáng" };
        if (eq != nullptr)
        {
            livent::quick::Group g;
            g.label = "EQ (MANNY)";
            for (int i = 0; i < 4; ++i)
            {
                if (eq->gain[i] == nullptr)
                    continue;
                livent::quick::Column c;
                c.name = livent::vn (bandNames[i]);
                c.sub = [eq, i] { return eq->alive() ? hzText (eq->freq[i]) : juce::String(); };
                const auto& m = eq->gainMap[i];
                c.minV = m.isValid() ? juce::jmax (-18.0, m.minValue()) : -10.0;
                c.maxV = m.isValid() ? juce::jmin (18.0,  m.maxValue()) :  10.0;
                c.step = 0.5;
                c.defaultV = 0.0;
                c.bipolar = true;
                const double edge = std::floor (juce::jmin (std::abs (c.minV), c.maxV));
                const double half = std::round (edge / 2.0);
                c.ticks = { { edge, "+" + juce::String ((int) edge) }, { half, "+" + juce::String ((int) half) },
                            { 0.0, "0" }, { -half, "-" + juce::String ((int) half) }, { -edge, "-" + juce::String ((int) edge) } };
                c.available = [eq] { return eq->alive(); };
                c.get = [eq, i] { return eq->gainMap[i].toValue (eq->gain[i]->getValue()); };
                c.set = [eq, i] (double v, bool) { if (eq->alive()) setParam (eq->gain[i], eq->gainMap[i].toNorm (v)); };
                c.endGesture = [this] { if (onPluginChanged) onPluginChanged(); };
                c.text = [] (double v)
                {
                    if (std::abs (v) < 0.05) return juce::String ("0.0 dB");
                    return (v > 0.0 ? "+" : "") + juce::String (v, 1) + " dB";
                };
                // 06/10: nen giu trong +-3 dB - qua thi giong de duc / choi / mong
                c.safeZone = 3.0;
                c.warn = [i] (double v)
                {
                    static const char* up[]   = { "Trầm quá +3 dB: giọng dễ ù, đục",
                                                  "Ấm quá +3 dB: giọng dễ đục, nghẹt mũi",
                                                  "Rõ lời quá +3 dB: giọng dễ chói, gắt tai",
                                                  "Sáng quá +3 dB: dễ xì, chói" };
                    static const char* down[] = { "Trầm dưới -3 dB: giọng dễ mỏng",
                                                  "Ấm dưới -3 dB: giọng dễ mỏng, rỗng",
                                                  "Rõ lời dưới -3 dB: giọng dễ chìm, xa",
                                                  "Sáng dưới -3 dB: giọng dễ tối, bí" };
                    return livent::vn (v > 0.0 ? up[i] : down[i]);
                };
                if (eq->inout[i] != nullptr)
                {
                    c.ledGet = [eq, i] { return eq->alive() && eq->inout[i]->getValue() >= 0.5f; };
                    c.ledToggle = [this, eq, i]
                    {
                        if (! eq->alive()) return;
                        setParam (eq->inout[i], eq->inout[i]->getValue() >= 0.5f ? 0.0f : 1.0f);
                        if (onPluginChanged) onPluginChanged();
                    };
                }
                g.cols.push_back (std::move (c));
            }
            s.groups.push_back (std::move (g));

            s.warnHint = livent::vn ("Nên giữ EQ trong ±3 dB (vạch xanh) - kéo quá dễ đục hoặc chói.");

            // 06/10: "Ve preset" = EQ ve dung nhu preset dang chon (ca tan so, Cat u).
            // Auto-Tune (Toc do / Flex) KHONG dong vao - dang hat khong bi doi Key / Be.
            s.actionText = livent::vn ("Về preset");
            s.actionEnabled = [this, eq]
            {
                auto* p = currentPresetWithData();
                if (p == nullptr || ! eq->alive()) return false;
                auto* ts = snapFor (*p, mixer.getTrackById (eq->trackId));
                if (ts == nullptr) return false;
                for (const auto& sl : ts->slots)
                    if (sl.slot == eq->slot && sl.state.getSize() > 0) return true;
                return false;
            };
            s.action = [this, eq]
            {
                auto* p = currentPresetWithData();
                auto* t = mixer.getTrackById (eq->trackId);
                if (p == nullptr || t == nullptr || ! eq->alive()) return;
                if (auto* ts = snapFor (*p, t))
                    for (const auto& sl : ts->slots)
                        if (sl.slot == eq->slot && sl.state.getSize() > 0)
                        {
                            auto& chain = t->getInserts();
                            if (chain.getPresetIdentity (sl.slot) == sl.identity || sl.identity.isEmpty())
                            {
                                chain.applyPresetState (sl.slot, sl.state, sl.identity);
                                chain.setBypassed (sl.slot, sl.bypassed);
                            }
                            break;
                        }
                if (onPluginChanged) onPluginChanged();
            };

            if (eq->hp != nullptr && eq->hpMap.isValid())
            {
                s.chipsLabel = livent::vn ("Cắt ù:");
                auto hpNow = [eq]
                {
                    return eq->alive() ? parseNumber (eq->hp->getText (eq->hp->getValue(), 32)) : 0.0;
                };
                s.chips.push_back ({ livent::vn ("Tắt"),
                                     [hpNow] { return std::isnan (hpNow()); },
                                     [this, eq] { if (eq->alive()) { setParam (eq->hp, 0.0f); if (onPluginChanged) onPluginChanged(); } } });
                for (double hz : { 71.0, 127.0, 220.0, 317.0 })
                {
                    if (hz < eq->hpMap.minValue() || hz > eq->hpMap.maxValue())
                        continue;
                    s.chips.push_back ({ juce::String ((int) hz),
                                         [hpNow, hz] { const double v = hpNow(); return ! std::isnan (v) && std::abs (v - hz) <= hz * 0.12; },
                                         [this, eq, hz] { if (eq->alive()) { setParam (eq->hp, eq->hpMap.toNorm (hz)); if (onPluginChanged) onPluginChanged(); } } });
                }
            }

            s.moreText = livent::vn ("Nâng cao  ▾");
            s.more = [this, eq] (juce::Component* anchor) { showEqAdvancedMenu (eq, anchor); };
            s.stillValid = [eq] { return eq->alive(); };
        }
        else if (! found.disabled)
        {
            livent::quick::Group g;
            g.label = "EQ";
            g.message = livent::vn ("Chưa thấy Manny EQ trên track MÍC.\nGắn VST Manny Marroquin EQ vào track MÍC "
                                    "(ô nào cũng được) hoặc chọn tay trong Cài đặt > Gán nút.");
            g.messageButton = livent::vn ("Gán VST EQ...");
            g.messageAction = [this] { if (onOpenButtonMapSettings) onOpenButtonMapSettings(); };
            s.groups.push_back (std::move (g));
        }

        s.groups.push_back (noiseGroup());     // 12s: Giam on thay Nen giong

        showQuick (std::move (s), &micButton);
    }

    void showEqAdvancedMenu (std::shared_ptr<EqLink> eq, juce::Component* anchor)
    {
        using namespace livent::vstctl;
        if (eq == nullptr || ! eq->alive())
            return;

        static const char* bandNames[] = { "Trầm", "Ấm", "Rõ lời", "Sáng" };
        auto actions = std::make_shared<std::map<int, std::function<void()>>>();
        int nextId = 1;
        auto add = [&] (juce::PopupMenu& m, const juce::String& text, bool ticked, std::function<void()> fn)
        {
            (*actions)[nextId] = std::move (fn);
            m.addItem (nextId++, text, true, ticked);
        };

        juce::PopupMenu menu;
        menu.addSectionHeader (livent::vn ("Tần số từng dải"));
        for (int i = 0; i < 4; ++i)
        {
            auto* p = eq->freq[i];
            if (p == nullptr) continue;
            juce::PopupMenu sub;
            const float cur = p->getValue();
            for (const auto& st : stepsOf (p))
                add (sub, st.text + " Hz", std::abs (st.norm - cur) < 0.02f,
                     [this, eq, p, v = st.norm] { if (eq->alive()) { setParam (p, v); if (onPluginChanged) onPluginChanged(); } });
            menu.addSubMenu (livent::vn ("Dải ") + juce::String (i + 1) + " · " + livent::vn (bandNames[i])
                               + ":  " + hzText (p), sub);
        }
        if (eq->type4 != nullptr)
        {
            juce::PopupMenu sub;
            const float cur = eq->type4->getValue();
            for (const auto& st : stepsOf (eq->type4))
                add (sub, st.text, std::abs (st.norm - cur) < 0.02f,
                     [this, eq, v = st.norm] { if (eq->alive()) { setParam (eq->type4, v); if (onPluginChanged) onPluginChanged(); } });
            menu.addSubMenu (livent::vn ("Dải 4 · kiểu (Bell / Shelf):  ")
                               + eq->type4->getText (cur, 32).trim(), sub);
        }
        menu.addSeparator();
        if (eq->phase != nullptr)
            add (menu, livent::vn ("Đảo pha"), eq->phase->getValue() >= 0.5f,
                 [this, eq] { if (eq->alive()) { setParam (eq->phase, eq->phase->getValue() >= 0.5f ? 0.0f : 1.0f); if (onPluginChanged) onPluginChanged(); } });
        if (eq->bypass != nullptr)
            add (menu, livent::vn ("Tạm bỏ qua EQ (Bypass)"), eq->bypass->getValue() >= 0.5f,
                 [this, eq] { if (eq->alive()) { setParam (eq->bypass, eq->bypass->getValue() >= 0.5f ? 0.0f : 1.0f); if (onPluginChanged) onPluginChanged(); } });
        menu.addSeparator();
        add (menu, livent::vn ("Mở cửa sổ VST EQ"), false, [this, eq]
        {
            if (eq->alive() && onOpenPluginSlot)
                onOpenPluginSlot (mixer.getTrackById (eq->trackId), eq->slot);
        });
        add (menu, livent::vn ("Gán VST EQ khác...  (Cài đặt > Gán nút)"), false, [this]
        {
            if (quickWindow != nullptr) quickWindow->close();
            if (onOpenButtonMapSettings) onOpenButtonMapSettings();
        });

        menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (anchor),
                            [actions] (int r)
                            {
                                auto it = actions->find (r);
                                if (it != actions->end() && it->second)
                                    it->second();
                            });
    }


    //=========================================================================
    //  V5.8.4 - REMOTE KNOBS TREN BANG DIEU KHIEN
    //=========================================================================
    void setupRemoteKnob (LiveFineKnob& slider, juce::Label& caption,
                          const juce::String& text, juce::Colour colour)
    {
        caption.setText (text, juce::dontSendNotification);
        caption.setJustificationType (juce::Justification::centred);
        caption.setFont (juce::Font (juce::FontOptions (12.5f).withStyle ("Medium")));
        caption.setColour (juce::Label::textColourId, Col::textDim);
        caption.setInterceptsMouseClicks (false, false);
        addAndMakeVisible (caption);

        slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        slider.setRotaryParameters (juce::MathConstants<float>::pi * 1.22f,
                                    juce::MathConstants<float>::pi * 2.78f,
                                    true);
        slider.setColour (juce::Slider::thumbColourId, colour);
        slider.setColour (juce::Slider::textBoxTextColourId, Col::text);
        slider.setColour (juce::Slider::textBoxBackgroundColourId, Col::bg);
        slider.setColour (juce::Slider::textBoxOutlineColourId,
                          juce::Colours::transparentBlack);
        slider.setMouseDragSensitivity (260);
        addAndMakeVisible (slider);
    }

    /** Plugin cao do nam o slot 1 cua MIC, cung duong ma nut AUTO TUNE/BÈ dung. */
    juce::AudioProcessorParameter* findRetuneSpeedParameter() const
    {
        auto* plugin = harmonyPlugin();
        if (plugin == nullptr)
            return nullptr;

        // Uu tien khop chinh xac de khong nham Vibrato Speed / Tracking Speed.
        for (auto* p : plugin->getParameters())
        {
            if (p == nullptr) continue;
            const auto n = compactHarmonyParamName (p->getName (128));
            if (n == "retunespeed" || n == "retune")
                return p;
        }

        // Ban plugin them don vi/chu phu (vd "Retune Speed ms") van bat duoc.
        for (auto* p : plugin->getParameters())
        {
            if (p == nullptr) continue;
            const auto n = compactHarmonyParamName (p->getName (128));
            if (n.contains ("retunespeed"))
                return p;
        }

        return nullptr;
    }

    juce::AudioProcessorParameter* findFlexTuneParameter() const
    {
        auto* plugin = harmonyPlugin();
        if (plugin == nullptr)
            return nullptr;

        for (auto* p : plugin->getParameters())
        {
            if (p == nullptr) continue;
            const auto n = compactHarmonyParamName (p->getName (128));
            if (n == "flextune" || n == "flex")
                return p;
        }

        for (auto* p : plugin->getParameters())
        {
            if (p == nullptr) continue;
            const auto n = compactHarmonyParamName (p->getName (128));
            if (n.contains ("flextune"))
                return p;
        }

        return nullptr;
    }

    int findMicSendIndexToRole (Track::Role role) const
    {
        auto* mic = micTrack();
        auto* target = mixer.getTrackByRole (role);
        if (mic == nullptr || target == nullptr)
            return -1;

        for (int i = 0; i < mic->getNumSends(); ++i)
        {
            const auto s = mic->getSend (i);
            if (s.targetSlot < 0 && s.targetId == target->getId())
                return i;
        }

        return -1;
    }

    float getMicSendLevelForRole (Track::Role role) const
    {
        if (auto* mic = micTrack())
        {
            const int i = findMicSendIndexToRole (role);
            if (i >= 0)
                return mic->getSend (i).levelDb;
        }
        return -60.0f;
    }

    void setMicSendLevelToRole (Track::Role role, float dB)
    {
        if (auto* mic = micTrack())
        {
            const int i = findMicSendIndexToRole (role);
            if (i >= 0)
                mic->setSendLevelDb (i, juce::jlimit (-60.0f, 6.0f, dB));
        }
    }

    /** Dong bo tu mixer/plugin ve remote. Timer goi 4 Hz de neu anh keo fader
        trong F3 hoac keo Retune Speed ngay tren Auto-Tune thi num remote quay
        theo, khong bao gio hien mot gia tri khac voi am thanh that. */
    void refreshRemoteKnobs()
    {
        const juce::ScopedValueSetter<bool> guard (updatingRemoteKnobs, true);

        if (auto* p = findRetuneSpeedParameter())
        {
            tuneSpeedKnob.setEnabled (true);
            if (! tuneSpeedKnob.isMouseButtonDown())
                tuneSpeedKnob.setValue (p->getValue(), juce::dontSendNotification);
        }
        else
        {
            tuneSpeedKnob.setEnabled (false);
        }

        if (auto* p = findFlexTuneParameter())
        {
            flexTuneKnob.setEnabled (true);
            if (! flexTuneKnob.isMouseButtonDown())
                flexTuneKnob.setValue ((double) p->getValue() * 100.0,
                                       juce::dontSendNotification);
        }
        else
        {
            flexTuneKnob.setEnabled (false);
        }

        if (auto* mic = micTrack())
        {
            micVolumeKnob.setEnabled (true);
            if (! micVolumeKnob.isMouseButtonDown())
                micVolumeKnob.setValue (mic->getGainDb(), juce::dontSendNotification);
        }
        else
        {
            micVolumeKnob.setEnabled (false);
        }

        if (auto* music = nhacTrack())
        {
            musicVolumeKnob.setEnabled (true);
            if (! musicVolumeKnob.isMouseButtonDown())
                musicVolumeKnob.setValue (music->getGainDb(), juce::dontSendNotification);
        }
        else
        {
            musicVolumeKnob.setEnabled (false);
        }

        const int longSend  = findMicSendIndexToRole (Track::Role::ReverbLong);
        const int shortSend = findMicSendIndexToRole (Track::Role::ReverbShort);
        const int delaySend = findMicSendIndexToRole (Track::Role::Delay);
        reverbLongKnob .setEnabled (longSend  >= 0);
        reverbShortKnob.setEnabled (shortSend >= 0);
        delayKnob      .setEnabled (delaySend >= 0);

        if (longSend >= 0 && ! reverbLongKnob.isMouseButtonDown())
            reverbLongKnob.setValue (getMicSendLevelForRole (Track::Role::ReverbLong),
                                     juce::dontSendNotification);
        if (shortSend >= 0 && ! reverbShortKnob.isMouseButtonDown())
            reverbShortKnob.setValue (getMicSendLevelForRole (Track::Role::ReverbShort),
                                      juce::dontSendNotification);
        if (delaySend >= 0 && ! delayKnob.isMouseButtonDown())
            delayKnob.setValue (getMicSendLevelForRole (Track::Role::Delay),
                                juce::dontSendNotification);

        // 01/10: num da gan -> hien gia tri / bat-tat theo dich da gan.
        refreshBoundKnob ("kMusic",    musicVolumeKnob);
        refreshBoundKnob ("kMic",      micVolumeKnob);
        refreshBoundKnob ("kRevLong",  reverbLongKnob);
        refreshBoundKnob ("kRevShort", reverbShortKnob);
        refreshBoundKnob ("kDelay",    delayKnob);

        tuneSpeedKnob.repaint();
        flexTuneKnob.repaint();
    }

    //==========================================================================
    //  01/10: GAN NUT - thuc thi / doc trang thai theo Binding
    //==========================================================================
    Track* boundTrack (const livent::buttonmap::Binding& b) const
    {
        return livent::buttonmap::resolveTrack (mixer, b);
    }

    bool boundState (const livent::buttonmap::Binding& b) const
    {
        using livent::buttonmap::Act;
        auto* t = boundTrack (b);
        if (t == nullptr)
            return false;

        switch (b.act)
        {
            case Act::ToggleInsert:
            {
                auto& chain = t->getInserts();
                return ! chain.isSlotEmpty (b.slot) && ! chain.isMissing (b.slot) && ! chain.isBypassed (b.slot);
            }
            case Act::ToggleTrack:  return t->isMonitorOn();
            case Act::ToggleAllSends: return t->areAllSendsOn();
            case Act::ToggleHarmony: return isHarmonyTriggerAllOn();   // 11h: be trong VST da gan
            case Act::ToggleSend:
            {
                const int i = livent::buttonmap::resolveSendIndex (mixer, *t, b);
                return i >= 0 && t->getSend (i).enabled;
            }
            default: break;
        }
        return false;
    }

    /** Bam nut da gan. Tra false neu nut chua gan (de chay kieu cu). */
    bool pressBound (const char* id)
    {
        using livent::buttonmap::Act;
        const auto b = buttonMap.get (id);
        if (b.isDefault())
            return false;

        if (auto* t = boundTrack (b))
        {
            switch (b.act)
            {
                case Act::ToggleInsert:
                {
                    auto& chain = t->getInserts();
                    if (! chain.isSlotEmpty (b.slot) && ! chain.isMissing (b.slot))
                        chain.setBypassed (b.slot, ! chain.isBypassed (b.slot));
                    break;
                }
                case Act::ToggleTrack:
                    t->setMonitor (! t->isMonitorOn());
                    break;
                case Act::ToggleHarmony:   // 11h: chi bat/tat be (Trigger All), plugin van chay
                    toggleHarmonyTriggerAll();
                    break;
                case Act::ToggleAllSends:
                    t->setAllSendsOn (! t->areAllSendsOn());
                    break;
                case Act::ToggleSend:
                {
                    const int i = livent::buttonmap::resolveSendIndex (mixer, *t, b);
                    if (i >= 0)
                        t->setSendEnabled (i, ! t->getSend (i).enabled);
                    break;
                }
                default: break;
            }
        }

        refreshLiveButtons();
        announceChange();
        return true;
    }

    void paintBound (const char* id, juce::TextButton& button)
    {
        const auto b = buttonMap.get (id);
        if (! b.isDefault())
            paintLiveButton (button, boundState (b));
    }

    /** Num da gan: ghi gia tri vao dich. false = num chua gan. */
    bool applyBoundKnob (const char* id, double dB)
    {
        using livent::buttonmap::Act;
        const auto b = buttonMap.get (id);
        if (b.isDefault())
            return false;

        if (auto* t = boundTrack (b))
        {
            if (b.act == Act::TrackVolume)
                t->setGainDb ((float) dB);
            else if (b.act == Act::SendLevel)
            {
                const int i = livent::buttonmap::resolveSendIndex (mixer, *t, b);
                if (i >= 0)
                    t->setSendLevelDb (i, juce::jlimit (-60.0f, 6.0f, (float) dB));
            }
        }
        return true;
    }

    void refreshBoundKnob (const char* id, juce::Slider& knob)
    {
        using livent::buttonmap::Act;
        const auto b = buttonMap.get (id);
        if (b.isDefault())
            return;

        auto* t = boundTrack (b);
        double value = 0.0;
        bool ok = false;
        if (t != nullptr && b.act == Act::TrackVolume)
        {
            value = t->getGainDb();
            ok = true;
        }
        else if (t != nullptr && b.act == Act::SendLevel)
        {
            const int i = livent::buttonmap::resolveSendIndex (mixer, *t, b);
            if (i >= 0)
            {
                value = t->getSend (i).levelDb;
                ok = true;
            }
        }

        knob.setEnabled (ok);
        if (ok && ! knob.isMouseButtonDown())
            knob.setValue (value, juce::dontSendNotification);
    }

    /** Song tren nut: nut da gan nhay theo track da gan khi dang BAT. */
    std::function<float()> boundLevel (const char* id, std::function<float()> fallback)
    {
        return [this, id, fallback]
        {
            using livent::buttonmap::Act;
            const auto b = buttonMap.get (id);
            if (b.isDefault())
                return fallback ? fallback() : 0.0f;
            auto* t = boundTrack (b);
            if (t == nullptr)
                return 0.0f;
            if (b.act == Act::ToggleTrack)
                return t->getMeterLevel();
            return boundState (b) ? t->getMeterLevel() : 0.0f;
        };
    }

    //==========================================================================
    //  02/10: PRESET - menu + luu / doi ten / xuat / nhap
    //==========================================================================
    void updatePresetButton()
    {
        const int c = presetBank.current;
        const auto text = (c >= 0 ? presetBank[c].name : livent::vn ("Preset")) + livent::vn (" ▾");
        presetButton.setButtonText (text);
        const auto col = c >= 0 ? livent::presets::colourFor (c) : Col::accent;
        presetButton.setToggleState (c >= 0, juce::dontSendNotification);
        presetButton.setColour (juce::TextButton::buttonOnColourId, col.withAlpha (0.28f));
        presetButton.setColour (juce::TextButton::textColourOnId, col.brighter (0.4f));
        presetButton.repaint();
        presetStrip.refresh();
    }

    /** 07/10: chuot phai mot o che do tren dai: Luu / Doi ten / Mac dinh / Xuat-Nhap / Xoa. */
    /*  07/10 _F: dong "Auto-Tune Modern Scale" + cong tac trong menu chuot
        phai nut Dan ca (demo B). CUNG mot cai dat voi Cai dat > Auto-Tune:
        dung Modern Scale - gat o dau thi cho kia doi theo.  */
    struct ModernScaleMenuItem final : public juce::PopupMenu::CustomComponent
    {
        ModernScaleMenuItem() : juce::PopupMenu::CustomComponent (true) {}

        void getIdealSize (int& w, int& h) override { w = 300; h = 50; }

        void paint (juce::Graphics& g) override
        {
            auto r = getLocalBounds().reduced (12, 5);
            if (isItemHighlighted())
            {
                g.setColour (juce::Colour (0xff1e3a2f));
                g.fillRect (getLocalBounds());
            }
            const bool on = TonePush::usesModernScale();

            auto sw = r.removeFromRight (36).withSizeKeepingCentre (36, 20).toFloat();
            g.setColour (on ? juce::Colour (0xff2fa58f) : juce::Colour (0xff4a5059));
            g.fillRoundedRectangle (sw, 10.0f);
            g.setColour (juce::Colours::white);
            const float k = 16.0f;
            g.fillEllipse (on ? sw.getRight() - k - 2.0f : sw.getX() + 2.0f, sw.getY() + 2.0f, k, k);

            r.removeFromRight (8);
            auto top = r.removeFromTop (22);
            g.setColour (Col::text);
            g.setFont (juce::Font (juce::FontOptions (14.5f)));
            g.drawText (juce::String::fromUTF8 ("Auto-Tune Modern Scale"), top, juce::Justification::centredLeft, true);
            g.setColour (Col::textDim);
            g.setFont (juce::Font (juce::FontOptions (11.5f)));
            g.drawText (livent::vn ("Bật khi Auto-Tune để Scales: Modern (Dân ca gửi Dorian)"),
                        r, juce::Justification::centredLeft, true);
        }
    };

    /** 07/10 _F: gat Modern Scale (tu menu Dan ca). Dang o Dan ca thi gui lai
        Dorian ngay vao dung num moi; che do khac van Major / Minor theo bai. */
    void toggleModernScaleFromMenu()
    {
        if (! TonePush::saveModernScalePreference (! TonePush::usesModernScale()))
        {
            livent::alert (livent::vn ("Không lưu được cài đặt"),
                           livent::vn ("Không ghi được tùy chọn Modern Scale vào thư mục cài đặt."));
            return;
        }
        statusLabel.setText (TonePush::usesModernScale()
                                 ? livent::vn ("Auto-Tune: đã BẬT Modern Scale (Dân ca gửi Dorian, chế độ khác gửi Major / Minor theo bài).")
                                 : livent::vn ("Auto-Tune: đã TẮT Modern Scale (dùng Scale Legacy)."),
                             juce::dontSendNotification);
        if (TonePush::usesFolkScale())
            folkModeChanged();   // gui lai Dorian vao num Scale moi
        else if (! followsPluginTone())
            sendShiftedKey();    // gui lai tone bai (Major / Minor goc) vao num moi
    }

    void showPresetChipMenu (int i)
    {
        using namespace livent::presets;
        if (! juce::isPositiveAndBelow (i, kCount)) return;
        const auto name = presetBank[i].name;
        juce::PopupMenu m;
        m.addSectionHeader (livent::vn ("Chế độ \"") + name + livent::vn ("\"   (Ctrl+") + juce::String (i + 1) + ")");
        m.addItem (2, livent::vn ("Lưu vào ô này"));
        m.addItem (3, livent::vn ("Đổi tên..."));
        if (isFolkName (name))
        {
            // 07/10 _F: chi nut Dan ca co dong nay (demo B)
            m.addSeparator();
            juce::PopupMenu::Item modern;
            modern.itemID = 8;
            modern.customComponent = new ModernScaleMenuItem();
            m.addItem (std::move (modern));
        }
        m.addSeparator();
        juce::PopupMenu more;
        // 12r: giu lai - bo che do anh chinh san se co trong moi du an moi tren may nay.
        more.addItem (4, livent::vn ("Làm bộ mặc định cho dự án mới"), presetBank.hasAny());
        more.addSeparator();
        more.addItem (5, livent::vn ("Xuất ra file..."), presetBank.hasAny());
        more.addItem (6, livent::vn ("Nhập từ file..."));
        more.addSeparator();
        more.addItem (7, livent::vn ("Xóa thông số ô này"), ! presetBank[i].isEmpty());
        m.addSubMenu (livent::vn ("Thêm"), more);

        juce::Component::SafePointer<TonePanel> safe (this);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetScreenArea (presetStrip.cellScreenBounds (i)),
            [safe, i] (int r)
            {
                if (safe == nullptr || r <= 0) return;
                switch (r)
                {
                    case 2: safe->savePresetTo (i); break;
                    case 3: safe->renamePreset (i); break;
                    case 8: safe->toggleModernScaleFromMenu(); break;
                    case 4:
                    {
                        const bool ok = safe->presetBank.saveToFile (Bank::machineDefaultFile());
                        safe->statusLabel.setText (ok ? livent::vn ("✓ Dự án mới trên máy này sẽ có sẵn bộ chế độ này.")
                                                      : livent::vn ("Không ghi được file mặc định."),
                                                   juce::dontSendNotification);
                        break;
                    }
                    case 5: safe->exportPresets(); break;
                    case 6: safe->importPresets(); break;
                    case 7:
                    {
                        auto nm = safe->presetBank[i].name;
                        safe->presetBank[i] = livent::presets::Preset{};
                        safe->presetBank[i].name = nm;
                        if (safe->presetBank.current == i)
                            safe->presetBank.current = -1;
                        safe->updatePresetButton();
                        if (safe->onPresetsChanged) safe->onPresetsChanged();
                        break;
                    }
                    default: break;
                }
            });
    }

    void savePresetTo (int i)
    {
        // 16/10: luu thang vao o, khong hoi ghi de; bao ket qua bang dong trang thai.
        const auto name = presetBank[i].name;
        presetBank[i] = livent::presets::capture (mixer, name);
        presetBank.current = i;
        int vstCount = 0, b32Count = 0;
        for (const auto& ts : presetBank[i].tracks)
            for (const auto& sl : ts.slots)
            {
                ++vstCount;
                if (sl.identity.endsWith ("|B32")) ++b32Count;
            }
        statusLabel.setText (juce::String (juce::CharPointer_UTF8 ("\xe2\x9c\x93 ")) + livent::vn ("Đã lưu \"") + name
                                 + livent::vn ("\" · ") + juce::String (vstCount) + " VST"
                                 + (b32Count > 0 ? livent::vn (" (có ") + juce::String (b32Count) + livent::vn (" VST 32-bit)")
                                                 : juce::String()),
                             juce::dontSendNotification);
        updatePresetButton();
        if (onPresetsChanged)
            onPresetsChanged();
    }

    void renamePreset (int i)
    {
        auto* w = new juce::AlertWindow (livent::vn ("Đổi tên preset"),
                                         livent::vn ("Tên mới cho preset số ") + juce::String (i + 1) + ":",
                                         juce::MessageBoxIconType::NoIcon);
        w->addTextEditor ("name", presetBank[i].name);
        w->addButton (livent::vn ("Đổi tên"), 1, juce::KeyPress (juce::KeyPress::returnKey));
        w->addButton (livent::vn ("Hủy"), 0, juce::KeyPress (juce::KeyPress::escapeKey));

        juce::Component::SafePointer<TonePanel> safe (this);
        w->enterModalState (true, juce::ModalCallbackFunction::create ([safe, w, i] (int r)
        {
            if (safe == nullptr || r != 1)
                return;
            const auto name = w->getTextEditorContents ("name").trim().substring (0, 40);
            if (name.isEmpty())
                return;
            safe->presetBank[i].name = name;
            safe->updatePresetButton();
            safe->syncFolkWithPreset();   // 06/10: doi ten thanh / khoi Dan ca
            if (safe->onPresetsChanged)
                safe->onPresetsChanged();
        }), true);
    }

    void exportPresets()
    {
        presetChooser = std::make_unique<juce::FileChooser> (livent::vn ("Xuất bộ preset"),
            juce::File::getSpecialLocation (juce::File::userDesktopDirectory).getChildFile ("presets.ntpreset"),
            "*.ntpreset");
        juce::Component::SafePointer<TonePanel> safe (this);
        presetChooser->launchAsync (juce::FileBrowserComponent::saveMode
                                    | juce::FileBrowserComponent::canSelectFiles
                                    | juce::FileBrowserComponent::warnAboutOverwriting,
            [safe] (const juce::FileChooser& fc)
            {
                if (safe == nullptr) return;
                auto f = fc.getResult();
                if (f == juce::File()) return;
                if (! f.hasFileExtension ("ntpreset"))
                    f = f.withFileExtension ("ntpreset");
                const bool ok = safe->presetBank.saveToFile (f);
                livent::alert (livent::vn ("Xuất preset"),
                               ok ? livent::vn ("Đã xuất:\n") + f.getFullPathName()
                                    + livent::vn ("\n\nMuốn khách cài xong có sẵn: đổi tên thành presets.ntpreset "
                                                  "và đặt cạnh LiveNT.exe trong thư mục xuất bản trước khi tạo bộ cài.")
                                  : livent::vn ("Không ghi được file."));
            });
    }

    void importPresets()
    {
        presetChooser = std::make_unique<juce::FileChooser> (livent::vn ("Nhập bộ preset"),
            juce::File::getSpecialLocation (juce::File::userDesktopDirectory), "*.ntpreset");
        juce::Component::SafePointer<TonePanel> safe (this);
        presetChooser->launchAsync (juce::FileBrowserComponent::openMode
                                    | juce::FileBrowserComponent::canSelectFiles,
            [safe] (const juce::FileChooser& fc)
            {
                if (safe == nullptr) return;
                const auto f = fc.getResult();
                if (! f.existsAsFile()) return;
                if (! safe->presetBank.loadFromFile (f))
                {
                    livent::alert (livent::vn ("Nhập preset"), livent::vn ("File này không phải bộ preset."));
                    return;
                }
                safe->updatePresetButton();
                if (safe->onPresetsChanged)
                    safe->onPresetsChanged();
                livent::alert (livent::vn ("Nhập preset"),
                               livent::vn ("Đã nhập bộ preset vào dự án này."));
            });
    }

    /*  06/10: BANG PRESET GON (PresetPopup.h) - 5 dong + "Luu vao day" khi
        di chuot + nut lon "Luu vao preset dang chon" + "Quan ly". Phan doi
        ten / xuat / nhap / mac dinh don vao showPresetManageMenu().  */
    void showPresetMenu()
    {
        auto popup = std::make_unique<livent::presets::PresetPopup> (presetBank);
        juce::Component::SafePointer<TonePanel> safe (this);
        popup->onApply  = [safe] (int i) { if (safe != nullptr) safe->applyPreset (i); };
        popup->onSaveTo = [safe] (int i) { if (safe != nullptr && i >= 0) safe->savePresetTo (i); };
        popup->onManage = [safe] { if (safe != nullptr) safe->showPresetManageMenu(); };
        auto& box = juce::CallOutBox::launchAsynchronously (std::move (popup), presetButton.getScreenBounds(), nullptr);
        box.setAlwaysOnTop (true);    // bang dieu khien co the dang "noi tren cung"
        box.toFront (true);
    }

    void showPresetManageMenu()
    {
        using namespace livent::presets;
        juce::PopupMenu menu;
        juce::PopupMenu rename;
        for (int i = 0; i < kCount; ++i)
            rename.addItem (200 + i, juce::String (i + 1) + ".  " + presetBank[i].name);
        menu.addSectionHeader (livent::vn ("Quản lý preset"));
        menu.addSubMenu (livent::vn ("Đổi tên preset"), rename);
        menu.addSeparator();
        menu.addItem (300, livent::vn ("Xuất bộ preset ra file..."), presetBank.hasAny());
        menu.addItem (301, livent::vn ("Nhập bộ preset từ file..."));

        juce::Component::SafePointer<TonePanel> safe (this);
        menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&presetButton),
            [safe] (int r)
            {
                if (safe == nullptr || r <= 0) return;
                if (r >= 1 && r <= kCount)           safe->applyPreset (r - 1);
                else if (r >= 100 && r < 100 + kCount) safe->savePresetTo (r - 100);
                else if (r >= 200 && r < 200 + kCount) safe->renamePreset (r - 200);
                else if (r == 300) safe->exportPresets();
                else if (r == 301) safe->importPresets();
            });
    }

    /** 15/10: goi 4 lan/giay. Xem setAutoVangByMusic(). */
    void autoVangFollowMusic()
    {
        if (! autoVangByMusic)
            return;
        auto* mic = micTrack();
        auto* nhac = nhacTrack();
        if (mic == nullptr || nhac == nullptr)
            return;
        // Nut Vang da duoc gan sang viec khac (Gan nut) -> khong tu dong dung vao Send nua.
        if (! buttonMap.get ("vang").isDefault())
            return;

        // Muc dong ho track NHAC (da tinh fader, M, nut Loa). > -50 dBFS = co nhac.
        constexpr float musicThreshold = 0.00316f;
        /*  15/10 (anh chot 12:15): BAT Vang khi
              - DAW da DO XONG Key/Scale cua bai dang mo (VPS / Auto-Key) va co nhac ~0,5 giay, hoac
              - may chu do tong loi / cham: co nhac lien tuc ~5 giay thi tu bat.
            TAT khi nhac im ~3 giay. Bai da do xong ma nhac dung roi chay lai (mang lag,
            tam dung) thi bat lai sau ~0,5 giay, khong phai doi.  */
        constexpr int readyTicks = 2, fallbackTicks = 20, offTicks = 12;   // 4 Hz
        if (nhac->getMeterLevel() > musicThreshold)
        { autoVangSilentTicks = 0; autoVangMusicTicks = juce::jmin (autoVangMusicTicks + 1, 1000); }
        else
        { autoVangMusicTicks = 0; autoVangSilentTicks = juce::jmin (autoVangSilentTicks + 1, 1000); }

        int want = -1;
        if ((autoVangKeyReady && autoVangMusicTicks >= readyTicks) || autoVangMusicTicks >= fallbackTicks)
            want = 1;
        else if (autoVangSilentTicks >= offTicks) want = 0;
        if (want < 0 || want == autoVangLastDecision)
            return;   // chi doi luc nhac bat dau / dung -> bam tay giua chung van giu

        autoVangLastDecision = want;
        if (mic->areAllSendsOn() != (want == 1))
        {
            mic->setAllSendsOn (want == 1);
            refreshLiveButtons();
            announceChange();
        }
    }

    void toggleMicSends()
    {
        if (auto* t = micTrack())
            t->setAllSendsOn (! t->areAllSendsOn());

        refreshLiveButtons();
        announceChange();
    }

    void toggleMonitor (Track* t, juce::TextButton&)
    {
        if (t != nullptr)
            t->setMonitor (! t->isMonitorOn());

        refreshLiveButtons();
        announceChange();
    }

    /** 14/10 TIET KIEM CPU: VST doi tone tren track NHAC vua duoc nap (mo du an / thay plugin) -> doi no on dinh ~3 giay
        (cho nap xong trang thai), roi neu tong tren man hinh VA so that trong VST deu = 0 thi tat VST. Moi lan nap chi lam MOT lan,
        nen nut Beat bam tay sau do van co hieu luc cho toi lan doi tong ke tiep (xem TonePush::setSemitonesOnTrack).  */
    void autoSyncMusicVstPower()
    {
        auto* nhac = nhacTrack();
        if (nhac == nullptr)
        {
            musicVstSignature = 0; musicVstStableTicks = 0; musicVstSynced = false;
            return;
        }

        auto& chain = nhac->getInserts();
        std::uint64_t signature = 1469598103934665603ull;
        for (int i = 0; i < chain.getNumPlugins(); ++i)
            signature = (signature ^ chain.getInstanceId (i)) * 1099511628211ull;

        if (signature != musicVstSignature)
        {
            musicVstSignature = signature; musicVstStableTicks = 0; musicVstSynced = false;
            return;
        }
        if (musicVstSynced || ++musicVstStableTicks < 12)
            return;

        musicVstSynced = true;
        if (TonePush::powerOffMusicVstIfZero (*nhac, semitoneShift()))
        {
            refreshLiveButtons();
            announceChange();
        }
    }

    /** V0.6.7.9c: bat/tat o insert cua track NHAC (slot 0 = VST so 1, plugin doi tone). */
    void toggleMusicInsert (int slot)
    {
        if (auto* t = nhacTrack())
        {
            auto& chain = t->getInserts();
            if (! chain.isSlotEmpty (slot) && ! chain.isMissing (slot))
                chain.setBypassed (slot, ! chain.isBypassed (slot));
        }

        refreshLiveButtons();
        announceChange();
    }

    /** 11/10: nut TUNE (khi chua gan): bat/tat o Auto-Tune o track bat ky (mac dinh MIC o 1). */
    void toggleAutoTuneInsert()
    {
        const auto at = livent::vstctl::findAutoTune (mixer, buttonMap, micTrack());
        if (at.track != nullptr)
        {
            auto& chain = at.track->getInserts();
            if (! chain.isSlotEmpty (at.slot) && ! chain.isMissing (at.slot))
                chain.setBypassed (at.slot, ! chain.isBypassed (at.slot));
        }
        refreshLiveButtons();
        announceChange();
    }

    bool autoTuneInsertOn() const
    {
        const auto at = livent::vstctl::findAutoTune (mixer, buttonMap, micTrack());
        if (at.track == nullptr)
            return false;
        auto& chain = at.track->getInserts();
        return ! chain.isSlotEmpty (at.slot) && ! chain.isMissing (at.slot) && ! chain.isBypassed (at.slot);
    }

    /** slot dem tu 0. Nut TUNE = o so 1 tren man hinh = slot 0. */
    void toggleMicInsert (int slot)
    {
        if (auto* t = micTrack())
        {
            auto& chain = t->getInserts();

            /*  O trong thi khong lam gi ca. Bat/tat mot o chua co plugin la
                vo nghia, va neu cu lat trang thai thi lan sau anh nhet plugin
                vao no se im tit ma khong hieu tai sao.  */
            if (! chain.isSlotEmpty (slot) && ! chain.isMissing (slot))
                chain.setBypassed (slot, ! chain.isBypassed (slot));
        }

        refreshLiveButtons();
        announceChange();
    }

    /*  MOC 36: bao cho phan con lai cua giao dien biet ma ve lai.

        Bay nut nay chi la LOI TAT -- chung sua dung nhung cong tac ma anh
        van bam duoc o cho cu (nut Loa tren dong track, nut nguon o o insert,
        nut nguon o muc Send trong Inspector). Sua bang loi tat ma cho cu
        khong doi theo thi giao dien noi hai dang khac nhau ve cung mot thu,
        va anh khong biet tin cai nao.

        Nen sau moi lan bam, bao ra ngoai de MainComponent ve lai dong track
        va bang Inspector. Nhin dau cung thay dung mot su that.  */
    void announceChange()
    {
        if (onLiveStateChanged)
            onLiveStateChanged();
    }

    /** Doc trang thai that tu mixer roi to mau lai ca bay nut. */
    void refreshLiveButtons()
    {
        auto* mic  = micTrack();
        auto* nhac = nhacTrack();

        paintLiveButton (vangButton, mic  != nullptr && mic->areAllSendsOn());
        paintLiveButton (micButton,  mic  != nullptr && mic->isMonitorOn());
        paintLiveButton (nhacButton, nhac != nullptr && nhac->isMonitorOn());

        auto insertOn = [mic] (int slot)
        {
            if (mic == nullptr)
                return false;

            auto& chain = mic->getInserts();

            //  O trong -> coi nhu dang tat, hien mau do
            return ! chain.isSlotEmpty (slot)
                && ! chain.isMissing (slot)
                && ! chain.isBypassed (slot);
        };

        paintLiveButton (tuneButton,   autoTuneInsertOn());   // 11/10: theo Auto-Tune o track bat ky

        // V0.6.7.9c: nut nguon Tone nhac = VST so 1 cua track NHAC
        {
            bool has = false, on = false;
            juce::String name;
            if (nhac != nullptr)
            {
                auto& chain = nhac->getInserts();
                has  = ! chain.isSlotEmpty (0) && ! chain.isMissing (0);
                on   = has && ! chain.isBypassed (0);
                name = has ? chain.getPluginName (0) : juce::String();
            }
            toneVstPowerButton.setEnabled (has);
            beatButton.setEnabled (has);
            paintLiveButton (beatButton, on);
            if (toneVstPowerButton.getToggleState() != on)
            {
                toneVstPowerButton.setToggleState (on, juce::dontSendNotification);
                toneVstPowerButton.repaint();
            }
            const auto tip = has ? livent::vn ("Bật/tắt VST số 1 của track NHẠC (tự tắt khi tông = 0, tự bật khi bấm + / −): ") + name
                                 : livent::vn ("Track NHẠC chưa có VST ở ô số 1");
            if (toneVstPowerButton.getTooltip() != tip)
            {
                toneVstPowerButton.setTooltip (tip);
                beatButton.setTooltip (tip);
            }
        }

        if (harmonyButtonAllowed || verticalLayout)
            paintLiveButton (harmonyButton, isHarmonyTriggerAllOn());
        paintLiveButton (lofiButton,   insertOn (slotLofi()));
        paintLiveButton (remix1Button, insertOn (slotRemix1()));
        paintLiveButton (remix2Button, insertOn (slotRemix2()));
        paintLiveButton (babyButton,   insertOn (slotBaby()));

        // 01/10: nut da gan -> to mau theo trang thai THAT cua dich da gan.
        paintBound ("vang",   vangButton);
        paintBound ("nhac",   nhacButton);
        paintBound ("mic",    micButton);
        paintBound ("tune",   tuneButton);
        paintBound ("lofi",   lofiButton);
        paintBound ("remix1", remix1Button);
        paintBound ("remix2", remix2Button);
        paintBound ("baby",   babyButton);
        if (harmonyButtonAllowed || verticalLayout)
            paintBound ("harmony", harmonyButton);
        {
            const auto b = buttonMap.get ("beat");
            if (! b.isDefault())
            {
                auto* t = boundTrack (b);
                const bool has = t != nullptr
                              && (b.act != livent::buttonmap::Act::ToggleInsert
                                  || (! t->getInserts().isSlotEmpty (b.slot) && ! t->getInserts().isMissing (b.slot)));
                const bool on = has && boundState (b);
                toneVstPowerButton.setEnabled (has);
                beatButton.setEnabled (has);
                paintLiveButton (beatButton, on);
                if (toneVstPowerButton.getToggleState() != on)
                {
                    toneVstPowerButton.setToggleState (on, juce::dontSendNotification);
                    toneVstPowerButton.repaint();
                }
            }
        }
    }

    //=========================================================================
    void updateChildVisibility()
    {
        // V5.7: mat chinh chi de lai thu can bam khi live. Logic cu van duoc
        // giu an de project cu/auto-watch/timeline khong bi dut.
        for (auto* c : { (juce::Component*) &header,        (juce::Component*) &urlBox,
                         (juce::Component*) &pasteButton,   (juce::Component*) &detectButton,
                         (juce::Component*) &linkToggle,    (juce::Component*) &autoButton,
                         (juce::Component*) &autoShiftButton,(juce::Component*) &targetCaption,
                         (juce::Component*) &targetBox,     (juce::Component*) &toneModeButton,
                         (juce::Component*) &resultLabel,   (juce::Component*) &statusLabel,
                         (juce::Component*) &timelineLabel, (juce::Component*) &clock })
            c->setVisible (false);

        // V6.3.5: meter tong chi hien khi hang 7 num dang thu gon va nguoi
        // dung bat tuy chon trong Hien thi. Khi mo 7 num, cac meter canh num
        // da du thong tin nen hai cot nay tu an.
        const bool showCompactMeters = false;   // V0.6.7.9e: song nam tren nut
        nhacMeter.setVisible (showCompactMeters);
        micMeter.setVisible (showCompactMeters);
        toneCaption.setVisible (false);

        for (auto* m : knobMeters())
            m->setVisible (knobsExpanded || (verticalLayout && ! noVerticalKnobs()));

        knobFoldButton.setVisible (! verticalLayout && ! foldOnStatusBar());   // doc: num gan co dinh, khong can nut gap
        statusFold.setVisible (foldOnStatusBar());   // 15/10: ca Doc (nut ⌄ tren thanh tieu de)
        statusFold.setExpanded (knobsExpanded);
        knobFoldButton.setExpanded (knobsExpanded);

        for (auto* c : { (juce::Component*) &nowPlaying,      (juce::Component*) &nowPlayingClockLabel,
                         (juce::Component*) &keyMinusButton,
                         (juce::Component*) &keyDisplayButton,(juce::Component*) &keyPlusButton,
                         (juce::Component*) &scaleToggleButton,
                         (juce::Component*) &toneMinusButton, (juce::Component*) &toneValueLabel,
                         (juce::Component*) &tonePlusButton,
                         (juce::Component*) &vangButton,      (juce::Component*) &tuneButton,
                         (juce::Component*) &nhacButton,      (juce::Component*) &micButton,
                         (juce::Component*) &lofiButton,      (juce::Component*) &remix1Button,
                         (juce::Component*) &remix2Button,    (juce::Component*) &babyButton,
                         (juce::Component*) &tuneSpeedCaption,(juce::Component*) &tuneSpeedKnob,
                         (juce::Component*) &musicVolumeCaption,(juce::Component*) &musicVolumeKnob,
                         (juce::Component*) &micVolumeCaption,(juce::Component*) &micVolumeKnob,
                         (juce::Component*) &flexTuneCaption,(juce::Component*) &flexTuneKnob,
                         (juce::Component*) &delayCaption,(juce::Component*) &delayKnob,
                         (juce::Component*) &reverbLongCaption,(juce::Component*) &reverbLongKnob,
                         (juce::Component*) &reverbShortCaption,(juce::Component*) &reverbShortKnob })
            c->setVisible (true);

        presetButton.setVisible (! verticalLayout && compactMode);
        presetStrip.setVisible (! compactMode);

        // V6.4.0: Thu Am chi con o thanh tren.
        recButton.setVisible (false);

        if ((! knobsExpanded && ! verticalLayout) || (verticalLayout && noVerticalKnobs()))   // V0.6.7.9c: doc luon hien num (tru ban VBK: doc gon, bo num)
        {
            for (auto* c : { (juce::Component*) &tuneSpeedCaption, (juce::Component*) &tuneSpeedKnob,
                             (juce::Component*) &musicVolumeCaption, (juce::Component*) &musicVolumeKnob,
                             (juce::Component*) &micVolumeCaption, (juce::Component*) &micVolumeKnob,
                             (juce::Component*) &flexTuneCaption, (juce::Component*) &flexTuneKnob,
                             (juce::Component*) &delayCaption, (juce::Component*) &delayKnob,
                             (juce::Component*) &reverbLongCaption, (juce::Component*) &reverbLongKnob,
                             (juce::Component*) &reverbShortCaption, (juce::Component*) &reverbShortKnob })
                c->setVisible (false);
        }

        // V5.8: hai nut nay da len thanh window; giu object de callback/compatibility
        // nhung khong de no nhan focus hay ve de len hang dieu khien.
        // V0.6.7.9b: bo cuc doc dua Luu bai / Danh sach vao luoi nut; Delay an.
        saveSongButton.setVisible (false);
        songListButton.setVisible (false);
        saveSongButton.getProperties().set ("liveChipStyle", true);
        songListButton.getProperties().set ("liveChipStyle", true);
        if (verticalLayout)
        {
            // 30/09 (anh chot): doc hien Delay, an Flex tune (chinh trong Auto-Tune).
            flexTuneCaption.setVisible (false);
            flexTuneKnob.setVisible (false);
            flexMeter.setVisible (false);
        }
        else
        {
            saveSongButton.setButtonText (livent::vn ("LƯU BÀI"));
            songListButton.setButtonText (livent::vn ("DANH SÁCH"));
        }

        autoTuneButton.setVisible (false);   // V5.8.7: bỏ nút AUTO TUNE khỏi remote
        harmonyButton.setVisible (harmonyButtonAllowed || verticalLayout);
        toneVstPowerButton.setVisible (false);   // 15/10: bo nut nguon (doi tong nhac da tu dong)
        beatButton.setVisible (beatAsText());
        // LaughBoard đang nằm trong LaughWindow/Viewport khi popup mở; không
        // ép visible theo layout TonePanel ở đây.
        refreshLiveButtons();
        refreshRemoteKnobs();
        resized();
    }

    int getSelectedTrackId() const
    {
        const int at = targetBox.getSelectedId() - 1;
        return juce::isPositiveAndBelow (at, trackIds.size()) ? trackIds[at] : -1;
    }

    //=========================================================================
    /*  V5.4 - NÚT BÈ ĐI THẲNG VÀO AUTO-TUNE 11

        Đã bắt được chính xác trên Auto-Tune Pro 11 của anh:
          #127 = HP All Voices Latch
          #148 = HP Voice 1 Trigger
          #149 = HP Voice 2 Trigger
          #150 = HP Voice 3 Trigger
          #151 = HP Voice 4 Trigger
          #152 = HP All Voices Trigger

        Vì vậy bỏ toàn bộ cơ chế "học núm" V5.3. Không MIDI, không giả click GUI,
        không cần mở cửa sổ Auto-Tune. Ưu tiên tìm theo TÊN để chịu được bản
        plugin đổi index; chỉ fallback #127/#152 khi đúng Auto-Tune và số
        parameter đủ lớn.

        Khi bấm BÈ:
          - ép All Voices Latch = ON (để Trigger All giữ trạng thái);
          - đổi HP All Voices Trigger 0 <-> 1;
          - nếu plugin không tự phản ánh ra 4 voice ngay, đồng bộ 4 Voice Trigger
            theo cùng trạng thái làm fallback.

        Đây là đường điều khiển host parameter giống Key/Scale hiện tại. */

    static juce::String compactHarmonyParamName (juce::String name)
    {
        return name.toLowerCase().removeCharacters (" _-./\\");
    }

    juce::AudioPluginInstance* harmonyPlugin() const
    {
        // 01/10: nut Tune da gan vao o VST khac (vd Group Vocal) -> Auto-Tune o do.
        const auto b = buttonMap.get ("tune");
        if (b.act == livent::buttonmap::Act::ToggleInsert)
        {
            auto* t = boundTrack (b);
            return t != nullptr ? t->getInserts().getPlugin (b.slot) : nullptr;
        }
        // 11/10: Auto-Tune co the nam o track bat ky (Group...) - xem VstControl.h findAutoTune()
        return livent::vstctl::findAutoTune (mixer, buttonMap, micTrack()).plugin;
    }

    /** 11h: plugin ma nut BE bat/tat Trigger All. Gan rieng (Act::ToggleHarmony) thi dung
        dung o da gan; khong gan thi theo nut Tune nhu cu. Retune / Flex van theo harmonyPlugin(). */
    juce::AudioPluginInstance* bePlugin() const
    {
        const auto b = buttonMap.get ("harmony");
        if (b.act == livent::buttonmap::Act::ToggleHarmony)
        {
            auto* t = boundTrack (b);
            if (t == nullptr || t->getInserts().isSlotEmpty (b.slot) || t->getInserts().isMissing (b.slot))
                return nullptr;
            return t->getInserts().getPlugin (b.slot);
        }
        return harmonyPlugin();
    }

    juce::AudioProcessorParameter* findHarmonyParamByCompactName (const juce::String& exact) const
    {
        auto* plugin = bePlugin();
        if (plugin == nullptr)
            return nullptr;

        for (auto* param : plugin->getParameters())
            if (param != nullptr && compactHarmonyParamName (param->getName (128)) == exact)
                return param;

        return nullptr;
    }

    bool looksLikeAutoTune11 (juce::AudioPluginInstance* plugin) const
    {
        if (plugin == nullptr)
            return false;

        const auto n = plugin->getName().toLowerCase();
        return n.contains ("auto-tune") || n.contains ("autotune");
    }

    juce::AudioProcessorParameter* harmonyParamAtFallbackIndex (int index,
                                                               const juce::String& expectedCompactName) const
    {
        auto* plugin = bePlugin();
        if (plugin == nullptr || ! looksLikeAutoTune11 (plugin))
            return nullptr;

        const auto& params = plugin->getParameters();
        if (! juce::isPositiveAndBelow (index, params.size()) || params[index] == nullptr)
            return nullptr;

        /* Nếu Antares có expose tên thì kiểm tra đúng tên. Nếu tên rỗng/n-a
           vẫn cho fallback index vì chính bản Auto-Tune 11 của anh đã đo ra
           index này. */
        const auto actual = compactHarmonyParamName (params[index]->getName (128));
        if (actual.isNotEmpty() && actual != "na" && actual != expectedCompactName)
            return nullptr;

        return params[index];
    }

    juce::AudioProcessorParameter* findHarmonyAllVoicesLatch() const
    {
        if (auto* p = findHarmonyParamByCompactName ("hpallvoiceslatch"))
            return p;

        return harmonyParamAtFallbackIndex (127, "hpallvoiceslatch");
    }

    juce::AudioProcessorParameter* findHarmonyTriggerAll() const
    {
        if (auto* p = findHarmonyParamByCompactName ("hpallvoicestrigger"))
            return p;

        /* Một số host/plugin rút gọn tên thành Trigger All. */
        if (auto* p = findHarmonyParamByCompactName ("triggerall"))
            return p;

        return harmonyParamAtFallbackIndex (152, "hpallvoicestrigger");
    }

    juce::AudioProcessorParameter* findHarmonyVoiceTrigger (int voiceIndex0) const
    {
        const int voiceNo = voiceIndex0 + 1;
        if (auto* p = findHarmonyParamByCompactName (juce::String ("hpvoice")
                                                      + juce::String (voiceNo)
                                                      + "trigger"))
            return p;

        return harmonyParamAtFallbackIndex (148 + voiceIndex0,
                                            juce::String ("hpvoice") + juce::String (voiceNo) + "trigger");
    }

    static void setHostParameter (juce::AudioProcessorParameter* param, float value)
    {
        if (param == nullptr)
            return;

        value = juce::jlimit (0.0f, 1.0f, value);
        param->beginChangeGesture();
        param->setValueNotifyingHost (value);
        param->endChangeGesture();
    }

    bool isHarmonyTriggerAllOn() const
    {
        /* Ưu tiên nhìn 4 voice vì đây là trạng thái nghe thực tế. Nếu Auto-Tune
           chưa expose/đồng bộ voice thì mới nhìn All Voices Trigger. */
        int available = 0;
        int enabled = 0;

        for (int i = 0; i < 4; ++i)
        {
            if (auto* p = findHarmonyVoiceTrigger (i))
            {
                ++available;
                if (p->getValue() >= 0.5f)
                    ++enabled;
            }
        }

        if (available > 0)
            return enabled * 2 >= available;  // đa số voice đang bật

        if (auto* p = findHarmonyTriggerAll())
            return p->getValue() >= 0.5f;

        return false;
    }

    void toggleHarmonyTriggerAll()
    {
        auto* plugin = bePlugin();

        if (plugin == nullptr)
        {
            livent::alert (livent::vn ("Chưa có Auto-Tune"),
                           livent::vn ("Nút BÈ không thấy Auto-Tune. LiveNT tự tìm ở track MÍC ô 1, rồi ở mọi track khác. "
                                      "Hãy nạp Auto-Tune Pro 11 vào một track, hoặc chọn tay ở "
                                      "Cài đặt > Gán nút > VST điều khiển > Auto-Tune."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        auto* triggerAll = findHarmonyTriggerAll();
        if (triggerAll == nullptr)
        {
            livent::alert (livent::vn ("Không tìm thấy HP All Voices Trigger"),
                           livent::vn ("LiveNT đã thử tìm theo tên và fallback parameter #152 "
                                      "nhưng plugin tìm được không khớp Auto-Tune Pro 11.\n\n"
                                      "Hãy kiểm tra Cài đặt > Gán nút > VST điều khiển > Auto-Tune đang trỏ đúng ô."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        /* Trigger All muốn bấm một lần giữ ON, bấm lần nữa OFF thì Latch phải
           bật. Trên bản anh đo được nó là #127 HP All Voices Latch. */
        if (auto* latch = findHarmonyAllVoicesLatch())
            if (latch->getValue() < 0.5f)
                setHostParameter (latch, 1.0f);

        const bool turnOn = ! isHarmonyTriggerAllOn();
        setHostParameter (triggerAll, turnOn ? 1.0f : 0.0f);

        /* Một số build của plugin cập nhật 4 voice qua GUI/event queue trễ hơn
           một nhịp. Nếu ngay sau set mà voice chưa theo, đồng bộ host parameter
           #148..#151 để người hát bấm là ăn ngay, không cần mở plugin. */
        for (int i = 0; i < 4; ++i)
        {
            if (auto* voice = findHarmonyVoiceTrigger (i))
            {
                const bool already = voice->getValue() >= 0.5f;
                if (already != turnOn)
                    setHostParameter (voice, turnOn ? 1.0f : 0.0f);
            }
        }

        paintLiveButton (harmonyButton, turnOn);
        if (onLiveStateChanged)
            onLiveStateChanged();
    }

    //=========================================================================
    void bindManualClockToLink()
    {
        const auto videoId = ToneClient::extractVideoId (urlBox.getText());
        if (videoId.isEmpty() || videoId == detectedVideoId) return;
        detectedVideoId = videoId;
        fallbackClockVideoId.clear();
        fallbackClockSeconds = fallbackClockLastMs = 0.0;
        autoKeyPlaybackClock.reset();
    }

    void startDetect (bool manualRequest = true)
    {
        cancelDetectedFlash();
        if (manualRequest) clearSongAutomation();
        // Explicit button/Enter requests must respect the selected mode too.
        if (manualDetectMode)
        {
            ++detectRequestSerial;
            client.cancel();
            bindManualClockToLink();
            failureNoticeUntilMs = 0;
            lastToneFailure.clear();
            detectButton.setButtonText (livent::vn ("ĐO TONE"));
            builtinNewSong();   // 12s
            return;
        }

        if (manualRequest && client.isBusy())
        {
            ++detectRequestSerial;
            client.cancel();
            detectButton.setButtonText (livent::vn ("ĐO TONE"));
            statusLabel.setText (livent::vn ("Đã hủy."), juce::dontSendNotification);
            return;
        }

        /* Bam DO TONE / Enter link bang tay = nguoi dung MUON hoi VPS lai,
           nen cho phep ket qua moi thay tone da luu. Goi tu BrowserWatcher
           truyen false de khong vo tinh doi quyen uu tien. */
        if (manualRequest)
            libraryToneVideoId.clear();

        const auto link = urlBox.getText().trim();

        if (link.isEmpty())
        {
            livent::alert (livent::vn ("Chưa có link"),
                           livent::vn ("Dán link YouTube vào ô trên, hoặc dùng bộ chọn tay bên dưới "
                           "rồi bấm GỬI."));
            return;
        }

        if (ToneClient::extractVideoId (link).isEmpty())
        {
            livent::alert (livent::vn ("Link không đúng"),
                           livent::vn ("Không tìm thấy mã video trong link này.\n\n"
                           "Link đúng có dạng:\n"
                           "https://www.youtube.com/watch?v=xxxxxxxxxxx"),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        resultLabel  .setText (juce::String(), juce::dontSendNotification);
        pluginToneFollowing=false;mirroredKey.clear();mirroredScale.clear();
        ++toneWriteSerial;pluginToneWriteUntilMs=0;
        stopBuiltinFallback();   // 12s: thu lai AI -> T-AutoKey ngu
        if (onSongChanged) onSongChanged(); // stop an older Auto-Key sequence before retrying AI
        timelineLabel.setText (juce::String(), juce::dontSendNotification);
        detectButton .setButtonText (livent::vn ("HỦY"));

        const int targetId = getSelectedTrackId();
        const auto requestSerial = ++detectRequestSerial;
        awaitingVpsSerial = requestSerial;
        juce::Component::SafePointer<TonePanel> requestOwner (this);
        const int waitSeconds=livent::autokey::Settings::load().vpsWaitSeconds;
        juce::Timer::callAfterDelay (waitSeconds*1000, [requestOwner, requestSerial, waitSeconds]
        {
            if (requestOwner == nullptr || requestOwner->manualDetectMode
                || requestOwner->detectRequestSerial != requestSerial
                || requestOwner->awaitingVpsSerial != requestSerial) return;
            requestOwner->awaitingVpsSerial = 0;
            ++requestOwner->detectRequestSerial; // reject every late result for this song
            requestOwner->client.cancel();
            requestOwner->keyShowingDetecting = requestOwner->keyLanding = false;
            requestOwner->keyRollTimer.stopTimer();
            requestOwner->detectButton.setButtonText (livent::vn ("ĐO TONE"));
            requestOwner->lastToneFailure = livent::vn ("VPS chưa trả kết quả sau ")+juce::String(waitSeconds)+livent::vn(" giây.");
            requestOwner->keyDisplayButton.setButtonText (livent::vn ("Dò bằng T-AutoKey"));
            requestOwner->startBuiltinFallback (requestOwner->lastToneFailure);   // 12s
        });

        client.detect (link, [this, safeThis = juce::Component::SafePointer<TonePanel> (this), targetId, requestSerial] (ToneClient::Result r)
        {
            if (safeThis == nullptr)
                return;
            /* Ket qua cua yeu cau cu (vd vua mo bai DA LUU trong luc VPS cu
               sap tra ve) khong duoc phep cham vao UI/plugin nua. */
            if (requestSerial != detectRequestSerial)
                return;
            awaitingVpsSerial = 0;

            detectButton.setButtonText (livent::vn ("ĐO TONE"));

            if (! r.ok)
            {
                if (! r.authorizationError) showServerNotice (livent::vn ("AI NT và AI HC đều lỗi · chuyển dò bằng T-AutoKey"));
                keyShowingDetecting=false;keyLanding=false;keyRollTimer.stopTimer();
                const auto text=r.authorizationError?r.errorText:livent::vn("Máy chủ không dò được bài này.");
                lastToneFailure=r.errorText;statusLabel.setText(text,juce::dontSendNotification);
                failureNoticeUntilMs=juce::Time::getMillisecondCounter()+1500;
                keyDisplayButton.setButtonText(livent::vn("Không dò được"));
                juce::Timer::callAfterDelay(1500,[safeThis,requestSerial,auth=r.authorizationError]
                {
                    if(safeThis==nullptr||safeThis->detectRequestSerial!=requestSerial)return;
                    safeThis->failureNoticeUntilMs=0;safeThis->refreshKeyDisplay();
                    safeThis->statusLabel.setText({},juce::dontSendNotification);
                    if(!auth)safeThis->startBuiltinFallback(livent::vn("AI không dò được bài này"));   // 12s
                });
                return;
            }

            /*  MOC 37: KHONG hien o day nua. pushToPlugin() ben duoi se cong
                tong lech roi moi hien -- hien o ca hai cho thi con so nhay
                mot cai tu goc sang da dich, nhin roi mat va de doc nham.  */
            detectedVideoId = ToneClient::extractVideoId (urlBox.getText());
            /*  16/10 (anh chot): may chu chinh khong do duoc nhung may chu kia do XONG ->
                bao XANH ("✓ Da do xong bang AI NT"), KHONG bao do - khach thay do tuong loi.
                Chi khi CA HAI deu loi moi bao do (nhanh ! r.ok o tren).  */
            showServerNotice ({});
            if (r.notice.isNotEmpty())
                showAppNotice (r.notice, 5000);

            //  Nap cac moc doi tong vao dong ho
            juce::Array<ToneClock::Mark> marks;

            for (const auto& sh : r.shifts)
                marks.add ({ sh.timeSeconds, sh.key, sh.scale, false });

            clock.setMarks (marks, r.key, r.scale);

            showShifts (r.shifts);
            pushToPlugin (targetId, r.key, r.scale);
            flashDetectedTone();
            autoSaveDetectedSong();
        });
    }

    //-------------------------------------------------------------------------
    /*  ==========  MOC 37: MOI DUONG DEU DI QUA DAY  ==========

        Do tone xong, hay toi mot moc doi tong giua bai -- ca hai deu goi vao
        day. Nen chi can cong tong lech o MOT cho nay la moi duong deu dung.

        Thu tu bat buoc:
            nhan Key GOC tu VPS2
              -> cat lai lam ban goc
              -> NGO xem o +/- dang la bao nhieu
              -> cong vao roi MOI hien len va MOI ban di

        Khong duoc hien ban goc ra truoc roi sua sau: nhin thay mot dang ma
        plugin nhan mot neo, va neu buoc sua sau do that bai thi con so tren
        man hinh la con so noi doi.  */
    void pushToPlugin (int trackId, const juce::String& key, const juce::String& scale)
    {
        juce::ignoreUnused (trackId);

        baseKey   = key;
        baseScale = scale;

        sendShiftedKey();
    }

    /** C04: plugin nhan Key/Scale (va noi doc lai tone). Thu tu:
          1. Gan nut > VST dieu khien > Auto-Tune do nguoi dung CHON TAY (dung track + dung o);
          2. plugin chinh cao do dau tien tren track dang chon o hop "Track dich";
          3. Auto-Tune tu tim duoc (MIC / track khac).
        Chon tay ma o do khong co num Key thi bao loi, KHONG tu ghi sang plugin khac.  */
    TonePush::Target toneTarget (juce::String* why = nullptr)
    {
        return TonePush::chooseTarget (mixer, buttonMap, micTrack(), mixer.getTrackById (getSelectedTrackId()), why);
    }

    /** Ban thang, KHONG cong them gi -- da cong o sendShiftedKey() roi. */
    void pushToPluginRaw (int trackId, const juce::String& key, const juce::String& scale)
    {
        /*  11/10: track dang chon khong co plugin chinh cao do (vd dang chon track khac) ma
            Auto-Tune nam o Group/track khac -> ghi Key/Scale vao track co Auto-Tune.  */
        juce::ignoreUnused (trackId);

        /*  31/10: GUI KIEU AUTO-KEY - ghi file Auto-Key.handoff, MOI Auto-Tune dang nhan
            Auto-Key deu nhan (3, 4 con, track nao cung duoc). Dan ca -> Dorian (KeyType 5).
            Cach cu ben duoi (ghi thang vao num 1 plugin) giu lai lam DU PHONG cho plugin
            khong doc file (Waves Tune, GSnap...). Khong tim thay plugin nao thi KHONG bao loi.  */
        const auto broadcastScale = TonePush::usesFolkScale() ? juce::String (TonePush::folkScaleName()) : scale;
        const bool broadcast = livent::akbroadcast::send (autoKeyBroadcastWriter, key, broadcastScale);
        const juce::String broadcastText = broadcast
            ? livent::vn ("Auto-Key: đã gửi ") + key + " " + broadcastScale + livent::vn (" cho mọi Auto-Tune")
            : juce::String();

        juce::String targetWhy;
        const auto target = toneTarget (&targetWhy);   // C04: dung track + o + doi tuong; ghi va doc CUNG mot dich
        if (target.empty())
        {
            statusLabel.setText (broadcast ? broadcastText : targetWhy, juce::dontSendNotification);
            return;
        }
        const auto writeSerial=++toneWriteSerial;
        if(followsPluginTone())pluginToneWriteUntilMs=juce::Time::getMillisecondCounter()+1000;
        juce::Component::SafePointer<TonePanel> writeOwner(this);
        statusLabel.setText (livent::vn ("Đang gửi Scale..."), juce::dontSendNotification);

        TonePush::pushToTargetAsync (mixer, target, key, scale,
            [this, safeThis = juce::Component::SafePointer<TonePanel> (this),writeSerial,broadcastText] (TonePush::PushResult res)
            {
                if (safeThis == nullptr || toneWriteSerial!=writeSerial)
                    return;
                pluginToneWriteUntilMs=0;
                if(followsPluginTone())syncToneFromPlugin();
                if (! res.foundPlugin || (! res.keyDone && ! res.scaleDone))
                {
                    // 31/10: file Auto-Key da gui thi plugin du phong hong cung khong sao
                    statusLabel.setText (broadcastText.isNotEmpty() ? broadcastText : res.note, juce::dontSendNotification);
                    return;
                }

                juce::String s;

                s << (res.scaleDone ? livent::vn ("Scale = ") + res.scaleText : juce::String (livent::vn ("Scale KHÔNG đạt được")))
                  << "   |   "
                  << (res.keyDone   ? livent::vn ("Key = ")   + res.keyText   : juce::String (livent::vn ("Key KHÔNG đạt được")))
                  << "   ->   " << res.pluginName;
                if (TonePush::usesFolkScale())
                    s = (res.folkFallback ? livent::vn ("Dân ca (plugin không có Dorian) · ")
                                          : livent::vn ("Dân ca · ")) + s;

                if (broadcastText.isNotEmpty())
                    s = broadcastText + "   |   " + s;
                statusLabel.setText (s, juce::dontSendNotification);

                if (onPluginChanged)
                    onPluginChanged();
            },[writeOwner,writeSerial]
            {return writeOwner!=nullptr && writeOwner->toneWriteSerial==writeSerial;});   // dich da CHOT luc bam; doi track chon khong huy lenh dang chay
    }

    //-------------------------------------------------------------------------
    /** Kim vua chay qua mot moc doi tong chua? Qua roi thi ban ngay.

        Vi sao lay so giay cua trinh duyet chu khong tu dem: anh tua bai, tam
        dung, hay phat lai tu dau thi so giay do van dung. Dong ho tu dem thi
        tua mot cai la lech han, va den phut doi tong se ban sai. */

    bool automationEffectState (int effect) const
    {
        const auto b = buttonMap.get (livent::songs::effectId (effect));
        if (! b.isDefault()) return boundState (b);
        if (effect == 4) return isHarmonyTriggerAllOn();
        const int slots[] = { slotLofi(), slotRemix1(), slotRemix2(), slotBaby() };
        if (auto* t = micTrack()) { const auto& chain = t->getInserts(); const int slot = slots[effect]; return ! chain.isSlotEmpty (slot) && ! chain.isMissing (slot) && ! chain.isBypassed (slot); }
        return false;
    }
    bool setAutomationEffect (int effect, bool on)
    {
        using livent::buttonmap::Act;
        const auto b = buttonMap.get (livent::songs::effectId (effect));
        if (! b.isDefault())
        {
            auto* t = boundTrack (b); if (t == nullptr) return false;
            switch (b.act)
            {
                case Act::ToggleInsert:
                    if (t->getInserts().isSlotEmpty (b.slot) || t->getInserts().isMissing (b.slot)) return false;
                    t->getInserts().setBypassed (b.slot, ! on); break;
                case Act::ToggleTrack: t->setMonitor (on); break;
                case Act::ToggleAllSends: t->setAllSendsOn (on); break;
                case Act::ToggleSend:
                { const int i = livent::buttonmap::resolveSendIndex (mixer, *t, b); if (i < 0) return false; t->setSendEnabled (i, on); break; }
                default: return false;
            }
        }
        else if (effect == 4)
        {
            auto* trigger = findHarmonyTriggerAll(); if (trigger == nullptr) return false;
            if (on) if (auto* latch = findHarmonyAllVoicesLatch()) setHostParameter (latch, 1.0f);
            setHostParameter (trigger, on ? 1.0f : 0.0f);
            for (int i = 0; i < 4; ++i) if (auto* voice = findHarmonyVoiceTrigger (i)) setHostParameter (voice, on ? 1.0f : 0.0f);
        }
        else
        {
            const int slots[] = { slotLofi(), slotRemix1(), slotRemix2(), slotBaby() };
            auto* t = micTrack(); if (t == nullptr) return false;
            const int slot = slots[effect]; auto& chain = t->getInserts();
            if (chain.isSlotEmpty (slot) || chain.isMissing (slot)) return false;
            chain.setBypassed (slot, ! on);
        }
        return true;
    }
    void clearSongAutomation()
    {
        if (! songAutomationActive) return;
        for (int i = 0; i < 5; ++i)
            if (automationLastEffects[(size_t) i] >= 0) setAutomationEffect (i, automationBaseline[(size_t) i]);
        if (automationToneTouched)
        {
            if (auto* t = nhacTrack()) TonePush::setSemitonesOnTrack (*t, (int) std::round (automationSong.shiftTong * 2));
            toneOffsetTong = automationSong.shiftTong; baseKey = automationSong.key; baseScale = automationSong.scale;
            updateToneLabel(); sendShiftedKey();
        }
        songAutomationActive = automationOwnsTone = automationToneTouched = false;
        lastExactSongTickMs = 0; automationLastTone = -2;
        refreshLiveButtons(); announceChange();
    }
    void activateSongAutomation (const livent::songs::Song& song)
    {
        automationSong = song; songAutomationActive = ! song.markers.isEmpty();
        automationOwnsTone = false; automationToneTouched = false; automationLastTone = -2;
        automationLastKey.clear(); automationLastScale.clear(); automationLastShift = 999;
        lastExactSongTickMs = 0; automationLastEffects.fill (-1);
        for (int i = 0; i < 5; ++i) automationBaseline[(size_t) i] = automationEffectState (i);
        for (const auto& m : song.markers) if (m.isTone()) automationOwnsTone = true;
    }
    void applySongAutomation (double seconds)
    {
        if (! songAutomationActive || ! std::isfinite (seconds) || seconds < 0) return;
        const auto state = livent::songs::evaluateMarkers (automationSong.markers, seconds);
        bool changed = false;
        for (int i = 0; i < 5; ++i)
        {
            const int wanted = state.effectStates[(size_t) i]; auto& last = automationLastEffects[(size_t) i];
            if (wanted == last) continue;
            if (wanted >= 0 || last >= 0)
            {
                if (setAutomationEffect (i, wanted >= 0 ? wanted == 1 : automationBaseline[(size_t) i])) changed = true;
                else
                {
                    statusLabel.setText (livent::vn ("Mốc hiệu ứng: chưa có VST / đích cho nút ") + livent::songs::effectNames()[i], juce::dontSendNotification);
                    continue; // retry if the missing target is loaded during the interval
                }
            }
            last = wanted;
        }
        const int toneMarker = autoShiftButton.getToggleState() ? state.toneMarker : -1;
        if (automationOwnsTone)
        {
            const bool hadApplied = automationToneTouched;
            auto originalKey = automationSong.key; auto originalScale = automationSong.scale;
            // Existing Key/Scale marks describe the music's natural key at this
            // position. Transpose that key, and restore it when the interval ends.
            if (autoShiftButton.getToggleState())
                for (const auto& p : automationSong.timeline)
                { if (p.seconds > seconds) break; originalKey = p.key; originalScale = p.scale; }
            int shift = (int) std::round (automationSong.shiftTong * 2); auto wantedScale = originalScale;
            if (toneMarker >= 0)
            {
                const auto& m = automationSong.markers.getReference (toneMarker);
                if (m.action == livent::songs::MarkerAction::transpose) shift += m.semitones;
                else { shift = livent::songs::keyDelta (originalKey, m.key); wantedScale = m.scale; }
            }
            if (toneMarker != automationLastTone || originalKey != automationLastKey
                || wantedScale != automationLastScale || shift != automationLastShift)
            {
                const bool writePitch = toneMarker >= 0 || hadApplied;
                auto* t = nhacTrack();
                if (writePitch && (shift < -12 || shift > 12 || t == nullptr || ! TonePush::setSemitonesOnTrack (*t, shift)))
                    statusLabel.setText (livent::vn ("Mốc đổi tông: cần VST dịch tông trên NHẠC, trong giới hạn ±6 tông."), juce::dontSendNotification);
                else
                {
                    automationLastTone = toneMarker; automationLastKey = originalKey;
                    automationLastScale = wantedScale; automationLastShift = shift;
                    if (writePitch) automationToneTouched = true;
                    toneOffsetTong = shift * 0.5f;
                    baseKey = originalKey; baseScale = wantedScale; resetManualKeyScaleAdjustments();
                    mirroredKey.clear(); mirroredScale.clear(); updateToneLabel(); sendShiftedKey(); changed = true;
                }
            }
        }
        clock.setPosition (seconds, true);
        if (changed) { refreshLiveButtons(); announceChange(); }
    }

    void checkForToneShift (double positionSeconds)
    {
        if (songAutomationActive)
        {
            applySongAutomation (positionSeconds);
            if (automationOwnsTone) return;
        }
        if(followsPluginTone())return; // plugin is the authority in manual/fallback mode
        if (! autoShiftButton.getToggleState())
            return;

        auto& marks = clock.getMarks();

        /*  V5.8.5: tinh TRANG THAI CAN CO tai dung vi tri hien tai, thay vi
            chi hoi "moc nay da applied chua". Logic cu bi ket khi tua nguoc:
            tu moc 2 ve giua moc 1-2 thi moc 1 van applied=true -> return,
            Auto-Tune van nam o tone moc 2. Tua ve truoc moc dau cung khong
            co duong tra lai Key goc. */
        int shouldApply = -1;
        for (int i = 0; i < marks.size(); ++i)
        {
            if (marks[i].seconds <= positionSeconds) shouldApply = i;
            else break;
        }

        for (int i = 0; i < marks.size(); ++i)
            marks.getReference (i).applied = (i <= shouldApply);

        juce::String wantedKey   = shouldApply >= 0 ? marks[shouldApply].key
                                                     : clock.getFirstKey();
        juce::String wantedScale = shouldApply >= 0 ? marks[shouldApply].scale
                                                     : clock.getFirstScale();

        if (wantedKey.isEmpty() || wantedScale.isEmpty())
        {
            clock.repaint();
            return;
        }

        if (baseKey == wantedKey && baseScale == wantedScale)
        {
            clock.repaint();
            return;
        }

        if (shouldApply >= 0)
            statusLabel.setText (livent::vn ("Phút ") + ToneClock::mmss (marks[shouldApply].seconds)
                                 + livent::vn (" -> đổi sang ") + wantedKey + " " + wantedScale,
                                 juce::dontSendNotification);
        else
            statusLabel.setText (livent::vn ("Đã tua về trước mốc đổi tone -> trở lại ")
                                 + wantedKey + " " + wantedScale, juce::dontSendNotification);

        pushToPlugin (getSelectedTrackId(), wantedKey, wantedScale);
        clock.repaint();
    }

    /*  14/10: noi dung o thong bao. Uu tien: sap doi tong (dem nguoc 10 giay)
        > loi may chu > bao bai co doi tong (8 giay sau khi do xong).  */
    juce::String currentFooterNotice (int& kind)
    {
        kind = 0;
        const auto now = juce::Time::getMillisecondCounter();

        if (clock.isLive())
        {
            const double pos = clock.getPosition();
            for (const auto& m : clock.getMarks())
            {
                const double left = m.seconds - pos;
                if (! m.applied && left > 0.0 && left <= 10.0)
                {
                    kind = 2;
                    return livent::vn ("Còn ") + juce::String ((int) std::ceil (left))
                         + livent::vn (" giây đổi tông → ") + noticeKeyText (m.key, m.scale);
                }
            }
        }

        if (serverNoticeUntil != 0 && now < serverNoticeUntil)
        {
            kind = 3;
            return serverNotice;
        }

        if (appNoticeUntil != 0 && now < appNoticeUntil)   // 15/10: vd "Đã tự đổi 2 VST sang 64-bit"
        {
            kind = 4;
            return appNotice;
        }

        if (shiftNoticeUntil != 0 && now < shiftNoticeUntil && ! clock.getMarks().isEmpty())
        {
            const auto& m = clock.getMarks().getReference (0);
            kind = 1;
            auto text = livent::vn ("Bài có đổi tông: ") + ToneClock::mmss (m.seconds)
                      + livent::vn (" → ") + noticeKeyText (m.key, m.scale);
            if (clock.getMarks().size() > 1)
                text << "  (+" << (clock.getMarks().size() - 1) << ")";
            return text;
        }
        return {};
    }

    /** Key hien tren thong bao = key se thuc su gui vao Auto-Tune (da cong +/- tong). */
    juce::String noticeKeyText (const juce::String& key, const juce::String& scale)
    {
        auto shown = TonePush::transposeKey (key, semitoneShift());
        if (shown.isEmpty()) shown = key;
        return shown + " " + scale;
    }

    void showServerNotice (const juce::String& text)
    {
        serverNotice = text;
        serverNoticeUntil = text.isEmpty() ? 0 : juce::Time::getMillisecondCounter() + 8000;
    }

    juce::String serverNotice;
    juce::uint32 serverNoticeUntil = 0, shiftNoticeUntil = 0;
    juce::String appNotice;          // 15/10: thong bao nhe mau xanh (kind 4)
    juce::uint32 appNoticeUntil = 0;

public:
    /** 15/10: bao nhe 8 giay o thanh duoi (bang Ngang) / o Dang phat (bang Doc). */
    void showAppNotice (const juce::String& text, int ms = 8000)
    {
        appNotice = text;
        appNoticeUntil = text.isEmpty() ? 0 : juce::Time::getMillisecondCounter() + (juce::uint32) ms;
    }
private:

    void showShifts (const juce::Array<ToneClient::Shift>& shifts)
    {
        shiftNoticeUntil = shifts.isEmpty() ? 0 : juce::Time::getMillisecondCounter() + 8000;   // 14/10
        if (shifts.isEmpty())
        {
            // V5.7: bo banner "Bai nay giu nguyen tone". Logic timeline van giu.
            timelineLabel.setText (juce::String(), juce::dontSendNotification);
            return;
        }

        juce::String s = "Cac moc doi tone:\n";

        for (const auto& sh : shifts)
        {
            const int total = (int) sh.timeSeconds;

            s << livent::vn ("   Phút ")
              << juce::String (total / 60).paddedLeft ('0', 2) << ":"
              << juce::String (total % 60).paddedLeft ('0', 2)
              << "  ->  " << sh.key << " " << sh.scale << "\n";
        }

        timelineLabel.setText (s.trimEnd(), juce::dontSendNotification);
    }

    //-------------------------------------------------------------------------
    void toggleAutoWatch()
    {
        const bool on = autoButton.getToggleState();

        autoButton.setButtonText (on ? livent::vn ("TỰ BẮT LINK: BẬT") : "TU BAT LINK: TAT");

        if (on || manualDetectMode)
        {
            watcher.forgetLastVideo();
            watcher.startWatching();
        }
        else
        {
            watcher.stopWatching();
        }
    }

    void updateSongAutomationClock()
    {
        if (! songAutomationActive) return;
        const double nowMs = juce::Time::getMillisecondCounterHiRes();
        if (detectedVideoId.isEmpty())
            applySongAutomation (mixer.getTimelinePositionSeconds());
        else if (lastExactSongTickMs > 0 && nowMs - lastExactSongTickMs < 2200)
            applySongAutomation (lastExactSongSeconds + (exactSongPlaying ? juce::jlimit (0.0, 1.0, (nowMs - lastExactSongTickMs) / 1000.0) : 0.0));
    }

    void timerCallback() override
    {
        updateSongAutomationClock();
        pollBuiltinKey();     // 12s: T-AutoKey co san (thuc / ngu, nhan Key moi)
        syncToneFromPlugin(); // 4 Hz read-only, independent of status banners
        autoSyncMusicVstPower();
        autoVangFollowMusic();
        /*  MOC 35: to lai mau bay nut dien theo trang thai THAT.

            Bam o day (4 lan/giay) chu khong chi to luc bam nut, vi cung mot
            thu co the bi doi tu cho khac: anh bam nut Loa ngay tren track
            MIC, hay bam nut nguon cua o insert trong bang mixer. Doc lai
            deu dan thi nut o day khong bao gio noi sai su that.

            Re thoi: chi doc vai bien atomic va so mau, khong dung toi luong
            am thanh.  */
        refreshLiveButtons();
        refreshRemoteKnobs();

        //  MOC 89: nap san mp3 da chuyen sang LaughBoard - no co dong ho
        //  rieng, chi chay khi cua so tieng cuoi dang mo.

        /*  MOC 74: dang thu thi hien so phut:giay da ghi ngay tren nut DUNG.

            Khong co con so nay thi khong cach nao biet may CO DANG ghi that
            khong -- nhat la khi anh vua bam THU xong roi quay ra hat, nhin
            lai chi thay mot nut do y het luc chua bam.  */
        if (mixer.isMasterRecording())
            recButton.setButtonText (ToneClock::mmss (mixer.getMasterRecordedSeconds()));

        const auto timeText = nowPlaying.getTimeText();
        if (nowPlayingClockLabel.getText() != timeText)
            nowPlayingClockLabel.setText (timeText, juce::dontSendNotification);
        if (onSongInfo)   // 07/10: ten bai + gio hien o thanh trang thai
            onSongInfo (nowPlaying.getTitle(), timeText, nowPlaying.isLivePosition());
        {
            int kind = 0;
            const auto text = currentFooterNotice (kind);
            if (onFooterNotice)   // 14/10
                onFooterNotice (text, kind);
            nowPlaying.setNotice (text, kind);   // 15/10: bang Doc - thong bao nam trong o Dang phat

            // 15/10: o tong nho canh ten bai + cham vang moc doi tong tren thanh tien trinh
            if (verticalLayout && ! compactMode)
            {
                juce::String badge;
                if (! keyShowingDetecting && ! keyLanding
                    && ! (followsPluginTone() && (mirroredKey.isEmpty() || mirroredScale.isEmpty())))
                    badge = effectiveKey() + (effectiveScale().containsIgnoreCase ("minor") ? "m" : "");
                nowPlaying.setKeyBadge (badge);
                juce::Array<double> markSeconds;
                for (const auto& m : clock.getMarks())
                    markSeconds.add (m.seconds);
                nowPlaying.setMarks (markSeconds);
            }
        }
        nowPlayingClockLabel.setColour (juce::Label::textColourId,
                                        nowPlaying.isLivePosition() ? Col::accent : Col::text);

        /*  Nut Key/Scale: trong luc cho YouTube phat du 2 giay de bat link,
            va trong luc may chu dang do tone, hien "Dang do..." thay vi de
            nguyen "C Major" mac dinh - khach nhin la biet may dang lam viec. */
        if(failureNoticeUntilMs!=0 && juce::Time::getMillisecondCounter()<failureNoticeUntilMs)return;
        failureNoticeUntilMs=0;
        refreshKeyDetectingState();

        //  Dang do thi tin cua may chu quan trong hon tin cua bo rinh
        if (client.isBusy())
        {
            statusLabel.setText (client.getProgress(), juce::dontSendNotification);
            return;
        }

        if (watcher.isWatching())
            statusLabel.setText (watcher.getStatus(), juce::dontSendNotification);
    }

    //=========================================================================
    /*  MOC 79: khai bao SOM NHAT trong vung nay. Thanh vien bi huy theo thu
        tu NGUOC voi thu tu khai bao, nen khai bao dau = bi huy cuoi = con
        song lau hon moi cai nut dang dung no.  */
    GlassLookAndFeel glassLook;

    static constexpr int headerHeight   = 22;
    static constexpr int timelineHeight = 38;   // MOC 94: giam tiep tu 46 - bang can gon them

    /*  MOC 75: kich thuoc cac hang o bo cuc NGANG. De rieng thanh hang so co
        ten de getWantedHeight() va resized() khong bao gio lech nhau - truoc
        day hai ham do cong tay hai day so khac nhau, sua mot ben la ben kia
        sai am tham.  */
    /*  MOC 94: giam tu 32 -> 27. Hang nay chua tieu de + ket qua + 2 nut;
        27 px van du cho chu 18pt cua resultLabel (chieu cao chu 18pt khoang
        23 px), ma bang thap di 5 px.  */
    static constexpr int topRowHeight     = 27;
    static constexpr int playerRowHeight  = 42;
    static constexpr int controlRowHeight = 30;
    static constexpr int liveRowHeight    = 28;
    static constexpr int remoteRowGap       = 7;
    static constexpr int remoteRowHeight    = 72;
    static constexpr int remoteCaptionHeight= 15;
    static constexpr int compactContentHeight = playerRowHeight + 5 + controlRowHeight + 8
                                              + liveRowHeight + remoteRowGap + remoteRowHeight;
    static constexpr int compactBaseHeight = compactContentHeight + 10;
    static constexpr int minClockHeight   = 26;

    //  MOC 89: hang so cua luoi nut tieng cuoi da chuyen sang LaughBoard.h   // MOC 80: giam tu 30 - dai thoi gian, cao toi thieu

    Mixer& mixer;
    livent::customLive::Panel customButtons { mixer };
    ToneClient client;

    // V4.6: hai meter gon luon hien tren remote chinh.
    LiveControlMeter nhacMeter { livent::vn ("NHẠC") };
    LiveControlMeter micMeter  { livent::vn ("MÍC") };
    NowPlayingStrip nowPlaying;
    juce::Label nowPlayingClockLabel;
    bool compactMode = false;                               // 06/10: thanh thu gon
    juce::Array<juce::Rectangle<int>> compactInfoCells;     // 06/10
    bool compactMetersVisible = true;

    SectionHeader header { livent::vn ("BẢNG ĐIỀU KHIỂN"), false };

    //  MOC 74: hai nut thu am, xem phan API o khu vuc public
    juce::TextButton recButton;
    juce::TextButton keyMinusButton, keyDisplayButton, keyPlusButton, scaleToggleButton;
    juce::uint32 skipNoticeUntilMs = 0;   // 30/09: dang hien "Khong do" (video dai / livestream)
    bool keyShowingDetecting = false;   // nut Key/Scale dang quay so (dang do)
    KeyRollTimer keyRollTimer;          // 02/10: hieu ung quay so
    KeyModeTag   keyModeTag;            // 02/10: chu AI / TAY tren o Key
    bool keyLanding = false;
    juce::uint32 keyLandStartMs = 0, keyNextStepMs = 0, keyFlashUntilMs = 0, keyRightClickMs = 0;
    int  keyRollIdx = 0;
    juce::uint32 failureNoticeUntilMs=0;
    bool manualDetectMode = false;      // 02/10: true = Do tay (tat bat link). 12s: = "Do khong AI" (T-AutoKey co san)
    bool builtinFallbackActive = false; // 12s: Do AI nhung AI loi -> T-AutoKey co san dang do thay
    bool builtinKeyFirstForSong = true; // 12s: Key dau tien cua bai -> chop sang + luu bai
    int  builtinLastShift = 0;          // 12s: tong lech luc T-AutoKey bat dau nghe
    bool songRowHidden = false;         // hang Tone bai/Tone nhac dang o duoi cua so YouTube
    int  keyDetectingPhase = 0;
    juce::uint32 lastDetectingMs = 0;
    juce::TextButton saveSongButton, songListButton;
    PowerIconButton toneVstPowerButton;   // V0.6.7.9c
    juce::TextButton beatButton;          // 30/09: ban khach - nut chu "Beat" thay bieu tuong
    std::uint64_t musicVstSignature = 0;  // 14/10: dau van tay cac plugin dang nap tren track NHAC (xem autoSyncMusicVstPower)
    int musicVstStableTicks = 0;
    bool musicVstSynced = false;
    livent::buttonmap::Map buttonMap;     // 01/10: gan nut / num (luu trong du an)
    livent::presets::Bank presetBank;     // 02/10: preset the loai (luu trong du an) - 07/10: 4 che do
    livent::presets::PresetStrip presetStrip { presetBank };   // 07/10: dai 4 che do thay nut Preset
    juce::TextButton presetButton;        // 02/10: nut Preset dau hang ten bai
    std::unique_ptr<juce::FileChooser> presetChooser;
    KnobFoldButton   statusFold;          // 30/09: mui ten thu/mo dat tren thanh trang thai

    static constexpr bool beatAsText()      noexcept { return livent::branding::musicVstAsBeatButton; }
    static constexpr bool foldOnStatusBar() noexcept { return livent::branding::foldArrowOnStatusBar; }

    /** Dat nut nguon VST 1 track NHAC (bieu tuong hoac chu "Beat"). */
    void placeMusicPower (juce::Rectangle<int> r)
    {
        // 06/10: nut nguon gon lai - o vuong theo chieu cao hang, khong keo
        // dai het phan con lai (anh thay "hoi to").
        auto icon = r.withWidth (juce::jmin (r.getWidth(), r.getHeight() + 4));
        toneVstPowerButton.setBounds (beatAsText() ? juce::Rectangle<int>() : icon);
        beatButton.setBounds (beatAsText() ? r : juce::Rectangle<int>());
    }

    //  V0.6.7.9e: thanh song tren 9 nut live, moi nut 1 mau
    ChipMeter tuneChipMeter   { juce::Colour (0xfff5b800) },   // vang gold
              nhacChipMeter   { juce::Colour (0xff4c8dff) },   // xanh duong
              micChipMeter    { juce::Colour (0xff2bd4a4) },   // xanh ngoc
              vangChipMeter   { juce::Colour (0xffa78bfa) },   // tim
              lofiChipMeter   { juce::Colour (0xffff9f43) },   // cam
              remix1ChipMeter { juce::Colour (0xffff5fa2) },   // hong
              remix2ChipMeter { juce::Colour (0xff29c5f6) },   // xanh troi
              babyChipMeter   { juce::Colour (0xff8ee36a) },   // xanh la
              harmonyChipMeter{ juce::Colour (0xffff6b6b) };   // do san ho

    std::array<ChipMeter*, 9> chipMeters()
    {
        return { &tuneChipMeter, &nhacChipMeter, &micChipMeter, &vangChipMeter, &lofiChipMeter,
                 &remix1ChipMeter, &remix2ChipMeter, &babyChipMeter, &harmonyChipMeter };
    }

    std::array<juce::TextButton*, 9> chipMeterButtons()
    {
        return { &tuneButton, &nhacButton, &micButton, &vangButton, &lofiButton,
                 &remix1Button, &remix2Button, &babyButton, &harmonyButton };
    }

    /** Dat moi thanh song nam sat day NUT cua no. Goi cuoi resized(). */
    /** 06/10: bo cuc thu gon - xem compactCell(). */
    void resizedCompact()
    {
        captions.clear();
        separators.clear();
        secTop = secChips = secKnobs = {};
        compactInfoCells.clear();

        juce::Array<juce::TextButton*> live = livent::branding::vangFirst
            ? juce::Array<juce::TextButton*> { &vangButton, &tuneButton, &nhacButton, &micButton }
            : juce::Array<juce::TextButton*> { &tuneButton, &nhacButton, &micButton, &vangButton };
        live.addArray (juce::Array<juce::TextButton*> { &lofiButton, &remix1Button, &remix2Button, &babyButton });

        std::vector<juce::Component*> keep { &nowPlaying, &nowPlayingClockLabel,
                                             &keyMinusButton, &keyDisplayButton, &keyPlusButton,
                                             &toneMinusButton, &toneValueLabel, &tonePlusButton,
                                             &presetButton };
        for (auto* b : live) keep.push_back (b);
        for (auto* m : chipMeters()) keep.push_back (m);

        for (auto* c : getChildren())
            if (std::find (keep.begin(), keep.end(), c) == keep.end())
                c->setBounds ({});

        for (auto* c : keep)
            c->setVisible (true);

        auto info = [this] (juce::Rectangle<int> r) { compactInfoCells.add (r); return r; };

        nowPlaying.setCardMode (false);
        nowPlaying.setBounds (info (compactCell (0, 1)).reduced (6, 2));
        nowPlayingClockLabel.setBounds (info (compactCell (0, 2)));

        constexpr int arrowW = 17;
        {
            auto k = info (compactCell (0, 3));
            keyMinusButton.setBounds (k.removeFromLeft (arrowW).reduced (1, 3));
            keyPlusButton .setBounds (k.removeFromRight (arrowW).reduced (1, 3));
            keyDisplayButton.setBounds (k.reduced (0, 2));
        }
        {
            auto tn = info (compactCell (0, 4));
            toneMinusButton.setBounds (tn.removeFromLeft (arrowW).reduced (1, 3));
            tonePlusButton .setBounds (tn.removeFromRight (arrowW).reduced (1, 3));
            toneValueLabel.setBounds (tn);
            toneValueBox = {};
        }
        presetButton.setBounds (compactCell (0, 5));

        for (int i = 0; i < live.size(); ++i)
            live[i]->setBounds (compactCell (1, i));

        placeChipMeters();
    }

    int chipBarSpill = 0;   // >0: bo cuc ngang chinh - thanh duoc phep tran 4 px xuong le tam

    void placeChipMeters()
    {
        auto meters  = chipMeters();
        auto buttons = chipMeterButtons();
        for (size_t i = 0; i < meters.size(); ++i)
        {
            auto* b = buttons[i];
            const auto bb = b->getBounds();
            // compactMetersVisible (F6 / menu Hien thi) gio bat/tat song tren nut
            if (bb.isEmpty() || ! b->isVisible() || ! compactMetersVisible)
            {
                meters[i]->setBounds ({});
                continue;
            }
            if (livent::rack::active())
            {
                // 12o: kieu D ngang - thanh 9 px nam NGAY DUOI nut (nut thap di 7 px), thanh tran xuong le tam 4 px
                if (chipBarSpill > 0)
                {
                    b->setBounds (bb.withTrimmedBottom (7));
                    meters[i]->setBounds (bb.getX() + 2, bb.getBottom() - 5, bb.getWidth() - 4, 9);
                }
                else   // bo cuc doc / thu gon: khong co le thua -> thanh 7 px nam gon trong o nut
                {
                    b->setBounds (bb.withTrimmedBottom (8));
                    meters[i]->setBounds (bb.getX() + 2, bb.getBottom() - 7, bb.getWidth() - 4, 7);
                }
                meters[i]->toFront (false);
                continue;
            }
            const int inset = juce::jmax (6, bb.getWidth() / 7);
            meters[i]->setBounds (bb.getX() + inset, bb.getBottom() - 7, bb.getWidth() - inset * 2, 3);
            meters[i]->toFront (false);
        }
    }

    /*  MOC 82: dai nut tieng cuoi - chi hien khi bang dang THU GON.  */
    struct SfxItem
    {
        juce::String label;
        juce::String file;
    };

    /*  MOC 89: bang tieng cuoi va cua so cua no.

        laughBoard khai bao TRUOC laughWindow de bi huy SAU - cua so giu con
        tro toi bang, khong duoc de bang chet truoc.  */
    LaughBoard laughBoard { mixer.sfx() };
    std::unique_ptr<LaughWindow> laughWindow;
    juce::Rectangle<int> laughAnchorScreen;
    std::unique_ptr<livent::songs::Window> songLibraryWindow;
    livent::songs::Song automationSong;
    bool songAutomationActive = false, automationOwnsTone = false, automationToneTouched = false;
    juce::String automationLastKey, automationLastScale;
    int automationLastShift = 999;
    std::array<bool, 5> automationBaseline {{ false, false, false, false, false }};
    std::array<int, 5> automationLastEffects {{ -1, -1, -1, -1, -1 }};
    int automationLastTone = -2;
    double lastExactSongSeconds = 0, lastExactSongTickMs = 0;
    bool exactSongPlaying = false;
    juce::uint32 keyPulseStartMs = 0;
    juce::String currentSongTitle, currentSongUrl;
    bool songAutoSaveEnabled = true;

    juce::TextEditor urlBox;
    juce::TextButton pasteButton, detectButton, autoTuneButton, linkToggle;
    PluginActionButton harmonyButton;   // 14/10: chuot phai = Doi ten
    juce::TextButton toneModeButton;

    juce::Label      targetCaption { {}, livent::vn ("Bắn vào track:") };
    juce::ComboBox   targetBox;
    juce::Array<int> trackIds;

    BrowserWatcher   watcher;
    /*  ==========  MOC 35: HANG NUT DIEN  ==========

        Bay nut bat/tat dat ngay trong bang do tone -- xanh la dang bat, do
        la dang tat. Dung LUC DANG HAT, nen tat ca deu la mot cham: khong
        menu, khong hop thoai, khong phai cuon di dau.

        Ba nhom viec khac nhau nhung nhin giong nhau, co y:
          VANG              -> tat/bat TOAN BO send cua track MIC
          MIC / NHAC        -> tat/bat loa (monitor) cua hai track do
          TUNE/LOFI/REMIX   -> tat/bat rieng mot o insert tren track MIC
          BÈ                 -> Trigger All cua Harmony Player (neu bat trong Hien thi)

        Chi so o insert dem tu 0 trong code, nhung nguoi dung dem tu 1:
        TUNE = o 1, LOFI = o 12, REMIX1 = o 13, REMIX2 = o 14, EM BE = o 15.  */
    /*  ==========  MOC 37: O DOI TONG NHAC  ==========

        Ba thanh phan:  [ - ]  [ 0.0 ]  [ + ]

        Con so trong o dem bang TONG, buoc 0.5, chan trong khoang -6 .. +6.
        Mot tong = hai nua cung (semitone), nen:

            o hien  0.5  ->  dich  1 nua cung
            o hien  1.0  ->  dich  2 nua cung
            o hien -1.5  ->  dich -3 nua cung

        Mot lan bam sua HAI thu cung luc:
          1. num Semitones cua plugin dich giong tren track NHAC;
          2. Key ma LiveNT ban sang plugin chinh cao do tren track MIC.

        Phai sua ca hai, va sua cung mot luong: nhac len nua tong ma giong
        van chinh theo tone cu thi hat cau nao cung chenh.  */
    juce::TextButton toneMinusButton, tonePlusButton;
    juce::Label      toneValueLabel, toneCaption;

    PluginActionButton vangButton, micButton, nhacButton;   // 06/10: chuot phai = bang nhanh
    PluginActionButton tuneButton;
    PluginActionButton lofiButton, remix1Button, remix2Button, babyButton;   // 14/10: chuot phai = Doi ten
    bool harmonyButtonAllowed = false;

    // V5.8.4: remote hang 3 tren Bang dieu khien.
    juce::Label  tuneSpeedCaption, flexTuneCaption, musicVolumeCaption, micVolumeCaption;
    juce::Label  reverbLongCaption, reverbShortCaption, delayCaption;
    LiveFineKnob tuneSpeedKnob, flexTuneKnob, musicVolumeKnob, micVolumeKnob;
    LiveFineKnob reverbLongKnob, reverbShortKnob, delayKnob;

    // 06/10: bang chuot phai (QuickPanel.h)
    std::unique_ptr<livent::quick::Window> quickWindow;
    int  quickSerial = 0;
    bool quickDragging = false;   // bang dang keo -> num khong bao "da doi" lien tuc

    // V6.1: mui ten giua hang nut va hang num.
    KnobFoldButton knobFoldButton;
    bool knobsExpanded = true;
    bool verticalLayout = false;

    //  V6.0: meter canh 7 num + MOT timer chung cho ca 7 (khai bao sau cac
    //  meter -> bi huy truoc chung, khong goi vao meter da chet).
    KnobMeter musicKnobMeter, micKnobMeter, reverbLongMeter, reverbShortMeter,
              delayMeter, tuneMeter, flexMeter;

    // 30/09: o VST cua nut hieu ung (AppBranding.h dem tu 1 -> chi so tu 0).
    static int slotLofi()   noexcept { return livent::branding::fxSlotLofi   - 1; }
    static int slotRemix1() noexcept { return livent::branding::fxSlotRemix1 - 1; }
    static int slotRemix2() noexcept { return livent::branding::fxSlotRemix2 - 1; }
    static int slotBaby()   noexcept { return livent::branding::fxSlotBaby   - 1; }
    static constexpr bool compactVertical() noexcept { return livent::branding::verticalCompactGrid; }
    // 15/10: bang Doc cung thu gon duoc 6 num (nut ⌄ tren thanh tieu de).
    bool noVerticalKnobs() const noexcept { return livent::branding::verticalHideKnobs || ! knobsExpanded; }

    std::array<KnobMeter*, 7> knobMeters()
    {
        return { &musicKnobMeter, &micKnobMeter, &reverbLongMeter, &reverbShortMeter,
                 &delayMeter, &tuneMeter, &flexMeter };
    }

    juce::TimedCallback knobMeterTimer { [this]
    {
        for (auto* m : knobMeters())
            if (m->isShowing())
                m->poll();

        for (auto* m : chipMeters())
            if (m->isShowing())
                m->poll();
    } };

    //  V6.0: bo cuc - so do chung cho resized() va getWantedHeight()
    //  01/10: equalSmallBlocks (ban khach) -> khoi 38 = 6 + nut 26 + 6, cach nhau 6.
    static constexpr bool smallBlocks = livent::branding::equalSmallBlocks;
    static constexpr int outerPadX = 6,  outerPadY = 4;
    static constexpr int secPadX   = 11, secPadY   = smallBlocks ? 6 : 7;
    static constexpr int capH      = 17, capGap    = 3;
    static constexpr int ctlH      = smallBlocks ? 26 : 32, secGap = smallBlocks ? 6 : 7;
    static constexpr int knobH     = 50, valueH    = 18;
    static constexpr int knobFoldRowH = livent::branding::foldArrowOnStatusBar ? 0 : 18;
    static constexpr int sepW      = 25, chipGap   = 4, unitGap = 6, meterW = 14;   // 12o: kieu D dung - khung 14 px (2 lane 4 px + khe 4 px)

    static constexpr int sectionHeight (int contentH)   { return secPadY * 2 + capH + capGap + contentH; }

    // V6.1.2: MSVC C++17 khong cho initializer constexpr trong class goi
    // mot member constexpr function khi class chua hoan tat. Tinh truc tiep
    // cac hang so nay de tranh C2131, con sectionHeight() van dung o resized().
    static constexpr int v6CtlSectionHeight  = secPadY * 2 + capH + capGap + ctlH;
    static constexpr int v6KnobSectionHeight = secPadY * 2 + capH + capGap + knobH + valueH;

    static constexpr int v6TopSectionHeight = secPadY * 2 + ctlH;   // V0.6.7.9d: khoi 1 khong con hang chu

    static constexpr int v6CollapsedHeight = outerPadY * 2
                                           + v6TopSectionHeight
                                           + secGap
                                           + v6TopSectionHeight   // V0.6.7.9e: khoi 2 cung khong con chu
                                           + knobFoldRowH;

    static constexpr int v6PanelHeight = v6CollapsedHeight
                                       + v6KnobSectionHeight
                                       + (livent::branding::foldArrowOnStatusBar ? secGap : 0);

    // V6.5.0: kich thuoc logical cua remote doc. Khi 7 num mo, CHI tang
    // chieu rong; chieu cao giu nguyen de khong nhay xuong taskbar.
    static constexpr int verticalCollapsedWidth = 340;
    static constexpr int verticalExpandedWidth  = 580;
    static constexpr int verticalKnobPaneWidth  = 225;
    static constexpr int verticalPanelHeight    = 440;

    //  V0.6.7.9b: BO CUC DOC theo y anh Tinh - cot hep, num + tieng cuoi xo NGANG.
    static constexpr int vColW        = 340;  // cot chinh
    static constexpr int vKnobPaneW   = 214;  // pane 6 num ben phai (3 x 2), Delay an
    static constexpr int vRowH        = 34;
    static constexpr int vChipGap     = 10;
    static constexpr int vPlayH       = 24;   // dong ten bai / ID bai hat
    static constexpr int vKnobCellH   = capH + 1 + knobH + valueH;   // 86
    static constexpr int vKnobGapY    = 6;
    static constexpr int vMeterStripH = 18;

    int verticalStyle = 1;   // 0 = mau A, 1 = mau B (xem setVerticalStyle)

    int verticalGridRows() const noexcept
    {
        // Tune Nhac Mic / Vang Lofi Remix1 / Remix2 EmBe (+Be) (+Luu bai)
        return 3;
    }

    int verticalSecTopH() const noexcept   { return secPadY * 2 + NowPlayingStrip::cardHeight + 36 + 6 + vRowH * 2 + 6; }   // 15/10: o the
    int verticalSecGridH() const noexcept  { const int r = verticalGridRows(); return secPadY * 2 + r * vRowH + (r - 1) * vChipGap; }
    int verticalSecKnobsH() const noexcept { return noVerticalKnobs() ? 0 : secPadY * 2 + vKnobCellH * 2 + vKnobGapY; }

    int verticalWantedHeight() const
    {
        // Hang Dang phat / Tone nhac / Tone bai dang nam duoi cua so YouTube -> bo khoi A.
        const int topPart = songRowHidden ? 36 : verticalSecTopH() + secGap;
        return outerPadY * 2 + topPart + verticalSecGridH() + (noVerticalKnobs() ? 0 : secGap + verticalSecKnobsH()) + 8 + customButtons.wantedHeight();
    }

    struct Caption { juce::Rectangle<int> area; juce::String text; };
    juce::Array<Caption>              captions;
    juce::Array<juce::Rectangle<int>> separators;
    juce::Rectangle<int> secTop, secChips, secKnobs, toneValueBox;
    bool updatingRemoteKnobs = false;

    juce::TextButton autoButton, autoShiftButton;

    /*  MOC 37: tong lech, don vi TONG (khong phai nua cung). Buoc 0.5. */
    /*  MOC 56: chieu cao tu keo. 0 = tu tinh theo noi dung.  */
    int  manualHeight    = 0;
    bool resizingPanel   = false;
    int  resizeStartY    = 0;
    int  resizeStartSize = 0;


    /*  MOC 81: nang tu 190 len 220.

        190 NHO HON chieu cao tu nhien cua bang (217 px = tong dung day so
        trong getWantedHeight). Nghia la keo mep duoi xuong het co thi 27 px
        cuoi cung khong con cho: dai thoi gian (clock) co san minClockHeight
        = 26 px nen no DE LEN hang danh sach moc ben duoi.

        220 = 217 cong 3 px de tho. Neu sau nay anh them/bot mot hang trong
        resized() thi nho chinh lai con so nay cho khop.  */
    /*  ==========  MOC 94: TINH LAI SAN CHIEU CAO  ==========

        Con so nay PHAI >= chieu cao tu nhien trong getWantedHeight(), khong
        thi keo mep duoi sat day la cac hang de len nhau (dung loi da gap o
        Moc 81: 190 < 217 nen 27 px cuoi khong con cho).

        Chieu cao tu nhien sau khi giam 3 hang o Moc 94:
            5 + 27 + 6 + 24 + 8 + 28 + 8 + 20 + 4 + 38 + 3 + 26 + 5 = 202

        Nen san la 202. Phep kiem 10 (check_height) doi chieu hai con so nay
        moi lan gui bai - lech mot px la no bao.  */
    static constexpr int minOpenHeight = v6CollapsedHeight;

    float toneOffsetTong = 0.0f;
    bool  resetToneOnNewSong = true;   // V4.5: false = GIỮ, true = TỰ VỀ 0
    // 15/10: vang tu dong theo nhac (xem setAutoVangByMusic)
    bool  autoVangByMusic = false;
    int   autoVangMusicTicks = 0, autoVangSilentTicks = 0;
    int   autoVangLastDecision = -1;   // -1 chua quyet, 0 = da tat, 1 = da bat
    bool  autoVangKeyReady = false;    // da do xong Key/Scale cua bai dang mo

    /*  MOC 39: ly do hong LAN TRUOC.

        Bung lai hop thoai khi ly do DOI, chu khong phai moi lan bam. Bam
        lien 5 nac ma nhay 5 hop thoai giong het nhau thi khong ai doc; con
        chi bung dung mot lan ca phien (ban Moc 38) thi sua xong thu nhat,
        gap loi thu hai lai im lang, khong biet duong nao lan.  */
    juce::String lastToneFailure;

    /*  Key/Scale GOC do VPS2 tra ve -- CHUA cong tong lech.

        Phai giu rieng ban goc: moi lan anh bam +/- la phai tinh lai tu day.
        Neu chi giu ban da dich roi cong tiep len no, bam 4 lan la sai tich
        luy 4 lan, va khong con duong nao ve lai dung goc.  */
    juce::String baseKey, baseScale;
    int manualKeyShiftSemitones = 0;
    juce::String manualScaleOverride;
    TonePush::Reader pluginToneReader;
    livent::akbroadcast::Writer autoKeyBroadcastWriter;   // 31/10: luong ghi file Auto-Key.handoff
    bool pluginToneFollowing=false;
    juce::String mirroredKey,mirroredScale;
    juce::String folkSourceScale;   // 06/10: Scale goc truoc khi doi sang Dorian (che do do tay)
    juce::uint64 toneWriteSerial=0;
    juce::uint32 pluginToneWriteUntilMs=0;

    ToneClock    clock;
    livent::autokey::PlaybackClock autoKeyPlaybackClock;
    juce::String detectedVideoId;

    // 03/10: fallback dong ho cho trinh duyet khong co tag [Xs].
    // Chi de hien thoi gian; timeline auto-shift van chi tin thoi gian THAT.
    juce::String fallbackClockVideoId;
    double fallbackClockSeconds = 0.0;
    double fallbackClockLastMs = 0.0;

    /* V5.8.5: bai mo tu THU VIEN dung tone da luu lam nguon chinh. */
    juce::String libraryToneVideoId;

    /* Chan callback VPS cu da xep hang ve MessageManager ghi de bai moi. */
    juce::uint64 detectRequestSerial = 0;
    juce::uint64 awaitingVpsSerial = 0;

    juce::Label resultLabel, statusLabel, timelineLabel;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TonePanel)
};
