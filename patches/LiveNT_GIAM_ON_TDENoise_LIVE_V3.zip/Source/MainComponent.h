#pragma once
#include <thread>

#include <JuceHeader.h>
#include <vector>
#include "Theme.h"
#include "Mixer.h"
#include "LoopbackMeter.h"
#include "MixerUI.h"
#include "ChannelEqPanel.h"
#include "ModeSwitch.h"   // 14/10: cong tac LIVE | THU
#include "UtilityWindow.h"
#include "PluginWindowManager.h"
#include "PluginPicker.h"
#include "PluginScanner.h"
#include "StartupScan.h"
#include "Splash.h"
#include "Dialogs.h"
#include "TonePanel.h"
#include "AutoKeyController.h"
#include "ScanDialog.h"
#include "MixerView.h"
#include "MixerPanelLayout.h"
#include "InspectorInsertLayout.h"
#include "BrandTitleLabel.h"
#include "MasterMeterPanel.h"
#include "WorkspacePanelLayout.h"
#include "KeyboardShortcuts.h"
#include "WindowShortcutRouter.h"
#include "TimelineJoin.h"
#include "PortableProject.h"
#include "InputSetupPanel.h"
#include "ExportDialog.h"   // V0.6.7.7
#include "ProjectHub.h"     // 06/10: man Tao / Mo du an moi
#include "YouTubeLauncher.h" // cua so YouTube chay tien trinh rieng
#include "VideoController.h" // 07/10 _D: cua so video chay theo dau phat

/** Bang Inspector ben trai: Routing, Inserts, Sends, Volume/Pan. */
class InspectorPanel : public juce::Component,
                       private juce::Timer
{
public:
    InspectorPanel (Mixer& m);
    ~InspectorPanel() override { setLookAndFeel (nullptr); }

    void paint (juce::Graphics& g) override;
    void resized() override;

    void setTrack (Track* t);

    /*  14/10: BANG TONG QUAN KENH (nut "e"). Cung mot InspectorPanel nhung xep
        thanh 4 cot: INSERT | EQ | SEND | KENH (nut, am luong, pan, dong ho, routing).
        Bang thuong (Inspector ben trai F2) khong doi gi.  */
    void setOverviewLayout (bool on);
    bool isOverviewLayout() const noexcept { return overviewLayout; }
    std::function<void()> onOpenOverview;   // nut "e" canh nut Loa trong Inspector

    /*  MOC 36: ve lai bang Inspector theo trang thai HIEN TAI cua track.

        Khac setTrack(): khong doi track dang chon, chi doc lai va ve lai.
        Dung khi trang thai bi doi tu cho khac - vd hang nut dien trong bang
        do tone tat vang cua track MIC.

        PHAI nam o vung public: MainComponent goi ham nay tu ben ngoai lop.  */
    void refreshFromTrack();

    /*  MOC 48: xo/thu tung muc trong bang, va doc lai trang thai do.

        Danh so 0..3 thay vi truyen ten muc: ten co the doi (co luc la
        "INSERT", co luc la "INSERT (7)"), con so thu tu thi khong.  */
    bool isSectionOpen (int index) const;
    void setSectionOpen (int index, bool shouldBeOpen);

private:
    SectionHeader* sectionAt (int index);

public:

    /*  MOC 43: day cac o insert ra de lo mot khe ho o vi tri se tha.
        steps = 0 nghia la xoa khe ho, tra moi o ve cho cu.  */
    void previewInsertGap (int draggedIndex, int steps);

    /*  ==========  MOC 78: CAO THAT SU CUA NOI DUNG  ==========

        Bang nay xep tu tren xuong, gan bao nhieu VST thi dai bay nhieu -
        khong co gioi han. Truoc day no bi cat cung bang chieu cao khung
        chua, nen gan tu ~8 plugin tro len la may cai cuoi bi cat mat, khong
        cach nao keo toi.

        MainComponent doc con so nay de cho ca bang vao mot Viewport (khung
        cuon) va biet keo bao xa. Tinh NGAY TRONG resized() chu khong tinh
        lai o cho khac: tinh lai la ban sao thu hai cua ca bo cuc, sua mot
        ben quen ben kia.  */
    int getContentHeight() const noexcept   { return contentHeight; }

    /*  MOC 78: bao ra ngoai khi chieu cao noi dung THAY DOI (them/bot mot o
        insert, xo hay thu mot muc...). MainComponent nghe cai nay de chinh
        lai khung cuon - nho vay khong phai di rai loi goi refit o hang chuc
        cho goi rebuildInserts/setTrack/refreshFromTrack rai rac trong file.

        Chi ban khi con so THAT SU doi, khong ban moi lan resized() - khong
        thi thanh vong lap vo tan.  */
    std::function<void()> onContentHeightChanged;

    /** MOC 43: toa do y goc cua tung o insert, de tra ve sau khi keo. */
    juce::Array<int> insertRowHomeY;
    Track* getTrack() const noexcept { return currentTrack; }

    void rebuildInserts();
    void rebuildSends();
    void rebuildRouting();

    /** MainComponent cung cap ten cac cong vao that cua card. */
    std::function<juce::StringArray()> getInputChannelNames;

    /*  MOC 26: ten cac CONG RA that cua card, de track AM THANH RA chon do
        tieng ra cap nao (Link 7/8...). Do MainComponent gan, vi chi no moi
        cam duoc deviceManager.  */
    std::function<juce::StringArray()> getOutputChannelNames;
    std::function<juce::StringArray()> getAllOutputChannelNames;
    std::function<int(int)> getActiveOutputPairIndex;
    std::function<int(int)> activateOutputPair;
    std::function<juce::String()> getOutputDeviceIdentity;

    std::function<void(int)> onChoosePlugin;   // index o insert
    std::function<void(int)> onOpenEditor;
    std::function<void()>    onTrackChanged;
    std::function<void(Track*)> onExpandEq;

    /*  Goi NGAY TRUOC khi mot plugin bi xoa khoi chuoi insert, de
        MainComponent kip dong cua so giao dien cua no. Khong co cai nay thi
        cua so van con song trong khi plugin da bi huy -> app treo. */
    std::function<void(juce::AudioPluginInstance*)> onPluginAboutToBeRemoved;

    /*  Goi NGAY TRUOC khi doi cho hai plugin trong chuoi. Ma dinh danh cua so
        plugin la "t<id track>:s<so o>", doi cho xong la ma do tro nham plugin
        khac -> MainComponent dong het cua so cua track nay truoc. */
    std::function<void()> onInsertsReordered;

private:
    void timerCallback() override;
    void chooseAudioFile();
    void showAddSendMenu();

    Mixer& mixer;
    Track* currentTrack = nullptr;

    //  MOC 78: cao that su cua noi dung, dat o CUOI resized() - xem
    //  getContentHeight() o vung public.
    int contentHeight = 0;

    workspace::LookAndFeel workspaceLook;
    juce::Label titleLabel, trackTypeLabel;
    juce::TextButton trackMute { "M" }, trackSolo { "S" };
    RecordArmButton trackArm;
    IconButton trackMonitor { Icon::Speaker, true };
    ChannelEditButton overviewButton;   // 14/10
    bool overviewLayout = false;        // 14/10
    juce::String lastStructure;         // 14/10: bang tong quan tu dung lai khi Insert/Send doi
    juce::String structureSignature() const;
    void layoutOverview();
    LevelMeter channelMeter { false };
    juce::Rectangle<int> gainControlRow, panControlRow;
    juce::Label meterDbLabel, channelCaption { {}, livent::vn ("Kênh vào") };

    /*  Ba muc thu gon duoc. Track co 8 plugin thi chuoi insert dai loang
        ngoang; thu gon lai la nhin thay ngay Send va Volume.
        Tham so thu hai = co nut cong tac tong ben phai hay khong.  */
    SectionHeader routingHeader { livent::vn ("ROUTING"),         false };   // 07/10: nhu Cubase
    ChannelEqPanel eqPanel;
    SectionHeader eqHeader { "EQ", true };
    SectionHeader insertsHeader { livent::vn ("INSERT"),      true  };
    SectionHeader sendsHeader   { livent::vn ("SEND"),        true  };
    SectionHeader levelHeader   { livent::vn ("KÊNH"), false };

    //-- Routing -------------------------------------------------------------
    /*  MOC 52: hang nay chi con hien khi chon livent::vn ("Đường vào trực tiếp") o
        sourceBox ben duoi -- la cho chon CONG VAT LY that su.  */
    juce::Label    inLabel   { {}, livent::vn ("Cổng") };
    juce::ComboBox inputBox;
    juce::ComboBox channelModeBox;
    juce::Label    outLabel  { {}, "Out" };
    juce::Label    pkSourceLabel;   // MOC 28: chu livent::vn ("Nghe:") cua track PK
    juce::ComboBox outputBox;

    /*  MOC 26b: nut chon CAC cap cong ra cho track AM THANH RA.

        Khong dung ComboBox duoc: hop xo chi chon duoc MOT muc, ma anh can
        bat nhieu duong cung luc (loa + day sang Cubase). Nen dung mot nut
        hien tom tat, bam vao xo ra menu co dau tich.  */
    /*  MOC 40: ma so cua muc livent::vn ("-- Không nghe gì --") trong hop nguon cua PK. */
    static constexpr int pkSourceNone = 9999;

    juce::TextButton outPairsButton;
    void showOutPairsMenu();
    void refreshOutPairsButton();
    juce::StringArray getOutPairNames() const;

    /*  MOC 52: day gio la hang "In" CHINH - MIC va NHAC dung chung mot
        kieu chon: hoac livent::vn ("Đường vào trực tiếp") (roi chon cong vat ly o hang
        duoi), hoac lay thang tu mot track cong vao (MONO IN / STEREO IN).
        Bo hoan toan lua chon "File nhac trong may" - anh hat chu yeu lay
        nhac YouTube qua card, khong can nap file.  */
    juce::Label    srcLabel  { {}, "In" };
    /*  MOC 51: ma so cac muc "lay tu track cong vao" = 1000 + id track.
        Cach xa hai ma co dinh (1, 2) de khong bao gio dam vao nhau.  */
    static constexpr int inputTrackIdBase = 1000;

    juce::ComboBox sourceBox;

    /*  MOC 52: chi con dung cho project CU con luu source = AudioFile.
        Khong con duong nao trong giao dien moi bat len duoc hai nut nay,
        nhung van giu de mo project cu khong bi mat nut Phat giua chung.  */
    juce::TextButton openFileButton { livent::vn ("Chọn file nhạc...") };
    juce::TextButton playButton     { livent::vn ("Phát") };
    juce::Label      fileLabel;

    //-- Inserts / Sends -----------------------------------------------------
    juce::Component insertContent, sendContent;
    juce::OwnedArray<InsertSlotRow> insertRows;
    juce::OwnedArray<SendRow>       sendRows;
    juce::Viewport insertViewport, sendViewport;
    class InsertResizeHandle : public juce::Component, public juce::SettableTooltipClient
    {
    public:
        InsertResizeHandle() { setMouseCursor (juce::MouseCursor::UpDownResizeCursor); }
        std::function<void()> onStart, onFinish;
        std::function<void(int)> onDrag;
        void paint (juce::Graphics& g) override
        {
            g.setColour (Col::textDim.withAlpha (isMouseOverOrDragging() ? 0.8f : 0.35f));
            g.fillRoundedRectangle ((float) getWidth() * 0.5f - 18.0f,
                                    (float) getHeight() * 0.5f - 1.0f, 36.0f, 2.0f, 1.0f);
        }
        void mouseDown (const juce::MouseEvent& e) override
        {
            screenStart = e.getScreenPosition();
            if (onStart) onStart();
        }
        void mouseDrag (const juce::MouseEvent& e) override
        {
            if (auto* parent = getParentComponent())
                if (onDrag) onDrag (parent->getLocalPoint (nullptr, e.getScreenPosition()).y
                                   - parent->getLocalPoint (nullptr, screenStart).y);
        }
        void mouseUp (const juce::MouseEvent&) override { if (onFinish) onFinish(); }
        void mouseEnter (const juce::MouseEvent&) override { repaint(); }
        void mouseExit (const juce::MouseEvent&) override { repaint(); }
    private:
        juce::Point<int> screenStart;
    };
    InsertResizeHandle insertResizeHandle, sendResizeHandle;   // 14/10: Send cung keo gian duoc
    int preferredInsertHeight = livent::inspectorInsertLayout::defaultHeight;
    int insertDragStartHeight = 0;
    int preferredSendHeight = 0;     // 0 = tu dong (chua keo)
    int sendDragStartHeight = 0;
    juce::TextButton addSendButton  { livent::vn ("+ Thêm Send") };

    //-- Volume / Pan --------------------------------------------------------
    juce::Slider gainSlider, panSlider;
    juce::Label  gainCaption { {}, "Volume" };
    juce::Label  panCaption  { {}, "Pan" };

    std::unique_ptr<juce::FileChooser> fileChooser;

    /*  Loai track nay CAN o dieu khien nao. rebuildRouting() ghi vao day,
        con resized() moi la noi duy nhat goi setVisible - xem ghi chu trong
        rebuildRouting de biet vi sao phai tach lam hai buoc. */
    bool wantSource = false;
    bool wantInput  = false;
    bool wantOutput = false;
    bool wantPkSource = false;   // MOC 28
    bool wantFile   = false;

    int autosaveTick = 0;      // dem giay de 60 giay tu luu mot lan

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (InspectorPanel)
};


//=============================================================================
class AudioSetupDialog;   // 16/10: AudioSetupDialog.h

namespace livent::companions    { class Manager; }
namespace livent::browsersession { class Session; }

class MainComponent : public juce::AudioAppComponent,
                      private juce::Timer,
                      private juce::MenuBarModel,
                      private juce::KeyListener
{
public:
    /** fileToOpenDirectly: neu KHONG rong (vd anh dup-click 1 file .NT),
        constructor se BO QUA loadProject() (mo lai du an lan truoc) va mo
        THANG file nay -- tranh viec phai nap-roi-vut du an cu vo ich moi
        lan mo file, va tranh loi cua du an cu "lay nham" sang luc mo file
        khac hoan toan khong lien quan. */
    explicit MainComponent (const juce::File& fileToOpenDirectly = {});
    ~MainComponent() override;

    void prepareToPlay (int samplesPerBlockExpected, double sampleRate) override;
    void getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill) override;
    void releaseResources() override;

    void paint (juce::Graphics& g) override;
    void resized() override;
    void moved() override;
    void lookAndFeelChanged() override;

    //  V6.0: vung trong tren thanh menu = cho nam de keo cua so (Windows)
    void mouseDown        (const juce::MouseEvent&) override;
    void mouseDrag        (const juce::MouseEvent&) override;
    void mouseDoubleClick (const juce::MouseEvent&) override;
    void mouseUp          (const juce::MouseEvent&) override;   // 06/10: nho cho thanh gon sau khi keo   // V6.0.1: popup CƯỜI bám theo toàn cửa sổ LiveNT

    /*  MOC 57: hoi "Luu / Khong luu / Huy" luc bam nut X - MainWindow (Main.cpp)
        goi cai nay thay vi tu dong dong luon, nen phai la PUBLIC (Main.cpp la
        mot class khac, khong phai ham thanh vien cua MainComponent).  */
    void showActivationDialog();
    void confirmCloseAndQuit();

    // V6.6.3f: duong cuu ho soundcard. Chi duoc Main.cpp goi sau khi nguoi
    // ban/quan tri da nhap dung mat khau F2. Mo thang bang soundcard o che do
    // khoa lai, de doi sang card moi ma khong phai xoa file cau hinh bang tay.
    void openSoundcardRecoverySettings();

    // V5.8.7: trạng thái ghim cửa sổ chính được nhớ giữa các lần chạy.
    static bool loadMainAlwaysOnTopPreference();
    static void saveMainAlwaysOnTopPreference (bool on);

    /* V6.6.4 HUB SIZE FIX: MainWindow chi luu window.txt khi dang co project.
       Hub co kich thuoc rieng, khong duoc ghi de bo cuc lam viec lan truoc. */
    bool isVerticalControlLayout() const noexcept { return verticalControlLayout; }
    bool hasOpenProjectForWindowLayout() const noexcept { return projectOpen; }

private:
    void openAudioSettings (bool lockAfterSave = false, bool headlessDriverSwitch = false);
    /** 15/10: chon driver tu danh sach -> doi ngam o tien trinh phu (khong hien bang). */
    void switchAudioDriver (const juce::String& type, const juce::String& name, const juce::String& inputName);
    void showExpandedEq(Track*);
    std::unique_ptr<livent::UtilityWindow> expandedEqWindow;
    std::unique_ptr<livent::UtilityWindow> channelOverviewWindow;   // 14/10: nut "e"
    class ChannelOverviewContent* channelOverviewContent = nullptr;  // so huu boi channelOverviewWindow
   #if JUCE_WINDOWS
    void showAudioSetupGuide();
    std::unique_ptr<livent::UtilityWindow> audioGuideWindow;
   #endif
    juce::String expandedEqTrackUuid;
    void openPluginScanner();
    void openScanPathEditor();              // sua danh sach thu muc quet
    void startBackgroundScan();             // quet tu dong luc khoi dong
    void updateStartupScanProgress();       // moi giay: bao tien do len splash

    void removeSelectedTrack();

    /*  MOC 21: bo nut "+ Them Track" / "- Xoa Track" rieng - thay bang
        chuot phai vao khoang trong duoi danh sach track (giong Cubase).
        Bam chuot phai dung tren mot track thi co them muc "Xoa track". */
    void showTrackListContextMenu (juce::Point<int> screenPos, Track* rightClickedTrack);

    void rebuildTrackList();
    void showAddTrackDialog(Track::Type, const juce::String&);
    void selectTrack (int index);
    void showPluginMenuForSlot (int slot);

    /** MOC 61: menu chuot phai tren mot o insert - mo / thay / go. */
    void showSlotContextMenu (int slot);
    void removePluginFromSlot (int slot);

    /** MOC 63: bat/tat duong vao phu (sidechain) cua mot plugin. */
    void toggleSidechain (int slot);
    /*  11j: thanh cong cu cua so VST (BYPASS / SIDECHAIN nhieu nguon / PRESET / A-B / chep-dan).  */
    void setupPluginToolbarHooks();
    void refreshAfterPluginToolbarChange();
    struct PluginAB { juce::MemoryBlock a, b; juce::String identity; int active = 0; };
    std::map<juce::String, PluginAB> pluginAB;
    juce::MemoryBlock pluginClipboard;
    juce::String pluginClipboardIdentity, pluginClipboardName;
    std::unique_ptr<juce::FileChooser> presetChooser;

    /** MOC 61: keo mot plugin sang track khac, giu nguyen moi thong so. */
    void movePluginBetweenTracks (int srcTrackId, int srcSlot,
                                  Track& dest, int destSlot, bool copy = false, bool replace = false);
    void toggleEditorForSlot (int slot);
    void openEditorForSlot (int slot, Track* requestedTrack = nullptr); // MOC 59
    void updateStatusText();

    void saveDeviceSettings();
    std::unique_ptr<juce::XmlElement> loadDeviceSettings();

    // V6.6.3: khoa soundcard de LiveNT khong tu roi sang Built-in/Default
    // khi nguoi dung quen cam card truoc luc mo app.
    void loadSoundcardLockState();
    void toggleSoundcardLock();
    void withAdminPassword (const juce::String& title, std::function<void()> action);
    bool currentAudioMatchesSoundcardLock() const;
    juce::String getSoundcardLockDisplayName() const;
    void updateSoundcardLockStartupWait();
    void showSoundcardLockWarningIfNeeded();

    // V6.6.3: ung dung di kem - chon mot app/exe de mo sau LiveNT va dong theo.
    void loadCompanionAppPreference();
    void saveCompanionAppPreference();
    void chooseCompanionApp();
    void showCompanionAppMenu();
    void launchCompanionApp();
    void stopCompanionApp (bool waitForExit = false);
    juce::String getCompanionAppDisplayName() const;

    // V4.8: soundcard settings process phu + phuc hoi audio sau khi dong/crash.
    void finishExternalAudioSettings();

    //-- Du an .NT -----------------------------------------------------------
    void newProject();
    void saveProject();                     // luu vao file dang mo
    void saveProjectAs();                   // hoi cho luu moi
    void saveDefaultMix (bool allowOverwrite = false); // moc mix/VST rieng cua project
    void restoreDefaultMix();               // giu nguyen file nhac va timeline
    juce::File getDefaultMixFile() const;

    /*  MOC 57: closeForReal() la buoc dong THAT SU sau khi da hoi xong -
        rieng confirmCloseAndQuit() (goi tu Main.cpp) da chuyen len PUBLIC
        o dau file, xem ghi chu tren do.  */
    void closeForReal();
    void closeProject();                    // dong .NT nhung giu LiveNT mo
    void closeProjectNow();
    void openProjectDialog();               // hop thoai mo file .NT
    void requestOpenProject (const juce::File& file); // hoi luu du an dang mo truoc khi doi file
    void markProjectDirty() noexcept
    {
        if (projectOpen)
        {
            projectDirty = true;
            autosaveDirty = true;
            /* V6.4.6: autosave LITE nen re. Moi thay doi se duoc checkpoint
               trong toi da ~10 giay, thay vi co the doi tron 60 giay. */
            autosaveTick = juce::jmax (autosaveTick, 50);
        }
    }

    bool writeProjectTo (const juce::File& file);
    std::unique_ptr<juce::XmlElement> buildProjectStateXml (bool includePluginState = true);   // MOC 65
    juce::String buildComparableProjectState();
    bool hasUnsavedChanges();                                    // MOC 65
    void setCurrentProjectFile (const juce::File& file);
    void updateTitleText();

    // MOC 96: man hinh chao / Hub khi chua co du an, giong cach cac DAW lon
    // tach VO UNG DUNG khoi TAI LIEU dang mo.
    void refreshProjectHub();
    void updateProjectUiState();
    void compactControlPanelWindow();
    void applyUiScaleFromMenu (double scale);   // V0.6.7.7: doi ti le xong tu thu gon cua so

    // V6.5.0: giao dien doc cho che do hat live; 7 num mo sang ben phai.
    void setVerticalControlLayout (bool on, bool persistPreference, bool markProject);

    // MOC 96: mat khau F2 doi duoc ma khong can build lai.
    void changeWorkPanelPassword();

    // MOC 96: duong dan co dinh cho bridge VST 32-bit tu viet sau nay.
    static juce::File getVst32BridgeFile();

    static juce::File getDefaultProjectFolder();
    juce::File getAutosaveFile() const;

    void saveRecentList();
    void loadRecentList();

    //-- An toan du lieu -----------------------------------------------------
    void timerCallback() override;          // tu luu dinh ky
    void updateAudioDeviceWatchdog();       // HOTFIX11: canh soundcard rot giua buoi
    bool isAudioDeviceHealthy() const;
    void writeAutosave();                   // ghi recovery LITE, khong hoi VST chunk
    void writeRecoveryCheckpoint();          // ghi ngay sau thay doi cau truc quan trong
    void clearAutosave();                   // xoa project.pending (thoat sach)
    void checkForCrashRecovery();           // khoi dong: co ban chua luu khong?
    void loadProject();
    bool loadProjectFrom (const juce::File& file);

    // HOTFIX10: mo project kieu Cubase - dung track/routing truoc, sau do
    // nap tung VST theo hang doi worker de message thread khong bi dung.
    void startProjectPluginLoadQueue (const juce::XmlElement& projectXml, bool fromRecovery);
    void beginProjectPluginLoadQueue();   // 14/10: sau khi hoi doi VST 32 -> 64-bit
    void deleteRecordingProject();        // 14/10: Tep > Xoa du an thu am (vao Thung rac)
    void cleanUnusedRecordings();         // 14/10: Tep > Don file thu khong dung
    void removeMissingTimelineClips();    // 14/10: nut "Xoa cac doan thieu"
    void openChannelOverview (Track* t);   // 14/10: nut "e" -> bang tong quan kenh
    void closeChannelOverview();
    void loadNextProjectPlugin();
    void cancelProjectPluginLoad();
    void finishProjectPluginLoadQueue (bool cancelled);

    void saveWindowLayout();
    void loadWindowLayout();
    bool saveMusicVst2WindowPreference (const juce::File& projectFile);
    void loadMusicVst2WindowPreference (const juce::File& projectFile);
    void openMusicVst2AfterProjectLoad();

    void togglePerformanceMode();
    void runAudioDropoutDiagnosis (int seconds = 10);   // 11i: 10 hoac 60 giay

public:
    /*  ==========  HAI HAM NAY PHAI O PUBLIC  ==========

        Main.cpp goi MainComponent::loadUiScale() TRUOC khi dung cua so chinh,
        de ap muc thu phong ngay tu dau -- khong thi cua so dung theo 100% roi
        moi scale sau, nhin giat mot cai.

        Ma luc do chua he co doi tuong MainComponent nao ca, nen phai la ham
        static VA phai o public thi ben ngoai moi goi duoc. De trong private
        thi bao:

            error C2248: cannot access private member declared in class

        Chung khong dung toi bien thanh vien nao, chi doc/ghi mot file cau hinh
        nho, nen de public hoan toan an toan.  */
    static double loadUiScale();
    void applyTextScaleFromMenu (double scale);
    void openAudioSetupDialog (int startPage);   // 14/10: Thiet lap am thanh (gop)
    void openInputSetupLegacy (juce::Component* anchor = nullptr);
    bool reopenAudioSetupAfterSettings = false;   // 14/10: co chu Cai dat / Huong dan
    static void   setUiScale (double scale);   // luu + ap dung ngay lap tuc

    /** Goi khi cua so chinh duoc dua len truoc: keo theo moi cua so plugin. */
    void bringPluginWindowsToFront();

    /** Mo mot file .NT tu ben ngoai (nhan dup o File Explorer). */
    void openProjectFile (const juce::File& file);

    /** Main.cpp kiem tra sau khi hien cua so: du an tu dong lenh da mo that chua
        (dang nap VST cung tinh la da mo). */
    bool isShowingProject (const juce::File& file) const
    {
        return projectOpen && currentProjectFile == file;
    }

    /** V6.5: nhan lenh tu bo phim tat toan cuc cua Main.cpp.
        action: 1=F2, 2=F3, 3=Play/Stop, 4=Zoom out, 5=Zoom in.
        V6.6.4: duong nay bi khoa toi khi cua so chinh da hien va F-key da tha. */
    void handleGlobalShortcut (int action);

    /** V6.6.3: Main.cpp goi dung luc cua so DAW da hien xong sau Splash.
        Day la moc de mo ung dung di kem - khong tranh CPU/IO voi khoi dong audio. */
    void onMainWindowRevealed();

private:
    void dumpPluginParametersToFile();
    livent::shortcuts::Map keyboardShortcuts;
    WindowShortcutRouter shortcutRouter;
    struct ShortcutTarget { livent::shortcuts::Command command; juce::Component::SafePointer<juce::Button> button; };
    std::vector<ShortcutTarget> shortcutTargets;
    void rebuildShortcutCommands();
    juce::String shortcutScope() const;
    bool executeShortcut (const juce::String& id);
    bool queueShortcut (const juce::KeyPress& key);
    void joinTimelineClips (const juce::StringArray& ids, bool renderInPlace = false);
    std::shared_ptr<livent::joining::Job> clipJoinJob;
    std::thread clipJoinWorker;
    void packageProject();
    void beginPackageProject(const juce::File&, bool reference);
    bool canRunHeavyWork();
    std::shared_ptr<livent::portable::Job> packageJob;
    std::thread packageWorker;
    std::unique_ptr<juce::FileChooser> packageChooser;
    bool lastAreaWasMixer = false;
    class AreaFocusListener final : public juce::MouseListener
    {
    public:
        std::function<void (juce::Component*)> clicked;
        void mouseDown (const juce::MouseEvent& e) override { if (clicked) clicked (e.eventComponent); }
    } areaFocusListener;
    // V6.6.4: chong shortcut F bi kich nham/lon luc LiveNT vua khoi dong.
    void armFunctionShortcutsWhenReleased();
    bool functionShortcutsReady = false;


    Mixer mixer;
    PluginWindowManager pluginWindows;
    livent::autokey::Controller autoKeyController;
    void openMusicAutoKey(bool locked,bool startSequence);
    void openAutoKeyAutomationSettings();
    void updateVpsConfiguration();
    bool vpsUpdateRunning=false;
    juce::ThreadPool vpsUpdatePool {1};


    std::unique_ptr<juce::ChildProcess> audioSettingsProcess;
    bool audioSettingsLockAfterSave = false;
    bool audioSettingsHeadless = false;            // 15/10: doi driver ngam (khong cua so)
    juce::Component::SafePointer<AudioSetupDialog> audioSetupDialogLive;   // 16/10: bang dang mo (hien vong quay khi doi driver)
    juce::uint32 audioSettingsStartedMs = 0;   // V6.6.3c: helper dang o che do chon thu cong de khoa soundcard
    int requestedAudioInputs = 2;
    int requestedAudioOutputs = 2;
    int selectedTrackIndex = 0;

    // V6.6.3 - khoa soundcard. Luu rieng, KHONG ghi vao project .NT.
    bool soundcardLockEnabled = false;
    bool soundcardLockWaiting = false;
    bool soundcardLockAlertShown = false;
    int  soundcardLockRetryTicks = 0;
    std::unique_ptr<juce::ChildProcess> lockedSoundcardProbe;
    juce::File lockedSoundcardProbeResult;
    juce::uint32 lockedSoundcardProbeStartedMs = 0;
    juce::String soundcardLockDeviceType;
    juce::String soundcardLockInputName;
    juce::String soundcardLockOutputName;
    juce::String soundcardLockBackendAsioDriver; // V6.6.3d: driver that trong ASIO Link Pro / Pick driver
    juce::String soundcardLockWindowsPhysicalDevice;
    bool soundcardLockRequiresWindowsPhysicalDevice = false;

    // 12u: NHIEU app mo cung LiveNT; tat LiveNT la tat het (CompanionApps.h).
    std::unique_ptr<livent::companions::Manager> companions;
    // 12u: trinh duyet YouTube LiveNT da mo -> tat LiveNT thi dong theo (BrowserSession.h).
    std::unique_ptr<livent::browsersession::Session> browserSession;
    bool mainWindowRevealed = false;
    void openYouTubeInBrowser (bool quietIfFails);

    juce::Label      titleLabel { {}, "LiveNT" };
    juce::Label      subtitleLabel;

    /*  ==========  MOC 24: THANH MENU THAT  ==========

        Truoc day tren dau chi co hai nut vuong to: "File" va "Tien ich". No
        chay duoc, nhung nhin khong giong phan mem thu am chuyen nghiep -- moi
        DAW (Cubase, Studio One, Reaper) deu co mot THANH MENU chu nho chay
        ngang tren cung: File / Edit / Project / Audio / Studio / Window.

        juce::MenuBarComponent la thanh do. No hoi noi dung tung menu qua lop
        MenuBarModel -- chinh la MainComponent nay (xem 3 ham
        getMenuBarNames / getMenuForIndex / menuItemSelected ben duoi).

        Loi thuc te chu khong chi dep: menu xo xuong thi nhet duoc nhieu muc
        va co nhom, nen sau nay them chuc nang moi (thu am, MIDI...) cu bo
        vao dung menu cua no -- khong phai nhoi them nut vao thanh tren cho
        toi khi het cho.  */
    juce::MenuBarComponent menuBar { this };

    /*  V5.8.1 - thanh window da tra ve native. Hai nut thu vien van nam
        tren thanh menu mong trong client de khong lam dai hang dieu khien. */
    struct TitleActionButton : public juce::TextButton
    {
        std::function<void()> onRightClick;
        void mouseDown (const juce::MouseEvent& e) override
        {
            if (e.mods.isPopupMenu())
            {
                if (onRightClick) onRightClick();
                return;
            }
            juce::TextButton::mouseDown (e);
        }
    };

    workspace::LookAndFeel controlFooterLook; // declared before the buttons that use it
    TitleActionButton topSaveSongButton;
    juce::TextButton topSongListButton;

    // YouTube chay thanh tien trinh rieng (LiveNT-YouTube), giong VST tach.
    // Bam: mo / dua len truoc. Chuot phai: ghim tren cung, dong YouTube.
    TitleActionButton topYouTubeButton;
    YouTubeLauncher youtube;

    /*  Cua so con (Danh sach bai, Cai dat, F2/F3, hop thoai...) mo ra trong
        luc DAW / YouTube dang "luon noi": tu noi len tren ngay lan dau, khong
        bi hai cua so kia de len. Kiem 8 lan/giay, chi xu ly cua so MOI. */
    struct ChildWindowRaiser final : juce::Timer
    {
        std::function<bool()> shouldFloat;
        std::function<bool()> paused;
        std::function<juce::Component*()> mainWindow;
        std::vector<juce::Component::SafePointer<juce::Component>> seen;
        void timerCallback() override;
    };
    ChildWindowRaiser childRaiser;

    void openYouTubeWindow();
    void showYouTubeMenu();
    void setYouTubeZoomPercent (int percent);  // 15/10: 0 = Tu dong, 70..110 = %
    void setYouTubeSizePreset (const juce::String& key);   // 12r: "" / small / left / right / large / full
    void pressYouTubeButton();                 // 15/10: mo YouTube bang DAW hoac trinh duyet da chon
    void pressLaughButton();                   // 15/10: bang tieng cuoi DAW hoac app tieng cuoi ngoai
    void showLaughMenu();
    void chooseExternalLaughApp();
    std::unique_ptr<juce::FileChooser> laughAppChooser;
    juce::Rectangle<int> topCaptionDivider;    // 15/10: vach ngan giua nut thao tac va cum bieu tuong
    void applyYouTubeSource();   // an/hien nut YouTube, tat cua so khi dung trinh duyet rieng
    void copyContactPhone();     // so lien he: Source/AppBranding.h
    void publishDawWindowForYouTube();   // de cua so YouTube hut dinh bam theo DAW
    void setYouTubeDockSide (const juce::String& side);   // "top"/"bottom" (Ngang), "right"/"left" (Doc)
    juce::String lastPublishedDawWindow;

    /*  30/09: mo du an tu Hub -> DAW ve dung vi tri lan truoc (window.txt).
        Dong du an ve Hub -> ghi lai vi tri truoc khi Hub phong to. */
    void restoreProjectWindowPosition();
    void saveProjectWindowPosition();
    juce::File projectWindowFile() const;
    bool uiShowingProject = false;
    bool projectWindowPlaced = false;   // YouTube chi dat canh DAW sau khi DAW da ve cho
    void handleYouTubeWindowCommand (const juce::String& cmd);   // nut tren cua so YouTube

    /*  V29/09: cua so DAW sat mep duoi, mo 7 num -> cao ra nen bi DAY LEN.
        Nho vi tri truoc khi day de thu lai thi VE DUNG CHO CU (sat mep).
        Nguoi dung tu keo cua so di cho khac thi quen vi tri cu.  */
    juce::Rectangle<int> placeWithLiftMemory (juce::Component& top,
                                              juce::Rectangle<int> target);
    bool autoLiftActive = false;
    juce::Rectangle<int> autoLiftOriginal;     // bounds truoc khi bi day
    juce::Point<int>     autoLiftAppliedPos;   // vi tri DAW tu dat
    void setYouTubeSource (livent::youtube::Source source);
    juce::TextButton topFileButton;
    void refreshModeSwitch();
    TitleActionButton topLaughButton;        // 15/10: chuot phai = chon bang cuoi DAW / app tieng cuoi ngoai
    juce::TextButton topRecordButton;
    juce::TextButton topExportButton;
    juce::TextButton topSettingsButton;
    juce::TextButton topHelpButton;          // 02/10: nut "?" che do huong dan  -> 06/10: nut "▾ Gon"

    //  06/10: THANH THU GON (mau 1B) - xem toggleCompactMode()
    bool compactMode = false;
    juce::TextButton compactExpandButton, compactCloseButton;
    juce::Rectangle<int> compactLogoArea;
    juce::ComponentDragger compactDragger;
    bool compactUiActive() const noexcept { return compactMode && projectOpen; }
    void toggleCompactMode();
    void layoutCompactBar();
    static bool loadCompactPref();
    static void saveCompactPref (bool on);
    //  06/10: thanh gon co cho RIENG (khong dung chung cho cua giao dien day du)
    //  + chuot phai logo: Sat mep duoi / Sat mep tren / Tu do.
    int  compactDock = 2;                       // 0 tu do, 1 sat mep tren, 2 sat mep duoi (07/10 _F: mac dinh DUOI)
    juce::Point<int> compactPos;  bool compactPosValid = false;
    juce::Rectangle<int> fullBoundsBeforeCompact;
    void loadCompactPlace();
    void saveCompactPlace();
    void placeCompactBar();                     // dat thanh gon theo cho nho / mep da chon
    void showCompactBarMenu();
    /*  07/10 _F: chuot phai nut "▾ Gon" (giao dien day du) -> chon mep roi
        thu gon luon. Nut van bam trai = thu gon nhu cu.  */
    void showGonDockMenu();
    struct GonRightClick final : public juce::MouseListener
    {
        explicit GonRightClick (MainComponent& o) : owner (o) {}
        void mouseDown (const juce::MouseEvent& e) override
        {
            if (e.mods.isPopupMenu())
            {
                owner.suppressGonClick = true;
                owner.showGonDockMenu();
            }
            else
                owner.suppressGonClick = false;
        }
        MainComponent& owner;
    };
    GonRightClick gonRightClick { *this };
    bool suppressGonClick = false;
    void lowerAllWindowsTemporarily (int seconds);   // 06/10: nhap key VST bang chuong trinh ngoai
    void restoreLoweredWindows();
    std::unique_ptr<juce::Timer> foreignRaiser;       // 06/10: ForeignDialogRaiser.h (chi Windows)
    std::vector<juce::Component::SafePointer<juce::Component>> loweredWindows;
    bool windowsLowered = false, youtubeLowered = false;
    int lowerGeneration = 0;
    void openTuneExtensionGuide();
    void openGuideWindow (int page);                 // 06/10: huong dan chi tiet (Cai dat > Ban quyen)
    livent::help::Overlay helpOverlay;       // 02/10
    void setHelpMode (bool on);
    void setupTopHelpTexts();
    juce::TextButton topLayoutButton;   // V0.6.7.9: 1 cham doi Ngang <-> Doc
    void refreshTopLayoutButton();

    // V6.5.0: che do portrait/live. Luu rieng trong project va co preference
    // chung cho project moi; audio engine khong phu thuoc bien nay.
    bool verticalControlLayout = false;

    // HOTFIX13: owner cua bang Cai dat dang xo. HOTFIX9 doi tu tab nhung
    // member nay da bi sot khoi header, trong khi MainComponent.cpp van dung
    // no de dong/mo va doi kich thuoc popup. Luu theo lop co so de header
    // khong can biet SettingsPopupWindow (lop cuc bo trong .cpp).
    std::unique_ptr<juce::DocumentWindow> settingsWindow;

    BrandTitleLabel topBrandLabel;
    void setupMenuActionButtons();
    void refreshTopRecordButton();

    /*  ==========  V6.0: THANH TREN TU VE (Windows)  ==========
        Bo thanh window cua Windows: logo ben trai chu Tep, nut thu nho + X
        ben phai nut Luu, khoang trong giua de nam keo cua so.
        Mac giu thanh he thong (3 nut tron) nen cac thu nay an tren Mac.  */
    class TitleBarButton : public juce::Button
    {
    public:
        enum Kind { closeKind, minimiseKind };

        explicit TitleBarButton (Kind k)
            : juce::Button (k == closeKind ? "close" : "minimise"), kind (k)
        {
            setTitle (k == closeKind ? livent::vn ("Tắt app") : livent::vn ("Thu nhỏ"));
            setTooltip (getTitle());
        }

        void paintButton (juce::Graphics& g, bool over, bool down) override
        {
            const auto bounds = getLocalBounds().toFloat();
            if (kind == closeKind)
            {
                livent::chrome_icons::drawCloseButton (g, bounds, over, down, isEnabled());
                return;
            }

            const auto r = bounds.reduced (0.5f, 1.0f).withTrimmedBottom (1.0f);
            if (over || down)
            {
                g.setColour (Col::raised.interpolatedWith (Col::text, down ? 0.14f : 0.07f));
                g.fillRoundedRectangle (r, 6.0f);
            }
            const auto c = r.getCentre();
            g.setColour (livent::rack::chromeText (Col::text));
            constexpr float s = 5.0f;
            g.drawLine (c.x - s, c.y, c.x + s, c.y, 1.4f);
        }

    private:
        Kind kind;
    };

    TitleBarButton        minimiseAppButton { TitleBarButton::minimiseKind };
    TitleBarButton        closeAppButton    { TitleBarButton::closeKind };
    bool masterRecordingUiActive = false;
    juce::Image           logoImage;
    juce::Image           compactLogoScaled; // independent HiDPI cache for Gon
    juce::Image           logoScaled;   // logo da thu nho dung co man hinh (net)
    juce::Rectangle<int>  logoArea, dragArea;
    juce::ComponentDragger windowDragger;
    bool                  draggingWindow = false;
    int                   menuBarNaturalWidth() ;

    //  V6.0: thanh trang thai - ten du an + CPU tach rieng ben phai
    juce::Label projectNameLabel, cpuLabel;
    int statusLabelMaxRight = -1;   // 30/09: chua cho mui ten thu num tren thanh trang thai

    /*  MOC 74: nut TACH BANG DO TONE da bi bo han (khong con che do tach
        ra cua so rieng). Bang Do Tone luon dock canh man hinh.  */

    // F3 may dock below the timeline or move to its own resizable window.

    /*  MOC 74: hai nut THU / DUNG da chuyen han vao trong bang Do Tone
        (xem TonePanel::onStartRecord / onStopRecord). O day khong con giu
        nut nao nua - de chi co MOT cho hien hai nut do, khong the lech
        trang thai giua hai cho.  */

    /*  MOC 52: quan ly track cong vao (MONO IN / STEREO IN...). Bang nay gio
        mo tu BEN TRONG "Cai dat am thanh" (xem AudioSettingsPanel trong
        openAudioSettings()) - anchor la nut bam trong bang do (co the la
        nullptr neu goi tu noi khong co nut ro rang, JUCE se tu dat menu gan
        con tro chuot).  */
    void openInputSetup (juce::Component* anchor = nullptr);
    /** 13/10: bang "Bu tre thu am": bu them (ms) + do tre that cua card bang day noi. */
    void openLatencyDialog();
    void afterInputTracksChanged();

    /*  MOC 48: be ngang bang Inspector - KEO DUOC.

        Truoc day dong cung 320 px. Nhung bang nay chua Insert va Send, ma
        ten plugin thi dai ngan tuy con ("UADx Topline Vocal Tune" so voi
        "C1"), nen 320 luc thua luc thieu.  */
    int inspectorWidth = workspace::inspectorWidth;
    int trackControlsWidth = workspace::trackWidth;

    /*  ==========  MOC 74: AN / HIEN BANG INSERT-SEND (Inspector)  =========

        Bang ben trai chua DINH TUYEN / INSERT / SEND / AM LUONG-PAN. Hat
        live xong xuoi roi thi khong dong toi no nua, ma no chiem hon 300 px
        be ngang -- an di la danh sach track rong hen han ra.

        Hai muc luu KHAC NHAU, co y:
          * inspectorVisible  -> luu trong file .NT (tung du an mot)
          * che do khoi dong  -> luu o %APPDATA%\LiveNT\inspector-startup.txt
                                 (dung chung cho moi du an)
        Xem loadInspectorStartupMode() trong MainComponent.cpp.  */
    bool inspectorVisible = true;

    /*  ==========  MOC 75: BANG DIEU KHIEN LA GIAO DIEN CHINH  ==========

        Bang dieu khien (truoc day la bang Do Tone) nam NGANG tren cung va
        LUON hien - no la giao dien chinh. Ba thu con lai deu la phu, an
        hien duoc, va deu duoc luu:

            (MOC 78: thanh menu tren cung da gan cung LUON hien - cong
             tac an/hien no da bi bo theo yeu cau cua anh)
            trackListVisible  cot danh sach track          (F2)
            inspectorVisible  bang Insert / Send           (nam trong F2; F4 moi = soundcard)
            mixerVisible      ban tron                     (F3)

        Cac gia tri khai bao o day chi dung khi file .NT khong co khoi <UI>.
        Luc mo app that su thi "che do khoi dong" quyet dinh - xem
        applyStartupLayoutMode() va loadStartupLayoutMode().  */
    bool trackListVisible = true;

    /** Ap dung 4 co an/hien o tren len giao dien that, roi ve lai. */
    void applyPanelVisibility();

    /** mode: 0 = nho theo du an, 1 = chi bang dieu khien, 2 = hien het. */
    void applyStartupLayoutMode (int mode);

    void setInspectorVisible (bool shouldShow);
    void toggleInspector();
    void toggleTrackList();

    /*  MOC 93: shortcut F4 CU cua Insert/Send da bi bo. V6.6.4 F4 duoc
        tai su dung rieng cho Cai dat soundcard. Bam F2 se HOI MAT KHAU roi moi
        mo BAN LAM VIEC (mot cua so rieng). Xem chu thich day du o dinh nghia
        trong MainComponent.cpp.  */
    void toggleWorkPanels();
    void toggleWorkPanelPasswordRequirement();

    /*  MOC 93: phan viec that su, tach khoi toggleWorkPanels vi hop thoai
        mat khau chay BAT DONG BO - luc no goi lai thi ham kia da ket thuc.  */
    void applyWorkPanels (bool shouldShow);

    /*  ==========  MOC 93: BAN LAM VIEC LA MOT CUA SO RIENG  ==========

        Truoc day danh sach track + bang Insert/Send nam CHUNG cua so voi bang
        dieu khien, nen keo to bang de gan VST la keo to luon bang dieu khien.

        Gio ba thu do (track, Insert/Send, ban tron) chuyen sang mot cua so
        thu hai. Anh keo no to het man hinh de gan VST, cua so bang dieu khien
        van y nguyen - dung y anh mo ta.

        Cach lam: KHONG dung ban sao thu hai cua cac component. Chinh
        trackListViewport / inspectorViewport / mixerView duoc DOI CHA sang
        workArea roi doi ve. juce::Component::addAndMakeVisible tu go khoi cha
        cu truoc khi gan cha moi, nen khong co luc nao mot component co hai
        cha.  */
    struct WorkArea : public juce::Component
    {
        workspace::LookAndFeel look;
        WorkArea() { setLookAndFeel (&look); }
        ~WorkArea() override { setLookAndFeel (nullptr); }
        std::function<void()> onResized;
        void resized() override { if (onResized) onResized(); }
        void paint (juce::Graphics& g) override { g.fillAll (workspace::bg); }
    };

    void openWorkWindow();
    void closeWorkWindow();

    /*  MOC 94: %APPDATA%\\LiveNT\\banlamviec.txt - nho vi tri/kich thuoc cua
        so ban lam viec. De ngoai file .NT vi day la thoi quen dung may, khong
        phai noi dung ban nhac (cung ly do voi khoidong.txt o Moc 74).  */
    juce::File workWindowStateFile() const;
    void layoutWorkArea();

    /*  MOC 93: xep cac dong track ben trong trackListHolder. Tach ra khoi
        resized() vi gio co HAI noi can goi: resized() (khi ban lam viec dang
        dong) va layoutWorkArea() (khi dang mo).  */
    void layoutTrackRows (int listWidth);

    /*  MOC 93: goi lai bo cuc dung cho - dang mo ban lam viec thi xep trong
        cua so do, dang dong thi xep trong cua so chinh. Moi cho truoc day goi
        resized() de cap nhat bo cuc gio goi ham nay.  */
    void relayoutAll();

    //  MOC 77: tu thu nho/khoi phuc kich thuoc cua so khi 2 bang tren an/hien
    void updateWindowSizeForPanels();

    /*  MOC 78: cho bang Insert/Send vao khung cuon va tinh lai chieu cao
        noi dung. Goi moi khi bo cuc doi HOAC khi so o insert/send thay doi.  */
    void layoutInspector (juce::Rectangle<int> area);
    void refitInspector();

    /*  Chan goi long: layoutInspector() lam inspector chay resized(), ma
        resized() lai co the ban onContentHeightChanged goi nguoc ve day.  */
    bool fittingInspector = false;

    /*  MOC 75: bang CAI DAT co tab - gom het moi thu truoc gio nam rai rac
        trong 6 menu tren cung. Mo bang nut CAI DAT tren bang dieu khien,
        hoac menu Hien thi.  */
    void openSettingsDialog();
    //  07/10 (mau C): thanh trang thai = ten bai chu chay + gio | mui ten | CPU ⚙ ▾Gon
    bool statusBarModern() const noexcept { return projectOpen; }
    int  statusBarHeight() const noexcept { return statusBarHeightForWidth (getWidth()); }
    int  statusBarHeightForWidth (int width) const noexcept { return statusBarModern() ? workspace::controlFooterHeight (width) : 20; }
    NowPlayingStrip statusSong;
    juce::Label     statusClock;
    juce::String    lastRoutineStatus;     // dong thong so card binh thuong (an, hien o tooltip CPU)
    bool            statusAlertShown = false;
    bool statusHasAlert() const { return statusLabel.getText().isNotEmpty() && statusLabel.getText() != lastRoutineStatus; }
    juce::String settingsStartPage;   // 06/10: mo Cai dat thang vao trang nay (vd "Gán nút")

    /** MOC 95: chon mau nen chung cho toan bo DAW, luu theo may. */
    void openDawBackgroundMenu();
    void applyRackChrome();       // 12o: cua so / thanh tieu de / chu theo kieu rack
    int  rackChromeApplied = -999;

    /** Thanh chia keo duoc giua cot track va lan hinh song. */
    struct SplitterBar : public juce::Component, public juce::SettableTooltipClient
    {
        std::function<void (int)> onDrag;

        SplitterBar()
        {
            setMouseCursor (juce::MouseCursor::LeftRightResizeCursor);
        }

        void paint (juce::Graphics& g) override
        {
            g.fillAll (Col::panel.brighter (0.15f));

            //  Ba cham doc o giua - dau hieu quen thuoc cua cho keo duoc
            g.setColour (Col::textDim.withAlpha (0.7f));

            for (int i = -1; i <= 1; ++i)
                g.fillEllipse ((float) getWidth() * 0.5f - 1.0f,
                               (float) getHeight() * 0.5f + (float) i * 6.0f - 1.0f,
                               2.0f, 2.0f);
        }

        void mouseDrag (const juce::MouseEvent& e) override
        {
            if (onDrag)
                onDrag (e.getScreenPosition().x);
        }
    };

    SplitterBar trackWidthSplitter;
    SplitterBar inspectorSplitter;  // MOC 48: giua Inspector va cot track

    /*  MOC 49: bat/tat cua so ban tron (F3).

        Cua so RIENG chu khong phai mot the trong cua so chinh, de anh keo
        duoc sang man hinh thu hai - dien thi mot man de ban tron, mot man de
        danh sach bai.  */
    /*  ==========  MOC 55: BAN TRON GAN THANG VAO GIAO DIEN  ==========

        Truoc day F3 mo mot CUA SO RIENG. Nhung mo cua so rieng thi moi lan
        bat len no lai nhay ra giua man hinh, che mat danh sach track - ma hai
        thu do anh nhin cung luc.

        Gio ban tron nam SAT LE DUOI cua so chinh, luon o day. F3 chi an/hien
        no di, khong mo cua so gi ca. Nhin xuong la thay, khong phai di tim.

        Van giu duong tach ra cua so rieng (menu Hien thi) cho ai co hai man
        hinh - nhung do khong con la cach mac dinh.  */
    MixerView mixerView { mixer };

    /* MOC 95: F3 chi song BEN TRONG F2. F2 chua mo thi mixer luon an;
       moi lan mo F2 lai bat dau voi F3 an, bam F3 moi hien. */
    bool mixerVisible   = false;

    /*  MOC 77: nho kich thuoc cua so TRUOC luc tu thu nho (khi Inspector +
        TrackList deu bi an, chi con Bang Dieu Khien) - de khoi phuc dung
        lai kich thuoc do khi anh hien lai. 0 = chua tung thu nho (dang o
        trang thai binh thuong).  */
    int  savedWindowHeightBeforeShrink = 0;   // MOC 78: khong con dung, xem shrinkDelta
    bool isWindowShrunk = false;

    /*  ==========  MOC 78: NHO DELTA, KHONG NHO CHIEU CAO TUYET DOI  =======

        Ban Moc 77 nho lai CHIEU CAO CU cua cua so truoc luc thu nho, roi lay
        nguyen con so do dat lai luc hien hai bang len. Hong o cho: dang o
        trang thai da thu nho, anh keo mep cua so cho no nho them nua - roi
        bam hien track, cua so nhay ve cai chieu cao cu tu doi nao, cao lu
        len. Dung nhu anh ta: "keo nho nhu nao thi khi an giao dien lai no
        khong bi thay doi".

        Gio nho BOT BAO NHIEU PX (delta) chu khong nho cao bao nhieu. Hien
        lai thi cong dung tung ay px vao chieu cao HIEN TAI - moi thao tac
        keo tay cua anh o giua deu duoc giu nguyen.  */
    int  shrinkDelta = 0;
    int  mixerHeight = livent::mixerPanel::defaultHeight;
    int  mixerHeightAtDragStart = livent::mixerPanel::defaultHeight;
    juce::String mixerFloatingWindowState;
    juce::Rectangle<int> mixerDockArea() const;
    void loadMixerLayout();
    void saveMixerLayout();
    void syncMixerPanelVisibility();
    void refreshMixerAfterPluginEdit (Track* changedTrack, int revealedSlot = -1);
    void dockMixerWindow (bool showPanel);


    /** Thanh keo chieu cao ban tron. */
    struct HSplitterBar : public juce::Component, public juce::SettableTooltipClient
    {
        static constexpr int height = livent::mixerPanel::splitterHeight;
        std::function<void()> onDragStarted, onDragFinished;
        std::function<void (int)> onDrag;

        HSplitterBar()
        {
            setMouseCursor (juce::MouseCursor::UpDownResizeCursor);
            setTooltip (livent::vn ("Kéo lên/xuống để đổi chiều cao mixer F3"));
        }
        void paint (juce::Graphics& g) override
        {
            g.fillAll (isMouseOverOrDragging() ? Col::panel.brighter (0.25f) : Col::panel2);
            g.setColour (isMouseOverOrDragging() ? Col::accent : Col::textDim);
            const float x = getWidth() * 0.5f - 24.0f;
            g.fillRoundedRectangle (x, getHeight() * 0.5f - 2.0f, 48.0f, 4.0f, 2.0f);
        }
        void mouseEnter (const juce::MouseEvent&) override { repaint(); }
        void mouseExit  (const juce::MouseEvent&) override { repaint(); }
        void mouseDown (const juce::MouseEvent&) override
        { if (onDragStarted) onDragStarted(); }
        void mouseDrag (const juce::MouseEvent& e) override
        {
            // Convert the whole drag to the parent's logical coordinates, including UI scale.
            if (onDrag) onDrag (e.getEventRelativeTo (getParentComponent()).getDistanceFromDragStartY());
        }
        void mouseUp (const juce::MouseEvent&) override
        { if (onDragFinished) onDragFinished(); repaint(); }
    };

    HSplitterBar mixerSplitter;

    void toggleMixerPanel();

    /** MOC 46: nhan doi track, giu nguyen moi VST va cai dat. */
    void duplicateTrack (Track* source);

    /*  Cac muc menu. Danh so theo NHOM cho de doc va de them muc moi ma khong
        dam so vao nhau:  1xx = Tep, 2xx = Du an, 3xx = Studio, 4xx = Hien thi,
        9xx = danh sach file mo gan day.  */
    enum MenuIds
    {
        menuFile = 0, menuStudio, menuView, menuContact, menuHelp
    };

    //=========================================================================
    //  MOC 24: ba ham bat buoc cua MenuBarModel -- thanh menu hoi gi tra loi nay
    //=========================================================================
    /*  MOC 46: PHIM TAT.

        Dung KeyListener gan vao cua so chinh chu khong dung
        addKeyListener cua tung thanh phan: nhu vay phim cach an o BAT KY dau
        trong cua so, khong phai bam chuot vao dung cho truoc.

        Ngoai tru khi con tro dang o trong mot O NHAP CHU (vd o dan link) --
        luc do phim cach phai la dau cach that.  */
    bool keyPressed (const juce::KeyPress& key, juce::Component* origin) override;

    juce::StringArray getMenuBarNames() override;
    juce::PopupMenu   getMenuForIndex (int index, const juce::String& name) override;
    void              menuItemSelected (int menuItemID, int topLevelMenuIndex) override;

    /*  File .NT dang mo. Rong = du an chua bao gio duoc luu ra file. */
    juce::File currentProjectFile;
    bool currentProjectPortable=false;
    /* Moc so sanh KHONG chua binary state cua VST. State plugin co the tu
       thay doi byte noi bo du nguoi dung khong sua gi; dung no de quyet
       dinh dirty la nguyen nhan Save xong van bi hoi Save lai. */
    juce::String lastSavedStateXml;
    bool projectOpen = false;
    bool recordingRecoveryDialogOpen = false;
    bool routingCycleNotified = false;
    bool projectDirty = false;
    bool autoOpenMusicVst2 = false; // tuy chon rieng tung project .NT
    bool autosaveDirty = false;   // V5.8.7: autosave chi chup state khi co thay doi moi
    bool closeProjectAfterSaveAs = false;
    bool quitAfterSaveAs = false;
    juce::File pendingProjectToOpenAfterSaveAs;

    juce::RecentlyOpenedFilesList recentFiles;

    std::unique_ptr<juce::FileChooser> fileChooser;

    int autosaveTick = 0;      // dem giay de 60 giay tu luu mot lan
    bool autosaveEnabled = true;   // MOC 66: cong tac tat/bat rieng, xem menu Studio
    bool harmonyButtonVisible = true;  // V6: mac dinh hien, nam canh LOFI trong luoi 9 cot

    InspectorPanel inspector { mixer };

    /*  ==========  MOC 78: KHUNG CUON CHO BANG INSERT/SEND  ==========

        Anh bao: cot danh sach track thu nho lai thi co thanh keo len xuong,
        con bang Insert/Send thi khong - gan nhieu VST vao la may cai phia
        sau khong thay duoc nua.

        Dung y het cach cot track dang lam: bang that (inspector) nam TRONG
        mot Viewport, va duoc cho chieu cao dung bang noi dung can (xem
        InspectorPanel::getContentHeight). Viewport tu lo phan thanh keo.

        Khai bao SAU inspector de no bi huy TRUOC - Viewport giu con tro toi
        inspector, khong duoc de inspector chet truoc.  */
    juce::Viewport inspectorViewport;

    /*  MOC 21: khoang trong duoi track cuoi cung bam chuot phai duoc, giong
        Cubase - hien menu them track. juce::Component thuong khong bao onClick
        cho chuot phai nen phai bao mot lop nho o day.  */
    struct TrackListArea : public juce::Component,
                           private juce::Timer
    {
        std::function<void (const juce::MouseEvent&)> onRightClick;
        Mixer* timelineMixer = nullptr;

        void attachTimeline (Mixer& m)
        {
            timelineMixer = &m;
            startTimerHz (30);
        }

        void paint (juce::Graphics& g) override
        {
            g.fillAll (workspace::bg);
            if (timelineMixer == nullptr)
                return;

            const int timelineX = TrackRow::getTimelineStartX (getWidth());
            if (timelineX >= getWidth())
                return;

            auto area = juce::Rectangle<float> ((float) timelineX, 0.0f,
                                                (float) (getWidth() - timelineX),
                                                (float) getHeight());

            // V6.3.4: mot mat timeline DUY NHAT, ke ca qua header folder va
            // khoang trong duoi track cuoi. Khong con cac "o" roi rac.
            g.setColour (workspace::timeline);
            g.fillRect (area);

            const double pps = juce::jmax (1.0, timelineMixer->getTimelinePixelsPerSecond());
            const double viewStart = juce::jmax (0.0, timelineMixer->getTimelineViewStartSeconds());

            double step = 10.0;
            if      (pps >= 160.0) step = 0.5;
            else if (pps >=  80.0) step = 1.0;
            else if (pps >=  38.0) step = 2.0;
            else if (pps >=  20.0) step = 5.0;

            const double first = std::floor (viewStart / step) * step;
            const double end = viewStart + area.getWidth() / pps;

            for (double t = first; t <= end + step; t += step)
            {
                const float x = area.getX() + (float) ((t - viewStart) * pps);
                if (x < area.getX() - 1.0f || x > area.getRight() + 1.0f)
                    continue;

                const bool major = std::fmod (std::abs (t), step * 5.0) < 0.0001;
                g.setColour (workspace::line.withAlpha (major ? 0.85f : 0.45f));   // 08/10: luoi theo bang mau F2
                g.drawVerticalLine ((int) std::round (x), area.getY(), area.getBottom());
            }

            // 07/10: vung khoa P + vung boi den keo dai qua ca folder / khoang trong
            auto band = [&] (double a, double b, juce::Colour c, float alpha)
            {
                const float xa = area.getX() + (float) ((a - viewStart) * pps);
                const float xb = area.getX() + (float) ((b - viewStart) * pps);
                g.setColour (c.withAlpha (alpha));
                g.fillRect (juce::Rectangle<float> (xa, area.getY(), xb - xa, area.getHeight()).getIntersection (area));
                g.setColour (c.withAlpha (0.7f));
                for (const float x : { xa, xb })
                    if (x >= area.getX() && x <= area.getRight())
                        g.fillRect (x - 0.5f, area.getY(), 1.0f, area.getHeight());
            };
            if (timelineMixer->hasTimelineLocators())
                band (timelineMixer->getTimelineLocatorStart(), timelineMixer->getTimelineLocatorEnd(),
                      juce::Colour (0xfffbbf24), 0.06f);
            if (timelineMixer->getTimelineUi().hasRange())
                band (timelineMixer->getTimelineUi().rangeStart, timelineMixer->getTimelineUi().rangeEnd,
                      juce::Colour (0xff7dd3fc), 0.12f);

            // Playhead ve mot vach xuyen suot toan bo ban lam viec.
            const float px = area.getX() + (float) ((timelineMixer->getTimelinePositionSeconds()
                                                     - viewStart) * pps);
            if (px >= area.getX() && px <= area.getRight())
            {
                // 07/10 _E: dau phat DO 2 px (nhu demo)
                g.setColour (juce::Colour (0xffff3b3b));
                g.fillRect (juce::Rectangle<float> (px - 1.0f, area.getY(),
                                                    2.0f, area.getHeight()));
            }
        }

        void mouseDown (const juce::MouseEvent& e) override
        {
            if (e.mods.isPopupMenu() && onRightClick)
                onRightClick (e);
        }

    private:
        void timerCallback() override
        {
            // Luoi rat re; 30 Hz chi cap nhat playhead. Clip van repaint rieng
            // trong TrackWaveformView nen khong doc WAV o day.
            repaint();
        }
    };

    TrackListArea   trackListHolder;
    juce::Viewport  trackListViewport;
    juce::OwnedArray<TrackRow> trackRows;

    // V6.2: transport dung chung cho timeline track NHAC/MIC. Khai bao truoc
    // workArea de khi huy, cua so/parent duoc huy truoc component nay.
    TimelineTransportBar timelineTransport { mixer };
    // 07/10 _F (demo A): thuoc thoi gian tren danh sach track + thanh duoi
    // (cuon ngang, goi y phim, vung P, theo dau phat).
    TimelineRuler     timelineRuler  { mixer };
    TimelineFooterBar timelineFooter { mixer };
    TimelineTransportIcons timelineTransportIcons { mixer };
    livent::ModeSwitch& modeSwitch { timelineTransportIcons.modeSwitch };   // 15/10: LIVE | THU nam canh Dung/Phat/Thu
    MasterMeterPanel masterMeterPanel { mixer };
    bool masterMeterVisible = true;

    /*  Cac dong tieu de thu muc trong danh sach track ("BUS HIEU UNG",
        "VAO / RA"). Hai co duoi giu trang thai thu gon qua cac
        lan dung lai danh sach - khong thi them mot track la no bung ra het. */
    juce::OwnedArray<SectionHeader> trackFolders;
    bool fxFolderOpen  = true;
    bool outFolderOpen = true;

    /*  Bang do tone, nam duoi cung danh sach track - ngay sau track AM THANH RA. */
    TonePanel tonePanel { mixer };

    /*  Doc tu file du an, nhung chi ap dung duoc SAU khi danh sach track dung
        xong (luc do o chon track moi co ten de chon). -1 = khong co gi cho. */
    int  pendingToneTrackId   = -1;
    /*  Mac dinh BAT. Du an cu (luu tu truoc Moc 16) khong co khoi <UI> trong
        file, nen doan doc o duoi khong chay -- va gia tri o day chinh la thu
        duoc dung. De false thi mo du an cu la nut tu bat link bi TAT oan,
        dung nhu anh gap.  */
    bool pendingToneAutoWatch = true;
    bool pendingMixerDetached = false;   // MOC 65

    /*  MOC 74: toneWindow / toggleToneWindow() / updateTonePanelParent() da
        bi bo han. Bang Do Tone luon la con TRUC TIEP cua MainComponent va
        luon dock canh man hinh, nen khong con phai doi cha hay dua sang
        cua so khac nua.  */

    /*  MOC 56: cua so rieng cho BAN TRON, cung kieu voi toneWindow o tren.
        Khai bao SAU mixerView de no bi huy TRUOC khi mixerView chet.  */
    std::unique_ptr<juce::DocumentWindow> mixerWindow;

    /*  ==========  MOC 93: BAN LAM VIEC  ==========

        THU TU KHAI BAO QUAN TRONG (bai hoc Moc 89 voi laughBoard):
        workArea PHAI dung TRUOC workWindow. Thanh vien bi huy theo thu tu
        NGUOC voi thu tu khai bao, nen workWindow chet TRUOC workArea - dung
        chieu can thiet, vi cua so dang giu con tro toi workArea.

        Va cua so dung setContentNonOwned: workArea la thanh vien cua lop nay,
        de cua so tu xoa no la xoa nham bo nho cua lop khac.  */
    WorkArea                              workArea;
    std::unique_ptr<juce::DocumentWindow> workWindow;

    /*  MOC 96: mat khau mo Ban lam viec F2.

        Mac dinh 2808. Sau khi nguoi dung doi, gia tri duoc luu rieng trong
        %APPDATA%\LiveNT\f2-password.txt cua tai khoan Windows hien tai, nen
        khong can sua source/build lai. Day van la "chot cua" de tranh bam
        nham, khong phai co che bao mat cap phep/ban quyen. */
    juce::String workPanelPassword { "2808" };
    bool workPanelPasswordRequired = false;
    int soundcardLockMismatchTicks = 0;
    bool workPanelPasswordPromptRunning = false;

    void toggleMixerWindow();

    //  MOC 96: Hub du an. Khi projectOpen == false, chi Hub + menu hien;
    //  bang dieu khien va toan bo khu VST duoc giau cho toi khi tao/mo .NT.
    juce::TextButton hubNewProjectButton { livent::vn ("+  Tạo dự án mới") };
    juce::TextButton hubOpenProjectButton { livent::vn ("Mở dự án .NT...") };
    juce::OwnedArray<juce::TextButton> hubRecentButtons;
    juce::Array<juce::File> hubRecentFiles;

    //  06/10: man Tao / Mo du an moi (ProjectHub.h) thay cho 2 nut + danh sach.
    ProjectHub projectHub;
    void createProjectFromHub (ProjectHub::Template kind, const juce::String& name, const juce::File& folder);
    static juce::File getMachineTemplateFile();
    void saveProjectAsMachineTemplate();

    //  MOC 72: thu am don gian
    void startMasterRecording();
    /** 14/10: Che do Live - tat het tinh nang thu am tren timeline (xem Mixer::setLiveMode). Goi tu Cai dat > Am thanh. */
    void setLiveMode (bool on);
    void stopMasterRecording();

    // V6.6.5: XUAT nam canh THU/DUNG/PHAT tren timeline. WAV truc tiep; MP3 dung FFmpeg.
    //  V0.6.7.7: hop thoai xuat kieu Cubase (ExportDialog.h) thay cho menu 2 dong.
    void showExportMenu (juce::Component* anchor = nullptr);
    void chooseTimelineExport (bool mp3);

    // 07/10: nhap file vao timeline + khoi phuc ban thu bi gian doan
    void importAudioToTimeline (Track* target, double atSeconds);
    juce::File timelineAudioFolder() const;
    void checkInterruptedTakes();
    std::unique_ptr<VideoController> videoController;   // 07/10 _D: video MP4 theo dau phat
    std::unique_ptr<juce::FileChooser> importChooser;
    std::atomic<int> importJobs { 0 };
    void startExportWithSettings (const livent::exporting::Settings& s);
    void beginTimelineExport (const juce::File& destination, const livent::exporting::Settings& s);
    void beginOfflineTimelineExport (const juce::File& destination, const livent::exporting::Settings& settings);
    void pollTimelineExport();
    void finishTimelineExport();
    void pollExportFinishing();
    void abortTimelineExport();
    void endTimelineExportUi();
    juce::File findFfmpegExecutable() const;

    std::unique_ptr<juce::FileChooser> exportFileChooser;
    bool timelineExportActive = false;
    bool timelineExportOffline = false;
    std::thread timelineExportWorker;
    std::shared_ptr<std::atomic<double>> timelineRenderProgress;
    std::shared_ptr<std::atomic<bool>> timelineRenderDone;
    std::shared_ptr<juce::String> timelineRenderError;
    bool timelineExportFinishing = false;
    double timelineExportLengthSeconds = 0.0;
    double timelineExportTotalSeconds = 0.0;
    double timelineExportPrerollSeconds = 0.0;
    double timelineExportLastRecorded = 0.0;
    int    timelineExportStallTicks = 0;
    juce::File timelineExportTempWav;
    juce::File timelineExportDestination;
    livent::exporting::Settings timelineExportSettings;
    std::shared_ptr<std::atomic<bool>>   timelineExportCancel;
    std::shared_ptr<livent::exporting::CommitGate> timelineExportCommitGate;
    std::shared_ptr<std::atomic<double>> timelineExportFinishProgress;
    std::shared_ptr<juce::String>        timelineExportFinishError;
    std::shared_ptr<std::atomic<bool>>   timelineExportFinishDone;
    juce::Component::SafePointer<juce::DialogWindow> exportDialogWindow;
    juce::Component::SafePointer<juce::DialogWindow> exportProgressWindow;
    juce::Component::SafePointer<livent::exporting::ProgressComponent> exportProgressUi;

    juce::Label  statusLabel;
    // V5.8.7: cache nền galaxy, tránh vẽ lại gradient/sao mỗi lần meter repaint.
    juce::Image backgroundCache;
    float backgroundCacheScale = 0.0f;
    juce::Colour backgroundCacheColour;
    bool backgroundCacheGalaxy = false;

    // HOTFIX11: card san khau XR18/X32/Ui24... co the co hon 16 duong vao.
    // Cap san 64 kenh chi ton ~128 KB o block 512, khong lam tang vong copy:
    // callback van chi chep dung so kenh DANG BAT cua driver.
    static constexpr int maxHardwareInputs = 64;
    juce::AudioBuffer<float> inputCopy;
    livent::LoopbackMeter loopbackMeter;     // 13/10: do tre that cua card (audio thread: chi khi dang do)
    double recordExtraMs = 0.0;              // 13/10: "bu them" (ms) cua may nay

    /*  So duong vao THAT SU dang bat cua card. Phai nho rieng: inputCopy luon
        co maxHardwareInputs kenh, neu lay getNumChannels() cua no lam gioi han
        thi track co the doc phai kenh rac (xem getNextAudioBlock). */
    int activeInputChannels = 0;

    // HOTFIX11 - watchdog soundcard. Timer MainComponent chay 1 Hz nen khong
    // chen bat ky viec kiem tra nao vao audio callback.
    bool audioInitialisedOnce = false;
    bool audioWatchdogFault = false;
    int  audioWatchdogBadTicks = 0;
    int  audioWatchdogRetryCooldown = 0;
    int  audioWatchdogRecoveredTicks = 0;

    // 0.6.7.5 - phan biet "CHUA TUNG mo duoc soundcard" (may khach, driver treo /
    // khong co thiet bi) voi "dang chay roi bi rot" (rut USB giua buoi).
    // Truoc day hai truong hop bi bao chung la "MAT SOUNDCARD" va app thu lai
    // vo han tren luong giao dien -> cua so "Not Responding".
    bool audioEverHealthy = false;
    bool audioSafeModeAtStartup = false;
    bool audioGiveUpAlertShown = false;
    int  audioWatchdogStartupGraceTicks = 0;
    int  audioWatchdogAttempts = 0;

    static juce::File getAudioOpeningFlagFile();
    void handleAudioPermissionResult (bool granted);
    juce::uint32 openAudioDeviceGuarded (const juce::XmlElement* saved, int numInputs,
                                         const juce::String& why);
    void logAudioDeviceSnapshot (const juce::String& stage, juce::uint32 elapsedMs);

    /*  V4.5: fade-in dau ra sau khi audio device duoc prepare lai.
        Hai bien nay chi duoc dung tren audio callback/prepare path, khong cap
        phat va khong khoa. */
    int outputFadeSamplesRemaining = 0;
    int outputFadeTotalSamples     = 0;

    // Optional 10-second capture: only atomic counters and clock reads on the
    // audio callback, never file I/O or an alert on the realtime thread.
    std::atomic<bool> audioDiagnosticsActive { false };
    std::atomic<int> diagnosticCallbackCount { 0 };
    std::atomic<int> diagnosticOverBudgetCount { 0 };
    std::atomic<int> diagnosticPeakPermille { 0 };
    double diagnosticTicksPerSample = 0.0; // audio thread only; set in prepare

    /*  Quet plugin luc khoi dong. Dat CUOI danh sach thanh vien de no bi huy
        TRUOC cac thu khac - destructor cua no doi luong quet dung han.  */
    std::unique_ptr<StartupScanner> startupScanner;
    bool startupScanReported = false;
    double startupScanProgressValue = -1.0;
    juce::ProgressBar startupScanProgressBar { startupScanProgressValue };

    /*  Ten plugin dang nap. Rong = khong nap gi. Hien o thanh trang thai de
        nguoi dung biet app dang ban chu khong phai treo. */
    juce::String loadingPluginName;
    bool pluginLoadInProgress = false;
    int  pluginLoadTrackId = -1;
    int  pluginLoadSlot = -1;

    struct ProjectPluginLoadJob
    {
        int trackId = -1;
        juce::String name;
        std::unique_ptr<juce::XmlElement> pluginXml;
    };

    std::vector<ProjectPluginLoadJob> projectPluginLoadJobs;
    juce::StringArray projectPluginLoadFailures;
    int projectPluginLoadIndex = 0;
    int projectPluginLoadDone = 0;
    bool projectLoadInProgress = false;
    bool projectPluginWorkerActive = false;
    bool projectLoadCancelRequested = false;
    bool projectLoadFromRecovery = false;
    juce::uint64 projectLoadGeneration = 0;
    juce::File pendingProjectAfterLoadCancel;
    juce::TextButton cancelProjectLoadButton { livent::vn ("Hủy nạp") };

    void warnAboutMissingPlugins();

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (MainComponent)
};
