#include "BuiltinDenoise.h"
#include <juce_dsp/juce_dsp.h>
#include "BuiltinVoiceTracker.h"
#include <algorithm>
#include <array>
#include <cstdint>
#include <cmath>
#include <vector>

//  12s: phan tinh cua Giam on co san (lay tu T-DeNoise, che do Live). Xem BuiltinDenoise.h.
namespace livent::builtinfx
{
    struct NoiseReducer::Impl
    {
        explicit Impl (std::atomic<float>& m) : meterGR (m) {}


        static int fftOrderFor (double sr)
        {
            int order = 9;                       // 512 (~11 ms) o 44.1-48 kHz
            if (sr > 60000.0) ++order;           // giu cung khoang thoi gian o 88.2/96 kHz
            if (sr > 130000.0) ++order;
            return order;
        }

        void prepare (double sr)
        {
            fs = sr > 0.0 ? sr : 48000.0;
            order = fftOrderFor (fs);
            const int N = 1 << order;
            fft = std::make_unique<juce::dsp::FFT> (order);
            for (auto* v : { &win, &noiseTrack, &noiseEst, &psSmooth, &gPrev, &pPrev, &gSmooth, &gainTmp, &pNow, &subMin, &winMin })
                v->assign ((size_t) N, 0.0f);
            for (auto& h : minHist) h.assign ((size_t) N, 0.0f);
            harmMask.assign ((size_t) N, 0);
            for (int c = 0; c < 2; ++c)
            {
                inRing[c].assign ((size_t) N, 0.0f);
                outAcc[c].assign ((size_t) N * 2, 0.0f);
                spec[c].assign ((size_t) N * 2, 0.0f);
            }
            tracker.prepare (fs);
            mixStep = (float) (1.0 / juce::jmax (1.0, fs * 0.030));
            mix = 0.0f;
            needsReset = true;
            prepared = true;
        }

        void process (juce::AudioBuffer<float>& b, int n, float a) noexcept
        {
            if (! prepared || n <= 0) return;
            const float target = a > 0.0f ? 1.0f : 0.0f;
            if (target == 0.0f && mix <= 0.0f)
            {
                needsReset = true;               // ngu: khong tinh
                meterGR.store (0.0f);
                return;
            }
            if (needsReset) { configure(); needsReset = false; }

            const int numCh = juce::jmin (2, b.getNumChannels());
            if (numCh <= 0) return;
            reductionDb = 0.3f * a;
            const int N = 1 << order;
            for (int i = 0; i < n; ++i)
            {
                float mono = 0.0f;
                for (int c = 0; c < numCh; ++c)
                {
                    float x = b.getSample (c, i);
                    if (! std::isfinite (x)) x = 0.0f;
                    inRing[c][(size_t) ringPos] = x;
                    mono += x;
                }
                tracker.push (mono / (float) numCh);
                // Retain the existing transition history; at the settled endpoint
                // output only wet samples, without oscillation or residual dry leakage.
                if (target > mix) mix = juce::jmin (target, mix + mixStep);
                else if (target < mix) mix = juce::jmax (target, mix - mixStep);
                const size_t alignedDryIdx = (size_t) ((ringPos + hop) % N);
                for (int c = 0; c < numCh; ++c)
                {
                    const float alignedDry = inRing[c][alignedDryIdx];
                    const float wet = outAcc[c][(size_t) sinceHop];
                    b.setSample (c, i, mix >= 1.0f ? wet : alignedDry + (wet - alignedDry) * mix);
                }
                ringPos = (ringPos + 1) % N;
                if (++sinceHop == hop)
                {
                    sinceHop = 0;
                    analyseFrame (numCh);
                }
            }
        }


        void configure() noexcept
        {
            const int N = 1 << order; hop = N / 4;
            for (int i = 0; i < N; ++i)
                win[(size_t) i] = (float) std::sqrt (0.5 - 0.5 * std::cos (juce::MathConstants<double>::twoPi * i / N));   // sqrt-Hann
            for (int c = 0; c < 2; ++c)
            {
                std::fill (inRing[c].begin(), inRing[c].end(), 0.0f);
                std::fill (outAcc[c].begin(), outAcc[c].end(), 0.0f);
            }
            std::fill (gPrev.begin(), gPrev.end(), 1.0f); std::fill (gSmooth.begin(), gSmooth.end(), 1.0f);
            std::fill (pPrev.begin(), pPrev.end(), 0.0f); std::fill (psSmooth.begin(), psSmooth.end(), 0.0f);
            std::fill (noiseTrack.begin(), noiseTrack.end(), 0.0f); std::fill (noiseEst.begin(), noiseEst.end(), 0.0f);
            ringPos = 0; sinceHop = 0; framesSeen = 0;
            std::fill (subMin.begin(), subMin.end(), 3.0e38f); std::fill (winMin.begin(), winMin.end(), 3.0e38f);
            subCount = minSlot = minFilled = 0; activity = 0.0f; holdLeft = 0.0f; tracker.reset();
            meterGR.store (0.0f);
        }

        // == T-DeNoise analyseFrame: Live, Adaptive bat, Sensitivity 0 dB, Smoothing 50 %, khong Learn / Listen ==
        void analyseFrame (int numCh) noexcept
        {
            const int N = 1 << order, bins = N / 2 + 1;
            const float binHz = (float) (fs / N), frameSec = (float) (hop / fs);
            for (int c = 0; c < numCh; ++c)
            {
                auto& acc = outAcc[c];
                std::copy (acc.begin() + hop, acc.begin() + N, acc.begin());
                std::fill (acc.begin() + (N - hop), acc.begin() + N, 0.0f);
                auto& sp = spec[c];
                for (int i = 0; i < N; ++i) sp[(size_t) i] = inRing[c][(size_t) ((ringPos + i) % N)] * win[(size_t) i];
                std::fill (sp.begin() + N, sp.begin() + 2 * N, 0.0f);
                fft->performRealOnlyForwardTransform (sp.data(), true);
            }
            const float gMin = juce::Decibels::decibelsToGain (-reductionDb);
            const float gVoice = juce::Decibels::decibelsToGain (-std::min (5.0f, 0.35f * reductionDb));
            const float smooth = 0.5f;
            const float alpha = 0.95f + 0.035f * smooth;
            const float holdSec = 0.03f + 0.17f * smooth;
            const float actRelease = std::exp (-frameSec / (0.03f + 0.12f * smooth));
            ++framesSeen;

            // 1. pho cong suat
            for (int k = 0; k < bins; ++k)
            {
                float P = 0;
                for (int c = 0; c < numCh; ++c) { const float re = spec[c][(size_t) 2 * k], im = spec[c][(size_t) 2 * k + 1]; P += re * re + im * im; }
                P /= (float) std::max (1, numCh);
                pNow[(size_t) k] = P;
                float& ps = psSmooth[(size_t) k]; ps = framesSeen == 1 ? P : 0.6f * ps + 0.4f * P;
                float& pl = noiseTrack[(size_t) k]; pl = framesSeen <= N / hop + 1 ? P : 0.95f * pl + 0.05f * P;
            }

            // 2. cuc tieu truot ~1.5 s
            const int subFrames = std::max (1, (int) std::round (0.25 / frameSec));
            const bool minReady = framesSeen > N / hop + 30;
            if (minReady) for (int k = 0; k < bins; ++k) subMin[(size_t) k] = std::min (subMin[(size_t) k], noiseTrack[(size_t) k]);
            if (minReady && ++subCount >= subFrames)
            {
                subCount = 0;
                float* slot = minHist[(size_t) minSlot].data();
                std::copy (subMin.begin(), subMin.begin() + bins, slot);
                std::fill (subMin.begin(), subMin.end(), 3.0e38f);
                minSlot = (minSlot + 1) % (int) minHist.size(); minFilled = std::min (minFilled + 1, (int) minHist.size());
                for (int k = 0; k < bins; ++k)
                {
                    float m = 3.0e38f;
                    for (int h = 0; h < minFilled; ++h) m = std::min (m, minHist[(size_t) h][(size_t) k]);
                    winMin[(size_t) k] = m;
                }
            }

            // 3. dang hat?
            const auto voice = tracker.state();
            bool voiced = false, active = false;
            const int warm = N / hop + 1;
            if (framesSeen > warm + 8)
            {
                const float edges[4] { 150.0f, 1000.0f, 4000.0f, 9000.0f };
                for (int bd = 0; bd < 3; ++bd)
                {
                    double sp = 0, sn = 0;
                    for (int k = std::max (1, (int) (edges[bd] / binHz)); k < std::min (bins, (int) (edges[bd + 1] / binHz)); ++k)
                    { sp += pNow[(size_t) k]; sn += noiseEst[(size_t) k]; }
                    if (sn <= 1.0e-20) continue;
                    // Match T-DeNoise Live: periodic hum is not voice by pitch alone.
                    if (sp > 4.0 * sn) active = true;
                    if (bd == 0 && sp > 1.6 * sn && voice.voiced && voice.hz > 75.0f) voiced = active = true;
                }
            }
            if (active) { activity = 1.0f; holdLeft = holdSec; }
            else if ((holdLeft -= frameSec) <= 0.0f) activity *= actRelease;

            // 4. theo doi tieng on: chi giua cac cau hat
            const bool quiet = ! active && holdLeft <= 0.0f;
            std::fill (harmMask.begin(), harmMask.begin() + bins, (uint8_t) 0);
            if (voice.voiced && voice.hz > 60.0f)
                for (int h = 1; h * voice.hz < (float) fs * 0.45f; ++h)
                {
                    const float fc = h * voice.hz, half = 1.5f + 0.02f * fc / binHz;
                    for (int k = std::max (0, (int) (fc / binHz - half)); k <= std::min (bins - 1, (int) (fc / binHz + half) + 1); ++k) harmMask[(size_t) k] = 1;
                }
            for (int k = 0; k < bins; ++k)
            {
                float& ne = noiseEst[(size_t) k];
                const float ps = psSmooth[(size_t) k];
                const float pl = noiseTrack[(size_t) k];
                if (framesSeen <= warm) ne = 0.0f;
                else if (framesSeen <= warm + 8) ne = framesSeen == warm + 1 ? ps : ne + 0.25f * (ps - ne);
                else if (quiet) ne += 0.03f * (ps - ne);
                else if (pl < 0.4f * ne) ne += 0.02f * (pl - ne);
                else if (minFilled >= 2 && ne < winMin[(size_t) k] && harmMask[(size_t) k] == 0)
                    ne += 0.01f * (1.5f * winMin[(size_t) k] - ne);
                if (minFilled >= 2) ne = std::min (ne, 4.0f * winMin[(size_t) k]);
            }

            // 5. he so giam
            const float f0 = voiced ? voice.hz : 0.0f;
            for (int k = 0; k < bins; ++k)
            {
                const float P = pNow[(size_t) k], noise = noiseEst[(size_t) k];
                float gw = 1.0f;
                if (noise > 1.0e-20f)
                {
                    const float gamma = P / noise;
                    const float xi = alpha * gPrev[(size_t) k] * gPrev[(size_t) k] * pPrev[(size_t) k] / noise + (1 - alpha) * std::max (gamma - 1.0f, 0.0f);
                    gw = xi / (1.0f + xi);
                }
                gPrev[(size_t) k] = gw; pPrev[(size_t) k] = P;
                gainTmp[(size_t) k] = std::max (gw, gVoice);
            }
            if (f0 > 60.0f)
                for (int h = 1; h * f0 < 9000.0f; ++h)
                {
                    const float fc = h * f0, half = 1.0f + 0.015f * fc / binHz;
                    const int k0 = std::max (0, (int) std::floor (fc / binHz - half)), k1 = std::min (bins - 1, (int) std::ceil (fc / binHz + half));
                    for (int k = k0; k <= k1; ++k) gainTmp[(size_t) k] = std::max (gainTmp[(size_t) k], 0.92f);
                }
            for (int k = 0; k < bins; ++k)
            {
                const int w = std::max (1, (int) (k * 0.04f));
                float sum = 0; int cnt = 0;
                for (int j = std::max (0, k - w); j <= std::min (bins - 1, k + w); ++j) { sum += gainTmp[(size_t) j]; ++cnt; }
                const float G = activity * (sum / (float) cnt) + (1.0f - activity) * gMin;
                float& gs = gSmooth[(size_t) k];
                gs = G > gs ? G : 0.55f * gs + 0.45f * G;
            }

            double pin = 0, pout = 0;
            for (int c = 0; c < numCh; ++c)
            {
                auto& sp = spec[c];
                for (int k = 0; k < bins; ++k)
                {
                    const float G = gSmooth[(size_t) k];
                    if (c == 0) { const double e = (double) sp[(size_t) 2 * k] * sp[(size_t) 2 * k] + (double) sp[(size_t) 2 * k + 1] * sp[(size_t) 2 * k + 1]; pin += e; pout += e * G * G; }
                    sp[(size_t) 2 * k] *= G; sp[(size_t) 2 * k + 1] *= G;
                }
                fft->performRealOnlyInverseTransform (sp.data());
                auto& acc = outAcc[c];
                for (int i = 0; i < N; ++i) acc[(size_t) i] += sp[(size_t) i] * win[(size_t) i] * 0.5f;   // Hann OLA 75 % = 2
            }
            const float gr = (pin > 1.0e-12 && pout > 1.0e-14) ? (float) juce::jlimit (0.0, 60.0, 10.0 * std::log10 (pin / pout)) : 0.0f;
            meterGR.store (0.8f * meterGR.load() + 0.2f * gr);
        }

        std::atomic<float>& meterGR;
        double fs = 48000.0;
        int order = 9, hop = 128, ringPos = 0, sinceHop = 0;
        long framesSeen = 0;
        bool prepared = false, needsReset = true;
        float reductionDb = 0.0f, mix = 0.0f, mixStep = 0.001f;
        std::unique_ptr<juce::dsp::FFT> fft;
        std::vector<float> win, noiseTrack, noiseEst, psSmooth, gPrev, pPrev, gSmooth, gainTmp, pNow, subMin, winMin;
        std::array<std::vector<float>, 6> minHist;
        int subCount = 0, minSlot = 0, minFilled = 0;
        float activity = 0.0f, holdLeft = 0.0f;
        std::vector<uint8_t> harmMask;
        tvoice::PitchTracker tracker;
        std::vector<float> inRing[2], outAcc[2], spec[2];
    };

    NoiseReducer::NoiseReducer() : impl (std::make_unique<Impl> (meterGR)) {}
    NoiseReducer::~NoiseReducer() = default;

    void NoiseReducer::prepare (double sampleRate) { impl->prepare (sampleRate); }

    void NoiseReducer::process (juce::AudioBuffer<float>& buffer, int numSamples) noexcept
    {
        impl->process (buffer, numSamples, amount.load());
    }
}
