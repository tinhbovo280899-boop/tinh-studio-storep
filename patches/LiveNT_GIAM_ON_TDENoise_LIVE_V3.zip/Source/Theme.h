#pragma once
#include "StudioControls.h"

#include <JuceHeader.h>
#include "WindowPlacement.h"
#include "AppBranding.h"   // 01/10: appDisplayName
#include <map>
#include "CubaseLook.h"
#include "ToolbarIcons.h"   // 15/10: anh nut YouTube / Cuoi / Cai dat
#include "RackSkin.h"       // 16/10: giao dien mau 3 (rack studio)

/*  ==========  V6.0: GIAO DIEN PHANG + 24 CHU DE + FONT NHUNG  ==========

    File nay thay the toan bo Theme.h cu. Giu nguyen moi TEN ma code khac dang
    dung (livent::vn, Col::bg, Col::accent, Col::snapshot, LiveNTLookAndFeel,
    GlassLookAndFeel...) nen cac file khac KHONG phai sua de bien dich duoc.

    Thay doi chinh:
      1. 24 chu de, moi chu de chi la 8 mau theo VAI TRO (nen, khoi, nut,
         vien, chu, chu mo, mau nhan, chu tren mau nhan). Them chu de moi =
         them 1 dong trong bang themes[].
      2. Nut, num, fader deu ve PHANG: khong gradient, khong bong, khong vet
         sang. Nhe CPU nhat co the va giong mockup da chot.
      3. Font Be Vietnam Pro nhung trong exe (neu co file trong
         Resources/fonts). Khong co file thi tu dung font he thong.
      4. Doi chu de luc dang chay: moi LiveNTLookAndFeel (ca cai cua TonePanel)
         deu duoc cap nhat mau, khong chi LookAndFeel mac dinh.
*/

#if __has_include("BinaryData.h")
 #include "BinaryData.h"
 #define LIVENT_THEME_HAS_BINARYDATA 1
#else
 #define LIVENT_THEME_HAS_BINARYDATA 0
#endif

namespace livent
{
    /*  MOC 57: boc moi chuoi tieng Viet co dau bang ham nay de ep UTF-8. */
    /*  01/10: doi chu "LiveNT" khach nhin thay thanh ten thuong hieu
        (AppBranding appDisplayName). GIU NGUYEN khi la ten file / thu muc /
        chuong trinh phu: "LiveNT-Scanner", "LiveNT_Export", "LiveNT.exe",
        "%APPDATA%\LiveNT", "LiveNTBridge32"...  */
    inline juce::String brandify (const juce::String& s)
    {
        static const juce::String name = juce::String::fromUTF8 (branding::appDisplayName);
        if (name == "LiveNT" || ! s.contains ("LiveNT"))
            return s;

        juce::String out;
        int i = 0;
        for (;;)
        {
            const int p = s.indexOf (i, "LiveNT");
            if (p < 0) { out << s.substring (i); break; }

            const auto next = s[p + 6];
            const auto prev = p > 0 ? s[p - 1] : (juce::juce_wchar) 0;
            const bool dotExt = next == '.' && juce::CharacterFunctions::isLetter (s[p + 7]);   // LiveNT.exe / .NT
            const bool isFileOrPath = next == '-' || next == '_' || dotExt
                                   || juce::CharacterFunctions::isLetterOrDigit (next)
                                   || prev == '\\' || prev == '/'
                                   || juce::CharacterFunctions::isLetterOrDigit (prev);
            out << s.substring (i, p) << (isFileOrPath ? juce::String ("LiveNT") : name);
            i = p + 6;
        }
        return out;
    }

    inline juce::String vn (const char* utf8Text)
    {
        return brandify (juce::String (juce::CharPointer_UTF8 (utf8Text)));
    }

    //=========================================================================
    //  FONT NHUNG TRONG EXE
    //=========================================================================
    namespace fonts
    {
        /*  Tim file theo TEN GOC (vd "BeVietnamPro-Regular.ttf") trong
            BinaryData. Dung ten goc chu khong dung ten bien C++ vi JUCE tu doi
            ten bien (bo dau gach ngang...) - doan ten bien de sai.  */
        inline juce::Typeface::Ptr loadEmbedded (const char* originalFileName)
        {
           #if LIVENT_THEME_HAS_BINARYDATA
            for (int i = 0; i < BinaryData::namedResourceListSize; ++i)
            {
                if (juce::String (BinaryData::originalFilenames[i]) != originalFileName)
                    continue;

                int size = 0;

                if (auto* data = BinaryData::getNamedResource (BinaryData::namedResourceList[i], size))
                    if (size > 0)
                        return juce::Typeface::createSystemTypefaceFor (data, (size_t) size);
            }
           #else
            juce::ignoreUnused (originalFileName);
           #endif

            return {};
        }

        struct Set
        {
            juce::Typeface::Ptr regular, medium, semibold, bold;
        };

        inline const Set& get()
        {
            /*  V6.1.3: uu tien Be Vietnam Pro. Neu bo 4 file nay chua co trong
                Resources/fonts thi tu roi ve SVN-Kelson Sans da co san trong
                bo font cu. Nhu vay giao dien khong bao gio mat font/vo chu. */
            static const Set s = []
            {
                Set out;
                out.regular  = loadEmbedded ("BeVietnamPro-Regular.ttf");
                out.medium   = loadEmbedded ("BeVietnamPro-Medium.ttf");
                out.semibold = loadEmbedded ("BeVietnamPro-SemiBold.ttf");
                out.bold     = loadEmbedded ("BeVietnamPro-Bold.ttf");

                if (out.regular == nullptr)
                    out.regular = loadEmbedded ("SVN-Kelson Sans Regular.otf");
                if (out.medium == nullptr)
                    out.medium = out.regular;
                if (out.semibold == nullptr)
                    out.semibold = loadEmbedded ("SVN-Kelson Sans Bold.otf");
                if (out.bold == nullptr)
                    out.bold = out.semibold != nullptr ? out.semibold : out.regular;

                return out;
            }();
            return s;
        }

        /*  Chi thay font MAC DINH (sans-serif). Font rieng (vd mono cho so)
            van giu nguyen.
            "Bold" -> SemiBold (dam vua, dung tinh than mockup),
            "Medium" -> Medium, con lai -> Regular.  */
        inline juce::Typeface::Ptr forFont (const juce::Font& f)
        {
            const auto name = f.getTypefaceName();

            if (name.isNotEmpty() && name != juce::Font::getDefaultSansSerifFontName())
                return {};

            const auto style = f.getTypefaceStyle().toLowerCase();

           #if JUCE_WINDOWS
            /*  V0.6.7.9: CHU NHO TREN WINDOWS BI NHOE.

                Be Vietnam Pro nhung trong exe van co day du (log build ghi
                "nhung 3 font"). Nhung JUCE ve chu bang Direct2D che do xam
                (grayscale), khong dung duoc hinting/ClearType cua Windows cho
                font nap tu bo nho -> chu 10-14 px (nhat la dau tieng Viet
                chong 2 tang) nhin mo, nhoe. Cang ro khi thu phong 75-90%.

                Segoe UI la font he thong cua Windows, duoc tinh chinh tung
                pixel cho co nho va du dau tieng Viet. Nen:
                    chu < 17 px  -> Segoe UI   (nut, nhan, so, menu...)
                    chu >= 17 px -> Be Vietnam Pro (tieu de, ten bai - giu chat
                                    thuong hieu, co lon khong bi nhoe)
                macOS ve font rat muot nen van dung Be Vietnam Pro toan bo.  */
            if (f.getHeight() < 17.0f)
            {
                struct Sys { juce::Typeface::Ptr regular, semibold; };
                static const Sys sys = []
                {
                    Sys out;
                    out.regular  = juce::Typeface::createSystemTypefaceFor (
                                       juce::Font (juce::FontOptions ("Segoe UI", 14.0f, juce::Font::plain)));
                    out.semibold = juce::Typeface::createSystemTypefaceFor (
                                       juce::Font (juce::FontOptions ("Segoe UI", 14.0f, juce::Font::plain)
                                                       .withStyle ("Semibold")));
                    if (out.semibold == nullptr)
                        out.semibold = out.regular;
                    return out;
                }();

                if (sys.regular != nullptr)
                {
                    const bool heavy = f.isBold() || style.contains ("bold") || style.contains ("medium");
                    return heavy ? sys.semibold : sys.regular;
                }
            }
           #endif

            const auto& s = get();

            if (s.regular == nullptr)
                return {};

            if (f.isBold() || style.contains ("bold"))
            {
                if (s.semibold != nullptr) return s.semibold;
                if (s.bold     != nullptr) return s.bold;
                if (s.medium   != nullptr) return s.medium;
                return s.regular;
            }

            if (style.contains ("medium"))
                return s.medium != nullptr ? s.medium : s.regular;

            return s.regular;
        }
    }
}

//=============================================================================
namespace Col
{
    inline juce::File settingsFolder()
    {
        return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                  .getChildFile ("LiveNT");
    }

    //=========================================================================
    //  BANG 24 CHU DE
    //=========================================================================
    /*  key  : ten ngan khong dau, ghi vao theme-id.txt. Dung key chu khong
               dung so thu tu -> sau nay chen chu de moi vao giua bang thi
               lua chon cu cua khach van dung.
        name : ten hien cho khach (UTF-8, boc bang livent::vn khi dung).
        light: nen sang hay toi - de chon mau canh bao de doc.  */
    struct ThemeDef
    {
        const char*  key;
        const char*  name;
        juce::uint32 bg, panel, raised, line, text, dim, acc, on;
        bool         light;
    };

    inline constexpr ThemeDef themes[] =
    {
        //  ---- Nen toi ----
        { "studio",      "Studio xanh ngọc", 0xff14171c, 0xff1b1f26, 0xff232833, 0xff2c323d, 0xffe6e8eb, 0xff8a93a0, 0xff2bb3a3, 0xff04201c, false },
        { "sankhau",     "Sân khấu",         0xff0a0a0b, 0xff131315, 0xff1d1d20, 0xff323238, 0xffffffff, 0xffa3a3ab, 0xfff5b800, 0xff231a00, false },
        { "xanhdem",     "Xanh đêm",         0xff0e1524, 0xff141e33, 0xff1c2842, 0xff2a3b5d, 0xffe8eefc, 0xff91a2c2, 0xff4c8dff, 0xffffffff, false },
        { "timhoanghon", "Tím hoàng hôn",    0xff15121f, 0xff1c1829, 0xff262136, 0xff352e4a, 0xffece8f7, 0xff9a91b3, 0xffa78bfa, 0xff1e1045, false },
        { "hongdao",     "Hồng đào",         0xff1a1216, 0xff22181d, 0xff2d2027, 0xff3d2c35, 0xfff5e9ee, 0xffa8909b, 0xfff472b6, 0xff3b0a24, false },
        { "camlua",      "Cam lửa",          0xff17130f, 0xff1f1a14, 0xff29221a, 0xff3a3024, 0xfff4ece2, 0xffa89a88, 0xfffb8c3c, 0xff2a1200, false },
        { "xanhrung",    "Xanh rừng",        0xff0f1612, 0xff151e18, 0xff1d2821, 0xff2a3a2f, 0xffe7f2ea, 0xff8ea596, 0xff4ade80, 0xff052e16, false },
        { "thanchi",     "Than chì",         0xff111111, 0xff181818, 0xff222222, 0xff333333, 0xfff2f2f2, 0xff9a9a9a, 0xffe8e8e8, 0xff111111, false },
        { "caphe",       "Cà phê",           0xff1a1511, 0xff231c16, 0xff2e251d, 0xff3f3328, 0xffefe4d6, 0xffa89580, 0xffd4a373, 0xff2a1a0a, false },
        { "banggia",     "Băng giá",         0xff0c1418, 0xff111c22, 0xff18262e, 0xff243842, 0xffe4f4f8, 0xff88a8b3, 0xff67e8f9, 0xff062a33, false },
        { "chanhdien",   "Chanh điện",       0xff111310, 0xff181b16, 0xff22261e, 0xff313829, 0xffeef3e6, 0xff98a38a, 0xffc6f432, 0xff1d2600, false },
        { "hongphandem", "Hồng phấn đêm",    0xff1f161b, 0xff281c23, 0xff33242d, 0xff47323e, 0xfffbe9f0, 0xffb893a4, 0xfff9a8c9, 0xff3d0f24, false },
        { "timmongmo",   "Tím mộng mơ",      0xff18142a, 0xff201b36, 0xff2a2443, 0xff3b335b, 0xffefeaff, 0xffa69cc8, 0xffc4a8ff, 0xff251552, false },
        { "hongkhoi",    "Hồng khói",        0xff1b1719, 0xff231e21, 0xff2d272a, 0xff3e3639, 0xfff1e9ec, 0xffa8989e, 0xffd9a5b3, 0xff3a1a24, false },
        { "denhong",     "Đen hồng",         0xff0b0a0c, 0xff141216, 0xff1e1b21, 0xff332e37, 0xffffffff, 0xffa59fab, 0xffff6fb5, 0xff33041c, false },
        { "hoanggia",    "Hoàng gia",        0xff0d1220, 0xff141b2e, 0xff1c253c, 0xff2b3756, 0xfff3efe3, 0xff9aa0b4, 0xffd9b25f, 0xff231800, false },

        { "dodo",        "Đỏ đô",            0xff1c1011, 0xff26161a, 0xff321d22, 0xff472a30, 0xfff7e9ea, 0xffb59498, 0xffe0485a, 0xff3a0710, false },

        //  ---- Nen sang: nen diu, mat nut xam, vien va chu ro hon (08/10) ----
        { "banngay",     "Ban ngày",         0xffdcdfe4, 0xffecedf0, 0xffe4e4e5, 0xff8b9097, 0xff1b1f26, 0xff535d6b, 0xff2563eb, 0xffffffff, true  },
        { "hongphan",    "Hồng phấn",        0xfff2e4e8, 0xfff8eef1, 0xffe9e5e7, 0xffb28e9b, 0xff4a2433, 0xff8c5e70, 0xffb74875, 0xffffffff, true  },
        { "oaihuong",    "Oải hương",        0xffe7e4f2, 0xfff1eff8, 0xffe6e5ea, 0xff9a92b5, 0xff2f2650, 0xff6d6394, 0xff7b5bc8, 0xffffffff, true  },
        { "dao",         "Đào",              0xfff4e6de, 0xfff8f0ea, 0xffe9e6e4, 0xffb39584, 0xff4a2c1d, 0xff8d6956, 0xfff08a5d, 0xff3d1604, true  },
        { "bacha",       "Bạc hà",           0xffdfeee8, 0xffecf4f1, 0xffe3e7e6, 0xff87a69a, 0xff173a2e, 0xff527c6c, 0xff2fb58a, 0xff06382a, true  },
        { "kemsua",      "Kem sữa",          0xffede7dd, 0xfff4f1eb, 0xffe7e6e5, 0xffa59b8a, 0xff3b3226, 0xff786d5c, 0xffc79a5b, 0xff2e1d05, true  },
        { "troixanh",    "Trời xanh",        0xffe0eaf2, 0xffedf2f8, 0xffe4e7ea, 0xff8b9fb4, 0xff1d3550, 0xff57708c, 0xff4aa3e8, 0xff062a4a, true  },
        { "nangmai",     "Nắng mai",         0xfff2eddc, 0xfff7f5ea, 0xffe8e7e3, 0xffaba17a, 0xff3d3515, 0xff786e47, 0xffe0b400, 0xff2a2200, true  },
    };

    inline constexpr int numThemes = (int) (sizeof (themes) / sizeof (themes[0]));
    static_assert (numThemes == livent::rack::numLooks, "RackSkin.h looks[] phai co dung 1 dong cho moi chu de trong themes[] (cung thu tu)");

    inline juce::File themeIdFile()       { return settingsFolder().getChildFile ("theme-id.txt"); }
    inline juce::File galaxyEnabledFile() { return settingsFolder().getChildFile ("theme-galaxy.txt"); }

    inline int indexOfKey (const juce::String& key)
    {
        for (int i = 0; i < numThemes; ++i)
            if (key == themes[i].key)
                return i;

        return -1;
    }

    inline int loadThemeIndex()
    {
        const auto f = themeIdFile();

        if (! f.existsAsFile())
            return 0;

        return juce::jmax (0, indexOfKey (f.loadFileAsString().trim()));
    }

    inline bool loadGalaxyEnabled()
    {
        const auto f = galaxyEnabledFile();
        return f.existsAsFile() && f.loadFileAsString().trim().getIntValue() != 0;
    }

    //=========================================================================
    //  MAU DANG DUNG
    //=========================================================================
    /*  THU TU KHAI BAO QUAN TRONG: themeIndex phai dung TRUOC cac mau, vi cac
        mau khoi tao tu no. (Bien inline trong cung mot header duoc khoi tao
        dung thu tu khai bao.)

        Ten cu duoc giu nguyen: panel2, border, select, insert, sendCol...
        Code cu dang dung chung o hang chuc cho.  */
    inline int  themeIndex = loadThemeIndex();
    inline bool isLight    = themes[themeIndex].light;
    inline const int rackThemeSync = (livent::rack::themeIdxRef() = themeIndex);   // 12o: bang dieu khien rack di theo chu de

    inline juce::Colour bg       { themes[themeIndex].bg };
    inline juce::Colour panel    { themes[themeIndex].panel };
    inline juce::Colour raised   { themes[themeIndex].raised };
    inline juce::Colour line     { themes[themeIndex].line };
    inline juce::Colour text     { themes[themeIndex].text };
    inline juce::Colour textDim  { themes[themeIndex].dim };
    inline juce::Colour accent   { themes[themeIndex].acc };
    inline juce::Colour onAccent { themes[themeIndex].on };

    inline juce::Colour panel2   = panel.interpolatedWith (raised, 0.5f);
    inline juce::Colour border   = line;
    inline juce::Colour select   = bg.interpolatedWith (accent, isLight ? 0.18f : 0.24f);
    inline juce::Colour insert   = accent.interpolatedWith (bg, 0.45f);
    // V6.1.3: nut OFF tren theme sang khong con trang toat nhu nen.
    inline juce::Colour offButton= isLight ? raised.interpolatedWith (text, 0.14f) : raised;

    /*  Mau MANG NGHIA - giu co dinh o moi chu de (chi doi sac do cho nen
        sang de doc duoc): xanh = meter/tot, vang = canh bao, do = thu am/loi. */
    inline juce::Colour green    { isLight ? 0xff1f9d62u : 0xff3ecf8eu };
    inline juce::Colour amber    { isLight ? 0xffb86e00u : 0xfff5a524u };
    inline juce::Colour red      { isLight ? 0xffd63a3fu : 0xffff5a5fu };
    inline const juce::Colour sendCol { 0xff7a5aa8 };

    /*  Nen "galaxy" cu - mac dinh TAT. Giao dien phang khong can no, va no
        la phan ve ton CPU nhat. Van giu ham de ai con bat thi khong loi.  */
    inline bool galaxyEnabled = loadGalaxyEnabled();

    /** Ghi 24 mau vao bien - KHONG ve lai gi. Dung noi bo. */
    inline void setPalette (int index)
    {
        themeIndex = juce::jlimit (0, numThemes - 1, index);
        livent::rack::themeIdxRef() = themeIndex;   // 12o: tam nhom + LCD doi cung chu de
        livent::rack::bumpGeneration();
        const auto& t = themes[themeIndex];

        isLight  = t.light;
        bg       = juce::Colour (t.bg);
        panel    = juce::Colour (t.panel);
        raised   = juce::Colour (t.raised);
        line     = juce::Colour (t.line);
        text     = juce::Colour (t.text);
        textDim  = juce::Colour (t.dim);
        accent   = juce::Colour (t.acc);
        onAccent = juce::Colour (t.on);

        panel2   = panel.interpolatedWith (raised, 0.5f);
        border   = line;
        select   = bg.interpolatedWith (accent, isLight ? 0.18f : 0.24f);
        insert   = accent.interpolatedWith (bg, 0.45f);
        offButton= isLight ? raised.interpolatedWith (text, 0.14f) : raised;

        green    = juce::Colour (isLight ? 0xff1f9d62u : 0xff3ecf8eu);
        amber    = juce::Colour (isLight ? 0xffb86e00u : 0xfff5a524u);
        red      = juce::Colour (isLight ? 0xffd63a3fu : 0xffff5a5fu);
    }

    inline juce::String themeName (int index)
    {
        return livent::vn (themes[juce::jlimit (0, numThemes - 1, index)].name);
    }

    //=========================================================================
    //  XEM TRUOC / HUY / LUU  (bang chon giao dien dung)
    //=========================================================================
    struct ThemeSnapshot
    {
        int  index  = 0;
        bool galaxy = false;
        bool rack   = true;    // 12o: kieu rack (bang dieu khien) dang bat
        int  style  = 0;       // 12w: kieu ve (Nhom / Do cung / Kinh / Trang su)
    };

    inline ThemeSnapshot snapshot() noexcept
    {
        return { themeIndex, galaxyEnabled, livent::rack::enabled(), livent::rack::style() };
    }

    inline void saveTheme()
    {
        settingsFolder().createDirectory();
        themeIdFile().replaceWithText (themes[themeIndex].key);
        galaxyEnabledFile().replaceWithText (galaxyEnabled ? "1" : "0");
        livent::rack::saveEnabled();
        livent::rack::saveStyle();   // 12w
    }

    //  applyTheme() va restoreSnapshot() nam o CUOI file - chung can goi
    //  LiveNTLookAndFeel::refreshAll(), ma lop do khai bao ben duoi.
    inline void applyTheme (int index);
    inline void restoreSnapshot (const ThemeSnapshot& old);

    //=========================================================================
    /*  Nen cua cua so. Phang = 1 lenh fillRect. Galaxy chi ve khi con bat. */
    inline void paintBackground (juce::Graphics& g, juce::Rectangle<float> area)
    {
        g.setColour (bg);
        g.fillRect (area);

        if (! galaxyEnabled || area.isEmpty())
            return;

        const auto w = area.getWidth();
        const auto h = area.getHeight();
        const auto x = area.getX();
        const auto y = area.getY();

        {
            juce::ColourGradient grad (accent.withAlpha (0.20f), x + w * 0.78f, y + h * 0.18f,
                                       juce::Colours::transparentBlack, x + w * 0.40f, y + h * 0.72f, true);
            g.setGradientFill (grad);
            g.fillRect (area);
        }

        juce::Random rng ((juce::int64) 0x4c6976654e54LL);

        for (int i = 0; i < 90; ++i)
        {
            const float px = x + rng.nextFloat() * w;
            const float py = y + rng.nextFloat() * h;
            const float r  = 0.45f + rng.nextFloat() * 1.25f;
            g.setColour (text.withAlpha (0.10f + rng.nextFloat() * 0.25f));
            g.fillEllipse (px, py, r, r);
        }
    }
}

//=============================================================================
// Shared vector Power icon for both main and compact window chrome.
// No font character or external PNG resource required (DPI independent).
namespace livent::chrome_icons
{
    inline void drawPower (juce::Graphics& g, juce::Rectangle<float> bounds,
                           juce::Colour colour)
    {
        const float side = juce::jmin (bounds.getWidth(), bounds.getHeight());
        if (side < 4.0f) return;

        const auto c = bounds.getCentre();
        const float r = juce::jlimit (4.0f, 6.0f, side * 0.24f);
        juce::Path p;
        p.addCentredArc (c.x, c.y + r * 0.12f, r, r, 0.0f,
                         0.72f, juce::MathConstants<float>::twoPi - 0.72f, true);
        p.startNewSubPath (c.x, c.y - r * 1.05f);
        p.lineTo (c.x, c.y + r * 0.10f);
        g.setColour (colour);
        g.strokePath (p, juce::PathStrokeType (juce::jlimit (1.25f, 1.5f, r * 0.25f),
                                               juce::PathStrokeType::curved,
                                               juce::PathStrokeType::rounded));
    }

    // One compact, outlined close control shared by the main and compact bars.
    // The Power icon stays red at rest; hover/press only deepen the subtle tint.
    inline void drawCloseButton (juce::Graphics& g, juce::Rectangle<float> bounds,
                                 bool over, bool down, bool enabled)
    {
        if (bounds.getWidth() < 4.0f || bounds.getHeight() < 4.0f) return;
        const auto face = bounds.reduced (0.5f, 1.0f).withTrimmedBottom (1.0f);
        const auto red = juce::Colour (0xffff6675);
        const float alpha = enabled ? 1.0f : 0.45f;
        const float tint = down ? 0.24f : (over ? 0.15f : 0.07f);
        g.setColour (Col::raised.interpolatedWith (red, tint).withMultipliedAlpha (alpha));
        g.fillRoundedRectangle (face, 6.0f);
        g.setColour (red.withAlpha ((over || down ? 0.72f : 0.38f) * alpha));
        g.drawRoundedRectangle (face, 6.0f, 1.0f);
        drawPower (g, face, red.withMultipliedAlpha (alpha));
    }
}

//=============================================================================
/** Giao dien chung cua LiveNT - phang, 2D, doc mau tu Col:: luc ve. */
class LiveNTLookAndFeel : public juce::LookAndFeel_V4
{
public:
    LiveNTLookAndFeel()
    {
        registry().add (this);
        refreshColours();
    }

    ~LiveNTLookAndFeel() override
    {
        registry().removeFirstMatchingValue (this);
    }

    /*  Moi LiveNTLookAndFeel dang song (cai mac dinh + cai rieng cua
        TonePanel, LaughBoard...). Doi chu de thi cap nhat HET, khong thi bang
        nao dung LookAndFeel rieng se giu mau cu.  */
    static juce::Array<LiveNTLookAndFeel*>& registry()
    {
        static juce::Array<LiveNTLookAndFeel*> list;
        return list;
    }

    static void refreshAll()
    {
        for (auto* lf : registry())
            lf->refreshColours();
    }

    void refreshColours()
    {
        //  Bang mau goc cua JUCE V4 - lo phan lon cac thanh phan chuan.
        setColourScheme ({ Col::bg,        //  windowBackground
                           Col::raised,    //  widgetBackground
                           Col::panel,     //  menuBackground
                           Col::line,      //  outline
                           Col::text,      //  defaultText
                           Col::accent,    //  defaultFill
                           Col::text,      //  highlightedText
                           Col::select,    //  highlightedFill
                           Col::text });   //  menuText

        setColour (juce::ResizableWindow::backgroundColourId,       Col::bg);
        setColour (juce::DocumentWindow::textColourId,              Col::text);

        setColour (juce::PopupMenu::backgroundColourId,             Col::panel);
        setColour (juce::PopupMenu::textColourId,                   Col::text);
        setColour (juce::PopupMenu::headerTextColourId,             Col::textDim);
        setColour (juce::PopupMenu::highlightedBackgroundColourId,  Col::select);
        setColour (juce::PopupMenu::highlightedTextColourId,        Col::text);

        setColour (juce::TextButton::buttonColourId,                Col::raised);
        setColour (juce::TextButton::buttonOnColourId,              Col::accent);
        setColour (juce::TextButton::textColourOffId,               Col::text);
        setColour (juce::TextButton::textColourOnId,                Col::onAccent);

        setColour (juce::ComboBox::backgroundColourId,              Col::raised);
        setColour (juce::ComboBox::textColourId,                    Col::text);
        setColour (juce::ComboBox::outlineColourId,                 Col::line);
        setColour (juce::ComboBox::arrowColourId,                   Col::textDim);
        setColour (juce::ComboBox::buttonColourId,                  Col::raised);

        setColour (juce::Label::textColourId,                       Col::text);

        setColour (juce::Slider::thumbColourId,                     Col::text);
        setColour (juce::Slider::trackColourId,                     Col::accent);
        setColour (juce::Slider::backgroundColourId,                Col::line);
        setColour (juce::Slider::rotarySliderFillColourId,          Col::accent);
        setColour (juce::Slider::rotarySliderOutlineColourId,       Col::line);
        setColour (juce::Slider::textBoxTextColourId,               Col::text);
        setColour (juce::Slider::textBoxBackgroundColourId,         Col::bg);
        setColour (juce::Slider::textBoxOutlineColourId,            juce::Colours::transparentBlack);

        setColour (juce::TextEditor::backgroundColourId,            Col::bg);
        setColour (juce::TextEditor::textColourId,                  Col::text);
        setColour (juce::TextEditor::outlineColourId,               Col::line);
        setColour (juce::TextEditor::focusedOutlineColourId,        Col::accent);
        setColour (juce::TextEditor::highlightColourId,             Col::select);
        setColour (juce::TextEditor::highlightedTextColourId,       Col::text);
        setColour (juce::CaretComponent::caretColourId,             Col::text);

        setColour (juce::AlertWindow::backgroundColourId,           Col::panel);
        setColour (juce::AlertWindow::textColourId,                 Col::text);
        setColour (juce::AlertWindow::outlineColourId,              Col::line);

        setColour (juce::ToggleButton::textColourId,                Col::text);
        setColour (juce::ToggleButton::tickColourId,                Col::accent);
        setColour (juce::ToggleButton::tickDisabledColourId,        Col::textDim);

        setColour (juce::ScrollBar::thumbColourId,                  Col::line);
        setColour (juce::ListBox::backgroundColourId,               Col::bg);
        setColour (juce::ListBox::outlineColourId,                  Col::line);
        setColour (juce::ListBox::textColourId,                     Col::text);

        setColour (juce::TooltipWindow::backgroundColourId,         Col::panel);
        setColour (juce::TooltipWindow::textColourId,               Col::text);
        setColour (juce::TooltipWindow::outlineColourId,            Col::line);

        setColour (juce::ProgressBar::backgroundColourId,           Col::raised);
        setColour (juce::ProgressBar::foregroundColourId,           Col::accent);
        setColour (juce::HyperlinkButton::textColourId,             Col::accent);
        setColour (juce::GroupComponent::outlineColourId,           Col::line);
        setColour (juce::GroupComponent::textColourId,              Col::textDim);
    }

    //=========================================================================
    //  FONT
    //=========================================================================
    juce::Typeface::Ptr getTypefaceForFont (const juce::Font& f) override
    {
        if (auto t = livent::fonts::forFont (f))
            return t;

        return juce::LookAndFeel_V4::getTypefaceForFont (f);
    }

    juce::Font getTextButtonFont (juce::TextButton& b, int h) override
    {
        // V6.5.3: nut dong bang Cai dat dung glyph X ro, khong phu thuoc
        // vao kich thuoc nut chung.
        if ((bool) b.getProperties().getWithDefault ("settingsClose", false))
            return juce::Font (juce::FontOptions (17.0f).withStyle ("SemiBold"));

        // Tab Cài đặt dùng SemiBold + cỡ nguyên pixel: chữ rõ hơn trên Windows
        // 125%/150%, đặc biệt khi đổi sang các theme nền sáng.
        if ((bool) b.getProperties().getWithDefault ("settingsTab", false))
            return juce::Font (juce::FontOptions (12.0f).withStyle ("SemiBold"));

        const float raw = juce::jmin (15.0f, (float) h * 0.50f);
        const float snapped = (float) juce::jmax (9, juce::roundToInt (raw));
        return juce::Font (juce::FontOptions (snapped).withStyle ("SemiBold"));
    }

    juce::Font getComboBoxFont (juce::ComboBox& box) override
    {
        return juce::Font (juce::FontOptions (juce::jmin (15.0f, (float) box.getHeight() * 0.54f)));
    }

    juce::Font getPopupMenuFont() override
    {
        return juce::Font (juce::FontOptions (15.0f));
    }

    //=========================================================================
    //  NUT - kieu NT TUNE: mat nut co chieu sau (gradient + vien sang tren),
    //  nut BAT co quang sang mau nhan ben trong, bam xuong thi lun xuong.
    //  Chi dung gradient + net ve (khong DropShadow) -> nhe nhu nut phang cu.
    //=========================================================================
    /*  Quy tac mau (giu nguyen nhu cu):
          - dang BAT (toggle) hoac nut chinh (accentButton) -> to mau nhan
          - dang TAT -> nen nut xam + vien mong
          - nut tu dat mau rieng (vd pad tieng cuoi) -> dung mau do
        Properties cu (navTab, soundPad, modernRound, solidButton...) van duoc nhan. */
    static void paintNtSurface (juce::Graphics& g, juce::Rectangle<float> r, float radius,
                                juce::Colour fill, juce::Colour edge, float edgeW,
                                bool over, bool down, juce::Colour innerGlow)
    {
        const bool light = Col::isLight;

        if (down)       fill = fill.interpolatedWith (Col::text, 0.10f).darker (light ? 0.02f : 0.10f);
        else if (over)  fill = fill.interpolatedWith (Col::text, 0.05f);

        // bong mem duoi day nut (nam trong vung nut, khong can clip rong)
        if (! down)
        {
            g.setColour (juce::Colours::black.withAlpha (light ? 0.05f : 0.22f));   // V0.6.7.9: diu hon
            g.fillRoundedRectangle (r.translated (0.0f, 1.0f), radius);
        }

        auto face = down ? r.translated (0.0f, 1.0f) : r;
        const auto top = fill.brighter (light ? 0.01f : (down ? 0.01f : 0.05f));
        const auto bot = fill.darker   (light ? 0.03f : (down ? 0.06f : 0.12f));
        g.setGradientFill (juce::ColourGradient (top, face.getX(), face.getY(),
                                                 bot, face.getX(), face.getBottom(), false));
        g.fillRoundedRectangle (face, radius);

        // quang sang ben trong cho nut dang BAT (glow gia, khong blur)
        if (! innerGlow.isTransparent())
        {
            g.setColour (innerGlow.withMultipliedAlpha (0.09f));
            g.drawRoundedRectangle (face.reduced (2.2f), juce::jmax (1.0f, radius - 2.0f), 2.5f);
        }

        // vien sang mep tren (mat nut noi len)
        if (! down && face.getHeight() > 10.0f)
        {
            g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (light ? 0.12f : 0.055f), face.getX(), face.getY(),
                                                     juce::Colours::white.withAlpha (0.0f), face.getX(), face.getY() + face.getHeight() * 0.5f, false));
            g.drawRoundedRectangle (face.reduced (1.0f), juce::jmax (1.0f, radius - 1.0f), 1.0f);
        }

        g.setColour (over && ! down ? edge.interpolatedWith (Col::text, 0.18f) : edge);
        g.drawRoundedRectangle (face, radius, edgeW);
    }

    void drawButtonBackground (juce::Graphics& g, juce::Button& b,
                               const juce::Colour& backgroundColour,
                               bool over, bool down) override
    {
        auto r = b.getLocalBounds().toFloat().reduced (0.5f, 1.0f);

        if (r.getWidth() < 2.0f || r.getHeight() < 3.0f)
            return;
        r = r.withTrimmedBottom (1.0f);   // chua 1 px cho bong / hieu ung lun

        const auto& props    = b.getProperties();
        const bool on        = b.getToggleState();
        const bool accentBtn = (bool) props.getWithDefault ("accentButton", false);
        const bool navTab    = (bool) props.getWithDefault ("navTab", false);
        const bool liveChip  = (bool) props.getWithDefault ("liveChipStyle", false);
        const float radius   = juce::jmin (7.0f, r.getHeight() * 0.5f);

        // 15/10: nut kieu thanh tieu de Windows (Doc / Ngang, Gon) - nen trong suot,
        // re chuot moi hien nen nhat. Cung kieu voi nut "–" / "✕" (TitleBarButton).
        if ((int) props.getWithDefault ("captionIcon", 0) > 0)
        {
            if (over || down)
            {
                g.setColour (Col::raised.interpolatedWith (Col::text, down ? 0.14f : 0.07f));
                g.fillRoundedRectangle (b.getLocalBounds().toFloat(), 6.0f);
            }
            return;
        }

        if ((int) props.getWithDefault ("powerIcon", 0) > 0)
        {
            livent::chrome_icons::drawCloseButton (g, b.getLocalBounds().toFloat(), over, down, b.isEnabled());
            return;
        }

        // 16/10: skin mau 3 - nut chuc nang sang CA NUT bang mau chuc nang khi bat
        if (props.contains ("rackFn") && livent::rack::active())
        {
            livent::rack::drawFnButton (g, b.getLocalBounds().toFloat().reduced (0.5f, 0.5f), on,
                                        juce::Colour ((juce::uint32) (int) props["rackFn"]), over, down);
            return;
        }

        if ((bool) props.getWithDefault ("toneDetectedPulse", false))
        {
            const auto green = juce::Colour (0xff38b86d);
            paintNtSurface (g, r, radius, green, green.darker (0.2f), 1.0f, over, down, juce::Colours::transparentBlack);
            return;
        }

        // 12w: kieu moi (Do cung / Kinh / Trang su) - o Key thanh man LCD, +/- M/m va nut thanh dau thanh phim cua kieu
        if (livent::rack::newStyle())
        {
            if ((bool) props.getWithDefault ("rackLcdBtn", false))
            {
                livent::rack::drawLcdBox (g, b.getLocalBounds().toFloat().reduced (0.5f), 4.0f);
                if (over) { g.setColour (juce::Colours::white.withAlpha (0.06f)); g.fillRoundedRectangle (b.getLocalBounds().toFloat().reduced (1.0f), 4.0f); }
                return;
            }
            if ((bool) props.getWithDefault ("rackPlain", false) || (bool) props.getWithDefault ("rackChrome", false))
            {
                const bool recOn = (bool) props.getWithDefault ("recDot", false) && on;
                livent::rack::drawFnButton (g, b.getLocalBounds().toFloat().reduced (0.5f, 0.5f), recOn,
                                            juce::Colour (0xffe5484d), over, down, 6.0f);
                return;
            }
        }

        // Vang / Lofi / Remix / Be / Em be: OFF = mat nut noi, BAT = nen nhuom nhe
        // + vien accent + quang sang ben trong. Khong to accent dac de chu van
        // tuong phan tot tren theme sang.
        if (liveChip)
        {
            const float liveRadius = juce::jmin (10.0f, r.getHeight() * 0.26f);
            const juce::Colour fill = on
                              ? Col::accent.interpolatedWith (Col::panel, Col::isLight ? 0.72f : 0.74f)
                              : (Col::isLight ? Col::offButton : Col::raised);
            paintNtSurface (g, r, liveRadius, fill,
                            on ? Col::accent : Col::line.withAlpha (0.9f), on ? 1.35f : 1.0f,
                            over, down, on && ! Col::isLight ? Col::accent : juce::Colours::transparentBlack);

            // 06/10: nut co bang chuot phai (Nhac / Mic / Vang) -> 3 cham nho goc phai tren
            if ((bool) props.getWithDefault ("quickPanel", false) && r.getWidth() > 30.0f)
            {
                g.setColour ((on ? Col::accent : Col::textDim).withAlpha (0.85f));
                const float d = 2.2f, gap = 1.6f;
                const float x0 = r.getRight() - 6.0f - 3.0f * d - 2.0f * gap, y0 = r.getY() + 4.5f;
                for (int i = 0; i < 3; ++i)
                    g.fillEllipse (x0 + (float) i * (d + gap), y0, d, d);
            }
            return;
        }

        // Nut THU AM - vien do, bat thi to do dac + quang sang
        if ((bool) props.getWithDefault ("recDot", false))
        {
            paintNtSurface (g, r, radius, on ? Col::red : Col::raised, Col::red, 1.0f,
                            over, down, juce::Colours::transparentBlack);
            return;
        }

        if (on || accentBtn)
        {
            paintNtSurface (g, r, radius, Col::accent, Col::accent.darker (0.15f), 1.0f,
                            over, down, juce::Colours::transparentBlack);
            return;
        }

        juce::Colour fill = b.isColourSpecified (juce::TextButton::buttonColourId) ? backgroundColour
                                                                                    : Col::offButton;
        if (navTab)
            fill = Col::panel;

        paintNtSurface (g, r, radius, fill, Col::line, 1.0f, over, down, juce::Colours::transparentBlack);
    }

    /*  Chu tren nut. Nut co property "led" = true se co them cham LED nho ben
        trai chu (kieu nut hieu ung tren Bang dieu khien).  */
    void drawButtonText (juce::Graphics& g, juce::TextButton& b,
                         bool, bool) override
    {
        const auto text = b.getButtonText();
        const auto& props = b.getProperties();
        const bool forceFullText = (bool) props.getWithDefault ("forceFullText", false);
        const bool liveChipStyle = (bool) props.getWithDefault ("liveChipStyle", false);
        const bool settingsClose = (bool) props.getWithDefault ("settingsClose", false);

        // The shared close renderer draws its icon with the background.
        if ((int) props.getWithDefault ("powerIcon", 0) > 0)
            return;

        if (props.contains ("rackFn") && livent::rack::active())
        {
            // 12o: chu nut to hon ~12% so voi ban 12n
            const float fs = (float) juce::roundToInt (juce::jlimit (11.0f, 16.0f, (float) b.getHeight() * 0.58f));
            g.setColour (livent::rack::fnTextColour (b.getToggleState(), juce::Colour ((juce::uint32) (int) props["rackFn"]))
                             .withMultipliedAlpha (b.isEnabled() ? 1.0f : 0.5f));
            g.setFont (juce::Font (juce::FontOptions (fs).withStyle ("Bold")));
            g.drawFittedText (text, b.getLocalBounds().reduced (3, 0), juce::Justification::centred, 1, 0.7f);
            return;
        }

        if ((bool) props.getWithDefault ("toneDetectedPulse", false))
        {
            g.setColour (juce::Colour (0xff092b18)); g.setFont (juce::Font (juce::FontOptions (14.0f).withStyle ("Bold")));
            g.drawFittedText (text, b.getLocalBounds().reduced (6, 2), juce::Justification::centred, 1);
            return;
        }

        if (livent::rack::newStyle())
        {
            if ((bool) props.getWithDefault ("rackLcdBtn", false))
            {
                g.setColour (livent::rack::lcdText().withMultipliedAlpha (b.isEnabled() ? 1.0f : 0.5f));
                g.setFont (juce::Font (juce::FontOptions (juce::jlimit (12.0f, 17.0f, (float) b.getHeight() * 0.50f)).withStyle ("Bold")));
                g.drawFittedText (text, b.getLocalBounds().reduced (6, 2), juce::Justification::centred, 1, 0.7f);
                return;
            }
            if ((bool) props.getWithDefault ("rackPlain", false))
            {
                g.setColour (livent::rack::fnTextColour (false).withMultipliedAlpha (b.isEnabled() ? 1.0f : 0.5f));
                g.setFont (juce::Font (juce::FontOptions (juce::jlimit (11.0f, 16.0f, (float) b.getHeight() * 0.52f)).withStyle ("Bold")));
                g.drawFittedText (text, b.getLocalBounds().reduced (3, 0), juce::Justification::centred, 1, 0.7f);
                return;
            }
        }

        // Nút X của bảng Cài đặt vẽ bằng vector nên luôn sắc ở mọi DPI/font.
        if (settingsClose)
        {
            auto r = b.getLocalBounds().toFloat().reduced (8.0f);
            auto c = b.isEnabled() ? Col::text : Col::textDim;
            g.setColour (c);
            g.drawLine (r.getX(), r.getY(), r.getRight(), r.getBottom(), 1.8f);
            g.drawLine (r.getRight(), r.getY(), r.getX(), r.getBottom(), 1.8f);
            return;
        }

        // 15/10: bieu tuong thanh tieu de - cung net 1.4 px, cung co ~13 px voi "–" / "✕".
        if (const int caption = (int) props.getWithDefault ("captionIcon", 0); caption > 0)
        {
            const auto c = b.getLocalBounds().toFloat().getCentre();
            const float lw = 1.4f;
            g.setColour (b.isEnabled() ? Col::text : Col::textDim);
            if (caption == 1)        // khung DUNG = chuyen sang bang Doc
            {
                const auto fr = juce::Rectangle<float> (8.5f, 13.0f).withCentre (c);
                g.drawRoundedRectangle (fr, 1.6f, lw);
                g.drawLine (fr.getX(), fr.getY() + 3.4f, fr.getRight(), fr.getY() + 3.4f, lw);
            }
            else if (caption == 2)   // khung NGANG = ve bang Ngang
            {
                const auto fr = juce::Rectangle<float> (13.0f, 8.5f).withCentre (c);
                g.drawRoundedRectangle (fr, 1.6f, lw);
                g.drawLine (fr.getX() + 3.4f, fr.getY(), fr.getX() + 3.4f, fr.getBottom(), lw);
            }
            else if (caption == 3)   // 2 o vuong chong nhau = Gon (giao dien dang day du -> bam de thu gon)
            {
                // Giong nut "khoi phuc" cua Windows: o sau lech len tren-phai, o truoc o duoi-trai.
                const float s = 8.0f;
                const auto front = juce::Rectangle<float> (s, s).withCentre (c).translated (-1.0f, 1.0f);
                const auto back  = front.translated (2.5f, -2.5f);
                juce::Path behind;                                  // chi ve phan o sau lo ra ngoai o truoc
                behind.startNewSubPath (front.getX() + 2.5f, back.getY());
                behind.lineTo (back.getRight(), back.getY());
                behind.lineTo (back.getRight(), front.getBottom() - 2.5f);
                g.strokePath (behind, juce::PathStrokeType (lw));
                g.drawRect (front, lw);
            }
            return;
        }

        // 15/10: o vuong DON (kieu nut "phong to" cua Windows) - ve len nen nut binh thuong.
        // Dung cho nut "mo lai giao dien day du" tren thanh gon.
        if ((int) props.getWithDefault ("squareIcon", 0) > 0)
        {
            const auto c = b.getLocalBounds().toFloat().getCentre();
            g.setColour (b.isEnabled() ? Col::text : Col::textDim);
            g.drawRect (juce::Rectangle<float> (10.0f, 10.0f).withCentre (c), 1.4f);
            return;
        }

        // 15/10: anh nut thanh duoi (YouTube / Cuoi / Cai dat). Co chu (thanh gon) -> ve chu nhu cu.
        if (const int image = (int) props.getWithDefault ("imageIcon", 0); image > 0 && text.isEmpty())
        {
            livent::toolbaricons::draw (g, image, b.getLocalBounds().toFloat(),
                                        b.isEnabled() ? Col::text : Col::textDim,
                                        image == livent::toolbaricons::settings);
            return;
        }

        // HOTFIX21: LOFI phai LUON hien du chu. Nut nay co the bi JUCE cat
        // thanh "L..." tren mot so DPI/scale du chieu rong nhin bang mat van du.
        // Khi forceFullText=true, bo LED va tu co font den khi chu vua, khong
        // bao gio cho drawText chen dau ba cham.

        // V6.5.2: cac nut live (LOFI/REMIX/BE...) co LED ben trai. Khi bang
        // dieu khien bi thu hep, viec tru 12 px le + 11 px LED co the lam
        // "Lofi" chi con ve duoc "L". Nut hep thi uu tien TEN NUT; LED se
        // tu an va hien lai khi co du chieu rong.
        const bool wantsLed = (bool) props.getWithDefault ("led", false) && ! forceFullText;
        auto area = b.getLocalBounds().reduced (wantsLed ? 3 : 4, 2);
        // V0.6.7.9e: nut co thanh song nam sat day -> day chu len mot chut cho khong de len song
        if ((bool) props.getWithDefault ("meterBelow", false))
            area = area.withTrimmedBottom (5);

        //  V6.0: nut THU AM - cham tron do (dang tat) / o vuong (dang thu) + chu
        if ((bool) props.getWithDefault ("recDot", false))
        {
            const bool rec  = b.getToggleState();
            const auto dark = juce::Colour (0xff2a0506);
            const float s   = 10.0f;

            juce::Rectangle<float> icon;
            const float textW = text.isEmpty() ? 0.0f
                              : juce::GlyphArrangement::getStringWidth (juce::Font (juce::FontOptions (12.0f).withStyle ("Bold")), text);
            const float total = s + (textW > 0.0f ? 6.0f + textW : 0.0f);
            icon = { (float) b.getWidth() * 0.5f - total * 0.5f, (float) b.getHeight() * 0.5f - s * 0.5f, s, s };

            g.setColour (rec ? dark : Col::red);

            if (rec) g.fillRoundedRectangle (icon.reduced (0.5f), 2.0f);
            else     g.fillEllipse (icon);

            if (textW > 0.0f)
            {
                g.setFont (juce::Font (juce::FontOptions (12.0f).withStyle ("Bold")));
                g.setColour (rec ? dark : Col::red);
                g.drawText (text, juce::Rectangle<float> (icon.getRight() + 6.0f, 0.0f, textW + 2.0f, (float) b.getHeight()),
                            juce::Justification::centredLeft, false);
            }
            return;
        }

        // V0.6.7.9d: (dat TRUOC lenh bo qua chu rong) nut doi bo cuc chi co ICON (khung nam ngang = "ve Ngang").
        if ((int) props.getWithDefault ("layoutIcon", 0) == 1 && text.isEmpty())
        {
            const auto ic = b.isEnabled() ? Col::text : Col::text.withMultipliedAlpha (Col::isLight ? 0.60f : 0.45f);
            const float h = juce::jlimit (8.0f, 11.0f, (float) b.getHeight() * 0.36f);
            const float w = h * 1.65f;
            auto ir = juce::Rectangle<float> (w, h).withCentre (area.toFloat().getCentre());
            g.setColour (ic);
            g.drawRoundedRectangle (ir, 1.8f, 1.35f);
            g.fillRoundedRectangle (ir.reduced (2.2f).withWidth ((ir.getWidth() - 4.4f) * 0.34f), 1.0f);
            g.drawLine (ir.getX() + ir.getWidth() * 0.62f, ir.getY() + 2.4f,
                        ir.getX() + ir.getWidth() * 0.62f, ir.getBottom() - 2.4f, 1.1f);
            return;
        }

        const bool iconOnly = text.isEmpty() && (int) props.getWithDefault ("toolbarIcon", 0) > 0;   // 06/10: banh rang
        if ((text.isEmpty() && ! iconOnly) || area.getWidth() < 6 || area.getHeight() < 6)
            return;

        if (forceFullText && ! iconOnly)
        {
            const bool on = b.getToggleState()
                         || (bool) props.getWithDefault ("accentButton", false);

            juce::Colour tc;
            if (liveChipStyle)
                tc = Col::text;
            else if (on)
                tc = b.isColourSpecified (juce::TextButton::textColourOnId)
                         ? b.findColour (juce::TextButton::textColourOnId) : Col::onAccent;
            else if (b.isColourSpecified (juce::TextButton::textColourOffId))
                tc = b.findColour (juce::TextButton::textColourOffId);
            else
                tc = Col::text;

            if (! b.isEnabled())
                tc = tc.withMultipliedAlpha (Col::isLight ? 0.60f : 0.45f);

            float fs = (float) juce::roundToInt (juce::jlimit (10.0f, 14.0f, (float) b.getHeight() * 0.46f));
            auto font = juce::Font (juce::FontOptions (fs).withStyle (liveChipStyle ? "SemiBold" : (on ? "Bold" : "SemiBold")));

            while (fs > 8.0f
                   && juce::GlyphArrangement::getStringWidth (font, text) > (float) area.getWidth())
            {
                fs -= 1.0f;
                font = juce::Font (juce::FontOptions (fs).withStyle (liveChipStyle ? "SemiBold" : (on ? "Bold" : "SemiBold")));
            }

            g.setColour (tc);
            g.setFont (font);
            g.drawText (text, area, juce::Justification::centred, false);
            return;
        }

        // V6.5.3: icon nho tren 4 nut thao tac dau Bang dieu khien.
        // Ve bang vector thay vi emoji/font icon de may khach nao cung giong nhau
        // va khong phu thuoc Windows co glyph do hay khong.
        const int toolbarIcon = (int) props.getWithDefault ("toolbarIcon", 0);
        if (toolbarIcon > 0)
        {
            const bool isOn = b.getToggleState();
            juce::Colour tc = isOn && b.isColourSpecified (juce::TextButton::textColourOnId)
                                  ? b.findColour (juce::TextButton::textColourOnId)
                                  : (b.isColourSpecified (juce::TextButton::textColourOffId)
                                         ? b.findColour (juce::TextButton::textColourOffId)
                                         : Col::text);
            if (! b.isEnabled())
                tc = tc.withMultipliedAlpha (Col::isLight ? 0.60f : 0.45f);

            // HOTFIX15: thanh tren van gon nhung chu ro hon. Truoc day o cao
            // 26 px font chi ~10 px nen tren laptop/scale 125% nhin rat nho.
            float fs = juce::jlimit (11.0f, 13.0f, (float) b.getHeight() * 0.46f);
            fs = (float) juce::roundToInt (fs);
            auto font = juce::Font (juce::FontOptions (fs).withStyle ("SemiBold"));
            float textW = juce::GlyphArrangement::getStringWidth (font, text);
            const float iconS = juce::jlimit (9.5f, 12.0f, (float) b.getHeight() * 0.42f)
                              * (text.isEmpty() ? 1.2f : 1.0f);   // 06/10: nut chi co icon (banh rang)
            const float gap = text.isEmpty() ? 0.0f : 4.0f;

            // Neu nut compact qua hep, thu nho chu mot chut truoc khi bo icon.
            while (fs > 10.0f && textW + iconS + gap > (float) area.getWidth())
            {
                fs -= 1.0f;
                font = juce::Font (juce::FontOptions (fs).withStyle ("SemiBold"));
                textW = juce::GlyphArrangement::getStringWidth (font, text);
            }

            const bool drawIcon = textW + iconS + gap <= (float) area.getWidth();
            const float totalW = textW + (drawIcon ? iconS + gap : 0.0f);
            float x = (float) area.getCentreX() - totalW * 0.5f;
            const float cy = (float) area.getCentreY();

            if (drawIcon)
            {
                auto ir = juce::Rectangle<float> (x, cy - iconS * 0.5f, iconS, iconS);
                g.setColour (toolbarIcon == 1 ? Col::red : tc);
                const float sw = 1.35f;

                if (toolbarIcon == 1) // Thu Am
                {
                    g.fillEllipse (ir.reduced (iconS * 0.22f));
                    g.drawEllipse (ir.reduced (0.5f), sw);
                }
                else if (toolbarIcon == 2) // Cuoi
                {
                    g.drawEllipse (ir.reduced (0.6f), sw);
                    const float eye = juce::jmax (1.0f, iconS * 0.10f);
                    g.fillEllipse (ir.getX() + iconS * 0.28f, ir.getY() + iconS * 0.30f, eye, eye);
                    g.fillEllipse (ir.getX() + iconS * 0.62f, ir.getY() + iconS * 0.30f, eye, eye);
                    juce::Path smile;
                    smile.startNewSubPath (ir.getX() + iconS * 0.25f, ir.getY() + iconS * 0.58f);
                    smile.quadraticTo (ir.getCentreX(), ir.getY() + iconS * 0.88f,
                                       ir.getX() + iconS * 0.75f, ir.getY() + iconS * 0.58f);
                    g.strokePath (smile, juce::PathStrokeType (sw));
                }
                else if (toolbarIcon == 3) // Luu bai
                {
                    g.drawRoundedRectangle (ir.reduced (0.7f), 1.5f, sw);
                    g.drawLine (ir.getX() + iconS * 0.28f, ir.getY() + iconS * 0.12f,
                                ir.getX() + iconS * 0.28f, ir.getY() + iconS * 0.48f, sw);
                    g.drawLine (ir.getX() + iconS * 0.28f, ir.getY() + iconS * 0.48f,
                                ir.getX() + iconS * 0.72f, ir.getY() + iconS * 0.48f, sw);
                    g.drawRoundedRectangle (ir.getX() + iconS * 0.28f, ir.getY() + iconS * 0.62f,
                                            iconS * 0.44f, iconS * 0.22f, 1.0f, sw);
                }
                else if (toolbarIcon == 5) // 06/10: Cai dat - banh rang
                {
                    const auto c = ir.getCentre();
                    const float rOut = iconS * 0.52f, rIn = iconS * 0.38f;
                    juce::Path gear;
                    constexpr int teeth = 8;
                    auto pt = [c] (float r, float a) { return juce::Point<float> (c.x + r * std::sin (a), c.y - r * std::cos (a)); };
                    for (int i = 0; i < teeth; ++i)
                    {
                        const float a = juce::MathConstants<float>::twoPi * (float) i / (float) teeth;
                        const auto p0 = pt (rIn, a - 0.30f);
                        if (i == 0) gear.startNewSubPath (p0); else gear.lineTo (p0);
                        gear.lineTo (pt (rOut, a - 0.17f));
                        gear.lineTo (pt (rOut, a + 0.17f));
                        gear.lineTo (pt (rIn,  a + 0.30f));
                    }
                    gear.closeSubPath();
                    g.setColour (tc);
                    g.strokePath (gear, juce::PathStrokeType (sw, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
                    g.drawEllipse (juce::Rectangle<float> (iconS * 0.32f, iconS * 0.32f).withCentre (c), sw);
                }
                else // Danh sach
                {
                    for (int i = 0; i < 3; ++i)
                    {
                        const float yy = ir.getY() + iconS * (0.22f + i * 0.29f);
                        g.fillEllipse (ir.getX() + iconS * 0.05f, yy - 1.0f, 2.0f, 2.0f);
                        g.drawLine (ir.getX() + iconS * 0.28f, yy, ir.getRight() - iconS * 0.04f, yy, sw);
                    }
                }
                x += iconS + gap;
            }

            g.setFont (font);
            g.setColour (tc);
            g.drawText (text, juce::Rectangle<float> (x, (float) area.getY(),
                                                      juce::jmax (1.0f, (float) area.getRight() - x),
                                                      (float) area.getHeight()),
                        juce::Justification::centredLeft, true);
            return;
        }

        //  V6.0: nut hai dong - chu chinh + dong phu nho (vd buffer "256" / "5.3 ms")
        if (props.contains ("subText"))
        {
            const bool onSub = b.getToggleState();
            const auto main  = onSub ? Col::onAccent : Col::text;
            auto top = area.removeFromTop (area.getHeight() / 2 + 1);

            g.setColour (b.isEnabled() ? main : main.withMultipliedAlpha (Col::isLight ? 0.60f : 0.45f));
            g.setFont (juce::Font (juce::FontOptions (13.0f).withStyle (onSub ? "Bold" : "Medium")));
            g.drawText (text, top, juce::Justification::centredBottom, true);

            g.setColour (onSub ? Col::onAccent : Col::textDim);
            g.setFont (juce::Font (juce::FontOptions (11.0f)));
            g.drawText (props["subText"].toString(), area, juce::Justification::centredTop, true);
            return;
        }

        const bool on  = b.getToggleState() || (bool) props.getWithDefault ("accentButton", false);

        bool led = wantsLed;
        if (led)
        {
            // Neu o kich thuoc chu toi thieu ma ten + LED van khong vua,
            // bo LED thay vi cat mat ten nut (vd "Lofi" -> "L").
            const auto minFont = juce::Font (juce::FontOptions (10.0f).withStyle (on ? "Bold" : "Medium"));
            const float minTextW = juce::GlyphArrangement::getStringWidth (minFont, text);
            if (minTextW + 11.0f > (float) area.getWidth())
                led = false;
        }

        juce::Colour tc;

        // Nút live luôn dùng màu chữ chính. Trước đây OFF + LED dùng textDim,
        // trên theme sáng nhìn giống chữ bị blur dù font vẫn đúng.
        if (liveChipStyle)
            tc = Col::text;
        else if (on)
            tc = b.isColourSpecified (juce::TextButton::textColourOnId)
                     ? b.findColour (juce::TextButton::textColourOnId) : Col::onAccent;
        else if (b.isColourSpecified (juce::TextButton::textColourOffId))
            tc = b.findColour (juce::TextButton::textColourOffId);
        else
            tc = led && ! Col::isLight ? Col::textDim : Col::text;

        if (! b.isEnabled())
            tc = tc.withMultipliedAlpha (Col::isLight ? 0.60f : 0.45f);

        auto makeFont = [on, liveChipStyle] (float size)
        {
            return juce::Font (juce::FontOptions (size).withStyle (liveChipStyle ? "SemiBold"
                                                                                : (on ? "Bold" : "SemiBold")));
        };

        const float ledW = led ? 11.0f : 0.0f;
        const bool preferFullText = (bool) props.getWithDefault ("preferFullText", false);
        const float minimumSize = preferFullText ? 8.0f : 10.0f;
        float size = (float) juce::roundToInt (juce::jlimit (11.0f, 16.0f, (float) b.getHeight() * 0.50f));
        auto font = makeFont (size);

        // Cỡ chữ chỉ đi theo pixel nguyên để nét chữ ổn định hơn ở DPI 125/150%.
        while (size > minimumSize
               && juce::GlyphArrangement::getStringWidth (font, text) + ledW > (float) area.getWidth())
        {
            size -= 1.0f;
            font = makeFont (size);
        }

        g.setFont (font);

        if (led)
        {
            const float textW = juce::jmin ((float) area.getWidth() - ledW,
                                            juce::GlyphArrangement::getStringWidth (font, text));
            const float startX = (float) area.getCentreX() - (textW + ledW) * 0.5f;

            const auto ledCol = on ? (liveChipStyle ? Col::accent : Col::onAccent) : Col::line;
            if (on && liveChipStyle && ! Col::isLight)
            {
                g.setColour (ledCol.withAlpha (0.22f));
                g.fillEllipse (startX - 3.0f, (float) area.getCentreY() - 6.0f, 12.0f, 12.0f);
            }
            g.setColour (ledCol);
            g.fillEllipse (startX, (float) area.getCentreY() - 3.0f, 6.0f, 6.0f);

            g.setColour (tc);
            g.drawText (text, juce::Rectangle<float> (startX + ledW, (float) area.getY(),
                                                      textW + 2.0f, (float) area.getHeight()),
                        juce::Justification::centredLeft, true);
            return;
        }

        g.setColour (tc);
        // Nút được đánh dấu ưu tiên tên (đặc biệt LOFI) không dùng dấu ...;
        // font đã tự co xuống trước nên luôn cố vẽ đủ chữ.
        g.drawText (text, area, juce::Justification::centred, ! preferFullText);
    }

    //=========================================================================
    //  NUM VAN - kieu NT TUNE: vach chia sang theo gia tri + cung phat sang
    //  + than kim loai co van tron + cham chi thi phat sang.
    //  Mau nhan lay theo theme (Col::accent) -> doi F5 la num doi mau theo.
    //  Theme sang (Col::isLight) dung than num sang, bong nhe hon.
    //
    //  HIEU NANG: phan TINH (vach chia tat, ranh, than num + bong + van) duoc ve
    //  MOT LAN vao anh dem theo (kich thuoc, ti le man hinh, theme) roi chi dan
    //  anh. Moi lan ve chi con phan DONG: vach sang, cung gia tri, cham chi thi.
    //  Glow = vai net ve chong mo dan, KHONG dung DropShadow (lam mo anh rat ton).
    //=========================================================================
    struct KnobGeom
    {
        float R, ringR, ringW, bodyR, faceR, dotR, tIn;
        bool  big;
        int   ticks;
    };

    static KnobGeom knobGeom (float d)
    {
        KnobGeom k;
        k.R     = d * 0.5f;
        k.big   = d >= 90.0f;
        k.ticks = k.big ? 25 : 13;
        k.tIn   = k.R * 0.86f;
        k.ringW = juce::jlimit (2.5f, 4.0f, d * 0.05f);
        k.ringR = k.R * 0.76f;
        k.bodyR = k.ringR - k.ringW * 1.5f - juce::jmax (2.0f, d * 0.04f);
        k.faceR = k.bodyR * 0.82f;
        k.dotR  = juce::jlimit (2.0f, 4.5f, d * 0.035f);
        return k;
    }

    static void drawKnobTick (juce::Graphics& g, juce::Point<float> c, const KnobGeom& k,
                              int i, float startAngle, float endAngle, juce::Colour col)
    {
        const float t     = (float) i / (float) (k.ticks - 1);
        const float a     = startAngle + t * (endAngle - startAngle);
        const bool  major = (i % (k.big ? 6 : 3)) == 0;
        const float r1    = major ? k.R * 0.99f : k.R * 0.94f;
        g.setColour (col.withMultipliedAlpha (major ? 1.0f : 0.65f));
        g.drawLine (juce::Line<float> (c.getPointOnCircumference (k.tIn, a),
                                       c.getPointOnCircumference (r1, a)),
                    major ? 1.4f : 1.0f);
    }

    /** Ve phan tinh cua num vao anh dem (goi lai chi khi doi size/theme/scale). */
    juce::Image renderKnobStatic (float d, float scale, float startAngle, float endAngle) const
    {
        const int px = juce::jmax (1, juce::roundToInt (d * scale));
        juce::Image img (juce::Image::ARGB, px, px, true);
        juce::Graphics g (img);
        g.addTransform (juce::AffineTransform::scale (scale));

        const bool light = Col::isLight;
        const auto k = knobGeom (d);
        const juce::Point<float> c (d * 0.5f, d * 0.5f);
        const auto base = light ? juce::Colours::black : juce::Colours::white;

        for (int i = 0; i < k.ticks; ++i)
            drawKnobTick (g, c, k, i, startAngle, endAngle,
                          base.withAlpha ((i % (k.big ? 6 : 3)) == 0 ? (light ? 0.22f : 0.16f) : (light ? 0.18f : 0.12f)));

        juce::Path track;
        track.addCentredArc (c.x, c.y, k.ringR, k.ringR, 0.0f, startAngle, endAngle, true);
        g.setColour (light ? Col::line.darker (0.05f) : Col::bg.darker (0.5f));
        g.strokePath (track, juce::PathStrokeType (k.ringW + 2.0f, juce::PathStrokeType::curved,
                                                   juce::PathStrokeType::rounded));
        g.setColour (base.withAlpha (0.07f));
        g.strokePath (track, juce::PathStrokeType (k.ringW, juce::PathStrokeType::curved,
                                                   juce::PathStrokeType::rounded));

        if (k.bodyR < 4.0f)
            return img;

        juce::Path body;
        body.addEllipse (c.x - k.bodyR, c.y - k.bodyR, k.bodyR * 2.0f, k.bodyR * 2.0f);
        // bong do chi ve 1 lan o day nen dung DropShadow van re
        juce::DropShadow (juce::Colours::black.withAlpha (light ? 0.25f : 0.75f),
                          juce::roundToInt (juce::jlimit (4.0f, 20.0f, k.bodyR * 0.5f)),
                          { 0, juce::roundToInt (juce::jmax (1.0f, k.bodyR * 0.15f)) }).drawForPath (g, body);

        const auto topCol = light ? juce::Colours::white        : Col::raised.brighter (0.30f);
        const auto botCol = light ? Col::raised.darker (0.12f) : Col::bg.darker (0.55f);
        g.setGradientFill (juce::ColourGradient (topCol, c.x - k.bodyR * 0.6f, c.y - k.bodyR,
                                                 botCol, c.x + k.bodyR * 0.4f, c.y + k.bodyR, false));
        g.fillPath (body);
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (light ? 0.9f : 0.22f), c.x, c.y - k.bodyR,
                                                 juce::Colours::white.withAlpha (0.0f), c.x, c.y + k.bodyR * 0.2f, false));
        g.drawEllipse (c.x - k.bodyR + 0.5f, c.y - k.bodyR + 0.5f, k.bodyR * 2.0f - 1.0f, k.bodyR * 2.0f - 1.0f, 1.0f);

        g.setGradientFill (juce::ColourGradient (light ? Col::panel : Col::raised.brighter (0.06f), c.x, c.y - k.faceR,
                                                 light ? Col::raised.darker (0.04f) : Col::raised.darker (0.35f), c.x, c.y + k.faceR, false));
        g.fillEllipse (c.x - k.faceR, c.y - k.faceR, k.faceR * 2.0f, k.faceR * 2.0f);
        const int rings = k.big ? 7 : 4;
        g.setColour (base.withAlpha (0.02f));
        for (int i = 1; i <= rings; ++i)
        {
            const float rr = k.faceR * (float) i / (float) (rings + 1);
            g.drawEllipse (c.x - rr, c.y - rr, rr * 2.0f, rr * 2.0f, 0.8f);
        }
        g.setColour (juce::Colours::black.withAlpha (light ? 0.12f : 0.45f));
        g.drawEllipse (c.x - k.faceR, c.y - k.faceR, k.faceR * 2.0f, k.faceR * 2.0f, 1.0f);
        return img;
    }

    /** 12o: o so duoi num kieu rack = man LCD (nen den, chu mau LCD, font dam lon hon). */
    juce::Label* createSliderTextBox (juce::Slider& slider) override
    {
        auto* l = juce::LookAndFeel_V4::createSliderTextBox (slider);
        if ((bool) slider.getProperties().getWithDefault ("rackKnob", false) && livent::rack::active())
        {
            l->setFont (juce::Font (juce::FontOptions (14.0f).withStyle ("Bold")));
            l->setColour (juce::Label::textColourId, livent::rack::valueText());          // 12w: theo kieu
            l->setColour (juce::Label::backgroundColourId, livent::rack::valueBoxBg());
            l->setColour (juce::Label::outlineColourId, livent::rack::valueBoxOutline());
            l->setBorderSize (juce::BorderSize<int> (0, 1, 0, 1));
        }
        return l;
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float pos, float startAngle, float endAngle,
                           juce::Slider& s) override
    {
        if ((bool) s.getProperties().getWithDefault ("rackKnob", false) && livent::rack::active())
        {
            livent::rack::drawKnob (g, juce::Rectangle<float> ((float) x, (float) y, (float) width, (float) height).reduced (1.0f),
                                    pos, startAngle, endAngle, s.isEnabled());
            return;
        }

        auto bounds = juce::Rectangle<float> ((float) x, (float) y,
                                              (float) width, (float) height).reduced (1.0f);
        const float d = juce::jmin (bounds.getWidth(), bounds.getHeight());
        if (d < 14.0f)
            return;

        const auto area  = bounds.withSizeKeepingCentre (d, d);
        const auto c     = area.getCentre();
        const float angle = startAngle + pos * (endAngle - startAngle);
        const bool  on    = s.isEnabled();
        const bool  light = Col::isLight;
        const auto  acc   = on ? (s.isColourSpecified (juce::Slider::thumbColourId)
                                     ? s.findColour (juce::Slider::thumbColourId) : Col::accent)
                               : Col::textDim;
        const auto  k     = knobGeom (d);

        // --- phan tinh: lay tu bo dem ------------------------------------------
        const float scale = juce::jlimit (1.0f, 4.0f, g.getInternalContext().getPhysicalPixelScaleFactor());
        const juce::String key = juce::String (juce::roundToInt (d * 4.0f)) + "|" + juce::String (juce::roundToInt (scale * 100.0f))
                               + "|" + juce::String (Col::themeIndex) + "|" + juce::String (Col::bg.getARGB())
                               + "|" + juce::String (startAngle, 3) + "|" + juce::String (endAngle, 3);
        auto it = knobCache.find (key);
        if (it == knobCache.end())
        {
            if (knobCache.size() > 48) knobCache.clear();   // gioi han bo nho
            it = knobCache.emplace (key, renderKnobStatic (d, scale, startAngle, endAngle)).first;
        }
        g.drawImage (it->second, area, juce::RectanglePlacement::stretchToFit);

        // --- phan dong: vach sang ---------------------------------------------
        for (int i = 0; i < k.ticks; ++i)
        {
            const float t = (float) i / (float) (k.ticks - 1);
            if (t > pos + 1.0e-4f) break;
            drawKnobTick (g, c, k, i, startAngle, endAngle, acc.withAlpha (0.90f));
        }

        // --- cung gia tri + glow gia (net rong mo dan, khong blur) -----------
        if (pos > 0.002f)
        {
            juce::Path value;
            value.addCentredArc (c.x, c.y, k.ringR, k.ringR, 0.0f, startAngle, angle, true);
            if (on && ! light)
            {
                g.setColour (acc.withAlpha (0.10f));
                g.strokePath (value, juce::PathStrokeType (k.ringW * 3.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
                g.setColour (acc.withAlpha (0.18f));
                g.strokePath (value, juce::PathStrokeType (k.ringW * 2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            }
            g.setColour (acc);
            g.strokePath (value, juce::PathStrokeType (k.ringW, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        // --- cham chi thi + glow gia -------------------------------------------
        if (k.bodyR >= 4.0f)
        {
            const auto dp = c.getPointOnCircumference (k.faceR - k.dotR - juce::jmax (3.0f, k.faceR * 0.14f), angle);
            if (on)
            {
                g.setColour (acc.withAlpha (0.14f));
                g.fillEllipse (dp.x - k.dotR * 2.6f, dp.y - k.dotR * 2.6f, k.dotR * 5.2f, k.dotR * 5.2f);
                g.setColour (acc.withAlpha (0.28f));
                g.fillEllipse (dp.x - k.dotR * 1.7f, dp.y - k.dotR * 1.7f, k.dotR * 3.4f, k.dotR * 3.4f);
            }
            g.setColour (on ? acc.brighter (0.25f) : Col::textDim);
            g.fillEllipse (dp.x - k.dotR, dp.y - k.dotR, k.dotR * 2.0f, k.dotR * 2.0f);
        }
    }

    // Bo dem anh tinh cua num (chi dung tren message thread, noi LookAndFeel ve).
    mutable std::map<juce::String, juce::Image> knobCache;

    //=========================================================================
    //  FADER / THANH TRUOT - phang
    //=========================================================================
    void drawLinearSlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPos, float minPos, float maxPos,
                           juce::Slider::SliderStyle style, juce::Slider& s) override
    {
        if ((bool) s.getProperties().getWithDefault ("f3StudioFader", false))
        { livent::drawStudioFader (g, x, y, width, height, sliderPos, s); return; }
        if ((bool) s.getProperties().getWithDefault ("compactTrackVolume", false))
        { livent::drawCompactVolume (g, x, y, width, height, sliderPos, s, Col::bg, Col::text, Col::accent); return; }
        if (style != juce::Slider::LinearVertical && style != juce::Slider::LinearHorizontal)
        {
            juce::LookAndFeel_V4::drawLinearSlider (g, x, y, width, height,
                                                    sliderPos, minPos, maxPos, style, s);
            return;
        }

        const float groove   = 5.0f;
        const auto  fillCol  = s.isEnabled() ? Col::accent : Col::textDim;
        const bool  panStyle = (bool) s.getProperties().getWithDefault ("panStyle", false);

        if (style == juce::Slider::LinearVertical)
        {
            const float cx = (float) x + (float) width * 0.5f;
            const juce::Rectangle<float> tr (cx - groove * 0.5f, (float) y, groove, (float) height);

            g.setColour (Col::bg);
            g.fillRoundedRectangle (tr, groove * 0.5f);
            g.setColour (Col::line);
            g.drawRoundedRectangle (tr, groove * 0.5f, 1.0f);

            g.setColour (fillCol);
            g.fillRoundedRectangle (tr.withTop (juce::jlimit (tr.getY(), tr.getBottom(), sliderPos)),
                                    groove * 0.5f);

            if ((bool) s.getProperties().getWithDefault ("f2ChannelFader", false))
            {
                const juce::Rectangle<float> thumb (cx - 14.0f, sliderPos - 16.0f, 28.0f, 32.0f);
                g.setGradientFill (juce::ColourGradient (cub::panelSel.brighter (0.45f), cx, thumb.getY(), cub::panel.darker (0.2f), cx, thumb.getBottom(), false));
                g.fillRoundedRectangle (thumb, 3.0f);
                g.setColour (cub::edge); g.drawRoundedRectangle (thumb, 3.0f, 1.0f);
                g.setColour (juce::Colours::white); g.fillRect (thumb.withSizeKeepingCentre (21.0f, 2.0f));
                return;
            }
            const juce::Rectangle<float> thumb (cx - 9.0f, sliderPos - 5.0f, 18.0f, 10.0f);
            g.setColour (Col::text);
            g.fillRoundedRectangle (thumb, 3.0f);
            g.setColour (Col::bg);
            g.fillRect (thumb.withSizeKeepingCentre (10.0f, 1.2f));
        }
        else
        {
            const float cy = (float) y + (float) height * 0.5f;
            const juce::Rectangle<float> tr ((float) x, cy - groove * 0.5f, (float) width, groove);

            g.setColour (Col::bg);
            g.fillRoundedRectangle (tr, groove * 0.5f);
            g.setColour (Col::line);
            g.drawRoundedRectangle (tr, groove * 0.5f, 1.0f);

            g.setColour (fillCol);

            if (panStyle)
            {
                //  Pan to tu GIUA ra, khong tu mep trai
                const float centreX = tr.getCentreX();
                const float dist    = std::abs (sliderPos - centreX);

                if (dist > 2.0f)
                    g.fillRoundedRectangle (juce::jmin (centreX, sliderPos), tr.getY(),
                                            dist, groove, groove * 0.5f);

                g.setColour (Col::textDim);
                g.fillRect (centreX - 0.5f, cy - 6.0f, 1.0f, 12.0f);
            }
            else
            {
                g.fillRoundedRectangle (tr.withRight (juce::jlimit (tr.getX(), tr.getRight(), sliderPos)),
                                        groove * 0.5f);
            }

            const juce::Rectangle<float> thumb (sliderPos - 5.0f, cy - 9.0f, 10.0f, 18.0f);
            g.setColour (Col::text);
            g.fillRoundedRectangle (thumb, 3.0f);
            g.setColour (Col::bg);
            g.fillRect (thumb.withSizeKeepingCentre (1.2f, 10.0f));
        }
    }

    //=========================================================================
    //  HOP XO
    //=========================================================================
    void drawComboBox (juce::Graphics& g, int width, int height, bool,
                       int, int, int, int, juce::ComboBox& box) override
    {
        auto area = juce::Rectangle<float> (0, 0, (float) width, (float) height).reduced (0.5f);

        g.setColour (box.findColour (juce::ComboBox::backgroundColourId));
        g.fillRoundedRectangle (area, 6.0f);

        g.setColour (Col::line);
        g.drawRoundedRectangle (area, 6.0f, 1.0f);

        juce::Path p;
        const float cx = (float) width - 13.0f, cy = (float) height * 0.5f;
        p.startNewSubPath (cx - 4.0f, cy - 2.0f);
        p.lineTo (cx, cy + 2.5f);
        p.lineTo (cx + 4.0f, cy - 2.0f);

        g.setColour (Col::textDim);
        g.strokePath (p, juce::PathStrokeType (1.6f, juce::PathStrokeType::curved,
                                               juce::PathStrokeType::rounded));
    }

    //=========================================================================
    //  THANH MENU (Windows) - chu + mui ten xuong o MOI muc
    //=========================================================================
    juce::Font getMenuBarFont (juce::MenuBarComponent&, int, const juce::String&) override
    {
        return juce::Font (juce::FontOptions (15.0f));
    }

    int getMenuBarItemWidth (juce::MenuBarComponent& bar, int index, const juce::String& text) override
    {
        return juce::roundToInt (juce::GlyphArrangement::getStringWidth (getMenuBarFont (bar, index, text), text))
             + 32;
    }

    void drawMenuBarBackground (juce::Graphics& g, int width, int height,
                                bool, juce::MenuBarComponent&) override
    {
        g.fillAll (Col::panel);
        g.setColour (Col::line);
        g.fillRect (0, height - 1, width, 1);
    }

    void drawMenuBarItem (juce::Graphics& g, int width, int height, int index,
                          const juce::String& text, bool over, bool open, bool,
                          juce::MenuBarComponent& bar) override
    {
        auto r = juce::Rectangle<float> (0.0f, 0.0f, (float) width, (float) height).reduced (1.0f, 4.0f);

        if (over || open)
        {
            g.setColour (Col::raised);
            g.fillRoundedRectangle (r, 6.0f);
        }

        g.setColour (Col::text);
        g.setFont (getMenuBarFont (bar, index, text));
        g.drawText (text, r.withTrimmedLeft (10.0f).withTrimmedRight (20.0f),
                    juce::Justification::centredLeft, false);

        const float cx = r.getRight() - 12.0f, cy = r.getCentreY();
        juce::Path chevron;
        chevron.startNewSubPath (cx - 3.5f, cy - 1.5f);
        chevron.lineTo (cx, cy + 2.0f);
        chevron.lineTo (cx + 3.5f, cy - 1.5f);

        g.setColour (Col::textDim);
        g.strokePath (chevron, juce::PathStrokeType (1.4f, juce::PathStrokeType::curved,
                                                     juce::PathStrokeType::rounded));
    }

    //  V6.0: cua so khong thanh title (Windows) - vien mong 1px
    void drawResizableFrame (juce::Graphics& g, int w, int h, const juce::BorderSize<int>&) override
    {
        g.setColour (Col::line);
        g.drawRect (0, 0, w, h, 1);
    }

    void drawResizableWindowBorder (juce::Graphics& g, int w, int h,
                                    const juce::BorderSize<int>&, juce::ResizableWindow&) override
    {
        g.setColour (Col::line);
        g.drawRect (0, 0, w, h, 1);
    }

    void drawPopupMenuBackground (juce::Graphics& g, int width, int height) override
    {
        g.fillAll (Col::panel);
        g.setColour (Col::line);
        g.drawRect (0, 0, width, height, 1);
    }

    //=========================================================================
    //  HOP THOAI - giu chu "T" lam nen mo (MOC 52), chi doi sang mau phang
    //=========================================================================
    void drawAlertBox (juce::Graphics& g, juce::AlertWindow& alert,
                       const juce::Rectangle<int>& textArea,
                       juce::TextLayout& textLayout) override
    {
        g.fillAll (Col::panel);

        g.setColour (Col::line);
        g.drawRect (alert.getLocalBounds(), 1);

        const auto fullArea = alert.getLocalBounds();
        const auto type     = alert.getAlertType();

        const juce::Colour badge = type == juce::MessageBoxIconType::WarningIcon  ? Col::amber
                                 : type == juce::MessageBoxIconType::QuestionIcon ? Col::accent
                                                                                  : Col::green;

        g.setColour (badge.withAlpha (0.12f));
        g.setFont (juce::Font (juce::FontOptions ((float) fullArea.getHeight() * 0.85f).withStyle ("Bold")));
        g.drawText ("T", fullArea, juce::Justification::centred);

        textLayout.draw (g, textArea.toFloat());
    }
};

//=============================================================================
/*  MOC 79 cu: GlassLookAndFeel ve nut "kinh". Ban V6.0 bo kieu kinh - Bang
    dieu khien dung chung kieu phang voi ca app. Giu lai TEN lop de TonePanel,
    LaughBoard khong phai sua (chung van setLookAndFeel (&glassLook)).  */
class GlassLookAndFeel : public LiveNTLookAndFeel
{
};

//=============================================================================
//  DOI CHU DE LUC DANG CHAY
//=============================================================================
namespace Col
{
    /** Ap chu de NGAY (xem truoc), chua ghi file. Goi saveTheme() de luu. */
    inline void applyTheme (int index)
    {
        setPalette (index);
        LiveNTLookAndFeel::refreshAll();

        //  sendLookAndFeelChange: bao cho moi component biet mau da doi, de
        //  cai nao tu cache mau (TextEditor...) tu cap nhat lai.
        auto& desktop = juce::Desktop::getInstance();

        for (int i = desktop.getNumComponents(); --i >= 0;)
            if (auto* top = desktop.getComponent (i))
            {
                if (auto* rw = dynamic_cast<juce::ResizableWindow*> (top))
                    rw->setBackgroundColour (bg);

                top->sendLookAndFeelChange();
                top->repaint();
            }
    }

    inline void restoreSnapshot (const ThemeSnapshot& old)
    {
        galaxyEnabled = old.galaxy;
        livent::rack::setEnabled (old.rack);
        livent::rack::setStyle (old.style);   // 12w
        applyTheme (old.index);
    }
}
