# LiveNT V3 – sửa mức giảm ồn theo T-DeNoise Live

## Cách dùng

Gói dựa trên Source.zip mới nhất anh gửi (SHA-256
25fb3b8c55a496a27da86d23437d21aa07da0656e3b84d9a7f5e15f5d9f87d37).
Đã gồm sửa EQ Míc/nút đóng của V2, áp dụng được trực tiếp trên source đó hoặc
sau V2. Giữ bản sao dự án hiện tại, giải nén vào thư mục gốc, chép đè 6 file
trong Source rồi build lại với bộ thư viện/SDK đầy đủ. Không cần áp lại V1/V2.
Đây là mã nguồn, chưa phải EXE hay bộ cài đã chạy kiểm tra trên Windows.

## Nguyên nhân và phần sửa

- DAW đã nới nhận biết giọng: chỉ cần pitch tracker thấy cao độ rõ cũng bảo vệ
  tín hiệu. Tiếng ù tuần hoàn bị coi là giọng hát; mức 50–100 % gần như không
  còn khác nhau trong phép thử ù 150 Hz.
- Đưa điều kiện nhận giọng và phạm vi bảo vệ họa âm về cùng lõi T-DeNoise Live
  trong ZIP tham chiếu; bỏ lớp bảo vệ formant mở rộng thêm ở bản DAW.
- Sửa hệ số trộn: trước đây khi đạt 1, nhánh so sánh lại hạ một bước, làm hệ số
  dao động 1/1-step và lọt tiếng gốc. Nay giữ yên tại đích; khi đã vào lọc hoàn
  toàn thì xuất trực tiếp wet, không trộn dư dry.
- Giữ núm 0–100 %, ánh xạ mục tiêu 0–30 dB, cùng định dạng dự án/preset đang có.
  T-DeNoise VST còn có Reduction đến 40 dB và nhiều điều khiển khác; đây không
  phải bản tích hợp toàn bộ giao diện/chức năng của VST.
- Dòng trạng thái Giảm ồn báo rõ “INSERT đang tắt” khi công tắc INSERT tổng của
  MÍC đang bypass. Bật INSERT để nghe bộ giảm ồn trong DAW.
- Giữ khôi phục EQ Míc (Trầm/Ấm/Rõ lời/Sáng, Cắt ù/Nâng cao) và nút đóng tinh
  chỉnh của V2. Giữ các thuật toán/scanner khác từ source mới nhất anh gửi.

## Đo đối chiếu thuật toán

Cùng mẫu đầu vào, 48 kHz/stereo, block 128, Live, Adaptive bật, Sensitivity 0 dB,
Smoothing 50 %, Low-cut tắt, Output 0 dB. VST tham chiếu là lõi configure/process/
analyseFrame lấy trực tiếp từ T-DeNoise.zip; chỉ adapter JUCE/FFT, HPF off và
output unity được thay thế cho phép chạy riêng. Không chạy binary VST, editor,
licensing, state/profile persistence hoặc môi trường native Windows.

Ở núm 100 % (mục tiêu 30 dB), đo trong khoảng ổn định của tín hiệu tổng hợp:

| Tín hiệu thử | DAW trước sửa | DAW V3 | Lõi VST |
|---|---:|---:|---:|
| Xì trắng | 12,71 dB | 30,00 dB | 30,00 dB |
| Ù 150 Hz + ít xì | 0,55 dB | 30,00 dB | 30,00 dB |
| Ù 100/200 Hz + ít xì | 0,55 dB | 30,00 dB | 30,00 dB |
| Quạt + ù 50/150 Hz | 7,18 dB | 9,65 dB | 9,65 dB |

Bộ lọc bảo vệ giọng nên mức giảm thực tế phụ thuộc tín hiệu và nhận biết giọng;
không cam kết cắt đủ 30 dB mọi loại ồn hoặc trong lúc hát.

- 20 phép so sánh = 5 loại tín hiệu (gồm hát có vibrato + quạt) × 4 mức
  0/20/50/100 %. So waveform sau căn độ trễ và bỏ đoạn khởi động. Tất cả đạt
  ngưỡng sai lệch tương đối dưới -80 dB; trường hợp xấu nhất khoảng -145,30 dB.
- Hát tổng hợp + quạt: projection giọng so với giọng sạch khoảng -0,037 dB trong
  cửa sổ thử. Không suy ra mọi giọng thật hoặc mọi phòng đều được bảo toàn như vậy.
- Chạy C++17 với cảnh báo nghiêm ngặt, ASan + UBSan, không có lỗi được báo trong
  lần chạy hoàn tất. LeakSanitizer tắt do giới hạn môi trường.
- 45 kiểm tra callback/UI mô phỏng đạt, gồm EQ được giữ lại, Giảm ồn và trạng
  thái INSERT tắt. Không phải kiểm thử native Waves/Windows.
- Lần thử trước sửa điểm kết thúc hệ số mix đã thất bại phép so waveform. Sau
  sửa đã chạy lại đủ 20 trường hợp và đạt; không nới ngưỡng để làm test qua.

## Giới hạn cần giữ rõ

- Chưa build/chạy toàn bộ DAW vì đầu vào vẫn thiếu bộ JUCE đã vá, module CMake,
  SDK và bộ test/tài nguyên liên quan. Chưa xác nhận trên soundcard/ASIO thật.
- Ở trạng thái ổn định, lõi lọc khớp chế độ Live tham chiếu trong phép thử.
  VST có Learn Noise, Quality, Sensitivity, Low-cut, Listen Noise và lưu profile;
  các chức năng đó chưa được thêm vào núm đơn của DAW.
- Chính sách trễ/bypass của host còn khác VST: ở 0 % DAW bỏ qua DSP và đi thẳng;
  VST giữ dry có bù trễ. Lỗi căn trễ trong đoạn bật/tắt đã báo ở lần đánh giá
  trước chưa được giải quyết toàn bộ trong gói sửa mức giảm ổn định này. Không
  coi kết quả so steady-state là bảo đảm không click ở mọi lần bật/tắt.
- Chưa sửa các vấn đề Waves/probe được báo riêng. Đây chưa phải xác nhận toàn
  bộ DAW ổn định để phát hành.

## Thử trên máy anh sau build

1. Dùng đúng track MÍC, bật INSERT tổng; để 50–100 % và nghe lúc chưa hát.
2. Khi so với VST, dùng Live + Auto Track, Sensitivity 0, Smoothing 50, Output 0,
   Low-cut tắt; DAW 100 % tương ứng Reduction 30 dB. So cùng nguồn âm và cân mức.
3. Khi nghe qua DAW, kiểm tra Direct Monitor của soundcard: nếu vẫn nghe đường
   mic trực tiếp từ card, đường đó không qua bộ lọc của DAW.
4. Thử đoạn nghỉ, hát nhẹ, hát ngân và đổi mức giảm; kiểm tra lưu/mở lại dự án.

THAY_DOI.patch và MANIFEST.json dùng để đối chiếu thay đổi/hash.
KIEM_TRA chứa số liệu trước/sau và thông số phép so sánh.
