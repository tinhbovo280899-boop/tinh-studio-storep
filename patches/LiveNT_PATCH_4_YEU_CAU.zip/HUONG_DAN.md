# LiveNT – 4 yêu cầu chỉnh sửa

Áp dụng cho đúng bản Source.zip và 1_BUILD_7_NGAY.zip đã gửi trong cuộc trò chuyện này.
Đây là bản vá mã nguồn, chưa phải bộ cài hoặc file EXE.

## Cách dùng

1. Giữ một bản sao dự án gốc của anh.
2. Giải nén gói này vào thư mục gốc dự án LiveNT (cạnh CMakeLists.txt), chép đè
   8 file trong thư mục Source. Gói chỉ chứa file thay đổi; giữ các file còn lại.
3. Build lại bằng bộ công cụ Windows của dự án đầy đủ rồi thử các tình huống bên dưới.

## Thay đổi

- Chuột phải VANG: giữ ba thanh mức Send Vang dài / Vang ngắn / Delay và nút Về preset;
  bỏ nhóm KHÔNG GIAN có sẵn (độ rộng, pre-delay, né giọng, lệch L/R).
- Bỏ xử lý SpaceFx có sẵn khỏi đường audio và việc bật mặc định trên dự án mới.
  Thông số vang/delay chỉnh trong VST. Dự án cũ từng bật SpaceFx sẽ không còn
  chịu tác động của lớp xử lý này; tiếng có thể khác ở các thông số nói trên.
  Dữ liệu SpaceFx/comp cũ vẫn được đọc/ghi để giữ định dạng dự án và preset.
- Chuột phải MÍC: chỉ còn Giảm ồn 0–100 % (0 % = tắt). Bỏ bảng EQ/Auto-Tune
  nhanh khỏi popup này; vẫn chỉnh các plugin trực tiếp trong cửa sổ VST.
  Trong source đầu vào, comp có sẵn đã không còn chạy trong audio callback.
- Inspector F2: các track FX như VANG DÀI, VANG NGẮN, DELAY có mục Sends và
  nút thêm Send, cả bố cục thường và bảng tổng quan. F3 vốn đã hỗ trợ FX Sends.
  Giữ cơ chế chọn đích/chống nối vòng và giới hạn Send hiện có.
- Nút đóng app: nền đỏ thường trực, biểu tượng nguồn trắng; nhấn xuống đậm hơn.
  Áp dụng cho thanh tiêu đề tự vẽ và chế độ thu gọn. Không đổi hành động hỏi lưu.
- Cập nhật chỉ dẫn rê chuột và hướng dẫn trong app theo popup MÍC mới.

## File được sửa

- Source/GuideWindow.h
- Source/MainComponent.h
- Source/Mixer.cpp
- Source/Theme.h
- Source/TonePanel.h
- Source/Track.cpp
- Source/Track.h
- Source/maincomponent.cpp

## Đã kiểm tra

- Probe C++17 với -Wall -Wextra -Werror: PASS 55 assertions.
- Phạm vi: điều kiện hiện Send của ba bố cục Inspector; thân hàm vẽ nút đóng
  thường/thu gọn với API giao diện giả lập; RoutingGraph thật cho chuỗi
  MIC → VANG DÀI → VANG NGẮN → Master, solo và xử lý vòng nối.
- Rà đường xử lý audio: không còn gọi SpaceFx prepare/processPre/processPost;
  giữ VST inserts, EQ kênh, giảm ồn và định dạng state cũ.
- Chỉ 8 file trên khác bản ZIP đầu vào. Không sửa manifest, lockfile hay script build.
- Chưa build/chạy DAW hoàn chỉnh trên Windows/ASIO hoặc thử VST thật. Hai ZIP
  hiện thiếu ThirdParty/JUCE đã vá, cmake/LiveNTRequiredSources.cmake,
  Tools/tests và các SDK/tài nguyên phục vụ build/đóng gói. Không xem probe
  độc lập là kết quả chạy ứng dụng hoặc bằng chứng ổn định khi biểu diễn.

## Cần thử sau khi build trên Windows

- Chuột phải VANG: chỉ còn mức Send, không còn nhóm KHÔNG GIAN.
- Chuột phải MÍC: không cần có Manny EQ vẫn mở được Giảm ồn; chỉnh 0/50/100 %,
  lưu/mở lại dự án để xác nhận mức giảm ồn.
- F2 thường và tổng quan: VANG DÀI/VANG NGẮN thêm Send sang đích hợp lệ;
  chọn lại track/đóng mở F2 vẫn thấy. Không hiện đích tự gửi hoặc tạo vòng.
- F3: xác nhận Send đó hiện cùng mức/pre-fader/bật tắt; lưu/mở lại dự án.
- Nút đóng đỏ ngay khi chưa rê chuột, ở theme hiện dùng và giao diện thu gọn;
  bấm vẫn hỏi lưu dự án và Hủy vẫn giữ ứng dụng mở.
- Mở dự án cũ có bật SpaceFx: so lại tiếng và chỉnh pre-delay/width/ducking
  trong VST nếu cần. Kiểm tra thu/dừng/xuất và nghe các đường vang.

THAY_DOI.patch là diff để đối chiếu; MANIFEST.json có SHA-256 trước/sau của 8 file.
