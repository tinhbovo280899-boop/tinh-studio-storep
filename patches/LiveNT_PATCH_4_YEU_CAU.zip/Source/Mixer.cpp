#include "Mixer.h"
#include "TrackGrouping.h"
#include "FinalizeGate.h"
#include "ProjectValidation.h"
#include <thread>
#include "StabilityLog.h"
#include "OutputGuard.h"
#include "ChannelLatency.h"
#include "DeClick.h"
#include <initializer_list>

//=============================================================================
Mixer::Mixer()
{
    formatManager.registerBasicFormats();
    // 13/10: luong doc file nhac/clip uu tien CAO hon binh thuong (van thap hon luong audio realtime):
    // dem 4 giay chi huu ich neu luong nap kip khi may ban (luc mo VST, quet plugin, antivirus...).
    readThread.startThread (juce::Thread::Priority::high);
    recordDiskThread.startThread (juce::Thread::Priority::normal);   // MOC 72

    // Track Output tong - tao san, luon nam cuoi danh sach.
    // V5.2: KHONG tao san PK nua. PK la duong nghe phu, neu mac dinh nghe
    // AM THANH RA va cung ra mot cap loa thi hai duong cong nhau thanh +6 dB.
    // Ai can PK se chuot phai > Them track > PK.
    if (auto* out = addTrack (Track::Type::Output, livent::vn ("ÂM THANH RA")))
        out->setRole (Track::Role::MainOutput);

    // 07/10 _D: plugin ARA phat ban da chinh pho vao dung lane
    araManager = std::make_unique<livent::ara::Manager> (mixerLock, timeline);
    timeline.setExtraRenderer (araManager.get());
    if(juce::MessageManager::getInstanceWithoutCreating()!=nullptr)startTimerHz(20);
}

Mixer::~Mixer()
{
    stopTimer();
    /* V6.5: vo hieu callback delayed TRUOC khi bat dau thao timeline/track. */
    lifeToken.reset();

    // 07/10 _E: luong nen dang dong WAV dung disk thread -> cho xong truoc
    for (auto& job : finalizeJobs)
        job->done.wait (-1);
    finalizeJobs.clear();

    // 07/10 _D: huy plugin ARA truoc timeline (no doc file cua timeline)
    if (araManager != nullptr)
        araManager->clear();

    //  V6.2: dung CA timeline recorder truoc khi dung hai disk thread.
    //  Neu de ThreadedWriter con song ma recordDiskThread da chet thi WAV co
    //  the bi cat duoi hoac destructor treo luc thoat app.
    timeline.shutdown();
    masterRecorder.stop();
    recordDiskThread.stopThread (4000);

    readThread.stopThread (2000);

    const juce::ScopedLock sl (mixerLock);
    tracks.clear();
}

//=============================================================================
Track* Mixer::addTrack (Track::Type type, const juce::String& name)
{
    if (isOfflineExporting()) return nullptr;
    static const juce::Colour palette[] = {
        juce::Colour (0xff3fa9d8), juce::Colour (0xffd8963f),
        juce::Colour (0xff4ec96e), juce::Colour (0xffc85f9c),
        juce::Colour (0xffd8c93f), juce::Colour (0xff8a6fd8)
    };

    // Chi co MOT Output tong. Cac dau ra logic bo sung dung Type::OutputBus.
    if (type == Track::Type::Output && getOutputTrack() != nullptr)
        return nullptr;

    // MOC 28: cung chi duoc co dung mot track PK
    if (type == Track::Type::PK && getPkTrack() != nullptr)
        return nullptr;

    const bool isFixed = type == Track::Type::Output;

    //  MOC 51: mau rieng cho track cong vao - de phan biet tren ban tron
    const bool isInput = type == Track::Type::Input;

    auto* t = new Track (nextId++, type, name,
                         type == Track::Type::Output ? juce::Colour (0xff7d8894)
                       : type == Track::Type::PK     ? juce::Colour (0xffc85f9c)
                       : isInput                     ? juce::Colour (0xff5f8fc8)
                                                     : palette[tracks.size() % 6]);
    t->getInserts().setHostPlayHead (&hostPlayHead);
    t->getInserts().setAutoKeyPlayHead (&autoKeyPlayHead);
    t->onAudibilityChanged = [this] { audibilityChanged(); };

    // Mac dinh track thuong do vao Output tong. Rieng PK: 0 = chua nghe
    // track nao, de vua tao xong TUYET DOI khong cong them +6 dB vao loa.
    if (type == Track::Type::PK)
    {
        t->setOutputTargetId (0);
        t->setOutPairMask (0); // choose a destination before listening
    }
    else if (auto* out = getOutputTrack())
        t->setOutputTargetId (out->getId());

    // Configure silence before publishing the new track to the audio thread.
    // Setting this only after addTrack() returns could leak one raw mic block.
    if (type == Track::Type::Audio || type == Track::Type::Beat)
    {
        t->setSource (Track::Source::TrackTap);
        t->setInputTrackId (0);
    }
    if (type == Track::Type::OutputBus)
    {
        t->setOutPairMask (0);
        t->setOutputBusSourceId (-1);
    }

    if (isPrepared)
        t->prepare (currentSampleRate, currentBlockSize);

    {
        const juce::ScopedLock sl (mixerLock);

        /*  Output va PK luon nam CUOI danh sach cho de nhin. Track thuong
            duoc chen vao TRUOC chung.  */
        if (isFixed || type == Track::Type::OutputBus || getOutputTrack() == nullptr)
        {
            // Dau ra logic nam canh khu Vao/Ra, truoc PK cho de nhin.
            if (type == Track::Type::OutputBus)
            {
                int insertAt = tracks.size();
                for (int i = 0; i < tracks.size(); ++i)
                    if (tracks[i]->getType() == Track::Type::PK)
                    {
                        insertAt = i;
                        break;
                    }
                tracks.insert (insertAt, t);
            }
            else
            {
                tracks.add (t);
            }
        }
        else
        {
            int insertAt = tracks.size();

            for (int i = 0; i < tracks.size(); ++i)
                if (tracks[i]->getType() == Track::Type::Output
                    || tracks[i]->getType() == Track::Type::OutputBus
                    || (livent::grouping::category(type)==0 && tracks[i]->getType()==Track::Type::FxBus))
                {
                    insertAt = i;
                    break;
                }

            tracks.insert (insertAt, t);
        }
        prepareRoutingStorage();
    }

    return t;
}

void Mixer::removeTrack (int index)
{
    removeTrackInternal (index, false);
}

void Mixer::resetToDefaultTracks()
{
    if(!waitForPendingTakes())return;
    stopTransportOwnedMusicPlayback();
    // V6.2: Du an moi = timeline moi. Xoa playhead/clip/arm truoc khi tao lai
    // NHAC + MIC de khong mang take cua du an cu sang du an moi.
    araManager->clear();
    {const juce::ScopedLock sl(mixerLock);timeline.clear();}

    /*  ==========  MOC 35: DON SACH ROI DUNG LAI  ==========

        Phai co ham rieng, khong the goi removeTrack() trong vong lap duoc
        nua: tu Moc 35, NHAC / MIC / ba bus vang deu la track "khong xoa
        duoc", nen removeTrack() se tu choi. Vong lap "con track thi xoa"
        se chon dung mot track do lam nan nhan, xoa khong duoc, roi chon
        lai chinh no -- QUAY MAI KHONG DUNG, treo cung app.

        O day dung removeTrackInternal (force = true) de bo qua co bao ve.
        Chi ham nay duoc phep, vi day la luc CO Y don sach de lam du an moi.  */
    for (int i = getNumTracks(); --i >= 0;)
        if (auto* t = getTrack (i))
            if (t->getType() != Track::Type::Output)
                removeTrackInternal (i, true);

    createDefaultTracks();
}

void Mixer::clearProjectTracks()
{
    if(!waitForPendingTakes())return;
    stopTransportOwnedMusicPlayback();
    // Dong project thi dong luon playback/record va xoa metadata timeline.
    araManager->clear();
    {const juce::ScopedLock sl(mixerLock);timeline.clear();}

    // Giu duy nhat Output tong de engine/card van o trang thai hop le khi khong mo project.
    // Moi track noi dung, Input bus va OutputBus cua project deu duoc bo.
    for (int i = getNumTracks(); --i >= 0;)
    {
        auto* t = getTrack (i);
        if (t == nullptr)
            continue;

        if (t->getType() == Track::Type::Output)
            continue;

        removeTrackInternal (i, true);
    }

    if (auto* out = getOutputTrack())
    {
        out->setName (livent::vn ("ÂM THANH RA"));
        out->setRole (Track::Role::MainOutput);
        out->setOutPairMask (1u);
        out->setGainDb (0.0f);
        out->setMute (false);
    }

}

void Mixer::removeTrackInternal (int index, bool force)
{
    if (isOfflineExporting()) return;
    auto* t = getTrack (index);

    if (t == nullptr || t->getType() == Track::Type::Output)
        return;

    // MOC 35: NHAC / MIC / ba bus vang - chi bo qua khi don sach co y
    if (t->isFixed() && t->getType() != Track::Type::PK && ! force)
        return;

    const int removedId = t->getId();
    const auto removedUuid = t->getUuid();

    Track* toDelete = nullptr;

    {
        const juce::ScopedLock sl (mixerLock);
        timeline.removeTrack (removedUuid);
        toDelete = tracks.removeAndReturn (index);
        prepareRoutingStorage();

        // Track nao dang tro ra track vua xoa thi chuyen ve Output tong
        auto* out = getOutputTrack();

        for (auto* other : tracks)
        {
            if (other->getOutputTargetId() == removedId)
            {
                if (other->getType() == Track::Type::PK)
                    other->setOutputTargetId (0);
                else if (out != nullptr)
                    other->setOutputTargetId (out->getId());
            }
            if (other->getType() == Track::Type::OutputBus
                && other->getOutputBusSourceId() == removedId)
                other->setOutputBusSourceId (-1);
            if (other->getType() == Track::Type::OutputBus)
                other->removeOutputBusMixSource (removedId);

            // Go luon cac Send tro toi no
            for (int i = other->getNumSends(); --i >= 0;)
                if (other->getSend (i).targetId == removedId)
                    other->removeSend (i);
        }
    }

    syncAra();   // 07/10 _D: phien ARA cua track vua xoa duoc huy
    delete toDelete;
}

Track* Mixer::getTrack (int index) const
{
    return juce::isPositiveAndBelow (index, tracks.size()) ? tracks[index] : nullptr;
}

Track* Mixer::getTrackById (int id) const
{
    for (auto* t : tracks)
        if (t->getId() == id)
            return t;

    return nullptr;
}

Track* Mixer::getTrackByUuid (const juce::String& uuid) const
{
    if (uuid.isEmpty()) return nullptr;
    for (auto* t : tracks)
        if (t->getUuid() == uuid)
            return t;
    return nullptr;
}

Track* Mixer::getTrackByRole (Track::Role role) const
{
    if (role == Track::Role::None) return nullptr;
    for (auto* t : tracks)
        if (t->getRole() == role)
            return t;
    return nullptr;
}

int Mixer::getIndexOfId (int id) const
{
    for (int i = 0; i < tracks.size(); ++i)
        if (tracks[i]->getId() == id)
            return i;

    return -1;
}

Track* Mixer::getOutputTrack() const
{
    for (auto* t : tracks)
        if (t->getType() == Track::Type::Output)
            return t;

    return nullptr;
}

void Mixer::createDefaultTracks()
{
    setTempoBpm (120.0);
    /*  V4.5: du an moi co SAN hai bus dau vao logic, giong cach Cubase /
        Studio One cho nguoi dung mot diem bat dau ro rang:

            NHẠC VÀO  - Stereo In
            MÍC VÀO   - Mono In

        Day chi la BUS LOGIC. Nguoi dung van co the vao
        "Cài đặt đường âm thanh" de doi cong vat ly tuy soundcard.

        addInputTrack() dua bus moi len dau danh sach; tao MÍC truoc roi
        NHẠC sau de thu tu nhin thay tren mixer la NHẠC VÀO -> MÍC VÀO. */
    Track* micIn = addInputTrack (false);
    if (micIn != nullptr)
    {
        micIn->setName (livent::vn ("MÍC VÀO"));
        micIn->setRole (Track::Role::InputMic);
        micIn->setInputChannels (0, 0);
        micIn->setGainDb (0.0f);
    }

    Track* musicIn = addInputTrack (true);
    if (musicIn != nullptr)
    {
        musicIn->setName (livent::vn ("NHẠC VÀO"));
        musicIn->setRole (Track::Role::InputMusic);
        musicIn->setInputChannels (0, 1);
        musicIn->setGainDb (0.0f);
    }

    //-- NHAC dung truoc, roi moi toi MIC ------------------------------------
    if (auto* beat = addTrack (Track::Type::Beat, livent::vn ("NHẠC")))
    {
        beat->setRole (Track::Role::Music);
        beat->setSource (Track::Source::TrackTap);
        beat->setInputTrackId (musicIn != nullptr ? musicIn->getId() : 0);
        beat->setChannelMode (Track::Chan::Stereo);
        beat->setFixed (true);
        beat->setGainDb (0.0f);
    }

    Track* mic = addTrack (Track::Type::Audio, livent::vn ("MÍC"));

    if (mic != nullptr)
    {
        mic->setRole (Track::Role::Mic);
        mic->setSource (Track::Source::TrackTap);
        mic->setInputTrackId (micIn != nullptr ? micIn->getId() : 0);
        mic->setChannelMode (Track::Chan::Mono);
        mic->setFixed (true);
        mic->setGainDb (0.0f);
    }

    /*  MOC 35: ba bus hieu ung, deu noi san send tu MIC.

        Ba cai nay la bo do nghe cua mot buoi hat: vang dai cho cau ngan,
        vang ngan cho cau nhanh, delay cho cau cuoi. Tao san va noi san de
        anh chi viec nhet plugin vao, khong phai ngoi noi day moi lan lam du
        an moi.

        Muc send mo san -6 dB -- day vang ro hon nhung van con headroom. Anh keo lai o
        bang Inspector cua track MIC.  */
    struct FxDefault { const char* name; Track::Role role; };
    const FxDefault fxDefaults[] = {
        { "VANG DÀI", Track::Role::ReverbLong },
        { "VANG NGẮN", Track::Role::ReverbShort },
        { "DELAY", Track::Role::Delay }
    };

    for (const auto& def : fxDefaults)
        if (auto* fx = addTrack (Track::Type::FxBus, livent::vn (def.name)))
        {
            fx->setRole (def.role);
            fx->setFixed (true);
            fx->setGainDb (0.0f);

            if (mic != nullptr)
                mic->addSend (fx->getId());
        }
}

//=============================================================================
Track* Mixer::addInputTrack (bool stereo)
{
    /*  Dat ten tu dong: MONO IN, MONO IN 2, MONO IN 3...

        Dem so track CUNG KIEU dang co roi cong mot, chu khong dem tong so
        track cong vao: anh co the co 1 mono va 2 stereo, luc do cai mono
        tiep theo phai la "MONO IN 2" chu khong phai "MONO IN 4".  */
    const juce::String base = stereo ? "STEREO IN" : "MONO IN";

    int sameKind = 0;

    for (auto* t : tracks)
        if (t->getType() == Track::Type::Input
            && t->getName().startsWithIgnoreCase (base))
            ++sameKind;

    const auto name = sameKind == 0 ? base
                                    : base + " " + juce::String (sameKind + 1);

    auto* t = addTrack (Track::Type::Input, name);

    if (t == nullptr)
        return nullptr;

    t->setChannelMode (stereo ? Track::Chan::Stereo : Track::Chan::Mono);
    t->setInputChannels (0, stereo ? 1 : 0);
    t->setGainDb (0.0f);

    /*  Dua len DAU danh sach. Track cong vao la diem bat dau cua moi duong
        tin hieu, xep tren cung thi doc bang tron tu trai sang la doc dung
        chieu tin hieu chay - giong het Cubase.  */
    const int at = tracks.indexOf (t);

    if (at > 0)
    {
        const juce::ScopedLock sl (mixerLock);
        tracks.move (at, 0);
    }

    return t;
}

juce::Array<Track*> Mixer::getInputTracks() const
{
    juce::Array<Track*> result;

    for (auto* t : tracks)
        if (t->getType() == Track::Type::Input)
            result.add (t);

    return result;
}

Track* Mixer::addOutputBus (const juce::String& preferredName)
{
    int n = 1;
    for (auto* t : tracks)
        if (t->getType() == Track::Type::OutputBus)
            ++n;

    auto name = preferredName.trim();
    if (name.isEmpty())
        name = "DAU RA " + juce::String (n);

    auto* t = addTrack (Track::Type::OutputBus, name);
    if (t != nullptr)
    {
        t->setChannelMode (Track::Chan::Stereo);
        t->setOutPairMask (0u);
        t->setGainDb (0.0f);
        t->setOutputBusSourceId (-1); // choose a source before duplicating audio
    }
    return t;
}

juce::Array<Track*> Mixer::getOutputBuses() const
{
    juce::Array<Track*> result;
    for (auto* t : tracks)
        if (t->getType() == Track::Type::Output || t->getType() == Track::Type::OutputBus)
            result.add (t);
    return result;
}

juce::Array<Track*> Mixer::getPossibleOutputBusSources() const
{
    juce::Array<Track*> result;
    for (auto* t : tracks)
        if (isOutputBusSourceType (t->getType())) result.add (t);
    return result;
}

bool Mixer::setOutputBusSource (int busId, int sourceId)
{
    const juce::ScopedLock sl (mixerLock);
    auto* bus = getTrackById (busId);
    if (bus == nullptr || bus->getType() != Track::Type::OutputBus || sourceId < -1)
        return false;
    if (sourceId > 0)
    {
        auto* source = getTrackById (sourceId);
        if (source == nullptr || ! isOutputBusSourceType (source->getType())) return false;
    }
    bus->setOutputBusSourceId (sourceId);
    return true;
}

bool Mixer::setOutputBusMixSources (int busId, const juce::Array<int>& sources)
{
    const juce::ScopedLock sl (mixerLock);
    auto* bus = getTrackById (busId);
    if (bus == nullptr || bus->getType() != Track::Type::OutputBus
        || sources.size() > Track::maxOutputMixSources) return false;
    for (int id : sources)
    {
        auto* t = getTrackById (id);
        // A mix of individual sources excludes the master itself: selecting
        // master plus its component tracks would sum the same sound twice.
        if (t == nullptr || ! isOutputBusSourceType (t->getType())
            || t->getType() == Track::Type::Output) return false;
    }
    bus->setOutputBusMixSources (sources);
    return true;
}

int Mixer::indexOfTrack (const Track* t) const
{
    for (int i = 0; i < tracks.size(); ++i)
        if (tracks[i] == t)
            return i;

    return -1;
}

void Mixer::moveTrack (int fromIndex, int toIndex)
{
    if (isOfflineExporting()) return;
    if (! juce::isPositiveAndBelow (fromIndex, tracks.size())
        || ! juce::isPositiveAndBelow (toIndex, tracks.size())
        || fromIndex == toIndex)
        return;

    if(livent::grouping::category(tracks[fromIndex]->getType())!=livent::grouping::category(tracks[toIndex]->getType()))return;

    /*  Khoa lai vi luong am thanh duyet mang nay moi khoi tinh. Doi cho giua
        chung thi no co the duyet phai mot phan tu dang di doi.  */
    const juce::ScopedLock sl (mixerLock);
    auto previousPlan = std::move (latencyPlan);
    const int previousLatency = graphLatencySamples.load();
    tracks.move (fromIndex, toIndex);
    // Publish index-based routing and PDC together before releasing the render lock.
    bool prepared = refreshLatencyCompensation();
    if (prepared && previousPlan && latencyPlan)
    {
        // Concurrent plugin/routing changes may require the new plan's clean history.
        try { latencyPlan->inheritReorderedHistory (*previousPlan); }
        catch (...) {} // Candidate DSP/PDC remains valid if optional history transfer cannot allocate.
    }
    if (! prepared)
    {
        tracks.move (toIndex, fromIndex);
        latencyPlan = std::move (previousPlan);
        graphLatencySamples.store (previousLatency);
    }
}

Track* Mixer::getTrackByName (const juce::String& name) const
{
    for (auto* t : tracks)
        if (t->getName().equalsIgnoreCase (name.trim()))
            return t;

    return nullptr;
}

Track* Mixer::getPkTrack() const
{
    for (auto* t : tracks)
        if (t->getType() == Track::Type::PK)
            return t;

    return nullptr;
}

void Mixer::migrateLegacyDirectInputs()
{
    // Project cu co the de Audio/Beat doc thang inL/inR. Tao/reuse mot bus
    // dau vao logic co cung mapping, sau do track chi tro toi bus do.
    juce::Array<Track*> toMigrate;
    for (auto* t : tracks)
        if ((t->getType() == Track::Type::Audio || t->getType() == Track::Type::Beat)
            && t->getSource() == Track::Source::HardwareInput)
            toMigrate.add (t);

    for (auto* t : toMigrate)
    {
        Track* bus = nullptr;
        for (auto* in : tracks)
        {
            if (in->getType() != Track::Type::Input)
                continue;
            if (in->getChannelMode() == t->getChannelMode()
                && in->getInputLeft() == t->getInputLeft()
                && in->getInputRight() == t->getInputRight())
            {
                bus = in;
                break;
            }
        }

        if (bus == nullptr)
        {
            bus = addInputTrack (t->getChannelMode() == Track::Chan::Stereo);
            if (bus != nullptr)
            {
                bus->setName (t->getName() + " - DAU VAO");
                bus->setInputChannels (t->getInputLeft(), t->getInputRight());
            }
        }

        if (bus != nullptr)
        {
            t->setSource (Track::Source::TrackTap);
            t->setInputTrackId (bus->getId());
        }
    }
}

juce::Array<Track*> Mixer::getPossiblePkSources() const
{
    juce::Array<Track*> result;

    /*  MOC 28: PK nghe trom duoc MOI track -- ke ca AM THANH RA.

        Chi tru chinh no: PK nghe chinh PK la tin hieu chay vong tron, moi
        vong lai cong them mot lan chinh no -> to dan len den vo loa. Day
        khong phai gia thiet xa voi, chi can mot lan bam nham.  */
    for (auto* t : tracks)
        if (t->getType() != Track::Type::PK)
            result.add (t);

    return result;
}

juce::Array<Track*> Mixer::getPossibleOutputTargets (const Track* forTrack) const
{
    juce::Array<Track*> result;

    for (auto* t : tracks)
    {
        if (t == forTrack || wouldCreateRoutingCycle(forTrack,t))
            continue;

        /*  KHONG liet ke PK o day. PK khong phai cho de do tieng VAO -- no
            tu di lay tieng tu track ma no nghe trom. Cho track khac do vao
            PK thi vua thua vua de gay vong tron.  */
        if (t->getType() == Track::Type::Output || t->getType() == Track::Type::OutputBus || t->getType() == Track::Type::Group)
            result.add (t);
    }

    return result;
}

juce::Array<Track*> Mixer::getPossibleSendTargets (const Track* forTrack) const
{
    juce::Array<Track*> result;

    for (auto* t : tracks)
    {
        /*  Khong cho track tu gui vao chinh no - tin hieu chay vong tron, moi
            vong lai cong them mot lan chinh no, to dan den vo loa.  */
        if (t == forTrack || wouldCreateRoutingCycle(forTrack,t))
            continue;

        if (t->getType() == Track::Type::FxBus
            || t->getType() == Track::Type::Group
            || t->getType() == Track::Type::Output)
            result.add (t);
    }

    return result;
}

juce::Array<Track*> Mixer::getPossibleSidechainTargets (const Track* forTrack) const
{
    juce::Array<Track*> result;

    for (auto* t : tracks)
    {
        if (t == nullptr || t == forTrack || wouldCreateRoutingCycle(forTrack,t))
            continue;

        /*  PK la duong nghe trom, khong phai noi dat insert xu ly chinh.
            Input bus chay truoc cac track noi dung; cho sidechain vao day tu
            mot track chay sau se thanh tre mot block va rat kho hieu khi live.

            Cac loai duoi day deu la dich hop le cho sidechain va bao phu hai
            ca dung anh can nhat:
              MIC  -> plugin tren NHAC
              MIC  -> plugin tren FX VANG/DELAY. */
        const auto ty = t->getType();

        if (ty == Track::Type::Audio
            || ty == Track::Type::Beat
            || ty == Track::Type::Group
            || ty == Track::Type::FxBus
            || ty == Track::Type::Output
            || ty == Track::Type::OutputBus)
            result.add (t);
    }

    return result;
}

juce::Array<Track*> Mixer::getFxBuses() const
{
    juce::Array<Track*> result;

    for (auto* t : tracks)
        if (t->getType() == Track::Type::FxBus)
            result.add (t);

    return result;
}

juce::String Mixer::transferInsertPlugin (Track& source, int sourceSlot, Track& dest, int destSlot,
                                           bool replace, PluginChain* stagedCopy)
{
    if (! juce::isPositiveAndBelow (sourceSlot, PluginChain::maxSlots)
        || ! juce::isPositiveAndBelow (destSlot, PluginChain::maxSlots)) return "Invalid insert slot";
    if (&source == &dest && sourceSlot == destSlot) return {};
    {
        const juce::ScopedLock sl (mixerLock);
        if (getTrackById (source.getId()) != &source || getTrackById (dest.getId()) != &dest)
            return "Track no longer exists";
        auto& origin = source.getInserts();
        auto& target = dest.getInserts();
        if (origin.isSlotEmpty (sourceSlot)) return "Source insert is empty";
        if (! replace && ! target.isSlotEmpty (destSlot)) return "Destination insert is occupied";
        auto& incoming = stagedCopy != nullptr ? *stagedCopy : origin;
        const int incomingSlot = stagedCopy != nullptr ? 0 : sourceSlot;
        if (incoming.isSlotEmpty (incomingSlot)) return "Copied insert is empty";
        if (! incoming.exchangeSlotWith (incomingSlot, target, destSlot))
            return "Audio setup changed; try moving the insert again";
        for (auto* track : tracks)
            track->moveSidechainSendTarget (source.getId(), sourceSlot, dest.getId(), destSlot,
                                            stagedCopy == nullptr);
    }
    // Retire the replaced plugin on the control thread, after releasing the mixer lock.
    // For copies it is owned by the private staging chain and cleaned up by its owner.
    if (stagedCopy == nullptr) source.getInserts().removePlugin (sourceSlot);
    return {};
}

void Mixer::moveInsertPlugin (Track& targetTrack, int fromSlot, int toSlot)
{
    if (fromSlot < 0 || toSlot < 0 || fromSlot == toSlot)
        return;

    /* V6.6.5 SIDECHAIN MOVE HOTFIX:
       Audio callback cung giu mixerLock trong routeToTarget(), noi Sidechain
       Send ghi vao PluginChain::scBuffer. Lay khoa nay trong luc DOI CHO
       dam bao khong co addToSidechain() dang ghi vao hai buffer bi swap.

       Thao tac keo-tha insert rat hiem va swap con tro/flag rat nhanh. Neu no
       trung dung audio callback, callback sau dung safety-net lastGoodOutput
       thay vi doc nua-cu/nua-moi. */
    const juce::ScopedLock sl (mixerLock);

    if (getTrackById (targetTrack.getId()) != &targetTrack)
        return;

    auto& chain = targetTrack.getInserts();
    if (! juce::isPositiveAndBelow (fromSlot, chain.getNumPlugins())
        || ! juce::isPositiveAndBelow (toSlot, chain.getNumPlugins()))
        return;

    chain.movePlugin (fromSlot, toSlot);

    // Send SC tu BAT KY track nao tro vao hai slot nay deu phai doi theo.
    for (auto* sourceTrack : tracks)
        sourceTrack->swapSidechainSendTargetSlots (targetTrack.getId(), fromSlot, toSlot);
}

//=============================================================================
//  Luu / nap du an
//=============================================================================
juce::File Mixer::getProjectFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("project.xml");
}

std::unique_ptr<juce::XmlElement> Mixer::getState (bool includePluginState) const
{
    auto xml = std::make_unique<juce::XmlElement> ("LIVENT_PROJECT");
    xml->setAttribute ("version", 1);
    xml->setAttribute ("tempoBpm", getTempoBpm());

    for (auto* t : tracks)
        xml->addChildElement (t->getState (includePluginState).release());

    // V6.2: Source/Clip/Playlist metadata nam ngoai TRACK audio routing.
    // Track UUID la khoa noi hai ben, nen keo sap xep/doi id khong lam mat clip.
    xml->addChildElement (timeline.getStateXml().release());

    // 07/10 _D: phan chinh pho ARA (chi khi luu that - archive co the nang)
    if (includePluginState && araManager != nullptr)
        if (auto ara = araManager->createStateXml(); ara != nullptr && ara->getNumChildElements() > 0)
            xml->addChildElement (ara.release());

    return xml;
}

bool Mixer::setState (const juce::XmlElement& xml, bool deferPluginLoading)
{
    if (livent::project::validate (xml).isNotEmpty() || ! waitForPendingTakes()) return false;
    // Build tracks before detaching the current project. Deferred/missing VST
    // slots keep their saved payload; media absence does not erase the project.
    juce::OwnedArray<Track> staged;
    int maxId = 0;
    try
    {
        for (auto* e : xml.getChildWithTagNameIterator ("TRACK"))
        {
            const int  id   = e->getIntAttribute ("id");
            const auto type = (Track::Type) e->getIntAttribute ("type");

            auto* t = staged.add (new Track (id, type, e->getStringAttribute ("name", "Track"),
                                            juce::Colour ((juce::uint32) e->getIntAttribute ("colour"))));

            t->getInserts().setHostPlayHead (&hostPlayHead);
            t->getInserts().setAutoKeyPlayHead (&autoKeyPlayHead);

            t->setState (*e, &formatManager, &readThread, deferPluginLoading);
            t->onAudibilityChanged = [this] { audibilityChanged(); };

            if (isPrepared)
                t->prepare (currentSampleRate, currentBlockSize);

            maxId = juce::jmax (maxId, id);
        }
    }
    catch (...) { return false; } // staged owns cleanup; current tracks still live.

    stopTransportOwnedMusicPlayback();
    araManager->clear();
    {
        const juce::ScopedLock sl (mixerLock);
        timeline.clear();
        tracks.swapWith (staged);
        prepareRoutingStorage();
    }
    staged.clear(); // Destroy old VSTs outside mixerLock.
    setTempoBpm (xml.getDoubleAttribute ("tempoBpm", 120.0));
    nextId = maxId + 1;

    // Phong khi file hong: van phai co track ra tong
    if (getOutputTrack() == nullptr)
        addTrack (Track::Type::Output, livent::vn ("ÂM THANH RA"));

    // V5.2: du an khong co PK thi giu nguyen khong co PK.

    migrateLegacyDirectInputs();
    migrateLegacySystemRoles();

    /*  VA DINH TUYEN GAY.

        File .NT cu co the co track tro "outTo" toi mot id da bi xoa, hoac
        khong co thuoc tinh outTo (= 0). Luc do getTrackById() tra nullptr,
        track van chay plugin, dong ho van nhay, NHUNG khong ra loa - nguoi
        dung tuong plugin hong. Keo het chung ve Output tong cho chac.  */
    if (auto* out = getOutputTrack())
    {
        const juce::ScopedLock sl (mixerLock);

        for (auto* t : tracks)
            if (t->getType() != Track::Type::Output
                && t->getType() != Track::Type::OutputBus
                && t->getType() != Track::Type::PK
                && getTrackById (t->getOutputTargetId()) == nullptr)
                t->setOutputTargetId (out->getId());
    }

    /* V6.2: load sau khi role/uuid legacy da duoc sua. Timeline lane bam vao
       UUID, khong vao vi tri dong hay track id. Project cu khong co khoi nay
       thi timeline rong, mo binh thuong. */
    {
        /*  13/10: doc XML + mo file + nap peak NGOAI khoa; chi doi con tro trong khoa (applyState).
            Ban 11j lam tat ca trong mixerLock -> mo du an lon la nhac dang phat bi dut hang tram ms.  */
        auto parsed = timeline.parseStateXml (xml.getChildByName ("TRACK_TIMELINE"));
        if (parsed.valid && ! timeline.applyParsedState (parsed, mixerLock))
            livent::stabilityLog ("PROJECT", "Khong nap duoc timeline: so lieu clip khong hop le");
    }

    // 07/10 _D: giu archive ARA; phien duoc tao (nap Melodyne...) khi
    // MainComponent cho phep - sau khi hang doi VST cua du an nap xong.
    araManager->restoreStateXml (xml.getChildByName ("ARA_SESSIONS"));
    return true;
}


void Mixer::migrateLegacySystemRoles()
{
    /* Project truoc V5.7 chua co role/uuid. Gan role theo dau hieu chac chan
       nhat, KHONG phu thuoc vao vi tri hang. Ten khach tu doi van duoc giu. */
    if (auto* out = getOutputTrack())
    {
        if (out->getRole() == Track::Role::None)
            out->setRole (Track::Role::MainOutput);
        out->setFixed (true);
    }

    auto assignUniqueFixed = [this] (Track::Type type, Track::Role role)
    {
        if (getTrackByRole (role) != nullptr) return;
        Track* candidate = nullptr;
        for (auto* t : tracks)
        {
            if (t->getType() != type || ! t->isFixed()) continue;
            if (candidate != nullptr) return; // khong doan neu co hon mot ung vien
            candidate = t;
        }
        if (candidate != nullptr) candidate->setRole (role);
    };

    assignUniqueFixed (Track::Type::Beat,  Track::Role::Music);
    assignUniqueFixed (Track::Type::Audio, Track::Role::Mic);

    /*  V6.5.1 - PROJECT RAT CU KHONG CO CA role LAN fixed.

        Ban migrate cu chi tim NHAC/MIC neu track con co fixed=1. Project tu
        truoc Moc 35 khong co thuoc tinh fixed nen Track::setState() mac dinh
        false; ket qua hai track van nhin thay ten NHAC/MIC nhung role=None.
        RecordingTimeline chi hien nut ARM khi role la Music/Mic -> nut cham do
        bien mat va bam THU luon bao "chua bat cham do".

        Fallback nay chi gan khi CHUA co role he thong, va doi chieu ca TYPE +
        TEN rat dac trung. Vi vay khong bien mot track nguoi dung binh thuong
        thanh track he thong chi vi no tinh co chua mot chu ngan. */
    auto assignLegacyByName = [this] (Track::Type type, Track::Role role,
                                      std::initializer_list<juce::String> names)
    {
        if (getTrackByRole (role) != nullptr)
            return;

        Track* candidate = nullptr;
        for (auto* t : tracks)
        {
            if (t == nullptr || t->getRole() != Track::Role::None || t->getType() != type)
                continue;

            const auto n = t->getName().trim().toLowerCase();
            bool matched = false;
            for (const auto& wanted : names)
                if (n == wanted.toLowerCase())
                {
                    matched = true;
                    break;
                }

            if (! matched)
                continue;

            if (candidate != nullptr)
                return; // co hon mot track trung ten -> khong doan

            candidate = t;
        }

        if (candidate != nullptr)
        {
            candidate->setRole (role);
            candidate->setFixed (true);
        }
    };

    assignLegacyByName (Track::Type::Beat, Track::Role::Music,
                        { livent::vn ("nhạc"), "nhac", "music", "beat" });
    assignLegacyByName (Track::Type::Audio, Track::Role::Mic,
                        { "mic", livent::vn ("míc") });

    for (auto* t : tracks)
    {
        if (t->getRole() != Track::Role::None) continue;
        const auto n = t->getName().toLowerCase();
        if (t->getType() == Track::Type::FxBus)
        {
            if (n.contains ("vang dai") || n.contains (livent::vn ("vang dài"))) { t->setRole (Track::Role::ReverbLong);  t->setFixed (true); }
            else if (n.contains ("vang ngan") || n.contains (livent::vn ("vang ngắn"))) { t->setRole (Track::Role::ReverbShort); t->setFixed (true); }
            else if (n.contains ("delay")) { t->setRole (Track::Role::Delay); t->setFixed (true); }
        }
    }

    if (auto* music = getTrackByRole (Track::Role::Music))
        if (auto* in = getTrackById (music->getInputTrackId()))
            if (in->getType() == Track::Type::Input && in->getRole() == Track::Role::None)
                in->setRole (Track::Role::InputMusic);

    if (auto* mic = getTrackByRole (Track::Role::Mic))
        if (auto* in = getTrackById (mic->getInputTrackId()))
            if (in->getType() == Track::Type::Input && in->getRole() == Track::Role::None)
                in->setRole (Track::Role::InputMic);
}

//=============================================================================
void Mixer::prepare (double sampleRate, int blockSize)
{
    if (isOfflineExporting())
    {
        offlineRequestedRate.store (sampleRate);
        offlineRequestedBlock.store (blockSize);
        offlineDeviceChanged.store (true);
        return;
    }
    currentSampleRate = sampleRate;
    currentBlockSize  = blockSize;
    exportGainScratch.setSize (2, juce::jmax (32, blockSize));

    masterRecorder.prepare (sampleRate);   // MOC 72: de tinh dung so giay da ghi
    sfxPlayer.prepare (sampleRate);        // MOC 82: de doc dung toc do file mp3

    // V6.6.6 AUDIO CORE: cap san fallback output, khong resize tren callback.
    lastGoodOutput.setSize (fallbackOutputChannels, juce::jmax (64, blockSize),
                            false, true, true);
    lastGoodOutput.clear();
    lastGoodOutputSamples = 0;
    contentionFallbackGain = 1.0f;
    softStopLeft = 0; softStopTotal = 1; expectedNextBlockStart = -1; pkOutGain = 0.0f;
    softStopRequested.store (false);
    softStopHold.store (false);

    const juce::ScopedLock sl (mixerLock);

    prepareRoutingStorage();
    timeline.prepare (sampleRate, blockSize);   // V6.2
    masterMeter.clear();
    loudnessMeter.prepare (sampleRate);
    monitorOutput.prepare (sampleRate);

    for (auto* t : tracks)
        t->prepare (sampleRate, blockSize);

    araManager->prepare (sampleRate, blockSize);   // 07/10 _D

    isPrepared = true;
    refreshLatencyCompensation();
}

//=============================================================================
//  V6.2: THU TRACK DRY + TIMELINE
//=============================================================================
void Mixer::setLiveMode (bool on)
{
    if (on == liveMode.load()) return;
    if (on)
    {
        if (isTimelineRecording()) return;   // noi goi (MainComponent) da chan + bao nguoi dung
        // Bo cham do (chuyen sang Live = khong thu duoc nua).
        const juce::ScopedLock sl (mixerLock);
        for (auto* t : tracks)
            if (timeline.isArmed (*t))
                timeline.setArmed (*t, false);
    }
    liveMode.store (on);
}

void Mixer::setTrackRecordArmed (Track& track, bool on)
{
    if (on && liveMode.load()) return;   // 14/10: Che do Live - khong cho thu
    if (isOfflineExporting()) return;
    /* V6.5 SAFETY: setArmed() co the tao Lane moi va push_back vao vector.
       Audio thread duyet cung vector nay ben trong processBlock() khi dang
       giu mixerLock. Khong khoa o day co the reallocate vector ngay duoi chan
       audio thread -> use-after-free/crash luc bam ARM lan dau. */
    const juce::ScopedLock sl (mixerLock);
    timeline.setArmed (track, on);
}

void Mixer::setTrackRecordToNewLane (Track& track, bool on)
{
    if (isOfflineExporting()) return;
    const juce::ScopedLock sl (mixerLock);   // co the tao Lane moi (giong setTrackRecordArmed)
    timeline.setRecordToNewLane (track, on);
}

juce::String Mixer::startTimelineRecording()
{
    if (liveMode.load())
        return livent::vn ("Đang ở Chế độ Live nên đã tắt tính năng thu âm. Vào Cài đặt > Âm thanh, tắt \"Chế độ Live\" để thu.");
    refreshLatencyCompensation();
    if (isOfflineExporting() || realtimeExportSourcesOnly.load())
        return livent::vn ("Hãy chờ xuất xong trước khi thu.");
    /*  07/10 _E (gop y 1): viec DIA (tao thu muc, mo WAV, bo ghi) lam NGOAI
        khoa mixer -> audio thread khong phai doi, bam THU khong khung tieng.
        Trong khoa chi con gan con tro + doi trang thai. Danh sach track chi
        doi tren message thread (chinh luong nay) nen doc khong can khoa.  */
    // Vua DUNG xong da THU lai: chot ban truoc len truoc (giu thu tu "Lan N")
    if(!waitForPendingTakes())return livent::vn("Bản thu trước đang chốt. Chờ vài giây rồi bấm Thu lại.");

    juce::String error;
    juce::Array<Track*> all;
    for (auto* t : tracks)
        all.add (t);

    /*  14/10 LANE KIEU A: vung boi den luc bam Thu = chi vung do duoc thay tren hang COMP (cho phep thu som / thu thua);
        ca lan thu van nam nguyen trong Lane. Khong boi den -> ca lan thu tam thay COMP, "Ghep cau" dau tien tra phan thua.  */
    const bool hadSelection = timelineUi.hasRange();
    auto prepared = timeline.prepareRecording (all, hadSelection ? timelineUi.rangeStart : -1.0,
                                                    hadSelection ? timelineUi.rangeEnd   : -1.0);
    error = prepared.error;

    if (error.isEmpty() && ! prepared.items.empty())
    {
        bool active = false;
        {
            const juce::ScopedLock sl (mixerLock);
            active = timeline.activateRecording (prepared);
        }
        if (active)
        {
            timeline.finishActivation (prepared);
            recordUsedSelection = hadSelection;
        }
        else
            prepared.discard();
    }

    // Bat dau THU that bi tu choi (vd chua ARM): dung phat timeline (nhu
    // ban cu), file NHAC do transport mo cung phai dung theo.
    if (error.isNotEmpty())
    {
        if (timeline.isPlaying())
            timeline.stopPlayback();
        stopTransportOwnedMusicPlayback();
    }
    return error;
}

void Mixer::setTempoBpm (double bpm)
{
    if (! std::isfinite (bpm)) return;
    bpm = juce::jlimit (20.0, 400.0, bpm);
    tempoBpm.store (bpm);
    hostPlayHead.setTempo (bpm);
    araManager->setTempoBpm (bpm);
}

void Mixer::startTimelinePlayback()
{
    if (isOfflineExporting()) return;
    if (timeline.isPlaying()) return;
    // 07/10 _E: dang THU ma bam PHAT -> chot ban thu o nen (khong dong WAV
    // trong khoa audio nhu truoc), roi phat tiep tu cho dang dung.
    if (timeline.isRecording())
        stopTimelineTransport();

    /*  11g A1: nap san bo doc clip tai cho sap phat TRUOC khi lay khoa mixer (cho toi da
        200 ms tren luong giao dien; audio van chay binh thuong trong luc cho). Cung quy
        tac "het bai thi phat lai tu 0" nhu TrackTimeline::startPlayback().  */
    {
        double from = timeline.getPositionSeconds();
        const double total = timeline.getTotalLengthSeconds();
        if (total > 0.0 && from >= total - 0.001) from = 0.0;
        timeline.warmClipsForPlayback (from, 200);
    }

    /*  13/10: dung bang bu tre NGOAI khoa. Ban 11j goi refreshLatencyCompensation() ben trong mixerLock
        (cap phat + tinh lai ca do thi) -> bam Phat luc dang nghe nhac la audio thread bi chan, nhac "tach".
        Ham nay tu lay/tha khoa trong tich tac.  */
    refreshLatencyCompensation();

    const juce::ScopedLock sl (mixerLock);
    softStopHold.store (false, std::memory_order_release);

    // Thanh transport phai PHAT duoc ca khi chua co clip timeline.
    // Neu NHAC dang dung file (khong phai tin hieu vao card), khoi dong
    // dung reader co san; khong khoi tao them engine/VST hay file thu.
    if (timeline.getTotalLengthSeconds() <= 0.0 && ! timeline.isRecording()
        && ! timeline.isPlaying() && ! musicPlaybackStartedByTransport)
        if (auto* music = getTrackByRole (Track::Role::Music))
            if (music->getSource() == Track::Source::AudioFile
                && music->getLengthSeconds() > 0.0 && ! music->isPlaying())
            {
                if (timeline.getPositionSeconds() >= music->getLengthSeconds() - 0.001)
                    timeline.setPositionSeconds (0.0);
                music->setPlayPosition (timeline.getPositionSeconds());
                musicPlaybackStartSeconds = music->getPositionSeconds();
                music->startPlayback();
                musicPlaybackStartedByTransport = music->isPlaying();
            }
    timeline.startPlayback();
}

void Mixer::stopTransportOwnedMusicPlayback (bool returnToStart)
{
    if (! musicPlaybackStartedByTransport)
        return;

    musicPlaybackStartedByTransport = false;
    if (auto* music = getTrackByRole (Track::Role::Music))
    {
        music->stopPlayback();
        // User Stop restores the music reader too, keeping it aligned with
        // the timeline's return point; project cleanup keeps the old reset.
        music->setPlayPosition (returnToStart ? musicPlaybackStartSeconds : 0.0);
    }
}

void Mixer::stopTimelineTransport()
{
    if (isOfflineExporting()) return;
    /* Detach captures under a short lock. Closing the WAV and building peaks
       happen after releasing it. Keep the operation synchronous so a Save or
       project switch immediately after Stop cannot lose the newly made clip. */
    if (timeline.isRecording())
    {
        RecordingTimelineEngine::StoppedTake take;
        {
            const juce::ScopedLock sl (mixerLock);
            take = timeline.detachRecordingForFinalization();
        }

        if (take.captures.empty())
        {
            stopTransportOwnedMusicPlayback();
            return;
        }

        /*  07/10 _E (gop y 2): dong WAV + dung song o LUONG NEN. Giao dien
            khong dung nua. LUU / dong du an goi waitForPendingTakes() de
            van chac chan co doan vua thu trong file .NT.  */
        auto job = std::make_shared<FinalizeJob>();
        job->take = std::move (take);
        finalizeJobs.push_back (job);

        std::weak_ptr<int> alive = lifeToken;
        std::thread ([job, alive, this]
        {
            job->finished.reserve (job->take.captures.size());
            for (auto& item : job->take.captures)
            {
                try
                {
                    auto segments=item.capture->finishSegments();
                    if(segments.empty()&&(item.capture->getRecordedSeconds()>0||item.capture->getDroppedSamples()>0))job->failed.store(true,std::memory_order_relaxed);
                    RecordingTimelineEngine::FinishedCapture finishedCapture { item.trackUuid, segments.empty()?nullptr:segments.front(), item.capture->getFile(), {} };
                    if(segments.size()>1)finishedCapture.more.assign(segments.begin()+1,segments.end());
                    job->finished.push_back (std::move(finishedCapture));
                }
                catch (...)
                {
                    job->failed.store(true,std::memory_order_relaxed);
                    // A failed peak/cache operation must not delete the source WAV.
                    livent::stabilityLog ("RECORD finalize", "Khong the chot mot take; kiem tra file WAV goc");
                }
            }
            job->isDone.store (true);
            job->done.signal();

            juce::MessageManager::callAsync ([alive, this]
            {
                if (! alive.expired())
                    commitReadyTakes();
            });
        }).detach();

        stopTransportOwnedMusicPlayback();
        return;
    }

    bool returnToStart = false;
    bool softStop = false;
    {
        const juce::ScopedLock sl (mixerLock);
        returnToStart = timeline.hasPlaybackReturnPoint()
                     && ! realtimeExportSourcesOnly.load();
        /*  13/10: DUNG MEM. Luong audio ha am luong ~8 ms roi moi dung timeline, tranh cat ngang giua
            tieng hat/nhac (tieng "bup" khi bam Space). Xuat file thoi gian thuc / chua co card chay thi
            dung ngay nhu cu.  */
        softStop = isPrepared && currentSampleRate > 0.0 && timeline.isPlaying()
                   && ! realtimeExportSourcesOnly.load();
        if (softStop)
        {
            softStopReturnToStart.store (returnToStart, std::memory_order_release);
            softStopRequested.store (true, std::memory_order_release);
        }
        else
            timeline.stopPlayback (returnToStart);
    }
    if (softStop)
    {
        // Cho luong audio hoan tat (khong giu mixerLock). Toi da ~80 ms; card khong chay thi dung cung.
        for (int i = 0; i < 80 && softStopRequested.load (std::memory_order_acquire); ++i)
            juce::Thread::sleep (1);
        if (softStopRequested.exchange (false, std::memory_order_acq_rel))
        {
            const juce::ScopedLock sl (mixerLock);
            timeline.stopPlayback (returnToStart);
        }
    }
    // AudioTransportSource::stop waits for its callback: keep mixerLock free.
    stopTransportOwnedMusicPlayback (returnToStart);
    softStopHold.store (false, std::memory_order_release);
}

void Mixer::commitReadyTakes()
{
    // Giu dung thu tu: ban thu truoc len truoc
    bool any = false;juce::String warnings;
    while (! finalizeJobs.empty() && finalizeJobs.front()->isDone.load())
    {
        auto job = finalizeJobs.front();
        finalizeJobs.erase (finalizeJobs.begin());
        timeline.commitFinishedTake (job->finished, job->take.generation, mixerLock);
        for(const auto& stopped:job->take.captures)
        {
            bool committed=false;
            for(const auto& finished:job->finished)if(finished.trackUuid==stopped.trackUuid&&finished.data)committed=true;
            if(!committed&&job->failed.load(std::memory_order_acquire))
            {failedFinalizationFiles.addIfNotAlreadyThere(stopped.capture->getFile().getFullPathName());warnings<<livent::vn("Không chốt được WAV: ")<<stopped.capture->getFile().getFileName()<<"\n";}
            else if(stopped.capture->getDroppedSamples()>0)
                warnings<<stopped.capture->getFile().getFileName()<<": "<<juce::String(stopped.capture->getDroppedSamples())<<livent::vn(" mẫu bị bỏ; đã chèn khoảng lặng đúng vị trí.\n");
        }
        any = true;
    }
    if(warnings.isNotEmpty()&&onRecordingWarning)onRecordingWarning(warnings);
    if (any)
    {
        syncAra();
        if (recordUsedSelection)
        {
            // Vung boi den chi dung cho MOT lan thu; lan sau thu lai ca bai khong bi gioi han nham.
            recordUsedSelection = false;
            timelineUi.clearRange();
            timeline.touch();
        }
        if (onTakeCommitted)
            onTakeCommitted();
    }
}

bool Mixer::waitForPendingTakes(int timeoutMs)
{
    const auto jobs=std::vector<std::shared_ptr<FinalizeJob>>(finalizeJobs);
    const bool complete=livent::waitForFinalizers(jobs,timeoutMs);
    commitReadyTakes();
    return complete&&finalizeJobs.empty()&&failedFinalizationFiles.isEmpty();
}

juce::StringArray Mixer::getTracksHearingLiveOverClips() const
{
    // Cung dieu kien voi livent::monitoring::decide(): Audio + khong phai NHAC + Loa bat -> nghe mic, clip im.
    juce::StringArray names;
    for (auto* t : tracks)
        if (t->getType() == Track::Type::Audio && t->getRole() != Track::Role::Music
            && t->isMonitorOn() && timeline.laneHasClips (t->getUuid()))
            names.add (t->getName());
    return names;
}

void Mixer::toggleTimelinePlayback()
{
    // Space/DUNG khi dang play: duong nhanh khong doi mixerLock.
    if (timeline.isPlaying())
    {
        stopTimelineTransport();
        return;
    }

    if (timeline.isRecording())
    {
        stopTimelineTransport();
        return;
    }

    startTimelinePlayback();
}

void Mixer::setTimelinePositionSeconds (double seconds)
{
    if (isOfflineExporting()) return;
    const juce::ScopedLock sl (mixerLock);
    timeline.setPositionSeconds (seconds);
    if (latencyPlan) latencyPlan->reset();
    lastGoodOutputSamples = 0;
    if (musicPlaybackStartedByTransport)
        if (auto* music = getTrackByRole (Track::Role::Music))
            music->setPlayPosition (timeline.getPositionSeconds());
}

bool Mixer::deleteTimelineClip (Track& track, const juce::String& clipId)
{
    if (isOfflineExporting()) return false;
    // 07/10: di qua edit() -> Hoan tac duoc. Khong xoa WAV goc.
    juce::ignoreUnused (track);
    if (timeline.isRecording())
        return false;
    const bool ok = timeline.edit ([&clipId] (TimelineState& s)
                                   { return livent::tledit::removeClips (s, juce::StringArray (clipId)); },
                                   mixerLock);
    if (ok) syncAra();
    return ok;
}

bool Mixer::addTimelineClip (Track& track, std::shared_ptr<TimelineClipData> clip, double startSeconds)
{
    if (isOfflineExporting()) return false;
    if (clip == nullptr || ! timeline.isRecordableTrack (track))
        return false;
    clip->timelineStartSeconds = juce::jmax (0.0, startSeconds);
    const auto uuid = track.getUuid();
    const bool ok = timeline.edit ([&] (TimelineState& s) { return livent::tledit::addClip (s, uuid, clip); },
                                   mixerLock);
    if (ok) syncAra();
    return ok;
}

std::vector<TimelinePendingTake> Mixer::findInterruptedTakes() const
{
    // Chi lay take cua track con ton tai trong du an nay.
    auto all = timeline.findPendingTakes();
    std::vector<TimelinePendingTake> out;
    for (auto& t : all)
        for (auto* tr : tracks)
            if (tr != nullptr && tr->getUuid() == t.trackUuid && timeline.isRecordableTrack (*tr))
            {
                out.push_back (t);
                break;
            }
    return out;
}

//=============================================================================
//  MOC 72: THU AM DON GIAN
//=============================================================================
bool Mixer::startMasterRecording (const juce::File& file, double maxSeconds, int bitsPerSample)
{
    if (isOfflineExporting()) return false;
    //  Track AM THANH RA luon co san tu luc Mixer duoc tao (xem constructor),
    //  nhung van kiem tra cho chac - phong truong hop du an bi xoa nham.
    auto* out = getOutputTrack();

    if (out == nullptr)
        return false;

    /*  MOC 77 FIX (crash nghiem trong): TRUOC DAY dung
        out->getBuffer().getNumChannels() de bao MasterRecorder biet "mo file
        may kenh" - nhung buffer cua MOI track (kho khong rieng gi Output)
        luon co san PluginChain::maxChannels = 16 kenh (danh du cho sidechain
        cua plugin, khong phai so kenh THAT SU dang dung).

        Ket qua: file WAV duoc TAO RA voi 16 kenh, nhung o Mixer::processBlock
        (noi thuc su GHI du lieu) chi bao gio dua dung 2 con tro (kenh trai/
        phai) vao mang "channels[2]" tren stack - ThreadedWriter/format
        writer ben trong lai nghi co 16 kenh nen co doc tiep channels[2] toi
        channels[15], TUC LA DOC QUA KHOI MANG CHI CO 2 PHAN TU TREN STACK -
        doc phai rac, coi rac do la dia chi bo nho that, roi thu doc du lieu
        tu dia chi rac do -> SAP UNG DUNG NGAY LAP TUC. Dung y het loi anh
        gap ("bam nut THU la vang app").

        Sua: LUON dung dung 2 (stereo) - khop chinh xac voi so con tro
        MasterRecorder::write() thuc su nhan duoc moi khoi (xem
        Mixer::processBlock), khong con doc lech nua.  */
    const juce::int64 maxSamples = maxSeconds > 0.0 && currentSampleRate > 0.0
                                     ? (juce::int64) std::llround (maxSeconds * currentSampleRate)
                                     : -1;
    return masterRecorder.start (file, currentSampleRate, 2, maxSamples, bitsPerSample);
}

void Mixer::stopMasterRecording()
{
    masterRecorder.stop();
}

void Mixer::release()
{
    if (isOfflineExporting())
    {
        offlineRequestedRate.store (0.0);
        offlineDeviceChanged.store (true);
        return;
    }
    // Flush outside mixerLock. Device release closes the take even if the next
    // device happens to have the same sample rate (e.g. USB hotplug).
    masterRecorder.stop();
    const juce::ScopedLock sl (mixerLock);

    timeline.release();   // V6.2: dong capture/reader truoc khi track buffer mat
    masterMeter.clear();
    araManager->releaseResources();   // 07/10 _D

    for (auto* t : tracks)
        t->release();

    isPrepared = false;
}

//=============================================================================
//  Dinh tuyen mot track sang dich cua no + cac Send
//=============================================================================

void Mixer::releaseRetiredPlan()
{
    // Luong dieu khien. Plan cu chi duoc huy khi block tron da xong (hoac khong con plan moi).
    std::unique_ptr<livent::LatencyPlan> dead;
    {
        const juce::ScopedLock lock (mixerLock);
        if (retiredPlan && (! latencyPlan || latencyPlan->xfadeFrom == nullptr))
            dead = std::move (retiredPlan);
    }
}

void Mixer::prepareRoutingStorage()
{
    latencyPlan.reset();retiredPlan.reset();graphLatencySamples.store(0);
    routingGraph.prepare(tracks.size());routeSnapshots.resize((size_t)tracks.size());
    for(auto& route:routeSnapshots)route.mixSources.resize(Track::maxOutputMixSources);
    routingDirty=true;routingCycle.store(false,std::memory_order_relaxed);
}

int Mixer::routingIndex(int id) const noexcept
{
    for(int i=0;i<(int)routeSnapshots.size();++i)if(routeSnapshots[(size_t)i].id==id)return i;
    return -1;
}

bool Mixer::routingAudible(const Track& t) const noexcept
{
    return routingGraph.audible(routingIndex(t.getId()));
}

void Mixer::snapshotRouting()
{
    bool soloDirty=routingDirty;
    for(int i=0;i<tracks.size();++i)
    {
        auto& t=*tracks[i];auto& r=routeSnapshots[(size_t)i];
        const int input=t.getSource()==Track::Source::TrackTap?t.getInputTrackId():0;
        const int main=t.getOutputTargetId(),source=t.getOutputBusSourceId();
        const bool sends=t.areAllSendsOn();
        if(r.id!=t.getId()||r.mainId!=main||r.inputId!=input||r.busSource!=source||r.allSends!=sends)routingDirty=true;
        r.id=t.getId();r.mainId=main;r.inputId=input;r.busSource=source;r.allSends=sends;
        const bool solo=t.isSoloed();if(r.solo!=solo)soloDirty=true;r.solo=solo;
        const int count=t.getNumSends();if(r.sendCount!=count)routingDirty=true;r.sendCount=count;
        for(int k=0;k<count;++k)
        {
            const auto send=t.getSendRT(k);const auto& previous=r.sends[(size_t)k];
            if(send.targetId!=previous.targetId||send.targetSlot!=previous.targetSlot||send.enabled!=previous.enabled)routingDirty=true;
            auto* destination=getTrackById(send.targetId);
            const bool active=send.targetSlot<0 || (destination!=nullptr && destination->areAllInsertsOn()
                && destination->getInserts().isSidechainOn(send.targetSlot));
            if(r.sidechainActive[(size_t)k]!=active)routingDirty=true;
            r.sidechainActive[(size_t)k]=active;r.sends[(size_t)k]=send;
        }
        const int mix=t.getOutputBusMixCount();if(r.mixCount!=mix)routingDirty=true;r.mixCount=mix;
        for(int k=0;k<mix;++k){const int id=t.getOutputBusMixSource(k);if(r.mixSources[(size_t)k]!=id)routingDirty=true;r.mixSources[(size_t)k]=id;}
    }
    if(routingDirty)
    {
        routingGraph.clearEdges();
        for(int i=0;i<tracks.size();++i)
        {
            const auto type=tracks[i]->getType();const auto& r=routeSnapshots[(size_t)i];routingGraph.setId(i,r.id);
            const int input=routingIndex(r.inputId);
            if(input>=0&&tracks[input]->getType()==Track::Type::Input)routingGraph.addEdge(input,i,livent::RoutingGraph::Tap);
            if(type==Track::Type::Audio||type==Track::Type::Beat||type==Track::Type::Group||type==Track::Type::FxBus)
            {
                const int main=routingIndex(r.mainId);
                if(main>=0)
                {
                    const auto targetType=tracks[main]->getType();
                    if(targetType==Track::Type::Group||targetType==Track::Type::Output||targetType==Track::Type::OutputBus)
                        routingGraph.addEdge(i,main);
                }
                if(r.allSends)for(int k=0;k<r.sendCount;++k)if(r.sends[(size_t)k].enabled&&r.sidechainActive[(size_t)k])
                {
                    const int target=routingIndex(r.sends[(size_t)k].targetId);
                    if(target>=0&&tracks[target]->getType()!=Track::Type::Input&&tracks[target]->getType()!=Track::Type::PK)
                        routingGraph.addEdge(i,target,r.sends[(size_t)k].targetSlot>=0 ? livent::RoutingGraph::Sidechain : livent::RoutingGraph::Audio);
                }
            }
            if(type==Track::Type::PK)routingGraph.addEdge(routingIndex(r.mainId),i,livent::RoutingGraph::Tap);
            if(type==Track::Type::OutputBus)
            {
                if(r.busSource==-2)for(int k=0;k<r.mixCount;++k)routingGraph.addEdge(routingIndex(r.mixSources[(size_t)k]),i,livent::RoutingGraph::Tap);
                else if(r.busSource>0)routingGraph.addEdge(routingIndex(r.busSource),i,livent::RoutingGraph::Tap);
            }
        }
        routingCycle.store(routingGraph.rebuildOrder(),std::memory_order_relaxed);
        soloDirty=true;routingDirty=false;
    }
    if(soloDirty)
    {
        for(int i=0;i<tracks.size();++i)routingGraph.setSolo(i,routeSnapshots[(size_t)i].solo,tracks[i]->getType()==Track::Type::Input,tracks[i]->getType()==Track::Type::FxBus);
        // PK is a post-mix tap: solo its source rather than muting its source.
        for(int i=0;i<tracks.size();++i)if(tracks[i]->getType()==Track::Type::PK&&routeSnapshots[(size_t)i].solo)
        {const int source=routingIndex(routeSnapshots[(size_t)i].mainId);if(source>=0)routingGraph.setSolo(source,true,tracks[source]->getType()==Track::Type::Input,tracks[source]->getType()==Track::Type::FxBus);}
        routingGraph.updateSolo();
    }
}

bool Mixer::wouldCreateRoutingCycle(const Track* from,const Track* to) const
{
    if(!from||!to)return false;
    if(from==to)return true;
    // This is the menu/control path, so temporary traversal storage is allowed.
    std::vector<int> pending {to->getId()};std::vector<int> seen;
    while(!pending.empty())
    {
        const int id=pending.back();pending.pop_back();if(id==from->getId())return true;
        if(std::find(seen.begin(),seen.end(),id)!=seen.end())continue;
        seen.push_back(id);
        const auto* track=getTrackById(id);if(!track)continue;
        const auto type=track->getType();
        if(type==Track::Type::Audio||type==Track::Type::Beat||type==Track::Type::Group||type==Track::Type::FxBus)
        {
            pending.push_back(track->getOutputTargetId());
            if(track->areAllSendsOn())for(int i=0;i<track->getNumSends();++i){const auto send=track->getSend(i);if(send.enabled)pending.push_back(send.targetId);}
        }
        if(type==Track::Type::Input)for(auto* next:tracks)if(next->getSource()==Track::Source::TrackTap&&next->getInputTrackId()==id)pending.push_back(next->getId());
        for(auto* bus:tracks)if(bus->getType()==Track::Type::OutputBus)
        {
            if(bus->getOutputBusSourceId()==id)pending.push_back(bus->getId());
            if(bus->getOutputBusSourceId()==-2)for(int i=0;i<bus->getOutputBusMixCount();++i)if(bus->getOutputBusMixSource(i)==id)pending.push_back(bus->getId());
        }
    }
    return false;
}

/*  D03: mute/solo/monitor doi -> nhac nguoi hat nghe duoc co the doi -> do bu take dang thu doi.
    Cap nhat NGAY tren luong giao dien (cung luc voi cu bam) de moc bu tre dat sat luc nhac doi that;
    luong khac thi timer 20 Hz (ben duoi) lam sau, tre toi da ~50 ms.  */
void Mixer::audibilityChanged()
{
    if (! isPrepared || isOfflineExporting() || realtimeExportSourcesOnly.load()) return;
    auto* manager = juce::MessageManager::getInstanceWithoutCreating();
    if (manager == nullptr || ! manager->isThisTheMessageThread()) return;
    try { refreshLatencyCompensation(); }
    catch (...) { livent::stabilityLog ("PDC", "Khong cap duoc bo dem bu tre khi doi Mute/Solo; timer se thu lai"); }
}

void Mixer::timerCallback()
{
    if (! liveMode.load())
        timeline.persistCompensationMarks();
    // OUTPUT GUARD: track nao co plugin vua nha NaN/Inf thi ghi log ten track (toi da 1 lan / 5 giay).
    if (pluginGuardPending.exchange (false, std::memory_order_relaxed))
    {
        juce::String bad;
        {
            // Chi lay khoa khi THAT SU co su co (hiem) -> khong lam audio thread truot khoa moi 50 ms.
            const juce::ScopedLock sl (mixerLock);
            for (auto* t : tracks)
                if (const int n = t->takeNonFiniteBlocks(); n > 0)
                    bad += (bad.isEmpty() ? "" : ", ") + t->getName() + " (" + juce::String (n) + " khoi)";
        }
        if (bad.isNotEmpty())
        {
            const auto now = juce::Time::getMillisecondCounter();
            if (now - lastPluginGuardLogMs > 5000)
            {
                lastPluginGuardLogMs = now;
                livent::stabilityLog ("PLUGIN NAN/INF", "plugin tren track da nha NaN/Inf, khoi bi xoa: " + bad);
            }
        }
    }
    // OUTPUT GUARD: bao mot dong log (toi da 1 lan / 5 giay) neu vua chan NaN/Inf.
    if (const int hits = outputGuardHits.exchange (0, std::memory_order_relaxed); hits > 0)
    {
        const auto now = juce::Time::getMillisecondCounter();
        if (now - lastGuardLogMs > 5000)
        {
            lastGuardLogMs = now;
            livent::stabilityLog ("OUTPUT GUARD", juce::String (hits) + " mau NaN/Inf da bi chan truoc khi ra card");
        }
    }
    if (retiredPlan) releaseRetiredPlan();   // 11g B2
    if(isOfflineExporting()||realtimeExportSourcesOnly.load())return;
    try {refreshLatencyCompensation();}
    catch (...) {livent::stabilityLog("PDC", "Khong cap duoc bo dem bu tre; giu ke hoach truoc");}
}

juce::String Mixer::getLatencyCompensationError() const
{
    const juce::ScopedLock lock (mixerLock);
    return latencyCompensationError;
}

bool Mixer::refreshLatencyCompensation()
{
    if(!isPrepared || currentBlockSize<=0)return true;
    try
    {
    // Plugin lifetime/latency storage changes are coordinated by PluginChain on the control thread.
    for(auto* t:tracks)t->getInserts().refreshLatencyStorage();
    // Goi khi da giu mixerLock. Do bu ban thu = tre tap + (che do live) tre nhac nghe duoc.
    auto applyCaptureLatency=[this](const livent::LatencyPlan& plan)
    {
        /*  13/10 BU TRE THU DUNG VOI TAI NGHE:
              bu = tre card (vao + ra) + tre tap (day plugin track Input) + TRE NHAC NGUOI HAT NGHE THAT.
            Tre nhac nghe that = (mau) tu luc timeline doc nhac toi luc ra loa, gom ca SoundShifter tren NHAC,
            plugin tren AM THANH RA / Group sau diem nhac nhap vao, va can cong ra - o CA HAI che do
            (live: nhac chay tu do; bu day du: nhac bi keo cho bang duong dai nhat). Khong co nhac nghe duoc:
            che do bu day du van tinh tre cong ra chinh (nghe lai ban cu), che do live = 0.
            Tre nay CHI de dat clip cho dung - khong them mot mau tre nao vao duong nguoi hat nghe giong minh.
            14/10: o che do LIVE, neu nhac KHONG nghe duoc qua duong chinh (VD tat Group nhung nhac van vang qua Send sang
            FX bus) thi heardMusicValid = false -> truoc day bu = 0 va ban thu lech dung bang tre plugin tren nhac.
            Truong hop do giu NGUYEN cach tinh cua 11j: bu = plan.musicLatency (nhac nghe duoc qua bat ky duong nao).  */
        const int heardMusic=plan.heardMusicValid ? plan.heardMusicDelay
                                                  : (plan.lowLatency ? plan.musicLatency : plan.primaryOutputDelay);
        // Moc "nhac nghe tre bao lau" dung cho CA bu thu lan phat lai (live): duong chinh, hoac so cua 11j neu chi nghe qua Send->FX.
        const bool liveRef=plan.lowLatency&&(plan.heardMusicValid||plan.musicLatency>0);
        const int liveRefDelay=plan.heardMusicValid ? plan.heardMusicDelay : plan.musicLatency;
        for(int i=0;i<tracks.size();++i)
        {
            const int source=plan.tapSource[(size_t)i];
            const int shift=plan.freeRunning[(size_t)i] ? 0 : heardMusic;
            timeline.setCaptureTapLatency(tracks[i]->getUuid(),(source>=0?plan.outputArrival[(size_t)source]:0)+shift);

            /*  PHAT LAI: o che do live moi duong co tre rieng (day plugin track, own delay...), nhac chay tu do.
                Doan da thu (clip) la file nen khong can "cho" - chi can doc SOM/MUON di dung bang chenh lech:
                tre nghe cua track nay tru tre nghe cua nhac. Che do bu day du da can bang delay -> 0.  */
            int playShift=0;
            if(liveRef&&i<(int)plan.sourceHeard.size()
               &&(i>=(int)plan.freeSeed.size()||plan.freeSeed[(size_t)i]==0)&&plan.sourceHeard[(size_t)i]>=0)
                playShift=juce::jlimit(-96000,96000,plan.sourceHeard[(size_t)i]-liveRefDelay);
            timeline.setPlaybackShift(tracks[i]->getUuid(),playShift);
        }
        timeline.updateLiveCompensation();   // D03: take dang thu doi bu tre theo vi tri mau
    };
    /*  11j: KHOA MIXER CHI GIU TRONG TICH TAC.
        Ban cu giu mixerLock suot luc dung lai ca bang bu tre (cap phat vector, duyet routing, so sanh)
        20 lan/giay ke ca khi khong co gi doi. Thinh thoang trung dung luc luong am thanh can vao ->
        "Khoa mixer truot" -> lap lai block truoc = tieng "tach" khi hat.
        Gio: (1) trong khoa chi CHEP NHANH so lieu vao bo nho da cap san; (2) dung bang NGOAI khoa;
        (3) vao khoa lai mot tich tac de so sanh / thay bang. Cach tinh giu NGUYEN nhu cu.  */
    struct PlanTrack
    {
        int id=0; Track::Role role{}; Track::Type type{};
        Track::Source source{};
        bool muted=false,monitor=false,extraSound=false,allInsertsOn=true;
        float gainDb=0.0f,sendTrimDb=0.0f; juce::uint32 outMask=0;
        std::array<int,PluginChain::maxSlots> slots {};
    };
    std::vector<PlanTrack> pt; std::vector<RouteSnapshot> rs; livent::RoutingGraph rg;
    for(int attempt=0;;++attempt)
    {
    // Cap phat TRUOC khi vao khoa (kich thuoc doc khong khoa chi la goi y; lech thi vector tu lon them).
    {
        const int hint=juce::jmax(0,tracks.size());
        pt.resize((size_t)hint);rs.resize((size_t)hint);
        for(auto& r:rs)r.mixSources.reserve((size_t)Track::maxOutputMixSources);
        if(rg.size()!=hint)rg.prepare(hint);
    }
    auto next=std::make_unique<livent::LatencyPlan>();std::vector<int> order;
    int n=0;bool lowLatency=false,primaryOnlySink=false;int block=0;
    {
        const juce::ScopedLock lock(mixerLock);snapshotRouting();
        n=tracks.size();block=currentBlockSize;
        pt.resize((size_t)n);
        rs=routeSnapshots;rg=routingGraph;
        /*  Che do HAT LIVE chi ap dung khi dang choi/thu binh thuong. Khi XUAT FILE
            (offline hoac thoi gian thuc) luon bu tre DAY DU de nhac va giong khop
            tung mau, khong phu thuoc cong tac nay.  */
        lowLatency=lowLatencyLive.load() && !isOfflineExporting() && !realtimeExportSourcesOnly.load();
        primaryOnlySink=lowLatency||isOfflineExporting()||realtimeExportSourcesOnly.load();   // F04/F05
        for(int i=0;i<n;++i)
        {
            auto& t=*tracks[i];auto& p=pt[(size_t)i];
            p.id=t.getId();p.role=t.getRole();p.type=t.getType();p.source=t.getSource();p.muted=t.isMuted();p.monitor=t.isMonitorOn();
            p.extraSound=timeline.laneHasClips(t.getUuid())||t.getInserts().hasAnyInstrumentPlugin();
            p.allInsertsOn=t.areAllInsertsOn();p.gainDb=t.getGainDb();p.sendTrimDb=t.getSendTrimDb();p.outMask=t.getOutPairMask();
            p.slots=t.getInserts().getSlotLatencies();
        }
    }
    // ---- Dung bang bu tre NGOAI khoa, chi tu ban chep pt / rs / rg ----
    auto idx=[&rs](int id){for(int i=0;i<(int)rs.size();++i)if(rs[(size_t)i].id==id)return i;return -1;};
    next->block=block;next->latency.resize((size_t)n);next->tapSource.assign((size_t)n,-1);next->terminals.resize((size_t)n);
    next->outputMasks.resize ((size_t) n);
    for (int i=0;i<n;++i) next->nodeIds.push_back (pt[(size_t)i].id);
    order=rg.processingOrder();
    next->lowLatency=lowLatency;
    next->primaryOnlySink=primaryOnlySink;
    next->primaryTerminal.assign((size_t)n,0);
    next->freeSeed.assign((size_t)n,0);next->ignoreSource.assign((size_t)n,0);next->silent.assign((size_t)n,0);
    next->voiceSeed.assign((size_t)n,0);
    for(int i=0;i<n;++i)
    {
        const auto& p=pt[(size_t)i];
        /*  R11-03: nhac = track he thong (Music/InputMusic) HOAC bat ky track kieu BEAT
            (them bang hop thoai thuong, ban sao track nhac...). Chi tieng tu nguon hat mic that
            moi can mic cho; Beat luon la file nhac nen chay tu do.  */
        next->freeSeed[(size_t)i]=(p.role==Track::Role::Music||p.role==Track::Role::InputMusic
                                   ||p.type==Track::Type::Beat)?1:0;
        /*  D02: track Audio/Beat chi CO THE phat tieng khi Loa (monitor) bat, hoac co clip de phat (phat clip khong phu thuoc Loa),
            hoac co plugin tu phat (instrument). Nguon hardware tat Loa, khong clip -> im o dau ra thuc nen khong tinh vao tre nhac / bu thu.
            Khong dung meter = 0 lam tieu chi (doan nghi cua bai hat van la mot duong nghe hop le).  */
        const bool contentTrack=p.type==Track::Type::Audio||p.type==Track::Type::Beat;
        const bool canSound=!contentTrack||p.monitor||p.extraSound;
        next->silent[(size_t)i]=(p.muted||!rg.audible(i)||!canSound)?1:0;
        next->ignoreSource[(size_t)i]=p.type==Track::Type::FxBus?1:0;
        /*  13/10: nguon GIONG THAT (de do tre nghe lai giong minh): track Input khong phai nhac, hoac track Audio
            lay thang tu card ma khong phai NHAC. Nhac (freeSeed) va file thi khong.  */
        const bool musicLike=p.role==Track::Role::Music||p.role==Track::Role::InputMusic||p.type==Track::Type::Beat;
        next->voiceSeed[(size_t)i]=(!musicLike&&(p.type==Track::Type::Input
                                   ||(p.type==Track::Type::Audio&&p.source==Track::Source::HardwareInput)))?1:0;
    }
    for(int i=0;i<n;++i)
    {
        const auto& p=pt[(size_t)i];const auto type=p.type;
        /*  F04: chi cong RA THAT SU NGHE DUOC moi tinh vao moc can nhau: PK tat nut Loa,
            bus bi mute hoac khong gan cong nao thi khong duoc keo AM THANH RA cho.  */
        const bool audibleExtra=(type==Track::Type::OutputBus&&!p.muted)
                              ||(type==Track::Type::PK&&p.monitor&&!p.muted);
        next->terminals[(size_t)i]=(type==Track::Type::Output||audibleExtra)&&p.outMask!=0;
        next->primaryTerminal[(size_t)i]=type==Track::Type::Output?1:0;
        next->outputMasks[(size_t) i] = p.outMask;
        if(p.allInsertsOn)for(int v:p.slots)
            next->latency[(size_t)i]=livent::latencyLimits::addSamples(next->latency[(size_t)i],v);
    }
    /*  C02: moi route kem co "co mang tieng ra tai nghe khong" (nut Loa, mute, send tat/-inf, solo, fader dong).
        Cung quy tac voi routeToTarget() nen tinh nhac nghe duoc khong tu y nghi khac voi am thanh that.  */
    auto add=[&](int from,int to,int key,int prefix=0,bool carriesAudio=true,bool mixRoute=false)
    {if(rg.passes(from,to)){next->routes.push_back({from,to,key,prefix});
        next->routeAudible.push_back((carriesAudio&&rg.audibleRoute(from,to))?1:0);
        next->noWait.push_back(mixRoute?1:0);}};   // 11g B1: main / Send audio = duong tron, live khong cho
    for(int i=0;i<n;++i)
    {
        const auto& r=rs[(size_t)i];const auto& p=pt[(size_t)i];const auto type=p.type;
        const int tap=idx(r.inputId);
        if(tap>=0&&pt[(size_t)tap].type==Track::Type::Input&&rg.passes(tap,i))
        {next->tapSource[(size_t)i]=tap;add(tap,i,-2);}
        if(type==Track::Type::Audio||type==Track::Type::Beat||type==Track::Type::Group||type==Track::Type::FxBus)
        {
            const bool content=type==Track::Type::Audio||type==Track::Type::Beat;
            const bool mainAudible=!p.muted&&rg.needsProcessing(i)&&(content||p.monitor)&&next->silent[(size_t)i]==0;
            const bool faderOpen=p.gainDb>-59.9f;
            add(i,idx(r.mainId),-1,0,mainAudible&&faderOpen,true);
            if(r.allSends)for(int k=0;k<r.sendCount;++k)if(r.sends[(size_t)k].enabled&&r.sidechainActive[(size_t)k])
            {
                const auto& send=r.sends[(size_t)k];const int to=idx(send.targetId);int prefix=0;
                if(to<0)continue;
                if(send.targetSlot>=0&&pt[(size_t)to].allInsertsOn)
                    for(int slot=0;slot<juce::jmin(send.targetSlot,PluginChain::maxSlots);++slot)
                        prefix=livent::latencyLimits::addSamples(prefix,pt[(size_t)to].slots[(size_t)slot]);
                // Send vao khe sidechain chi dieu khien plugin, khong ra loa. Send audio: Pre-fader van nghe duoc khi fader = 0.
                const float trim=p.sendTrimDb;
                const bool sendAudible=send.targetSlot<0&&mainAudible&&trim>-59.9f
                    &&send.levelDb+trim>-59.9f&&(send.preFader||faderOpen);
                add(i,to,k,prefix,sendAudible,send.targetSlot<0);   // sidechain van can khoa dung nhip
            }
        }
        if(type==Track::Type::PK)add(idx(r.mainId),i,-3);
        if(type==Track::Type::OutputBus)
        {
            if(r.busSource==-2)for(int k=0;k<r.mixCount;++k)add(idx(r.mixSources[(size_t)k]),i,100+k);
            else if(r.busSource>0)add(idx(r.busSource),i,100);
        }
    }
    // ---- Vao khoa mot tich tac: kiem tra bang hien tai ----
    auto sameTopology=[&]
    {
        if(tracks.size()!=n||currentBlockSize!=block)return false;
        for(int i=0;i<n;++i)if(tracks[i]->getId()!=pt[(size_t)i].id)return false;
        return true;
    };
    {
        const juce::ScopedLock lock(mixerLock);
        if(!sameTopology())
        {
            if(attempt<3)continue;   // track vua them/xoa/doi cho trong luc dung bang: dung lai
            latencyCompensationError = livent::vn ("Cấu hình âm thanh đã thay đổi trong lúc chuẩn bị bù trễ. Hãy thử xuất lại.");
            return false;
        }
        if(latencyPlan && next->nodeIds==latencyPlan->nodeIds && next->block==latencyPlan->block && next->latency==latencyPlan->latency
            && next->routes==latencyPlan->routes && next->tapSource==latencyPlan->tapSource
            && next->terminals==latencyPlan->terminals && next->lowLatency==latencyPlan->lowLatency
            && next->freeSeed==latencyPlan->freeSeed && next->voiceSeed==latencyPlan->voiceSeed && next->ignoreSource==latencyPlan->ignoreSource
            && next->primaryTerminal==latencyPlan->primaryTerminal && next->primaryOnlySink==latencyPlan->primaryOnlySink
            && next->outputMasks==latencyPlan->outputMasks && next->noWait==latencyPlan->noWait)
        {
            /*  Cau truc giu nguyen; chi mute/solo co the doi -> cap nhat tre nhac nghe duoc va do bu ban thu
                tai cho (KHONG dung lai bo can: bat/tat mute khong duoc lam dut tieng).  */
            if(next->lowLatency&&(next->silent!=latencyPlan->silent||next->routeAudible!=latencyPlan->routeAudible))
            {
                latencyPlan->silent=next->silent;latencyPlan->routeAudible=next->routeAudible;
                latencyPlan->computeMusicLatency(order);
                latencyPlan->computeHeardDelays(order);
                applyCaptureLatency(*latencyPlan);
                musicLatencySamples.store(latencyPlan->musicLatency);
                voiceMonitorSamples.store(latencyPlan->voiceMonitorValid?latencyPlan->voiceMonitorDelay:-1);
                heardMusicSamples.store(latencyPlan->heardMusicValid?latencyPlan->heardMusicDelay:(latencyPlan->lowLatency?latencyPlan->musicLatency:0));
            }
            latencyCompensationError.clear(); return true;
        }
    }
    next->prepare(order); // Allocation occurs outside mixerLock and outside the device callback.
    std::unique_ptr<livent::LatencyPlan> old;
    {
        const juce::ScopedLock lock(mixerLock);
        if(!sameTopology())
        {
            if(attempt<3)continue;
            latencyCompensationError = livent::vn ("Cấu hình âm thanh đã thay đổi trong lúc chuẩn bị bù trễ. Hãy thử xuất lại.");
            return false;
        }
        const int output=routingIndex(getOutputTrack()!=nullptr ? getOutputTrack()->getId() : -1);
        /*  F05: mau Master ra khoi mixer da qua bo can cong (hardwareDelay) nen preroll xuat
            file phai gom ca phan do, neu khong dau file thua im lang / cuoi bi cat.  */
        graphLatencySamples.store(output>=0 ? livent::channelLatency::addSamples(next->outputArrival[(size_t)output],
                                                                               next->hardwareDelays[(size_t)output].delaySamples()) : 0);
        /*  Che do live: nguoi hat nghe nhac tre them musicLatency (VD nhac co
            SoundShifter) nen giong thu vao cung phai doi som ngan do, neu khong
            ban thu se lech nhac. Che do bu day du thi nhac da duoc can theo mic.  */
        applyCaptureLatency(*next);
        musicLatencySamples.store(next->musicLatency);
        voiceMonitorSamples.store(next->voiceMonitorValid?next->voiceMonitorDelay:-1);
        heardMusicSamples.store(next->heardMusicValid?next->heardMusicDelay:(next->lowLatency?next->musicLatency:0));   // 14/10: bang so dang dung de bu
        /*  11g B2: plan moi nhan lich su vong tre cua plan cu va block dau tien tron dan
            cu -> moi: bat/tat plugin co tre khi dang hat khong con hut tieng/click.
            Plan cu bi thay truoc do (neu con) duoc giai phong ngoai khoa.  */
        old=std::move(retiredPlan);
        if(latencyPlan)
        {
            latencyPlan->endBlock();
            try{next->beginTransition(*latencyPlan);}catch(...){next->endBlock();}
        }
        retiredPlan=std::move(latencyPlan);latencyPlan=std::move(next);
        latencyCompensationError.clear();
    }
    return true;
    }
    }
    catch (const std::exception& error)
    {
        const juce::ScopedLock lock (mixerLock);
        const auto message = livent::vn ("Không thiết lập được bù trễ VST: ") + juce::String (error.what());
        if (message != latencyCompensationError) livent::stabilityLog ("PDC", message);
        latencyCompensationError = message;
        latencyPlan.reset(); graphLatencySamples.store (0);
        return false;
    }
    catch (...)
    {
        const juce::ScopedLock lock (mixerLock);
        latencyCompensationError = livent::vn ("Không cấp được bộ đệm bù trễ VST.");
        latencyPlan.reset(); graphLatencySamples.store (0);
        return false;
    }
}

void Mixer::routeToTarget (Track& t, int numSamples, bool anySolo)
{
    /*  V5.8.7 LIVE: tat/mute/solo/monitor khong cat gain thang dung nua.
        Track::addToBus() nho gain block truoc va ramp den target trong 1
        block. Nhu vay bam M/Loa hay keo volume/send luc dang hat khong tao
        click/zipper, ma audio thread van khong lock/allocate. */
    juce::ignoreUnused(anySolo);
    const int from=routingIndex(t.getId());
    if(from<0)return;
    const auto& routes=routeSnapshots[(size_t)from];
    auto delayed=[&](int target,int key)->const juce::AudioBuffer<float>&
    {return latencyPlan ? latencyPlan->route(from,routingIndex(target),key,t.getBuffer(),numSamples) : t.getBuffer();};
    const bool notSilenced = !t.isMuted() && routingGraph.needsProcessing(from);
    const bool content = t.getType() == Track::Type::Audio || t.getType() == Track::Type::Beat;
    const bool mainAudible = notSilenced && (content || t.isMonitorOn());

    // Duong chinh: ke ca khi tat, van goi 1 block voi target=0 de ramp xuong.
    if (auto* target = getTrackById(routes.mainId))
        t.addToBus(target->getBuffer(),numSamples,mainAudible&&routingGraph.audibleRoute(from,routingIndex(routes.mainId))?1.0f:0.0f,-1,true,&delayed(routes.mainId,-1));

    /* Nut Loa la cong tac dut ca dry + FX send cho live. Khong return som:
       send thuong can nhan target=0 de fade het trong 1 block. Sidechain
       khong phat ra loa truc tiep nen van cat ngay de tranh kich nham. */
    const bool sendsAudible = mainAudible && routes.allSends;
    const float sendTrimDb  = t.getSendTrimDb();

    for (int i = 0; i < routes.sendCount; ++i)
    {
        auto s = routes.sends[(size_t)i];
        s.enabled=s.enabled&&(s.targetSlot>=0 ? routingGraph.controlRoute(from,routingIndex(s.targetId))
                        : routingGraph.audibleRoute(from,routingIndex(s.targetId)));
        auto* fx = getTrackById (s.targetId);

        if (fx == nullptr)
            continue;

        const auto& sendAudio=delayed(s.targetId,i);
        if (s.targetSlot >= 0)
        {
            if (t.isMuted() || !routes.allSends || !routingGraph.needsProcessing(from)
                || !(content || t.isMonitorOn()) || ! s.enabled || s.levelDb <= -59.9f)
                continue;

            const float g = juce::Decibels::decibelsToGain (s.levelDb);
            const float sourceGain = s.preFader ? 1.0f : t.getGainLinear();
            fx->getInserts().addToSidechain (s.targetSlot, sendAudio,
                                             numSamples, g * sourceGain);
            continue;
        }

        float effectiveSendDb = s.levelDb;
        bool sendOn = sendsAudible && s.enabled;

        if (sendOn)
        {
            if (sendTrimDb <= -59.9f)
                sendOn = false;
            else
                effectiveSendDb = juce::jlimit (-60.0f, 6.0f,
                                                 s.levelDb + sendTrimDb);
        }

        const float sendGain = (sendOn && effectiveSendDb > -59.9f)
                             ? juce::Decibels::decibelsToGain (effectiveSendDb)
                             : 0.0f;

        t.addToBus (fx->getBuffer(), numSamples, sendGain, i, ! s.preFader,&sendAudio);
    }
}

void Mixer::prepareOutputBusSources (int numSamples, bool anySolo, Track* only)
{
    juce::ignoreUnused(anySolo);
    // Every allowed source has finished its inserts in this block. OutputBus
    // and PK cannot be sources, so list order never introduces a tap cycle.
    for (auto* bus : tracks)
    {
        if (bus->getType() != Track::Type::OutputBus || (only!=nullptr&&bus!=only))continue;
        const auto& snap=routeSnapshots[(size_t)routingIndex(bus->getId())];
        const int sourceId = snap.busSource;
        if (sourceId == 0) continue; // keep legacy summing of routed inputs
        bus->clearBuffer (numSamples); // explicit source replaces routed input
        if (sourceId == -2)
        {
            for (int i = 0; i < snap.mixCount; ++i)
            {
                auto* source = getTrackById(snap.mixSources[(size_t)i]);
                if (source == nullptr || ! isOutputBusSourceType (source->getType())
                    || source->getType() == Track::Type::Output) continue;
                const bool audible = ! source->isMuted()
                    && routingGraph.audibleRoute(routingIndex(source->getId()),routingIndex(bus->getId()));
                const float db = source->getGainDb();
                bus->addOutputMixTap (*source, numSamples,
                    audible && db > -59.9f ? juce::Decibels::decibelsToGain (db) : 0.0f, i,
                    latencyPlan ? &latencyPlan->route(routingIndex(source->getId()),routingIndex(bus->getId()),100+i,source->getBuffer(),numSamples) : nullptr);
            }
            continue;
        }
        auto* source = getTrackById (sourceId);
        if (source == nullptr || ! isOutputBusSourceType (source->getType())) continue;
        const bool audible = ! source->isMuted()
                          && routingGraph.audibleRoute(routingIndex(source->getId()),routingIndex(bus->getId()));
        const float db = source->getGainDb();
        const float gain = audible && db > -59.9f ? juce::Decibels::decibelsToGain (db) : 0.0f;
        bus->copyFromTrackTap (latencyPlan ? latencyPlan->route(routingIndex(source->getId()),routingIndex(bus->getId()),100,source->getBuffer(),numSamples) : source->getBuffer(), numSamples, gain);
    }
}

void Mixer::processTier (Track::Type tierType, int numSamples, bool anySolo)
{
    for (auto* t : tracks)
    {
        if (t->getType() != tierType)
            continue;

        t->runInserts (numSamples);
        t->applyPan (numSamples);
        t->updateMeter (numSamples);

        /*  Output va PK deu do THANG ra card chu khong do vao track nao.
            Rieng PK ma goi routeToTarget thi con nguy: o "outputTargetId"
            cua no dang mang nghia track NGUON, nen no se do nguoc tieng vao
            chinh cai track no dang nghe -> vong tron, hu loa.  */
        /*  MOC 51: them Input vao danh sach khong route. Track cong vao chi
            ngoi day cho track khac toi lay, khong tu do tieng di dau ca -
            do di la tieng ra loa hai lan.  */
        if (tierType != Track::Type::Output
            && tierType != Track::Type::OutputBus
            && tierType != Track::Type::PK
            && tierType != Track::Type::Input)
            routeToTarget (*t, numSamples, anySolo);
    }
}

//=============================================================================
void Mixer::processBlock (const juce::AudioBuffer<float>& hardwareInput,
                          juce::AudioBuffer<float>& output,
                          int startSample, int numSamples, bool offlineWorker)
{
    if (! offlineWorker && offlineExportActive.load (std::memory_order_acquire))
    {
        output.clear (startSample, numSamples);
        return;
    }
    /*  11j: TRUOC KHI CHIU THUA, THU LAI TRONG CHOC LAT.
        Luong dieu khien (bo hen gio 20 lan/giay, bam nut...) chi giu mixerLock vai micro-giay.
        Ban cu thay khoa dang ban la bo ngay block do (lap lai block truoc = tieng "tach").
        Gio thu lai lien tuc toi da ~200 us (khong qua 5% thoi gian mot block): khong ngu, khong
        cap phat, khong doi vo han. Het han ma van ban (thao tac lon hiem gap) thi xu ly nhu cu.  */
    bool gotMixerLock = mixerLock.tryEnter();
    if (! gotMixerLock && ! offlineWorker && currentSampleRate > 0.0)
    {
        const auto ticksPerSecond = (double) juce::Time::getHighResolutionTicksPerSecond();
        const double budgetSeconds = juce::jmin (0.0002, 0.05 * numSamples / currentSampleRate);
        const auto budget = (juce::int64) (ticksPerSecond * budgetSeconds);
        const auto start = juce::Time::getHighResolutionTicks();
        while (! gotMixerLock && juce::Time::getHighResolutionTicks() - start < budget)
            gotMixerLock = mixerLock.tryEnter();
        if (gotMixerLock) mixerLockRetryWins.fetch_add (1, std::memory_order_relaxed);
    }
    struct MixerLockRelease
    {
        juce::CriticalSection& lock; bool held;
        ~MixerLockRelease() { if (held) lock.exit(); }
    } mixerLockRelease { mixerLock, gotMixerLock };

    if (! gotMixerLock)
    {
        /* V6.6.6 AUDIO CORE:
           Ban cu clear() ca block -> nghe nhu dut day/no mot phat. O day
           khong doi khoa, khong ngu, khong cap phat. Neu co block tot truoc
           do thi lap lai rat ngan va fade nhe neu contention keo dai. Day la
           safety-net cho thao tac topology/timeline hiem gap; duong plugin
           binh thuong da duoc bo chainLock rieng trong PluginChain. */
        mixerLockMissCount.fetch_add (1, std::memory_order_relaxed);
        if(!offlineWorker)timeline.noteMissingAudioBlock(numSamples);
        if (! offlineWorker && (! realtimeExportSourcesOnly.load() || realtimeExportCaptureReady.load()))
            masterRecorder.noteMissingAudioBlock (numSamples);

        const int cached = lastGoodOutputSamples;
        const int chs = juce::jmin (output.getNumChannels(), lastGoodOutput.getNumChannels());

        // Cached hardware audio contains the previous monitor gain. Never
        // replay it after a mute/dim/volume change while the mixer is busy.
        if (cached >= numSamples && chs > 0 && ! monitorOutput.hasPendingChange())
        {
            const float g0 = contentionFallbackGain;
            const float g1 = juce::jmax (0.0f, g0 * 0.92f);

            for (int ch = 0; ch < chs; ++ch)
            {
                output.copyFrom (ch, startSample, lastGoodOutput, ch, 0, numSamples);
                output.applyGainRamp (ch, startSample, numSamples, g0, g1);
            }

            for (int ch = chs; ch < output.getNumChannels(); ++ch)
                output.clear (ch, startSample, numSamples);

            contentionFallbackGain = g1;
        }
        else
        {
            output.clear (startSample, numSamples);
            contentionFallbackGain = 0.0f;
        }

        return;
    }

    if (! offlineWorker && offlineExportActive.load (std::memory_order_acquire))
    {
        output.clear (startSample, numSamples);
        return;
    }

    // 11g B2: block nay xong thi plan cu (neu dang tron) khong con duoc dung nua.
    struct TransitionBlockEnd { Mixer& m; ~TransitionBlockEnd() { if (m.latencyPlan) m.latencyPlan->endBlock(); } } transitionBlockEnd { *this };
    timeline.consumeAudioGaps();
    // Lay duoc mixer lock: block moi se la nguon fallback moi.
    contentionFallbackGain = 1.0f;

    /*  13/10 CHONG NO TIENG KHI DUNG: bam DUNG khong cat ngang ban thu / nhac dang phat (cat ngang o muc
        tin hieu khac 0 = tieng "bup"). Luong dieu khien chi XIN dung; o day ha am luong track clip/nhac
        ve 0 trong ~8 ms roi moi that su dung timeline (cuoi processBlock). Duoi vang VST van chay tu nhien.  */
    if (! offlineWorker && softStopLeft <= 0 && softStopRequested.load (std::memory_order_acquire))
    {
        if (timeline.isPlaying())
        {
            softStopTotal = softStopLeft = livent::declick::rampSamplesFor (currentSampleRate, 0.008);
            softStopMusicOwned = musicPlaybackStartedByTransport.load (std::memory_order_acquire);
        }
        else
            softStopRequested.store (false, std::memory_order_release);
    }
    float stopGain0 = 1.0f, stopGain1 = 1.0f;
    const bool stopFading = softStopLeft > 0;
    // Da ha am xong nhung nhac chua dung han (luong dieu khien dang cho transport): giu im, tranh bat lai 1 khoi.
    const bool stopHold = ! stopFading && softStopHold.load (std::memory_order_acquire);
    if (stopFading)
    {
        stopGain0 = (float) softStopLeft / (float) softStopTotal;
        softStopLeft = juce::jmax (0, softStopLeft - numSamples);
        stopGain1 = (float) softStopLeft / (float) softStopTotal;
    }

    // Audio thu van xu ly nhu truoc. Khi chi PHAT NHAC (khong ghi dia),
    // thong bao transport cho Auto-Key/nhung VST can host playhead.
    const bool recording = timeline.isRecording();
    bool playing = recording || timeline.isPlaying();
    double playSeconds = timeline.getPositionSeconds();

    snapshotRouting();
    // ---- Xoa sach buffer moi track, roi nap nguon ------------------------
    bool anySolo = false;

    for (auto* t : tracks)
    {
        t->clearBuffer (numSamples);
        t->getInserts().beginAudioBlock(numSamples);

        if (t->isSoloed())
            anySolo = true;

        // Ghep vao vong duyet DA CO: khong quet danh sach track lan thu hai
        // moi audio callback chi de tim file NHAC dang phat.
        if (! playing && t->getRole() == Track::Role::Music && t->isPlaying())
        {
            playing = true;
            playSeconds = t->getPositionSeconds();
        }
    }

    hostPlayHead.update (playing, recording, playSeconds, currentSampleRate);

    // hardwareInput la view rieng cua khoi hien tai, luon bat dau tai mau 0.
    if (offlineWorker)
    {
        for (auto& source : offlineFileSources)
        {
            source.reader->read (source.track->getBuffer(), numSamples);
            if (source.reader->isStereo() && source.track->getChannelMode() == Track::Chan::Mono)
            {
                auto& buffer = source.track->getBuffer();
                for (int i = 0; i < numSamples; ++i)
                {
                    const float mono = 0.5f * (buffer.getSample (0, i) + buffer.getSample (1, i));
                    buffer.setSample (0, i, mono);
                    buffer.setSample (1, i, mono);
                }
            }
        }
    }
    else
        for (auto* t : tracks)
            if (! realtimeExportSourcesOnly.load() || t->getSource() == Track::Source::AudioFile)
                t->readSource (hardwareInput, 0, numSamples);

    // ---- Xu ly theo tang, dung thu tu ------------------------------------
    /*  ==========  MOC 51: TANG CONG VAO CHAY DAU TIEN  ==========

        Track Input nhan tieng thang tu card va chay day plugin cua no truoc
        moi track khac. Bat buoc phai truoc: cac track lay tieng TU no chi
        chep duoc khi no da xong - chep som thi chep phai vung con rong.

        Track Input KHONG goi routeToTarget (xem processTier): no khong do
        tieng vao track nao ca, chi ngoi day cho track khac toi lay.  */
    processTier (Track::Type::Input, numSamples, anySolo);

    /*  Chep tieng tu track Input sang cac track lay tu no.

        Chep SAU day plugin cua track Input (user chot huong nay) - nho vay
        mot con nen dat o track cong vao la moi track lay ve deu da qua no.

        Chong VONG TRON: chi chep tu track loai Input. Track Input khong the
        lay tieng tu track khac (giao dien khong cho chon), nen khong bao gio
        co chuoi A lay tu B ma B lay tu A.  */
    for (auto* t : tracks)
    {
        if (t->getSource() != Track::Source::TrackTap)
            continue;

        auto* src = getTrackById (t->getInputTrackId());

        if (src == nullptr || src == t || src->getType() != Track::Type::Input)
            continue;

        /*  ==========  MOC 52: CHEP KEM AM LUONG CUA TRACK CONG VAO  ==========

            Ban Moc 51 chep buffer tran, khong nhan am luong. Ket qua: keo
            thanh volume cua MONO IN khong lam gi ca - track MIC lay tu no
            van y nguyen muc cu. Nhin thi thanh volume nam do nhu do trang
            tri, ma anh khong hieu tai sao keo mai khong an.

            Dung ra thanh volume cua track cong vao phai la NUM CHINH GAIN
            DAU VAO - cho de bu mic to nho khac nhau, mot lan cho moi track
            lay tu no. Do cung la cach ban tron that lam.

            Nut M cung phai an theo: tat M o track cong vao la moi track lay
            tu no deu im. Neu khong, tat M ma tieng van ra loa thi khong con
            biet duong nao ma lan.  */
        const float srcGain = src->isMuted()
                                ? 0.0f
                                : src->getGainLinear();

        const auto& sb = src->getBuffer();

        // V5.8.7: TrackTap chi mang stereo va ramp gain cua track Input,
        // tranh pop khi bam M/keo gain dau vao trong luc dang hat.
        t->copyFromTrackTap (sb, numSamples, srcGain);
    }

    /*  ==========  V6.2: REC TAP DRY / PLAYBACK TAP  ==========

        Day la vi tri co y: track Audio/Beat da co dung nguon (Hardware hoac
        TrackTap), nhung CHUA chay Track::runInserts(). Vi vay:

          - dang THU + track ARM: ghi dung DRY vao WAV;
          - dang PHAT: thay nguon live bang clip dry;
          - sau do processTier() van chay cung mot chuoi VST -> tai nghe WET.

        MasterRecorder o phia sau van giu nguyen de thu ban WET tong neu can. */
    // Export renders recorded material even if live monitoring is selected.
    // Do not toggle track monitor flags: they remain the user's saved choice.
    const bool sourcePlaybackOnly = offlineWorker
        || realtimeExportSourcesOnly.load (std::memory_order_acquire);
    const juce::int64 blockStartPos = timeline.getPositionSamples();
    // Tua / mat block: vi tri khong noi tiep voi khoi truoc -> mau dau cua clip cach xa mau cuoi cu.
    const bool positionJumped = playing && expectedNextBlockStart >= 0 && blockStartPos != expectedNextBlockStart;
    for (auto* t : tracks)
        if (t->getType() == Track::Type::Audio || t->getType() == Track::Type::Beat)
        {
            const bool clips=timeline.willPlayClips(*t,numSamples,sourcePlaybackOnly);
            timeline.processTrackPreInsert (*t, numSamples, sourcePlaybackOnly);
            if (! offlineWorker && ! realtimeExportSourcesOnly.load())
            {
                // Chi nhac do transport khoi dong moi bi ha theo (nhac phat rieng bang nut cua no thi giu nguyen).
                // (khong can isPlaying: AudioTransportSource con tu ha am 256 mau SAU khi nhan lenh dung)
                const bool fileMusic = softStopMusicOwned && t->getRole() == Track::Role::Music
                                       && t->getSource() == Track::Source::AudioFile;
                if ((stopFading || stopHold) && (clips || fileMusic))
                    for (int ch = 0; ch < juce::jmin (2, t->getBuffer().getNumChannels()); ++ch)
                        t->getBuffer().applyGainRamp (ch, 0, numSamples, stopFading ? stopGain0 : 0.0f, stopFading ? stopGain1 : 0.0f);
                auto& mixState = t->getSourceMix();
                const bool clipsEnded = mixState.prevClips && ! clips;
                mixState.prevClips = clips;
                t->bridgeSource (numSamples, (positionJumped && clips) || clipsEnded);
            }
            if (! offlineWorker && realtimeExportSourcesOnly.load()
                && realtimeExportRequiredReads.contains (t->getId())
                && ((clips && timeline.hasRealtimeReadError (t->getUuid()))
                    || (! clips && t->getSource() == Track::Source::AudioFile && t->hasFileReadError())))
            {
                int noError = 0;
                realtimeExportReadErrorTrack.compare_exchange_strong (noError, t->getId());
            }
            if(latencyPlan)latencyPlan->source(routingIndex(t->getId()),t->getBuffer(),numSamples,
                !clips && t->getSource()==Track::Source::TrackTap);
        }

    // 07/10 _E: timeline DUNG ma cua so Melodyne / Auto-Tune dang mo -> van
    // goi plugin (im) de no biet dau phat o dau, khung Graph cuon theo.
    if (! recording && ! timeline.isPlaying())
        araManager->renderIdle (timeline.getPositionSamples(), numSamples, currentSampleRate);

    // Kiem tra duy nhat track NHAC truoc inserts; khong tao timer, khong doc
    // dia va khong quet ca mixer khi cai dat tat/transport that dang chay.
    bool audibleMusic = false;
    if (autoKeyPlayHead.isEnabled() && ! playing)
        if (auto* music = getTrackByRole (Track::Role::Music))
            if (! music->isMuted())
            {
                const auto& b = music->getBuffer();
                audibleMusic = b.getNumChannels() > 0
                            && (b.getMagnitude (0, 0, numSamples) >= 0.0001f
                                || (b.getNumChannels() > 1
                                    && b.getMagnitude (1, 0, numSamples) >= 0.0001f));
            }
    autoKeyPlayHead.update (playing, audibleMusic, numSamples, currentSampleRate);

    // Dependencies include normal routes, Sends and native sidechain Sends.
    // Visual track order is independent of audio processing order.
    for(const int index:routingGraph.processingOrder())
    {
        auto& t=*tracks[index];const auto type=t.getType();
        if(type==Track::Type::Input || type==Track::Type::PK)continue;
        if(type==Track::Type::Output && !offlineWorker && !realtimeExportSourcesOnly.load())
            sfxPlayer.addTo(t.getBuffer(),numSamples);
        if(type==Track::Type::OutputBus)prepareOutputBusSources(numSamples,anySolo,&t);
        t.runInserts(numSamples);t.applyPan(numSamples);t.updateMeter(numSamples);
        if(type!=Track::Type::Output && type!=Track::Type::OutputBus)routeToTarget(t,numSamples,anySolo);
    }

    if (! offlineWorker && realtimeExportSourcesOnly.load() && realtimeExportCaptureReady.load())
        for (auto* track : tracks)
            if (realtimeExportRequiredReads.contains (track->getId()))
            {
                if (track->areAllInsertsOn() && track->getInserts().hasExportProcessingFailure())
                { int empty = 0; realtimeExportProcessingErrorTrack.compare_exchange_strong (empty, track->getId()); }
                if (track->hasExportNonFinite())   // C01: NaN/Inf -> phien xuat that bai (da nam trong tap required reads = track gop vao Master)
                { int empty = 0; realtimeExportProcessingErrorTrack.compare_exchange_strong (empty, track->getId()); }
                if (araManager->hasSourceReadFailure (track->getUuid()))
                { int empty = 0; realtimeExportReadErrorTrack.compare_exchange_strong (empty, track->getId()); }
            }

    // Capture the logical Master after its fader/mute, before monitor controls
    // and physical-output alignment. Ordinary WET recording and export agree.
    if (masterRecorder.isRecording()
        && (! realtimeExportSourcesOnly.load()
            || (realtimeExportCaptureReady.load() && realtimeExportReadErrorTrack.load() == 0
                && realtimeExportProcessingErrorTrack.load() == 0)))
    {
        if (auto* out = getOutputTrack())
        {
            auto& buf = out->getBuffer();

            const float* channels[2] = { buf.getReadPointer (0),
                                        buf.getNumChannels() > 1 ? buf.getReadPointer (1)
                                                                 : buf.getReadPointer (0) };

            if (numSamples <= exportGainScratch.getNumSamples())
            {
                const float gain = out->isMuted() ? 0.0f : out->getGainLinear();
                for (int channel = 0; channel < 2; ++channel)
                {
                    exportGainScratch.copyFrom (channel, 0, channels[channel], numSamples);
                    if (realtimeExportSourcesOnly.load()) exportGainScratch.applyGain (channel, 0, numSamples, gain);
                    else exportGainScratch.applyGainRamp (channel, 0, numSamples, out->getHardwareOutRampStart(), gain);
                }
                const float* exportChannels[] { exportGainScratch.getReadPointer (0), exportGainScratch.getReadPointer (1) };
                if (! realtimeExportSourcesOnly.load()) masterRecorder.write (exportChannels, 2, numSamples);
                else
                {
                    const auto remaining = realtimeExportSkipSamples.load();
                    const int skip = (int) juce::jmin<juce::int64> (numSamples, remaining);
                    realtimeExportSkipSamples.store (remaining - skip);
                    realtimeExportProcessedSamples.fetch_add (numSamples);
                    if (skip < numSamples)
                    {
                        const float* selected[] { exportChannels[0] + skip, exportChannels[1] + skip };
                        masterRecorder.write (selected, 2, numSamples - skip);
                    }
                }
            }
        }
    }

    /*  ==========  MOC 28: TANG PK, CHAY SAU CUNG  ==========

        PK phai chay SAU Output, khong duoc truoc. Vi neu anh cho PK nghe
        trom chinh AM THANH RA ma PK lai chay truoc, thi luc PK doc, buffer
        cua AM THANH RA con dang rong -- nghe ra im lang. Chay sau thi moi
        track deu da xong, doc cai nao cung co tieng that.

        Hai buoc: chep tieng tu track nguon sang, roi moi chay insert cua PK.
        Nho vay PK co day plugin rieng -- vd day sang Cubase thi them mot con
        nen tieng, ma loa nghe cua anh khong bi anh huong.  */
    for (auto* t : tracks)
    {
        if (t->getType() != Track::Type::PK)
            continue;

        auto* src = getTrackById (t->getOutputTargetId());

        if (src == nullptr || src == t)
            continue;

        auto&       dst = t->getBuffer();
        const auto& sb  = latencyPlan ? latencyPlan->route(routingIndex(src->getId()),routingIndex(t->getId()),-3,src->getBuffer(),numSamples) : src->getBuffer();

        const int nch = juce::jmin (2, dst.getNumChannels(), sb.getNumChannels());

        for (int ch = 0; ch < nch; ++ch)
            dst.copyFrom (ch, 0, sb, ch, 0, numSamples);
    }

    processTier (Track::Type::PK, numSamples, anySolo);

    // V6.2: dong ho chung tang dung MOT lan moi audio block. Dat truoc phan
    // do ra card de ke ca thiet bi tam thoi khong co output channel, capture
    // va playhead van khong bi dung thoi gian.
    timeline.advance (numSamples);
    if (stopFading && softStopLeft <= 0)
        if (softStopRequested.exchange (false, std::memory_order_acq_rel))
        {
            softStopHold.store (true, std::memory_order_release);
            timeline.stopPlayback (softStopReturnToStart.load (std::memory_order_acquire));
        }
    expectedNextBlockStart = (! offlineWorker && (timeline.isPlaying() || timeline.isRecording()))
                                 ? timeline.getPositionSamples() : -1;

    // ---- Do ra card -------------------------------------------------------
    output.clear (startSample, numSamples);

    auto* out = getOutputTrack();

    if (out == nullptr)
        return;

    /*  Buffer ra da duoc xoa sach o tren.

        Xoa het la bat buoc: neu anh doi tu cap 1/2 sang cap 7/8 ma khong xoa,
        cap 1/2 se giu lai mau am cuoi cung roi keu "re" mai khong dut.  */
    const int nOut = output.getNumChannels();

    if (nOut <= 0)
        return;

    /*  MOC 26b/28: do CUNG MOT tin hieu vao MOI cap dang bat.

        Chep chu khong chia: moi duong ra deu nhan du am luong, khong ai bi
        nho di vi co them duong khac.

        Doc bang co MOT LAN vao bien tam roi moi dung. Neu doc lai nhieu lan
        trong vong lap, anh bam tich giua chung thi nua tren dung bang co cu,
        nua duoi dung bang co moi -- ra tieng ky cuc.

        Dung addFrom chu khong copyFrom: AM THANH RA va PK co the duoc chon
        ra CUNG mot cap cong. Luc do hai tin hieu phai CONG lai voi nhau,
        chu neu chep de thi cai sau xoa mat cai truoc.  */
    const auto monitorRamp = offlineWorker ? livent::MonitorOutput::Ramp{} : monitorOutput.next (numSamples);
    auto pourOut = [&] (Track& t, float extraStart = 1.0f, float extraEnd = 1.0f)
    {
        // Physical output alignment uses its own prepared scratch. Never write
        // it back into the logical mix: export, metering and PK tap that mix.
        const int index = routingIndex (t.getId());
        const auto& hardwareAudio = ! offlineWorker && latencyPlan && index >= 0
                                  && index < (int) latencyPlan->hardwareDelays.size()
            ? latencyPlan->hardware (index, t.getBuffer(), numSamples)
            : t.getBuffer();
        const float targetGain = t.isMuted() || !routingAudible(t) ? 0.0f
                                             : t.getGainLinear();
        const float startGain = t.getHardwareOutRampStart();
        t.setHardwareOutRampTarget (targetGain);

        // The panel reads atomic levels from the main Output after Inserts,
        // Pan and the Master fader. Extra OutputBus/PK routes never overwrite it.
        if (! offlineWorker && t.getType() == Track::Type::Output)
        {
            masterMeter.process (t.getBuffer().getReadPointer (0), t.getBuffer().getReadPointer (1),
                                 numSamples, currentSampleRate, startGain, targetGain);
            loudnessMeter.process (t.getBuffer().getReadPointer (0), t.getBuffer().getReadPointer (1),
                                   numSamples, startGain, targetGain);
        }

        // Only the physical main Master feed uses monitor controls. Metering,
        // recording and render remain at the original pre-monitor tap.
        const bool monitorMaster = ! offlineWorker && t.getType() == Track::Type::Output;
        const float hardwareStart = startGain * (monitorMaster ? monitorRamp.start : 1.0f) * extraStart;
        const float hardwareEnd = targetGain * (monitorMaster ? monitorRamp.end : 1.0f) * extraEnd;

        if (hardwareStart <= 0.0f && hardwareEnd <= 0.0f)
            return;

        const juce::uint32 mask     = t.getOutPairMask();
        const int          numPairs = nOut / 2;

        for (int pair = 0; pair < numPairs && pair < 32; ++pair)
        {
            if ((mask & (1u << pair)) == 0)
                continue;

            const int left = pair * 2;

            output.addFromWithRamp (left, startSample, hardwareAudio.getReadPointer (0),
                                    numSamples, hardwareStart, hardwareEnd);
            output.addFromWithRamp (left + 1, startSample, hardwareAudio.getReadPointer (1),
                                    numSamples, hardwareStart, hardwareEnd);
        }
    };

    // Do tat ca bus dau ra logic. Moi bus co mapping cong vat ly rieng.
    for (auto* t : tracks)
        if (t->getType() == Track::Type::Output || t->getType() == Track::Type::OutputBus)
            pourOut (*t);

    /*  MOC 40: PK chi ra tieng khi nut Loa cua no dang bat.

        Kiem o day chu khong nhet vao pourOut: AM THANH RA khong co nut Loa
        (da an di tren giao dien), nen neu kiem chung mot cho thi duong ra
        tong se im tit vi mot cai nut khong ai bat duoc.  */
    if (auto* pk = getPkTrack())
    {
        // 13/10: nut Loa cua PK tang/giam trong 1 khoi (khong ngat dot ngot = khong "bup").
        const float pkTarget = pk->isMonitorOn() ? 1.0f : 0.0f;
        if (pkTarget > 0.0f || pkOutGain > 0.0f)
        {
            const float pkStart = offlineWorker ? pkTarget : pkOutGain;
            if (! offlineWorker) pkOutGain = pkTarget;
            pourOut (*pk, pkStart, pkTarget);
        }
    }

    /*  OUTPUT GUARD (0.6.7.9): lop bao ve cuoi truoc khi ra card. Mau NaN/Inf
        thanh 0 (khong con tieng no), tin hieu qua 0.98 duoc uon mem thay vi
        bi card cat cung. Tin hieu binh thuong khong bi dong cham. Chi o duong
        NGHE: xuat file / thu Master da lay mau truoc buoc nay.  */
    if (! offlineWorker)
    {
        for (auto* t : tracks)
            if (t->peekNonFiniteBlocks() > 0) { pluginGuardPending.store (true, std::memory_order_relaxed); break; }
        int bad = 0;
        for (int ch = 0; ch < output.getNumChannels(); ++ch)
            bad += livent::outputguard::process (output.getWritePointer (ch, startSample), numSamples);
        if (bad > 0)
            outputGuardHits.fetch_add (bad, std::memory_order_relaxed);
    }

    /* V6.6.6 AUDIO CORE: cap nhat block tot GAN NHAT sau khi da do xong moi
       Output/OutputBus/PK. Chi copy bo nho da cap san; khong malloc/lock. */
    if (numSamples <= lastGoodOutput.getNumSamples())
    {
        const int cacheCh = juce::jmin (output.getNumChannels(), lastGoodOutput.getNumChannels());
        for (int ch = 0; ch < cacheCh; ++ch)
            lastGoodOutput.copyFrom (ch, 0, output, ch, startSample, numSamples);

        lastGoodOutputSamples = numSamples;
    }
    else
    {
        lastGoodOutputSamples = 0;
    }

}
