#pragma once

#include <JuceHeader.h>
#include "Theme.h"
#include "AppBranding.h"

/*  ==========  06/10: HUONG DAN CHI TIET (Cai dat > Ban quyen & Bao mat)  ==========

    Nut "?" tren thanh tren cung da nhuong cho nut "▾ Gon". Huong dan chuyen
    vao day: ben trai la muc luc, ben phai la noi dung chu tung buoc.
    Chi doc - khong lam gi voi du an. Noi dung viet thang trong file nay de
    sua chu khong phai dung toi giao dien.                                  */
namespace livent::guide
{
    /** illustration: 0 = khong co; 1..3 = hinh minh hoa bai Lane (ve bang code, khong can file anh). */
    struct Page { const char* title; juce::String body; int illustration = 0; };

    inline std::vector<Page> pages()
    {
        const auto app = juce::String::fromUTF8 (livent::branding::appDisplayName);
        const auto r1  = juce::String::fromUTF8 (livent::branding::fxNameRemix1);
        const auto r2  = juce::String::fromUTF8 (livent::branding::fxNameRemix2);
        auto v = [] (const char* s) { return livent::vn (s); };

        std::vector<Page> p;

        p.push_back ({ "Kích hoạt bản quyền",
            v ("KÍCH HOẠT BẢN QUYỀN\n\n"
               "Bước 1 - Lấy mã máy\n"
               "  • Vào Cài đặt (nút bánh răng) > Bản quyền & Bảo mật > bấm \"Nhập mã bản quyền\".\n"
               "  • Bấm CHÉP MÃ MÁY rồi gửi mã này cho người bán (Zalo / tin nhắn).\n"
               "  • Mỗi máy có một mã riêng. Cài lại Windows / thay ổ cứng / thay bo mạch thì mã có thể đổi - gửi lại mã mới.\n\n"
               "Bước 2 - Dán key\n"
               "  • Người bán gửi lại một KEY dài. Chép TOÀN BỘ key (đừng để thiếu ký tự đầu / cuối).\n"
               "  • Dán vào ô \"Dán toàn bộ key vào đây\" rồi bấm KÍCH HOẠT.\n"
               "  • Thành công: hiện tên chủ máy và hạn dùng (hoặc \"Vĩnh viễn\").\n\n"
               "Nếu báo \"Key không đúng\"\n"
               "  • Kiểm tra đã dán đủ key chưa, không có dấu cách thừa.\n"
               "  • Key chỉ dùng cho đúng máy đã gửi mã. Đổi máy thì gửi lại mã máy mới.\n\n"
               "Dùng thử / gia hạn\n"
               "  • Chưa có key: bấm DÙNG THỬ để dùng trong số ngày còn lại.\n"
               "  • Xem hạn dùng: Cài đặt > Bản quyền & Bảo mật (thẻ trên cùng).\n"
               "  • Gia hạn / đổi key: bấm \"Nhập mã khác\" ở cùng chỗ.") });

        p.push_back ({ "Bắt đầu: dự án",
            v ("TẠO / MỞ DỰ ÁN\n\n"
               "Dự án (.NT) lưu toàn bộ: track, VST, núm chỉnh, preset, vang, đường âm thanh.\n\n"
               "Tạo dự án mới\n"
               "  • Ở màn hình đầu chọn một MẪU (Hát live cơ bản, Song ca, Từ mẫu máy này, Dự án trống), đặt tên, chọn thư mục rồi bấm TẠO DỰ ÁN.\n"
               "  • Hoặc Tệp > Dự án mới.\n\n"
               "Mở dự án\n"
               "  • Danh sách \"Gần đây\" bên phải: bấm vào dự án để mở. Ghim dự án hay dùng lên đầu.\n"
               "  • Tệp > Mở file .NT... để mở file ở chỗ khác.\n\n"
               "Lưu\n"
               "  • Tệp > Lưu hoặc Lưu thành...\n"
               "  • Tệp > Tự động lưu (mỗi 60 giây) - nên bật.\n"
               "  • Tệp > Lưu thông số làm mặc định (cần mật khẩu F2) / Khôi phục thông số mặc định.\n\n"
               "Âm thanh chưa ra?\n"
               "  • Bấm F4 (Thiết lập âm thanh): chọn đúng soundcard, buffer 128-256.\n"
               "  • Cài đặt > Âm thanh > đường âm thanh: chọn đúng cổng vào míc / nhạc và cổng ra loa.") });

        p.push_back ({ "Bảng điều khiển",
            v ("BẢNG ĐIỀU KHIỂN (giao diện chính)\n\n"
               "Hàng trên\n"
               "  • Thu âm: ghi toàn bộ tiếng ra loa thành file. Bấm lần nữa để dừng và lưu.\n"
               "  • Cười: bảng tiếng cười / vỗ tay phát xen khi đang hát.\n"
               "  • Tên bài (chữ chạy) + thời gian: ở thanh dưới cùng. Rê chuột vào CPU xem thông số card.\n"
               "  • Góc dưới phải: ⚙ Cài đặt và ▾ Gọn (thu gọn).\n"
               "  • Tone bài (Key ‹ ›): Key gửi cho Auto-Tune. Chỉ đổi Key, KHÔNG đổi tông nhạc.\n"
               "      Chuột trái vào ô Key: chọn Key bằng tay. Chuột phải (Windows): chọn Dò AI / Dò tay.\n"
               "  • Tone nhạc (‹ 0.0 ›): nâng / hạ tông bản nhạc nửa nấc. Key Auto-Tune tự bù theo.\n"
               "      Bấm đúp số tone để về 0. Nút nguồn nhỏ bên cạnh = bật / tắt VST đổi tone.\n"
               "      Tiết kiệm CPU: tone = 0 thì VST đổi tone TỰ TẮT; bấm + / − thì TỰ BẬT rồi mới gửi tông. Vẫn bấm tay được.\n"
               "  • Dải chế độ: Đa thể loại / Nhạc trẻ / Bolero / Dân ca (xem mục Preset).\n\n"
               "Hàng nút hiệu ứng\n"
               "  • Tune: bật/tắt Auto-Tune. Chuột phải = mở cửa sổ VST Tune.\n"
               "  • Nhạc / Míc: bật / tắt tiếng nhạc, tiếng míc ra loa.\n"
               "  • Vang: bật / tắt toàn bộ vang + delay của míc.\n") +
            v ("  • Lofi, ") + r1 + ", " + r2 + v (", Em bé: bật / tắt các hiệu ứng giọng trên track MÍC.\n\n"
               "Hàng 7 núm\n"
               "  • Nhạc, Míc, Vang dài, Vang ngắn, Delay, Tốc độ tune, Flex tune.\n"
               "  • Kéo lên / xuống để chỉnh, bấm đúp để về mặc định.\n"
               "  • Mũi tên thu / mở để ẩn hàng núm cho gọn.\n\n"
               "Bảng chuột phải (chỉnh nhanh, hiện sát DAW, nổi trên YouTube)\n"
               "  • Chuột phải NHẠC: âm lượng Nhạc + Míc.\n"
               "  • Chuột phải VANG: Vang dài / Vang ngắn / Delay.\n"
               "  • Chuột phải MÍC: chỉ chỉnh Giảm ồn (0 % = tắt).\n"
               "    EQ, comp, Auto-Tune và thông số vang chỉnh trực tiếp trong VST.\n"
               "  • Chuột phải TUNE: mở cửa sổ Auto-Tune (như cũ).\n"
               "  • Thanh âm lượng có + / − mỗi lần 0,5 dB; Giảm ồn mỗi lần 5 %; giữ chuột chạy đều. Kéo thanh được\n"
               "    (giữ Shift = mịn), bấm đúp = về mặc định. Đóng: ✕, Esc hoặc bấm ra ngoài.\n"
               "  • Nút có bảng chuột phải có 3 chấm nhỏ ở góc.\n\n"
               "Mẹo: Cài đặt > Hướng dẫn > \"Chế độ chỉ dẫn rê chuột\" - rê chuột vào nút nào sẽ hiện giải thích nút đó.") });

        p.push_back ({ "Preset & Dân ca",
            v ("PRESET THỂ LOẠI\n\n"
               "Có 4 chế độ ghi sẵn trên bảng điều khiển: 1 Đa thể loại · 2 Nhạc trẻ · 3 Bolero · 4 Dân ca.\n\n"
               "Dùng preset\n"
               "  • Chuột trái vào tên chế độ để dùng (chế độ đang dùng sáng màu). Hoặc phím Ctrl+1 ... Ctrl+4.\n"
               "  • Áp preset đổi toàn bộ nút, núm và thông số VST (Auto-Tune, vang...).\n"
               "  • Preset KHÔNG đổi tone nhạc và Key bài đang hát.\n\n"
               "Lưu preset\n"
               "  • Chỉnh xong núm / VST theo ý rồi\n"
               "      chuột phải vào tên chế độ > \"Lưu thông số hiện tại vào ...\".\n"
               "  • Chuột phải còn có: Đổi tên, Làm bộ mặc định cho dự án mới, Xuất / Nhập file, Xóa thông số.\n"
               "  • Chế độ chưa lưu thông số thì chữ mờ.\n\n"
               "Chế độ Dân ca\n"
               "  • Preset nào có TÊN chứa chữ \"Dân ca\" thì khi chọn, Scale gửi cho Auto-Tune là DORIAN,\n"
               "    Key giữ nguyên. Chọn preset khác thì gửi lại Scale gốc của bài.\n"
               "  • Muốn tắt Dân ca: đổi tên preset đó (bỏ chữ \"Dân ca\") hoặc chọn preset khác.\n"
               "  • Auto-Tune để Scales: Modern? Chuột phải nút Dân ca > gạt \"Auto-Tune Modern Scale\"\n"
               "    (cùng một cài đặt với Cài đặt > VST > Auto-Tune). Bật Modern: chỉ chế độ Dân ca gửi\n"
               "    Dorian, các chế độ khác vẫn gửi Major / Minor theo Key bài.") });

        p.push_back ({ "VST & kích hoạt VST",
            v ("VST / HIỆU ỨNG\n\n"
               "Quét VST\n"
               "  • Cài VST xong: Cài đặt > VST / Hiệu ứng > Quét VST...\n"
               "  • VST nằm ở thư mục lạ: Thư mục quét VST... để thêm đường dẫn.\n\n"
               "Gắn VST vào track\n"
               "  • Bấm F2 mở Bàn làm việc (có mật khẩu) > chọn track > bấm ô VST trống để chọn plugin.\n"
               "  • Track NHẠC: ô 1 = VST đổi tone, ô 2 = Auto-Key (dò tone tay).\n"
               "  • Cửa sổ Auto-Key kéo đi đâu cũng được, phần mềm nhớ chỗ đó trên máy này. Khi cắt khung\n"
               "    có dải mỏng phía trên để kéo và nút ✕ tắt (đang giữ mở để tự bấm thì ✕ mờ).\n"
               "  • Track MÍC: ô 1 = Auto-Tune; các ô sau là hiệu ứng Lofi / Remix / Em bé\n    (bật chế độ chỉ dẫn rê chuột vào nút để xem đúng số ô).\n\n"
               "Cửa sổ kích hoạt / nhập key của VST bị che\n"
               "  • Từ bản 06/10: cửa sổ kích hoạt mà VST bật ra trong ") + app + v (" tự được đưa lên trên cùng.\n"
               "  • Nếu VST mở CHƯƠNG TRÌNH RIÊNG (IK Product Manager, Waves Central, iLok License Manager...):\n"
               "      Cài đặt > Bản quyền & Bảo mật > \"Tạm hạ ") + app + v (" xuống 60 giây\" (hoặc Tệp > Tạm hạ...).\n"
               "      Trong 60 giây đó DAW, YouTube, cửa sổ VST không nổi trên cùng nữa -> nhập key thoải mái.\n"
               "      Hết giờ tự nổi lại; muốn nổi lại ngay thì bấm lại mục đó.\n"
               "  • IK Multimedia (T-RackS, AmpliTube...) báo \"Can't find Authorization...\": đây là lỗi cài đặt của IK,\n"
               "    không phải lỗi DAW. Cài lại IK Product Manager rồi đăng nhập kích hoạt lại plugin.\n\n"
               "EQ míc (Waves Manny Marroquin EQ)\n"
               "  • Gắn VST EQ/comp vào track MÍC và mở cửa sổ VST để chỉnh. Chuột phải nút Míc chỉ còn Giảm ồn.\n"
               "  • Cài đặt > Gán nút > \"VST điều khiển\": Tự tìm (mặc định) / Chọn tay track + ô / Không dùng.\n"
               "  • Trong bảng: Nâng cao ▾ để đổi tần số từng dải, Bell / Shelf, đảo pha, mở cửa sổ VST.\n"
               "  • Nên giữ mỗi dải trong ±3 dB (vạch xanh). Quá ±3 dB thanh chuyển vàng + dòng cảnh báo\n"
               "    (dễ ù / đục / chói / mỏng).\n"
               "  • Nút \"Về preset\": các thanh quay về đúng số trong preset đang chọn (Auto-Tune giữ nguyên).\n\n"
               "Tiết kiệm CPU\n"
               "  • Cài đặt > VST / Hiệu ứng > Chế độ biểu diễn: giảm vẽ giao diện, ưu tiên âm thanh.") });

        p.push_back ({ "Bàn làm việc & Send",
            v ("BÀN LÀM VIỆC (F2) & BÀN TRỘN (F3)\n\n"
               "F2 - Bàn làm việc\n"
               "  • Danh sách track + Insert / Send. Có mật khẩu (đổi ở Cài đặt > Bản quyền & Bảo mật).\n"
               "  • G / H: thu / phóng timeline khi Bàn làm việc đang mở. Space: phát / dừng.\n\n"
               "F3 - Bàn trộn\n"
               "  • Fader, pan, mute / solo từng track, đồng hồ mức.\n\n"
               "Thanh Send (vang, delay...)\n"
               "  • Mỗi Send là một thanh màu: kéo NGANG để chỉnh mức, số dB hiện ngay trong thanh.\n"
               "  • Giữ Shift khi kéo = chỉnh mịn. Bấm đúp = về 0 dB. Lăn chuột = ±0.5 dB.\n"
               "  • Chip SAU / TRƯỚC: gửi sau fader (cam) hoặc trước fader (xanh).") });

        p.push_back ({ "Thu âm & cắt ghép",
            v ("THU ÂM & CẮT GHÉP SÓNG (trong Bàn làm việc F2)\n\n"
               "Thu\n"
               "  • Bật chấm đỏ ● ở track MÍC (và NHẠC nếu cần) > ● THU. Space = dừng.\n"
               "  • Giọng tự được bù trễ của card nên khớp nhạc. File thu 32-bit float.\n"
               "  • Thu đè như thường: cứ bấm THU. Muốn GIỮ lại từng lần hát để chọn câu hay: bật nút \"Lane\" ở track (xem bài \"Thu đè & các Lần\").\n"
               "  • Giọng thu tự dịch sớm đúng bằng độ trễ để khớp nhạc: Cài đặt > Âm thanh > Bù trễ thu âm / đo trễ card.\n"
               "  • App tắt đột ngột khi đang thu: mở lại dự án sẽ hỏi khôi phục bản thu.\n\n"
               "Thanh công cụ (trên đầu vùng sóng)\n"
               "  • Mũi tên = Chọn · Kéo cắt = Cắt (bấm lên đoạn là cắt, Esc về Chọn) · Nối · Xoá · M tắt tiếng.\n"
               "  • Bắt dính Bật / Tắt · Hoàn tác · Làm lại · + Nhập file · Video · Chỉnh phô (ARA).\n"
               "  • Bên phải: G / H thu phóng · về đầu bài · PHÁT · DỪNG · THU · đồng hồ · XUẤT.\n"
               "  • Thước thời gian dưới thanh: bấm / kéo = đặt đầu phát (vạch đỏ).\n\n"
               "Chuột trên sóng\n"
               "  • Giữ Ctrl (Mac: Cmd): hiện vạch vàng, bấm chuột trái = CẮT tại đó.\n"
               "  • Nửa DƯỚI đoạn: kéo = di chuyển, Alt + kéo = nhân bản. Bấm = chọn + đặt đầu phát.\n"
               "  • Nửa TRÊN đoạn hoặc chỗ trống: kéo = bôi đen vùng.\n"
               "  • Kéo mép trái / phải = tỉa. Kéo ô vuông ở 2 góc trên = fade vào / ra.\n"
               "  • Shift + bấm = chọn thêm. Chuột phải đoạn: cắt, nhân bản, tắt tiếng, nối, fade,\n"
               "    âm lượng từng đoạn, chỉnh phô (ARA).\n\n"
               "Phím\n"
               "  • S cắt tại đầu phát · Del xoá · M tắt tiếng · N nối đoạn liền nhau\n"
               "  • Ctrl+D nhân bản · Ctrl+A chọn hết · Ctrl+Z hoàn tác · Ctrl+Y làm lại · Esc bỏ chọn\n\n"
               "Xuất một đoạn\n"
               "  • Bôi đen > bấm P = khoá vùng xuất (2 vạch vàng). Shift+P = bỏ.\n"
               "  • XUẤT > Phạm vi \"Vùng khoá P\" (có đuôi vang để không cụt tiếng).\n\n"
               "Nhập file / Video\n"
               "  • + Nhập file (thanh công cụ) hoặc chuột phải chỗ trống trên track: WAV, MP3, FLAC,\n"
               "    MP4 / video (tự tách tiếng). File được chép vào thư mục _Audio của dự án.\n"
               "  • Nhập MP4 thì tự mở cửa sổ VIDEO chạy theo đầu phát (nút \"Video\" để mở / tắt).\n\n"
               "Chỉnh phô (ARA - Melodyne / Auto-Tune Pro bản VST3)\n"
               "  • Chọn đoạn > nút Chỉnh phô (hoặc chuột phải đoạn > Chỉnh phô (ARA)) > Mở bằng ...\n"
               "    sóng + nốt hiện ngay, không cần phát. Plugin chưa ra tiếng thì vẫn nghe bản gốc.\n"
               "  • Bấm đúp đoạn có dải tím để mở lại. Cắt / kéo đoạn vẫn giữ phần đã chỉnh.\n"
               "  • Nhớ LƯU dự án: phần chỉnh nằm trong file dự án. Bỏ chỉnh phô = về bản gốc.") });

        p.push_back ({ "Thu đè & các Lần",
            v ("NÚT \"Lane\" - MỖI LẦN THU LÀ MỘT \"LẦN N\"\n\n"
               "Ý chính: lần thu MỚI NHẤT luôn nằm ở HÀNG TRÊN CÙNG (hàng nghe được, gọi là COMP) và là lần được phát.\n"
               "Các lần cũ không mất: chúng được cất ở các hàng \"Lần 1, Lần 2...\" bên dưới.\n\n"
               "Nút \"Lane\" nằm cạnh chấm đỏ ● và nút loa của track MÍC / NHẠC.\n"
               "  • TẮT (mặc định): thu đè như DAW thường, không sinh Lần nào.\n"
               "  • BẬT: mỗi lần bấm THU là một Lần mới, kể cả track còn trống hoặc đầu phát đứng ngoài đoạn đã có. Nút được nhớ theo dự án.\n"
               "  • Tắt nút chỉ ngừng sinh Lần MỚI; các Lần đã có vẫn còn, xóa bằng chuột phải vào Lần.\n"
               "  • Không đổi được nút lúc đang thu.\n\n"
               "Cách dùng\n"
               "  • Bật nút Lane + chấm đỏ ● ở track MÍC > ● THU > hát > DỪNG.\n"
               "  • Lane BẬT, hát lần đầu ở track trống: lần đó là \"Lần 1\", hàng Lần mở ngay.\n"
               "  • Lane BẬT, thu đè lên track đã có tiếng: bên trái track hiện nhãn cam \"2 lần ▾\". Bấm nhãn để mở / đóng các hàng Lần.\n"
               "  • Tiếng cũ có sẵn trước khi thu được gom nguyên vẹn vào \"Lần 1\"; lần vừa thu là \"Lần 2\", lần sau nữa là \"Lần 3\"...\n"
               "  • ▶ cạnh tên Lần: GIỮ chuột để nghe thử lần đó, thả ra là tự về bản đang phát (không sợ quên tắt).\n"
               "  • Chuột phải một Lần: Dùng cả lần này / Nghe thử lần này / Xóa lần này\n"
               "    (file thu vẫn còn trên đĩa, Ctrl+Z lấy lại).\n\n"
               "Cần nhớ\n"
               "  • Các hàng Lần chỉ để CHỌN. Muốn cắt, tỉa, fade, kéo dời, chỉnh âm lượng thì làm ở hàng trên cùng như bình thường.\n"
               "  • \"Tắt tiếng đoạn\" (phím M) là im thật sự, không lộ lần bên dưới ra.\n"
               "    Đoạn đã tắt tiếng cất vào Lần vẫn GIỮ tắt tiếng; lấy lại cả lần cũ cũng không làm nó ra tiếng lại.\n"
               "  • Chỉ nên bật chấm đỏ cho MÍC. Nếu NHẠC cũng đang đỏ, phần mềm sẽ hỏi một lần trước khi thu.\n"
               "  • Đang thu đè thì chưa bấm được các hàng Lần; thu xong mới chọn.\n"
               "  • Dự án cũ đã có Lần từ trước thì nút Lane tự BẬT khi mở."), 1 });

        p.push_back ({ "Ghép câu (lấy câu hay)",
            v ("GHÉP CÂU - LẤY ĐÚNG CÂU HAY TỪ CÁC LẦN\n\n"
               "  1. Bấm nhãn \"N lần ▾\" để mở các hàng Lần.\n"
               "  2. Bấm nút cam \"✂ Ghép câu\" ở góc phải hàng trên cùng để BẬT.\n"
               "  3. QUÉT chuột (kéo) trên một Lần qua đúng câu muốn lấy: câu đó nhảy lên hàng trên cùng và mang màu của Lần đó.\n"
               "     BẤM một cái (không kéo) lên Lần = lấy cả lần đó.\n"
               "  4. Làm tiếp các câu khác nếu cần, xong thì bấm lại nút Ghép câu để tắt.\n\n"
               "Đọc màu\n"
               "  • Trên mỗi Lần, phần SÁNG có dải màu + chữ \"đang dùng\" là phần đang được phát ở hàng trên cùng; phần TỐI là chưa dùng.\n"
               "  • Đoạn ở hàng trên cùng mang màu của Lần mà nó lấy ra.\n\n"
               "Chỗ nối\n"
               "  • Mép mỗi câu được nối mượt khoảng 10 ms (hai tiếng chồng nhẹ vào nhau) nên không bị tách / lụp bụp.\n"
               "  • Sai chỗ nào: Ctrl+Z hoàn tác từng lần ghép.\n\n"
               "Sau khi ghép\n"
               "  • Hàng trên cùng là đoạn bình thường: vẫn cắt, tỉa, fade, chỉnh âm lượng, chỉnh phô được.\n"
               "  • Nghe thử một Lần thay vì bản đang phát: giữ chuột vào nút ▶ của Lần đó."), 2 });

        p.push_back ({ "Thu đè một đoạn (bôi đen)",
            v ("THU ĐÈ MỘT ĐOẠN - \"PUNCH\" BẰNG VÙNG BÔI ĐEN\n\n"
               "Cách 1 - có bôi đen (chính xác nhất)\n"
               "  • Kéo bôi đen đúng đoạn muốn hát lại (ví dụ câu thứ 3), rồi bấm ● THU.\n"
               "  • Anh cứ vào sớm một chút (chạy đà) và dừng thừa ra cũng được: phần nghe được chỉ đổi ở ĐÚNG vùng bôi đen.\n"
               "  • Ngoài vùng bôi đen vẫn là bản cũ. Cả lần thu vẫn giữ nguyên trong Lần mới nên không mất gì.\n"
               "  • Quên bỏ vùng bôi đen cũ ở chỗ khác (không dính vào lần thu): phần mềm tự bỏ qua, lần thu mới vẫn lên hàng nghe được.\n\n"
               "Cách 2 - không bôi đen\n"
               "  • Bấm ● THU như thường: lần thu mới tạm thay hết đoạn mà nó phủ lên ở hàng trên cùng.\n"
               "  • Muốn chỉ giữ vài câu của lần mới: bật ✂ Ghép câu và QUÉT đúng các câu đó trên Lần MỚI NHẤT.\n"
               "    Phần còn lại tự trở về đúng bản cũ trước khi thu.\n"
               "  • Nếu quét trên một Lần khác (cũ hơn), phần mềm hiểu là anh chấp nhận lần mới như đang nghe, chỉ thêm câu vừa quét.\n\n"
               "Mẹo\n"
               "  • Muốn lấy lại cả bản cũ: chuột phải Lần cũ > Dùng cả lần này.\n"
               "    Khúc trống của bản cũ (chỗ anh đã xóa tiếng thừa) cũng trở lại IM, không còn tiếng lần mới ở đó.\n"
               "  • Hát thử nhiều lần cho cùng một câu: cứ thu đè tiếp, mỗi lần là một Lần mới, rồi nghe thử bằng ▶ và ghép câu hay nhất."), 3 });

        p.push_back ({ "Bù trễ thu âm",
            v ("BÙ TRỄ THU ÂM - GIỌNG THU KHỚP NHẠC\n\n"
               "Vì sao cần\n"
               "  • Tiếng míc đi qua card âm thanh nên bị trễ vài chục ms so với nhạc anh đang nghe. Nếu không bù, giọng thu sẽ lệch chậm so với nhạc.\n"
               "  • Phần mềm dịch bản thu sớm đúng bằng độ trễ đó, nên lúc phát lại giọng khớp nhạc. Việc này CHỈ đặt bản thu cho đúng chỗ,\n"
               "    KHÔNG làm giọng anh nghe trong lúc hát bị trễ thêm.\n\n"
               "Chỉnh\n"
               "  • Cài đặt > Âm thanh > \"Bù trễ thu âm / đo trễ card\".\n"
               "  • Driver thường báo THIẾU độ trễ thật của card. Muốn chính xác: nối dây từ NGÕ RA của card vào NGÕ VÀO,\n"
               "    vặn nhỏ loa / tai nghe, dừng nhạc rồi bấm \"Đo trễ tự động\" > \"Dùng số đo\".\n"
               "  • Hoặc kéo ô \"Bù thêm (ms)\" bằng tay; bấm đúp thanh để về 0.\n"
               "  • Bảng cho biết: độ trễ card báo, độ trễ nhạc anh nghe thêm (SoundShifter, plugin ÂM THANH RA...) và độ trễ giọng anh nghe lại.\n\n"
               "Mẹo giảm trễ khi hát live\n"
               "  • Buffer 128 (F4) nếu máy chịu được; plugin nặng (Auto-Tune bản chất lượng cao...) nên chọn chế độ độ trễ thấp (Low Latency) lúc hát.\n"
               "  • Plugin 32-bit chạy qua cầu nối thường trễ thêm ~10 ms: nếu có bản 64-bit thì dùng, hoặc đặt plugin đó ở Master / tắt khi hát live.")});

        p.push_back ({ "Thanh thu gọn",
            v ("THANH THU GỌN\n\n"
               "Khi hát chỉ cần vài nút: bấm \"▾ Gọn\" trên thanh trên cùng (hoặc phím F8).\n"
               "Mặc định thanh gọn tự SÁT MÉP DƯỚI, ngay trên taskbar. Chuột phải nút \"▾ Gọn\" để chọn\n"
               "sát mép DƯỚI / TRÊN / tự do rồi thu gọn luôn.\n\n"
               "  • Bảng điều khiển thu thành thanh 2 hàng, nổi trên cùng.\n"
               "  • Hàng trên: Thu · tên bài (chữ chạy) · thời gian · Key ‹ › · Tone ‹ › · Preset · Cười · ▴ ✕\n"
               "  • Hàng dưới: Tune, Nhạc, Míc, Vang, Lofi, ") + r1 + ", " + r2 + v (", Em bé.\n"
               "  • Nắm LOGO bên trái để kéo thanh đi chỗ khác.\n"
               "  • ▴ (hoặc F8) = mở lại giao diện đầy đủ.  ✕ = đóng phần mềm.\n"
               "  • Phần mềm nhớ đang gọn hay đầy đủ và vị trí thanh cho lần mở sau.\n"
               "  • Chuột phải vào LOGO thanh gọn: Sát mép DƯỚI / Sát mép TRÊN / Tự do (để đâu nhớ đó).\n"
               "    Đang sát mép thì kéo logo chỉ trượt ngang, thanh vẫn dính mép.\n"
               "  • Thanh gọn và giao diện đầy đủ nhớ chỗ RIÊNG: thu / mở không bị nhảy chỗ.") });

        p.push_back ({ "Phím tắt",
            v ("PHÍM TẮT\n\n"
               "  F2          Bàn làm việc (track, VST) - có mật khẩu\n"
               "  F3          Bàn trộn\n"
               "  F4          Thiết lập âm thanh\n"
               "  F5          Giao diện màu\n"
               "  F6          Bật / tắt sóng nhạc trên nút\n"
               "  F7          Hiện / ẩn nút BÉ\n"
               "  F8          Thu gọn / mở lại bảng điều khiển\n"
               "  Ctrl+1..4   Dùng chế độ 1 .. 4\n"
               "  Space       Phát / dừng (timeline)\n"
               "  G / H       Thu / phóng timeline (khi mở F2)\n"
               "  Ctrl+bấm    Cắt sóng tại chuột (Mac: Cmd+bấm)\n"
               "  S / Del / M Cắt tại đầu phát / xoá / tắt tiếng đoạn chọn\n"
               "  N           Nối các đoạn liền nhau đã chọn\n"
               "  P / Shift+P Khoá vùng xuất theo vùng bôi đen / bỏ khoá\n"
               "  Ctrl+Z / Y  Hoàn tác / làm lại sửa sóng\n"
               "  Esc         Thoát chế độ chỉ dẫn rê chuột, đóng hộp thoại") });

        p.push_back ({ "Sự cố thường gặp",
            v ("SỰ CỐ THƯỜNG GẶP\n\n"
               "Tiếng rè, lụp bụp\n"
               "  • Xem số CPU góc dưới: cao quá 70-80% -> F4 tăng buffer (256 / 512) hoặc bớt VST.\n"
               "  • Bật Chế độ biểu diễn (Cài đặt > VST / Hiệu ứng).\n\n"
               "Không ra tiếng\n"
               "  • F4: kiểm tra đúng soundcard, đúng cổng ra.\n"
               "  • Nút Nhạc / Míc trên bảng điều khiển phải đang sáng.\n\n"
               "VST báo thiếu / không mở được\n"
               "  • Cài lại VST đó rồi Quét VST lại. VST 32-bit cần cầu nối LiveNTBridge32.\n\n"
               "Cửa sổ kích hoạt bị che\n"
               "  • Xem mục \"VST & kích hoạt VST\": Tạm hạ phần mềm xuống 60 giây.\n\n"
               "Cần hỗ trợ\n"
               "  • Cài đặt > Bản quyền & Bảo mật: thẻ trên cùng có số liên hệ (bấm để chép).\n"
               "  • Cài đặt > VST / Hiệu ứng > Mở nhật ký quét / Ghi thông số VST ra file để gửi kỹ thuật.") });

        return p;
    }


    //=========================================================================
    // Hinh minh hoa 3 bai Lane (ve bang code, khong can file anh -> khong doi CMake)
    //=========================================================================
    namespace art
    {
        inline juce::Colour blue()   { return juce::Colour (0xff3f86e8); }
        inline juce::Colour orange() { return juce::Colour (0xfff0a030); }

        inline void wave (juce::Graphics& g, juce::Rectangle<float> r, juce::Colour c, float seed)
        {
            g.setColour (c);
            for (float x = r.getX() + 2.0f; x < r.getRight() - 1.0f; x += 2.0f)
            {
                const float a = 0.18f + 0.72f * std::abs (std::sin (x * 0.061f + seed) * std::sin (x * 0.017f + seed * 2.3f));
                const float h = a * (r.getHeight() - 8.0f) * 0.5f;
                g.drawVerticalLine ((int) x, r.getCentreY() - h, r.getCentreY() + h);
            }
        }

        inline void tag (juce::Graphics& g, juce::Rectangle<float> r, const juce::String& text, juce::Colour fill, juce::Colour ink)
        {
            g.setColour (fill);
            g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
            g.setColour (ink);
            g.setFont (juce::FontOptions (11.0f, juce::Font::bold));
            g.drawText (text, r.toNearestInt(), juce::Justification::centred);
        }

        inline void clip (juce::Graphics& g, juce::Rectangle<float> r, juce::Colour c, float seed, const juce::String& label = {})
        {
            if (r.getWidth() < 2.0f) return;
            g.setColour (c.withMultipliedBrightness (0.34f).withAlpha (0.96f));
            g.fillRoundedRectangle (r, 3.0f);
            {
                juce::Graphics::ScopedSaveState keep (g);
                g.reduceClipRegion (r.toNearestInt());
                wave (g, r, c.brighter (0.15f), seed);
            }
            g.setColour (c.withAlpha (0.85f));
            g.drawRoundedRectangle (r, 3.0f, 1.0f);
            if (label.isNotEmpty())
                tag (g, juce::Rectangle<float> (0, 0, (float) label.length() * 6.6f + 16.0f, 16.0f).withCentre (r.getCentre()),
                     label, juce::Colours::black.withAlpha (0.55f), juce::Colours::white);
        }

        // phan chua dung cua mot Lan: toi di; phan dang dung: dai mau + chu "dang dung"
        inline void usage (juce::Graphics& g, juce::Rectangle<float> r, juce::Colour c, float fromX, float toX, bool pill = true)
        {
            juce::Graphics::ScopedSaveState keep (g);
            g.reduceClipRegion (r.toNearestInt());
            g.setColour (juce::Colours::black.withAlpha (0.38f));
            g.fillRect (juce::Rectangle<float> (r.getX(), r.getY(), fromX - r.getX(), r.getHeight()));
            g.fillRect (juce::Rectangle<float> (toX, r.getY(), r.getRight() - toX, r.getHeight()));
            g.setColour (c.brighter (0.25f));
            g.fillRect (juce::Rectangle<float> (fromX, r.getY(), toX - fromX, 3.0f));
            if (pill && toX - fromX > 74.0f)
                tag (g, juce::Rectangle<float> (fromX + 4.0f, r.getY() + 6.0f, 60.0f, 14.0f), livent::vn ("đang dùng"), c.withAlpha (0.92f), juce::Colours::black);
        }

        inline void rowHead (juce::Graphics& g, juce::Rectangle<float> r, const juce::String& name, bool play, juce::Colour bar = {})
        {
            if (! bar.isTransparent()) { g.setColour (bar); g.fillRect (r.withWidth (3.0f)); }
            g.setColour (Col::text);
            g.setFont (juce::FontOptions (12.0f, juce::Font::bold));
            g.drawText (name, r.toNearestInt().withTrimmedLeft (8).withTrimmedRight (play ? 30 : 0), juce::Justification::centredLeft);
            if (play)
            {
                auto b = juce::Rectangle<float> (22.0f, 16.0f).withCentre ({ r.getRight() - 16.0f, r.getCentreY() });
                g.setColour (Col::panel2); g.fillRoundedRectangle (b, 3.0f);
                juce::Path t; const auto c = b.getCentre();
                t.addTriangle (c.x - 3.5f, c.y - 4.5f, c.x - 3.5f, c.y + 4.5f, c.x + 4.5f, c.y);
                g.setColour (Col::text); g.fillPath (t);
            }
        }

        inline void note (juce::Graphics& g, juce::Rectangle<int> r, const juce::String& text, bool strong = false)
        {
            g.setColour (strong ? Col::text : Col::textDim);
            g.setFont (juce::FontOptions (12.0f, strong ? juce::Font::bold : juce::Font::plain));
            g.drawFittedText (text, r, juce::Justification::centredLeft, 3);
        }

        inline int heightFor (int id) { return id == 1 ? 196 : id == 2 ? 232 : id == 3 ? 296 : 0; }

        /** Bai 1: thu lan 1 (mot hang)  ->  thu de lan 2 (COMP + 2 Lan). */
        inline void lesson1 (juce::Graphics& g, juce::Rectangle<int> a)
        {
            const float leftW = (float) a.getWidth() * 0.30f;
            const auto L = juce::Rectangle<float> ((float) a.getX() + 12.0f, (float) a.getY() + 30.0f, leftW - 20.0f, 150.0f);
            const auto R = juce::Rectangle<float> ((float) a.getX() + leftW + 24.0f, (float) a.getY() + 30.0f, (float) a.getWidth() - leftW - 36.0f, 150.0f);
            note (g, a.withHeight (22).withTrimmedLeft (12), livent::vn ("1. Hát lần đầu"), true);
            note (g, a.withHeight (22).withTrimmedLeft ((int) (leftW + 24.0f)), livent::vn ("2. Thu đè lên (lần 2)"), true);

            g.setColour (Col::bg); g.fillRoundedRectangle (L, 5.0f); g.fillRoundedRectangle (R, 5.0f);
            const float head = 74.0f;
            // trai
            rowHead (g, juce::Rectangle<float> (L.getX(), L.getY() + 8.0f, head, 40.0f), "MIC", false);
            clip (g, juce::Rectangle<float> (L.getX() + head, L.getY() + 8.0f, L.getWidth() - head - 8.0f, 40.0f), blue(), 1.0f, livent::vn ("Lần 1"));
            note (g, juce::Rectangle<int> ((int) L.getX() + 8, (int) L.getY() + 60, (int) L.getWidth() - 16, 60), livent::vn ("Chỉ có 1 hàng,\nchưa có gì để chọn."));
            // phai
            rowHead (g, juce::Rectangle<float> (R.getX(), R.getY() + 8.0f, head, 40.0f), "MIC", false);
            tag (g, juce::Rectangle<float> (R.getX() + 40.0f, R.getY() + 29.0f, 60.0f, 16.0f), livent::vn ("2 lần ▾"), orange(), juce::Colours::black);
            const float cx = R.getX() + head + 20.0f, cw = R.getWidth() - head - 28.0f;
            clip (g, { cx, R.getY() + 8.0f, cw, 40.0f }, orange(), 2.0f, livent::vn ("Lần 2 · đang phát"));
            g.setColour (Col::line); g.drawHorizontalLine ((int) (R.getY() + 54.0f), R.getX(), R.getRight());
            rowHead (g, { R.getX(), R.getY() + 60.0f, head + 20.0f, 34.0f }, livent::vn ("Lần 1"), true, blue());
            clip (g, { cx, R.getY() + 60.0f, cw, 34.0f }, blue(), 1.0f);
            usage (g, { cx, R.getY() + 60.0f, cw, 34.0f }, blue(), cx, cx, false);
            rowHead (g, { R.getX(), R.getY() + 98.0f, head + 20.0f, 34.0f }, livent::vn ("Lần 2"), true, orange());
            clip (g, { cx, R.getY() + 98.0f, cw, 34.0f }, orange(), 2.0f);
            usage (g, { cx, R.getY() + 98.0f, cw, 34.0f }, orange(), cx, cx + cw, true);
            note (g, a.withTrimmedTop (a.getHeight() - 16).withTrimmedLeft ((int) (leftW + 24.0f)), livent::vn ("Lần cũ không mất: cất ở các hàng Lần, giữ ▶ để nghe thử."));
            // mui ten
            juce::Path arrow; const float ay = L.getCentreY();
            arrow.startNewSubPath (L.getRight() + 3.0f, ay); arrow.lineTo (R.getX() - 3.0f, ay);
            g.setColour (Col::textDim); g.strokePath (arrow, juce::PathStrokeType (2.0f));
            juce::Path head2; head2.addTriangle (R.getX() - 3.0f, ay, R.getX() - 10.0f, ay - 5.0f, R.getX() - 10.0f, ay + 5.0f); g.fillPath (head2);
        }

        /** Bai 2: Ghep cau - quet tren Lan 1 lay mot cau len COMP. */
        inline void lesson2 (juce::Graphics& g, juce::Rectangle<int> a)
        {
            const auto P = a.toFloat().reduced (12.0f, 4.0f).withTrimmedTop (22.0f).withTrimmedBottom (22.0f);
            g.setColour (Col::bg); g.fillRoundedRectangle (P, 5.0f);
            note (g, a.withHeight (22).withTrimmedLeft (12), livent::vn ("Bật ✂ Ghép câu, rồi QUÉT trên Lần 1 qua câu muốn lấy"), true);
            const float head = 96.0f, cx = P.getX() + head, cw = P.getWidth() - head - 12.0f;
            const float y0 = P.getY() + 8.0f;
            const float qa = cx + cw * 0.38f, qb = cx + cw * 0.64f;

            rowHead (g, { P.getX() + 2.0f, y0, head - 4.0f, 44.0f }, "MIC", false);
            tag (g, { P.getX() + 44.0f, y0 + 14.0f, 56.0f, 16.0f }, livent::vn ("2 lần ▾"), orange(), juce::Colours::black);
            tag (g, { P.getRight() - 106.0f, y0 - 4.0f, 98.0f, 20.0f }, juce::String::fromUTF8 ("\xe2\x9c\x82 ") + livent::vn ("Ghép câu"), orange(), juce::Colours::black);
            // COMP: cam | xanh | cam
            clip (g, { cx, y0 + 16.0f, qa - cx, 30.0f }, orange(), 2.0f);
            clip (g, { qa, y0 + 16.0f, qb - qa, 30.0f }, blue(), 1.4f, livent::vn ("từ Lần 1"));
            clip (g, { qb, y0 + 16.0f, cx + cw - qb, 30.0f }, orange(), 2.7f);
            g.setColour (Col::line); g.drawHorizontalLine ((int) (y0 + 54.0f), P.getX(), P.getRight());

            const float y1 = y0 + 60.0f, y2 = y1 + 46.0f;
            rowHead (g, { P.getX() + 2.0f, y1, head, 40.0f }, livent::vn ("Lần 1"), true, blue());
            clip (g, { cx, y1, cw, 40.0f }, blue(), 1.4f);
            usage (g, { cx, y1, cw, 40.0f }, blue(), qa, qb, true);
            // vung quet
            g.setColour (juce::Colours::white.withAlpha (0.16f)); g.fillRect (juce::Rectangle<float> (qa, y1 - 2.0f, qb - qa, 44.0f));
            g.setColour (juce::Colours::white.withAlpha (0.9f));
            g.drawRect (juce::Rectangle<float> (qa, y1 - 2.0f, qb - qa, 44.0f), 1.5f);
            g.setFont (juce::FontOptions (12.0f, juce::Font::bold));
            g.drawText (livent::vn ("← quét →"), juce::Rectangle<float> (qa, y1 + 22.0f, qb - qa, 16.0f).toNearestInt(), juce::Justification::centred);

            rowHead (g, { P.getX() + 2.0f, y2, head, 40.0f }, livent::vn ("Lần 2"), true, orange());
            clip (g, { cx, y2, cw, 40.0f }, orange(), 2.4f);
            {
                juce::Graphics::ScopedSaveState keep (g);
                g.reduceClipRegion (juce::Rectangle<float> (cx, y2, cw, 40.0f).toNearestInt());
                g.setColour (juce::Colours::black.withAlpha (0.38f)); g.fillRect (juce::Rectangle<float> (qa, y2, qb - qa, 40.0f));
                g.setColour (orange().brighter (0.25f));
                g.fillRect (juce::Rectangle<float> (cx, y2, qa - cx, 3.0f)); g.fillRect (juce::Rectangle<float> (qb, y2, cx + cw - qb, 3.0f));
            }
            note (g, a.withTrimmedTop (a.getHeight() - 20).withTrimmedLeft (12), livent::vn ("Quét một câu = lấy câu đó  ·  Bấm một cái = lấy cả lần  ·  Sai thì Ctrl+Z"));
        }

        /** Bai 3: boi den mot doan roi thu - chi doan do doi tren COMP. */
        inline void lesson3 (juce::Graphics& g, juce::Rectangle<int> a)
        {
            const auto P = a.toFloat().reduced (12.0f, 2.0f);
            g.setColour (Col::bg); g.fillRoundedRectangle (P, 5.0f);
            const float head = 96.0f, cx = P.getX() + head, cw = P.getWidth() - head - 12.0f;
            const float sa = cx + cw * 0.40f, sb = cx + cw * 0.62f;
            float y = P.getY() + 6.0f;

            note (g, { (int) P.getX() + 8, (int) y, (int) P.getWidth() - 16, 18 }, livent::vn ("Trước: bôi đen đúng câu muốn hát lại, rồi bấm ● THU"), true);
            y += 22.0f;
            rowHead (g, { P.getX() + 2.0f, y, head - 4.0f, 40.0f }, "MIC", false);
            clip (g, { cx, y, cw, 40.0f }, blue(), 1.2f, {});
            g.setColour (juce::Colours::white.withAlpha (0.20f)); g.fillRect (juce::Rectangle<float> (sa, y - 2.0f, sb - sa, 44.0f));
            g.setColour (juce::Colours::white.withAlpha (0.9f)); g.drawRect (juce::Rectangle<float> (sa, y - 2.0f, sb - sa, 44.0f), 1.5f);
            tag (g, juce::Rectangle<float> (0, 0, 60.0f, 16.0f).withCentre ({ (sa + sb) * 0.5f, y + 20.0f }), livent::vn ("bôi đen"), juce::Colours::white.withAlpha (0.85f), juce::Colours::black);
            y += 52.0f;

            g.setColour (Col::line); g.drawHorizontalLine ((int) y, P.getX(), P.getRight());
            y += 6.0f;
            note (g, { (int) P.getX() + 8, (int) y, (int) P.getWidth() - 16, 18 }, livent::vn ("Sau: chỉ vùng bôi đen đổi trên hàng trên cùng; cả lần thu vẫn giữ trong Lần 2"), true);
            y += 22.0f;
            rowHead (g, { P.getX() + 2.0f, y, head - 4.0f, 40.0f }, "MIC", false);
            tag (g, { P.getX() + 44.0f, y + 12.0f, 56.0f, 16.0f }, livent::vn ("2 lần ▾"), orange(), juce::Colours::black);
            clip (g, { cx, y, sa - cx, 40.0f }, blue(), 1.2f);
            clip (g, { sa, y, sb - sa, 40.0f }, orange(), 2.6f);
            clip (g, { sb, y, cx + cw - sb, 40.0f }, blue(), 3.1f);
            y += 46.0f;
            const float ra = cx + cw * 0.34f, rb = cx + cw * 0.70f;
            rowHead (g, { P.getX() + 2.0f, y, head, 34.0f }, livent::vn ("Lần 1"), true, blue());
            clip (g, { cx, y, cw, 34.0f }, blue(), 1.2f);
            usage (g, { cx, y, cw, 34.0f }, blue(), cx, cx, false);
            {
                juce::Graphics::ScopedSaveState keep (g);
                g.reduceClipRegion (juce::Rectangle<float> (cx, y, cw, 34.0f).toNearestInt());
                g.setColour (juce::Colours::black.withAlpha (0.0f));
                g.setColour (blue().brighter (0.25f));
                g.fillRect (juce::Rectangle<float> (cx, y, sa - cx, 3.0f)); g.fillRect (juce::Rectangle<float> (sb, y, cx + cw - sb, 3.0f));
                g.setColour (juce::Colours::black.withAlpha (0.38f)); g.fillRect (juce::Rectangle<float> (sa, y, sb - sa, 34.0f));
            }
            y += 40.0f;
            rowHead (g, { P.getX() + 2.0f, y, head, 34.0f }, livent::vn ("Lần 2"), true, orange());
            clip (g, { ra, y, rb - ra, 34.0f }, orange(), 2.6f);
            usage (g, { ra, y, rb - ra, 34.0f }, orange(), sa, sb, false);
            tag (g, { sa + 3.0f, y + 6.0f, 60.0f, 14.0f }, livent::vn ("đang dùng"), orange().withAlpha (0.92f), juce::Colours::black);
            note (g, { (int) ra - 150, (int) y + 8, 146, 18 }, livent::vn ("cả lần thu (vào sớm) ›"));
        }

        inline void paint (juce::Graphics& g, int id, juce::Rectangle<int> area)
        {
            g.setColour (Col::panel2);
            g.fillRoundedRectangle (area.toFloat(), 6.0f);
            g.setColour (Col::line);
            g.drawRoundedRectangle (area.toFloat().reduced (0.5f), 6.0f, 1.0f);
            auto inner = area.reduced (4);
            if (id == 1) lesson1 (g, inner);
            else if (id == 2) lesson2 (g, inner);
            else if (id == 3) lesson3 (g, inner);
        }
    }

    class Illustration final : public juce::Component
    {
    public:
        void setId (int newId) { id = newId; repaint(); }
        int  getId() const noexcept { return id; }
        void paint (juce::Graphics& g) override { if (id > 0) art::paint (g, id, getLocalBounds()); }
    private:
        int id = 0;
    };

    class GuideComponent final : public juce::Component
    {
    public:
        explicit GuideComponent (int startPage)
        {
            content = pages();

            for (int i = 0; i < (int) content.size(); ++i)
            {
                auto* b = nav.add (new juce::TextButton (livent::vn (content[(size_t) i].title)));
                b->setClickingTogglesState (true);
                b->setRadioGroupId (7301);
                b->setColour (juce::TextButton::buttonColourId, Col::panel);
                b->setColour (juce::TextButton::buttonOnColourId, Col::accent.withAlpha (0.85f));
                b->setColour (juce::TextButton::textColourOffId, Col::text);
                b->setColour (juce::TextButton::textColourOnId, Col::onAccent);
                b->setConnectedEdges (0);
                b->onClick = [this, i] { showPage (i); };
                addAndMakeVisible (b);
            }

            text.setMultiLine (true, true);
            text.setReadOnly (true);
            text.setCaretVisible (false);
            text.setScrollbarsShown (true);
            text.setFont (juce::Font (juce::FontOptions (14.5f)));
            text.setColour (juce::TextEditor::backgroundColourId, Col::bg);
            text.setColour (juce::TextEditor::textColourId, Col::text);
            text.setColour (juce::TextEditor::outlineColourId, Col::line);
            text.setColour (juce::TextEditor::focusedOutlineColourId, Col::line);
            text.setIndents (14, 12);
            addAndMakeVisible (text);
            addChildComponent (picture);

            showPage (juce::jlimit (0, (int) content.size() - 1, startPage));
            setSize (860, 680);
        }

        void paint (juce::Graphics& g) override
        {
            g.fillAll (Col::panel);
            g.setColour (Col::textDim);
            g.setFont (juce::Font (juce::FontOptions (11.0f).withStyle ("Bold")).withExtraKerningFactor (0.12f));
            g.drawText (livent::vn ("MỤC LỤC"), 14, 10, 180, 18, juce::Justification::centredLeft, false);
        }

        void resized() override
        {
            auto r = getLocalBounds().reduced (10);
            auto left = r.removeFromLeft (200);
            left.removeFromTop (24);
            for (auto* b : nav)
            {
                b->setBounds (left.removeFromTop (34));
                left.removeFromTop (4);
            }
            r.removeFromLeft (10);
            layoutRight (r);
        }

    private:
        void showPage (int i)
        {
            if (! juce::isPositiveAndBelow (i, (int) content.size()))
                return;
            nav[i]->setToggleState (true, juce::dontSendNotification);
            text.setText (content[(size_t) i].body, false);
            text.moveCaretToTop (false);
            picture.setId (content[(size_t) i].illustration);
            picture.setVisible (content[(size_t) i].illustration > 0);
            if (! lastRight.isEmpty()) layoutRight (lastRight);
        }

        void layoutRight (juce::Rectangle<int> r)
        {
            lastRight = r;
            const int h = art::heightFor (picture.getId());
            if (h > 0 && r.getHeight() > h + 160)
            {
                picture.setBounds (r.removeFromTop (h));
                r.removeFromTop (8);
                picture.setVisible (true);
            }
            else
                picture.setVisible (false);
            text.setBounds (r);
        }

        std::vector<Page> content;
        juce::OwnedArray<juce::TextButton> nav;
        juce::TextEditor text;
        Illustration picture;
        juce::Rectangle<int> lastRight;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (GuideComponent)
    };
}
