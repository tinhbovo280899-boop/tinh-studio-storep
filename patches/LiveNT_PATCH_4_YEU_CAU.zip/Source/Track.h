#pragma once
#include "CheckedAudioReader.h"

#include <JuceHeader.h>
#include <cmath>
#include <array>
#include <functional>
#include "PluginChain.h"
#include "ChannelEq.h"
#include "BuiltinDenoise.h"   // 12s: giam on co san (track MIC)
#include "BuiltinFx.h"   // 12r: pre-delay / do rong / ne giong / lech L/R + nen giong (co san, khong phai VST)
#include "DeClick.h"

/**
    Track - mot duong tin hieu, tuong duong track cua Cubase.

    Loai track:
      Audio  - lay tu duong vao card (mic, nhac cu)
      Beat   - nhac nen: duong vao card HOAC file trong may
      Group  - gom nhieu track lai de chinh chung
      FxBus  - chi nhan tin hieu qua Send (cho nhet vang)
      Output - track ra tong, luon co dung mot cai, chi nhet insert, KHONG co send
      PK     - track PHU KIEM (Moc 28). Cung dac biet nhu Output, nhung:
                 * dau VAO cua no la DAU RA cua mot track khac -- anh chon
                   track nao thi no "nghe trom" track do (MIC, NHAC, hay ca
                   AM THANH RA);
                 * dau RA cua no do thang ra card, chon duoc NHIEU cap cong
                   giong AM THANH RA.
               Dung de day mot ban tron KHAC ra duong khac: vd loa nghe ban
               day du, con Link 7/8 chi day rieng tieng mic sang Cubase.

    Duong di:  nguon -> inserts -> fader/pan -> track dich (out)
                                             -> cac send
*/
class Track
{
public:
    /*  THEM LOAI MOI PHAI THEM O CUOI.

        File .NT ghi loai track bang SO THU TU trong danh sach nay. Chen mot
        loai vao giua la moi so phia sau xe dich mot bac -- mo lai du an cu
        se thay track FX bien thanh track Output. Them o cuoi thi cac so cu
        giu nguyen.  */
    /*  THEM LOAI MOI PHAI THEM O CUOI - file .NT ghi loai bang so thu tu.

        MOC 51: them Input - "track cong vao".

        Day la track nhan tieng THANG tu card, va cac track khac lay tieng tu
        no thay vi lay thang tu cong. Y tuong lay tu Cubase (ho goi la Input
        Bus, xem bang Audio Connections).

        Duoc gi so voi cach cu (moi track tu cam mot cong):

          * Mot cong dung cho NHIEU track. Truoc day muon co hai duong mic
            (mot de hat, mot de noi chuyen, hieu ung khac nhau) thi phai mo
            cung mot cong o hai track - card khong phai luc nao cung cho.

          * Dat plugin DUNG CHUNG. Con nen hay EQ chong hu dat mot lan o
            track cong vao, moi track lay ve deu da qua no. Truoc day phai nap
            mot ban rieng cho tung track, ton CPU va chinh thi phai chinh het.

        Track Input KHONG hien o giao dien chinh, chi hien o ban tron - vi no
        khong phai thu anh dong toi luc dang hat.  */
    enum class Type   { Audio, Beat, Group, FxBus, Output, PK, Input, OutputBus };

    /*  MOC 51: TrackTap = lay tieng tu DAU RA cua mot track Input, va lay
        SAU khi qua day plugin cua track do (user chot huong nay).  */
    enum class Source { HardwareInput, AudioFile, TrackTap };
    enum class Chan   { Mono, Stereo };

    /* V5.7: vai tro he thong tach khoi TEN hien thi. Khach doi ten/kéo track
       khong duoc lam nut MÍC/NHẠC/AUTO TUNE/BÈ mat dich. */
    enum class Role
    {
        None = 0, Music, Mic, ReverbLong, ReverbShort, Delay,
        MainOutput, InputMusic, InputMic
    };

    /** Mot moi Send: gui bao nhieu sang track nao. */
    struct Send
    {
        int   targetId  = 0;        // id cua track nhan
        float levelDb   = -6.0f;
        bool  enabled   = true;

        /*  MOC 63: gui vao DUONG VAO PHU cua mot plugin, thay vi vao duong
            chinh cua track.

            -1  = gui binh thuong (vao buffer cua track dich)
            >=0 = gui vao sidechain cua o insert thu may tren track dich

            Vi du: track MIC gui vao sidechain cua con nen dat o o 1 tren
            track NHAC -> nhac tu nho xuong moi khi anh cat tieng hat.  */
        int   targetSlot = -1;

        /*  06/10: TRUOC / SAU fader (giong Cubase).
            false = SAU fader (mac dinh, mau cam): keo volume track thi vang
                    giam theo.
            true  = TRUOC fader (mau xanh): vang gui di khong phu thuoc
                    volume track - ha fader ve 0 van con nghe vang.
            Nut M / Loa van cat ca hai kieu.  */
        bool  preFader = false;
    };

    ChannelEq& getChannelEq() noexcept { return channelEq; }
    /** Legacy spatial-effect state: retained for old projects/presets, not processed. */
    livent::builtinfx::SpaceFx& getSpaceFx() noexcept { return spaceFx; }
    const livent::builtinfx::SpaceFx& getSpaceFx() const noexcept { return spaceFx; }
    /** 12r: nen giong co san. 12s: KHONG con chay (thay bang Giam on), chi giu de doc / ghi du an cu. */
    livent::builtinfx::VoiceLeveler& getLeveler() noexcept { return leveler; }
    const livent::builtinfx::VoiceLeveler& getLeveler() const noexcept { return leveler; }
    /** 12s: giam on co san (dung tren track MIC), dat TRUOC chuoi VST. */
    livent::builtinfx::NoiseReducer& getDenoise() noexcept { return denoise; }
    const livent::builtinfx::NoiseReducer& getDenoise() const noexcept { return denoise; }
    /** 12r: chuoi luu gon (du an + preset). 12s: them phan thu 3 "dn=.." (du an cu khong co -> tat). */
    juce::String getBuiltinFxString() const { return spaceFx.toString() + "|" + leveler.toString() + "|" + denoise.toString(); }
    void setBuiltinFxString (const juce::String& s)
    {
        if (s.isEmpty()) return;
        juce::StringArray parts;
        parts.addTokens (s, "|", {});
        spaceFx.fromString (parts[0]);
        leveler.fromString (parts[1]);
        if (parts.size() >= 3) denoise.fromString (parts[2]);   // preset cu (chua co giam on): giu nguyen muc dang dung
    }
    const ChannelEq& getChannelEq() const noexcept { return channelEq; }

    Track (int trackId, Type trackType, const juce::String& trackName, juce::Colour c);
    ~Track();

    //=========================================================================
    int          getId()     const noexcept { return id; }
    const juce::String& getUuid() const noexcept { return uuid; }
    void setUuid (const juce::String& u) { if (u.isNotEmpty()) uuid = u; }
    Role getRole() const noexcept { return role; }
    void setRole (Role r) noexcept { role = r; }

    /*  MOC 46: dat lai ma so. CHI dung sau khi nhan doi track.

        Ma so binh thuong do Mixer cap va khong bao gio doi -- moi thu dinh
        tuyen (send tro toi bus nao, track do vao dau) deu ghi bang ma so, doi
        ma so giua chung la dut het cac moi noi. Rieng luc nhan doi thi ban
        sao vua doc de ma so cua ban goc, phai dat lai ngay.  */
    void setId (int newId) noexcept   { id = newId; }
    Type         getType()   const noexcept { return type; }
    juce::String getName()   const          { return name; }
    juce::Colour getColour() const noexcept { return colour; }

    void setName (const juce::String& n)  { name = n; }
    void setColour (juce::Colour c)       { colour = c; }

    juce::String getTypeName() const;

    //=========================================================================
    //  Routing
    //=========================================================================
    Source getSource() const noexcept        { return source.load (std::memory_order_acquire); }
    void   setSource (Source s) noexcept     { source.store (s, std::memory_order_release); }

    Chan   getChannelMode() const noexcept   { return channelMode; }
    void   setChannelMode (Chan c)           { channelMode.store (c); }

    void setInputChannels (int left, int right);
    int  getInputLeft()  const noexcept { return inputLeft.load(); }
    int  getInputRight() const noexcept { return inputRight.load(); }

    /*  Track dich nhan tin hieu ra. 0 = chua gan (se do thang vao Output).

        MOC 28: rieng track PK thi o nay mang nghia NGUOC LAI -- no la track
        NGUON ma PK nghe trom, chu khong phai noi PK do tieng vao. Dung chung
        mot o cho hai viec de khoi phai them mot truong nua vao file .NT, va
        vi hai viec do khong bao gio xay ra tren cung mot track.  */
    /*  MOC 35: track MAC DINH - khong xoa duoc.

        NHAC, MIC va ba bus vang deu la bo khung co dinh cua mot buoi hat.
        Xoa nham mot cai giua buoi dien la mat tieng ngay, va dung lai thi
        phai gan lai insert lan send tu dau. Nen chan han o Mixer::removeTrack.

        Track anh TU THEM sau nay thi khong dat co nay, xoa binh thuong.  */
    //=========================================================================
    void setFixed (bool f) noexcept   { fixedTrack.store (f); }
    bool isFixed() const noexcept     { return fixedTrack.load(); }

    /*  MOC 51: track Input nao dang cap tieng cho track nay.

        Chi co nghia khi source == TrackTap. Luu rieng chu khong dung chung
        voi outputTargetId: track thuong vua LAY tu mot track Input vua DO ra
        mot track dich, hai thu do khac nhau va ton tai cung luc.  */
    void setInputTrackId (int trackId) noexcept   { inputTrackId.store (trackId); }
    int  getInputTrackId() const noexcept         { return inputTrackId.load(); }

    // Additional output buses: -1 = silent, 0 = sum of routed tracks
    // (legacy behaviour), positive = copy this processed source track.
    void setOutputBusSourceId (int trackId) noexcept { outputBusSourceId.store (juce::jmax (-1, trackId)); }
    int  getOutputBusSourceId() const noexcept { return outputBusSourceId.load(); }
    static constexpr int maxOutputMixSources = 32;
    int getOutputBusMixCount() const noexcept { return outputBusMixCount.load(); }
    int getOutputBusMixSource (int index) const noexcept
    { return index >= 0 && index < getOutputBusMixCount() ? outputBusMixSources[(size_t)index].load() : 0; }
    void setOutputBusMixSources (const juce::Array<int>& sources);
    void removeOutputBusMixSource (int sourceId);
    void addOutputMixTap (const Track& sourceTrack, int numSamples, float targetGain, int index, const juce::AudioBuffer<float>* compensated = nullptr);

    void setOutputTargetId (int trackId)   { outputTargetId.store (trackId); }
    int  getOutputTargetId() const noexcept { return outputTargetId.load(); }

    //=========================================================================
    //  MOC 28: CAC CAP CONG RA THAT tren card  (chi track Output va PK dung)
    //=========================================================================
    /*  Bang co: bit 0 = cap 1/2, bit 1 = cap 3/4, bit 3 = cap 7/8...

        Truoc day so nay nam trong Mixer vi chi co MOT track ra tong. Nay co
        them PK cung do thang ra card, va hai track phai ra HAI duong khac
        nhau -- nen so nay chuyen ve nam tren tung track.  */
    void setOutPairMask (juce::uint32 m) noexcept { outPairMask.store (m); }
    juce::uint32 getOutPairMask() const noexcept  { return outPairMask.load(); }

    bool isOutPairOn (int pairIndex) const noexcept
    {
        return juce::isPositiveAndBelow (pairIndex, 32)
            && (outPairMask.load() & (1u << pairIndex)) != 0;
    }

    void setOutPairOn (int pairIndex, bool shouldBeOn) noexcept
    {
        if (! juce::isPositiveAndBelow (pairIndex, 32))
            return;

        const juce::uint32 bit = 1u << pairIndex;
        const auto m = outPairMask.load();

        outPairMask.store (shouldBeOn ? (m | bit) : (m & ~bit));
    }

    //=========================================================================
    //  Send  (them/xoa theo y muon, khong tu sinh)
    //=========================================================================
    static constexpr int maxSends = 8;

    int  getNumSends() const;
    Send getSend (int index) const;
    /** 13/10: CHI audio thread (duoc goi duoi mixerLock). Khong cho khoa: neu UI dang sua send trung luc
        thi dung gia tri send DUNG GAN NHAT (lech toi da 1 khoi) thay vi coi nhu send bi tat - tranh
        ramp gain xuong 0 roi len lai + dung lai do thi dinh tuyen moi lan chen ngang. */
    Send getSendRT (int index) noexcept;
    void addSend (int targetTrackId, int targetSlot = -1);
    void removeSend (int index);
    void setSendTarget (int index, int targetTrackId, int targetSlot = -1);

    /** Khi hai insert tren track dich doi cho, Sidechain Send phai doi
        targetSlot theo de van tro dung plugin cu. */
    void swapSidechainSendTargetSlots (int targetTrackId, int slotA, int slotB);
    void moveSidechainSendTarget (int sourceTrackId, int sourceSlot, int destTrackId, int destSlot,
                                 bool movingSource);

    void setSendLevelDb (int index, float dB);
    void setSendEnabled (int index, bool on);
    void setSendPreFader (int index, bool pre);   // 06/10

    /** Cong tac tong: tat HET send cua track chi bang mot nut. */
    void setAllSendsOn (bool on)        { allSendsOn.store (on); }
    bool areAllSendsOn() const noexcept { return allSendsOn.load(); }

    /*  V5.8.3: trim tong cho cac SEND NGHE/FX cua mot track.

        Khac voi level cua tung Send: sendTrimDb khong pha huy ty le VANG DAI /
        VANG NGAN / DELAY ma nguoi dung da can rieng. Remote chinh chi can mot
        num SEND de nang/ha tat ca cung luc, con ba send con van giu level rieng.

        Sidechain send (targetSlot >= 0) KHONG di qua trim nay. Chinh vang tren
        remote khong duoc vo tinh lam compressor/ducking sidechain yeu theo.

        -60 dB duoc coi la tat han o Mixer::routeToTarget(). */
    void  setSendTrimDb (float dB) noexcept
    {
        sendTrimDb.store (juce::jlimit (-60.0f, 6.0f, dB));
    }
    float getSendTrimDb() const noexcept { return sendTrimDb.load(); }

    /** Cong tac tong cho CA chuoi insert. Tat la tin hieu di thang, khong
        qua plugin nao - dung de so sanh nhanh co/khong hieu ung, va de cuu
        khi mot plugin nao do dang an qua nhieu CPU giua luc dang hat. */
    void setAllInsertsOn (bool on)        { allInsertsOn.store (on); }
    bool areAllInsertsOn() const noexcept { return allInsertsOn.load(); }

    //=========================================================================
    //  File nhac nen
    //=========================================================================
    bool loadFile (const juce::File& file, juce::AudioFormatManager& formats,
                   juce::TimeSliceThread& readThread);
    void startPlayback();
    void stopPlayback();
    void setPlayPosition (double seconds);
    bool   isPlaying() const;
    double getPositionSeconds() const;
    double getLengthSeconds() const;
    // Media metadata survives an unavailable reader. getLoadedFile() returns
    // the project's reference; the file may be missing or undecodable.
    juce::String getFileName() const { return loadedFileName; }
    juce::File getLoadedFile() const { return juce::File (fileReferencePath); }
    bool hasFileReadError() const noexcept { return fileReadFailed.load (std::memory_order_acquire); }
    bool prepareFileExport(); // control thread, Mixer excludes callbacks
    /** 13/10: bao audio thread noi mem mau dau khoi ke tiep (vua bam Phat / tua / doi nguon). */
    void requestDeclick() noexcept { declickRequested.store (true, std::memory_order_release); }
    /** Audio thread, goi sau khi buffer da co nguon (file / clip / mic) va TRUOC insert. */
    void bridgeSource (int numSamples, bool forceArm) noexcept;

    /** 13/10: tron muot giua tin hieu mic dang nghe (live) va ban thu dang phat (clips) khi bam nut Loa,
        bat/tat phat... Chi audio thread dung (RecordingTimelineEngine::processTrackPreInsert). */
    struct SourceMix { livent::declick::GainSmoother live, clips; bool prevClips = false; };
    SourceMix& getSourceMix() noexcept { return sourceMix; }
    juce::uint64 getFileLockMissCount() const noexcept
    {
        return fileLockMissCount.load (std::memory_order_relaxed);
    }
    juce::uint64 getSendLockMissCount() const noexcept
    {
        return sendLockMissCount.load (std::memory_order_relaxed);
    }

    //=========================================================================
    //  Num chinh
    //=========================================================================
    void  setGainDb (float dB);
    float getGainDb() const noexcept  { return gainDb.load(); }
    /** D05: he so fader DUY NHAT cho moi duong (nghe, thu, xuat, tap, send sau fader). <= -59,9 dB = "-inf" = 0 chinh xac. */
    float getGainLinear() const noexcept { return gainLinear.load(); }

    void  setPan (float p);
    void applyPan (int numSamples) noexcept;
    float getPan() const noexcept     { return pan.load(); }

    /** D03: Mixer dang ky de biet NGAY khi mute/solo/monitor doi (anh huong nhac nghe duoc -> do bu take dang thu).
        Chi goi tren luong dieu khien; Mixer tu kiem tra luong. */
    std::function<void()> onAudibilityChanged;
    void  setMute (bool m)            { const bool was = muted.exchange (m); if (was != m) notifyAudibility(); }
    bool  isMuted() const noexcept    { return muted.load(); }
    void  setSolo (bool s)            { const bool was = soloed.exchange (s); if (was != s) notifyAudibility(); }
    bool  isSoloed() const noexcept   { return soloed.load(); }
    void  setMonitor (bool m)         { const bool was = monitorOn.exchange (m); if (was != m) notifyAudibility(); }
    bool  isMonitorOn() const noexcept{ return monitorOn.load(); }
    /** Lay-va-xoa so khoi bi chan vi plugin nha NaN/Inf (goi tu timer giao dien). */
    int   peekNonFiniteBlocks() const noexcept { return nonFiniteBlocks.load (std::memory_order_relaxed); }
    int   takeNonFiniteBlocks() noexcept { return nonFiniteBlocks.exchange (0, std::memory_order_relaxed); }
    /** C01: loi NaN/Inf CHO PHIEN XUAT. Khac nonFiniteBlocks (timer log doc roi xoa), co nay giu nguyen
        den khi bat dau phien xuat ke tiep -> xuat khong the "thanh cong" voi am thanh da bi xoa. */
    bool  hasExportNonFinite() const noexcept { return exportNonFinite.load (std::memory_order_relaxed) > 0; }
    void  clearExportNonFinite() noexcept { exportNonFinite.store (0, std::memory_order_relaxed); }

    float getMeterLevel() const noexcept { return meterLevel.load(); }
    /** 16/10: muc tung kenh (L, R) cho dong ho stereo. Cung quy tac giu/xa nhu getMeterLevel(). */
    float getMeterLevelL() const noexcept { return meterLevelL.load(); }
    float getMeterLevelR() const noexcept { return meterLevelR.load(); }

    //=========================================================================
    //  Chieu cao dong track trong danh sach (keo to/nho kieu Cubase)
    //=========================================================================
    static constexpr int defaultRowHeight = 96;
    static constexpr int minRowHeight     = 40;
    static constexpr int maxRowHeight     = 360;   // V6.3: phong waveform lon de canh take

    void setRowHeight (int h) { rowHeight.store (juce::jlimit (minRowHeight, maxRowHeight, h)); }
    int  getRowHeight() const noexcept { return rowHeight.load(); }

    // Display magnification only: never used by the audio/recording path.
    void setWaveformZoom (float zoom) noexcept
    {
        waveformZoom.store (std::isfinite (zoom) ? juce::jlimit (1.0f, 8.0f, zoom) : 1.0f);
    }
    float getWaveformZoom() const noexcept { return waveformZoom.load(); }

    PluginChain& getInserts() noexcept   { return inserts; }

    /** Luu / nap toan bo track (routing, num, insert, send). */
    std::unique_ptr<juce::XmlElement> getState (bool includePluginState = true) const;
    void setState (const juce::XmlElement& xml,
                   juce::AudioFormatManager* formats = nullptr,
                   juce::TimeSliceThread* readThread = nullptr,
                   bool deferPluginLoading = false);

    /** Restore mix/routing and insert settings without changing the track's
        audio file, name, UUID or timeline clips. Plugins are loaded later. */
    void restoreMixState (const juce::XmlElement& xml, bool deferPluginLoading = true);

    //=========================================================================
    //  Luong audio
    //=========================================================================
    void prepare (double sampleRate, int blockSize);
    void release();
    void clearBuffer (int numSamples);
    void readSource (const juce::AudioBuffer<float>& hardwareInput, int startSample, int numSamples);
    void copyFromTrackTap (const juce::AudioBuffer<float>& sourceBuffer,
                           int numSamples, float targetGain);
    void runInserts (int numSamples);
    void feedBuiltinKey (int numSamples) noexcept;   // 12s: chep tieng NHAC (sau VST) cho T-AutoKey co san
    void setOfflineRendering (bool on) noexcept { offlineRendering = on; silentSampleCount = 0; }

    /** Cong track vao mot bus voi ramp gain trong 1 block de keo volume / mute / send
        khong tao zipper/pop. routeIndex < 0 = duong chinh, 0..maxSends-1 = send. */
    void addToBus (juce::AudioBuffer<float>& destination, int numSamples,
                   float extraGain, int routeIndex = -1, bool applyFader = true, const juce::AudioBuffer<float>* compensated = nullptr);

    /** Trang thai ramp khi do Output/PK ra cong vat ly. Chi audio thread dung. */
    float getHardwareOutRampStart() const noexcept { return lastHardwareOutGain; }
    void  setHardwareOutRampTarget (float g) noexcept { lastHardwareOutGain = g; }

    void updateMeter (int numSamples);

    juce::AudioBuffer<float>& getBuffer() noexcept { return buffer; }

private:
    void notifyAudibility() { if (onAudibilityChanged) onAudibilityChanged(); }
    int          id;
    Type         type;
    juce::String uuid;
    Role         role = Role::None;
    juce::String name;
    juce::Colour colour;

    std::atomic<Source> source { Source::HardwareInput };
    std::atomic<Chan> channelMode { Chan::Stereo };
    std::atomic<int>  inputLeft   { 0 };
    std::atomic<int>  inputRight  { 1 };
    std::atomic<int>  outputTargetId { 0 };
    std::atomic<int>  inputTrackId   { 0 };   // MOC 51
    std::atomic<int>  outputBusSourceId { 0 };
    // -2 in outputBusSourceId selects this explicitly chosen mix.
    std::array<std::atomic<int>, maxOutputMixSources> outputBusMixSources {};
    std::atomic<int> outputBusMixCount { 0 };
    std::array<int, maxOutputMixSources> lastOutputMixIds {};
    std::array<float, maxOutputMixSources> lastOutputMixGains {};

    /*  MOC 28: cac cap cong ra that (bit 0 = cap 1/2). Chi track Output va
        PK dung toi; cac track khac de nguyen, khong anh huong gi.  */
    std::atomic<juce::uint32> outPairMask { 1u };
    std::atomic<bool> fixedTrack { false };   // MOC 35

    ChannelEq channelEq;
    livent::builtinfx::SpaceFx spaceFx;          // Legacy serialization only
    livent::builtinfx::VoiceLeveler leveler;     // 12r (12s: khong chay nua)
    livent::builtinfx::NoiseReducer denoise;     // 12s
    PluginChain inserts;

    juce::AudioBuffer<float> buffer;
    juce::MidiBuffer         midi;

    std::atomic<float> gainDb     { 0.0f };
    std::atomic<float> gainLinear { 1.0f };
    std::atomic<float> pan        { 0.0f };
    std::atomic<bool>  muted      { false };
    std::atomic<bool>  soloed     { false };
    std::atomic<bool>  monitorOn  { true };
    std::atomic<int>   nonFiniteBlocks { 0 };   // OUTPUT GUARD: so khoi plugin nha NaN/Inf (audio ghi, timer doc)
    std::atomic<int>   exportNonFinite { 0 };   // C01: nhu tren nhung KHONG bi timer xoa; chi xoa luc bat dau phien xuat
    std::atomic<float> meterLevel { 0.0f };
    std::atomic<float> meterLevelL { 0.0f };
    std::atomic<float> meterLevelR { 0.0f };
    std::atomic<int>   rowHeight  { defaultRowHeight };
    std::atomic<float> waveformZoom { 2.0f };

    /* V5.8.7 LIVE: cac bien nay CHI audio thread doc/ghi, khong can atomic.
       Giu gain cua block truoc de noi ramp lien tuc sang block sau. */
    float lastPanL = 1.0f, lastPanR = 1.0f;
    float lastMainRouteGain   = 0.0f;
    float lastSendRouteGain[maxSends] {};
    float lastTrackTapGain    = 0.0f;
    float lastHardwareOutGain = 0.0f;
    float meterRelease        = 0.90f;

    // 13/10 CHONG NO TIENG: noi mem nguon khi doi dot ngot + chuyen tiep cong tac INSERT tong.
    livent::declick::Bridge sourceBridge;
    SourceMix sourceMix;
    std::atomic<bool> declickRequested { false };
    bool  lastInsertsOn = true;
    int   insertsFadeLeft = 0, insertsFadeTotal = 1;
    juce::AudioBuffer<float> insertsDryScratch;

    Send sends[maxSends];
    Send rtSendCache[maxSends];            // 13/10: ban sao gan nhat audio thread doc duoc (chi audio thread dung)
    mutable juce::CriticalSection sendLock;
    mutable std::atomic<juce::uint64> sendLockMissCount { 0 };
    std::atomic<int>  numSends     { 0 };
    std::atomic<bool> allSendsOn   { true };
    std::atomic<float> sendTrimDb  { 0.0f };
    std::atomic<bool> allInsertsOn { true };

    // Persistent project reference, independent of the runtime reader below.
    // A failed interactive load must leave the current reference untouched.
    juce::String fileReferencePath;

    juce::AudioTransportSource                     transport;
    std::unique_ptr<livent::CheckedAudioReaderSource> readerSource;
    std::unique_ptr<livent::CheckedBufferingAudioSource> fileBuffering;
    std::atomic<bool> fileReadFailed { false };
    int                                            loadedFileChannels = 0;
    juce::String                                   loadedFileName;
    juce::CriticalSection                          fileLock;
    std::atomic<juce::uint64>                       fileLockMissCount { 0 };
    bool                                           transportPrepared = false;

    double currentSampleRate = 44100.0;

    /*  MOC 66: "Smart Silence" - dem so mau LIEN TUC im lang, va thoi gian
        an han (giay) truoc khi bat dau bo qua goi plugin. Xem runInserts().
        Khong can atomic: chi doc/ghi trong dung 1 ham, tren dung 1 luong
        (luong am thanh) - khong co luong nao khac dung toi 2 bien nay.  */
    int64_t silentSampleCount = 0;
    bool offlineRendering = false;
    static constexpr double silenceHoldSeconds = 3.0;
    int    currentBlockSize  = 512;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (Track)
};
