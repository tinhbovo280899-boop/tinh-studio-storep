#include "MainComponent.h"
#include "SendWarning.h"   // 12r
#include "WatchdogPolicy.h"
#include "UniqueRecordingFile.h"
#include "ControlLayoutStore.h"
#include "SafeFile.h"
#include "SafeAudioSettings.h"   // V5.2.1: MainComponent dung livent::safeaudio
#include "License.h"   // MOC 63: hien trang thai ban quyen o muc Lien he
#include "ActivationDialog.h"   // MOC 64: nhap key kich hoat thu cong tu menu
#include "ThemeChooser.h"         // V4.7: bo chon chu de dang card
#include "ButtonMap.h"              // 01/10: gan nut
#include "HelpOverlay.h"            // 02/10: nut ? huong dan
#include "TuneExtensionGuide.h"
#include "AudioSetupDialog.h"        // 14/10: Thiet lap am thanh kieu Cubase (gop soundcard + duong am thanh)
#include "ModeSwitch.h"             // 14/10: cong tac LIVE | THU
#include "TextScale.h"             // 14/10: co chu Cai dat / Huong dan
#include "GuideWindow.h"            // 06/10: huong dan chi tiet (Cai dat > Ban quyen)
#include "ForeignDialogRaiser.h"    // 06/10: cua so kich hoat VST khong bi che
#include "LatencyDialog.h"          // 13/10: bu tre thu + do tre card
#if JUCE_WINDOWS
#include "AudioSetupGuide.h"
#endif
#include "AppBranding.h"            // V6.4.0: dong ban quyen tren thanh tren
#include "OutputRouting.h"
#include "TrackGrouping.h"
#include "OutputBusSourceMenu.h"
#include "ProjectValidation.h"
#include "MissingPluginsDialog.h"    // 11j: bang plugin can kiem tra
#include "SidechainSources.h"        // 11j: nut SIDECHAIN tren cua so VST
#include "ExternalLaunch.h"           // 15/10: nut YouTube mo trinh duyet, nut Cuoi mo app ngoai

static constexpr int kMusicVst2Slot = 1; // o so 2 tren giao dien, index 1

namespace
{
    /*  30/09 (ban khach): chu thuong hieu canh logo TO - CAO - DAM.
        bigBrandTitle = true -> font Oswald SemiBold (chu cao, hep, co dau
        tieng Viet) nhung tu Resources/fonts. Thieu font -> Bold he thong. */
    juce::Font brandTitleFont (float normalSize, float bigSize)
    {
        if constexpr (! livent::branding::bigBrandTitle)
        {
           #if JUCE_WINDOWS
            // A native UI face keeps the small brand sharp on Windows too.
            return juce::Font (juce::FontOptions ("Segoe UI", normalSize, juce::Font::plain)
                                  .withStyle ("Semibold"));
           #else
            return juce::Font (juce::FontOptions (normalSize).withStyle ("SemiBold"));
           #endif
        }

        static juce::Typeface::Ptr tf = livent::fonts::loadEmbedded ("Oswald-SemiBold.ttf");
        if (tf != nullptr)
            return juce::Font (juce::FontOptions (tf).withHeight (bigSize)).withExtraKerningFactor (0.02f);
        return juce::Font (juce::FontOptions (bigSize * 0.85f).withStyle ("Bold"));
    }

    /** Chieu cao dai tieu de (logo + ten + nut). Chu thuong hieu to -> cao them 8. */
    constexpr int titleChromeHeight (bool vertical) noexcept
    {
        // 01/10 mau 2: thanh tren ngang = khoi bo goc 38 (4 tren + 38 + 2 duoi;
        // TonePanel them 4 nua -> cach khoi Tone dung 6 nhu giua cac khoi).
        if (livent::branding::equalSmallBlocks && ! vertical)
            return 44;
        return (vertical ? 76 : 42) + (livent::branding::bigBrandTitle ? 8 : 0);
    }

    /** 01/10 (khach VBK): chu ten to -> bo le trai cua Label (sat logo bang
        nua khoang cu) va day chu len 2 px cho can giua mat voi logo. */
    void nudgeBrandLabel (juce::Label& l)
    {
        if constexpr (livent::branding::bigBrandTitle)
            l.setBorderSize ({ 0, 1, 4, 2 });   // tren, trai, duoi, phai
        else
            juce::ignoreUnused (l);
    }

    /** Khoi bo goc cua thanh tren (mau 2), thang mep voi cac khoi TonePanel. */
    juce::Rectangle<int> topBlockBounds (int width) noexcept
    {
        return { 6, 4, juce::jmax (0, width - 12), 38 };
    }
}
#include "StabilityLog.h"
#include "MacOpenDocument.h"   // V6.6.3: companion app on macOS
#include "CompanionApps.h"     // 12u: nhieu app mo cung, tat LiveNT la tat het
#include "BrowserSession.h"    // 12u: trinh duyet YouTube mo / tat cung LiveNT

#include <vector>   // MOC 75: bang CAI DAT dung std::vector<SettingsItem>
#include <algorithm>
#include <string>   // Windows companion CreateProcessW command line
#include <cmath>     // V4.5: std::lround cho fade-in audio device

#if JUCE_WINDOWS
 #include <windows.h>   // HOTFIX17: watchdog thoat cung neu VST/driver treo trong teardown
 #include <tlhelp32.h>  // 14/10: liet ke luong de do CPU tung luong trong "Do giat tieng"
#else
 #include <sys/resource.h>   // 14/10: getrusage - do CPU ca app trong "Do giat tieng"
#endif

//  MOC 66: khai bao truoc - dinh nghia that nam duoi cung file, gan
//  loadUiScale()/setUiScale(), nhung constructor (o ngay duoi day) can goi
//  no som hon vi tri dinh nghia.
static bool loadAutosavePref();
static void saveAutosavePref (bool enabled);
static bool loadHarmonyButtonPref();
static void saveHarmonyButtonPref (bool enabled);
static bool loadVstGuiSafeModePref();
static void saveVstGuiSafeModePref (bool enabled);
static bool loadLiveModePref();   // 14/10
static void saveLiveModePref (bool enabled);
static bool loadLowLatencyLivePref();
static void saveLowLatencyLivePref (bool enabled);
static double loadRecordExtraMsPref();
static void saveRecordExtraMsPref (double ms);
static bool loadAutoKeyListenPref();
static bool loadBridge32SafetyPref();               // 11i
static bool saveBridge32SafetyPref (bool enabled);  // 11i
static bool saveAutoKeyListenPref (bool enabled);
static bool loadVerticalLayoutPref();
static void saveVerticalLayoutPref (bool enabled);
// 15/10: VST 32-bit ma may co ban 64-bit: 0 = luon hoi, 1 = luon doi 64-bit, 2 = luon giu 32-bit
static int  loadVst32UpgradePref();
static void saveVst32UpgradePref (int mode);

//  MOC 75: che do khoi dong cua giao dien - dinh nghia that nam gan
//  loadAutosavePref() o duoi, nhung constructor can goi som hon.
static int  loadStartupLayoutMode();
static void saveStartupLayoutMode (int mode);
static juce::String loadWorkPanelPassword();
static void saveWorkPanelPassword (const juce::String& password);
static bool loadWorkPanelPasswordRequired();
static bool saveWorkPanelPasswordRequired (bool required);
#if JUCE_MAC
static juce::String loadBrowserPref();
#endif

//=============================================================================
// V5.8.6 - Generic editor du phong cho VST2 32-bit khong co native editor.
// Moi thao tac di qua kenh control cua Bridge32, khong cham audio callback.
//=============================================================================
namespace
{
class Bridge32GenericEditor final : public juce::Component,
                                    private juce::Timer
{
public:
    Bridge32GenericEditor (std::shared_ptr<Bridge32Client> b,
                           std::function<void()> changed)
        : bridge (std::move (b)), onChanged (std::move (changed))
    {
        viewport.setViewedComponent (&content, false);
        viewport.setScrollBarsShown (true, false);
        addAndMakeVisible (viewport);

        if (! bridge)
        {
            setSize (620, 120);
            return;
        }

        const int total = bridge->getNumParameters();
        const int shown = juce::jmin (total, 256);

        for (int i = 0; i < shown; ++i)
        {
            Bridge32Client::ParamInfo info;
            juce::String err;
            if (! bridge->getParameterInfo (i, info, err))
                continue;

            auto* name = names.add (new juce::Label());
            name->setText (info.name.isNotEmpty() ? info.name
                                                  : livent::vn ("Thông số ") + juce::String (i + 1),
                           juce::dontSendNotification);
            name->setColour (juce::Label::textColourId, Col::text);
            name->setFont (juce::Font (juce::FontOptions (14.0f).withStyle ("Bold")));
            content.addAndMakeVisible (name);

            auto* slider = sliders.add (new juce::Slider());
            slider->setSliderStyle (juce::Slider::LinearHorizontal);
            slider->setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
            slider->setRange (0.0, 1.0, 0.0001);
            slider->setValue (info.value, juce::dontSendNotification);
            slider->setColour (juce::Slider::trackColourId, Col::accent.withAlpha (0.85f));
            slider->setColour (juce::Slider::thumbColourId, Col::text);
            content.addAndMakeVisible (slider);

            auto* value = values.add (new juce::Label());
            value->setText (formatDisplay (info), juce::dontSendNotification);
            value->setJustificationType (juce::Justification::centredRight);
            value->setColour (juce::Label::textColourId, Col::textDim);
            value->setFont (juce::Font (juce::FontOptions (13.0f)));
            content.addAndMakeVisible (value);

            const int rowIndex = (int) paramIndices.size();
            paramIndices.push_back (i);
            pendingValues.push_back (info.value);
            pendingDirty.push_back (0);
            refreshAfterSend.push_back (0);

            /* V6.4.6 - COALESCE PARAMETER.

               Ban cu moi pixel chuot = SET qua IPC + GET lai text qua IPC.
               Keo 100 pixel co the thanh 200 lenh dong bo, nen num cam giac
               bi dinh/giat. Gio Slider tu ve NGAY; moi 33 ms chi gui GIA TRI
               MOI NHAT. Nha chuot moi hoi display/label mot lan. */
            slider->onValueChange = [this, slider, value, rowIndex]
            {
                if (updating || ! bridge || ! juce::isPositiveAndBelow (rowIndex, (int) pendingValues.size()))
                    return;

                pendingValues[(std::size_t) rowIndex] = (float) slider->getValue();
                pendingDirty [(std::size_t) rowIndex] = 1;
                value->setText (juce::String (slider->getValue(), 4), juce::dontSendNotification);
            };

            slider->onDragEnd = [this, rowIndex]
            {
                if (juce::isPositiveAndBelow (rowIndex, (int) refreshAfterSend.size()))
                {
                    refreshAfterSend[(std::size_t) rowIndex] = 1;
                    pendingDirty[(std::size_t) rowIndex] = 1;
                }
            };
        }

        if (total > shown)
        {
            truncated.setText (livent::vn ("Plugin có ") + juce::String (total)
                               + livent::vn (" thông số; bảng nhẹ chỉ hiện 256 thông số đầu."),
                               juce::dontSendNotification);
            truncated.setColour (juce::Label::textColourId, Col::amber);
            truncated.setJustificationType (juce::Justification::centredLeft);
            content.addAndMakeVisible (truncated);
        }

        rowCount = sliders.size();
        content.setSize (680, juce::jmax (80, rowCount * rowH + (total > shown ? 32 : 8)));
        setSize (700, juce::jlimit (180, 620, content.getHeight() + 4));

        if (rowCount > 0)
            startTimerHz (30);   // du muot cho UI, giam rat manh so lenh IPC
    }

    void resized() override
    {
        viewport.setBounds (getLocalBounds());

        int y = 4;
        for (int i = 0; i < sliders.size(); ++i)
        {
            auto row = juce::Rectangle<int> (8, y, content.getWidth() - 24, rowH - 4);
            names[i]->setBounds (row.removeFromLeft (210));
            values[i]->setBounds (row.removeFromRight (130));
            sliders[i]->setBounds (row.reduced (8, 5));
            y += rowH;
        }

        if (truncated.isVisible())
            truncated.setBounds (12, y, content.getWidth() - 24, 26);
    }

private:
    void timerCallback() override
    {
        if (! bridge)
            return;

        for (int row = 0; row < (int) pendingDirty.size(); ++row)
        {
            if (pendingDirty[(std::size_t) row] == 0)
                continue;

            pendingDirty[(std::size_t) row] = 0;
            const int paramIndex = paramIndices[(std::size_t) row];
            const float v = pendingValues[(std::size_t) row];

            juce::String err;
            if (! bridge->setParameter (paramIndex, v, err))
            {
                if (juce::isPositiveAndBelow (row, values.size()))
                    values[row]->setText (err.isNotEmpty() ? err : livent::vn ("Lỗi"),
                                          juce::dontSendNotification);
                continue;
            }

            if (refreshAfterSend[(std::size_t) row] != 0)
            {
                refreshAfterSend[(std::size_t) row] = 0;
                Bridge32Client::ParamInfo refreshed;
                if (bridge->getParameterInfo (paramIndex, refreshed, err)
                    && juce::isPositiveAndBelow (row, values.size()))
                    values[row]->setText (formatDisplay (refreshed), juce::dontSendNotification);
            }

            if (onChanged)
                onChanged();
        }
    }

    static juce::String formatDisplay (const Bridge32Client::ParamInfo& info)
    {
        juce::String t = info.display;
        if (info.label.isNotEmpty())
            t << " " << info.label;
        if (t.trim().isEmpty())
            t = juce::String (info.value, 4);
        return t.trim();
    }

    std::shared_ptr<Bridge32Client> bridge;
    std::function<void()> onChanged;
    juce::Viewport viewport;
    juce::Component content;
    juce::OwnedArray<juce::Label> names, values;
    juce::OwnedArray<juce::Slider> sliders;
    juce::Label truncated;
    std::vector<int> paramIndices;
    std::vector<float> pendingValues;
    std::vector<unsigned char> pendingDirty, refreshAfterSend;
    bool updating = false;
    int rowCount = 0;
    static constexpr int rowH = 42;
};
}

//=============================================================================
// InspectorPanel
//=============================================================================
InspectorPanel::InspectorPanel (Mixer& m) : mixer (m)
{
    setLookAndFeel (&workspaceLook);
    auto caption = [this] (juce::Label& l)
    {
        l.setFont (juce::Font (juce::FontOptions (13.0f)));
        l.setColour (juce::Label::textColourId, Col::textDim);
        addAndMakeVisible (l);
    };

    titleLabel.setFont (juce::Font (juce::FontOptions (14.0f).withStyle ("Bold")));
    titleLabel.setText (livent::vn ("(chưa chọn track)"), juce::dontSendNotification);
    titleLabel.setColour (juce::Label::textColourId, cub::text);   // 06/10
    addAndMakeVisible (titleLabel);

    trackTypeLabel.setFont (juce::Font (juce::FontOptions (10.0f)));
    trackTypeLabel.setColour (juce::Label::textColourId, cub::text.withAlpha (0.8f));
    addAndMakeVisible (trackTypeLabel);
    for (auto* b : std::initializer_list<juce::Button*> { &trackMute, &trackSolo, &trackArm })
    {
        b->setClickingTogglesState (true);
        addAndMakeVisible (b);
    }
    trackArm.setColour (juce::TextButton::buttonOnColourId, cub::red);
    trackMute.setColour (juce::TextButton::buttonOnColourId, Col::amber);
    trackSolo.setColour (juce::TextButton::buttonOnColourId, Col::amber);
    trackMute.onClick = [this] { if (currentTrack) { currentTrack->setMute (trackMute.getToggleState()); if (onTrackChanged) onTrackChanged(); } };
    trackSolo.onClick = [this] { if (currentTrack) { currentTrack->setSolo (trackSolo.getToggleState()); if (onTrackChanged) onTrackChanged(); } };
    trackArm.onClick = [this] { if (currentTrack) { mixer.setTrackRecordArmed (*currentTrack, trackArm.getToggleState());
                                                    trackArm.setToggleState (mixer.isTrackRecordArmed (*currentTrack), juce::dontSendNotification);   // 14/10: Che do Live co the tu choi
                                                    if (onTrackChanged) onTrackChanged(); } };
    trackMonitor.setDrawBackground (true);
    trackMonitor.getProperties().set ("f2Compact", true);
    trackMonitor.setIconColours (Col::amber, cub::dim);
    trackMonitor.onClick = [this] { if (currentTrack) { currentTrack->setMonitor (trackMonitor.getToggleState()); if (onTrackChanged) onTrackChanged(); } };
    addAndMakeVisible (trackMonitor);
    overviewButton.onClick = [this] { if (currentTrack != nullptr && onOpenOverview) onOpenOverview(); };   // 14/10
    addChildComponent (overviewButton);
    channelMeter.getProperties().set ("f2Meter", true);
    channelMeter.getLevelSource = [this] { return currentTrack ? currentTrack->getMeterLevel() : 0.0f; };
    addAndMakeVisible (channelMeter);
    meterDbLabel.setFont (juce::Font (juce::FontOptions (13.0f)));
    meterDbLabel.setColour (juce::Label::textColourId, Col::amber);
    meterDbLabel.setJustificationType (juce::Justification::centred);
    addAndMakeVisible (meterDbLabel);
    caption (channelCaption);
    for (auto* v : { &insertViewport, &sendViewport })
    {
        v->setScrollBarsShown (true, false);
        v->setScrollBarThickness (7);
        v->getVerticalScrollBar().setAutoHide (true);
        addAndMakeVisible (v);
    }
    insertViewport.setViewedComponent (&insertContent, false);
    sendViewport.setViewedComponent (&sendContent, false);
    const auto insertHeightFile = PluginChain::getSettingsFolder().getChildFile ("inspector-inserts-height.txt");
    const int maximumInsertHeight = (PluginChain::maxSlots - 1) * workspace::insertPitch + workspace::insertHeight;
    if (insertHeightFile.existsAsFile())
        preferredInsertHeight = livent::inspectorInsertLayout::clampPreference (
            insertHeightFile.loadFileAsString().trim().getIntValue(), workspace::insertHeight, maximumInsertHeight);
    insertResizeHandle.setTooltip (livent::vn ("Kéo lên/xuống để thu gọn hoặc kéo dài danh sách INSERT"));
    insertResizeHandle.onStart = [this] { insertDragStartHeight = insertViewport.getHeight(); };
    insertResizeHandle.onDrag = [this, maximumInsertHeight] (int delta)
    {
        preferredInsertHeight = livent::inspectorInsertLayout::clampPreference (
            insertDragStartHeight + delta, workspace::insertHeight, maximumInsertHeight);
        resized();
    };
    insertResizeHandle.onFinish = [this, insertHeightFile]
    {
        insertHeightFile.replaceWithText (juce::String (preferredInsertHeight));
    };
    addAndMakeVisible (insertResizeHandle);

    // 14/10: o SEND keo gian duoc nhu o INSERT; nho chieu cao rieng (0 = tu dong nhu cu)
    const auto sendHeightFile = PluginChain::getSettingsFolder().getChildFile ("inspector-sends-height.txt");
    if (sendHeightFile.existsAsFile())
        preferredSendHeight = livent::inspectorSendLayout::clampPreference (sendHeightFile.loadFileAsString().trim().getIntValue());
    sendResizeHandle.setTooltip (livent::vn ("Kéo lên/xuống để thu gọn hoặc kéo dài danh sách SEND"));
    sendResizeHandle.onStart = [this] { sendDragStartHeight = sendViewport.getHeight(); };
    sendResizeHandle.onDrag = [this] (int delta)
    {
        preferredSendHeight = livent::inspectorSendLayout::clampPreference (juce::jmax (1, sendDragStartHeight + delta));
        resized();
    };
    sendResizeHandle.onFinish = [this, sendHeightFile]
    {
        sendHeightFile.replaceWithText (juce::String (preferredSendHeight));
    };
    addChildComponent (sendResizeHandle);

    //-- Bon muc thu gon duoc ------------------------------------------------
    for (auto* h : { &routingHeader, &eqHeader, &insertsHeader, &sendsHeader, &levelHeader })
    {
        h->setWorkspaceLook (true);
        h->onToggleOpen = [this] { resized(); };
        addAndMakeVisible (h);
    }

    addAndMakeVisible (eqPanel);
    eqHeader.setOpen (false, false);
    eqHeader.onPowerChanged = [this](bool on) { if (currentTrack) { currentTrack->getChannelEq().setEnabled(on); eqPanel.refresh(); if(onTrackChanged) onTrackChanged(); } };
    eqPanel.onExpand = [this](Track* t){if(onExpandEq)onExpandEq(t);};
    eqPanel.onChanged = [this] { if(currentTrack) eqHeader.setPowerState(currentTrack->getChannelEq().isEnabled()); if(onTrackChanged) onTrackChanged(); };

    /*  Cong tac tong cua ca chuoi insert. XANH = dang chay, DO = tat het.
        Tat la tin hieu di thang khong qua plugin nao - CPU tut ngay. */
    insertsHeader.onPowerChanged = [this] (bool on)
    {
        if (currentTrack == nullptr)
            return;

        currentTrack->setAllInsertsOn (on);
        if (onTrackChanged) onTrackChanged();

        // Tat tong -> den cua TUNG o phai tat theo, khong de moi cai mot phach
        for (auto* row : insertRows)
            row->setMasterOn (on);

        rebuildInserts();
        resized();
    };

    sendsHeader.onPowerChanged = [this] (bool on)
    {
        if (currentTrack == nullptr)
            return;

        currentTrack->setAllSendsOn (on);
        if (onTrackChanged) onTrackChanged();

        for (auto* row : sendRows)
            row->setMasterOn (on);

        rebuildSends();
        resized();
    };

    pkSourceLabel.setText (livent::vn ("Nghe:"), juce::dontSendNotification);   // MOC 28
    addAndMakeVisible (pkSourceLabel);

    caption (inLabel); caption (outLabel); caption (srcLabel); caption (pkSourceLabel);
    caption (gainCaption); caption (panCaption);

    //-- Routing -------------------------------------------------------------
    inputBox.onChange = [this]
    {
        if (currentTrack == nullptr || inputBox.getSelectedId() <= 0)
            return;

        const int l = inputBox.getSelectedId() - 1;
        currentTrack->setInputChannels (l, l + 1);
        if (onTrackChanged) onTrackChanged();
    };
    addAndMakeVisible (inputBox);

    channelModeBox.addItem ("Mono", 1);
    channelModeBox.addItem ("Stereo", 2);
    channelModeBox.onChange = [this]
    {
        if (currentTrack == nullptr)
            return;

        currentTrack->setChannelMode (channelModeBox.getSelectedId() == 2
                                          ? Track::Chan::Stereo : Track::Chan::Mono);

        rebuildRouting();   // danh sach cong doi giua "le" va "theo cap"
        if (onTrackChanged) onTrackChanged();
    };
    addAndMakeVisible (channelModeBox);

    outputBox.onChange = [this]
    {
        if (currentTrack == nullptr || outputBox.getSelectedId() <= 0)
            return;

        /*  MOC 40: chon "Khong nghe gi" thi ghi 0 vao o nguon. Mixer tim
            track co ma so 0 se khong thay gi, nen PK ngoi im -- dung y.  */
        const int chosen = outputBox.getSelectedId();

        currentTrack->setOutputTargetId (chosen == pkSourceNone ? 0 : chosen);
        if (onTrackChanged) onTrackChanged();
    };

    // MOC 26b: track AM THANH RA dung nut nay thay cho hop xo
    outPairsButton.onClick = [this] { showOutPairsMenu(); };
    addAndMakeVisible (outPairsButton);
    addAndMakeVisible (outputBox);

    /*  MOC 52: danh sach that (Duong vao truc tiep + cac MONO IN/STEREO IN
        dang co) duoc nap lai trong setTrack() - o day chi noi day su kien.
        Bo hoan toan muc "File nhac trong may".  */
    sourceBox.onChange = [this]
    {
        if (currentTrack == nullptr)
            return;

        const int id = sourceBox.getSelectedId();

        if (currentTrack->getType() == Track::Type::OutputBus)
        {
            if (sourceBox.getSelectedId() == livent::outputSource::mixChoice
                || sourceBox.getSelectedId() == livent::outputSource::mixEditChoice)
            {
                sourceBox.setSelectedId (livent::outputSource::choice (currentTrack->getOutputBusSourceId()), juce::dontSendNotification);
                juce::Component::SafePointer<InspectorPanel> safe (this);
                livent::outputSource::show (sourceBox, mixer, currentTrack->getId(), [safe]
                {
                    if (safe == nullptr) return;
                    if (safe->onTrackChanged) safe->onTrackChanged();
                    safe->rebuildRouting(); safe->resized();
                });
                return;
            }
            if (mixer.setOutputBusSource (currentTrack->getId(), livent::outputSource::source (id)))
                if (onTrackChanged) onTrackChanged();
            rebuildRouting();
            resized();
            return;
        }

        if (id >= inputTrackIdBase)
        {
            currentTrack->setSource (Track::Source::TrackTap);
            currentTrack->setInputTrackId (id - inputTrackIdBase);
            if (onTrackChanged) onTrackChanged();
        }

        rebuildRouting();
        resized();
    };
    addAndMakeVisible (sourceBox);

    openFileButton.onClick = [this] { chooseAudioFile(); };
    addAndMakeVisible (openFileButton);

    playButton.setClickingTogglesState (true);
    playButton.setColour (juce::TextButton::buttonOnColourId, Col::green.darker (0.35f));
    playButton.onClick = [this]
    {
        if (currentTrack == nullptr)
            return;

        if (playButton.getToggleState()) currentTrack->startPlayback();
        else                             currentTrack->stopPlayback();
    };
    addAndMakeVisible (playButton);

    fileLabel.setFont (juce::Font (juce::FontOptions (12.0f)));
    fileLabel.setColour (juce::Label::textColourId, Col::textDim);
    addAndMakeVisible (fileLabel);

    //-- Sends ---------------------------------------------------------------
    addSendButton.onClick = [this] { showAddSendMenu(); };
    sendContent.addAndMakeVisible (addSendButton);


    //-- Volume / Pan --------------------------------------------------------
    gainSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    gainSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 54, 18);
    gainSlider.setRange (-60.0, 6.0, 0.1);
    gainSlider.setTextValueSuffix (" dB");
    gainSlider.setColour (juce::Slider::thumbColourId, Col::accent);
    gainSlider.getProperties().set ("inspectorChannelControl", true);

    /*  MOC 52: bam DUP vao thanh truot la ve dung 0 dB ngay lap tuc.

        Truoc day keo tay khong bao gio trung dung 0.0 - thanh dai 66 dB ma
        chi rong vai chuc pixel, keo hut mot cai la lech thanh 1.5 hay 2.6 dB
        ngay. Day la cach chuan cua moi DAW: bam dup la ve mac dinh.  */
    gainSlider.setDoubleClickReturnValue (true, 0.0);

    gainSlider.onValueChange = [this]
    {
        if (currentTrack != nullptr)
        {
            currentTrack->setGainDb ((float) gainSlider.getValue());
            if (onTrackChanged) onTrackChanged();
        }
    };
    addAndMakeVisible (gainSlider);

    panSlider.setSliderStyle (juce::Slider::LinearHorizontal);
    panSlider.setTextBoxStyle (juce::Slider::TextBoxRight, false, 54, 18);
    panSlider.setRange (-1.0, 1.0, 0.01);
    panSlider.setColour (juce::Slider::thumbColourId, Col::accent);

    /*  Bao cho LookAndFeel biet day la thanh PAN, khong phai thanh am luong.
        Thanh pan to tu CHINH GIUA ra, va o giua thi khong to gi ca - de o
        giua ma nua trai van xanh thi nhin tuong dang lech trai.  */
    panSlider.getProperties().set ("panStyle", true);
    panSlider.getProperties().set ("inspectorChannelControl", true);

    panSlider.onValueChange = [this]
    {
        if (currentTrack != nullptr)
        {
            currentTrack->setPan ((float) panSlider.getValue());
            if (onTrackChanged) onTrackChanged();
        }
    };
    panSlider.setDoubleClickReturnValue (true, 0.0);
    panSlider.textFromValueFunction = livent::panText;
    panSlider.valueFromTextFunction = livent::panValue;
    panSlider.updateText();
    addAndMakeVisible (panSlider);

    startTimerHz (5);
}

//-----------------------------------------------------------------------------
void InspectorPanel::setTrack (Track* t)
{
    const bool changed = currentTrack != t;
    currentTrack = t;
    eqPanel.setTrack(t);
    eqHeader.setPowerState(t != nullptr && t->getChannelEq().isEnabled());
    if (changed) { insertViewport.setViewPosition (0, 0); sendViewport.setViewPosition (0, 0); }

    if (t == nullptr)
    {
        titleLabel.setText (livent::vn ("(chưa chọn track)"), juce::dontSendNotification);
        trackTypeLabel.setText ({}, juce::dontSendNotification);
        insertRows.clear(); sendRows.clear();
        insertsHeader.setInfoText ({}); sendsHeader.setInfoText ({});
        resized(); repaint(); return;
    }

    titleLabel.setText (t->getName(), juce::dontSendNotification);
    trackTypeLabel.setText (t->getTypeName() + " · " + (t->getChannelMode() == Track::Chan::Mono ? "Mono" : "Stereo"), juce::dontSendNotification);
    channelModeBox.setSelectedId (t->getChannelMode() == Track::Chan::Stereo ? 2 : 1, juce::dontSendNotification);

    gainSlider.setValue (t->getGainDb(), juce::dontSendNotification);
    panSlider .setValue (t->getPan(),    juce::dontSendNotification);
    fileLabel .setText  (t->getFileName(), juce::dontSendNotification);
    /*  MOC 51/52: nap lai danh sach nguon moi lan doi track - so track cong
        vao co the doi bat cu luc nao qua bang Setup audio. Bo han muc "File
        nhac trong may": IN gio chi con hai kieu - cong vat ly (truc tiep)
        hoac lay tu mot track cong vao (MONO IN / STEREO IN...).  */
    sourceBox.clear (juce::dontSendNotification);

    for (auto* in : mixer.getInputTracks())
        if (in != t)
            sourceBox.addItem (in->getName(), inputTrackIdBase + in->getId());

    sourceBox.setTextWhenNothingSelected (livent::vn ("Chưa chọn đầu vào"));
    sourceBox.setSelectedId (
        t->getSource() == Track::Source::TrackTap ? inputTrackIdBase + t->getInputTrackId() : 0,
        juce::dontSendNotification);

    rebuildRouting();
    rebuildInserts();
    rebuildSends();
    resized(); timerCallback(); repaint();
}

//-----------------------------------------------------------------------------
void InspectorPanel::rebuildRouting()
{
    if (currentTrack == nullptr)
        return;

    const auto type      = currentTrack->getType();
    const bool isOutput  = type == Track::Type::Output || type == Track::Type::OutputBus;
    const bool isBeat    = type == Track::Type::Beat;
    const bool hasSource = type == Track::Type::Audio || isBeat;

    /*  CHI GHI LAI Y DINH, khong dat setVisible thang o day.

        Ly do: muc ROUTING thu gon duoc. Neu vua dat visible o day, vua dat o
        resized() theo trang thai thu gon, thi hai cho danh nhau - thu gon
        xong bam sang track khac la cac o hien lai het.
        resized() la NOI DUY NHAT dat visible, dua tren: y dinh AND dang mo. */
    /*  MOC 52: MIC va NHAC gio dung CHUNG mot kieu chon "In" - truoc day chi
        NHAC (Beat) moi thay hop nay, con MIC (Audio) chi thay thang o cong
        vat ly, khong co cach nao lay tu MONO IN / STEREO IN ca. Bo luon lua
        chon "File nhac trong may" - hang "Cong" chi con hien khi chon "Duong
        vao truc tiep".  */
    wantSource = hasSource || type == Track::Type::OutputBus;
    srcLabel.setText (type == Track::Type::OutputBus ? livent::vn ("Nguồn nhận") : "In", juce::dontSendNotification);
    if (type == Track::Type::OutputBus)
        livent::outputSource::fill (sourceBox, mixer, *currentTrack);
    wantInput  = false;   // v4: track chi chon BUS dau vao logic, khong chon cong vat ly truc tiep
    wantFile   = false;
    /* Track thuong chon DAU RA LOGIC. Rieng cac bus Output/OutputBus khong
       map cong vat ly trong Inspector nua - viec do chi nam o "Cài đặt đường âm thanh".
       PK van la duong monitor dac biet nen giu nut cong ra rieng. */
    wantOutput = ! isOutput;

    /*  MOC 28: track PK co MOT hang rieng -- chon track NGUON de nghe trom. */
    const bool isPk = type == Track::Type::PK;
    wantPkSource = isPk;

    const bool showIn = wantInput;

    //-- Nap danh sach cong vao THAT cua card --------------------------------
    if (showIn)
    {
        inputBox.clear (juce::dontSendNotification);

        juce::StringArray names;

        if (getInputChannelNames)
            names = getInputChannelNames();

        if (names.isEmpty())
            for (int i = 0; i < 8; ++i)
                names.add ("In " + juce::String (i + 1));

        /*  Stereo la HAI cong lien nhau, nen phai hien theo cap:
                LinkIn3 + LinkIn4
            Mono thi hien tung cong le. Danh sach tu doi khi anh gat Mono/Stereo. */
        const bool stereo = currentTrack->getChannelMode() == Track::Chan::Stereo;

        if (stereo)
        {
            for (int i = 0; i + 1 < names.size(); ++i)
                inputBox.addItem (names[i] + "  +  " + names[i + 1], i + 1);
        }
        else
        {
            for (int i = 0; i < names.size(); ++i)
                inputBox.addItem (names[i], i + 1);
        }

        const int wanted = currentTrack->getInputLeft() + 1;
        inputBox.setSelectedId (wanted <= names.size() ? wanted : 1,
                                juce::dontSendNotification);

        channelModeBox.setSelectedId (currentTrack->getChannelMode() == Track::Chan::Stereo ? 2 : 1,
                                      juce::dontSendNotification);
    }

    //-- Nap danh sach duong ra ----------------------------------------------
    outputBox.clear (juce::dontSendNotification);

    if (isPk)
    {
        /*  MOC 40: muc "Khong nghe gi" dat len DAU danh sach.

            Truoc day PK bat buoc phai nghe trom mot track nao do -- khong co
            duong nao de no ngoi im. Ma phan lon thoi gian anh khong dung toi
            PK, chi luc nao can day sang phan mem khac moi bat.

            Dung ma so 9999 chu khong dung 0: ComboBox cua JUCE coi ma so 0 la
            "chua chon gi ca" va se khong hien muc do len.  */
        outputBox.addItem (livent::vn ("-- Không nghe gì --"), pkSourceNone);

        for (auto* src : mixer.getPossiblePkSources())
            outputBox.addItem (src->getName(), src->getId());

        const int srcId = currentTrack->getOutputTargetId();

        outputBox.setSelectedId (mixer.getTrackById (srcId) != nullptr ? srcId
                                                                      : pkSourceNone,
                                 juce::dontSendNotification);

        refreshOutPairsButton();
    }
    else if (isOutput)
    {
        refreshOutPairsButton();
    }
    else
    {
        for (auto* target : mixer.getPossibleOutputTargets (currentTrack))
            outputBox.addItem (target->getName(), target->getId());

        outputBox.setSelectedId (currentTrack->getOutputTargetId(),
                                 juce::dontSendNotification);
    }
}

//-----------------------------------------------------------------------------
//  MOC 26b: chon NHIEU cap cong ra cho track AM THANH RA
//-----------------------------------------------------------------------------
juce::StringArray InspectorPanel::getOutPairNames() const
{
    juce::StringArray names;

    if (getOutputChannelNames)
        names = getOutputChannelNames();

    if (names.isEmpty())
        names = { "Out 1", "Out 2" };

    juce::StringArray pairs;

    for (int i = 0; i + 1 < names.size(); i += 2)
        pairs.add (names[i] + " + " + names[i + 1]);

    if (pairs.isEmpty())
        pairs.add (names[0]);

    return pairs;
}

void InspectorPanel::refreshOutPairsButton()
{
    const auto pairs = getOutPairNames();

    juce::StringArray on;

    if (currentTrack != nullptr)
        for (int i = 0; i < pairs.size(); ++i)
            if (currentTrack->isOutPairOn (i))
                on.add (pairs[i]);

    /*  Chu tren nut noi luon dang ra duong nao, khong phai bam vao moi biet.
        Khong duong nao thi bao mau do -- day la truong hop MAT TIENG hoan
        toan, phai thay ngay.  */
    if (on.isEmpty())
    {
        outPairsButton.setButtonText (livent::vn ("CHƯA CHỌN ĐƯỜNG RA - bấm để chọn"));
        outPairsButton.setColour (juce::TextButton::textColourOffId, Col::red);
    }
    else
    {
        outPairsButton.setButtonText (on.joinIntoString ("  |  "));
        outPairsButton.setColour (juce::TextButton::textColourOffId, Col::text);
    }
}

void InspectorPanel::showOutPairsMenu()
{
    if (currentTrack == nullptr)
        return;

    auto pairs = getOutPairNames();
    const bool physicalMenu=(bool)getAllOutputChannelNames && (bool)getActiveOutputPairIndex && (bool)activateOutputPair;
    if(physicalMenu)
    {
        pairs.clear();
        const auto names=getAllOutputChannelNames();
        for(int i=0;i+1<names.size() && i<64;i+=2)pairs.add(names[i]+" + "+names[i+1]);
    }
    const int trackId=currentTrack->getId();
    const auto deviceIdentity=getOutputDeviceIdentity?getOutputDeviceIdentity():juce::String();

    juce::PopupMenu m;

    m.addSectionHeader (livent::vn ("Đổ tiếng tổng ra những đường nào"));

    for (int i = 0; i < pairs.size(); ++i)
    {
        /*  Tham so: (ma so, chu, bat/tat muc, co dau tich hay khong).
            Dau tich cho biet duong do dang bat.  */
        const int activePair=physicalMenu?getActiveOutputPairIndex(i):i;
        m.addItem (i + 1, pairs[i]+(activePair<0?livent::vn(" (bật cổng)"):juce::String()), true,
                   activePair>=0 && currentTrack->isOutPairOn(activePair));
    }

    m.addSeparator();
    m.addItem (1000, livent::vn ("Cặp chưa bật sẽ khởi động lại audio; chỉ hiện cổng driver cung cấp."), false, false);
    juce::Component::SafePointer<InspectorPanel> owner(this);

    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&outPairsButton),
        [owner,physicalMenu,trackId,deviceIdentity] (int choice)
        {
            if(owner==nullptr)return;
            auto* self=owner.getComponent();
            if(self->getOutputDeviceIdentity && self->getOutputDeviceIdentity()!=deviceIdentity)return;
            if (choice <= 0 || choice >= 1000)
                return;

            int pair = choice - 1;

            if (self->currentTrack == nullptr || self->currentTrack->getId()!=trackId)
                return;
            const int oldPair=physicalMenu?self->getActiveOutputPairIndex(pair):pair;
            const bool wasOn=oldPair>=0 && self->currentTrack->isOutPairOn(oldPair);
            if(physicalMenu)pair=self->activateOutputPair(pair);
            if(pair<0 || owner==nullptr || self->currentTrack==nullptr || self->currentTrack->getId()!=trackId)return;
            self->currentTrack->setOutPairOn(pair,!wasOn);
            self->refreshOutPairsButton();
            if(self->onTrackChanged)self->onTrackChanged();

            /*  Menu tu dong dong sau moi lan bam. Mo lai ngay de anh tich
                tiep duong thu hai ma khong phai bam vao nut lai tu dau --
                bat hai duong la thao tac rat hay dung.  */
            juce::Component::SafePointer<InspectorPanel> safeThis (self);

            juce::Timer::callAfterDelay (60, [safeThis]
            {
                if (safeThis == nullptr || safeThis->currentTrack == nullptr)
                    return;

                /*  MOC 32: chi mo lai khi VAN dang o track dung loai.

                    Trong 60 mili giay do anh hoan toan co the da bam sang
                    track khac. Mo lai mu quang thi bang chon cap cong ra
                    hien len giua man hinh cho mot track MIC -- vua vo duyen,
                    vua co the ghi nham bang co vao track do.  */
                const auto ty = safeThis->currentTrack->getType();

                if (ty == Track::Type::Output || ty == Track::Type::OutputBus || ty == Track::Type::PK)
                    safeThis->showOutPairsMenu();
            });
        });
}

//-----------------------------------------------------------------------------
void InspectorPanel::previewInsertGap (int draggedIndex, int steps)
{
    /*  ==========  MOC 43: KHE HO KHI KEO  ==========

        Truoc day keo mot o insert thi CHI o do chay theo chuot, cac o khac
        dung im. Nhin ra la o dang keo de chong len o khac, con cho cu cua no
        thi trong hoac. Tha tay xong moi biet no roi vao dau -- trat thi keo
        lai, ma moi lan keo lai la mot lan cua so plugin dong mo.

        Gio cac o khac TU DAY RA, chua san mot khe ho ngay duoi con tro. Nhin
        thay truoc ket qua thi khong con phai doan.

        Cach day: goi o dang keo la D, cho se tha la T.
          * Keo XUONG (T > D): moi o nam trong khoang D+1..T bi day LEN mot nac.
          * Keo LEN  (T < D): moi o nam trong khoang T..D-1 bi day XUONG mot nac.
        Cac o ngoai khoang do khong dong toi.  */
    if (! insertsHeader.isOpen() || insertRows.isEmpty())
        return;

    const int n = insertRows.size();

    if (! juce::isPositiveAndBelow (draggedIndex, n))
        return;

    const int target = juce::jlimit (0, n - 1, draggedIndex + steps);

    //  Cao mot nac = chieu cao o + khe ho giua hai o (phai khop voi resized)
    const int pitch = workspace::insertPitch;

    for (int i = 0; i < n; ++i)
    {
        if (i == draggedIndex)
            continue;   // o dang keo do chuot dieu khien, khong dung toi

        int shift = 0;

        if (target > draggedIndex && i > draggedIndex && i <= target)
            shift = -pitch;
        else if (target < draggedIndex && i >= target && i < draggedIndex)
            shift = pitch;

        if (! juce::isPositiveAndBelow (i, insertRowHomeY.size()))
            continue;   // chua kip xep lai lan nao -> chua co toa do goc

        insertRows[i]->setTopLeftPosition (insertRows[i]->getX(),
                                           insertRowHomeY[i] + shift);
    }
}

//-----------------------------------------------------------------------------
//  MOC 48: xo / thu tung muc trong bang Inspector
//-----------------------------------------------------------------------------
SectionHeader* InspectorPanel::sectionAt (int index)
{
    switch (index)
    {
        case 0:  return &routingHeader;
        case 1:  return &insertsHeader;
        case 2:  return &sendsHeader;
        case 3:  return &levelHeader;
        case 4:  return &eqHeader;
        default: return nullptr;
    }
}

bool InspectorPanel::isSectionOpen (int index) const
{
    //  const_cast: sectionAt chi tra con tro, khong doi gi trong lop
    if (auto* h = const_cast<InspectorPanel*> (this)->sectionAt (index))
        return h->isOpen();

    return true;
}

void InspectorPanel::setSectionOpen (int index, bool shouldBeOpen)
{
    if (auto* h = sectionAt (index))
    {
        //  false = dung ban tin doi, khong thi moi lan nap du an lai chay
        //  het cac ham dung lai bang mot cach vo ich
        h->setOpen (shouldBeOpen, false);
        resized();
    }
}

void InspectorPanel::refreshFromTrack()
{
    eqHeader.setPowerState(currentTrack && currentTrack->getChannelEq().isEnabled());
    eqPanel.refresh();
    if (currentTrack == nullptr)
        return;

    /*  Hai ham nay von da doc thang tu track de dung lai cac dong va dat
        trang thai nut nguon o dau muc -- nen goi lai la du, khong phai viet
        rieng mot duong cap nhat thu hai (hai duong thi som muon lech nhau).  */
    rebuildInserts();
    rebuildSends();
    if (currentTrack->getType() == Track::Type::OutputBus)
        livent::outputSource::fill (sourceBox, mixer, *currentTrack);
    resized();
}

void InspectorPanel::rebuildInserts()
{
    insertRows.clear();

    if (currentTrack == nullptr)
        return;

    auto& chain = currentTrack->getInserts();

    const bool masterOn = currentTrack->areAllInsertsOn();

    /*  ==========  MOC 45: HIEN TOI O CUOI CO PLUGIN, CONG MOT O TRONG  ==========

        Moc 44 bay du ca 16 o. Dung ve chuc nang, nhung track moi tinh chua
        co plugin nao cung hien 16 o rong -- day man hinh, va bang Send bi
        day tut xuong duoi phai cuon moi thay.

        Gio: tim o CUOI CUNG dang co plugin, roi bay them MOT o trong duoi no.
        Thanh ra:
          * track trong        -> 1 o trong
          * plugin o o 1       -> 2 o (o 1 + mot o trong)
          * plugin o o 1 va 6  -> 7 o (giu nguyen khoang trong o 2-5!)

        Diem mau chot: dem theo O CUOI CUNG chu khong theo SO LUONG plugin.
        Dem theo so luong thi 2 plugin nam o o 1 va o 6 se chi bay 3 o -- an
        mat chinh cai o 6 dang co plugin. Khoang trong anh co y de lai van
        con nguyen, chi cat phan duoi cung chua dung toi.

        Va vi moi lan them plugin vao o cuoi la lai co mot o trong moi moc ra
        ben duoi, danh sach tu dai them dung nhu anh muon.  */
    int lastUsed = -1;

    for (int i = 0; i < PluginChain::maxSlots; ++i)
        if (! chain.isSlotEmpty (i))
            lastUsed = i;

    const int rowCount = juce::jmin (lastUsed + 2, PluginChain::maxSlots);

    for (int i = 0; i < rowCount; ++i)
    {
        auto* row = new InsertSlotRow();
        row->setCompactLook (true);

        row->onChoose = [this, i] { if (onChoosePlugin) onChoosePlugin (i); };
        row->onEditor = [this, i] { if (onOpenEditor)   onOpenEditor (i); };
        row->onBypass = [this, i] (bool b)
        {
            if (currentTrack != nullptr)
            {
                currentTrack->getInserts().setBypassed (i, b);
                if (onTrackChanged) onTrackChanged();
            }
        };
        row->onRemove = [this, i]
        {
            if (currentTrack != nullptr)
            {
                /*  Bao cho MainComponent dong cua so giao dien TRUOC.
                    Thu tu nay bat buoc: dong cua so -> roi moi huy plugin. */
                if (onPluginAboutToBeRemoved != nullptr)
                    onPluginAboutToBeRemoved (currentTrack->getInserts().getPlugin (i));

                currentTrack->getInserts().removePlugin (i);
                if (onTrackChanged) onTrackChanged();
                rebuildInserts();
                resized();
            }
        };

        /*  V5.1: Sidechain bat/tat duoc ngay tu mui ten cua o Insert trong
            Inspector. Truoc day engine da co nhung phai vao ban tron/chuot
            phai moi thay, nen rat de tuong la DAW "chua co Sidechain". */
        row->setSidechainState (chain.hasSidechain (i), chain.isSidechainOn (i));
        row->onToggleSidechain = [this, i]
        {
            if (currentTrack == nullptr)
                return;

            auto& c = currentTrack->getInserts();
            const bool turnOn = ! c.isSidechainOn (i);

            if (! c.setSidechainOn (i, turnOn))
            {
                livent::alert (livent::vn ("Plugin không nhận"),
                               livent::vn ("Plugin này từ chối mở đường vào phụ. "
                                          "Một số plugin chỉ cho bật Sidechain từ giao diện của chính nó."),
                               juce::MessageBoxIconType::WarningIcon);
                return;
            }

            rebuildInserts();
            rebuildSends();
            resized();

            if (onTrackChanged)
                onTrackChanged();
        };

        /*  KEO THA DOI THU TU.

            Thu tu insert la thu tu TIN HIEU di qua. Nen / EQ / vang xep khac
            nhau ra tieng khac han, khong phai chuyen thich thi doi.

            Phai goi qua callAsync: luc nay minh dang o TRONG ham mouseUp cua
            chinh cai o do, ma rebuildInserts() se XOA no di. Xoa mot component
            trong khi no dang chay ham cua no la sap ngay. callAsync doi toi
            vong lap thong diep ke tiep - luc do mouseUp da chay xong.  */
        row->onDragMoved = [this, i] (int steps)
        {
            juce::Component::SafePointer<InspectorPanel> safe (this);
            const auto uuid = currentTrack ? currentTrack->getUuid() : juce::String();

            juce::MessageManager::callAsync ([safe, uuid, i, steps]
            {
                if (safe == nullptr || safe->currentTrack == nullptr || safe->currentTrack->getUuid() != uuid)
                    return;

                auto& c  = safe->currentTrack->getInserts();
                const int to = juce::jlimit (0, c.getNumPlugins() - 1, i + steps);

                if (to == i)
                    return;

                /*  Cua so plugin nho vi tri theo "t<id>:s<so o>". Doi cho xong
                    la ma do tro nham plugin khac -> dong het cho chac.  */
                if (safe->onInsertsReordered)
                    safe->onInsertsReordered();

                /* V6.6.5 HOTFIX: doi qua Mixer de Sidechain Send cung doi targetSlot
                   va audio thread khong ghi scBuffer dung luc hai slot swap. */
                safe->mixer.moveInsertPlugin (*safe->currentTrack, i, to);
                if (safe->onTrackChanged) safe->onTrackChanged();
                safe->rebuildInserts();
                safe->resized();
            });
        };

        row->onDragPreview = [this, i] (int steps) { previewInsertGap (i, steps); };
        row->onDragEnded   = [this, i]              { previewInsertGap (i, 0);     };

        row->setContent (chain.getPluginName (i),
                         ! chain.isSlotEmpty (i) && ! chain.isMissing (i),
                         chain.isBypassed (i),
                         chain.isMissing (i));

        row->setMasterOn (masterOn);

        insertContent.addAndMakeVisible (row);
        insertRows.add (row);
    }

    //-- Cap nhat tieu de muc ------------------------------------------------
    const bool on      = currentTrack->areAllInsertsOn();
    const auto missing = chain.getMissingPluginNames();

    insertsHeader.setPowerState (on);

    insertsHeader.setInfoText (! on            ? "DA TAT HET"
                             : ! missing.isEmpty() ? juce::String (missing.size()) + " THIEU"
                             : juce::String (chain.getNumUsedSlots()) + " plugin");   // MOC 47
}

//-----------------------------------------------------------------------------
void InspectorPanel::rebuildSends()
{
    sendRows.clear();

    // Track Output chi nhet insert, KHONG co send
    const bool canSend = currentTrack != nullptr
                      && currentTrack->getType() != Track::Type::Output
                      && currentTrack->getType() != Track::Type::OutputBus;

    sendsHeader   .setVisible (canSend);
    addSendButton .setVisible (canSend && sendsHeader.isOpen());

    if (! canSend)
        return;

    const bool on = currentTrack->areAllSendsOn();
    sendsHeader.setPowerState (on);
    sendsHeader.setInfoText (on ? juce::String (currentTrack->getNumSends()) + " send"
                                : "DA TAT HET");

    for (int i = 0; i < currentTrack->getNumSends(); ++i)
    {
        const auto s = currentTrack->getSend (i);
        auto* fx = mixer.getTrackById (s.targetId);

        auto* row = new SendRow();
        row->setCompactLook (true);
        row->setMasterOn (on);

        juce::String sendName = fx != nullptr ? fx->getName() : livent::vn ("(đã xóa)");

        if (s.targetSlot >= 0)
        {
            const auto pluginName = fx != nullptr
                                  ? fx->getInserts().getPluginName (s.targetSlot)
                                  : juce::String();

            sendName = "SC -> " + sendName;

            if (pluginName.isNotEmpty())
                sendName << " / " << pluginName;
            else if (fx != nullptr)
                sendName << livent::vn (" / (ô trống)");
        }

        row->setContent (sendName, s.levelDb, s.enabled, s.preFader);

        row->onLevelChanged = [this, i] (float dB)
        {
            if (currentTrack != nullptr)
            {
                currentTrack->setSendLevelDb (i, dB);
                if (onTrackChanged) onTrackChanged();
            }
        };
        row->onPreFaderChanged = [this, i] (bool pre)
        {
            if (currentTrack != nullptr)
            {
                currentTrack->setSendPreFader (i, pre);
                if (onTrackChanged) onTrackChanged();
            }
        };
        row->onEnabledChanged = [this, i] (bool on)
        {
            if (currentTrack != nullptr)
            {
                currentTrack->setSendEnabled (i, on);
                if (onTrackChanged) onTrackChanged();
            }
        };
        row->onRemove = [this, i]
        {
            if (currentTrack != nullptr)
            {
                currentTrack->removeSend (i);
                if (onTrackChanged) onTrackChanged();
                rebuildSends();
                resized();
            }
        };

        sendContent.addAndMakeVisible (row);
        sendRows.add (row);
    }
}

//-----------------------------------------------------------------------------
void InspectorPanel::showAddSendMenu()
{
    if (currentTrack == nullptr) return;
    const auto sourceUuid = currentTrack->getUuid();
    juce::StringArray busIds;
    juce::Array<std::pair<juce::String, int>> sidechains;
    juce::PopupMenu menu;
    for (auto* bus : mixer.getPossibleSendTargets (currentTrack))
    {
        busIds.add (bus->getUuid());
        menu.addItem (busIds.size(), livent::vn ("Gửi sang: ") + bus->getName());
    }
    if (busIds.isEmpty()) menu.addItem (-1, livent::vn ("Chưa có bus nào để gửi sang"), false);
    for (auto* target : mixer.getPossibleSidechainTargets (currentTrack))
        for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
            if (target->getInserts().isSidechainOn (slot))
            {
                if (sidechains.isEmpty()) { menu.addSeparator(); menu.addSectionHeader (livent::vn ("Đường vào phụ (Sidechain)")); }
                menu.addItem (1000 + sidechains.size(), target->getName() + " - " + target->getInserts().getPluginName (slot));
                sidechains.add ({ target->getUuid(), slot });
            }
    juce::Component::SafePointer<InspectorPanel> safe (this);
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&addSendButton),
        [safe, sourceUuid, busIds, sidechains] (int result)
        {
            if (safe == nullptr || result <= 0) return;
            auto* source = safe->mixer.getTrackByUuid (sourceUuid);
            if (source == nullptr || source != safe->currentTrack) return;
            Track* target = nullptr; int slot = -1;
            if (result >= 1000)
            {
                const int at = result - 1000;
                if (! juce::isPositiveAndBelow (at, sidechains.size())) return;
                target = safe->mixer.getTrackByUuid (sidechains[at].first); slot = sidechains[at].second;
                if (target == nullptr || ! target->getInserts().isSidechainOn (slot)
                    || ! safe->mixer.getPossibleSidechainTargets (source).contains (target)) return;
            }
            else
            {
                if (! juce::isPositiveAndBelow (result - 1, busIds.size())) return;
                target = safe->mixer.getTrackByUuid (busIds[result - 1]);
                if (target == nullptr || ! safe->mixer.getPossibleSendTargets (source).contains (target)) return;
            }
            // 12r: gui NHAC vao DELAY -> hoi lai truoc
            const int targetId = target->getId();
            livent::sendwarn::confirmThen (source, target, slot, safe.getComponent(), [safe, sourceUuid, targetId, slot]
            {
                if (safe == nullptr) return;
                auto* src = safe->mixer.getTrackByUuid (sourceUuid);
                if (src == nullptr || src != safe->currentTrack || safe->mixer.getTrackById (targetId) == nullptr) return;
                src->addSend (targetId, slot);
                if (safe->onTrackChanged) safe->onTrackChanged();
                safe->rebuildSends(); safe->resized();
            });
        });
}

void InspectorPanel::chooseAudioFile()
{
    if (currentTrack == nullptr) return;
    const auto uuid = currentTrack->getUuid();
    juce::Component::SafePointer<InspectorPanel> safe (this);
    fileChooser = std::make_unique<juce::FileChooser> (livent::vn ("Chọn file nhạc nền"),
        juce::File::getSpecialLocation (juce::File::userMusicDirectory), "*.wav;*.mp3;*.aiff;*.flac;*.ogg");
    fileChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [safe, uuid] (const juce::FileChooser& chooser)
        {
            if (safe == nullptr || safe->currentTrack == nullptr || safe->currentTrack->getUuid() != uuid) return;
            const auto file = chooser.getResult(); if (file == juce::File()) return;
            if (safe->currentTrack->loadFile (file, safe->mixer.getFormatManager(), safe->mixer.getReadThread()))
            {
                safe->fileLabel.setText (file.getFileName(), juce::dontSendNotification);
                if (safe->onTrackChanged) safe->onTrackChanged();
            }
            else livent::alert (livent::vn ("Không đọc được file"), file.getFullPathName(), juce::MessageBoxIconType::WarningIcon);
        });
}

juce::String InspectorPanel::structureSignature() const
{
    juce::String s;
    if (currentTrack == nullptr)
        return s;
    auto& chain = currentTrack->getInserts();
    for (int i = 0; i < PluginChain::maxSlots; ++i)
        s << (chain.isSlotEmpty (i) ? juce::String ("-") : chain.getPluginName (i)) << "|";
    s << "#" << currentTrack->getNumSends();
    return s;
}

void InspectorPanel::setOverviewLayout (bool on)
{
    overviewLayout = on;
    if (on)
        for (auto* h : { &routingHeader, &eqHeader, &insertsHeader, &sendsHeader, &levelHeader })
            h->setOpen (true, false);
    resized();
    repaint();
}

void InspectorPanel::timerCallback()
{
    if (currentTrack == nullptr)
        return;
    // 14/10: bang tong quan la ban thu 2 cua cung track -> Insert/Send doi o noi khac thi dung lai.
    if (overviewLayout)
    {
        if (mixer.indexOfTrack (currentTrack) < 0)   // track da bi xoa o noi khac -> tha ra ngay
        {
            setTrack (nullptr);
            return;
        }
        const auto sig = structureSignature();
        if (sig != lastStructure)
        {
            lastStructure = sig;
            rebuildInserts();
            rebuildSends();
            resized();
        }
    }
    trackMute.setToggleState (currentTrack->isMuted(), juce::dontSendNotification);
    trackSolo.setToggleState (currentTrack->isSoloed(), juce::dontSendNotification);
    trackArm.setToggleState (mixer.isTrackRecordArmed (*currentTrack), juce::dontSendNotification);
    trackMonitor.setToggleState (currentTrack->isMonitorOn(), juce::dontSendNotification);
    trackMonitor.setIcon (currentTrack->isMonitorOn() ? Icon::Speaker : Icon::SpeakerMuted);
    titleLabel.setText (currentTrack->getName(), juce::dontSendNotification);
    trackTypeLabel.setText (currentTrack->getTypeName() + " · " + (currentTrack->getChannelMode() == Track::Chan::Mono ? "Mono" : "Stereo"), juce::dontSendNotification);
    if (! gainSlider.isMouseButtonDown() && ! gainSlider.hasKeyboardFocus (true)) gainSlider.setValue (currentTrack->getGainDb(), juce::dontSendNotification);
    if (! panSlider.isMouseButtonDown() && ! panSlider.hasKeyboardFocus (true)) panSlider.setValue (currentTrack->getPan(), juce::dontSendNotification);
    const float meterDb = juce::Decibels::gainToDecibels (currentTrack->getMeterLevel(), -60.0f);
    meterDbLabel.setText (meterDb <= -59.9f ? "-inf" : juce::String (meterDb, 1), juce::dontSendNotification);
    if (currentTrack->getType() == Track::Type::OutputBus
        && sourceBox.getSelectedId() != livent::outputSource::choice (currentTrack->getOutputBusSourceId()))
        livent::outputSource::fill (sourceBox, mixer, *currentTrack);

    //-- Cap nhat so % CPU tren tung o insert --------------------------------
    {
        auto& chain = currentTrack->getInserts();

        for (int i = 0; i < insertRows.size(); ++i)
            insertRows[i]->setLoadPercent (chain.getLoadPercent (i));
    }

    // F3 edits share the same Send routes. Refresh values without recreating
    // rows or interrupting a Send being edited in the Inspector.
    for (int i = 0; i < juce::jmin (sendRows.size(), currentTrack->getNumSends()); ++i)
    {
        auto* row = sendRows[i];
        if (row->isMouseButtonDown (true) || row->hasKeyboardFocus (true)) continue;
        const auto send = currentTrack->getSend (i);
        auto* target = mixer.getTrackById (send.targetId);
        auto name = target != nullptr ? target->getName() : juce::String ("?");
        if (send.targetSlot >= 0)
        {
            const auto plugin = target != nullptr ? target->getInserts().getPluginName (send.targetSlot) : juce::String();
            name = "SC -> " + name + " / " + (plugin.isNotEmpty() ? plugin : livent::vn ("(ô trống)"));
        }
        row->setMasterOn (currentTrack->areAllSendsOn());
        row->setContent (name, send.levelDb, send.enabled, send.preFader);
    }

    if (! playButton.isVisible())
        return;

    const double pos = currentTrack->getPositionSeconds();
    const double len = currentTrack->getLengthSeconds();

    auto fmt = [] (double s)
    {
        const int t = (int) s;
        return juce::String (t / 60) + ":" + juce::String (t % 60).paddedLeft ('0', 2);
    };

    if (len > 0.0)
        fileLabel.setText (currentTrack->getFileName() + "  " + fmt (pos) + " / " + fmt (len),
                           juce::dontSendNotification);

    playButton.setToggleState (currentTrack->isPlaying(), juce::dontSendNotification);
}

//-----------------------------------------------------------------------------
void InspectorPanel::paint (juce::Graphics& g)
{
    if (overviewLayout)   // 14/10: bang tong quan - chi nen, tieu de cot do SectionHeader ve
    {
        g.fillAll (workspace::bg.darker (0.15f));
        return;
    }
    g.fillAll (workspace::bg);
    g.setColour (workspace::header); g.fillRect (0, 0, getWidth(), 20);
    g.setColour (workspace::text);
    g.setFont (juce::Font (juce::FontOptions (13.0f).withStyle ("Bold")));
    g.drawText ("INSPECTOR", 6, 0, getWidth() - 12, 20, juce::Justification::centredLeft);
    const auto colour = currentTrack ? currentTrack->getColour() : workspace::header;
    g.setColour (colour.darker (0.10f)); g.fillRect (5, 23, getWidth() - 10, 22);
    if (currentTrack != nullptr)
    {
        g.setColour (workspace::line.withAlpha (0.7f));
        for (const auto row : { gainControlRow, panControlRow })
            g.drawHorizontalLine (row.getBottom() - 1, (float) row.getX(), (float) row.getRight());
        g.setColour (workspace::dim);
        g.strokePath (IconPath::speaker (gainControlRow.withWidth (18).toFloat().reduced (2, 4), true),
                      juce::PathStrokeType (1.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        const auto panIcon = panControlRow.withWidth (18).toFloat().reduced (2, 5);
        const float cy = panIcon.getCentreY();
        juce::Path arrows;
        arrows.addTriangle (panIcon.getX(), cy, panIcon.getX() + 4, cy - 3, panIcon.getX() + 4, cy + 3);
        arrows.addTriangle (panIcon.getRight(), cy, panIcon.getRight() - 4, cy - 3, panIcon.getRight() - 4, cy + 3);
        g.fillPath (arrows);
        g.drawHorizontalLine (juce::roundToInt (cy), panIcon.getX() + 4, panIcon.getRight() - 4);
    }
    g.setColour (workspace::line); g.drawVerticalLine (getWidth() - 1, 0.0f, (float) getHeight());
}

void InspectorPanel::layoutOverview()
{
    /*  14/10: 4 cot  [INSERT 230] [EQ (con lai)] [SEND 230] [KENH 170].  Dung lai DUNG cac
        nut/thanh cua Inspector thuong -> moi thao tac giong het ben trai F2.  */
    const bool hasTrack = currentTrack != nullptr;
    auto area = getLocalBounds().reduced (8);
    titleLabel.setBounds ({});
    trackTypeLabel.setVisible (false);
    overviewButton.setVisible (false);
    gainCaption.setVisible (hasTrack); panCaption.setVisible (hasTrack); meterDbLabel.setVisible (hasTrack);

    const bool canSend = hasTrack && currentTrack->getType() != Track::Type::Output
                      && currentTrack->getType() != Track::Type::OutputBus;

    auto colChannel = area.removeFromRight (170); area.removeFromRight (8);
    auto colInsert  = area.removeFromLeft (juce::jmin (240, area.getWidth() / 3)); area.removeFromLeft (8);
    juce::Rectangle<int> colSend;
    if (canSend) { colSend = area.removeFromRight (juce::jmin (240, area.getWidth() / 2)); area.removeFromRight (8); }
    auto colEq = area;

    //-- INSERT
    insertsHeader.setBounds (colInsert.removeFromTop (22)); colInsert.removeFromTop (6);
    insertViewport.setVisible (hasTrack); insertResizeHandle.setVisible (false);
    insertViewport.setBounds (colInsert);
    const int insertH = juce::jmax (0, insertRows.size() * workspace::insertPitch - 3);
    insertContent.setSize (juce::jmax (0, insertViewport.getWidth() - 7), insertH);
    insertRowHomeY.clearQuick();
    for (int i = 0; i < insertRows.size(); ++i)
    {
        const int y = i * workspace::insertPitch;
        insertRows[i]->setBounds (0, y, insertContent.getWidth(), workspace::insertHeight);
        insertRowHomeY.add (y);
    }

    //-- EQ
    eqHeader.setBounds (colEq.removeFromTop (22)); colEq.removeFromTop (6);
    eqPanel.setVisible (hasTrack);
    eqPanel.setBounds (colEq.withHeight (juce::jmin (colEq.getHeight(), 420)));

    //-- SEND
    sendsHeader.setVisible (canSend); sendViewport.setVisible (canSend); sendResizeHandle.setVisible (false);
    if (canSend)
    {
        sendsHeader.setBounds (colSend.removeFromTop (22)); colSend.removeFromTop (6);
        sendViewport.setBounds (colSend);
        const int sendH = livent::inspectorSendLayout::contentHeight (sendRows.size(), workspace::sendPitch, 22);
        sendContent.setSize (juce::jmax (0, sendViewport.getWidth() - 7), sendH);
        for (int i = 0; i < sendRows.size(); ++i)
            sendRows[i]->setBounds (0, i * workspace::sendPitch, sendContent.getWidth(), workspace::sendHeight);
        addSendButton.setBounds (0, sendRows.size() * workspace::sendPitch, sendContent.getWidth(), 22);
        addSendButton.setVisible (true);
    }

    //-- KENH: nut, am luong, pan, routing, dong ho
    levelHeader.setBounds (colChannel.removeFromTop (22)); colChannel.removeFromTop (8);
    auto buttons = colChannel.removeFromTop (22);
    for (auto* b : std::initializer_list<juce::Component*> { &trackMute, &trackSolo, &trackArm, &trackMonitor })
        if (b != &trackArm || (hasTrack && mixer.isTimelineRecordableTrack (*currentTrack)))
        { b->setBounds (buttons.removeFromLeft (26)); buttons.removeFromLeft (4); }
    for (auto* b : std::initializer_list<juce::Component*> { &trackMute, &trackSolo, &trackMonitor }) b->setVisible (hasTrack);
    trackArm.setVisible (hasTrack && mixer.isTimelineRecordableTrack (*currentTrack));
    colChannel.removeFromTop (8);
    auto capRow = [&] (juce::Label& cap, juce::Component& c)
    {
        cap.setBounds (colChannel.removeFromTop (16));
        c.setBounds (colChannel.removeFromTop (22));
        colChannel.removeFromTop (6);
    };
    capRow (gainCaption, gainSlider);
    capRow (panCaption, panSlider);
    gainControlRow = panControlRow = {};
    gainSlider.setVisible (hasTrack); panSlider.setVisible (hasTrack);
    channelCaption.setVisible (hasTrack); channelModeBox.setVisible (hasTrack);
    if (hasTrack)
    {
        auto row = colChannel.removeFromTop (22);
        channelCaption.setBounds (row.removeFromLeft (64));
        channelModeBox.setBounds (row);
        channelModeBox.setSelectedId (currentTrack->getChannelMode() == Track::Chan::Stereo ? 2 : 1, juce::dontSendNotification);
        colChannel.removeFromTop (8);
    }

    // Routing (In / Out) nam duoi cot KENH
    routingHeader.setBounds (colChannel.removeFromTop (20)); colChannel.removeFromTop (4);
    const bool showSrc = wantSource && hasTrack, showIn = wantInput && hasTrack;
    const bool showOut = wantOutput && hasTrack, showPk = wantPkSource && hasTrack;
    const bool usesPairs = hasTrack && (currentTrack->getType() == Track::Type::Output || currentTrack->getType() == Track::Type::OutputBus || currentTrack->getType() == Track::Type::PK);
    srcLabel.setVisible (showSrc); sourceBox.setVisible (showSrc);
    inLabel.setVisible (showIn); inputBox.setVisible (showIn);
    pkSourceLabel.setVisible (showPk); outLabel.setVisible (showOut);
    outputBox.setVisible ((showOut && ! usesPairs) || showPk); outPairsButton.setVisible (showOut && usesPairs);
    openFileButton.setVisible (false); playButton.setVisible (false); fileLabel.setVisible (false);
    auto route = [&] (juce::Label& label, juce::Component& field, int labelWidth = 34)
    { auto row = colChannel.removeFromTop (22); label.setBounds (row.removeFromLeft (labelWidth)); field.setBounds (row); colChannel.removeFromTop (3); };
    if (showSrc) route (srcLabel, sourceBox);
    if (showIn) route (inLabel, inputBox);
    if (showPk) route (pkSourceLabel, outputBox, 38);
    if (showOut) { if (usesPairs) route (outLabel, outPairsButton); else route (outLabel, outputBox); }

    colChannel.removeFromTop (8);
    meterDbLabel.setBounds (colChannel.removeFromBottom (18));
    channelMeter.setVisible (hasTrack);
    channelMeter.setBounds (colChannel.withSizeKeepingCentre (16, juce::jmax (40, colChannel.getHeight())));
    contentHeight = getHeight();
}

void InspectorPanel::resized()
{
    if (overviewLayout)
    {
        layoutOverview();
        return;
    }

    auto r = juce::Rectangle<int> (5, 23, juce::jmax (0, getWidth() - 10), 8192);
    titleLabel.setBounds (r.removeFromTop (22));
    trackTypeLabel.setVisible (false);
    r.removeFromTop (4);
    auto buttons = r.removeFromTop (20);
    for (auto* b : std::initializer_list<juce::Component*> { &trackMute, &trackSolo, &trackArm, &trackMonitor, &overviewButton })
    { b->setBounds (buttons.removeFromLeft (24)); buttons.removeFromLeft (3); }
    const bool hasTrack = currentTrack != nullptr;
    overviewButton.setVisible (hasTrack);   // 14/10: nut "e" sat nut Loa
    for (auto* b : std::initializer_list<juce::Component*> { &trackMute, &trackSolo, &trackMonitor }) b->setVisible (hasTrack);
    trackArm.setVisible (hasTrack && mixer.isTimelineRecordableTrack (*currentTrack));
    r.removeFromTop (6);
    gainControlRow = r.removeFromTop (22); panControlRow = r.removeFromTop (22);
    gainSlider.setBounds (gainControlRow.withTrimmedLeft (20));
    panSlider.setBounds (panControlRow.withTrimmedLeft (20));
    channelMeter.setBounds (buttons.getRight() - 12, buttons.getY(), 12, buttons.getHeight());
    gainSlider.setVisible (hasTrack); panSlider.setVisible (hasTrack); channelMeter.setVisible (hasTrack);
    gainSlider.setTooltip (livent::vn ("Âm lượng track (dB); bấm đúp về 0 dB"));
    panSlider.setTooltip (livent::vn ("Pan trái/phải; C = giữa; bấm đúp về giữa"));
    gainCaption.setVisible (false); panCaption.setVisible (false); meterDbLabel.setVisible (false);
    r.removeFromTop (6);
    auto header = [&] (SectionHeader& h) { h.setBounds (r.removeFromTop (20)); r.removeFromTop (4); };
    header (routingHeader);
    const bool routingOpen = hasTrack && routingHeader.isOpen();
    const bool showSrc = wantSource && routingOpen, showIn = wantInput && routingOpen;
    const bool showOut = wantOutput && routingOpen, showFil = wantFile && routingOpen;
    const bool showPk = wantPkSource && routingOpen;
    const bool usesPairs = hasTrack && (currentTrack->getType() == Track::Type::Output || currentTrack->getType() == Track::Type::OutputBus || currentTrack->getType() == Track::Type::PK);
    srcLabel.setVisible (showSrc); sourceBox.setVisible (showSrc);
    inLabel.setVisible (showIn); inputBox.setVisible (showIn);
    pkSourceLabel.setVisible (showPk); outLabel.setVisible (showOut);
    outputBox.setVisible ((showOut && ! usesPairs) || showPk); outPairsButton.setVisible (showOut && usesPairs);
    openFileButton.setVisible (showFil); playButton.setVisible (showFil); fileLabel.setVisible (showFil);
    auto route = [&] (juce::Label& label, juce::Component& field, int labelWidth = 28)
    { auto row = r.removeFromTop (22); label.setBounds (row.removeFromLeft (labelWidth)); field.setBounds (row); r.removeFromTop (3); };
    if (showSrc) route (srcLabel, sourceBox, currentTrack->getType() == Track::Type::OutputBus ? 48 : 28);
    if (showIn) route (inLabel, inputBox);
    if (showPk) route (pkSourceLabel, outputBox, 38);
    if (showOut) { if (usesPairs) route (outLabel, outPairsButton); else route (outLabel, outputBox); }
    if (showFil) { auto row = r.removeFromTop (22); playButton.setBounds (row.removeFromRight (44)); openFileButton.setBounds (row); fileLabel.setBounds (r.removeFromTop (18)); }
    r.removeFromTop (5); header (eqHeader);
    eqPanel.setVisible(hasTrack && eqHeader.isOpen());
    if(hasTrack && eqHeader.isOpen()) eqPanel.setBounds(r.removeFromTop(300));   // 15/10: EQ moi can them cho cho do thi
    r.removeFromTop (5); header (insertsHeader);
    const bool insertOpen = hasTrack && insertsHeader.isOpen();
    insertViewport.setVisible (insertOpen);
    insertResizeHandle.setVisible (insertOpen);
    insertRowHomeY.clearQuick();
    const int insertH = juce::jmax (0, insertRows.size() * workspace::insertPitch - 3);
    if (insertOpen)
    {
        insertViewport.setBounds (r.removeFromTop (livent::inspectorInsertLayout::visibleHeight (
            preferredInsertHeight, insertRows.size(), workspace::insertHeight, workspace::insertPitch, PluginChain::maxSlots)));
        insertResizeHandle.setBounds (r.removeFromTop (livent::inspectorInsertLayout::handleHeight));
    }
    insertContent.setSize (juce::jmax (0, insertViewport.getWidth() - 7), insertH);
    for (int i = 0; i < insertRows.size(); ++i)
    {
        const int y = i * workspace::insertPitch;
        insertRows[i]->setBounds (0, y, insertContent.getWidth(), workspace::insertHeight);
        insertRowHomeY.add (y);
    }
    const bool canSend = hasTrack && currentTrack->getType() != Track::Type::Output && currentTrack->getType() != Track::Type::OutputBus;
    sendsHeader.setVisible (canSend); sendViewport.setVisible (canSend && sendsHeader.isOpen());
    sendResizeHandle.setVisible (canSend && sendsHeader.isOpen());
    if (canSend)
    {
        r.removeFromTop (7); header (sendsHeader);
        const int sendH = livent::inspectorSendLayout::contentHeight (sendRows.size(), workspace::sendPitch, 22);
        if (sendsHeader.isOpen())
        {
            sendViewport.setBounds (r.removeFromTop (livent::inspectorSendLayout::visibleHeight (
                preferredSendHeight, sendRows.size(), workspace::sendPitch, 22)));
            sendResizeHandle.setBounds (r.removeFromTop (livent::inspectorSendLayout::handleHeight));
        }
        sendContent.setSize (juce::jmax (0, sendViewport.getWidth() - 7), sendH);
        for (int i = 0; i < sendRows.size(); ++i)
            sendRows[i]->setBounds (0, i * workspace::sendPitch, sendContent.getWidth(), workspace::sendHeight);
        addSendButton.setBounds (0, sendRows.size() * workspace::sendPitch, sendContent.getWidth(), 22);
        addSendButton.setVisible (true);
    }
    r.removeFromTop (7); header (levelHeader);
    const bool channelOpen = hasTrack && levelHeader.isOpen();
    channelCaption.setVisible (channelOpen); channelModeBox.setVisible (channelOpen);
    if (channelOpen)
    {
        auto row = r.removeFromTop (22);
        channelCaption.setBounds (row.removeFromLeft (juce::jmin (64, row.getWidth() / 2)));
        channelModeBox.setBounds (row);
        channelModeBox.setSelectedId (currentTrack->getChannelMode() == Track::Chan::Stereo ? 2 : 1, juce::dontSendNotification);
    }
    const int newHeight = r.getY() + 8;
    if (newHeight != contentHeight) { contentHeight = newHeight; if (onContentHeightChanged) onContentHeightChanged(); }
}

//=============================================================================
// MainComponent
//=============================================================================
/*  Chieu cao toi thieu cua Bang dieu khien. Truoc la 190: khi hang Tone bai /
    Tone nhac chuyen xuong duoi cua so YouTube va thu 7 num, DAW chi con
    ~135 px nen bi chua mot khoang trong. */
static constexpr int kMinControlPanelHeight = 110;

MainComponent::MainComponent (const juce::File& fileToOpenDirectly)
{
    autosaveEnabled = loadAutosavePref();   // MOC 66: doc lai lua chon da luu
   #if JUCE_WINDOWS
    mixer.setAutoKeyListenEnabled (loadAutoKeyListenPref());
   #else
    mixer.setAutoKeyListenEnabled (false);
   #endif
    mixer.setLowLatencyLive (loadLowLatencyLivePref());
    mixer.setLiveMode (loadLiveModePref());   // 14/10
    recordExtraMs = loadRecordExtraMsPref();
    mixer.setTimelineLatencyCompensation (true, recordExtraMs);
    Bridge32Client::safetyBufferEnabled().store (loadBridge32SafetyPref());   // 11i: truoc khi nap VST 32-bit nao
    harmonyButtonVisible = loadHarmonyButtonPref();
    workPanelPassword = loadWorkPanelPassword();
    workPanelPasswordRequired = loadWorkPanelPasswordRequired();
    verticalControlLayout = loadVerticalLayoutPref();
    tonePanel.setVerticalLayout (verticalControlLayout, false);

    // V6.6.3: hai tuy chon MAY, khong nam trong project .NT.
    loadSoundcardLockState();
    companions = std::make_unique<livent::companions::Manager>();
    browserSession = std::make_unique<livent::browsersession::Session>();
    loadCompanionAppPreference();

    PluginChain::loadPluginList();

    // V5.8.7: đóng editor NGAY TRƯỚC khi bất kỳ plugin native nào bị hủy/thay.
    // Chặn cửa sổ editor còn giữ con trỏ tới instance đã chết sau replace async.
    PluginChain::onPluginAboutToBeDestroyed = [this] (juce::AudioPluginInstance* p)
    {
        if (p != nullptr)
            pluginWindows.closeFor (p);
    };

    /*  KHONG bat quet tien trinh con mac dinh nua.

        Da thu -> tren may thuc te no lam hong ca qua trinh quet. Gio de
        cach quet THUONG lam mac dinh (da chay tot), con cach an toan thanh
        tuy chon trong menu nut "Quet plugin VST3". */

    titleLabel.setFont (juce::Font (juce::FontOptions (24.0f).withStyle ("Bold")));
    addAndMakeVisible (titleLabel);

    subtitleLabel.setText (livent::vn ("dự án chưa lưu"), juce::dontSendNotification);
    subtitleLabel.setColour (juce::Label::textColourId, Col::textDim);
    subtitleLabel.setFont (juce::Font (juce::FontOptions (12.0f)));
    addAndMakeVisible (subtitleLabel);

    /*  MOC 24: thanh menu that thay cho hai nut vuong "File" / "Tien ich".
        Noi dung tung menu nam o 3 ham getMenuBarNames / getMenuForIndex /
        menuItemSelected cuoi file nay.

        ==========  MOC 33: MAC DAT MENU O CHO KHAC  ==========

        Windows: moi cua so tu ve thanh menu cua no, ngay duoi thanh tieu de.

        macOS  : KHONG cua so nao duoc tu ve menu ca. Ca may chi co MOT thanh
                 menu duy nhat, nam sat mep TREN CUNG man hinh, va noi dung
                 cua no doi theo app dang duoc chon. Day la quy uoc tu doi
                 dau cua Mac, nguoi dung Mac nao cung tim menu o tren cung.

                 Ve mot thanh menu ben trong cua so tren Mac thi khong sai,
                 app van chay -- nhung nhin la biet ngay "app nay chuyen tu
                 Windows sang", va nguoi dung se ngo ngac vi menu tren cung
                 lai trong khong.

        setMacMainMenu() giao chinh MainComponent nay lam noi dung cho thanh
        menu he thong. Ba ham getMenuBarNames / getMenuForIndex /
        menuItemSelected dung nguyen, khong phai viet lai gi -- chi khac cho
        hien.  */
    // V6.4.0: bo thanh menu chu tren mat DAW. Tat ca muc cu van giu logic
    // menuItemSelected() de bang Cai dat moi goi lai, nhung khong ve menu nua.
   #if ! JUCE_MAC
    addChildComponent (menuBar);
    menuBar.setVisible (false);
   #endif

    // V6.1.4 macOS: ba nut thao tac nhanh CƯỜI / Lưu bài / Danh sách phải có
    // trên cả hai hệ điều hành. Trước đây setup chỉ chạy trên Windows nên Mac
    // tạo project xong mất hẳn ba nút này.
    setupMenuActionButtons();

    /*  MOC 95: ban tron F3 khong con nam tren Bang dieu khien. No chi duoc
        gan vao cua so Ban lam viec sau khi F2 mo, roi F3 moi an/hien no.  */

    /*  MOC 74: hai nut THU / DUNG gio nam trong bang Do Tone. MainComponent
        chi noi hai day cap - phan viec that (mo file, ghi dia, hoi noi luu)
        van o startMasterRecording()/stopMasterRecording() nhu cu.  */
    tonePanel.onStartRecord = [this] { startMasterRecording(); };
    tonePanel.onStopRecord  = [this] { stopMasterRecording();  };

    //-- MOC 46: bat phim tat cho ca cua so ---------------------------------
    setWantsKeyboardFocus (true);
    addKeyListener (this);
    areaFocusListener.clicked = [this] (juce::Component* c)
    {
        if (c == &mixerView || mixerView.isParentOf (c)) lastAreaWasMixer = true;
        else if (c == &trackListViewport || trackListViewport.isParentOf (c)
                 || c == &timelineTransport || timelineTransport.isParentOf (c)) lastAreaWasMixer = false;
    };
    juce::Desktop::getInstance().addGlobalMouseListener (&areaFocusListener);
    shortcutRouter.onKey = [this] (const juce::KeyPress& key) { return queueShortcut (key); };
    shortcutRouter.start();
    mixer.onRenderTimelineClip = [this](const juce::String& id){joinTimelineClips(juce::StringArray(id),true);};
    mixer.onJoinTimelineClips = [this] (const juce::StringArray& ids) { joinTimelineClips (ids); };
    mixer.shortcutDescription = [this] (const juce::String& id) { const auto key = keyboardShortcuts.keyFor (id); return key.isValid() ? key.getTextDescription() : juce::String(); };

    //-- MOC 95: F3 chi thuoc cua so F2 -------------------------------------
    /*  Giu component song san nhung AN trong MainComponent. Khi F2 mo,
        openWorkWindow() moi doi cha no sang workArea. Nhu vay F3 khong bao
        gio co co hoi ve len Bang dieu khien nua. */
    addChildComponent (mixerView);
    addChildComponent (mixerSplitter);
    mixerView    .setVisible (false);
    mixerSplitter.setVisible (false);

    loadMixerLayout();
    mixerView.onLayoutChanged = [this] { saveMixerLayout(); };
    mixerView.onTrackEdited = [this] (Track& track, bool sendStructureChanged)
    {
        markProjectDirty();
        updateTitleText();
        for (auto* row : trackRows) row->refresh();
        if (sendStructureChanged && inspector.getTrack() == &track)
        {
            inspector.rebuildSends();
            refitInspector();
        }
    };
    mixerSplitter.onDragStarted = [this] { mixerHeightAtDragStart = mixerView.getHeight(); };
    mixerSplitter.onDrag = [this] (int deltaY)
    {
        if (workWindow == nullptr || mixerWindow != nullptr) return;
        const auto area = mixerDockArea();
        mixerHeight = livent::mixerPanel::dockedHeight (area.getHeight(), mixerHeightAtDragStart - deltaY);
        layoutWorkArea();
    };
    mixerSplitter.onDragFinished = [this] { saveMixerLayout(); };
    mixerView.onToggleDetached = [this]
    {
        juce::Component::SafePointer<MainComponent> safe (this);
        juce::MessageManager::callAsync ([safe] { if (safe != nullptr) safe->toggleMixerWindow(); });
    };
    mixerView.onHide = [this]
    {
        juce::Component::SafePointer<MainComponent> safe (this);
        juce::MessageManager::callAsync ([safe]
        { if (safe != nullptr && safe->mixerVisible) safe->toggleMixerPanel(); });
    };
    mixerView.setWantsKeyboardFocus (true);
    mixerView.addKeyListener (this);

    /*  Bam o plugin tren ban tron: KHONG viet duong nap thu hai. Chi chon
        track do trong Inspector roi goi dung ham Inspector van goi - nho vay
        dung lai nguyen bo nap co kiem chung (Moc 23-25) va viec huy plugin
        boc SEH.  */
    auto selectThenDo = [this] (Track& t, std::function<void (int)> action, int slot)
    {
        for (int i = 0; i < mixer.getNumTracks(); ++i)
            if (mixer.getTrack (i) == &t)
            {
                selectTrack (i);
                break;
            }

        action (slot);
    };

    /*  Ban tron chon cot -> danh sach track va Inspector theo ngay. */
    mixerView.onTrackSelected = [this] (Track& t)
    {
        const int at = mixer.indexOfTrack (&t);

        if (at >= 0)
            selectTrack (at);
    };

    /*  ==========  MOC 58: MO CUA SO PLUGIN O NHIP SAU  ==========

        Loi anh gap: bam vao o plugin tren ban tron thi cua so "chop len roi
        tat".

        Ly do: bam mot cai la ba viec chay lien tiep NGAY TRONG ham xu ly
        chuot - chon track, dung lai bang Inspector, roi mo cua so plugin.
        Buoc dung lai bang Inspector co the dong cac cua so plugin cua track
        (no lam vay khi thu tu o insert doi), va vi ba viec nam trong cung
        mot nhip nen thu tu giua chung khong dam bao: co lan mo truoc dong
        sau -> vua hien ra da tat.

        Chua: chon track thi lam ngay (de Inspector doi theo lien tay), con
        MO cua so thi hoan sang NHIP SAU. Luc do moi viec dung lai giao dien
        da xong han, khong con gi dong duoc no nua.  */
    mixerView.onSlotClicked = [this, selectThenDo] (Track& t, int slot)
    {
        selectThenDo (t, [] (int) {}, slot);   // chi chon track

        juce::Component::SafePointer<MainComponent> safeThis (this);

        const auto trackUuid = t.getUuid();
        juce::MessageManager::callAsync ([safeThis, slot, trackUuid]
        {
            if (safeThis == nullptr)
                return;

            auto* track = safeThis->mixer.getTrackByUuid (trackUuid);

            if (track == nullptr)
                return;

            safeThis->selectTrack (safeThis->mixer.indexOfTrack (track));
            if (! track->getInserts().isSlotEmpty (slot)
                && ! track->getInserts().isMissing (slot))
                safeThis->openEditorForSlot (slot);       // MOC 59: mo han
            else
                safeThis->showPluginMenuForSlot (slot);
        });
    };

    mixerView.onPluginDropped = [this] (int srcTrackId, int srcSlot,
                                        Track& dest, int destSlot, bool copy)
    {
        const auto destUuid = dest.getUuid();
        juce::Component::SafePointer<MainComponent> safe (this);
        // Let JUCE finish the drop before rebuilding/deleting its source strip.
        juce::MessageManager::callAsync ([safe, srcTrackId, srcSlot, destUuid, destSlot, copy]
        {
            if (safe != nullptr)
                if (auto* target = safe->mixer.getTrackByUuid (destUuid))
                    safe->movePluginBetweenTracks (srcTrackId, srcSlot, *target, destSlot, copy);
        });
    };

    // 15/10: bat/tat EQ tu nut tron hang "Equalizer" o F3 -> Inspector cap nhat den EQ.
    mixerView.onEqPowerChanged = [this] (Track& t)
    {
        markProjectDirty();
        updateTitleText();
        if (inspector.getTrack() == &t)
            inspector.refreshFromTrack();
    };
    // 15/10: hang "Equalizer" trong F3 -> mo cua so EQ lon cua kenh do.
    mixerView.onEqClicked = [this] (Track& t)
    {
        const auto uuid = t.getUuid();
        juce::Component::SafePointer<MainComponent> safeThis (this);
        juce::MessageManager::callAsync ([safeThis, uuid]
        {
            if (safeThis == nullptr) return;
            if (auto* track = safeThis->mixer.getTrackByUuid (uuid))
                safeThis->showExpandedEq (track);
        });
    };
    mixerView.onSlotRightClicked = [this, selectThenDo] (Track& t, int slot)
    {
        selectThenDo (t, [] (int) {}, slot);

        juce::Component::SafePointer<MainComponent> safeThis (this);

        const auto trackUuid = t.getUuid();
        juce::MessageManager::callAsync ([safeThis, slot, trackUuid]
        {
            if (safeThis == nullptr) return;
            auto* track = safeThis->mixer.getTrackByUuid (trackUuid);
            if (track == nullptr) return;
            safeThis->selectTrack (safeThis->mixer.indexOfTrack (track));
            safeThis->showSlotContextMenu (slot);
        });
    };

    /*  Ban tron can ten cong card de hien cho track cong vao - ma chi
        MainComponent cam duoc deviceManager. Dung CHUNG mot nguon voi
        Inspector: mot cho lay, hai noi hien, khong bao gio lech nhau.  */
    mixerView.getInputChannelNames = [this]
    {
        juce::StringArray result;

        if (auto* dev = deviceManager.getCurrentAudioDevice())
        {
            auto names  = dev->getInputChannelNames();
            auto active = dev->getActiveInputChannels();

            for (int i = 0; i < names.size(); ++i)
                if (active[i])
                    result.add (names[i]);
        }

        return result;
    };

    mixerView.rebuild();

    addAndMakeVisible (inspectorSplitter);

    inspectorSplitter.onDrag = [this] (int screenX)
    {
        //  MOC 48: keo mep phai cua bang Inspector
        //  MOC 93: cung ly do nhu thanh chia ban tron - moc theo cha that su
        auto* host = inspectorSplitter.getParentComponent();

        if (host == nullptr)
            host = this;

        inspectorWidth = juce::jlimit (180, juce::jmax (180, host->getWidth() - 300),
                                       screenX - host->getScreenX());
        relayoutAll();
        markProjectDirty();
    };
    addChildComponent (trackWidthSplitter);
    trackWidthSplitter.setTooltip (livent::vn ("Kéo để đổi chiều rộng cột track"));
    trackWidthSplitter.onDrag = [this] (int screenX)
    {
        trackControlsWidth = juce::jlimit (TrackRow::minControlsWidth, 520, screenX - trackListViewport.getScreenX());
        TrackRow::setControlsWidth (trackControlsWidth); relayoutAll(); markProjectDirty();
    };

    // Chuot phai vao khoang trong duoi danh sach track -> menu them track
    trackListHolder.attachTimeline (mixer);

    trackListHolder.onRightClick = [this] (const juce::MouseEvent& e)
    {
        showTrackListContextMenu (e.getScreenPosition(), nullptr);
    };

    /*  MOC 26: ten cac CONG RA dang bat -- de track AM THANH RA chon cap. */
    inspector.getOutputChannelNames = [this]
    {
        if (auto* dev = deviceManager.getCurrentAudioDevice())
        {
            auto names  = dev->getOutputChannelNames();
            auto active = dev->getActiveOutputChannels();

            juce::StringArray result;

            for (int i = 0; i < names.size(); ++i)
                if (active[i])
                    result.add (names[i]);

            return result;
        }

        return juce::StringArray();
    };

    inspector.getAllOutputChannelNames=[this]
    {
        if(auto* dev=deviceManager.getCurrentAudioDevice())return dev->getOutputChannelNames();
        return juce::StringArray();
    };
    inspector.getOutputDeviceIdentity=[this]
    {
        if(auto* dev=deviceManager.getCurrentAudioDevice())
            return deviceManager.getCurrentAudioDeviceType()+"\n"+dev->getName()+"\n"+dev->getOutputChannelNames().joinIntoString("\n");
        return juce::String();
    };
    inspector.getActiveOutputPairIndex=[this](int physicalPair)
    {
        if(auto* dev=deviceManager.getCurrentAudioDevice())
            return livent::outputs::compactPair(livent::outputs::activeIndices(*dev),physicalPair*2);
        return -1;
    };
    inspector.activateOutputPair=[this](int physicalPair)
    {
        juce::String error;
        const int pair=livent::outputs::activatePair(mixer,deviceManager,physicalPair*2,error);
        if(pair<0)livent::alert(livent::vn("Chưa bật được đầu ra"),error,juce::MessageBoxIconType::WarningIcon);
        saveDeviceSettings();
        return pair;
    };

    inspector.getInputChannelNames = [this]
    {
        if (auto* dev = deviceManager.getCurrentAudioDevice())
        {
            // Chi liet ke cac cong DANG BAT - dung thu tu ma buffer sap xep
            auto names  = dev->getInputChannelNames();
            auto active = dev->getActiveInputChannels();

            juce::StringArray result;

            for (int i = 0; i < names.size(); ++i)
                if (active[i])
                    result.add (names[i]);

            return result;
        }

        return juce::StringArray();
    };

    inspector.onChoosePlugin = [this] (int slot) { showPluginMenuForSlot (slot); };
    inspector.onOpenEditor   = [this] (int slot) { toggleEditorForSlot (slot); };

    /*  Inspector sap xoa mot plugin -> dong cua so cua no truoc. */
    inspector.onPluginAboutToBeRemoved = [this] (juce::AudioPluginInstance* p)
    {
        pluginWindows.closeFor (p);
    };

    /*  Sap doi cho hai plugin trong chuoi. Ma dinh danh cua so la
        "t<id>:s<so o>" - doi cho xong thi ma cu tro nham sang plugin khac,
        va cua so se nho vi tri cua nham nguoi. Dong het truoc cho sach. */
    inspector.onInsertsReordered = [this]
    {
        if (auto* t = inspector.getTrack())
            for (int i = 0; i < t->getInserts().getNumPlugins(); ++i)
                pluginWindows.closeFor (t->getInserts().getPlugin (i));
    };
    inspector.onExpandEq = [this](Track* t){showExpandedEq(t);};
    inspector.onOpenOverview = [this] { openChannelOverview (inspector.getTrack()); };   // 14/10 nut "e"
    inspector.onTrackChanged = [this]
    {
        markProjectDirty();
        updateTitleText();
        for (auto* row : trackRows)
            row->refresh();
    };
    setupPluginToolbarHooks();   // 11j: BYPASS / SIDECHAIN / PRESET / A-B tren cua so VST

    /*  MOC 36: bam nut o hang nut dien -> ve lai ca dong track lan Inspector.

        Nut Loa tren dong track va nut nguon o muc Send trong Inspector deu
        dang noi ve cung mot cong tac. Doi bang loi tat ma khong bao cho
        chung biet thi chung con hien trang thai cu -- dang hat ma nhin nut
        noi sai la hong.  */
    tonePanel.onLiveStateChanged = [this]
    {
        mixerView.rebuild();

        for (auto* row : trackRows)
            row->refresh();

        inspector.refreshFromTrack();
    };

    /*  V4.5: AUTO TUNE tren Bang dieu khien = MO giao dien VST so 1
        (slot 0) cua track MIC. Nut TUNE ben canh van chi BAT/TAT plugin nhu
        cu. Dung lai chinh PluginWindowManager de cua so nho vi tri va khong
        bi mo/dong hai lan. */
    tonePanel.onPresetsChanged = [this]
    {
        markProjectDirty();
        updateTitleText();
    };

    // 06/10: bang EQ mic -> "Mo cua so VST EQ" / "Gan VST EQ..."
    tonePanel.onOpenPluginSlot = [this] (Track* t, int slot)
    {
        if (t != nullptr && projectOpen)
            openEditorForSlot (slot, t);
    };
    tonePanel.onOpenButtonMapSettings = [this]
    {
        settingsStartPage = livent::vn ("Gán nút");
        settingsWindow.reset();      // dang mo thi mo lai dung trang
        openSettingsDialog();
    };

    tonePanel.onOpenAutoTune = [this]
    {
        // V5.7: bam theo vai tro he thong, khong theo ten/vi tri track.
        // Khach doi "MÍC" thanh ten rieng hoac keo len/xuong van mo dung VST.
        Track* mic = mixer.getTrackByRole (Track::Role::Mic);
        int autoTuneSlot = 0;

        // 01/10: nut Tune da gan vao track/o khac (Cai dat > Gan nut) -> mo o do.
        {
            int boundId = 0, boundSlot = 0;
            tonePanel.getTuneTarget (boundId, boundSlot);
            if (boundId > 0)
                if (auto* t = mixer.getTrackById (boundId))
                {
                    mic = t;
                    autoTuneSlot = boundSlot;
                }
        }

        if (mic == nullptr)
        {
            livent::alert (livent::vn ("Không thấy track MÍC"),
                           livent::vn ("Không tìm thấy track MÍC hệ thống của dự án."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        if (mic->getInserts().isSlotEmpty (autoTuneSlot)
            || mic->getInserts().isMissing (autoTuneSlot))
        {
            livent::alert (livent::vn ("AUTO TUNE"),
                           livent::vn ("Ô VST số ") + juce::String (autoTuneSlot + 1)
                             + livent::vn (" của track ") + mic->getName()
                             + livent::vn (" đang trống. Hãy nạp Auto-Tune vào ô đó trước."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        const int at = mixer.indexOfTrack (mic);
        if (at >= 0)
            selectTrack (at);

        openEditorForSlot (autoTuneSlot, mic);
    };
    /*  MOC 78: bang Insert/Send nam TRONG khung cuon, khong gan thang vao
        MainComponent nua. setViewedComponent(..., false) = Viewport CHI
        muon xem, khong nhan quyen so huu - inspector van la thanh vien cua
        MainComponent va tu huy theo no.  */
    inspector.onContentHeightChanged = [this] { refitInspector(); };

    inspectorViewport.setViewedComponent (&inspector, false);
    inspectorViewport.setScrollBarsShown (true, false);   // chi keo doc
    addAndMakeVisible (inspectorViewport);

   #if JUCE_MAC
    tonePanel.setPreferredBrowser (loadBrowserPref());   // MOC 66e: nho lai lua chon da luu
   #endif

    trackListViewport.setViewedComponent (&trackListHolder, false);

    /*  Bang do tone nam TRONG vung cuon cua danh sach track, duoi cung - dung
        cho anh muon: ngay sau track AM THANH RA.  */
    /*  MOC 78: keo mep duoi bang dieu khien thi cua so bam theo. Truoc day
        chi goi resized(), nen o trang thai "chi con bang dieu khien" (cua so
        da tu thu nho bang dung bang) thi keo mep bang khong thay gi doi ca -
        bang van lap day cua so nhu cu.  */
    tonePanel.onHeightChanged = [this]
    {
        /* V6.5.5: bấm mũi tên thu/mở hàng núm thì cửa sổ ôm sát nội dung
           nhưng chuyển kích thước trong ~140 ms thay vì giật một phát.
           Nếu đang sát mép dưới màn hình, target được đẩy lên trước khi animate. */
        auto* top = getTopLevelComponent();

        if (! projectOpen || top == nullptr)
        {
            resized();
            return;
        }

        const int chromeH = titleChromeHeight (verticalControlLayout);
        const int wantedContentW = verticalControlLayout ? tonePanel.getWantedWidth() : getWidth();
        const int wantedContentH = juce::jmax (kMinControlPanelHeight, tonePanel.getWantedHeight() + chromeH + statusBarHeightForWidth (wantedContentW) + 2);

        auto target = top->getBounds();
        const int extraW = juce::jmax (0, top->getWidth()  - getWidth());
        const int extraH = juce::jmax (0, top->getHeight() - getHeight());
        target.setSize (wantedContentW + extraW, wantedContentH + extraH);

        // Tran mep duoi -> day len (nho cho cu); thu lai -> ve dung cho cu.
        target = placeWithLiftMemory (*top, target);

        auto& animator = juce::Desktop::getInstance().getAnimator();
        animator.cancelAnimation (top, false);
        animator.animateComponent (top, target, 1.0f, 140, false, 1.0, 1.0);
    };
    autoKeyController.window=[this]() -> PluginWindow*
    {
        auto* music=mixer.getTrackByRole(Track::Role::Music);
        if(music==nullptr)return nullptr;
        auto* p=music->getInserts().getPlugin(kMusicVst2Slot);
        if(p==nullptr || !p->getName().toLowerCase().retainCharacters("abcdefghijklmnopqrstuvwxyz0123456789").contains("autokey"))return nullptr;
        return pluginWindows.findWindow(PluginWindowManager::makeKey(music->getId(),kMusicVst2Slot));
    };
    autoKeyController.onStatus=[this](juce::String text){tonePanel.showAutoKeyStatus(text);};
    autoKeyController.onDiagnostic=[](juce::String text){livent::stabilityLog("AUTO-KEY",text);};
    autoKeyController.playbackSeconds=[this]{return tonePanel.getAutoKeyPlaybackSeconds();};
    autoKeyController.onFinished=[this]{tonePanel.autoKeySequenceFinished();};
    autoKeyController.companionPid=[this]() -> juce::uint32
    { return youtube.isRunning() ? (juce::uint32)livent::youtube::helperPid() : 0; };
    /*  12s: KHONG con tu bam Antares Auto-Key o o VST 2 NHAC. Do key khi AI loi / Do khong AI
        do T-AutoKey co san trong track NHAC lam (BuiltinKey.h, TonePanel tu dieu khien).
        Cac ham duoi chi con dung chuoi tu bam cu neu no dang chay do dang.  */
    livent::builtinkey::Detector::get();   // tao luong T-AutoKey tren luong giao dien (truoc khi audio goi)
    tonePanel.onManualDetectChanged=[this](bool)
    {
        autoKeyController.stop();
        pluginWindows.clearAutoKeyCloseLocks();
    };
    tonePanel.onSongChanged=[this]{autoKeyController.stop();};
    tonePanel.onManualSongChanged=nullptr;
    tonePanel.onToneDetectionFailed=nullptr;
    tonePanel.onPanelStateChanged = [this]
    {
        markProjectDirty();
        updateTitleText();
    };
    tonePanel.onPluginChanged = [this]
    {
        markProjectDirty();
        updateTitleText();
        //  Vua ghi Key/Scale vao plugin -> Inspector ve lai cho khop
        inspector.rebuildInserts();
        refitInspector();   // MOC 78: so o insert doi -> chieu cao cuon doi theo
    };
    /*  MOC 75: bang dieu khien nam ngang tren cung, luon la con TRUC TIEP
        cua MainComponent (khong nam trong vung cuon danh sach track).  */
    tonePanel.onOpenSettings = [this] { openSettingsDialog(); };
    tonePanel.onCustomUtility = [this] (const juce::String& action)
    {
        if (action == "workspace") toggleWorkPanels();
        if (action == "mixer")
        {
            const bool opening = workWindow == nullptr;
            if (opening) applyWorkPanels (true);
            if (workWindow != nullptr && (! opening || ! mixerVisible)) toggleMixerPanel();
        }
    };
    tonePanel.getCustomUtilityState = [this] (const juce::String& action)
    { return action == "mixer" ? workWindow != nullptr && mixerVisible : action == "workspace" && workWindow != nullptr; };
    tonePanel.setHarmonyButtonVisible (harmonyButtonVisible);
    addAndMakeVisible (tonePanel);

    trackListViewport.setScrollBarsShown (true, false);
    addAndMakeVisible (trackListViewport);

    statusLabel.setColour (juce::Label::textColourId, Col::textDim);
    statusLabel.setFont (juce::Font (juce::FontOptions (11.5f)));
    addAndMakeVisible (statusLabel);

    // 07/10 (mau C): ten bai chu chay + gio o thanh trang thai
    addAndMakeVisible (statusSong);
    statusClock.setJustificationType (juce::Justification::centredRight);
    statusClock.setFont (juce::Font (juce::FontOptions (12.0f).withStyle ("SemiBold")));
    statusClock.setInterceptsMouseClicks (false, false);
    addAndMakeVisible (statusClock);
    tonePanel.onSongInfo = [this] (const juce::String& title, const juce::String& timeText, bool live)
    {
        statusSong.setTitle (title);
        if (statusClock.getText() != timeText)
            statusClock.setText (timeText, juce::dontSendNotification);
        statusClock.setColour (juce::Label::textColourId, live ? Col::accent : Col::text);
    };
    tonePanel.onFooterNotice = [this] (const juce::String& text, int kind)   // 14/10: o thong bao
    {
        statusSong.setNotice (text, kind);
    };
    livent::help::set (statusSong, livent::vn ("Bài đang phát"),
                       livent::vn ("Tên bài YouTube đang phát (chữ chạy khi dài) và thời gian bài."));

    cancelProjectLoadButton.onClick = [this] { cancelProjectPluginLoad(); };
    addAndMakeVisible (cancelProjectLoadButton);
    cancelProjectLoadButton.setVisible (false);

    startupScanProgressBar.setVisible (false);
    startupScanProgressBar.setColour (juce::ProgressBar::backgroundColourId, Col::panel2);
    startupScanProgressBar.setColour (juce::ProgressBar::foregroundColourId, Col::accent);
    addAndMakeVisible (startupScanProgressBar);

    /*  ==========  MOC 96: HUB DU AN  ==========

        Khi chua co .NT, LiveNT la "vo ung dung" nhu Cubase Hub: nguoi dung
        chon TAO DU AN / MO DU AN / MO GAN DAY. Chua co project thi KHONG
        hien bang dieu khien va khong co cho gan VST. */
    hubNewProjectButton.onClick = [this] { newProject(); };
    hubOpenProjectButton.onClick = [this] { openProjectDialog(); };
    addChildComponent (hubNewProjectButton);    // 06/10: thay bang projectHub
    addChildComponent (hubOpenProjectButton);

    // 06/10: man Tao / Mo du an moi
    projectHub.onCreate = [this] (ProjectHub::Template kind, const juce::String& name, const juce::File& folder)
    { createProjectFromHub (kind, name, folder); };
    projectHub.onOpenDialog = [this] { openProjectDialog(); };
    projectHub.onOpenRecent = [this] (const juce::File& f) { requestOpenProject (f); };
    projectHub.onRemoveRecent = [this] (const juce::File& f)
    {
        recentFiles.removeFile (f);
        saveRecentList();
        refreshProjectHub();
    };
    projectHub.onAudioSettings = [this] { menuItemSelected (301, menuStudio); };
    projectHub.onScanVst = [this] { menuItemSelected (302, menuStudio); };
    projectHub.onLicense = [this] { showActivationDialog(); };
    projectHub.onGuide = [this] { openGuideWindow (0); };
    projectHub.hasMachineTemplate = [] { return getMachineTemplateFile().existsAsFile(); };
    projectHub.getStatus = [this]
    {
        ProjectHub::Status st;
        if (auto* dev = deviceManager.getCurrentAudioDevice(); dev != nullptr && isAudioDeviceHealthy())
        {
            st.soundcardOk = true;
            st.soundcard = dev->getName();
            const double sr = dev->getCurrentSampleRate();
            st.soundcardInfo << deviceManager.getCurrentAudioDeviceType();
            if (sr > 0) st.soundcardInfo << " · " << juce::String (sr / 1000.0, 1).trimCharactersAtEnd ("0").trimCharactersAtEnd (".") << " kHz";
            st.soundcardInfo << " · " << dev->getCurrentBufferSizeSamples() << livent::vn (" mẫu");
        }
        else if (soundcardLockWaiting)
            st.soundcard = livent::vn ("Chờ card: ") + getSoundcardLockDisplayName();
        bool warn = false;
        st.license = livent::license::summaryText (&warn);
        st.licenseWarn = warn;
        st.vstCount = PluginChain::getKnownPlugins().getNumTypes();
        return st;
    };
    addChildComponent (projectHub);

    /*  MOC 96: F2 la MOT CUA SO KHAC that su. Ba bang phu song thuong truc
        trong workArea, KHONG bao gio duoc gan lai vao MainComponent nua.
        Day la diem cat xung dot "F2 dinh vao Bang dieu khien": dong F2 chi
        lam workArea roi khoi cua so, khong doi cha cac bang ve cua so chinh. */
    workArea.addChildComponent (inspectorViewport);
    workArea.addChildComponent (inspectorSplitter);
    workArea.addChildComponent (trackWidthSplitter);
    workArea.addChildComponent (trackListViewport);
    workArea.addChildComponent (mixerView);
    workArea.addChildComponent (mixerSplitter);
    workArea.addChildComponent (timelineTransport);
    workArea.addChildComponent (timelineRuler);
    workArea.addChildComponent (timelineFooter);
    workArea.addChildComponent (timelineTransportIcons);
    workArea.addChildComponent (masterMeterPanel);
    masterMeterPanel.settingsChangedCallback() = [this] { saveMixerLayout(); };

    timelineTransport.onPackageProject=[this]{packageProject();};
    timelineTransport.setPanelVisibility (inspectorVisible, mixerVisible, masterMeterVisible);
    timelineTransport.onInspectorVisibilityChanged = [this] (bool visible)
    {
        setInspectorVisible (visible);
        markProjectDirty();
        updateTitleText();
    };
    timelineTransport.onMixerVisibilityChanged = [this] (bool visible)
    {
        if (visible != mixerVisible) toggleMixerPanel();
    };
    timelineTransportIcons.onCommand = [this] (TimelineTransportBar::Command command)
    {
        timelineTransport.performCommand (command);
    };
    timelineTransport.onMasterMeterChanged = [this] (bool visible)
    {
        masterMeterVisible = visible;
        layoutWorkArea();
        saveMixerLayout();
    };

    timelineTransport.onError = [this] (const juce::String& message)
    {
        livent::alert (livent::vn ("Thu âm"), message);
    };
    timelineTransport.onShowMain = [this]
    {
        if (auto* window = getTopLevelComponent())
        {
            window->setVisible (true);
            if (auto* doc = dynamic_cast<juce::DocumentWindow*> (window)) doc->setMinimised (false);
            window->toFront (true);
        }
    };
    timelineTransport.onTimelineChanged = [this]
    {
        markProjectDirty();
        updateTitleText();
    };
    mixer.onRecordingWarning=[safe=juce::Component::SafePointer<MainComponent>(this)](const juce::String& text)
    {
        if(!safe)return;
        const bool failed=safe->mixer.hasFinalizationFailures();
        livent::alert(livent::vn("Kiểm tra bản thu"),text+(failed?livent::vn("\nChưa cho lưu/đóng gói vì có WAV chưa chốt. File gốc và dữ liệu phục hồi vẫn được giữ. Có thể phục hồi phần WAV đọc được; cần nghe lại chỗ rơi mẫu."):livent::vn("\nThời gian bản thu được giữ, nhưng âm thanh của các mẫu bị bỏ không thể khôi phục. Hãy nghe lại các đoạn này.")));
        if(failed)juce::Timer::callAfterDelay(900,[safe]{if(safe)safe->checkInterruptedTakes();});
    };
    mixer.onTakeCommitted = [this]
    {
        // 07/10 _E: ban thu vua chot xong o nen va len timeline
        markProjectDirty();
        updateTitleText();
    };
    timelineTransport.onExport = [this] (juce::Component* anchor)
    {
        showExportMenu (anchor);
    };
    timelineTransport.onImport = [this]
    {
        importAudioToTimeline (nullptr, mixer.getTimelinePositionSeconds());
    };

    // 07/10 _D: cua so video (MP4 da nhap) chay theo dau phat
    videoController = std::make_unique<VideoController> (mixer);
    timelineTransport.onVideo = [this]
    {
        videoController->toggle ([] (const juce::String& err)
        {
            livent::alert (livent::vn ("Video"), err, juce::MessageBoxIconType::InfoIcon);
        });
    };
    timelineTransport.isVideoOpen = [this] { return videoController != nullptr && videoController->isOpen(); };

    // 07/10 _D: nut Play / Stop / vi tri trong Melodyne / Auto-Tune (ARA)
    mixer.getAra().onRequestPlay = [this]
    {
        if (! mixer.isTimelinePlaying() && ! mixer.isTimelineRecording())
            mixer.startTimelinePlayback();
    };
    mixer.getAra().onRequestStop = [this]
    {
        if (mixer.isTimelinePlaying())
            mixer.stopTimelineTransport();
    };
    mixer.getAra().onRequestPosition = [this] (double t)
    {
        mixer.setTimelinePositionSeconds (t);
    };
    mixer.getAra().onContentEdited = [this]
    {
        // keo not trong Melodyne -> phai LUU du an, khong thi mat phan chinh
        markProjectDirty();
        updateTitleText();
    };
    mixer.getAra().onStatus = [this] (const juce::String& text)
    {
        // 07/10 _E: "Auto-Tune dang phan tich 40%", "khong doc duoc file..."
        statusLabel.setText (text, juce::dontSendNotification);
    };
    mixer.getAra().onChanged = [this]
    {
        const auto err = mixer.getAra().takeLastError();
        if (err.isNotEmpty())
            statusLabel.setText (err, juce::dontSendNotification);
        mixer.touchTimeline();
    };
    timelineTransport.onRecordStarted = [this]
    {
        /*  V0.6.7.7: bam THU la track dang thu tu cao len toi thieu 120 px
            de nhin ro song ngay luc hat, khong phai keo mep track nua.
            Track anh da keo to hon thi giu nguyen. */
        constexpr int recordingRowHeight = 120;
        bool changed = false;

        for (auto* row : trackRows)
        {
            auto& t = row->getTrack();
            if (mixer.isTrackRecordArmed (t) && t.getRowHeight() < recordingRowHeight)
            {
                t.setRowHeight (recordingRowHeight);
                changed = true;
            }
        }

        if (changed)
        {
            markProjectDirty();
            updateTitleText();
            layoutTrackRows (juce::jmax (260, trackListViewport.getMaximumVisibleWidth()));
        }
    };

    inspectorViewport.setVisible (false);
    inspectorSplitter.setVisible (false);
    trackWidthSplitter.setVisible (false);
    trackListViewport.setVisible (false);
    mixerView.setVisible (false);
    // MixerView owns its F3 look. Inheriting the main window look here used
    // to replace its slim Pan, fader thumb and centred channel buttons.
    mixerSplitter.setVisible (false);
    timelineTransport.setVisible (false);
    timelineRuler.setVisible (false);
    timelineFooter.setVisible (false);
    timelineTransportIcons.setVisible (false);
    masterMeterPanel.setVisible (false);

    /* LiveNT la UNG DUNG, project la TAI LIEU. Khoi dong chi giu engine
       toi thieu (chi Output tong), KHONG tu dung project
       mac dinh va KHONG tu mo project gan nhat. */
    projectOpen = false;
    projectDirty = false;

    /*  ==========  MOC 75: AP DUNG CHE DO KHOI DONG  ==========

        Dat o CUOI constructor, KHONG dat som hon -- day la cho duy nhat dung.

        Ly do: addAndMakeVisible() luon dat visible = true. Trong constructor
        nay co addAndMakeVisible cho inspector, inspectorSplitter,
        trackListViewport, mixerView, menuBar... nam rai rac; goi
        setVisible(false) truoc bat ky cai nao trong so do la bi no ghi de
        ngay sau, va anh se thay bang van hien du da chon "chi bang dieu
        khien".  */
    applyStartupLayoutMode (1);   // MOC 96: project luon bat dau khoa, chi Bang dieu khien

    setSize (1240, 760);

    // Vi tri cua so plugin lan truoc + danh sach file .NT mo gan day
    loadWindowLayout();
    loadRecentList();
    refreshProjectHub();

    /*  Neu anh dup-click 1 file .NT (fileToOpenDirectly khong rong): BO QUA
        loadProject() -- khong con phai nap du an LAN TRUOC len roi vut ngay
        di de nap file that su can nua. Vua nhanh hon, vua tranh loi cua du
        an cu (vd VST thieu/loi trong do) hien ra du file dang mo khong lien
        quan gi ca. */
    if (fileToOpenDirectly != juce::File() && fileToOpenDirectly.existsAsFile())
    {
        openProjectFile (fileToOpenDirectly);

        // Chan doan: ghi ket qua mo thang file .NT vao startup.log.
        juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
            .getChildFile ("LiveNT").getChildFile ("startup.log")
            .appendText (juce::Time::getCurrentTime().toString (true, true) + "  "
                         + (projectOpen ? "Da mo du an: " + currentProjectFile.getFullPathName()
                                        : "KHONG mo duoc du an tu file: " + fileToOpenDirectly.getFullPathName()
                                          + (projectLoadInProgress ? " (dang nap)" : juce::String())
                                          + (pluginLoadInProgress ? " (dang nap VST)" : juce::String()))
                         + "\n");
    }

    rebuildTrackList();
    if (projectOpen)
        selectTrack (0);
    else
        inspector.setTrack (nullptr); closeChannelOverview();
    updateTitleText();
    updateProjectUiState();

    /*  Cu 60 giay tu luu mot lan ra project.pending. Ghi bang SafeFile nen
        khong bao gio lam hong file du an that.  */
    startTimer (1000);

    childRaiser.mainWindow = [this] { return getTopLevelComponent(); };
    childRaiser.paused = [this] { return windowsLowered; };
    childRaiser.shouldFloat = [this]
    {
        return loadMainAlwaysOnTopPreference()
            || (youtube.isRunning() && YouTubeLauncher::isAlwaysOnTop());
    };
    childRaiser.startTimer (120);

    {
        auto raiser = std::make_unique<livent::ForeignDialogRaiser>();
        raiser->paused = [this] { return windowsLowered; };
        foreignRaiser = std::move (raiser);
    }

    /*  Lan truoc co bi treo khong? Hoi sau khi cua so da hien ra.

        MOC 23: SafePointer chu khong phai "this" tran. 600 ms la du lau de
        nguoi dung kip dong app (nhat la khi app vua len da bao loi card am
        thanh) -- luc ay "this" da chet, goi vao la sap.  */
    {
        juce::Component::SafePointer<MainComponent> safeThis (this);

        juce::Timer::callAfterDelay (600, [safeThis]
        {
            if (safeThis != nullptr)
                safeThis->checkForCrashRecovery();
        });
    }

    juce::Component::SafePointer<MainComponent> permissionLifetime (this);
    juce::RuntimePermissions::request (juce::RuntimePermissions::recordAudio,
        [permissionLifetime] (bool granted)
        {
            if (permissionLifetime != nullptr)
                permissionLifetime->handleAudioPermissionResult (granted);
        });
}

void MainComponent::handleAudioPermissionResult (bool granted)
{
    requestedAudioInputs = granted ? 2 : 0;
    requestedAudioOutputs = 2;

    Splash::setStatus (livent::vn ("Đang mở soundcard... (lâu = driver đang phản hồi chậm)"));
    Splash::setProgress (0.08);
    Splash::setStep (Splash::Step::soundcard, Splash::StepState::running, livent::vn ("Đang mở driver..."));

    // 0.6.7.5: ve NGAY. Neu lenh mo driver ben duoi bi treo thi man hinh
    // khoi dong van noi dung cho nao thay vi dung im o 2%.
    Splash::forcePaintNow();

    // Nap lai cau hinh card da luu lan truoc
    auto saved = loadDeviceSettings();

    /*  ==========  0.6.7.5: LAN MO TRUOC BI TREO -> KHONG MO LAI Y HET  ==========

        openAudioDeviceGuarded() ghi file co "audio-opening.flag" truoc khi
        mo driver va xoa ngay khi ham mo TRA VE. Con file co nghia la lan
        truoc driver treo/crash trong luc mo (khach phai bam End Task).
        Mo lai dung audio.xml do se treo lai y het, khach ket vong lap.

        Nen: cat audio.xml (+ audio.lastgood.xml) sang ban .hung.xml de
        giu lai, roi mo thiet bi MAC DINH cua he dieu hanh.
        Khong ap dung khi dang KHOA SOUNDCARD - khoa la khong duoc tu
        nhay sang card khac.  */
    if (! soundcardLockEnabled && getAudioOpeningFlagFile().existsAsFile())
    {
        getAudioOpeningFlagFile().deleteFile();

        for (const char* name : { "audio.xml", "audio.lastgood.xml" })
        {
            auto f = PluginChain::getSettingsFolder().getChildFile (name);

            if (f.existsAsFile())
            {
                auto backup = f.getSiblingFile (f.getFileNameWithoutExtension() + ".hung.xml");
                backup.deleteFile();
                f.moveFileTo (backup);
            }
        }

        saved.reset();
        audioSafeModeAtStartup = true;
        livent::stabilityLog ("AUDIO safe-mode",
                              "lan mo audio truoc khong ket thuc -> bo audio.xml (giu audio.hung.xml), dung thiet bi mac dinh");
    }

    /*  ==========  MOC 26: LAN DAU CHI MO 2 DUONG VAO  ==========

        Truoc day cho nay xin 16 duong vao. Voi card thuong thi khong
        sao, nhung voi ASIO Link Pro (co hang chuc duong ao Link 1..16)
        thi JUCE bat SAN 16 duong do -- nen mo bang Cai dat am thanh
        len la thay Link 3/4, 5/6, 7/8... da tich het, dung nhu anh ta.

        Bat nhieu duong khong chi roi mat: moi duong vao la mot vung
        nho phai chep moi khoi am thanh, va Link Pro con lam tang tre.

        Gio mac dinh chi mo 2 duong. Anh muon dung Link 5/6 cho track
        nhac thi tu vao Cai dat am thanh tich them -- va tich xong la
        duoc LUU lai, lan sau mo app khong phai lam lai.

        Luu y: dong nay chi co tac dung LAN DAU (khi chua co audio.xml).
        Da co file cau hinh cu thi JUCE dung y nguyen file do.  */
    openAudioDeviceGuarded (saved.get(), requestedAudioInputs, "startup");

    audioEverHealthy = isAudioDeviceHealthy();
    audioWatchdogStartupGraceTicks = audioEverHealthy ? 0 : 6;

    if (soundcardLockEnabled
        && (! currentAudioMatchesSoundcardLock() || ! isAudioDeviceHealthy()))
    {
        /* V6.6.3: JUCE co the fallback sang Built-in/Default khi card
           USB chua cam. Tat fallback ngay va GIU NGUYEN audio.xml cu.
           Timer se thu lai cau hinh goc moi 2 giay. */
        shutdownAudio();
        audioInitialisedOnce = false;
        soundcardLockWaiting = true;
        soundcardLockRetryTicks = 0;
        statusLabel.setText (livent::vn ("CHỜ SOUNDCARD: ") + getSoundcardLockDisplayName(),
                             juce::dontSendNotification);
        statusLabel.setColour (juce::Label::textColourId, Col::amber);
        Splash::setStep (Splash::Step::soundcard, Splash::StepState::warning,
                         livent::vn ("Chờ card khóa: ") + getSoundcardLockDisplayName());
    }
    else
    {
        soundcardLockWaiting = false;
        audioInitialisedOnce = true;
        updateStatusText();
        inspector.rebuildRouting();

        // 06/10: man khoi dong mau B - "Ten card · ASIO 48 kHz"
        if (auto* dev = deviceManager.getCurrentAudioDevice(); dev != nullptr && isAudioDeviceHealthy())
        {
            juce::String d = dev->getName() + "  ·  " + deviceManager.getCurrentAudioDeviceType();
            const double sr = dev->getCurrentSampleRate();
            if (sr > 0) d << " " << juce::String (sr / 1000.0, sr == std::floor (sr / 1000.0) * 1000.0 ? 0 : 1) << " kHz";
            Splash::setStep (Splash::Step::soundcard, Splash::StepState::done, d);
        }
        else
            Splash::setStep (Splash::Step::soundcard, Splash::StepState::warning,
                             livent::vn ("Chưa mở được - vào DAW chọn lại (F4)"));
    }

    Splash::setStatus (livent::vn ("Đang chuẩn bị quét VST..."));
    Splash::setProgress (0.16);

    /*  V4.5: QUÉT NHANH VST MỚI khi mở LiveNT, giống cách các DAW
        lớn kiểm tra plugin lúc khởi động.

        StartupScanner KHÔNG quét lại cả nghìn VST đã biết: nó dùng
        plugins.xml + isListingUpToDate() để bỏ qua file cũ, chỉ đưa
        file MỚI/ĐÃ ĐỔI sang process scanner. Chạy Priority::low và
        chờ 1.8 giây sau khi card đã mở để không tranh CPU đúng lúc
        audio engine vừa khởi tạo.

        Quét thủ công trong Studio vẫn giữ nguyên cho lúc anh muốn
        quét lại toàn bộ. */
    {
        juce::Component::SafePointer<MainComponent> safeThis (this);
        juce::Timer::callAfterDelay (150, [safeThis]
        {
            if (safeThis != nullptr)
                safeThis->startBackgroundScan();
        });
    }
}

MainComponent::~MainComponent()
{
    livent::builtinkey::Detector::get().shutdown();   // 12s: dung luong T-AutoKey (khong giet cuong buc)
    expandedEqWindow.reset();
   #if JUCE_WINDOWS
    audioGuideWindow.reset();
   #endif
    shortcutRouter.onKey = nullptr;
    juce::Desktop::getInstance().removeGlobalMouseListener (&areaFocusListener);
    mixer.onRenderTimelineClip = nullptr;
    mixer.onJoinTimelineClips = nullptr;
    mixer.shortcutDescription = nullptr;
    if (clipJoinJob != nullptr) clipJoinJob->cancel.store (true);
    if (clipJoinWorker.joinable()) clipJoinWorker.join();
    clipJoinJob.reset();
    if(packageJob)packageJob->cancel.store(true);
    if(packageWorker.joinable())packageWorker.join();
    packageJob.reset();mixer.setBackgroundWorkActive(false);
    for (auto* button : std::initializer_list<juce::TextButton*> { &topSaveSongButton, &topSongListButton, &topSettingsButton, &topHelpButton })
        button->setLookAndFeel (nullptr);
    if (timelineExportCancel != nullptr) timelineExportCancel->store (true);
    if (timelineExportWorker.joinable()) timelineExportWorker.join();
    mixer.endOfflineExport();
    autoKeyController.stop();
    childRaiser.stopTimer();
    foreignRaiser.reset();
    YouTubeLauncher::openInDawHandler = nullptr;
    audioDiagnosticsActive.store (false, std::memory_order_relaxed);
    PluginChain::setDiagnosticTimingEnabled (false);
    stopTimer();
    if (lockedSoundcardProbe != nullptr && lockedSoundcardProbe->isRunning())
        lockedSoundcardProbe->kill();
    lockedSoundcardProbe.reset();
    if (lockedSoundcardProbeResult != juce::File())
        lockedSoundcardProbeResult.deleteFile();
    stopCompanionApp (true);
    // 12u: dong trinh duyet LiveNT da mo YouTube (nhu bam X, khong ep tat)
    if (browserSession != nullptr && livent::browsersession::autoEnabled())
        browserSession->closeOpened();

    // HOTFIX10: moi callback project-loader cu phai tu rung khi app bat dau huy.
    ++projectLoadGeneration;
    projectLoadCancelRequested = true;
    projectLoadInProgress = false;

    // Bảng Cài đặt là cửa sổ nổi giữ nội dung trỏ về MainComponent.
    // Đóng nó trước khi tháo các bảng/âm thanh còn lại.
    settingsWindow.reset();

    /*  MOC 33: tra thanh menu he thong ve cho macOS TRUOC MOI THU.

        Thanh menu tren cung man hinh la cua CA MAY, khong phai cua cua so
        nay. Neu app thoat ma khong tra lai, macOS van con giu con tro toi
        MainComponent da chet, va lan sau no hoi noi dung menu la sap.  */
   #if JUCE_MAC
    juce::MenuBarModel::setMacMainMenu (nullptr);
   #endif

    /*  MOC 74: khong con toneWindow de thao - bang Do Tone luon la con truc
        tiep cua MainComponent, JUCE tu don.  */

    saveMixerLayout();
    /*  MOC 56: tuong tu cho ban tron - cua so rieng giu con tro toi mixerView,
        phai thao ra truoc khi MainComponent (chu cua mixerView) bi huy.  */
    if (mixerWindow != nullptr)
    {
        mixerWindow->clearContentComponent();
        mixerWindow.reset();
    }

    /*  MOC 93: cung ly do cho cua so BAN LAM VIEC. No giu con tro toi
        workArea (setContentNonOwned), ma workArea lai dang giu ba component
        thuoc so huu cua MainComponent. Thao theo dung thu tu: go noi dung ->
        xoa cua so -> keo ba bang ve lam con cua MainComponent, de JUCE don
        chung theo duong binh thuong.

        Goi closeWorkWindow() thay vi viet lai o day: mot viec mot cho, sua
        mot lan la ca hai duong cung dung.  */
    closeWorkWindow();

    /*  Cat luong quet TRUOC MOI THU. No dang doc/ghi KnownPluginList va bung
        tien trinh con; de no chay tiep trong luc app thao do la sap chac.

        MOC 60: bao no DUNG ngay day, roi lam cac viec khac (luu cau hinh, luu
        bo cuc) TRUOC khi ngoi cho no thoat han.

        Truoc day goi thang reset() - vua bao dung vua ngoi cho luon, ma trong
        luc cho thi khong lam gi ca. Gio bao truoc thi no co vai tram mili giay
        de tu ket thuc trong khi minh dang luu file - toi luc cho thi thuong
        no da xong roi.  */
    if (startupScanner != nullptr)
        startupScanner->signalThreadShouldExit();

    Splash::close();

    saveDeviceSettings();
    saveWindowLayout();
    PluginChain::savePluginList();

    //  MOC 60: gio moi ngoi cho luong quet thoat han (thuong da xong tu truoc)
    startupScanner.reset();

    /*  Thoat SACH: xoa file autosave.NT. Lan mo sau khong thay no thi biet
        la lan nay thoat binh thuong, khong hoi khoi phuc.  */
    clearAutosave();

    PluginChain::onPluginAboutToBeDestroyed = nullptr;
    autoKeyController.stop();
    pluginWindows.closeAll();
    shutdownAudio();
}

//=============================================================================
//  Luu / nap cau hinh card
//=============================================================================
void MainComponent::saveDeviceSettings()
{
    /* V6.6.3: khi soundcard dang bi khoa ma card chua cam, AudioDeviceManager
       co the tam roi sang Built-in/Default. Tuyet doi KHONG duoc ghi trang
       thai fallback do de len audio.xml cu, neu khong lan sau cam card lai
       cung mat routing. */
    if (soundcardLockEnabled
        && (soundcardLockWaiting || ! currentAudioMatchesSoundcardLock() || ! isAudioDeviceHealthy()))
        return;

    if (auto xml = deviceManager.createStateXml())
        SafeFile::writeXml (*xml, PluginChain::getSettingsFolder().getChildFile ("audio.xml"), false);
}

std::unique_ptr<juce::XmlElement> MainComponent::loadDeviceSettings()
{
    auto file = PluginChain::getSettingsFolder().getChildFile ("audio.xml");

    if (file.existsAsFile())
        return juce::XmlDocument::parse (file);

    return nullptr;
}

//=============================================================================
//  0.6.7.5 - MO AUDIO CO GHI DAU VET
//=============================================================================
juce::File MainComponent::getAudioOpeningFlagFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("audio-opening.flag");
}

void MainComponent::logAudioDeviceSnapshot (const juce::String& stage, juce::uint32 elapsedMs)
{
    juce::String d;
    d << "type=" << deviceManager.getCurrentAudioDeviceType();

    if (auto* dev = deviceManager.getCurrentAudioDevice())
    {
        d << " | name=" << dev->getName()
          << " | open=" << (dev->isOpen() ? 1 : 0)
          << " | playing=" << (dev->isPlaying() ? 1 : 0)
          << " | sr=" << juce::String (dev->getCurrentSampleRate(), 0)
          << " | buf=" << dev->getCurrentBufferSizeSamples()
          << " | in=" << dev->getActiveInputChannels().countNumberOfSetBits()
          << " | out=" << dev->getActiveOutputChannels().countNumberOfSetBits()
          << " | err=" << dev->getLastError();
    }
    else
    {
        d << " | device=NULL";
    }

    d << " | ms=" << (int) elapsedMs;
    livent::stabilityLog (stage, d);

    // Mo khong duoc thi liet ke luon driver/thiet bi may nay dang co, de doc log
    // la biet may khach co gi ma khong phai hoi lai.
    if (! isAudioDeviceHealthy())
    {
        for (auto* type : deviceManager.getAvailableDeviceTypes())
        {
            if (type == nullptr)
                continue;

            livent::stabilityLog ("AUDIO drivers",
                                  type->getTypeName()
                                    + " | in=[" + type->getDeviceNames (true).joinIntoString (", ")
                                    + "] | out=[" + type->getDeviceNames (false).joinIntoString (", ") + "]");
        }
    }
}

juce::uint32 MainComponent::openAudioDeviceGuarded (const juce::XmlElement* saved, int numInputs,
                                                    const juce::String& why)
{
    const auto flag = getAudioOpeningFlagFile();
    flag.replaceWithText (why);

    const auto t0 = juce::Time::getMillisecondCounter();
    livent::stabilityLog ("AUDIO open begin", why);

    try
    {
        setAudioChannels (numInputs, requestedAudioOutputs, saved);
    }
    catch (...)
    {
        livent::stabilityLog ("AUDIO open EXCEPTION", why);
    }

    // Toi day nghia la driver DA tra ve (thanh cong hay that bai deu duoc).
    flag.deleteFile();

    const auto elapsed = juce::Time::getMillisecondCounter() - t0;
    logAudioDeviceSnapshot ("AUDIO open end", elapsed);
    return elapsed;
}


//=============================================================================
// V6.6.3 - KHOA SOUNDCARD
//=============================================================================
void MainComponent::loadSoundcardLockState()
{
    soundcardLockEnabled = false;
    soundcardLockWaiting = false;
    soundcardLockAlertShown = false;
    soundcardLockRetryTicks = 0;
    soundcardLockDeviceType.clear();
    soundcardLockInputName.clear();
    soundcardLockOutputName.clear();
    soundcardLockBackendAsioDriver.clear();
    soundcardLockWindowsPhysicalDevice.clear();
    soundcardLockRequiresWindowsPhysicalDevice = false;

    auto file = PluginChain::getSettingsFolder().getChildFile ("soundcard-lock.xml");
    if (! file.existsAsFile())
        return;

    auto xml = juce::XmlDocument::parse (file);
    if (xml == nullptr || ! xml->hasTagName ("SOUNDCARD_LOCK"))
        return;

    soundcardLockEnabled    = xml->getBoolAttribute ("enabled", true);
    soundcardLockDeviceType = xml->getStringAttribute ("deviceType").trim();
    soundcardLockInputName  = xml->getStringAttribute ("inputDevice").trim();
    soundcardLockOutputName = xml->getStringAttribute ("outputDevice").trim();
    soundcardLockBackendAsioDriver = xml->getStringAttribute ("backendAsioDriver").trim();
    soundcardLockWindowsPhysicalDevice = xml->getStringAttribute ("windowsPhysicalDevice").trim();
    soundcardLockRequiresWindowsPhysicalDevice = xml->getBoolAttribute ("requiresWindowsPhysicalDevice", false);

    if (soundcardLockInputName.isEmpty() && soundcardLockOutputName.isEmpty())
        soundcardLockEnabled = false;
}

juce::String MainComponent::getSoundcardLockDisplayName() const
{
    if (soundcardLockWindowsPhysicalDevice.isNotEmpty())
    {
        const auto driver = soundcardLockBackendAsioDriver.isNotEmpty()
                          ? soundcardLockBackendAsioDriver : soundcardLockOutputName;
        return soundcardLockWindowsPhysicalDevice + (driver.isNotEmpty() ? " (" + driver + ")" : juce::String());
    }
    if (soundcardLockBackendAsioDriver.isNotEmpty())
        return soundcardLockBackendAsioDriver;
    if (soundcardLockOutputName.isNotEmpty())
        return soundcardLockOutputName;
    if (soundcardLockInputName.isNotEmpty())
        return soundcardLockInputName;
    return livent::vn ("Chưa có thiết bị");
}

bool MainComponent::currentAudioMatchesSoundcardLock() const
{
    if (! soundcardLockEnabled)
        return true;

   #if JUCE_WINDOWS
    // Message-thread watchdog only: never enumerate Windows devices in DSP.
    if (soundcardLockDeviceType.containsIgnoreCase ("ASIO")
        && (livent::safeaudio::isAsioLinkName (soundcardLockInputName)
            || livent::safeaudio::isAsioLinkName (soundcardLockOutputName))
        && soundcardLockBackendAsioDriver.isEmpty())
        return false;

    if (soundcardLockRequiresWindowsPhysicalDevice || soundcardLockWindowsPhysicalDevice.isNotEmpty()
        || livent::safeaudio::requiresWindowsPhysicalDevice (soundcardLockDeviceType,
               soundcardLockInputName, soundcardLockOutputName, soundcardLockBackendAsioDriver))
        if (livent::safeaudio::verifyWindowsPhysicalDevice (soundcardLockWindowsPhysicalDevice).isNotEmpty())
            return false;
   #endif

    auto* dev = deviceManager.getCurrentAudioDevice();
    if (dev == nullptr)
        return false;

    juce::AudioDeviceManager::AudioDeviceSetup setup;
    deviceManager.getAudioDeviceSetup (setup);

    if (soundcardLockDeviceType.isNotEmpty()
        && ! deviceManager.getCurrentAudioDeviceType().equalsIgnoreCase (soundcardLockDeviceType))
        return false;

    if (soundcardLockInputName.isNotEmpty()
        && ! setup.inputDeviceName.equalsIgnoreCase (soundcardLockInputName))
        return false;

    if (soundcardLockOutputName.isNotEmpty()
        && ! setup.outputDeviceName.equalsIgnoreCase (soundcardLockOutputName))
        return false;

    return true;
}

void MainComponent::toggleSoundcardLock()
{
    if (soundcardLockEnabled)
    {
        const bool wasWaiting = soundcardLockWaiting;
        soundcardLockEnabled = false;
        soundcardLockWaiting = false;
        soundcardLockAlertShown = false;
        soundcardLockDeviceType.clear();
        soundcardLockInputName.clear();
        soundcardLockOutputName.clear();
        soundcardLockBackendAsioDriver.clear();
        soundcardLockWindowsPhysicalDevice.clear();
        soundcardLockRequiresWindowsPhysicalDevice = false;
        PluginChain::getSettingsFolder().getChildFile ("soundcard-lock.xml").deleteFile();

        // Neu nguoi dung mo khoa trong luc dang cho card, cho phep JUCE mo
        // Default/Built-in lai ngay - day la hanh dong co y cua nguoi dung.
        if (wasWaiting)
        {
            auto saved = loadDeviceSettings();
            setAudioChannels (requestedAudioInputs, requestedAudioOutputs, saved.get());
            audioInitialisedOnce = true;
            inspector.rebuildRouting();
            updateStatusText();
        }

        livent::alert (livent::vn ("Đã mở khóa soundcard"),
                       livent::vn ("LiveNT sẽ lại cho phép chọn thiết bị âm thanh khác khi khởi động."));
    }
    else
    {
        auto* dev = deviceManager.getCurrentAudioDevice();
        if (dev == nullptr || ! isAudioDeviceHealthy())
        {
            livent::alert (livent::vn ("Chưa thể khóa soundcard"),
                           livent::vn ("Hãy cắm và mở đúng soundcard trước, sau đó bật KHÓA SOUNDCARD."),
                           juce::MessageBoxIconType::WarningIcon);
        }
        else
        {
            juce::AudioDeviceManager::AudioDeviceSetup setup;
            deviceManager.getAudioDeviceSetup (setup);

            soundcardLockDeviceType = deviceManager.getCurrentAudioDeviceType();
            soundcardLockInputName  = setup.inputDeviceName.trim();
            soundcardLockOutputName = setup.outputDeviceName.trim();

           #if JUCE_WINDOWS
            // Wrappers need the manual panel to select their backend and/or
            // the actual Windows audio adapter. Never lock just the wrapper.
            if (soundcardLockDeviceType.containsIgnoreCase ("ASIO")
                && (livent::safeaudio::isAsioLinkName (soundcardLockInputName)
                    || livent::safeaudio::isAsioLinkName (soundcardLockOutputName)
                    || livent::safeaudio::requiresWindowsPhysicalDevice (soundcardLockDeviceType,
                           soundcardLockInputName, soundcardLockOutputName)))
            {
                soundcardLockDeviceType.clear();
                soundcardLockInputName.clear();
                soundcardLockOutputName.clear();
                openAudioSettings (true);
                return;
            }
           #endif

            soundcardLockEnabled    = true;
            soundcardLockWaiting    = false;
            soundcardLockAlertShown = false;
            soundcardLockBackendAsioDriver.clear();
            soundcardLockWindowsPhysicalDevice.clear();
            soundcardLockRequiresWindowsPhysicalDevice = false;

            juce::XmlElement xml ("SOUNDCARD_LOCK");
            xml.setAttribute ("enabled", true);
            xml.setAttribute ("deviceType", soundcardLockDeviceType);
            xml.setAttribute ("inputDevice", soundcardLockInputName);
            xml.setAttribute ("outputDevice", soundcardLockOutputName);

            if (! SafeFile::writeXml (xml,
                                      PluginChain::getSettingsFolder().getChildFile ("soundcard-lock.xml"),
                                      false))
            {
                soundcardLockEnabled = false;
                livent::alert (livent::vn ("Không lưu được khóa soundcard"),
                               livent::vn ("LiveNT chưa thể ghi file cấu hình khóa."),
                               juce::MessageBoxIconType::WarningIcon);
            }
            else
            {
                // Chot lai audio.xml dung card dang khoa ngay tai thoi diem nay.
                saveDeviceSettings();
                livent::alert (livent::vn ("Đã khóa soundcard"),
                               livent::vn ("LiveNT đã khóa: ") + getSoundcardLockDisplayName()
                               + livent::vn ("\n\nTừ lần mở sau, nếu không tìm thấy/mở được đúng thiết bị này thì LiveNT sẽ không cho vào giao diện DAW."));
            }
        }
    }
    // 02/10: KHONG dong bang Cai dat nua - cong tac doc lai trang thai that.
}

void MainComponent::showSoundcardLockWarningIfNeeded()
{
    if (! soundcardLockEnabled || ! soundcardLockWaiting || soundcardLockAlertShown)
        return;

    auto* top = getTopLevelComponent();
    if (top == nullptr || ! top->isVisible())
        return;

    soundcardLockAlertShown = true;
    livent::alert (livent::vn ("CHƯA TÌM THẤY SOUNDCARD"),
                   livent::vn ("VUI LÒNG CẮM SOUNDCARD ") + getSoundcardLockDisplayName()
                   + livent::vn (" ĐỂ KHÔNG BỊ MẤT ÂM THANH.\n\nLiveNT đang giữ nguyên cấu hình cũ và sẽ tự kết nối khi thiết bị xuất hiện."),
                   juce::MessageBoxIconType::WarningIcon);
}

void MainComponent::updateSoundcardLockStartupWait()
{
    if (! soundcardLockEnabled || ! soundcardLockWaiting)
        return;

    if (audioSettingsProcess != nullptr)
        return;

    showSoundcardLockWarningIfNeeded();

    statusLabel.setText (livent::vn ("CHỜ SOUNDCARD: ") + getSoundcardLockDisplayName(),
                         juce::dontSendNotification);
    statusLabel.setColour (juce::Label::textColourId, Col::amber);

    if (lockedSoundcardProbe != nullptr)
    {
        if (lockedSoundcardProbe->isRunning())
        {
            if (juce::Time::getMillisecondCounter() - lockedSoundcardProbeStartedMs < 5000u)
                return;

            lockedSoundcardProbe->kill();
            lockedSoundcardProbe.reset();
            lockedSoundcardProbeResult.deleteFile();
            soundcardLockRetryTicks = -3; // retry after a pause, not every tick
            return;
        }

        lockedSoundcardProbe.reset();
        auto result = juce::XmlDocument::parse (lockedSoundcardProbeResult);
        lockedSoundcardProbeResult.deleteFile();
        if (result == nullptr || ! result->hasTagName ("SOUNDCARD_GATE_RESULT")
            || ! result->getBoolAttribute ("allow", false))
        {
            soundcardLockRetryTicks = -3;
            return;
        }

        // The helper has opened exactly the locked card. Only now ask the
        // main process to connect; preserve the existing no-fallback check.
    }
    else
    {
        if (++soundcardLockRetryTicks < 2)
            return;
        soundcardLockRetryTicks = 0;

        const auto token = juce::Uuid().toString();
        lockedSoundcardProbeResult = juce::File::getSpecialLocation (juce::File::tempDirectory)
                                         .getChildFile ("LiveNT-soundcard-gate-" + token + ".xml");
        lockedSoundcardProbeResult.deleteFile();
        juce::StringArray args;
        args.add (juce::File::getSpecialLocation (juce::File::currentExecutableFile).getFullPathName());
        args.add ("--soundcard-gate-probe=" + token);
        auto probe = std::make_unique<juce::ChildProcess>();
        if (! probe->start (args))
        {
            soundcardLockRetryTicks = -3;
            return;
        }
        lockedSoundcardProbeStartedMs = juce::Time::getMillisecondCounter();
        lockedSoundcardProbe = std::move (probe);
        return;
    }

    try
    {
        auto saved = loadDeviceSettings();
        setAudioChannels (requestedAudioInputs, requestedAudioOutputs, saved.get());

        if (currentAudioMatchesSoundcardLock() && isAudioDeviceHealthy())
        {
            soundcardLockWaiting = false;
            audioInitialisedOnce = true;
            audioWatchdogFault = false;
            audioWatchdogBadTicks = 0;
            audioWatchdogRetryCooldown = 0;
            audioWatchdogRecoveredTicks = 3;

            statusLabel.setText (livent::vn ("ĐÃ KẾT NỐI SOUNDCARD: ") + getSoundcardLockDisplayName(),
                                 juce::dontSendNotification);
            statusLabel.setColour (juce::Label::textColourId, Col::green);
            inspector.rebuildRouting();
            refitInspector();
            return;
        }

        // Neu JUCE roi sang Built-in/Default thi tat ngay va cho tiep.
        shutdownAudio();
        audioInitialisedOnce = false;
    }
    catch (...)
    {
        shutdownAudio();
        audioInitialisedOnce = false;
    }
}

//=============================================================================
// V6.6.3 - UNG DUNG MO CUNG LIVENT
//=============================================================================
void MainComponent::loadCompanionAppPreference()
{
    if (companions != nullptr)
        companions->load (PluginChain::getSettingsFolder());
}

void MainComponent::saveCompanionAppPreference()
{
    if (companions != nullptr)
        companions->save (PluginChain::getSettingsFolder());
}

juce::String MainComponent::getCompanionAppDisplayName() const
{
    return companions != nullptr ? companions->displayName() : livent::vn ("Chưa chọn");
}

void MainComponent::chooseCompanionApp()
{
    settingsWindow.reset();

   #if JUCE_MAC
    const auto pattern = juce::String ("*.app");
    const int flags = juce::FileBrowserComponent::openMode
                    | juce::FileBrowserComponent::canSelectFiles
                    | juce::FileBrowserComponent::canSelectDirectories;
   #else
    const auto pattern = juce::String ("*.exe");
    const int flags = juce::FileBrowserComponent::openMode
                    | juce::FileBrowserComponent::canSelectFiles;
   #endif

    juce::File start = juce::File::getSpecialLocation (juce::File::userHomeDirectory);
    if (companions != nullptr && ! companions->isEmpty())
        start = companions->files().getLast().getParentDirectory();

    fileChooser = std::make_unique<juce::FileChooser> (livent::vn ("Thêm ứng dụng mở cùng LiveNT"),
                                                       start, pattern);

    juce::Component::SafePointer<MainComponent> safeThis (this);
    fileChooser->launchAsync (flags, [safeThis] (const juce::FileChooser& fc)
    {
        if (safeThis == nullptr || safeThis->companions == nullptr)
            return;

        auto picked = fc.getResult();
        if (picked == juce::File())
            return;

       #if JUCE_MAC
        const bool valid = picked.isDirectory() && picked.getFileExtension().equalsIgnoreCase (".app");
       #else
        const bool valid = picked.existsAsFile() && picked.getFileExtension().equalsIgnoreCase (".exe");
       #endif

        if (! valid)
        {
            livent::alert (livent::vn ("Ứng dụng không hợp lệ"),
                           livent::vn ("Hãy chọn đúng ứng dụng (.app trên macOS hoặc .exe trên Windows)."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        // 12u: THEM vao danh sach (khong thay app cu).
        safeThis->companions->add (picked);
        safeThis->saveCompanionAppPreference();

        // Neu DAW da hien xong thi mo app vua chon ngay, khong can doi lan sau.
        if (safeThis->mainWindowRevealed && ! safeThis->companions->launchOne (picked))
            livent::alert (livent::vn ("Không mở được ứng dụng đi kèm"), picked.getFullPathName(),
                           juce::MessageBoxIconType::WarningIcon);
    });
}

void MainComponent::showCompanionAppMenu()
{
    if (companions == nullptr || companions->isEmpty())
    {
        chooseCompanionApp();
        return;
    }

    const auto apps = companions->files();
    juce::PopupMenu m;
    m.addSectionHeader (livent::vn ("Ứng dụng mở cùng (tắt LiveNT là tắt hết)"));
    for (int i = 0; i < apps.size(); ++i)
    {
        juce::PopupMenu one;
        one.addItem (200 + i, livent::vn ("Mở thử ngay"));
        one.addItem (100 + i, livent::vn ("Bỏ khỏi danh sách (đóng app này)"));
        m.addSubMenu (livent::companions::Manager::nameOf (apps[i]), one);
    }
    m.addSeparator();
    m.addItem (1, livent::vn ("Thêm ứng dụng..."));
    m.addItem (2, livent::vn ("Mở thử tất cả"));
    m.addSeparator();
    m.addItem (3, livent::vn ("Bỏ hết ứng dụng mở cùng"));

    juce::Component::SafePointer<MainComponent> safeThis (this);
    m.showMenuAsync (livent::menuAtPointer (this), [safeThis, apps] (int result)
    {
        if (safeThis == nullptr || safeThis->companions == nullptr || result == 0)
            return;

        if (result == 1) { safeThis->chooseCompanionApp(); return; }
        if (result == 2) { safeThis->launchCompanionApp(); return; }
        if (result == 3)
        {
            safeThis->companions->clear (true);
            safeThis->saveCompanionAppPreference();
            safeThis->settingsWindow.reset();
            return;
        }
        if (result >= 200 && result < 200 + apps.size())
        {
            if (! safeThis->companions->launchOne (apps[result - 200]))
                livent::alert (livent::vn ("Không mở được ứng dụng đi kèm"), apps[result - 200].getFullPathName(),
                               juce::MessageBoxIconType::WarningIcon);
            return;
        }
        if (result >= 100 && result < 100 + apps.size())
        {
            safeThis->companions->remove (apps[result - 100], true);
            safeThis->saveCompanionAppPreference();
            safeThis->settingsWindow.reset();
        }
    });
}

void MainComponent::launchCompanionApp()
{
    if (companions == nullptr || companions->isEmpty())
        return;

    const auto failed = companions->launchAll();   // app dang chay thi khong mo them ban nua
    if (! failed.isEmpty())
        livent::alert (livent::vn ("Không mở được ứng dụng đi kèm"), failed.joinIntoString ("\n"),
                       juce::MessageBoxIconType::WarningIcon);
}

void MainComponent::stopCompanionApp (bool waitForExit)
{
    if (companions != nullptr)
        companions->stopAll (waitForExit);   // dong binh thuong, doi toi 2 giay, con sot thi buoc tat
}

void MainComponent::openYouTubeInBrowser (bool quietIfFails)
{
    const auto id = livent::external::loadBrowserChoice();
    if (browserSession != nullptr)
        browserSession->noteOpening (id);   // ghi nhan TRUOC khi mo: trinh duyet co chay san khong
    if (! livent::external::openUrl (id, "https://www.youtube.com") && ! quietIfFails)
        livent::alert ("YouTube", livent::vn ("Không mở được trình duyệt. Chuột phải nút YouTube để chọn trình duyệt khác."),
                       juce::MessageBoxIconType::WarningIcon);
}

void MainComponent::onMainWindowRevealed()
{
    mainWindowRevealed = true;

    /* V6.6.4: khoa shortcut trong giai do khoi dong.
       F2/F3 tren Windows la hotkey toan cuc nen co the phat WM_HOTKEY ngay ca
       luc cua so chinh con an sau Splash. Neu nguoi dung dang giu phim F khi
       mo LiveNT, khong duoc de len giao dien xong la tu mo mot bang nao do.

       Chi mo khoa sau khi cua so chinh da hien VA tat ca phim F1..F12 da duoc
       tha het. Ham duoi tu hen lai neu van con phim dang duoc giu. */
    functionShortcutsReady = false;
    armFunctionShortcutsWhenReleased();

    showSoundcardLockWarningIfNeeded();

    // De GUI/audio on dinh xong mot nhip roi moi mo app ben ngoai.
    juce::Component::SafePointer<MainComponent> safeThis (this);
    juce::Timer::callAfterDelay (350, [safeThis]
    {
        if (safeThis != nullptr)
            safeThis->launchCompanionApp();
    });

    juce::Timer::callAfterDelay (500, [safeThis]
    {
        if (safeThis != nullptr)
            safeThis->openMusicVst2AfterProjectLoad();
    });

    // 12u: Cai dat > YouTube = "Trinh duyet rieng": mo LiveNT la tu mo trinh duyet
    // vao youtube.com (sau cac app mo cung de YouTube nam tren cung) - giong tool.
    juce::Timer::callAfterDelay (1300, [safeThis]
    {
        if (safeThis == nullptr || livent::youtube::useDawYouTube() || ! livent::browsersession::autoEnabled())
            return;
        safeThis->openYouTubeInBrowser (true);
    });

    // Cai dat > YouTube = "YouTube trong DAW": mo DAW la cua so YouTube tu mo
    // (dung vi tri/kich thuoc da nho). Khach lo tat thi bam nut YouTube tren
    // thanh tren cung, khong phai vao Cai dat.
    juce::Timer::callAfterDelay (900, [safeThis]
    {
        if (safeThis == nullptr || ! livent::youtube::useDawYouTube())
            return;

        safeThis->publishDawWindowForYouTube();
        juce::String ignored;   // thieu LiveNT-YouTube: nut YouTube se bao khi bam
        (void) safeThis->youtube.openOrBringToFront (ignored);
    });
}

void MainComponent::armFunctionShortcutsWhenReleased()
{
    juce::Component::SafePointer<MainComponent> safeThis (this);

    juce::Timer::callAfterDelay (120, [safeThis]
    {
        if (safeThis == nullptr || ! safeThis->mainWindowRevealed)
            return;

        const int fKeys[] =
        {
            juce::KeyPress::F1Key,  juce::KeyPress::F2Key,
            juce::KeyPress::F3Key,  juce::KeyPress::F4Key,
            juce::KeyPress::F5Key,  juce::KeyPress::F6Key,
            juce::KeyPress::F7Key,  juce::KeyPress::F8Key,
            juce::KeyPress::F9Key,  juce::KeyPress::F10Key,
            juce::KeyPress::F11Key, juce::KeyPress::F12Key
        };

        for (const auto keyCode : fKeys)
        {
            if (juce::KeyPress::isKeyCurrentlyDown (keyCode))
            {
                // Van dang giu phim luc khoi dong: doi toi khi tha that su.
                safeThis->armFunctionShortcutsWhenReleased();
                return;
            }
        }

        safeThis->functionShortcutsReady = true;
    });
}

//=============================================================================
//  MOC 21: chuot phai vao danh sach track -> them / xoa track, giong Cubase.
//  screenPos    : vi tri mo popup (vi tri chuot luc bam).
//  rightClickedTrack : khac nullptr neu bam dung tren mot track - luc do co
//                       them muc "Xoa track nay" o dau menu.
//=============================================================================
void MainComponent::duplicateTrack (Track* source)
{
    if(!mixer.waitForPendingTakes())
    {livent::alert(livent::vn("Bản thu đang chốt"),livent::vn("Chờ WAV hoàn tất rồi nhân đôi track lại."));return;}

    if (source == nullptr)
        return;

    /*  ==========  MOC 46: NHAN DOI TRACK  ==========

        Cach lam: bao track cu TU MO TA CHINH NO ra XML (dung cai getState da
        co san), tao track moi cung loai, roi bao track moi DOC lai ban mo ta
        do.

        Vi sao khong chep tung thu bang tay: chep tay thi moi lan them mot
        thiet lap moi vao Track la phai nho quay lai sua cho nay. Quen mot cai
        la track nhan doi thieu mot thu, va loai thieu sot do rat kho phat
        hien -- vd quen chep muc send thi phai hat mot luc moi nhan ra sao
        track moi khong co vang.

        Dung getState/setState thi bat ky thu gi luu duoc vao file .NT deu tu
        dong duoc nhan doi theo, mai mai, khong phai bao tri.  */
    if (mixer.isTimelineRecording() || mixer.isOfflineExporting())
    {
        livent::alert (livent::vn ("Chưa nhân đôi được"), livent::vn ("Hãy dừng thu hoặc chờ xuất xong trước khi nhân đôi track."));
        return;
    }
    auto state = source->getState();

    if (state == nullptr)
        return;

    auto* copy = mixer.addTrack (source->getType(), source->getName() + " 2");

    if (copy == nullptr)
    {
        livent::alert (livent::vn ("Không nhân đôi được"),
                       livent::vn ("Đã hết chỗ cho track mới."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    /*  Nho lai ma so va ten cua ban SAO truoc khi doc de len.

        setState() se doc ca ma so tu ban mo ta cu -- de nguyen thi hai track
        cung mang mot ma so, va moi thu dinh tuyen theo ma so (send, duong ra)
        deu tro nham cho. Doc xong dat lai ngay.  */
    const int  newId   = copy->getId();
    const auto newName = copy->getName();

    copy->setState (*state, &mixer.getFormatManager(), &mixer.getReadThread());

    copy->setId (newId);
    copy->setUuid (juce::Uuid().toString());   // V5.7: ban sao PHAI co identity rieng
    copy->setRole (Track::Role::None);         // role he thong khong duoc nhan doi
    copy->setName (newName);
    copy->setFixed (false);      // ban sao xoa duoc, khac ban goc

    mixer.waitForPendingTakes();
    mixer.getAra().copyTrackState (source->getUuid(), copy->getUuid());
    mixer.timelineEdit ([&] (TimelineState& timeline)
    {
        return livent::tledit::duplicateLane (timeline, source->getUuid(), copy->getUuid());
    });

    /*  MOC 51: dua ban sao ve NGAY SAU ban goc.

        addTrack() chen o cuoi (truoc nhom Output/PK), nen ban sao roi tan
        duoi cung - phai cuon di tim. Nhan doi la de so sanh hai ban canh
        nhau, dat xa nhau thi mat han y nghia.  */
    {
        const int fromIndex = mixer.indexOfTrack (copy);
        const int srcIndex  = mixer.indexOfTrack (source);

        if (fromIndex >= 0 && srcIndex >= 0)
            mixer.moveTrack (fromIndex, fromIndex > srcIndex ? srcIndex + 1 : srcIndex);
    }

    rebuildTrackList();
    relayoutAll();   // MOC 93
    markProjectDirty();
    updateTitleText();

    livent::alert (livent::vn ("Đã nhân đôi"),
                   livent::vn ("Track \"") + newName + livent::vn ("\" đã có các clip thu, VST và thiết lập "
                   "của \"") + source->getName() + livent::vn ("\".\n\n"
                   "Lưu ý: các VST được nạp lại từ đầu nên có thể mất vài giây."));
}

void MainComponent::showTrackListContextMenu (juce::Point<int> screenPos, Track* rightClickedTrack)
{
    if (! projectOpen)
    {
        livent::alert (livent::vn ("Chưa có dự án"),
                       livent::vn ("Tạo hoặc mở một dự án trước khi thêm track."));
        return;
    }

    juce::PopupMenu menu;

    if (rightClickedTrack != nullptr)
    {
        const bool isOutput = rightClickedTrack->getType() == Track::Type::Output;

        /* MOC 95: doi mau tung track ngay tu menu chuot phai. Dung preset
           de thao tac nhanh luc live, khong phai mo them hop thoai lon. */
        juce::PopupMenu colourMenu;
        const auto currentColour = rightClickedTrack->getColour();

        colourMenu.addItem (1101, livent::vn ("Xanh cyan"),   true, currentColour == juce::Colour (0xff3fa9d8));
        colourMenu.addItem (1102, livent::vn ("Cam"),         true, currentColour == juce::Colour (0xffd8963f));
        colourMenu.addItem (1103, livent::vn ("Xanh lá"),     true, currentColour == juce::Colour (0xff4ec96e));
        colourMenu.addItem (1104, livent::vn ("Hồng"),        true, currentColour == juce::Colour (0xffc85f9c));
        colourMenu.addItem (1105, livent::vn ("Vàng"),        true, currentColour == juce::Colour (0xffd8c93f));
        colourMenu.addItem (1106, livent::vn ("Tím"),         true, currentColour == juce::Colour (0xff8a6fd8));
        colourMenu.addItem (1107, livent::vn ("Đỏ"),          true, currentColour == juce::Colour (0xffd8534f));
        colourMenu.addItem (1108, livent::vn ("Xanh dương"),  true, currentColour == juce::Colour (0xff477fd1));
        colourMenu.addItem (1109, livent::vn ("Teal"),         true, currentColour == juce::Colour (0xff36a6a6));
        colourMenu.addItem (1110, livent::vn ("Xanh lime"),    true, currentColour == juce::Colour (0xff8abf45));
        colourMenu.addItem (1111, livent::vn ("Nâu"),          true, currentColour == juce::Colour (0xff9a7049));
        colourMenu.addItem (1112, livent::vn ("Xám"),          true, currentColour == juce::Colour (0xff7b7f89));
        menu.addSubMenu (livent::vn ("Đổi màu track..."), colourMenu);
        menu.addSeparator();

        //  MOC 46: nhan doi track, giu nguyen moi VST
        menu.addItem (6, livent::vn ("Nhân đôi track \"") + rightClickedTrack->getName() + livent::vn ("\""),
                      rightClickedTrack->getType() == Track::Type::Audio
                        || rightClickedTrack->getType() == Track::Type::Beat
                        || rightClickedTrack->getType() == Track::Type::FxBus
                        || rightClickedTrack->getType() == Track::Type::Group);

        menu.addItem (5, livent::vn ("Xóa track \"") + rightClickedTrack->getName() + livent::vn ("\""), ! isOutput);
        menu.addSeparator();
    }

    juce::PopupMenu addMenu;
    addMenu.addItem (1, livent::vn ("Audio Track   (mic, nhạc cụ)"));
    addMenu.addItem (2, livent::vn ("Beat Track    (nhạc nền)"));
    addMenu.addItem (3, livent::vn ("Group Track   (gộp nhiều track)"));
    addMenu.addItem (4, livent::vn ("FX Bus        (vang, delay)"));
    addMenu.addSeparator();
    addMenu.addItem (7, livent::vn ("PK Track      (nghe phụ / kiểm âm)"), mixer.getPkTrack() == nullptr);
    menu.addSubMenu (livent::vn ("Thêm track..."), addMenu);

    const int rightClickedTrackId = rightClickedTrack != nullptr ? rightClickedTrack->getId() : -1;

    menu.showMenuAsync (juce::PopupMenu::Options().withTargetScreenArea ({ screenPos.x, screenPos.y, 1, 1 }),
        [this, rightClickedTrackId] (int r)
        {
            if (r >= 1101 && r <= 1112 && rightClickedTrackId >= 0)
            {
                juce::Colour colour;

                switch (r)
                {
                    case 1101: colour = juce::Colour (0xff3fa9d8); break;
                    case 1102: colour = juce::Colour (0xffd8963f); break;
                    case 1103: colour = juce::Colour (0xff4ec96e); break;
                    case 1104: colour = juce::Colour (0xffc85f9c); break;
                    case 1105: colour = juce::Colour (0xffd8c93f); break;
                    case 1106: colour = juce::Colour (0xff8a6fd8); break;
                    case 1107: colour = juce::Colour (0xffd8534f); break;
                    case 1108: colour = juce::Colour (0xff477fd1); break;
                    case 1109: colour = juce::Colour (0xff36a6a6); break;
                    case 1110: colour = juce::Colour (0xff8abf45); break;
                    case 1111: colour = juce::Colour (0xff9a7049); break;
                    case 1112: colour = juce::Colour (0xff7b7f89); break;
                    default: return;
                }

                for (int i = 0; i < mixer.getNumTracks(); ++i)
                {
                    if (auto* t = mixer.getTrack (i); t != nullptr && t->getId() == rightClickedTrackId)
                    {
                        t->setColour (colour);
                        selectedTrackIndex = i;
                        break;
                    }
                }

                rebuildTrackList();
                mixerView.rebuild();
                mixerView.setSelectedTrack (mixer.getTrack (selectedTrackIndex));
                relayoutAll();
                markProjectDirty();
                updateTitleText();
                return;
            }

            if (r == 6 && rightClickedTrackId >= 0)
            {
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                    if (auto* t = mixer.getTrack (i); t != nullptr && t->getId() == rightClickedTrackId)
                    {
                        duplicateTrack (t);
                        break;
                    }

                return;
            }

            if (r == 5 && rightClickedTrackId >= 0)
            {
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                {
                    if (auto* t = mixer.getTrack (i); t != nullptr && t->getId() == rightClickedTrackId)
                    {
                        selectedTrackIndex = i;
                        removeSelectedTrack();
                        break;
                    }
                }

                return;
            }

            if (! ((r >= 1 && r <= 4) || r == 7))
                return;

            const auto type = r == 1 ? Track::Type::Audio
                            : r == 2 ? Track::Type::Beat
                            : r == 3 ? Track::Type::Group
                            : r == 4 ? Track::Type::FxBus
                                     : Track::Type::PK;

            const juce::String base = r == 1 ? "Audio " : r == 2 ? "Beat "
                                    : r == 3 ? "Group " : r == 4 ? "FX " : "PK";

            showAddTrackDialog(type, base.trim());
        });
}

void MainComponent::showAddTrackDialog(Track::Type type, const juce::String& base)
{
    if(mixer.isOfflineExporting() || mixer.isTimelineRecording()) return;
    auto* w=livent::makeAlert(livent::vn("Thêm track — ")+base,livent::vn("Chọn tên và đường âm thanh trước khi thêm."),juce::MessageBoxIconType::NoIcon);
    w->addTextEditor("name",base,livent::vn("Tên"));
    w->addComboBox("channels",{ "Mono", "Stereo" },livent::vn("Cấu hình"));
    w->getComboBoxComponent("channels")->setSelectedId(type==Track::Type::Audio?1:2);
    juce::StringArray inputs{livent::vn("Không kết nối")},outputs;
    juce::Array<int> inputIds{0},outputIds;
    const bool hasInput=type==Track::Type::Audio||type==Track::Type::Beat||type==Track::Type::PK;
    if(hasInput)
    {
        for(int i=0;i<mixer.getNumTracks();++i) if(auto* t=mixer.getTrack(i))
            if(type==Track::Type::PK ? t->getType()!=Track::Type::PK : t->getType()==Track::Type::Input)
            {inputs.add(t->getName());inputIds.add(t->getId());}
        w->addComboBox("input",inputs,livent::vn(type==Track::Type::PK?"Nguồn nghe":"Đầu vào"));
        w->getComboBoxComponent("input")->setSelectedId(1);
    }
    if(type==Track::Type::PK)
    {
        outputs.add(livent::vn("Không kết nối"));outputIds.add(-1);
        const auto names=inspector.getOutputChannelNames?inspector.getOutputChannelNames():juce::StringArray();
        for(int i=0;i+1<names.size() && i<64;i+=2){outputs.add(names[i]+" + "+names[i+1]);outputIds.add(i/2);}
    }
    else
        for(int i=0;i<mixer.getNumTracks();++i) if(auto* t=mixer.getTrack(i))
            if(t->getType()==Track::Type::Output||t->getType()==Track::Type::OutputBus||t->getType()==Track::Type::Group)
            {outputs.add(t->getName());outputIds.add(t->getId());}
    w->addComboBox("output",outputs,livent::vn("Đầu ra"));w->getComboBoxComponent("output")->setSelectedId(1);
    if(type!=Track::Type::PK)w->addTextEditor("count","1",livent::vn("Số lượng (1–32)"));
    w->addButton(livent::vn("Thêm"),1,juce::KeyPress(juce::KeyPress::returnKey));w->addButton(livent::vn("Hủy"),0,juce::KeyPress(juce::KeyPress::escapeKey));
    juce::Component::SafePointer<MainComponent> safe(this);
    w->setAlwaysOnTop(true);livent::centreDialog(w);
    w->enterModalState(true,juce::ModalCallbackFunction::create([safe,w,type,base,inputIds,outputIds,hasInput](int result)
    {
        if(result==1&&safe&&!safe->mixer.isTimelineRecording()&&!safe->mixer.isOfflineExporting())
        {
            const int count=type==Track::Type::PK?1:juce::jlimit(1,32,w->getTextEditorContents("count").getIntValue());
            auto name=w->getTextEditorContents("name").trim();if(name.isEmpty())name=base;
            const int inIndex=hasInput?w->getComboBoxComponent("input")->getSelectedId()-1:0;
            const int outIndex=w->getComboBoxComponent("output")->getSelectedId()-1;
            Track* last=nullptr;
            for(int n=0;n<count;++n) if(auto* t=safe->mixer.addTrack(type,count==1?name:name+" "+juce::String(n+1)))
            {
                t->setMonitor(false);t->setChannelMode(w->getComboBoxComponent("channels")->getSelectedId()==1?Track::Chan::Mono:Track::Chan::Stereo);
                if(type==Track::Type::PK)
                {t->setOutputTargetId(inputIds[inIndex]);const int pair=outputIds[outIndex];t->setOutPairMask(pair>=0?(1u<<(unsigned)pair):0);}
                else
                {if(juce::isPositiveAndBelow(outIndex,outputIds.size()))t->setOutputTargetId(outputIds[outIndex]);if(hasInput)t->setInputTrackId(inputIds[inIndex]);}
                last=t;
            }
            safe->rebuildTrackList();if(last)safe->selectTrack(safe->mixer.indexOfTrack(last));safe->markProjectDirty();safe->updateTitleText();
        }
        delete w;
    }),false);w->toFront(true);
}

void MainComponent::removeSelectedTrack()
{
    auto* t = mixer.getTrack (selectedTrackIndex);

    if (t == nullptr)
        return;

    if (t->getType() == Track::Type::Output)
    {
        livent::alert (livent::vn ("Không xóa được"),
            livent::vn ("Track ra tổng luôn phải có, không thể xóa."));
        return;
    }

    /*  Xoa track = xoa luon moi plugin trong no. Phai dong het cua so truoc. */
    autoKeyController.stop();
    pluginWindows.closeAll();

    /*  Buong track ra KHOI Inspector truoc khi xoa. Khong lam vay thi
        inspector.currentTrack tro vao vung nho da bi giai phong, va cai
        Timer 5 Hz cua Inspector se doc no -> sap app dung luc kho hieu nhat. */
    inspector.setTrack (nullptr); closeChannelOverview();

    mixer.removeTrack (selectedTrackIndex);
    rebuildTrackList();
    selectTrack (juce::jlimit (0, juce::jmax (0, mixer.getNumTracks() - 1), selectedTrackIndex));
    markProjectDirty();
    updateTitleText();
}

void MainComponent::rebuildTrackList()
{
    trackRows.clear();
    trackFolders.clear();

    if (! projectOpen)
    {
        // Khong co du an: rebuildTrackList() khong nhan listWidth.
        // Lay chieu rong hien tai cua viewport, giong layoutTrackRows().
        const int emptyListWidth = juce::jmax (260, trackListViewport.getWidth() - 12);
        trackListHolder.setSize (emptyListWidth, 1);
        return;
    }

    /*  GOM THEO THU MUC, giong Cubase.

        Cubase khong do het track ra mot dong lien tuc. No gom lai:
        cac track thuong o tren, roi "FX Channels", roi "Input/Output
        Channels" - moi cai thu gon duoc bang mui ten.

        Vi sao can: dang hat ma phai cuon qua 4 bus vang moi toi track MIC thi
        rat cham. Thu gon hai thu muc duoi lai la ba track hay dung nam gon
        ngay tren cung.

        Cach lam: duyet track theo thu tu, moi khi CHUYEN sang nhom moi thi
        chen mot dong tieu de thu muc truoc.  */
    auto makeFolder = [this] (const juce::String& title, bool* openFlag)
    {
        auto* h = new SectionHeader (title, false);
        h->setWorkspaceLook (true);
        h->setOpen (*openFlag, false);
        h->onToggleOpen = [this, h, openFlag]
        {
            *openFlag = h->isOpen();
            // V6.3.4: Ban lam viec F2 la cua so rieng; resized() cua MainComponent
            // khong xep lai track trong cua so do. Phai relayoutAll().
            relayoutAll();
        };

        trackListHolder.addAndMakeVisible (h);
        trackFolders.add (h);
        return h;
    };

    bool fxFolderMade = false, outFolderMade = false;
    int  fxCount = 0;

    // Dem truoc de ghi so len tieu de thu muc
    for (int i = 0; i < mixer.getNumTracks(); ++i)
        if (auto* t = mixer.getTrack (i))
            if (t->getType() == Track::Type::FxBus)
                ++fxCount;

    for (int i = 0; i < mixer.getNumTracks(); ++i)
    {
        auto* t = mixer.getTrack (i);

        if (t == nullptr)
            continue;

        const auto type = t->getType();

        if (type == Track::Type::FxBus && ! fxFolderMade)
        {
            makeFolder (livent::vn ("BUS HIỆU ỨNG"), &fxFolderOpen)
                ->getProperties().set ("trackGroup", "fx");
            fxFolderMade = true;
        }
        else if (type == Track::Type::Output && ! outFolderMade)
        {
            makeFolder (livent::vn ("VÀO / RA"), &outFolderOpen)->getProperties().set("trackGroup", "out");
            outFolderMade = true;
        }

        auto* row = new TrackRow (*t, i, mixer);
        row->onSelected     = [this, i] { selectTrack (i); };
        row->onOpenOverview = [this, t] { openChannelOverview (t); };   // 14/10 nut "e"

        /*  MOC 54: keo tha sap xep lai track.

            Doi cho trong Mixer roi DUNG LAI ca danh sach - khong tu di chuyen
            cac dong bang tay. Dung lai thi vi tri dong, thu muc, va lan hinh
            song deu tu khop; sua tay thi ba cho do lech nhau ngay.  */
        row->onReordered = [this, t] (int steps)
        {
            const int from = mixer.indexOfTrack (t);

            if(from>=0)
            {
                juce::Array<int> peers;for(int i=0;i<mixer.getNumTracks();++i)if(auto* p=mixer.getTrack(i))if(p->getType()!=Track::Type::Input && livent::grouping::category(p->getType())==livent::grouping::category(t->getType()))peers.add(i);
                const int rank=peers.indexOf(from);if(rank>=0)mixer.moveTrack(from,peers[juce::jlimit(0,peers.size()-1,rank+steps)]);
            }

            rebuildTrackList();
            resized();
            markProjectDirty();
            updateTitleText();
        };
        row->onStateChanged = [this]
        {
            markProjectDirty();
            updateTitleText();
            // Inspector reads level and Pan without rebuilding Send rows while dragging.
        };

        // Chuot phai dung tren mot track -> menu them TRACK NAY (co muc Xoa)
        row->onContextMenu = [this, t] (juce::Point<int> screenPos)
        {
            showTrackListContextMenu (screenPos, t);
        };

        // Keo mep duoi -> doi chieu cao dong nay, luu lai theo track
        // 07/10: chuot phai cho trong tren song -> Nhap file vao track nay
        row->onImportRequest = [this, t] (double at) { importAudioToTimeline (t, at); };

        row->onHeightDragged = [this, t] (int newHeight)
        {
            if (t->getRowHeight() == newHeight)
                return;
            t->setRowHeight (newHeight);
            markProjectDirty();
            updateTitleText();
            // Resize the actual timeline rows immediately. Do not rebuild
            // inspector/control-panel layout on every mouse move during REC.
            layoutTrackRows (juce::jmax (260, trackListViewport.getMaximumVisibleWidth()));
        };

        trackListHolder.addAndMakeVisible (row);
        trackRows.add (row);
    }

    tonePanel.refreshTrackList();

    /*  ==========  MOC 60: BAN TRON DUNG LAI CUNG LUC  ==========

        Loi anh gap: mo app len ban tron chi co hai cot (AM THANH RA va PK),
        tat F3 roi bat lai thi day du.

        Ly do la THU TU: ban tron duoc dung lan dau ngay trong ham dung
        MainComponent - luc do du an chua nap xong, Mixer moi chi co may
        track tao san. Nap du an xong thi danh sach track duoc dung lai,
        nhung ban tron thi khong ai bao nen no giu nguyen anh cu.

        Bam F3 hai lan "chua" duoc chinh la vi no ep dung lai - dung luc do
        thi track da du.

        Gio dat ngay day: HE danh sach track dung lai la ban tron dung lai
        theo. Mot cho goi, hai noi luon khop - khong the lech nhau nua.  */
    mixerView.rebuild();
    mixerView.setSelectedTrack (mixer.getTrack (selectedTrackIndex));

    relayoutAll();   // MOC 93: danh sach track co the dang o ban lam viec
}

void MainComponent::selectTrack (int index)
{
    selectedTrackIndex = index;

    for (int i = 0; i < trackRows.size(); ++i)
        trackRows[i]->setSelected (i == index);

    inspector.setTrack (mixer.getTrack (index));

    /*  MOC 58: ban tron to sang cung mot cot.

        Dung setSelectedTrack chu KHONG dung selectTrack cua ban tron: ham do
        lai bao nguoc ve day, thanh vong lap goi qua goi lai khong dut.  */
    mixerView.setSelectedTrack (mixer.getTrack (index));
}

//=============================================================================
//=============================================================================
//  MOC 61: MENU CHUOT PHAI CHO MOT O INSERT  (dung tu ban tron)
//=============================================================================
//=============================================================================
//  MOC 61: CHUYEN MOT PLUGIN SANG TRACK KHAC, GIU NGUYEN THONG SO
//=============================================================================
void MainComponent::movePluginBetweenTracks (int srcTrackId, int srcSlot,
                                             Track& dest, int destSlot, bool copy, bool replace)
{
    auto* src = mixer.getTrackById (srcTrackId);
    if (src == nullptr || ! juce::isPositiveAndBelow (srcSlot, PluginChain::maxSlots)
        || ! juce::isPositiveAndBelow (destSlot, PluginChain::maxSlots)) return;
    auto& srcChain = src->getInserts();
    auto& destChain = dest.getInserts();
    if (srcChain.isSlotEmpty (srcSlot) || (src == &dest && srcSlot == destSlot)) return;
    const auto sourceUuid = src->getUuid(), destUuid = dest.getUuid();
    auto* original = srcChain.getPlugin (srcSlot);
    auto* previous = destChain.getPlugin (destSlot);
    const auto previousName = destChain.getPluginName (destSlot);
    const bool previousEmpty = destChain.isSlotEmpty (destSlot);
    juce::Component::SafePointer<MainComponent> safe (this);

    if (! previousEmpty && ! replace)
    {
        juce::AlertWindow::showAsync (juce::MessageBoxOptions()
            .withIconType (juce::MessageBoxIconType::QuestionIcon)
            .withTitle (livent::vn ("Thay VST trong ô Insert?"))
            .withMessage (livent::vn ("Ô đích đang có: ") + previousName
                          + livent::vn ("\nThay VST này bằng VST vừa kéo sang?"))
            .withButton (livent::vn ("Thay thế")).withButton (livent::vn ("Hủy"))
            .withAssociatedComponent (livent::dialogOwner()),
            [safe, sourceUuid, destUuid, srcSlot, destSlot, copy, original, previous, previousName] (int result)
            {
                if (safe == nullptr || result != 1) return;
                auto* source = safe->mixer.getTrackByUuid (sourceUuid);
                auto* target = safe->mixer.getTrackByUuid (destUuid);
                if (source == nullptr || target == nullptr
                    || source->getInserts().getPlugin (srcSlot) != original
                    || target->getInserts().getPlugin (destSlot) != previous
                    || target->getInserts().getPluginName (destSlot) != previousName) return;
                safe->movePluginBetweenTracks (source->getId(), srcSlot, *target, destSlot, copy, true);
            });
        return;
    }

    auto finished = [safe, destUuid, destSlot] (const juce::String& error)
    {
        if (safe == nullptr) return;
        if (error.isNotEmpty())
        {
            livent::alert (livent::vn ("Không chuyển / sao chép được VST"), error,
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }
        if (auto* target = safe->mixer.getTrackByUuid (destUuid))
            safe->selectTrack (safe->mixer.indexOfTrack (target));
        safe->inspector.refreshFromTrack();
        safe->refreshMixerAfterPluginEdit (safe->mixer.getTrackByUuid (destUuid), destSlot);
        safe->markProjectDirty();
        safe->updateTitleText();
    };

    if (! copy)
    {
        pluginWindows.closeFor (original);
        pluginWindows.closeFor (previous);
        finished (mixer.transferInsertPlugin (*src, srcSlot, dest, destSlot, replace));
        return;
    }

    juce::MemoryBlock state;
    juce::String identity;
    if (original == nullptr || ! srcChain.capturePresetState (srcSlot, state, identity))
    {
        finished (livent::vn ("VST này không cung cấp trạng thái sao chép an toàn. VST gốc vẫn giữ nguyên."));
        return;
    }
    const auto desc = original->getPluginDescription();
    const bool bypassed = srcChain.isBypassed (srcSlot), sidechain = srcChain.isSidechainOn (srcSlot);
    auto staging = destChain.createStagingChain();
    staging->addPluginAsync (desc,
        [safe, staging, state, identity, sourceUuid, destUuid, srcSlot, destSlot, original,
         previous, previousName, previousEmpty, bypassed, sidechain, replace, finished] (juce::String error)
        {
            if (safe == nullptr) return;
            auto* source = safe->mixer.getTrackByUuid (sourceUuid);
            auto* target = safe->mixer.getTrackByUuid (destUuid);
            if (source == nullptr || target == nullptr
                || source->getInserts().getPlugin (srcSlot) != original
                || target->getInserts().getPlugin (destSlot) != previous
                || target->getInserts().isSlotEmpty (destSlot) != previousEmpty
                || target->getInserts().getPluginName (destSlot) != previousName)
            { finished (livent::vn ("Track hoặc ô VST đã thay đổi trong lúc sao chép. Hãy kéo lại.")); return; }
            if (error.isEmpty() && ! staging->applyPresetState (0, state, identity))
                error = livent::vn ("Không khôi phục được thông số VST; đã hủy bản sao.");
            if (error.isEmpty() && sidechain && ! staging->setSidechainOn (0, true))
                error = livent::vn ("Không khôi phục được chế độ sidechain; đã hủy bản sao.");
            if (error.isNotEmpty()) { finished (error); return; }
            staging->setBypassed (0, bypassed);
            safe->pluginWindows.closeFor (previous);
            finished (safe->mixer.transferInsertPlugin (*source, srcSlot, *target, destSlot, replace, staging.get()));
        });
}

void MainComponent::showSlotContextMenu (int slot)
{
    auto* track = inspector.getTrack();

    if (track == nullptr)
        return;

    auto& chain = track->getInserts();

    /*  O trong thi khong can menu - bay thang bang chon plugin cho do mot
        buoc bam. Menu chi co nghia khi da co plugin de thao tac.  */
    if (chain.isSlotEmpty (slot) || chain.isMissing (slot))
    {
        showPluginMenuForSlot (slot);
        return;
    }

    auto menu = std::make_shared<juce::PopupMenu>();

    menu->addSectionHeader (chain.getPluginName (slot));
    if (chain.isBridge32Slot (slot))
        menu->addItem (1, livent::vn ("Giao diện VST32 sẽ nối ở M2/P2"), false, false);
    else
        menu->addItem (1, livent::vn ("Mở giao diện plugin"));
    menu->addItem (2, livent::vn ("Thay bằng plugin khác..."));

    /*  MOC 63: chi hien muc nay khi plugin THAT SU co duong vao phu.

        Hien cho moi plugin thi anh bam vao mot con EQ khong co sidechain, no
        bao that bai - vo nghia. Hoi plugin truoc, no co thi moi bay ra.  */
    if (chain.hasSidechain (slot))
    {
        menu->addSeparator();
        menu->addItem (4, livent::vn ("Bật đường vào phụ (Sidechain)"),
                       true, chain.isSidechainOn (slot));
    }

    menu->addSeparator();
    menu->addItem (3, livent::vn ("Gỡ plugin khỏi ô này"));

    juce::Component::SafePointer<MainComponent> safeThis (this);

    menu->showMenuAsync (livent::menuAtPointer (&mixerView),
        [safeThis, menu, slot] (int choice)
        {
            if (safeThis == nullptr || choice == 0)
                return;

            if (choice == 1)  safeThis->openEditorForSlot (slot);
            if (choice == 2)  safeThis->showPluginMenuForSlot (slot);
            if (choice == 3)  safeThis->removePluginFromSlot (slot);
            if (choice == 4)  safeThis->toggleSidechain (slot);
        });
}

//=============================================================================
//  11j: THANH CONG CU CUA SO VST
//=============================================================================
void MainComponent::refreshAfterPluginToolbarChange()
{
    markProjectDirty();
    updateTitleText();
    for (auto* row : trackRows)
        row->refresh();
    inspector.refreshFromTrack();
    mixerView.rebuild();
}

void MainComponent::setupPluginToolbarHooks()
{
    juce::Component::SafePointer<MainComponent> safe (this);

    // key "t<id>:s<slot>" -> track + o. nullptr neu track/o khong con.
    auto resolve = [safe] (const juce::String& key, int& slot) -> Track*
    {
        int trackId = 0;
        if (safe == nullptr || ! PluginWindowManager::parseKey (key, trackId, slot)
            || ! juce::isPositiveAndBelow (slot, PluginChain::maxSlots))
            return nullptr;
        return safe->mixer.getTrackById (trackId);
    };
    auto& h = pluginWindows.toolbarHooks;

    //-- BYPASS ---------------------------------------------------------------
    h.bypassState = [resolve] (const juce::String& key)
    {
        int slot = 0;
        auto* t = resolve (key, slot);
        if (t == nullptr || t->getInserts().getPlugin (slot) == nullptr) return -1;
        return t->getInserts().isBypassed (slot) ? 1 : 0;
    };
    h.toggleBypass = [safe, resolve] (const juce::String& key)
    {
        int slot = 0;
        if (auto* t = resolve (key, slot))
        {
            auto& chain = t->getInserts();
            chain.setBypassed (slot, ! chain.isBypassed (slot));
            safe->refreshAfterPluginToolbarChange();
        }
    };

    //-- SIDECHAIN: bat/tat + chon NHIEU track nguon (tu tao Send 0 dB, PRE fader) ------
    h.sidechainLabel = [safe, resolve] (const juce::String& key) -> juce::String
    {
        int slot = 0;
        auto* t = resolve (key, slot);
        if (t == nullptr || ! t->getInserts().hasSidechain (slot)) return {};
        const auto sources = livent::sidechain::sources (safe->mixer, *t, slot);
        if (sources.isEmpty()) return livent::vn ("SIDECHAIN");
        auto name = sources.getFirst()->getName();
        if (name.length() > 9) name = name.substring (0, 8) + juce::String::fromUTF8 ("…");
        return "SC: " + name + (sources.size() > 1 ? " +" + juce::String (sources.size() - 1) : juce::String());
    };
    h.sidechainActive = [resolve] (const juce::String& key)
    {
        int slot = 0;
        auto* t = resolve (key, slot);
        return t != nullptr && t->getInserts().isSidechainOn (slot);
    };
    h.showSidechainMenu = [safe, resolve] (const juce::String& key, juce::Component* anchor)
    {
        int slot = 0;
        auto* target = resolve (key, slot);
        if (target == nullptr || ! target->getInserts().hasSidechain (slot)) return;
        auto& chain = target->getInserts();
        const auto current = livent::sidechain::sources (safe->mixer, *target, slot);

        juce::PopupMenu m;
        m.addItem (1, livent::vn ("Bật đường vào phụ (Sidechain)"), true, chain.isSidechainOn (slot));
        m.addSectionHeader (livent::vn ("Track nguồn - chọn được nhiều track (Send 0 dB, trước fader)"));
        juce::StringArray candidates;
        for (auto* t : livent::sidechain::candidates (safe->mixer, *target))
        {
            candidates.add (t->getUuid());
            m.addItem (100 + candidates.size() - 1, t->getName(), true, current.contains (t));
        }
        if (candidates.isEmpty())
            m.addItem (-1, livent::vn ("Chưa có track nào gửi được vào đây"), false);
        m.addSeparator();
        m.addItem (2, livent::vn ("Bỏ hết track nguồn"), ! current.isEmpty());

        const auto targetUuid = target->getUuid();
        juce::Component::SafePointer<juce::Component> safeAnchor (anchor);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (anchor),
            [safe, key, slot, targetUuid, candidates, safeAnchor] (int result)
            {
                if (safe == nullptr || result <= 0) return;
                auto* tg = safe->mixer.getTrackByUuid (targetUuid);
                if (tg == nullptr) return;
                auto& c = tg->getInserts();
                auto refused = []
                {
                    livent::alert (livent::vn ("Không bật được Sidechain"),
                                   livent::vn ("Plugin này từ chối mở đường vào phụ. Vài plugin chỉ cho bật Sidechain từ giao diện của chính nó."),
                                   juce::MessageBoxIconType::WarningIcon);
                };
                if (result == 1)
                {
                    if (! c.setSidechainOn (slot, ! c.isSidechainOn (slot))) refused();
                }
                else if (result == 2)
                {
                    livent::sidechain::removeAll (safe->mixer, *tg, slot);
                }
                else if (juce::isPositiveAndBelow (result - 100, candidates.size()))
                {
                    auto* src = safe->mixer.getTrackByUuid (candidates[result - 100]);
                    if (src == nullptr) return;
                    // Them nguon dau tien ma sidechain dang tat -> bat len luon cho tien.
                    if (! livent::sidechain::isSource (*src, *tg, slot) && ! c.isSidechainOn (slot) && ! c.setSidechainOn (slot, true))
                    {
                        refused();
                        return;
                    }
                    if (livent::sidechain::toggleSource (safe->mixer, *src, *tg, slot) == livent::sidechain::Toggle::full)
                    {
                        livent::alert (livent::vn ("Không thêm được Send"),
                                       src->getName() + livent::vn (" đã dùng hết số Send cho phép."),
                                       juce::MessageBoxIconType::WarningIcon);
                        return;
                    }
                }
                safe->refreshAfterPluginToolbarChange();
                // Chon nhieu: mo lai menu ngay de chon tiep track khac.
                if (result >= 100 && safeAnchor != nullptr)
                    juce::MessageManager::callAsync ([safe, key, safeAnchor]
                    {
                        if (safe != nullptr && safeAnchor != nullptr && safe->pluginWindows.toolbarHooks.showSidechainMenu)
                            safe->pluginWindows.toolbarHooks.showSidechainMenu (key, safeAnchor.getComponent());
                    });
            });
    };

    //-- PRESET: preset cua plugin + luu / mo file .ntpreset ------------------
    auto presetFolder = [] (const juce::String& pluginName)
    {
        return PluginChain::getSettingsFolder().getChildFile ("Presets")
                   .getChildFile (juce::File::createLegalFileName (pluginName).trim());
    };
    h.showPresetMenu = [safe, resolve, presetFolder] (const juce::String& key, juce::Component* anchor)
    {
        int slot = 0;
        auto* t = resolve (key, slot);
        if (t == nullptr) return;
        auto& chain = t->getInserts();
        auto* p = chain.getPlugin (slot);
        const auto identity = chain.getPresetIdentity (slot);
        const bool canState = p != nullptr && identity.isNotEmpty();
        const auto pluginName = chain.getPluginName (slot);

        juce::PopupMenu m;
        int numPrograms = 0, current = -1;
        juce::StringArray programNames;
        if (p != nullptr)
            livent::sehGuard ([&]
            {
                numPrograms = juce::jmin (256, p->getNumPrograms());
                current = p->getCurrentProgram();
                for (int i = 0; i < numPrograms; ++i) programNames.add (p->getProgramName (i));
            });
        if (numPrograms > 1)
        {
            juce::PopupMenu programs;
            for (int i = 0; i < numPrograms; ++i)
                programs.addItem (1000 + i, programNames[i].isNotEmpty() ? programNames[i] : "Preset " + juce::String (i + 1), true, i == current);
            m.addSubMenu (livent::vn ("Preset có sẵn của plugin"), programs);
        }
        const auto folder = presetFolder (pluginName);
        auto files = folder.findChildFiles (juce::File::findFiles, false, "*.ntpreset");
        std::sort (files.begin(), files.end(), [] (const juce::File& a, const juce::File& b)
                   { return a.getFileName().compareNatural (b.getFileName()) < 0; });
        if (! files.isEmpty())
        {
            m.addSectionHeader (livent::vn ("Preset đã lưu"));
            for (int i = 0; i < juce::jmin (64, files.size()); ++i)
                m.addItem (2000 + i, files[i].getFileNameWithoutExtension(), canState);
        }
        m.addSeparator();
        m.addItem (1, livent::vn ("Lưu preset hiện tại…"), canState);
        m.addItem (2, livent::vn ("Mở preset từ file…"), canState);
        if (! canState)
            m.addItem (-1, livent::vn ("(Plugin này không đọc/ghi được preset qua LiveNT)"), false);

        const auto trackUuid = t->getUuid();
        auto applyFile = [safe, trackUuid, slot] (const juce::File& file)
        {
            if (safe == nullptr) return;
            auto* tr = safe->mixer.getTrackByUuid (trackUuid);
            if (tr == nullptr) return;
            auto& c = tr->getInserts();
            auto xml = juce::XmlDocument::parse (file);
            juce::MemoryBlock data;
            if (xml == nullptr || ! xml->hasTagName ("NTPRESET")
                || ! data.fromBase64Encoding (xml->getChildElementAllSubText ("DATA", {})))
            {
                livent::alert (livent::vn ("Không đọc được preset"), file.getFullPathName(), juce::MessageBoxIconType::WarningIcon);
                return;
            }
            const auto wanted = xml->getStringAttribute ("identity");
            if (wanted != c.getPresetIdentity (slot))
            {
                livent::alert (livent::vn ("Preset của plugin khác"),
                               livent::vn ("Preset này lưu từ \"") + xml->getStringAttribute ("plugin")
                                   + livent::vn ("\", không dùng cho \"") + c.getPluginName (slot) + "\".",
                               juce::MessageBoxIconType::WarningIcon);
                return;
            }
            if (! c.applyPresetState (slot, data, wanted))
                livent::alert (livent::vn ("Plugin không nhận preset"), file.getFileName(), juce::MessageBoxIconType::WarningIcon);
            safe->refreshAfterPluginToolbarChange();
        };

        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (anchor),
            [safe, trackUuid, slot, files, folder, pluginName, applyFile] (int result)
            {
                if (safe == nullptr || result <= 0) return;
                auto* tr = safe->mixer.getTrackByUuid (trackUuid);
                if (tr == nullptr) return;
                auto& c = tr->getInserts();
                if (result >= 2000 && juce::isPositiveAndBelow (result - 2000, files.size()))
                {
                    applyFile (files[result - 2000]);
                }
                else if (result >= 1000)
                {
                    if (auto* pl = c.getPlugin (slot))
                    {
                        livent::sehGuard ([pl, result] { pl->setCurrentProgram (result - 1000); });
                        safe->refreshAfterPluginToolbarChange();
                    }
                }
                else if (result == 1)
                {
                    juce::MemoryBlock data; juce::String savedIdentity;
                    if (! c.capturePresetState (slot, data, savedIdentity))
                    {
                        livent::alert (livent::vn ("Không lấy được cài đặt plugin"), pluginName, juce::MessageBoxIconType::WarningIcon);
                        return;
                    }
                    folder.createDirectory();
                    safe->presetChooser = std::make_unique<juce::FileChooser> (livent::vn ("Lưu preset"),
                        folder.getNonexistentChildFile (juce::File::createLegalFileName (pluginName), ".ntpreset", false), "*.ntpreset");
                    safe->presetChooser->launchAsync (juce::FileBrowserComponent::saveMode | juce::FileBrowserComponent::canSelectFiles
                                                          | juce::FileBrowserComponent::warnAboutOverwriting,
                        [data, savedIdentity, pluginName] (const juce::FileChooser& fc)
                        {
                            auto file = fc.getResult();
                            if (file == juce::File()) return;
                            if (! file.hasFileExtension ("ntpreset")) file = file.withFileExtension ("ntpreset");
                            juce::XmlElement x ("NTPRESET");
                            x.setAttribute ("version", 1);
                            x.setAttribute ("identity", savedIdentity);
                            x.setAttribute ("plugin", pluginName);
                            x.createNewChildElement ("DATA")->addTextElement (data.toBase64Encoding());
                            if (! x.writeTo (file))
                                livent::alert (livent::vn ("Không lưu được preset"), file.getFullPathName(), juce::MessageBoxIconType::WarningIcon);
                        });
                }
                else if (result == 2)
                {
                    safe->presetChooser = std::make_unique<juce::FileChooser> (livent::vn ("Mở preset"), folder, "*.ntpreset");
                    safe->presetChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                        [applyFile] (const juce::FileChooser& fc)
                        {
                            if (fc.getResult() != juce::File()) applyFile (fc.getResult());
                        });
                }
            });
    };

    //-- A/B: hai bo chinh cho cung mot plugin --------------------------------
    h.abState = [safe, resolve] (const juce::String& key)
    {
        int slot = 0;
        auto* t = resolve (key, slot);
        if (t == nullptr) return 0;
        auto it = safe->pluginAB.find (key);
        if (it == safe->pluginAB.end() || it->second.identity != t->getInserts().getPresetIdentity (slot)) return 0;
        return it->second.active;
    };
    h.toggleAB = [safe, resolve] (const juce::String& key)
    {
        int slot = 0;
        auto* t = resolve (key, slot);
        if (t == nullptr) return;
        auto& c = t->getInserts();
        juce::MemoryBlock now; juce::String identity;
        if (! c.capturePresetState (slot, now, identity))
        {
            livent::alert (livent::vn ("Không so sánh A/B được"),
                           livent::vn ("Plugin này không cho đọc cài đặt qua LiveNT (hoặc là plugin 32-bit)."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }
        auto& ab = safe->pluginAB[key];
        if (ab.identity != identity) ab = PluginAB { {}, {}, identity, 0 };
        if (ab.active == 0)
        {
            // Lan dau: A = ban hien tai. Chuyen sang B (bat dau giong A) de chinh thu.
            ab.a = now; ab.b = now; ab.active = 2;
        }
        else
        {
            (ab.active == 1 ? ab.a : ab.b) = now;
            ab.active = ab.active == 1 ? 2 : 1;
            if (! c.applyPresetState (slot, ab.active == 1 ? ab.a : ab.b, identity))
                livent::alert (livent::vn ("Plugin không nhận bộ chỉnh A/B"), c.getPluginName (slot), juce::MessageBoxIconType::WarningIcon);
        }
        safe->refreshAfterPluginToolbarChange();
    };

    //-- ... : chep / dan cai dat, (cua so hep) preset + A/B ------------------
    h.showMoreMenu = [safe, resolve] (const juce::String& key, juce::Component* anchor, bool includePresetAndAB)
    {
        int slot = 0;
        auto* t = resolve (key, slot);
        if (t == nullptr) return;
        auto& c = t->getInserts();
        const auto identity = c.getPresetIdentity (slot);
        const bool canPaste = identity.isNotEmpty() && identity == safe->pluginClipboardIdentity && safe->pluginClipboard.getSize() > 0;
        const int ab = safe->pluginWindows.toolbarHooks.abState ? safe->pluginWindows.toolbarHooks.abState (key) : 0;

        juce::PopupMenu m;
        m.addItem (1, livent::vn ("Chép cài đặt plugin"), identity.isNotEmpty());
        m.addItem (2, livent::vn ("Dán cài đặt") + (safe->pluginClipboardName.isNotEmpty() ? " (" + safe->pluginClipboardName + ")" : juce::String()), canPaste);
        if (includePresetAndAB)
        {
            m.addSeparator();
            if (c.hasSidechain (slot))
                m.addItem (13, livent::vn ("Sidechain…"));
            m.addItem (10, livent::vn ("Preset…"));
            m.addItem (11, ab == 0 ? livent::vn ("So sánh A/B") : ab == 1 ? livent::vn ("A/B: đang nghe A - chuyển sang B") : livent::vn ("A/B: đang nghe B - chuyển sang A"));
        }
        if (ab != 0)
            m.addItem (12, livent::vn ("Thôi so sánh A/B (giữ bản đang nghe)"));

        const auto trackUuid = t->getUuid();
        juce::Component::SafePointer<juce::Component> safeAnchor (anchor);
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (anchor),
            [safe, key, trackUuid, slot, safeAnchor] (int result)
            {
                if (safe == nullptr || result <= 0) return;
                auto* tr = safe->mixer.getTrackByUuid (trackUuid);
                if (tr == nullptr) return;
                auto& ch = tr->getInserts();
                auto& hk = safe->pluginWindows.toolbarHooks;
                if (result == 1)
                {
                    juce::MemoryBlock data; juce::String id;
                    if (ch.capturePresetState (slot, data, id))
                    {
                        safe->pluginClipboard = data; safe->pluginClipboardIdentity = id;
                        safe->pluginClipboardName = ch.getPluginName (slot);
                    }
                    else livent::alert (livent::vn ("Không chép được cài đặt"), ch.getPluginName (slot), juce::MessageBoxIconType::WarningIcon);
                }
                else if (result == 2)
                {
                    if (! ch.applyPresetState (slot, safe->pluginClipboard, safe->pluginClipboardIdentity))
                        livent::alert (livent::vn ("Plugin không nhận cài đặt dán vào"), ch.getPluginName (slot), juce::MessageBoxIconType::WarningIcon);
                    safe->refreshAfterPluginToolbarChange();
                }
                else if (result == 10 && hk.showPresetMenu && safeAnchor != nullptr) hk.showPresetMenu (key, safeAnchor.getComponent());
                else if (result == 11 && hk.toggleAB) hk.toggleAB (key);
                else if (result == 12) safe->pluginAB.erase (key);
                else if (result == 13 && hk.showSidechainMenu && safeAnchor != nullptr) hk.showSidechainMenu (key, safeAnchor.getComponent());
            });
    };
}

void MainComponent::toggleSidechain (int slot)
{
    auto* track = inspector.getTrack();

    if (track == nullptr)
        return;

    auto& chain = track->getInserts();
    const bool turnOn = ! chain.isSidechainOn (slot);

    if (! chain.setSidechainOn (slot, turnOn))
    {
        livent::alert (livent::vn ("Plugin không nhận"),
                       livent::vn ("Plugin nay tu choi mo duong vao phu. Vai con chi cho bat sidechain tu trong giao dien cua chinh no."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    if (turnOn)
        livent::alert (livent::vn ("Đã bật đường vào phụ"),
                       livent::vn ("Gio vao track muon gui tin hieu toi, bam \"+ Them Send\" - plugin nay da co trong danh sach."));

    inspector.refreshFromTrack();
    mixerView.rebuild();
    mixerView.setSelectedTrack (track);
    markProjectDirty();
    updateTitleText();
}

void MainComponent::removePluginFromSlot (int slot)
{
    auto* track = inspector.getTrack();

    if (track == nullptr)
        return;

    auto& chain = track->getInserts();

    if (chain.isSlotEmpty (slot))
        return;

    /*  Dong cua so giao dien cua plugin TRUOC khi go no.

        Cua so do giu con tro toi chinh plugin sap bi huy - de no song sot
        qua luc nay la sap ngay. Day dung la duong da gay crash o Moc 12.  */
    if (auto* native = chain.getPlugin (slot))
        pluginWindows.closeFor (native);

    chain.removePlugin (slot);

    inspector.refreshFromTrack();
    mixerView.rebuild();
    mixerView.setSelectedTrack (track);
    markProjectDirty();
    updateTitleText();
}

void MainComponent::showPluginMenuForSlot (int slot)
{
    auto* track = inspector.getTrack();

    if (track == nullptr)
        return;

    /* V6.4.6: mot host in-process khong nen khoi tao hai VST cung luc.
       Mot so bo Waves/Antares/Kontakt dung static/global state trong DLL;
       hai lan init chong nhau co the treo message thread hoac lam hong heap. */
    if (pluginLoadInProgress)
    {
        livent::alert (livent::vn ("Đang nạp VST"),
                       livent::vn ("Đang nạp: ") + loadingPluginName
                         + livent::vn ("\n\nChờ plugin này nạp xong rồi thêm plugin tiếp theo."));
        return;
    }

    const auto types = PluginChain::getKnownPlugins().getTypes();

    if (types.isEmpty())
    {
        livent::alert (livent::vn ("Chưa có plugin"),
            livent::vn ("Bấm \"Quét plugin VST3\" để quét trước đã."));
        return;
    }

    const int targetTrackId = track->getId();
    juce::Component::SafePointer<MainComponent> safeThis (this);

    auto* picker = new PluginPicker (types,
        [safeThis, slot, targetTrackId] (const juce::PluginDescription& d)
        {
            if (safeThis == nullptr)
                return;

            if (safeThis->pluginLoadInProgress)
                return; // PluginPicker da khoa double-pick; day la lop chan thu hai.

            auto* targetTrack = safeThis->mixer.getTrackById (targetTrackId);
            if (targetTrack == nullptr)
                return; // project/track da doi trong luc hop thoai dang mo

            safeThis->pluginLoadInProgress = true;
            safeThis->pluginLoadTrackId = targetTrackId;
            safeThis->pluginLoadSlot = slot;
            safeThis->loadingPluginName = d.name;
            safeThis->updateStatusText();

            livent::stabilityLog ("BEGIN plugin-add",
                                  d.name + " | track=" + juce::String (targetTrackId)
                                  + " | slot=" + juce::String (slot)
                                  + " | " + d.pluginFormatName
                                  + " | " + d.fileOrIdentifier);

            /* KHONG dong editor cu tu som. Neu plugin moi nap that bai thi plugin
               cu van con nguyen. PluginChain::onPluginAboutToBeDestroyed se dong
               editor DUNG luc swap thanh cong, ngay truoc khi instance cu bi huy. */
            targetTrack->getInserts().replacePluginAsync (slot, d,
                [safeThis, slot, targetTrackId, pluginName = d.name] (juce::String err)
                {
                    if (safeThis == nullptr)
                        return;

                    const bool isThisLoad = safeThis->pluginLoadTrackId == targetTrackId
                                         && safeThis->pluginLoadSlot == slot;

                    if (isThisLoad)
                    {
                        safeThis->pluginLoadInProgress = false;
                        safeThis->pluginLoadTrackId = -1;
                        safeThis->pluginLoadSlot = -1;
                        safeThis->loadingPluginName.clear();
                    }

                    safeThis->updateStatusText();

                    auto* loadedTrack = safeThis->mixer.getTrackById (targetTrackId);
                    if (loadedTrack == nullptr)
                        return; // huy vi doi project/xoa track: khong bao loi vo nghia

                    if (err.isNotEmpty())
                    {
                        livent::stabilityLog ("END plugin-add FAIL",
                                              pluginName + " | " + err);
                        livent::alert (livent::vn ("Không nạp được plugin"), err,
                                       juce::MessageBoxIconType::WarningIcon);
                        return;
                    }

                    livent::stabilityLog ("END plugin-add OK",
                                          "track=" + juce::String (targetTrackId)
                                          + " | slot=" + juce::String (slot));

                    /* Chi rebuild Inspector neu no VAN dang xem dung track da nap.
                       Truoc day callback dung Inspector hien tai, nen doi sang track
                       khac trong luc VST dang nap co the rebuild/mo nham slot. */
                    if (safeThis->inspector.getTrack() == loadedTrack)
                    {
                        safeThis->inspector.rebuildInserts();
                        safeThis->refitInspector();
                    }

                    safeThis->refreshMixerAfterPluginEdit (loadedTrack,
                        juce::jmin (slot + 1, PluginChain::maxSlots - 1));
                    safeThis->markProjectDirty();
                    safeThis->updateTitleText();

                    /* Phao cuu NGAY sau moi VST thanh cong. Day la recovery LITE:
                       khong goi getStateInformation() nen khong tu tao them mot
                       diem treo trong luc anh dang lap gan chuoi plugin. */
                    safeThis->writeRecoveryCheckpoint();

                    /* HOTFIX26 FINAL - GIU WORKFLOW CU CUA ANH:
                       Them VST xong van TU MO giao dien nhu truoc. Khac biet la
                       viec mo duoc day sang nhip message ke tiep, sau khi instance
                       da gan vao track/rebuild xong. openEditorForSlot() se di qua
                       Host64 GUI probe neu che do An toan giao dien VST dang bat.

                       May binh thuong: PASS -> tu mo GUI goc ngay.
                       May ken GUI:      GUI fail -> Generic Editor, DAW van song.
                       DSP/runtime fail: khong mo GUI nguy hiem, co log ro stage. */
                    livent::stabilityLog ("AUTO editor-open scheduled",
                                          pluginName + " | track=" + juce::String (targetTrackId)
                                          + " | slot=" + juce::String (slot));

                    juce::MessageManager::callAsync ([safeThis, slot, targetTrackId, pluginName]
                    {
                        if (safeThis == nullptr)
                            return;

                        auto* stillThere = safeThis->mixer.getTrackById (targetTrackId);
                        if (stillThere == nullptr)
                        {
                            livent::stabilityLog ("AUTO editor-open skipped",
                                                  pluginName + " | track disappeared");
                            return;
                        }

                        // Neu anh da chuyen sang track khac trong luc plugin nap,
                        // khong cuop focus cua track moi. Bam o VST sau van mo duoc.
                        if (safeThis->inspector.getTrack() != stillThere)
                        {
                            livent::stabilityLog ("AUTO editor-open skipped",
                                                  pluginName + " | selection changed");
                            return;
                        }

                        auto& inserts = stillThere->getInserts();
                        if (inserts.isSlotEmpty (slot) || inserts.isMissing (slot))
                        {
                            livent::stabilityLog ("AUTO editor-open skipped",
                                                  pluginName + " | slot empty/missing");
                            return;
                        }

                        livent::stabilityLog ("AUTO editor-open begin",
                                              pluginName + " | track=" + juce::String (targetTrackId)
                                              + " | slot=" + juce::String (slot));
                        safeThis->openEditorForSlot (slot);
                        safeThis->syncMixerPanelVisibility();
                    });
                });
        }, [] (const juce::Array<juce::PluginDescription>& missing)
        {
            if (livent::removeMissingPluginEntries (PluginChain::getKnownPlugins(), missing) > 0)
                PluginChain::savePluginList();
        });

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (picker);
    o.dialogTitle = livent::vn ("Chọn plugin");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = true;

    if (auto* dw = livent::launchDialog (o))
    {
        livent::bringDialogToFront (dw);

        /* Raw pointer + callAfterDelay tung la use-after-free: neu hop thoai bi
           dong trong 120 ms, picker da bi delete nhung timer van goi vao no. */
        juce::Component::SafePointer<PluginPicker> safePicker (picker);
        juce::Timer::callAfterDelay (120, [safePicker]
        {
            if (safePicker != nullptr)
                safePicker->focusSearch();
        });
    }
}

void MainComponent::openEditorForSlot (int slot, Track* requestedTrack)
{
    /*  MOC 59: dung tu BAN TRON - mo han, khong lat.

        Xem ghi chu day du o PluginWindowManager::open(). Tom tat: bam mot cai
        tren ban tron keo theo mot chuoi viec, va neu ham nay lo bi goi hai
        lan thi toggle() se mo roi dong ngay - "chop len roi tat".  */
    auto* track = requestedTrack != nullptr ? requestedTrack : inspector.getTrack();

    if (track == nullptr)
        return;

    auto& chain = track->getInserts();

    if (chain.isBridge32Slot (slot))
    {
        auto bridge = chain.getBridge32Client (slot);
        if (! bridge || ! bridge->isReady())
        {
            livent::alert (livent::vn ("VST2 32-bit - M2/P2"),
                           livent::vn ("Bridge32 của plugin này chưa READY. Hãy build/copy đúng LiveNTBridge32 M2/P2 cạnh file chương trình."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }

        if (pluginWindows.isPerformanceMode())
        {
            livent::alert (livent::vn ("Đang ở CHẾ ĐỘ ĐIỆN"),
                           livent::vn ("Tắt chế độ điện nếu anh muốn mở giao diện plugin 32-bit."));
            return;
        }

        /* P2: plugin co editor native thi mo THANG editor cua plugin trong
           process x86. Nhu vay UI 32-bit khong bao gio nam trong LiveNT x64.
           Plugin khong co editor thi fallback sang bang parameter nhe cua LiveNT. */
        if (bridge->hasEditor())
        {
            juce::String err;
            const bool ok = bridge->isEditorOpen() ? bridge->bringEditorToFront (err)
                                                    : bridge->openEditor (err);
            if (ok)
                return;

            livent::alert (livent::vn ("Không mở được giao diện VST32"), err,
                           juce::MessageBoxIconType::WarningIcon);
        }

        auto safeThis = juce::Component::SafePointer<MainComponent> (this);
        auto* panel = new Bridge32GenericEditor (bridge, [safeThis]
        {
            if (safeThis != nullptr)
            {
                safeThis->markProjectDirty();
                safeThis->updateTitleText();
            }
        });

        juce::DialogWindow::LaunchOptions o;
        o.content.setOwned (panel);
        o.dialogTitle = chain.getPluginName (slot) + livent::vn (" - Thông số 32-bit");
        o.dialogBackgroundColour = Col::panel;
        o.escapeKeyTriggersCloseButton = true;
        o.useNativeTitleBar = true;
        o.resizable = true;
        if (auto* dw = livent::launchDialog (o))
            livent::bringDialogToFront (dw);
        return;
    }

    auto* p = chain.getPlugin (slot);

    if (p == nullptr)
        return;

    const auto key = PluginWindowManager::makeKey (track->getId(), slot);
    bool forceGenericEditor = false;

    livent::stabilityLog ("BEGIN editor-open",
                          p->getName() + " | " + key);

    /* STABILITY PACK V1:
       Chinh trieu chung may khach: project hat duoc, nhung mo Ban lam viec /
       mo GUI VST thi vang. Day la dau hieu native editor, khong phai DSP.
       Khi che do an toan BAT, thu GUI trong LiveNTPluginHost64.exe truoc.
       Core DSP fail -> khong mo bat ky editor nao. GUI fail nhung DSP pass ->
       KHONG cham native editor trong process chinh, dung Generic Editor. */
    if (loadVstGuiSafeModePref())
    {
        juce::PluginDescription desc;
        p->fillInPluginDescription (desc);

        const double sr = p->getSampleRate() > 1000.0 ? p->getSampleRate() : 48000.0;
        const int bs = p->getBlockSize() > 0 ? p->getBlockSize() : 512;
        const auto probe = livent::probePluginRuntime (desc, sr, bs);

        if (probe.checked && ! probe.safe)
        {
            livent::stabilityLog ("END editor-open BLOCK",
                                  p->getName() + " | stage=" + probe.stage
                                  + " | " + probe.error);

            livent::alert (
                livent::vn ("Không mở giao diện VST"),
                livent::vn ("Plugin vẫn đang được giữ trong project, nhưng kiểm tra an toàn "
                            "không vượt qua ở bước: ")
                    + probe.stage
                    + (probe.error.isNotEmpty() ? "\n\n" + probe.error : juce::String())
                    + livent::vn ("\n\nLiveNT không mở GUI để tránh làm văng DAW."),
                juce::MessageBoxIconType::WarningIcon);
            return;
        }

        if (probe.checked && ! probe.editorSafe)
        {
            forceGenericEditor = true;
            livent::stabilityLog ("editor-native-isolated",
                                  p->getName() + " | stage=" + probe.stage
                                  + (probe.warning.isNotEmpty() ? " | " + probe.warning
                                                               : juce::String()));
        }
        else if (! probe.checked && probe.error.isNotEmpty())
        {
            // Ban cai cu thieu Host64: giu fallback SEH cu, nhung log de biet
            // may nay chua du lop cach ly GUI.
            livent::stabilityLog ("editor-probe-skip",
                                  p->getName() + " | " + probe.error);
        }
    }

    pluginWindows.open (p, key, forceGenericEditor);
    livent::stabilityLog ("END editor-open",
                          p->getName() + (forceGenericEditor ? " | GENERIC" : " | NATIVE"));
}

void MainComponent::toggleEditorForSlot (int slot)
{
    auto* track = inspector.getTrack();

    if (track == nullptr)
        return;

    auto& chain = track->getInserts();

    if (chain.isBridge32Slot (slot))
    {
        if (auto bridge = chain.getBridge32Client (slot))
        {
            if (bridge->hasEditor() && bridge->isEditorOpen())
            {
                juce::String err;
                if (! bridge->closeEditor (err) && err.isNotEmpty())
                    livent::alert (livent::vn ("Không đóng được giao diện VST32"), err,
                                   juce::MessageBoxIconType::WarningIcon);
                return;
            }
        }
        openEditorForSlot (slot);
        return;
    }

    auto* p = chain.getPlugin (slot);

    if (p == nullptr)
        return;

    /* STABILITY PACK V1: moi duong MO editor native deu phai di qua
       openEditorForSlot() de probe Host64 truoc. toggle() chi con dung cho
       hanh vi DONG neu cua so da mo. */
    if (auto* w=pluginWindows.findWindow(PluginWindowManager::makeKey(track->getId(),slot)))
        if(w->isCloseLocked())return;
    if (pluginWindows.isOpen (p))
        pluginWindows.closeFor (p);
    else
        openEditorForSlot (slot);
}

void MainComponent::bringPluginWindowsToFront()
{
    /*  Khi anh chuyen sang app khac roi quay lai, cua so plugin bi Windows
        day ra sau cua so chinh. Keo tat ca len truoc cho khoi phai di tim. */
    pluginWindows.bringAllToFront();
}

//=============================================================================
void MainComponent::togglePerformanceMode()
{
    const bool turnOn = ! pluginWindows.isPerformanceMode();
    // 12s: Do khong AI dung T-AutoKey co san (khong can cua so VST) -> bat tiet kiem CPU thoai mai.
    if (turnOn) autoKeyController.stop();
    pluginWindows.setPerformanceMode (turnOn);

    /* V5.8.6: editor VST32 song trong process Bridge32 nen PluginWindowManager
       khong thay no. Che do dien bat thi dong ca editor 32-bit de khong ton CPU ve GUI. */
    if (turnOn)
    {
        for (int ti = 0; ti < mixer.getNumTracks(); ++ti)
            if (auto* t = mixer.getTrack (ti))
                for (int si = 0; si < t->getInserts().getNumPlugins(); ++si)
                    if (auto b = t->getInserts().getBridge32Client (si))
                    {
                        juce::String ignored;
                        b->closeEditor (ignored);
                    }
    }

    /*  MOC 21: khong con nut rieng tren toolbar - trang thai BAT/TAT hien
        bang dau tick trong menu Tien ich (xem openUtilityMenu). */

    /*  Che do dien tat bot viec ve len man hinh:
          - dong het cua so plugin (giao dien plugin ve lien tuc rat ton CPU)
          - dong ho do muc chay cham lai (xem MixerUI: setMeterRefreshRate)
        Muc dich: nhuong CPU cho luong am thanh trong luc dang hat.  */
    updateStatusText();
}

/** 14/10: tong thoi gian CPU cua CA APP (moi luong: audio, giao dien, ARA, tai file, quet...) tinh bang giay.
    Dung de so voi "CPU audio" cua JUCE: phan chenh = app ton CPU o ngoai luong audio. -1 neu he thong khong cho do. */
static double livent_processCpuSeconds()
{
   #if JUCE_WINDOWS
    FILETIME creation, exitT, kernel, user;
    if (GetProcessTimes (GetCurrentProcess(), &creation, &exitT, &kernel, &user))
    {
        auto toSec = [] (const FILETIME& f) { return (double) (((ULONGLONG) f.dwHighDateTime << 32) | f.dwLowDateTime) * 1.0e-7; };
        return toSec (kernel) + toSec (user);
    }
    return -1.0;
   #else
    struct rusage ru {};
    if (getrusage (RUSAGE_SELF, &ru) == 0)
        return (double) ru.ru_utime.tv_sec + 1.0e-6 * (double) ru.ru_utime.tv_usec
             + (double) ru.ru_stime.tv_sec + 1.0e-6 * (double) ru.ru_stime.tv_usec;
    return -1.0;
   #endif
}

/** 14/10: CPU (giay) da dung cua TUNG LUONG trong app. Chi Windows. {idLuong, giay}. */
struct LiventThreadCpu { unsigned long id; double seconds; juce::String name; };

static std::vector<LiventThreadCpu> livent_threadCpuTimes()
{
    std::vector<LiventThreadCpu> out;
   #if JUCE_WINDOWS
    using GetThreadDescriptionFn = HRESULT (WINAPI*) (HANDLE, PWSTR*);
    static const auto getDescription = (GetThreadDescriptionFn) GetProcAddress (GetModuleHandleW (L"kernel32.dll"), "GetThreadDescription");

    const HANDLE snap = CreateToolhelp32Snapshot (TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return out;
    const DWORD pid = GetCurrentProcessId();
    THREADENTRY32 te;
    te.dwSize = sizeof (te);
    if (Thread32First (snap, &te))
        do
        {
            if (te.th32OwnerProcessID != pid)
                continue;
            if (HANDLE h = OpenThread (THREAD_QUERY_LIMITED_INFORMATION, FALSE, te.th32ThreadID))
            {
                FILETIME creation, exitT, kernel, user;
                if (GetThreadTimes (h, &creation, &exitT, &kernel, &user))
                {
                    auto toSec = [] (const FILETIME& f) { return (double) (((ULONGLONG) f.dwHighDateTime << 32) | f.dwLowDateTime) * 1.0e-7; };
                    juce::String name;
                    if (getDescription != nullptr)
                    {
                        PWSTR desc = nullptr;
                        if (SUCCEEDED (getDescription (h, &desc)) && desc != nullptr)
                        {
                            name = juce::String (juce::CharPointer_UTF16 ((const juce::CharPointer_UTF16::CharType*) desc));
                            LocalFree (desc);
                        }
                    }
                    out.push_back ({ (unsigned long) te.th32ThreadID, toSec (kernel) + toSec (user), name });
                }
                CloseHandle (h);
            }
        } while (Thread32Next (snap, &te));
    CloseHandle (snap);
   #endif
    return out;
}

/** 15/10: CPU (giay) cua cac TIEN TRINH CON / CHAU cua app: cau VST 32-bit (LiveNTBridge32), cua so YouTube
    va WebView2 cua no, plugin host 64-bit, scanner... "CPU ca app" o tren chi do rieng tien trinh chinh nen bo sot
    nhung phan nay (bao cao kiem tra CPU 15/10 muc 3). Chi Windows. {pid, giay, ten file exe}. */
struct LiventChildCpu { unsigned long pid; double seconds; juce::String exe; };

static std::vector<LiventChildCpu> livent_childProcessCpuTimes()
{
    std::vector<LiventChildCpu> out;
   #if JUCE_WINDOWS
    const HANDLE snap = CreateToolhelp32Snapshot (TH32CS_SNAPPROCESS, 0);
    if (snap == INVALID_HANDLE_VALUE)
        return out;

    struct Entry { DWORD pid, parent; juce::String exe; };
    std::vector<Entry> all;
    PROCESSENTRY32W pe;
    pe.dwSize = sizeof (pe);
    if (Process32FirstW (snap, &pe))
        do { all.push_back ({ pe.th32ProcessID, pe.th32ParentProcessID,
                              juce::String (juce::CharPointer_UTF16 ((const juce::CharPointer_UTF16::CharType*) pe.szExeFile)) }); }
        while (Process32NextW (snap, &pe));
    CloseHandle (snap);

    // Moi hau due cua tien trinh nay (con, chau...). Gioi han vong lap de khong bi PID tai su dung lam quay vong.
    std::vector<DWORD> family { GetCurrentProcessId() };
    for (size_t i = 0; i < family.size() && family.size() < 512; ++i)
        for (const auto& e : all)
            if (e.parent == family[i] && e.pid != family[i]
                && std::find (family.begin(), family.end(), e.pid) == family.end())
                family.push_back (e.pid);

    for (size_t i = 1; i < family.size(); ++i)
    {
        HANDLE h = OpenProcess (PROCESS_QUERY_LIMITED_INFORMATION, FALSE, family[i]);
        if (h == nullptr)
            continue;
        FILETIME creation, exitT, kernel, user;
        if (GetProcessTimes (h, &creation, &exitT, &kernel, &user))
        {
            auto toSec = [] (const FILETIME& f) { return (double) (((ULONGLONG) f.dwHighDateTime << 32) | f.dwLowDateTime) * 1.0e-7; };
            juce::String exe;
            for (const auto& e : all)
                if (e.pid == family[i]) { exe = e.exe; break; }
            out.push_back ({ (unsigned long) family[i], toSec (kernel) + toSec (user), exe });
        }
        CloseHandle (h);
    }
   #endif
    return out;
}

void MainComponent::setLiveMode (bool on)
{
    if (on == mixer.isLiveMode())
        return;
    if (on)
    {
        if (mixer.isTimelineRecording() || mixer.isMasterRecording())
        {
            livent::alert (livent::vn ("Đang thu âm"), livent::vn ("Dừng thu trước rồi mới bật Chế độ Live."));
            return;
        }
        if (! mixer.waitForPendingTakes())
        {
            livent::alert (livent::vn ("Bản thu đang chốt"), livent::vn ("Chờ vài giây cho WAV chốt xong rồi bật Chế độ Live."));
            return;
        }
        mixer.stopTimelineTransport();   // dang phat lai ban thu thi dung
    }
    mixer.setLiveMode (on);
    saveLiveModePref (on);
    if (on)
        writeRecoveryCheckpoint();   // 16/10: mot diem cuu ho cuoi truoc khi vao Live
    livent::stabilityLog ("PREF live-mode", on ? "ON" : "OFF");

    // Ve lai giao dien: an / hien nut Thu, Lane, "N lan" va nut thu tren ban tron.
    mixerView.rebuild();
    for (auto* row : trackRows)
        row->refresh();
    inspector.refreshFromTrack();
    updateStatusText();
    tonePanel.showAutoKeyStatus (on ? livent::vn ("Đã bật Chế độ Live: thu âm đã tắt.")
                                    : livent::vn ("Đã tắt Chế độ Live: thu âm hoạt động như cũ."));
    refreshModeSwitch();
}

void MainComponent::refreshModeSwitch()
{
    modeSwitch.setLive (mixer.isLiveMode());
}

void MainComponent::runAudioDropoutDiagnosis (int seconds)
{
    seconds = seconds >= 60 ? 60 : 10;   // 11i: chi 2 lua chon
    auto* device = deviceManager.getCurrentAudioDevice();
    if (! projectOpen || device == nullptr || device->getCurrentSampleRate() <= 0.0
        || device->getCurrentBufferSizeSamples() <= 0
        || projectLoadInProgress || pluginLoadInProgress)
    {
        livent::alert (livent::vn ("Chưa thể đo âm thanh"),
                       livent::vn ("Hãy mở project, đợi nạp xong VST và mở soundcard rồi đo lại."));
        return;
    }
    if (audioDiagnosticsActive.load (std::memory_order_relaxed))
        return;

    const auto projectFile = currentProjectFile;
    const auto generation = projectLoadGeneration;
    const auto deviceType = deviceManager.getCurrentAudioDeviceType();
    const auto deviceName = device->getName();
    const double sampleRate = device->getCurrentSampleRate();
    const int blockSize = device->getCurrentBufferSizeSamples();

    auto getFileMisses = [this]() -> juce::uint64
    {
        juce::uint64 total = 0;
        for (int i = 0; i < mixer.getNumTracks(); ++i)
            if (auto* track = mixer.getTrack (i))
                total += track->getFileLockMissCount();
        return total;
    };
    auto getSendMisses = [this]() -> juce::uint64
    {
        juce::uint64 total = 0;
        for (int i = 0; i < mixer.getNumTracks(); ++i)
            if (auto* track = mixer.getTrack (i))
                total += track->getSendLockMissCount();
        return total;
    };
    auto getBridgeMisses = [this]() -> juce::uint64
    {
        juce::uint64 total = 0;
        for (int i = 0; i < mixer.getNumTracks(); ++i)
            if (auto* track = mixer.getTrack (i))
                for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
                    if (auto bridge = track->getInserts().getBridge32Client (slot))
                        total += (juce::uint64) bridge->getMissedBlocks();
        return total;
    };

    const auto lockBefore = mixer.getMixerLockMissCount();
    const auto lockRetryBefore = mixer.getMixerLockRetryWins();   // 11j
    const double cpuSecBefore = livent_processCpuSeconds();       // 14/10
    const double wallBefore = juce::Time::getMillisecondCounterHiRes() * 0.001;
    const auto threadsBefore = livent_threadCpuTimes();
    const auto childrenBefore = livent_childProcessCpuTimes();    // 15/10
   #if JUCE_WINDOWS
    const unsigned long uiThreadId = (unsigned long) GetCurrentThreadId();   // luong giao dien (message thread)
   #else
    const unsigned long uiThreadId = 0;
   #endif
    const auto fileBefore = getFileMisses();
    const auto sendBefore = getSendMisses();
    const auto bridgeBefore = getBridgeMisses();
    /*  11i: dem rieng tung VST 32-bit de biet DUNG plugin nao hut block (weak_ptr: plugin bi go
        trong luc do thi bo qua, khong giu song bridge).  */
    struct BridgeBefore { std::weak_ptr<Bridge32Client> bridge; int missed; };
    std::vector<BridgeBefore> bridgesBefore;
    for (int i = 0; i < mixer.getNumTracks(); ++i)
        if (auto* track = mixer.getTrack (i))
            for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
                if (auto bridge = track->getInserts().getBridge32Client (slot))
                    bridgesBefore.push_back ({ bridge, bridge->getMissedBlocks() });
    for (int i = 0; i < mixer.getNumTracks(); ++i)
        if (auto* track = mixer.getTrack (i))
            track->getInserts().resetDiagnosticPeaks();

    diagnosticCallbackCount.store (0, std::memory_order_relaxed);
    diagnosticOverBudgetCount.store (0, std::memory_order_relaxed);
    diagnosticPeakPermille.store (0, std::memory_order_relaxed);
    PluginChain::setDiagnosticTimingEnabled (true);
    audioDiagnosticsActive.store (true, std::memory_order_relaxed);

    juce::Component::SafePointer<MainComponent> safe (this);
    juce::MessageManager::callAsync ([safe]
    {
        if (safe != nullptr)
            safe->settingsWindow.reset();
    });

    juce::Timer::callAfterDelay (seconds * 1000,
        [safe, seconds, projectFile, generation, deviceType, deviceName, sampleRate, blockSize,
         lockBefore, lockRetryBefore, fileBefore, sendBefore, bridgeBefore, bridgesBefore, cpuSecBefore, wallBefore, threadsBefore, childrenBefore, uiThreadId]
    {
        PluginChain::setDiagnosticTimingEnabled (false);
        if (safe == nullptr)
            return;
        safe->audioDiagnosticsActive.store (false, std::memory_order_relaxed);

        auto* now = safe->deviceManager.getCurrentAudioDevice();
        if (! safe->projectOpen || safe->currentProjectFile != projectFile
            || safe->projectLoadGeneration != generation || now == nullptr
            || safe->deviceManager.getCurrentAudioDeviceType() != deviceType
            || now->getName() != deviceName
            || now->getCurrentSampleRate() != sampleRate
            || now->getCurrentBufferSizeSamples() != blockSize)
        {
            livent::alert (livent::vn ("Đã hủy phép đo"),
                           livent::vn ("Project hoặc soundcard thay đổi trong lúc đo. Hãy thử lại."));
            return;
        }

        juce::uint64 fileAfter = 0, sendAfter = 0, bridgeAfter = 0;
        struct PluginPeak { int permille; juce::String label; };
        std::vector<PluginPeak> peaks;
        juce::StringArray bridgeLines;   // 11i: tung VST 32-bit
        for (int i = 0; i < safe->mixer.getNumTracks(); ++i)
            if (auto* track = safe->mixer.getTrack (i))
            {
                fileAfter += track->getFileLockMissCount();
                sendAfter += track->getSendLockMissCount();
                auto& inserts = track->getInserts();
                for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
                {
                    if (auto bridge = inserts.getBridge32Client (slot))
                    {
                        const int missedNow = bridge->getMissedBlocks();
                        bridgeAfter += (juce::uint64) missedNow;
                        int missedBefore = -1;
                        for (const auto& b : bridgesBefore)
                            if (b.bridge.lock() == bridge) { missedBefore = b.missed; break; }
                        const int depth = bridge->getActiveDepth();
                        const int mmcss = bridge->getAudioThreadMmcss();
                        bridgeLines.add (track->getName() + " / " + juce::String (slot + 1) + " / "
                                         + inserts.getPluginName (slot) + ": "
                                         + (missedBefore >= 0 ? livent::vn ("hụt ") + juce::String (juce::jmax (0, missedNow - missedBefore))
                                                                  + " block"
                                                              : livent::vn ("mới nạp lại trong lúc đo"))
                                         + livent::vn (" · đệm an toàn: ") + (depth > 1 ? livent::vn ("bật") : livent::vn ("tắt"))
                                         + livent::vn (" · Pro Audio: ")
                                         + (mmcss > 0 ? livent::vn ("có") : mmcss < 0 ? livent::vn ("KHÔNG") : livent::vn ("chưa rõ")));
                    }
                    else if (inserts.getPlugin (slot) != nullptr)
                    {
                        const int peak = inserts.getDiagnosticPeakPermille (slot);
                        if (peak > 0)
                            peaks.push_back ({ peak, track->getName() + " / "
                                + juce::String (slot + 1) + " / " + inserts.getPluginName (slot) });
                    }
                }
            }
        std::sort (peaks.begin(), peaks.end(), [] (const PluginPeak& a, const PluginPeak& b)
        {
            return a.permille > b.permille;
        });

        auto delta = [] (juce::uint64 after, juce::uint64 before)
        {
            return (juce::int64) (after >= before ? after - before : 0);
        };
        // 14/10: CPU CA APP (nhu Task Manager) tach khoi CPU luong audio -> biet nang o audio hay o giao dien / luong khac.
        juce::String processCpuLine;
        {
            const double cpuSecAfter = livent_processCpuSeconds();
            const double wall = juce::Time::getMillisecondCounterHiRes() * 0.001 - wallBefore;
            if (cpuSecBefore >= 0.0 && cpuSecAfter >= cpuSecBefore && wall > 0.5)
            {
                const double cores = (double) juce::jmax (1, juce::SystemStats::getNumCpus());
                const double used = (cpuSecAfter - cpuSecBefore) / wall;   // so "nhan" trung binh
                processCpuLine << livent::vn ("CPU cả app (mọi luồng): ") << juce::String (juce::roundToInt (used * 100.0))
                               << livent::vn ("% của 1 nhân  =  ") << juce::String (used / cores * 100.0, 1)
                               << livent::vn ("% tổng máy (") << (int) cores << livent::vn (" nhân, giống Task Manager)\n");
            }
            else
                processCpuLine << livent::vn ("CPU cả app: không đo được trên máy này\n");

            // 15/10: tien trinh con (cau VST 32-bit, YouTube + WebView2, plugin host...) - phan Task Manager tinh rieng.
            const auto childrenAfter = livent_childProcessCpuTimes();
            if (! childrenAfter.empty() && wall > 0.5)
            {
                const double cores = (double) juce::jmax (1, juce::SystemStats::getNumCpus());
                struct ChildRow { juce::String exe; double pct = 0.0; int count = 0; };
                std::vector<ChildRow> kids;
                double childTotal = 0.0;
                for (const auto& a : childrenAfter)
                {
                    double before = 0.0;               // tien trinh moi sinh trong luc do: tinh tu 0
                    for (const auto& b : childrenBefore)
                        if (b.pid == a.pid && b.exe == a.exe) { before = b.seconds; break; }
                    const double pct = juce::jmax (0.0, a.seconds - before) / wall * 100.0;
                    childTotal += pct;
                    auto it = std::find_if (kids.begin(), kids.end(), [&] (const ChildRow& r) { return r.exe == a.exe; });
                    if (it == kids.end()) { kids.push_back ({ a.exe, pct, 1 }); }
                    else { it->pct += pct; ++it->count; }
                }
                std::sort (kids.begin(), kids.end(), [] (const ChildRow& x, const ChildRow& y) { return x.pct > y.pct; });
                processCpuLine << livent::vn ("Tiến trình con (cầu VST 32-bit, YouTube, plugin host...): ")
                               << juce::String (juce::roundToInt (childTotal)) << livent::vn ("% của 1 nhân\n");
                int shown = 0;
                for (const auto& k : kids)
                {
                    if (k.pct < 0.5 || shown >= 6) continue;
                    ++shown;
                    const auto lower = k.exe.toLowerCase();
                    juce::String label = lower.contains ("bridge32") ? livent::vn ("cầu VST 32-bit (") + k.exe + ")"
                                       : lower.contains ("webview2") ? livent::vn ("trình duyệt nhúng của YouTube (") + k.exe + ")"
                                       : lower.contains ("youtube")  ? livent::vn ("cửa sổ YouTube (") + k.exe + ")"
                                       : k.exe;
                    processCpuLine << "   " << juce::String (k.pct, 1) << "%  " << label
                                   << (k.count > 1 ? " x" + juce::String (k.count) : juce::String()) << "\n";
                }
                if (cpuSecBefore >= 0.0 && cpuSecAfter >= cpuSecBefore)
                {
                    const double mainPct = (cpuSecAfter - cpuSecBefore) / wall * 100.0;
                    processCpuLine << livent::vn ("TỔNG app + tiến trình con: ") << juce::String (juce::roundToInt (mainPct + childTotal))
                                   << livent::vn ("% của 1 nhân  =  ") << juce::String ((mainPct + childTotal) / cores, 1)
                                   << livent::vn ("% tổng máy\n");
                }
            }

            // Tung luong: luong nao ngon CPU nhat (% cua 1 nhan trong luc do).
            const auto threadsAfter = livent_threadCpuTimes();
            if (! threadsAfter.empty() && wall > 0.5)
            {
                struct Row { double pct; juce::String label; };
                std::vector<Row> rows;
                for (const auto& a : threadsAfter)
                {
                    double before = 0.0;
                    for (const auto& b : threadsBefore)
                        if (b.id == a.id) { before = b.seconds; break; }
                    const double pct = juce::jmax (0.0, a.seconds - before) / wall * 100.0;
                    if (pct < 0.5)
                        continue;
                    juce::String label = a.id == uiThreadId ? livent::vn ("giao diện (luồng chính)")
                                       : a.name.isNotEmpty() ? a.name
                                       : livent::vn ("luồng #") + juce::String ((juce::int64) a.id);
                    rows.push_back ({ pct, label });
                }
                std::sort (rows.begin(), rows.end(), [] (const Row& x, const Row& y) { return x.pct > y.pct; });
                processCpuLine << livent::vn ("Luồng tốn CPU nhất (% của 1 nhân):\n");
                for (size_t i = 0; i < rows.size() && i < 8; ++i)
                    processCpuLine << "   " << juce::String (rows[i].pct, 1) << "%  " << rows[i].label << "\n";
                if (rows.empty())
                    processCpuLine << livent::vn ("   (không luồng nào quá 0,5%)\n");
            }
        }
        juce::String report;
        report << "LiveNT - " << livent::vn ("đo giật tiếng ") << seconds << livent::vn (" giây\n")
               << livent::vn ("Driver: ") << deviceType << " / " << deviceName << " / "
               << juce::String (sampleRate, 0) << " Hz / buffer " << blockSize << "\n"
               << livent::vn ("Thời gian một block: ")
               << juce::String (1000.0 * blockSize / sampleRate, 2) << " ms\n"
               << livent::vn ("CPU audio hiện tại: ")
               << juce::String (safe->deviceManager.getCpuUsage() * 100.0, 1) << "%\n"
               << processCpuLine
               << livent::vn ("Callback vượt thời hạn: ")
               << safe->diagnosticOverBudgetCount.load (std::memory_order_relaxed)
               << "/" << safe->diagnosticCallbackCount.load (std::memory_order_relaxed) << "\n"
               << livent::vn ("Đỉnh thời gian callback: ")
               << juce::String (safe->diagnosticPeakPermille.load (std::memory_order_relaxed) / 10.0, 1)
               << "% " << livent::vn ("thời hạn block\n")
               << livent::vn ("Khóa mixer trượt: ")
               << delta (safe->mixer.getMixerLockMissCount(), lockBefore) << "\n"
               << livent::vn ("Khóa mixer bận nhưng chờ vào kịp (không tách): ")
               << delta (safe->mixer.getMixerLockRetryWins(), lockRetryBefore) << "\n"
               << livent::vn ("Khóa file nhạc trượt: ")
               << delta (fileAfter, fileBefore) << "\n"
               << livent::vn ("Khóa đường Send trượt: ")
               << delta (sendAfter, sendBefore) << "\n"
               << livent::vn ("Bridge32 hụt block: ")
               << delta (bridgeAfter, bridgeBefore) << "\n";

        if (! bridgeLines.isEmpty())
        {
            report << livent::vn ("\nVST 32-bit (cầu nối):\n");
            for (const auto& line : bridgeLines)
                report << line << "\n";
        }

        if (! peaks.empty())
        {
            report << livent::vn ("\nĐỉnh tải riêng từng VST (tối đa 5):\n");
            for (int i = 0; i < juce::jmin (5, (int) peaks.size()); ++i)
                report << peaks[(size_t) i].label << ": "
                       << juce::String (peaks[(size_t) i].permille / 10.0, 1) << "%\n";
        }
        report << livent::vn ("\nPhép đo không thấy được trễ driver trước callback. "
                             "Đỉnh của các VST có thể xảy ra ở những block khác nhau.");

        const auto file = PluginChain::getSettingsFolder().getChildFile ("audio_diagnostics.txt");
        const bool saved = file.replaceWithText (report);
        livent::alert (livent::vn ("Kết quả đo giật tiếng"),
                       report + (saved ? livent::vn ("\n\nFile báo cáo: ") + file.getFullPathName()
                                       : juce::String()));
    });
}

//=============================================================================
//  Luu / mo du an
//=============================================================================
//=============================================================================
//  DU AN .NT
//=============================================================================
//  Duoi file ".NT" chi la ten goi - ben trong van la XML nhu truoc, doc ghi
//  khong doi mot dong nao. Cubase dung ".cpr", Studio One dung ".song", minh
//  dung ".NT". Cai duoi giup Windows biet file nao la cua LiveNT, va giup anh
//  moi buoi dien mot file rieng: QuanA.NT, SanKhauLon.NT...

static const char* kProjectExtension = ".NT";

static juce::File musicVst2PreferenceFileFor (const juce::File& projectFile)
{
    return projectFile == juce::File() ? juce::File()
        : projectFile.getSiblingFile (projectFile.getFileName() + ".music-vst2-window.xml");
}
static const char* kProjectWildcard  = "*.NT";

static juce::File defaultMixFileFor (const juce::File& project)
{
    return project.getSiblingFile (project.getFileName() + ".mix-default.xml");
}

/* Binary state cua mot so VST (dac biet plugin doi meter/internal cache) co
   the khac byte giua hai lan getStateInformation() du nguoi dung khong sua
   parameter nao. Neu đem ca chuoi Base64 do so sanh de quyet dinh "du an da
   thay doi" thi Save xong dong app van bi hoi Save lai.

   Ban so sanh chi bo THUOC TINH state cua node PLUGIN; moi thu host quan ly
   (track, routing, gain/pan, send, ten bus, bypass, UI...) van duoc so sanh. */
static void stripVolatilePluginState (juce::XmlElement& e)
{
    if (e.hasTagName ("PLUGIN"))
        e.removeAttribute ("state");

    // V6.2: playhead chi la vi tri dang xem, khong phai thay doi am nhac.
    // Neu dem POSITION vao so sanh thi chi bam Space/nghe lai cung bi dau *.
    if (e.hasTagName ("TRACK_TIMELINE"))
        e.removeAttribute ("position");

    for (auto* child : e.getChildIterator())
        stripVolatilePluginState (*child);
}

static juce::String comparableProjectXml (std::unique_ptr<juce::XmlElement> xml)
{
    if (xml == nullptr)
        return {};

    stripVolatilePluginState (*xml);

    /*  MOC 96: bo cuc/cua so la trang thai cua UNG DUNG, khong phai am nhac.
        Mo F2, keo cua so hay doi kich thuoc khong duoc lam project thanh dirty. */
    if (auto* ui = xml->getChildByName ("UI"))
        xml->removeChildElement (ui, true);

    return xml->toString();
}

juce::File MainComponent::getDefaultProjectFolder()
{
    auto folder = juce::File::getSpecialLocation (juce::File::userDocumentsDirectory)
                      .getChildFile ("LiveNT");

    folder.createDirectory();
    return folder;
}

juce::File MainComponent::getAutosaveFile() const
{
    // Ban tu dong luon nam trong thu muc cai dat, khong lam ban thu muc du an
    return PluginChain::getSettingsFolder().getChildFile ("autosave.NT");
}

void MainComponent::setCurrentProjectFile (const juce::File& file)
{
    if(file==juce::File() || file.getParentDirectory()!=currentProjectFile.getParentDirectory())currentProjectPortable=false;
    currentProjectFile = file;

    // V6.2: tu khi du an co ten, take moi nam canh file .NT de de backup /
    // mang sang may khac:  BaiHat.NT + BaiHat_Audio/*.wav. Du an chua luu
    // van dung AppData/LiveNT/Recordings de khong ep anh Save truoc khi thu.
    if (file != juce::File())
        mixer.setTimelineRecordingFolder (file.getSiblingFile (
            file.getFileNameWithoutExtension() + "_Audio"));
    else
        mixer.setTimelineRecordingFolder (juce::File());

    // 07/10: danh dau take dang thu thuoc du an nao (khoi phuc khi app tat ngang)
    mixer.setTimelineRecoveryTag (file.getFullPathName());

    if (file != juce::File())
    {
        recentFiles.addFile (file);
        saveRecentList();
    }

    refreshProjectHub();
    updateTitleText();
}

//=============================================================================
// MOC 96: HUB DU AN
//=============================================================================
void MainComponent::refreshProjectHub()
{
    hubRecentButtons.clear (true);
    hubRecentFiles.clear();

    // 06/10: man moi hien ca file da mat (mo di, bam de xoa khoi danh sach)
    {
        juce::Array<juce::File> all;
        for (int i = 0; i < recentFiles.getNumFiles(); ++i)
            all.add (recentFiles.getFile (i));
        projectHub.setRecentFiles (all);
    }

    const int count = 0;   // 06/10: nut cu khong dung nua

    for (int i = 0; i < count; ++i)
    {
        const auto file = recentFiles.getFile (i);

        if (! file.existsAsFile())
            continue;

        hubRecentFiles.add (file);

        auto* b = hubRecentButtons.add (
            new juce::TextButton (file.getFileNameWithoutExtension()));

        b->setTooltip (file.getFullPathName());
        b->setColour (juce::TextButton::buttonColourId, Col::panel2);
        b->setColour (juce::TextButton::textColourOffId, Col::text);

        b->onClick = [this, file]
        {
            requestOpenProject (file);
        };

        addAndMakeVisible (b);
        b->setVisible (! projectOpen);
    }

    resized();
    repaint();
}

void MainComponent::updateProjectUiState()
{
    const bool showHub = ! projectOpen;

    hubNewProjectButton.setVisible (false);
    hubOpenProjectButton.setVisible (false);
    projectHub.setVisible (showHub);
    if (showHub)
    {
        projectHub.refreshStatus();
        juce::Component::SafePointer<ProjectHub> hub (&projectHub);
        juce::MessageManager::callAsync ([hub] { if (hub != nullptr && hub->isShowing()) hub->focusName(); });
    }

    for (auto* b : hubRecentButtons)
        b->setVisible (showHub);

    /* Chua co project thi khong co DAW de gan VST. */
    tonePanel.setVisible (! showHub);

    // 30/09: nho / tra lai vi tri cua so DAW khi chuyen Hub <-> du an.
    if (showHub)
    {
        if (uiShowingProject)
            saveProjectWindowPosition();   // truoc khi Hub phong to cua so
        uiShowingProject = false;
        projectWindowPlaced = false;
    }
    else if (! uiShowingProject)
    {
        uiShowingProject = true;
        juce::Component::SafePointer<MainComponent> safe (this);
        juce::MessageManager::callAsync ([safe]
        {
            if (safe != nullptr)
                safe->restoreProjectWindowPosition();
        });
    }

    if (showHub)
    {
        inspectorViewport.setVisible (false);
        inspectorSplitter.setVisible (false);
    trackWidthSplitter.setVisible (false);
        trackListViewport.setVisible (false);
        mixerView.setVisible (false);
        mixerSplitter.setVisible (false);

        /* V6.6.4 HUB SIZE FIX:
           Hub co kich thuoc rieng, khong ke thua cua so Bang dieu khien dang
           thu gon. Khi Dong du an de quay ve Hub trong CUNG mot phien, mo rong
           ve muc de doc 1180x700; nhung van clamp theo display hien tai de
           laptop / Windows scale 125-150% khong bi tran man hinh. */
        int hubW = 1180;
        int hubH = 700;

        juce::Rectangle<int> screenArea;
        if (auto* top = getTopLevelComponent())
        {
            if (auto* display = juce::Desktop::getInstance().getDisplays().getDisplayForRect (top->getBounds()))
                screenArea = display->userArea;
        }

        if (screenArea.isEmpty())
            if (auto* primary = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay())
                screenArea = primary->userArea;

        if (! screenArea.isEmpty())
        {
            hubW = juce::jmin (hubW, juce::jmax (320, screenArea.getWidth()  - 30));
            hubH = juce::jmin (hubH, juce::jmax (190, screenArea.getHeight() - 30));
        }

        if (getWidth() < hubW || getHeight() < hubH)
            setSize (juce::jmax (hubW, getWidth()), juce::jmax (hubH, getHeight()));
    }

    // macOS dùng native main menu; trạng thái enable/check của các mục như
    // Bàn làm việc (F2) được cache. Báo menu rebuild ngay sau khi đổi project,
    // nếu không F2 có thể vẫn xám dù project đã mở.
    menuItemsChanged();

    resized();
    repaint();
}

juce::File MainComponent::projectWindowFile() const
{
    return livent::controlLayout::file (verticalControlLayout);
}

void MainComponent::saveProjectWindowPosition()
{
    auto* w = dynamic_cast<juce::ResizableWindow*> (getTopLevelComponent());
    if (w == nullptr || w->isMinimised() || w->isFullScreen())
        return;

    const auto b = w->getBounds();
    if (auto* d = juce::Desktop::getInstance().getDisplays().getDisplayForRect (b))
    {
        const auto vis = d->userArea.getIntersection (b);
        if (vis.getWidth() < 120 || vis.getHeight() < 80)
            return;
    }

    livent::controlLayout::save (*w, verticalControlLayout);
}

void MainComponent::restoreProjectWindowPosition()
{
    if (! projectOpen)
        return;

    if (auto* top = getTopLevelComponent())
    {
        auto* w = dynamic_cast<juce::ResizableWindow*> (top);
        const bool usable = w == nullptr || (! w->isMinimised() && ! w->isFullScreen());

        // window.txt: "[fs ]x y w h ..." -> chi lay VI TRI, giu kich thuoc gon hien tai.
        auto tokens = juce::StringArray::fromTokens (livent::controlLayout::load (verticalControlLayout), " ", {});
        tokens.removeEmptyStrings();
        if (tokens.size() > 0 && tokens[0] == "fs")
            tokens.remove (0);

        if (usable && tokens.size() >= 4
            && tokens[0].containsOnly ("-0123456789") && tokens[1].containsOnly ("-0123456789"))
        {
            auto target = top->getBounds().withPosition (tokens[0].getIntValue(), tokens[1].getIntValue());
            const int width = tokens[2].getIntValue(), height = tokens[3].getIntValue();
            if (width >= 264 && width <= 6000 && height >= 100 && height <= 4000)
                target.setSize (juce::jmax (width, top->getWidth()), juce::jmax (height, top->getHeight()));

            if (auto* d = juce::Desktop::getInstance().getDisplays().getDisplayForRect (target))
            {
                const auto vis = d->userArea.getIntersection (target);
                if (vis.getWidth() >= 120 && vis.getHeight() >= 80)
                {
                    // Lot ra ngoai mep (vd DAW Doc cao hon lan truoc): day vao trong.
                    target = target.constrainedWithin (d->userArea);
                    top->setBounds (target);
                }
            }
        }
    }

    // Bao YouTube: DAW da ve cho, gio moi duoc dat YouTube canh DAW lan dau.
    projectWindowPlaced = true;
    lastPublishedDawWindow.clear();
    publishDawWindowForYouTube();
}

void MainComponent::setVerticalControlLayout (bool on, bool persistPreference, bool markProject)
{
    if (verticalControlLayout == on)
        return;

    // Dong cac popup phu truoc khi doi hinh dang cua so de toa do anchor
    // khong bi giu theo bo cuc cu.
    saveProjectWindowPosition();
    tonePanel.closeLaughPanel();

    // Neu doi tu ngay trong bang Cai dat, owner se dong bang o message
    // tick ke tiep (menu() da lam san) de khong huy nut dang chay callback.
    verticalControlLayout = on;
    tonePanel.setVerticalLayout (verticalControlLayout, false);

    if (persistPreference)
        saveVerticalLayoutPref (verticalControlLayout);

    if (markProject && projectOpen)
    {
        markProjectDirty();
        updateTitleText();
    }

    autoLiftActive = false;
    compactControlPanelWindow();
    restoreProjectWindowPosition();
    resized();
    repaint();

    // Bao ngay cho cua so YouTube: Ngang -> dinh tren/duoi, Doc -> trai/phai.
    publishDawWindowForYouTube();
}

void MainComponent::compactControlPanelWindow()
{
    if (! projectOpen)
        return;

    if (compactUiActive())
    {
        // 06/10: kich thuoc thanh gon co dinh: logo + luoi 8 o x 2 hang
        constexpr int pad = 7, logoW = 46;
        const int wantedW = pad + logoW + 8 + TonePanel::compactGridWidth() + pad;
        const int wantedH = pad + TonePanel::compactGridHeight() + pad;
        if (auto* dw = findParentComponentOfClass<juce::DocumentWindow>())
            dw->setResizeLimits (juce::jmin (320, wantedW), juce::jmin (60, wantedH), 6000, 4000);
        if (getWidth() != wantedW || getHeight() != wantedH)
            setSize (wantedW, wantedH);
        autoLiftActive = false;      // thanh gon khong dung "nho cho cu" cua 7 num
        placeCompactBar();
        return;
    }

    /* V6.5.2: ngang giữ khung 640. Dọc compact còn 340 px khi gấp núm;
       mở 7 núm sang phải thành khoảng 580 px, chiều cao vẫn giữ gọn. */
    const int chromeH = titleChromeHeight (verticalControlLayout);
    const int wantedW = verticalControlLayout ? tonePanel.getWantedWidth() : 640;
    const int wantedH = juce::jmax (kMinControlPanelHeight, tonePanel.getWantedHeight() + chromeH + statusBarHeightForWidth (wantedW) + 2);

    if (getWidth() != wantedW || std::abs (getHeight() - wantedH) > 2)
        setSize (wantedW, wantedH);

    /*  V0.6.7.9d: doi Ngang <-> Doc (hay doi ti le) lam cua so to ra -> neu
        dang dat sat mep man hinh thi phan moi lo ra ngoai. Day cua so vao
        trong vung lam viec (tru thanh taskbar): tran xuong day thi day LEN,
        tran phai thi day sang TRAI.  */
    if (auto* top = getTopLevelComponent())
    {
        const auto b = top->getBounds();
        const auto nb = placeWithLiftMemory (*top, b);

        if (nb.getPosition() != b.getPosition())
            top->setTopLeftPosition (nb.getPosition());
    }
}

juce::Rectangle<int> MainComponent::placeWithLiftMemory (juce::Component& top,
                                                         juce::Rectangle<int> target)
{
    const auto current = top.getBounds();

    // Nguoi dung tu keo cua so (khong phai DAW dang animate) -> quen cho cu.
    /*  06/10 (Mac): macOS hay tu xe dich cua so vai pixel sau khi minh dat
        vi tri (thanh tieu de, Dock, lam tron Retina). Truoc day lech 1 px la
        coi nhu nguoi dung tu keo -> quen cho cu -> thu 7 num lai thi DAW
        khong ve sat mep. Gio cho phep lech toi 8 px.  */
    if (autoLiftActive
        && ! juce::Desktop::getInstance().getAnimator().isAnimating (&top)
        && (std::abs (current.getX() - autoLiftAppliedPos.getX()) > 8
            || std::abs (current.getY() - autoLiftAppliedPos.getY()) > 8))
        autoLiftActive = false;

    auto* display = juce::Desktop::getInstance().getDisplays().getDisplayForRect (target);
    if (display == nullptr)
        return target;

    const auto work = display->userArea;

    // 1) Dang nho cho cu va cua so nay VUA lai: ve sat mep nhu truoc
    //    (giu mep DUOI cu, khong phai mep tren, de kich thuoc khac chut van sat).
    if (autoLiftActive)
    {
        const auto back = target.withPosition (autoLiftOriginal.getX(),
                                               autoLiftOriginal.getBottom() - target.getHeight());
        // 06/10 (Mac): cua so dat sat day co the de len vung Dock (ngoai
        // userArea) - van cho ve cho cu mien con nam trong man hinh that.
        if (work.contains (back) || display->totalArea.contains (back))
        {
            autoLiftActive = false;
            return back;
        }
    }

    // 2) Day vao trong vung lam viec (tru taskbar) nhu truoc.
    auto placed = target;
    if (placed.getBottom() > work.getBottom()) placed.setY (work.getBottom() - placed.getHeight());
    if (placed.getRight()  > work.getRight())  placed.setX (work.getRight()  - placed.getWidth());
    placed.setX (juce::jmax (work.getX(), placed.getX()));
    placed.setY (juce::jmax (work.getY(), placed.getY()));

    if (placed.getPosition() != target.getPosition() && ! autoLiftActive)
    {
        autoLiftActive = true;
        autoLiftOriginal = current;   // cho cu, truoc khi bi day
    }

    if (autoLiftActive)
        autoLiftAppliedPos = placed.getPosition();

    return placed;
}

juce::File MainComponent::getVst32BridgeFile()
{
    /* Bridge do LiveNT tu viet se dat CUNG THU MUC voi LiveNT.exe.
       Chua co file van tra ve dung duong dan mong doi de UI/host biet cho tim. */
    return juce::File::getSpecialLocation (juce::File::currentExecutableFile)
              .getSiblingFile ("LiveNTBridge32.exe");
}

void MainComponent::openProjectFile (const juce::File& file)
{
    requestOpenProject (file);
}

void MainComponent::requestOpenProject (const juce::File& file)
{
    if (! file.existsAsFile())
        return;

    /* HOTFIX10: dang mo project cu thi khong bat nguoi dung doi het 10-20 VST.
       Ghi nho file moi, dung hang doi SAU plugin dang khoi tao hien tai; khi
       worker tra ve, finishProjectPluginLoadQueue() se mo file moi. Khong
       khoi tao hai DLL VST song song de tranh Waves/Antares dung global state. */
    if (projectLoadInProgress)
    {
        pendingProjectAfterLoadCancel = file;
        cancelProjectPluginLoad();
        return;
    }

    if (pluginLoadInProgress)
    {
        livent::alert (livent::vn ("Đang nạp VST"),
                       livent::vn ("Hãy chờ plugin đang nạp xong rồi đổi/đóng dự án. "
                                  "LiveNT chỉ nạp một VST tại một thời điểm để tránh chồng luồng."));
        return;
    }

    /* Neu chua co project, hoac project dang mo da sach, thay tai lieu ngay.
       Neu dang dirty thi tuyet doi khong duoc load de len state cu: hoi Luu /
       Mo khong luu / Huy truoc, giong hanh vi cua mot DAW kieu document. */
    if (! projectOpen || ! hasUnsavedChanges())
    {
        loadProjectFrom (file);
        return;
    }

    livent::confirm3 (livent::vn ("Mở dự án khác"),
                      livent::vn ("Dự án hiện tại có thay đổi chưa lưu."),
                      livent::vn ("Lưu rồi mở"), livent::vn ("Mở không lưu"), livent::vn ("Hủy"),
        [this, file] (int choice)
        {
            if (choice == 0)
                return;

            if (choice == 2)
            {
                loadProjectFrom (file);
                return;
            }

            if (currentProjectFile == juce::File())
            {
                pendingProjectToOpenAfterSaveAs = file;
                saveProjectAs();
                return;
            }

            if (writeProjectTo (currentProjectFile))
                loadProjectFrom (file);
        });
}

void MainComponent::updateTitleText()
{
    juce::String text;

    if (! projectOpen)
        text = livent::vn ("không có dự án");
    else if (currentProjectFile == juce::File())
        text = livent::vn ("dự án mới - chưa lưu");
    else
        text = currentProjectFile.getFileNameWithoutExtension();

    if (projectOpen && projectDirty)
        text << "  *";

    subtitleLabel.setText (text, juce::dontSendNotification);

    //  V6.0: ten du an nam o thanh trang thai, canh CPU. Ten dai -> "...",
    //  re chuot vao thi hien day du duong dan.
    juce::String shown;

    if (! projectOpen)                           shown = livent::vn ("Chưa mở dự án");
    else if (currentProjectFile == juce::File()) shown = livent::vn ("Dự án mới (chưa lưu)");
    else                                         shown = currentProjectFile.getFileName();

    if (projectOpen && projectDirty)
        shown << "  *";

    projectNameLabel.setText (shown, juce::dontSendNotification);
    topBrandLabel.setTooltip (shown);   // 07/10: mau C - ten du an hien khi re chuot vao ten thuong hieu
    projectNameLabel.setTooltip (currentProjectFile == juce::File() ? shown
                                                                   : currentProjectFile.getFullPathName());
}

//=============================================================================
/** MOC 65: dung chung cho ca luc GHI file that va luc chi CAN SO SANH xem
    du an co gi thay doi so voi lan luu gan nhat khong (xem hasUnsavedChanges()
    va confirmCloseAndQuit()) - tach rieng ra de khong phai chep lai y het
    dong nay o hai noi, dam sai lech nhau ve sau.  */
std::unique_ptr<juce::XmlElement> MainComponent::buildProjectStateXml (bool includePluginState)
{
    auto xml = mixer.getState (includePluginState);

    if (xml == nullptr)
        return nullptr;

    // 01/10: cach gan nut nam TRONG du an -> mang sang may khac van giu.
    if (! tonePanel.getButtonMap().isEmpty())
        xml->addChildElement (tonePanel.getButtonMap().toXml().release());

    // 02/10: 5 preset the loai nam TRONG du an.
    if (tonePanel.getPresetBank().hasAny())
        xml->addChildElement (tonePanel.getPresetBank().toXml().release());

    auto* ui = xml->createNewChildElement ("UI");

    ui->setAttribute ("fxFolderOpen",  fxFolderOpen  ? 1 : 0);
    ui->setAttribute ("outFolderOpen", outFolderOpen ? 1 : 0);
    ui->setAttribute ("tonePanelOpen", tonePanel.isPanelOpen() ? 1 : 0);
    ui->setAttribute ("toneTrackId",   tonePanel.getTargetTrackId());
    ui->setAttribute ("toneAutoWatch", tonePanel.isAutoWatchOn() ? 1 : 0);
    ui->setAttribute ("toneLinkRow",   tonePanel.isLinkRowOpen() ? 1 : 0);
    ui->setAttribute ("knobsExpanded", tonePanel.areKnobsExpanded() ? 1 : 0);
    ui->setAttribute ("controlLayoutVertical", verticalControlLayout ? 1 : 0);
    ui->setAttribute ("autoOpenMusicVst2", autoOpenMusicVst2 ? 1 : 0);
    // The .NT itself carries the editor placement when saved and copied to
    // another computer. The sidecar also remembers changes before Save.
    if (auto* music = mixer.getTrackByRole (Track::Role::Music))
    {
        juce::Rectangle<int> bounds;
        bool pinned = true;
        if (pluginWindows.getPlacement (
                PluginWindowManager::makeKey (music->getId(), kMusicVst2Slot),
                bounds, pinned))
        {
            ui->setAttribute ("musicVst2X", bounds.getX());
            ui->setAttribute ("musicVst2Y", bounds.getY());
            ui->setAttribute ("musicVst2W", bounds.getWidth());
            ui->setAttribute ("musicVst2H", bounds.getHeight());
            ui->setAttribute ("musicVst2Pin", pinned ? 1 : 0);
        }
    }
    ui->setAttribute ("inspectorVisible", inspectorVisible ? 1 : 0);        // MOC 74
    ui->setAttribute ("trackListVisible", trackListVisible ? 1 : 0);        // MOC 75
    ui->setAttribute ("mixerVisible",     mixerVisible     ? 1 : 0);        // MOC 75
    ui->setAttribute ("mixerDetached", 0);   // MOC 95: F3 chi nam trong F2, khong con tach rieng
    ui->setAttribute ("toneOffset", (double) tonePanel.getToneOffsetTong());
    ui->setAttribute ("f2LayoutRevision", 1);
    ui->setAttribute ("inspectorWidth",  inspectorWidth);
    ui->setAttribute ("trackControlsWidth", trackControlsWidth);
    ui->setAttribute ("fxFolderOpen",  fxFolderOpen  ? 1 : 0);
    ui->setAttribute ("outFolderOpen", outFolderOpen ? 1 : 0);
    ui->setAttribute ("secRouting", inspector.isSectionOpen (0) ? 1 : 0);
    ui->setAttribute ("secInserts", inspector.isSectionOpen (1) ? 1 : 0);
    ui->setAttribute ("secSends",   inspector.isSectionOpen (2) ? 1 : 0);
    ui->setAttribute ("secLevel",   inspector.isSectionOpen (3) ? 1 : 0);
    ui->setAttribute ("secEq", inspector.isSectionOpen(4));
    ui->setAttribute ("hwOutMask", (int) mixer.getHardwareOutMask());

    if (auto* dw = findParentComponentOfClass<juce::DocumentWindow>())
        ui->setAttribute ("winState", dw->getWindowStateAsString());

    return xml;
}

juce::String MainComponent::buildComparableProjectState()
{
    /* Phan host: bo opaque state Base64 cua VST. */
    auto text = comparableProjectXml (buildProjectStateXml (false));

    /* Phan plugin: doc gia tri parameter CHUAN HOA 0..1. Nhờ vậy user xoay
       knob trong giao dien VST van duoc tinh la thay doi, nhung meter/cache
       noi bo cua plugin khong con lam dirty sai. */
    text << "\n<PARAMETERS>";

    for (int ti = 0; ti < mixer.getNumTracks(); ++ti)
    {
        auto* t = mixer.getTrack (ti);
        if (t == nullptr)
            continue;

        auto& chain = t->getInserts();
        for (int si = 0; si < PluginChain::maxSlots; ++si)
        {
            if (auto bridge = chain.getBridge32Client (si))
            {
                // V6.4.6: native editor VST2 32-bit nam trong process x86.
                // Bridge tang revision moi lan plugin bao audioMasterAutomate,
                // nen vặn núm native vẫn được tính là thay đổi của project.
                text << "\nT" << t->getId() << ":S" << si
                     << ":B32REV=" << bridge->getParameterRevision();
                continue;
            }

            auto* p = chain.getPlugin (si);
            if (p == nullptr)
                continue;

            text << "\nT" << t->getId() << ":S" << si << ":";
            const auto params = p->getParameters();
            for (auto* param : params)
                if (param != nullptr)
                    text << juce::String ((double) param->getValue(), 7) << ",";
        }
    }

    text << "</PARAMETERS>";
    return text;
}

/** MOC 65: co gi thay doi tu luc luu gan nhat (hoac tu luc mo file) khong.
    Dung de QUYET DINH co can hoi "Luu truoc khi thoat?" hay khong - da luu
    roi va khong dong gi them thi khong can hoi lai, do vao thang luon cho
    nhanh (xem confirmCloseAndQuit()).

    Cach lam: dung lai TOAN BO trang thai thanh XML (y het luc ghi file that)
    roi so sanh CHUOI voi ban da chup luc luu/mo gan nhat. Don gian hon nhieu
    so voi rai co "dirty" o moi noi co the sua du an (them track, doi num,
    keo fader...) - it cho de sot, doi lai ton chut cong dung moi lan hoi.  */
bool MainComponent::hasUnsavedChanges()
{
    if (! projectOpen)
        return false;

    // Co thay doi ro rang do LiveNT ghi nhan (vd mo/chinh VST) thi khoi can
    // dung lai XML de so sanh.
    if (projectDirty)
        return true;

    return buildComparableProjectState() != lastSavedStateXml;
}

//=============================================================================
bool MainComponent::writeProjectTo (const juce::File& file)
{
    if (! projectOpen)
        return false;

    // 07/10 _E: bam DUNG xong LUU ngay -> cho ban thu chot o nen xong truoc
    if(mixer.isTimelineRecording())
    {
        livent::alert(livent::vn("Chưa lưu dự án"),livent::vn("Hãy dừng thu để chốt WAV trước khi lưu. File dự án cũ được giữ nguyên."));
        return false;
    }
    if(!mixer.waitForPendingTakes())
    {
        livent::alert(livent::vn("Bản thu đang chốt"),livent::vn("Chưa ghi đè dự án vì WAV mới chưa hoàn tất. Chờ vài giây rồi bấm Lưu lại."));
        return false;
    }

    auto xml = buildProjectStateXml();

    if (xml == nullptr)
        return false;

    if(currentProjectPortable && file.getParentDirectory()==currentProjectFile.getParentDirectory())
    {
        const auto root=file.getParentDirectory();xml->setAttribute("portable",true);xml->setAttribute("portableVersion",1);
        livent::portable::rewriteMedia(*xml,[&](juce::String& path){const juce::File media(path);if(media.isAChildOf(root))path=media.getRelativePathFrom(root).replaceCharacter('\\','/');return true;});
    }

    /*  ==========  DEM TRACK TRUOC KHI GHI  ==========

        De lat nua doi chieu voi file da ghi ra. Neu hai so khong khop thi co
        gi do sai va KHONG duoc phep coi la luu thanh cong.  */
    int trackCount = 0;

    for (auto* e : xml->getChildWithTagNameIterator ("TRACK"))
    {
        juce::ignoreUnused (e);
        ++trackCount;
    }

    if (trackCount == 0 && mixer.getNumTracks() > 0)
    {
        livent::alert (livent::vn ("Lưu thất bại"),
            livent::vn ("Dự án có ") + juce::String (mixer.getNumTracks()) + livent::vn (" track nhưng "
            "không dùng được dữ liệu để ghi ra.\n\n"
            "LiveNT đã KHÔNG ghi đè lên file cũ, nên bản cũ của anh vẫn còn "
            "nguyên. Thử bấm Lưu lại lần nữa."),
            juce::MessageBoxIconType::WarningIcon);
        return false;
    }

    // Ghi file tam -> sao luu .bak -> doi ten (xem SafeFile.h)
    if (! SafeFile::writeXml (*xml, file))
        return false;

    /*  ==========  DOC LAI DE KIEM TRA  ==========

        Ghi xong khong co nghia la ghi DUNG. Doc nguoc file vua ghi ra, dem lai
        so track. Khop thi moi bao thanh cong.

        Vi sao can: anh bao "luc luu duoc luc khong". Truoc day LiveNT khong he
        kiem tra lai -- ghi xong la bao livent::vn ("Đã lưu") bat ke ket qua. Nen den luc mo
        ra tren may khac moi phat hien file rong, ma luc do da muon.

        Kiem tra nay ton them mot lan doc file, vai phan tram giay. Doi lai anh
        biet CHAC file vua luu la dung.  */
    {
        auto check = juce::XmlDocument::parse (file);

        if (check == nullptr)
        {
            livent::alert (livent::vn ("Lưu thất bại"),
                livent::vn ("Ghi file xong nhưng đọc lại không được:\n") + file.getFullPathName(),
                juce::MessageBoxIconType::WarningIcon);
            return false;
        }

        int readBack = 0;

        for (auto* e : check->getChildWithTagNameIterator ("TRACK"))
        {
            juce::ignoreUnused (e);
            ++readBack;
        }

        if (readBack != trackCount)
        {
            livent::alert (livent::vn ("Lưu thất bại"),
                livent::vn ("File ghi ra không đầy đủ: đang có ") + juce::String (trackCount)
                    + livent::vn (" track mà đọc lại chỉ thấy ") + juce::String (readBack) + livent::vn (".\n\n"
                    "Bản cũ nằm cạnh nó đuôi đuôi .bak nếu anh cần lấy lại."),
                juce::MessageBoxIconType::WarningIcon);
            return false;
        }
    }

    // Save As keeps this project's approved mix baseline alongside its new name.
    if (currentProjectFile != juce::File() && currentProjectFile != file)
    {
        const auto oldDefault = defaultMixFileFor (currentProjectFile);
        const auto newDefault = defaultMixFileFor (file);
        if (oldDefault.existsAsFile() && ! newDefault.existsAsFile())
            oldDefault.copyFileTo (newDefault);
    }

    saveWindowLayout();
    clearAutosave();

    // Save As: mang theo ca tuy chon/mo cua so rieng cua project cu.
    if (currentProjectFile != juce::File() && currentProjectFile != file)
    {
        const auto oldPref = musicVst2PreferenceFileFor (currentProjectFile);
        const auto newPref = musicVst2PreferenceFileFor (file);
        if (oldPref.existsAsFile() && ! newPref.existsAsFile())
            oldPref.copyFileTo (newPref);
    }

    setCurrentProjectFile (file);
    (void) saveMusicVst2WindowPreference (file);

    // 07/10: take cua phien nay da nam an toan trong file .NT
    mixer.markTimelineProjectSaved();

    /* So sanh tren ban KHONG co state Base64 cua plugin - xem helper o tren. */
    lastSavedStateXml = buildComparableProjectState();
    projectDirty = false;
    updateTitleText();
    return true;
}

juce::File MainComponent::getDefaultMixFile() const
{
    return currentProjectFile == juce::File() ? juce::File()
                                               : defaultMixFileFor (currentProjectFile);
}

void MainComponent::saveDefaultMix (bool allowOverwrite)
{
    if (! projectOpen || currentProjectFile == juce::File())
    {
        livent::alert (livent::vn ("Lưu mặc định"),
                       livent::vn ("Hãy lưu dự án .NT trước để có chỗ lưu thông số mặc định."));
        return;
    }

    if (projectLoadInProgress || pluginLoadInProgress
        || mixer.isTimelineRecording() || mixer.isMasterRecording()
        || timelineExportActive || timelineExportFinishing)
    {
        livent::alert (livent::vn ("Lưu mặc định"),
                       livent::vn ("Hãy chờ nạp VST/xuất âm thanh hoặc dừng thu trước khi lưu mặc định."));
        return;
    }

    if (! allowOverwrite && getDefaultMixFile().existsAsFile())
    {
        const auto projectAtPrompt = currentProjectFile;
        juce::Component::SafePointer<MainComponent> safeThis (this);
        livent::confirm (livent::vn ("Thay mốc mặc định?"),
                         livent::vn ("Dự án này đã có thông số mặc định. "
                                     "Anh có muốn thay mốc đó bằng thông số hiện tại không?"),
                         livent::vn ("Thay mốc"), livent::vn ("Hủy"),
                         [safeThis, projectAtPrompt] (bool yes)
        {
            if (yes && safeThis != nullptr && safeThis->currentProjectFile == projectAtPrompt)
                safeThis->saveDefaultMix (true);
        });
        return;
    }

    // Full VST chunks and parameter recovery use the same tested path as Save.
    // Clip and source audio belong to the live project, never to a mix preset.
    auto xml = buildProjectStateXml (true);
    if (xml == nullptr)
        return;

    if (auto* timeline = xml->getChildByName ("TRACK_TIMELINE"))
        xml->removeChildElement (timeline, true);
    xml->setAttribute ("mixDefaultVersion", 1);

    if (! SafeFile::writeXml (*xml, getDefaultMixFile()))
    {
        livent::alert (livent::vn ("Không lưu được mặc định"),
                       livent::vn ("Không ghi được file thông số mặc định cạnh dự án .NT."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    livent::alert (livent::vn ("Đã lưu mặc định"),
                   livent::vn ("Đã lưu thông số track, routing, send và VST cho dự án này. ")
                   + livent::vn ("Các đoạn thu trên timeline vẫn thuộc project .NT."));
}

void MainComponent::restoreDefaultMix()
{
    if (! projectOpen || ! getDefaultMixFile().existsAsFile())
        return;

    if (projectLoadInProgress || pluginLoadInProgress
        || mixer.isTimelineRecording() || mixer.isMasterRecording()
        || timelineExportActive || timelineExportFinishing)
    {
        livent::alert (livent::vn ("Khôi phục mặc định"),
                       livent::vn ("Hãy chờ nạp VST/xuất âm thanh hoặc dừng thu trước khi khôi phục."));
        return;
    }

    const auto projectAtPrompt = currentProjectFile;
    juce::Component::SafePointer<MainComponent> safeThis (this);
    livent::confirm (livent::vn ("Khôi phục thông số mặc định"),
                     livent::vn ("Đưa các núm, fader, routing, send và VST về mốc đã lưu?\n\n")
                     + livent::vn ("File nhạc và các take trên timeline sẽ được giữ nguyên. "
                                   "Bản mix hiện tại sẽ được sao lưu trước khi khôi phục."),
                     livent::vn ("Khôi phục"), livent::vn ("Hủy"),
                     [safeThis, projectAtPrompt] (bool yes)
    {
        if (! yes || safeThis == nullptr || ! safeThis->projectOpen
            || safeThis->currentProjectFile != projectAtPrompt
            || safeThis->projectLoadInProgress || safeThis->pluginLoadInProgress
            || safeThis->mixer.isTimelineRecording() || safeThis->mixer.isMasterRecording()
            || safeThis->timelineExportActive || safeThis->timelineExportFinishing)
            return;

        auto saved = juce::XmlDocument::parse (safeThis->getDefaultMixFile());
        if (saved == nullptr || ! saved->hasTagName ("LIVENT_PROJECT")
            || saved->getIntAttribute ("mixDefaultVersion") != 1)
        {
            livent::alert (livent::vn ("Không khôi phục được"),
                           livent::vn ("File thông số mặc định bị lỗi hoặc không đúng định dạng."));
            return;
        }

        int count = 0;
        juce::StringArray matchedUuids;
        for (auto* trackXml : saved->getChildWithTagNameIterator ("TRACK"))
        {
            ++count;
            const auto id = trackXml->getIntAttribute ("id", -1);
            const auto uuid = trackXml->getStringAttribute ("uuid");
            auto* track = safeThis->mixer.getTrackByUuid (uuid);
            if (uuid.isEmpty() || matchedUuids.contains (uuid)
                || track == nullptr || track->getId() != id
                || (int) track->getType() != trackXml->getIntAttribute ("type", -1)
                || trackXml->getChildByName ("INSERT") == nullptr)
            {
                livent::alert (livent::vn ("Không khôi phục được"),
                               livent::vn ("Cấu trúc track đã đổi từ khi lưu mặc định. "
                                           "Hãy kiểm tra lại rồi bấm Lưu mặc định lần nữa."));
                return;
            }
            matchedUuids.add (uuid);
        }

        if (count == 0 || count != safeThis->mixer.getNumTracks())
        {
            livent::alert (livent::vn ("Không khôi phục được"),
                           livent::vn ("Số track hiện tại không khớp với bản mặc định."));
            return;
        }

        // Keep a full undo point, including the current timeline, before any
        // insert is replaced. A failed write must not discard the current mix.
        auto before = safeThis->buildProjectStateXml (true);
        const auto backup = projectAtPrompt.getSiblingFile (
                                projectAtPrompt.getFileName() + ".before-restore.NT");
        if (before == nullptr || ! SafeFile::writeXml (*before, backup))
        {
            livent::alert (livent::vn ("Không khôi phục được"),
                           livent::vn ("Chưa sao lưu được bản mix hiện tại nên không thay đổi gì."));
            return;
        }

        if (safeThis->mixer.isTimelinePlaying())
            safeThis->mixer.toggleTimelinePlayback();
        safeThis->autoKeyController.stop();
        safeThis->pluginWindows.closeAll();

        for (auto* trackXml : saved->getChildWithTagNameIterator ("TRACK"))
            if (auto* track = safeThis->mixer.getTrackByUuid (trackXml->getStringAttribute ("uuid")))
                track->restoreMixState (*trackXml, true);

        if (auto* ui = saved->getChildByName ("UI"))
            safeThis->tonePanel.setToneOffsetSilently ((float) ui->getDoubleAttribute ("toneOffset", 0.0));

        safeThis->markProjectDirty();
        safeThis->rebuildTrackList();
        safeThis->mixerView.rebuild();
        safeThis->inspector.refreshFromTrack();
        safeThis->refitInspector();
        safeThis->updateTitleText();
        // Restore each saved VST with the existing async, guarded project
        // loader. This leaves the .NT path and timeline clips untouched.
        safeThis->startProjectPluginLoadQueue (*saved, true);
    });
}

void MainComponent::saveProject()
{
    if (! projectOpen)
    {
        livent::alert (livent::vn ("Chưa có dự án"),
                       livent::vn ("Hãy tạo hoặc mở một dự án trước khi lưu."));
        return;
    }

    // Chua co file nao -> hoi cho luu, giong het Ctrl+S lan dau ben Cubase
    if (currentProjectFile == juce::File())
    {
        saveProjectAs();
        return;
    }

    const bool ok = writeProjectTo (currentProjectFile);

    livent::alert (ok ? livent::vn ("Đã lưu") : livent::vn ("Lưu thất bại"),
        ok ? livent::vn ("Đã lưu vào:\n") + currentProjectFile.getFullPathName()
           : livent::vn ("Không ghi được file:\n") + currentProjectFile.getFullPathName(),
        ok ? juce::MessageBoxIconType::InfoIcon : juce::MessageBoxIconType::WarningIcon);
}

void MainComponent::saveProjectAs()
{
    if (! projectOpen)
    {
        livent::alert (livent::vn ("Chưa có dự án"),
                       livent::vn ("Hãy tạo hoặc mở một dự án trước khi lưu."));
        return;
    }

    auto startFile = currentProjectFile != juce::File()
                       ? currentProjectFile
                       : getDefaultProjectFolder().getChildFile (juce::String ("BuoiDien") + kProjectExtension);

    fileChooser = std::make_unique<juce::FileChooser> (livent::vn ("Lưu dự án LiveNT"),
                                                       startFile, kProjectWildcard);

    fileChooser->launchAsync (juce::FileBrowserComponent::saveMode
                                | juce::FileBrowserComponent::warnAboutOverwriting,
        [this] (const juce::FileChooser& fc)
        {
            auto file = fc.getResult();

            if (file == juce::File())
            {
                // Huy Save As = huy luon hanh dong dang cho (dong/thoat/mo file khac).
                closeProjectAfterSaveAs = false;
                quitAfterSaveAs = false;
                pendingProjectToOpenAfterSaveAs = juce::File();
                return;
            }

            /*  Nguoi dung go "BuoiDien" khong kem duoi -> tu them ".NT".
                Khong lam viec nay thi ra file khong duoi, lan sau tim khong thay. */
            if (! file.hasFileExtension (kProjectExtension))
                file = file.withFileExtension (kProjectExtension);

            if (! writeProjectTo (file))
            {
                closeProjectAfterSaveAs = false;
                quitAfterSaveAs = false;
                pendingProjectToOpenAfterSaveAs = juce::File();
                livent::alert (livent::vn ("Lưu thất bại"),
                    livent::vn ("Không ghi được file:\n") + file.getFullPathName(),
                    juce::MessageBoxIconType::WarningIcon);
                return;
            }

            if (pendingProjectToOpenAfterSaveAs.existsAsFile())
            {
                auto next = pendingProjectToOpenAfterSaveAs;
                pendingProjectToOpenAfterSaveAs = juce::File();
                loadProjectFrom (next);
                return;
            }

            if (closeProjectAfterSaveAs)
            {
                closeProjectAfterSaveAs = false;
                closeProjectNow();
                return;
            }

            if (quitAfterSaveAs)
            {
                quitAfterSaveAs = false;
                closeForReal();
            }
        });
}

//=============================================================================
//  MOC 57: HOI LUU LUC DONG APP
//=============================================================================
void MainComponent::showActivationDialog()
{
    /*  MOC 64: mo bang kich hoat THU CONG giua chung, khac voi luc khoi
        dong (ActivationDialog o Main.cpp) - luc do app CHUA co cua so nao
        nen phai tu quan ly DocumentWindow. O day app DA dang chay, nen
        dung DialogWindow::LaunchOptions nhu moi hop thoai khac cho gon
        (xem ScanDialog::openPathEditor lam mau).

        Bam KICH HOAT / DUNG THU / Thoat trong bang nay deu chi can DONG
        cua so lai - khong lam gi voi app (app dang chay roi, khong phai
        luc khoi dong). Dung shared_ptr lam "o chua" con tro cua so, vi
        callback duoc goi TU BEN TRONG dialog (dang o giua ham xu ly nut
        cua chinh no) nen phai hoan sang nhip sau moi xoa, giong het cach
        Main.cpp lam voi activationWindow.  */
    auto windowCell = std::make_shared<juce::Component::SafePointer<juce::DialogWindow>> ();

    auto* dialog = new ActivationDialog ([windowCell] (bool)
    {
        juce::MessageManager::callAsync ([windowCell]
        {
            if (auto* w = windowCell->getComponent())
                delete w;
        });
    });

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (dialog);
    o.dialogTitle = livent::vn ("Nhập key kích hoạt");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = false;

    auto* window = livent::launchDialog (o);
    *windowCell = window;

    livent::bringDialogToFront (window);
}

void MainComponent::confirmCloseAndQuit()
{
    if (! hasUnsavedChanges())
    {
        closeForReal();
        return;
    }

    livent::confirm3 (livent::vn ("Dự án chưa được lưu"),
                      livent::vn ("Những thay đổi trong dự án sẽ mất nếu thoát mà không lưu."),
                      livent::vn ("Lưu rồi thoát"), livent::vn ("Không lưu và thoát"), livent::vn ("Hủy"),
        [this] (int choice)
        {
            if (choice == 0)
                return;

            if (choice == 2) // thoat khong luu
            {
                closeForReal();
                return;
            }

            if (currentProjectFile == juce::File())
            {
                quitAfterSaveAs = true;
                saveProjectAs();
                return;
            }

            if (writeProjectTo (currentProjectFile))
                closeForReal();
        });
}

//=============================================================================
// Dong DU AN nhung giu ung dung/ASIO/plugin database song - giong Cubase.
void MainComponent::closeProject()
{
    if(mixer.isBackgroundWorkActive()){livent::alert(livent::vn("Đang xử lý"),livent::vn("Chờ render / đóng gói xong trước khi đóng dự án."));return;}
    if (pluginLoadInProgress)
    {
        livent::alert (livent::vn ("Đang nạp VST"),
                       livent::vn ("Hãy chờ plugin đang nạp xong rồi đổi/đóng dự án. "
                                  "LiveNT chỉ nạp một VST tại một thời điểm để tránh chồng luồng."));
        return;
    }

    if (! projectOpen)
        return;

    if(!mixer.waitForPendingTakes())
    {
        livent::alert(livent::vn("Bản thu đang chốt"),livent::vn("Chờ WAV hoàn tất rồi đóng dự án lại. Dự án hiện tại được giữ nguyên."));return;
    }

    if (! hasUnsavedChanges())
    {
        closeProjectNow();
        return;
    }

    livent::confirm3 (livent::vn ("Đóng dự án"),
                      livent::vn ("Dự án có thay đổi chưa lưu."),
                      livent::vn ("Lưu và đóng"), livent::vn ("Đóng không lưu"), livent::vn ("Hủy"),
        [this] (int choice)
        {
            if (choice == 0)
                return;

            if (choice == 2)
            {
                closeProjectNow();
                return;
            }

            if (currentProjectFile == juce::File())
            {
                closeProjectAfterSaveAs = true;
                saveProjectAs();
                return;
            }

            if (writeProjectTo (currentProjectFile))
                closeProjectNow();
        });
}

void MainComponent::closeProjectNow()
{
    if(mixer.isMasterRecording() || mixer.isTimelineRecording() || !mixer.waitForPendingTakes())
    {livent::alert(livent::vn("Bản thu chưa hoàn tất"),livent::vn("Dừng thu và chờ WAV chốt xong trước khi đổi/đóng dự án hoặc nhân đôi track."));return ;}

    if(mixer.isBackgroundWorkActive())return;
    if (timelineExportActive || timelineExportFinishing) return;
    tonePanel.closeLaughPanel();
    if (videoController != nullptr)
        videoController->close();   // 07/10 _D
    (void) saveMusicVst2WindowPreference (currentProjectFile);
    autoKeyController.stop();
    pluginWindows.closeAll();
    inspector.setTrack (nullptr); closeChannelOverview();

    if (auto* music = mixer.getTrackByRole (Track::Role::Music))
        pluginWindows.clearPlacement (
            PluginWindowManager::makeKey (music->getId(), kMusicVst2Slot));

    // F2/F3 la cua so lam viec cua DU AN, nen dong theo du an.
    if (workWindow != nullptr)
        closeWorkWindow();

    mixer.clearProjectTracks();
    setCurrentProjectFile (juce::File());
    projectOpen = false;
    projectDirty = false;
    autoOpenMusicVst2 = false;
    lastSavedStateXml.clear();
    closeProjectAfterSaveAs = false;
    clearAutosave();   // V6.4.6: dong project sach -> khong de recovery cu bao nham lan sau

    rebuildTrackList();
    mixerView.rebuild();
    refreshProjectHub();
    updateProjectUiState();
    updateTitleText();
    resized();
}

void MainComponent::closeForReal()
{
    // V6.6.3: app nao LiveNT tu mo thi gui dong NGAY khi LiveNT bat dau thoat.
    stopCompanionApp (true);
    youtube.close (true);   // cho YouTube tu luu dang nhap/vi tri roi thoat

    if (projectOpen)
        (void) saveMusicVst2WindowPreference (currentProjectFile);

    /* HOTFIX17: tu day la THOAT HAN process, khong phai dong project.
       Bao cac PluginChain bo qua teardown native VST co nguy co treo vo han,
       va bo quyen so huu cua so editor thay vi delete editor cua plugin. */
    PluginChain::beginProcessShutdown();
    pluginWindows.abandonAllForProcessShutdown();

    projectLoadCancelRequested = true;
    ++projectLoadGeneration;

   #if JUCE_WINDOWS
    /* Lop cuoi cung: neu driver/audio callback/VST ben thu ba mac VO HAN trong
       shutdown thi sau 8 giay ket thuc process cuong buc. Chi duoc arm SAU
       khi nguoi dung da chon thoat (va neu can da luu project), nen khong
       cat ngang hop thoai Luu/Huy. Binh thuong process tat truoc 8 giay thi
       thread nay tu bien mat cung process va khong lam gi. */
    std::thread ([]
    {
        ::Sleep (8000);
        ::TerminateProcess (::GetCurrentProcess(), 0);
    }).detach();
   #endif

    /*  MOC 57: bao NGAY cho anh biet dang dong.

        Don dep phia sau (tra tung plugin ra bo nho an toan qua duong SEH,
        dong card am thanh...) co the mat vai giay THAT SU, nhat la khi tai
        nhieu VST - dung nhu anh mo ta "tat phai doi 3 giay". Khong bao thi
        nhin y het app dong bang hay sap.

        Dung lai chinh man hinh khoi dong (Splash) cho viec nay - no da co
        san vong xoay + tu dong an sau vai giay, khong can viet them gi.  */
    Splash::show();
    Splash::setStatus (livent::vn ("Đang đóng LiveNT..."));

    /*  MOC 70 FIX: gop y tu 1 phien lam viec khac - "Windows dung do nhu
        loi" luc dong, trong khi Mac thi muot.

        Nguyen nhan: cua so chinh (MainWindow chua MainComponent nay) truoc
        gio KHONG HE bi an di luc dong - trong luc dang don dep (block luong
        giao dien vai giay that su, xem chu thich tren), no VAN DUNG YEN,
        KHONG con phan hoi. Windows xu ly cua so "khong phan hoi" rat lo
        lieu (vien xam, chu "(Khong phan hoi)" tren thanh tieu de) - macOS
        it lo hon (chi con quay vong tron, cua so van giu nguyen hinh cuoi).
        Ket qua: tren cung 1 co che, Windows nhin "nhu loi", macOS nhin
        "muot", du code xu ly giong het nhau ca hai ben.

        Cach chua: AN HAN cua so chinh di NGAY luc bat dau dong - chi con
        Splash hien tren man hinh trong luc don dep, khong con cua so chinh
        dung yen o do de Windows danh dau "khong phan hoi" nua.  */
    if (auto* top = getTopLevelComponent())
        top->setVisible (false);

    /*  Doi 1 nhip de Splash kip ve len man hinh TRUOC khi luong chinh bi
        chan boi qua trinh dong (releaseResources cua hang chuc plugin cong
        lai co the chiem het thoi gian cua luong giao dien).  */
    juce::Timer::callAfterDelay (30, []
    {
        juce::JUCEApplication::getInstance()->systemRequestedQuit();
    });
}

//=============================================================================
void MainComponent::openProjectDialog()
{
    auto startFolder = currentProjectFile != juce::File()
                         ? currentProjectFile.getParentDirectory()
                         : getDefaultProjectFolder();

    fileChooser = std::make_unique<juce::FileChooser> (livent::vn ("Mở dự án LiveNT"),
                                                       startFolder, kProjectWildcard);

    fileChooser->launchAsync (juce::FileBrowserComponent::openMode
                                | juce::FileBrowserComponent::canSelectFiles,
        [this] (const juce::FileChooser& fc)
        {
            auto file = fc.getResult();

            if (file.existsAsFile())
                requestOpenProject (file);
        });
}

//=============================================================================
//  MOC 21: gop Moi / Luu / Luu thanh.../ Mo... / Mo gan day vao MOT nut File.
//=============================================================================

//=============================================================================
void MainComponent::newProject()
{
    if(mixer.isMasterRecording() || mixer.isTimelineRecording() || !mixer.waitForPendingTakes())
    {livent::alert(livent::vn("Bản thu chưa hoàn tất"),livent::vn("Dừng thu và chờ WAV chốt xong trước khi đổi/đóng dự án hoặc nhân đôi track."));return ;}

    if(mixer.isBackgroundWorkActive()){livent::alert(livent::vn("Đang xử lý"),livent::vn("Chờ render / đóng gói xong trước khi tạo dự án khác."));return;}
    if (pluginLoadInProgress)
    {
        livent::alert (livent::vn ("Đang nạp VST"),
                       livent::vn ("Hãy chờ plugin đang nạp xong rồi đổi/đóng dự án. "
                                  "LiveNT chỉ nạp một VST tại một thời điểm để tránh chồng luồng."));
        return;
    }

    juce::Component::SafePointer<MainComponent> safe (this);

    auto createNow = [safe]
    {
        if (safe == nullptr)
            return;

        if (safe->projectOpen)
            (void) safe->saveMusicVst2WindowPreference (safe->currentProjectFile);
        safe->autoKeyController.stop();
        safe->pluginWindows.closeAll();
        safe->inspector.setTrack (nullptr); safe->closeChannelOverview();
        safe->clearAutosave();   // V6.4.6: khong de recovery cua project cu sot lai

        if (safe->workWindow != nullptr)
            safe->closeWorkWindow();

        // FIX: xoa vi tri VST o 2 NHAC cua project cu (xem loadProjectFrom).
        if (auto* oldMusic = safe->mixer.getTrackByRole (Track::Role::Music))
            safe->pluginWindows.clearPlacement (
                PluginWindowManager::makeKey (oldMusic->getId(), kMusicVst2Slot));

        safe->mixer.resetToDefaultTracks();
        if (auto* music = safe->mixer.getTrackByRole (Track::Role::Music))
            safe->pluginWindows.clearPlacement (
                PluginWindowManager::makeKey (music->getId(), kMusicVst2Slot));

        // 01/10: du an moi lay cach gan "mac dinh cua may" (neu co), khop theo ten track.
        safe->tonePanel.getButtonMap().loadMachineDefault();
        livent::buttonmap::rebindByName (safe->tonePanel.getButtonMap(), safe->mixer);
        safe->tonePanel.buttonMapChanged();

        // 02/10: du an moi co san bo preset (mac dinh cua may / file trong bo cai).
        safe->tonePanel.getPresetBank().loadFallback();
        safe->tonePanel.presetsReloaded();

        safe->projectOpen = true;
        safe->projectDirty = false;
        safe->autoOpenMusicVst2 = false;

        // Project moi dung preference giao dien cua may. Project da luu se
        // co thuoc tinh rieng trong <UI>.
        safe->verticalControlLayout = loadVerticalLayoutPref();
        safe->tonePanel.setVerticalLayout (safe->verticalControlLayout, false);

        /*  MOC 96: moi project deu bat dau o che do KHOA: cua so chinh chi
            con Bang dieu khien. Muon gan/sua VST phai F2 + mat khau. */
        safe->inspectorVisible = false;
        safe->trackListVisible = false;
        safe->mixerVisible = false;

        safe->setCurrentProjectFile (juce::File());
        safe->rebuildTrackList();
        safe->selectTrack (0);
        safe->lastSavedStateXml = safe->buildComparableProjectState();
        safe->applyPanelVisibility();
        safe->updateProjectUiState();
        safe->compactControlPanelWindow();
        safe->updateTitleText();
        safe->writeRecoveryCheckpoint(); // project moi cung co phao cuu ngay tu dau
    };

    /*  Dang o Hub thi "Tao du an" khong co gi de mat, nen khong hoi mot cau
        vo nghia "bo het track hien tai?". Bam la vao thang project moi. */
    if (! projectOpen)
    {
        createNow();
        return;
    }

    juce::AlertWindow::showAsync (
        juce::MessageBoxOptions()
            .withIconType (juce::MessageBoxIconType::QuestionIcon)
            .withTitle (livent::vn ("Dự án mới"))
            .withMessage (livent::vn ("Bỏ dự án hiện tại và bắt đầu một dự án mới?\n"
                                      "Những gì chưa lưu sẽ mất."))
            .withButton (livent::vn ("Tạo mới"))
            .withButton (livent::vn ("Thôi"))
            .withAssociatedComponent (livent::dialogOwner()),
        [createNow] (int result)
        {
            if (result == 1)
                createNow();
        });
}

//=============================================================================
//  06/10: MAN TAO / MO DU AN - tao theo mau
//=============================================================================
juce::File MainComponent::getMachineTemplateFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("project-template.NT");
}

void MainComponent::saveProjectAsMachineTemplate()
{
    if (! projectOpen)
        return;

    if (projectLoadInProgress || pluginLoadInProgress)
    {
        livent::alert (livent::vn ("Lưu mẫu"),
                       livent::vn ("Hãy chờ nạp VST xong rồi mới lưu mẫu (đang nạp thì thông số VST chưa đủ)."));
        return;
    }

    juce::Component::SafePointer<MainComponent> safe (this);
    auto doSave = [safe]
    {
        if (safe == nullptr) return;
        auto xml = safe->buildProjectStateXml (true);
        if (xml == nullptr) return;

        // Mau khong mang theo clip thu am / timeline cua buoi dien nay
        while (auto* tl = xml->getChildByName ("TRACK_TIMELINE"))
            xml->removeChildElement (tl, true);

        const bool ok = SafeFile::writeXml (*xml, getMachineTemplateFile());
        livent::alert (livent::vn ("Lưu mẫu máy này"),
                       ok ? livent::vn ("Đã lưu. Lần sau ở màn Tạo dự án chọn \"Từ mẫu máy này\" là có sẵn "
                                        "toàn bộ track / VST / vang / nút / preset như dự án này.")
                          : livent::vn ("Không ghi được file mẫu."),
                       ok ? juce::MessageBoxIconType::InfoIcon : juce::MessageBoxIconType::WarningIcon);
    };

    if (! getMachineTemplateFile().existsAsFile())
    {
        doSave();
        return;
    }

    livent::confirm (livent::vn ("Thay mẫu máy này?"),
                     livent::vn ("Máy này đã có mẫu dự án. Thay bằng dự án đang mở?"),
                     livent::vn ("Thay mẫu"), livent::vn ("Hủy"),
                     [doSave] (bool yes) { if (yes) doSave(); });
}

void MainComponent::createProjectFromHub (ProjectHub::Template kind,
                                          const juce::String& name, const juce::File& folder)
{
    if (pluginLoadInProgress || projectLoadInProgress)
    {
        livent::alert (livent::vn ("Đang nạp VST"),
                       livent::vn ("Hãy chờ nạp xong rồi tạo dự án mới."));
        return;
    }

    juce::File target;
    if (name.isNotEmpty())
    {
        folder.createDirectory();
        target = folder.getChildFile (name + kProjectExtension);
        if (target.exists())
            target = target.getNonexistentSibling (true);   // khong bao gio ghi de du an cu
    }

    //-- Tu mau cua may: chep file mau roi mo nhu mot du an binh thuong ---------
    if (kind == ProjectHub::Template::machine)
    {
        const auto tpl = getMachineTemplateFile();
        if (! tpl.existsAsFile())
        {
            livent::alert (livent::vn ("Mẫu của máy này"), livent::vn ("Chưa có mẫu - dùng mẫu Hát live cơ bản."));
            kind = ProjectHub::Template::basic;
        }
        else if (target != juce::File())
        {
            if (! tpl.copyFileTo (target))
            {
                livent::alert (livent::vn ("Tạo dự án"),
                               livent::vn ("Không ghi được file:\n") + target.getFullPathName(),
                               juce::MessageBoxIconType::WarningIcon);
                return;
            }
            loadProjectFrom (target);
            return;
        }
        else
        {
            // Chua dat ten: nap mau roi tach khoi file mau (Luu se hoi ten).
            if (loadProjectFrom (tpl))
            {
                recentFiles.removeFile (tpl);
                saveRecentList();
                setCurrentProjectFile (juce::File());
            }
            return;
        }
    }

    //-- Co ban / Song ca / Trong ---------------------------------------------
    newProject();      // dang o man Hub -> tao ngay, khong hoi
    if (! projectOpen)
        return;

    if (kind == ProjectHub::Template::duet)
    {
        if (auto* mic = mixer.getTrackByRole (Track::Role::Mic))
        {
            const int before = mixer.getNumTracks();
            duplicateTrack (mic);
            if (mixer.getNumTracks() > before)
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                    if (auto* t = mixer.getTrack (i))
                        if (t != mic && t->getType() == mic->getType()
                            && t->getName() == mic->getName() + " 2")
                        {
                            t->setName (livent::vn ("MÍC 2"));
                            break;
                        }
            rebuildTrackList();
        }
    }
    else if (kind == ProjectHub::Template::empty)
    {
        tonePanel.getButtonMap().clear();
        tonePanel.buttonMapChanged();
        tonePanel.getPresetBank().resetNames();
        tonePanel.presetsReloaded();
    }

    if (target != juce::File() && ! writeProjectTo (target))
        livent::alert (livent::vn ("Tạo dự án"),
                       livent::vn ("Đã tạo dự án nhưng chưa ghi được file:\n") + target.getFullPathName()
                       + livent::vn ("\n\nBấm Lưu (Ctrl+S) để chọn chỗ khác."),
                       juce::MessageBoxIconType::WarningIcon);

    lastSavedStateXml = buildComparableProjectState();
    projectDirty = false;
    updateTitleText();
}

//=============================================================================
void MainComponent::loadProject()
{
    /*  Mo lai file .NT lan truoc dang lam. Khong co thi thu file project.xml
        cua ban cu (Moc 5-6) de anh khong mat cong dung lai tu dau.  */
    if (recentFiles.getNumFiles() > 0)
    {
        auto last = recentFiles.getFile (0);

        if (last.existsAsFile() && loadProjectFrom (last))
            return;
    }

    auto legacy = PluginChain::getSettingsFolder().getChildFile ("project.xml");

    if (legacy.existsAsFile())
        loadProjectFrom (legacy);
}

bool MainComponent::loadProjectFrom (const juce::File& file)
{
    if(mixer.isMasterRecording() || mixer.isTimelineRecording() || !mixer.waitForPendingTakes())
    {livent::alert(livent::vn("Bản thu chưa hoàn tất"),livent::vn("Dừng thu và chờ WAV chốt xong trước khi đổi/đóng dự án hoặc nhân đôi track."));return false;}

    if(mixer.isBackgroundWorkActive()){livent::alert(livent::vn("Đang xử lý"),livent::vn("Chờ render / đóng gói xong trước khi mở dự án khác."));return false;}
    if (! file.existsAsFile())
        return false;

    auto xml = juce::XmlDocument::parse (file);

    bool recoveredFromBackup = false;
    auto validationError = xml != nullptr ? livent::project::validate (*xml)
                                         : juce::String ("Khong doc duoc XML.");
    if (validationError.isNotEmpty())
    {
        /*  File hong (mat dien giua luc ghi o ban cu). Thu ban sao luu. */
        auto bak = file.getSiblingFile (file.getFileName() + ".bak");

        if (bak.existsAsFile())
            xml = juce::XmlDocument::parse (bak);

        validationError = xml != nullptr ? livent::project::validate (*xml)
                                        : juce::String ("Khong doc duoc XML.");
        if (validationError.isNotEmpty())
        {
            livent::alert (livent::vn ("Không đọc được file"),
                livent::vn ("File này không phải dự án LiveNT, hoặc đã hỏng:\n")
                    + file.getFullPathName() + "\n\n" + validationError,
                juce::MessageBoxIconType::WarningIcon);
            return false;
        }
        recoveredFromBackup = true;
    }

    livent::portable::resolveMedia(*xml,file);

    if (projectOpen)
        (void) saveMusicVst2WindowPreference (currentProjectFile);
    autoKeyController.stop();
    pluginWindows.closeAll();
    if (videoController != nullptr)
        videoController->close();   // 07/10 _D: video cua du an cu

    /*  MOC 96: doi project = khoa lai khu VST. Khong de F2 cua project cu
        tiep tuc mo tren project moi. */
    if (workWindow != nullptr)
        closeWorkWindow();

    inspector.setTrack (nullptr); closeChannelOverview();      // xem ghi chu o removeSelectedTrack()
    /*  Dem track TRONG FILE truoc khi nap. File hong hoac file cua ban khac
        co the doc duoc XML ma khong co track nao -- luc do man hinh len trang
        tron, va nguoi dung khong hieu chuyen gi.  */
    int tracksInFile = 0;

    for (auto* e : xml->getChildWithTagNameIterator ("TRACK"))
    {
        juce::ignoreUnused (e);
        ++tracksInFile;
    }

    if (tracksInFile == 0)
    {
        livent::alert (livent::vn ("File dự án rỗng"),
            livent::vn ("Đọc được file nhưng bên trong không có track nào:\n")
                + file.getFullPathName() + livent::vn ("\n\n"
                "File có thể đã bị ghi hỏng. Thử tìm file cùng tên có đuôi "
                ".bak nằm cạnh nó -- đó là bản lưu trước đó."),
            juce::MessageBoxIconType::WarningIcon);
        return false;
    }

    // FIX: xoa vi tri cua so VST o 2 cua track NHAC thuoc project CU truoc khi
    // doi track. Neu khong, project moi co track khac trung ID (vd track hat
    // id 3) se mo VST o 2 dung vi tri/kich thuoc cua NHAC project cu.
    if (auto* oldMusic = mixer.getTrackByRole (Track::Role::Music))
        pluginWindows.clearPlacement (
            PluginWindowManager::makeKey (oldMusic->getId(), kMusicVst2Slot));

    if (! mixer.setState (*xml, true))
    {
        rebuildTrackList();
        livent::alert (livent::vn ("Không mở được dự án"),
                       livent::vn ("Không dựng được trạng thái mới. Dữ liệu project đang làm được giữ nguyên."),
                       juce::MessageBoxIconType::WarningIcon);
        return false;
    }
    projectOpen = true;
    projectDirty = false;
    autoOpenMusicVst2 = false;

    // 01/10: cach gan nut cua du an (khong co = nhu cu).
    tonePanel.getButtonMap().fromXml (xml->getChildByName ("BUTTON_MAP"));
    tonePanel.buttonMapChanged();

    // 02/10: preset cua du an; du an chua co -> mac dinh cua may / bo cai.
    if (! tonePanel.getPresetBank().fromXml (xml->getChildByName ("PRESETS")))
        tonePanel.getPresetBank().loadFallback();
    tonePanel.presetsReloaded();

    // The role track can have the same numeric ID in two projects. Only a
    // project that actually saved its own bounds may restore editor size.
    if (auto* music = mixer.getTrackByRole (Track::Role::Music))
        pluginWindows.clearPlacement (
            PluginWindowManager::makeKey (music->getId(), kMusicVst2Slot));

    /*  MOC 96: project da duoc nap, nhung khu gan VST van KHOA cho toi khi
        nguoi dung bam F2 va nhap mat khau. */
    inspectorVisible = false;
    trackListVisible = false;
    mixerVisible = false;

    /*  Doc lai trang thai giao dien TRUOC khi dung danh sach track, vi
        rebuildTrackList() se dung hai co thu muc de xep cho. File project
        rat cu co the chua co <UI>, nen khoi tao tu preference cua may truoc. */
    verticalControlLayout = loadVerticalLayoutPref();
    tonePanel.setVerticalLayout (verticalControlLayout, false);

    if (auto* ui = xml->getChildByName ("UI"))
    {
        autoOpenMusicVst2 = ui->getIntAttribute ("autoOpenMusicVst2", 0) != 0;
        if (auto* music = mixer.getTrackByRole (Track::Role::Music))
            if (ui->hasAttribute ("musicVst2X") && ui->hasAttribute ("musicVst2Y")
                && ui->hasAttribute ("musicVst2W") && ui->hasAttribute ("musicVst2H"))
                pluginWindows.setPlacement (
                    PluginWindowManager::makeKey (music->getId(), kMusicVst2Slot),
                    { ui->getIntAttribute ("musicVst2X"),
                      ui->getIntAttribute ("musicVst2Y"),
                      ui->getIntAttribute ("musicVst2W"),
                      ui->getIntAttribute ("musicVst2H") },
                    ui->getIntAttribute ("musicVst2Pin", 1) != 0);
        fxFolderOpen  = ui->getIntAttribute ("fxFolderOpen",  1) != 0;
        outFolderOpen = ui->getIntAttribute ("outFolderOpen", 1) != 0;

        tonePanel.setPanelOpen (ui->getIntAttribute ("tonePanelOpen", 1) != 0);

        // V0.6.7.9: bo cuc Ngang/Doc theo lua chon cua MAY (nut Ngang/Doc tren
        // thanh tren), khong lay theo file du an - mo du an cu khong bi doi.
        verticalControlLayout = loadVerticalLayoutPref();
        tonePanel.setVerticalLayout (verticalControlLayout, false);

        pendingToneTrackId = ui->getIntAttribute ("toneTrackId", -1);
        //  Mac dinh 1: tu bat link BAT san, dung nhu anh muon
        pendingToneAutoWatch = ui->getIntAttribute ("toneAutoWatch", 1) != 0;

        tonePanel.setLinkRowOpen (ui->getIntAttribute ("toneLinkRow", 0) != 0);
        tonePanel.setKnobsExpanded (ui->getIntAttribute ("knobsExpanded", 1) != 0, false);
        pendingMixerDetached = false;   // MOC 95: bo khoi phuc F3 tach rieng tu project cu

        /*  ==========  MOC 74: AN/HIEN BANG INSERT-SEND  ==========

            Thu tu uu tien co y: che do khoi dong thang gia tri luu trong
            file .NT.

            Anh chon "Luon an" nghia la anh muon no an, cham het -- mo mot du
            an cu (luu tu hoi con hien) ma no lai bung ra thi lua chon do coi
            nhu vo nghia. Chon "Nho theo tung du an" thi moi dung file .NT.  */
        {
            /*  MOC 96: khong khoi phuc trang thai "dang mo khu VST" tu file.
                Day la quyen truy cap cua PHIEN LAM VIEC, khong phai noi dung
                ban nhac. Moi project mo ra deu chi co Bang dieu khien. */
            inspectorVisible = false;
            trackListVisible = false;
            mixerVisible = false;

            /* MOC 96: khong con che do tu bung F2 theo project/startup.
               Moi project deu khoa o Bang dieu khien; F2 phai nhap mat khau. */
        }

        /*  MOC 37: dat con so, KHONG ghi xuong plugin.

            Trang thai cua plugin dich giong tren track NHAC da duoc khoi
            phuc tu chinh file .NT nay roi (PluginChain luu ca chunk cua
            plugin). Ghi de them mot lan nua o day la de len dung cai vua
            khoi phuc -- va neu plugin chua nap xong thi ghi vao khoang
            khong.  */
        tonePanel.setToneOffsetSilently ((float) ui->getDoubleAttribute ("toneOffset", 0.0));

        //  MOC 48: be ngang bang Inspector
        inspectorWidth   = ui->getIntAttribute ("inspectorWidth",   inspectorWidth);
        trackControlsWidth = juce::jlimit (TrackRow::minControlsWidth, 520, ui->getIntAttribute ("trackControlsWidth", workspace::trackWidth));
        if (ui->getIntAttribute ("f2LayoutRevision", 0) < 1)
        {
            inspectorWidth = workspace::inspectorWidth;
            trackControlsWidth = workspace::trackWidth;
        }
        TrackRow::setControlsWidth (trackControlsWidth);

        fxFolderOpen  = ui->getIntAttribute ("fxFolderOpen",  1) != 0;
        outFolderOpen = ui->getIntAttribute ("outFolderOpen", 1) != 0;

        inspector.setSectionOpen (0, ui->getIntAttribute ("secRouting", 1) != 0);
        inspector.setSectionOpen (1, ui->getIntAttribute ("secInserts", 1) != 0);
        inspector.setSectionOpen (2, ui->getIntAttribute ("secSends",   1) != 0);
        inspector.setSectionOpen (3, ui->getIntAttribute ("secLevel",   1) != 0);
        inspector.setSectionOpen(4,ui->getBoolAttribute("secEq",false));

        /*  Doc bang co. Du an cu (Moc 26a) con ghi "hwOutPair" la mot chi so
            don -- doi sang bang co cho khoi mat cai anh da chon.  */
        if (ui->hasAttribute ("hwOutMask"))
        {
            mixer.setHardwareOutMask ((juce::uint32) ui->getIntAttribute ("hwOutMask", 1));
        }
        else
        {
            const int oldPair = ui->getIntAttribute ("hwOutPair", 0);
            mixer.setHardwareOutMask (1u << juce::jlimit (0, 31, oldPair / 2));
        }

        /*  MOC 96: khong con khoi phuc kich thuoc/vi tri cua SO UNG DUNG
            tu file .NT. Cua so LiveNT la thiet lap cua MAY/UNG DUNG, con
            project chi la tai lieu. Thuoc tinh winState cu van co the nam
            trong file de tuong thich nguoc, nhung ban moi bo qua no. */
    }

    if (file != getAutosaveFile())
        loadMusicVst2WindowPreference (file);

    rebuildTrackList();
    selectTrack (0);

    /*  Khong tu mo lai TAT CA cua so VST tu lan luu truoc. Rieng o NHAC/VST 2
        duoc mo sau khi queue nap xong neu chu project da bat tuy chon rieng. */
    pluginWindows.clearKeysToReopen();

    /*  Dat SAU rebuildTrackList: luc do o chon track moi co day du ten track
        de chon dung cai anh da luu.  */
    if (pendingToneTrackId >= 0)
    {
        tonePanel.setTargetTrackId (pendingToneTrackId);
        pendingToneTrackId = -1;
    }

    tonePanel.setAutoWatchOn (pendingToneAutoWatch);

    //  Dat lai ve MAC DINH BAT, khong phai ve false -- xem ghi chu o header
    pendingToneAutoWatch = true;

    /*  MOC 74: doan tu tach bang Do Tone ra cua so rieng da bi bo han -
        bang luon dock canh man hinh, khong con cua so rieng nao.  */

    //  MOC 95: F3 khong con duoc khoi phuc thanh cua so rieng.
    pendingMixerDetached = false;

    // File tu dong luu khong duoc coi la "file dang mo"
    if (file != getAutosaveFile())
        setCurrentProjectFile (file);

    currentProjectPortable=xml->getBoolAttribute("portable",false) && file!=getAutosaveFile();

    /* HOTFIX10: CHUA chup lastSavedStateXml o day. Luc nay track/routing da
       dung xong nhung VST moi chi la o giu cho. Chi sau plugin CUOI CUNG
       (hoac sau khi nguoi dung huy hang doi) moi dong moc so sanh, neu khong
       hasUnsavedChanges() se so mot project dang nap do dang voi file day du. */
    projectDirty = (file == getAutosaveFile());
    lastSavedStateXml.clear();
    updateTitleText();

    updateProjectUiState();
    applyPanelVisibility();
    compactControlPanelWindow();

    /* Dung UI truoc, roi moi nạp VST tung cai. startProjectPluginLoadQueue()
       clone cac the PLUGIN nen XML cuc bo o ham nay co the huy ngay sau khi
       tra ve. */
    startProjectPluginLoadQueue (*xml, file == getAutosaveFile());
    if (recoveredFromBackup)
        livent::alert (livent::vn ("Đã mở bản sao lưu"),
                       livent::vn ("Project gốc không hợp lệ. LiveNT đã mở bản lưu trước (.bak). Hãy kiểm tra nội dung trước khi lưu lại."),
                       juce::MessageBoxIconType::WarningIcon);
    juce::StringArray missingAudio;
    for(const auto& lane:mixer.getTimelineState())for(const auto& clip:lane.clips)
        if(clip&&clip->missingMedia)missingAudio.addIfNotAlreadyThere(clip->file.getFullPathName());
    if(!missingAudio.isEmpty())
    {
        // 14/10: them nut "Xoa cac doan thieu" - bo het doan do mot lan, khoi chuot phai tung cai.
        juce::Component::SafePointer<MainComponent> safeMissing (this);
        livent::confirm (livent::vn ("Dự án thiếu audio"),
                         juce::String (missingAudio.size())
                             + livent::vn (" file chưa đọc được. Các đoạn và thông số vẫn được giữ nguyên. Trong F2, chuột phải vào đoạn màu đỏ → Tìm lại file audio.\n"
                                           "Không cần nữa thì bấm \"Xóa các đoạn thiếu\" (Ctrl+Z lấy lại được).\n\n")
                             + missingAudio.joinIntoString ("\n"),
                         livent::vn ("Xóa các đoạn thiếu"), livent::vn ("Để sau"),
                         [safeMissing] (bool removeThem)
                         {
                             if (removeThem && safeMissing != nullptr)
                                 safeMissing->removeMissingTimelineClips();
                         });
    }

    // 07/10: lan truoc app tat dot ngot luc dang thu -> hoi khoi phuc take
    if (file != getAutosaveFile())
        juce::Timer::callAfterDelay (900, [safeThis = juce::Component::SafePointer<MainComponent> (this)]
        {
            if (safeThis != nullptr)
                safeThis->checkInterruptedTakes();
        });

    return true;
}

//=============================================================================
// HOTFIX10 - Project Loader kieu Cubase: track/routing dung truoc, VST nap sau.
//=============================================================================
void MainComponent::startProjectPluginLoadQueue (const juce::XmlElement& projectXml,
                                                 bool fromRecovery)
{
    ++projectLoadGeneration;
    projectPluginLoadJobs.clear();
    projectPluginLoadFailures.clear();
    projectPluginLoadIndex = 0;
    projectPluginLoadDone = 0;
    projectLoadCancelRequested = false;
    projectPluginWorkerActive = false;
    projectLoadFromRecovery = fromRecovery;
    pendingProjectAfterLoadCancel = juce::File();

    for (auto* trackXml : projectXml.getChildWithTagNameIterator ("TRACK"))
    {
        const int trackId = trackXml->getIntAttribute ("id", -1);
        auto* insertXml = trackXml->getChildByName ("INSERT");
        if (insertXml == nullptr)
            continue;

        for (auto* pluginXml : insertXml->getChildWithTagNameIterator ("PLUGIN"))
        {
            ProjectPluginLoadJob job;
            job.trackId = trackId;
            job.pluginXml = std::make_unique<juce::XmlElement> (*pluginXml);

            if (auto* descXml = pluginXml->getFirstChildElement())
            {
                juce::PluginDescription d;
                if (d.loadFromXml (*descXml))
                    job.name = d.name;
            }

            if (job.name.isEmpty())
                job.name = livent::vn ("Plugin không rõ tên");

            projectPluginLoadJobs.push_back (std::move (job));
        }
    }

    if (projectPluginLoadJobs.empty())
    {
        finishProjectPluginLoadQueue (false);
        return;
    }

    /*  14/10: du an dung VST2 32-bit ma may nay co ban 64-bit cung ten -> HOI truoc.
        Dong y = nap ban 64-bit va dua thong so cu vao luon (doi vo chunk / phuc hoi
        theo ten num). Khong dong y = giu dung ban 32-bit nhu du an da luu.  */
    PluginChain::upgradeBridge32OnLoad.store (false);
    {
        juce::StringArray upgradable;
        for (const auto& job : projectPluginLoadJobs)
            if (job.pluginXml != nullptr)
                if (auto* descXml = job.pluginXml->getFirstChildElement())
                {
                    juce::PluginDescription d;
                    if (d.loadFromXml (*descXml) && livent::isBridge32Description (d)
                        && PluginChain::hasNative64Equivalent (d))
                        upgradable.addIfNotAlreadyThere (d.name);
                }

        // 15/10: da chon "nho lua chon" -> tu lam, chi bao nhe 8 giay, khong hoi nua.
        if (const int pref = loadVst32UpgradePref(); ! upgradable.isEmpty() && pref != 0)
        {
            const bool upgrade = pref == 1;
            PluginChain::upgradeBridge32OnLoad.store (upgrade);
            if (upgrade)
                tonePanel.showAppNotice (livent::vn ("Đã tự đổi ") + juce::String (upgradable.size())
                                         + livent::vn (" VST sang 64-bit · giữ thông số cũ"));
            beginProjectPluginLoadQueue();
            return;
        }

        if (! upgradable.isEmpty())
        {
            juce::String list;
            for (int i = 0; i < juce::jmin (6, upgradable.size()); ++i)
                list << "  •  " << upgradable[i] << "\n";
            if (upgradable.size() > 6)
                list << livent::vn ("  … và ") << (upgradable.size() - 6) << livent::vn (" VST khác\n");

            const auto generation = projectLoadGeneration;
            juce::Component::SafePointer<MainComponent> safeThis (this);
            livent::confirmWithCheck (livent::vn ("Đổi VST 32-bit sang 64-bit?"),
                             livent::vn ("Dự án dùng ") + juce::String (upgradable.size())
                                 + livent::vn (" VST bản 32-bit mà máy này đã có bản 64-bit:\n\n")
                                 + list
                                 + livent::vn ("\nĐổi sang 64-bit: chạy nhẹ và ổn định hơn, thông số cũ được gắn sang luôn.\n"
                                               "Giữ 32-bit: mở đúng như lúc lưu.\n\n"
                                               "Đổi lại trong Cài đặt › VST / Hiệu ứng."),
                             livent::vn ("Đổi sang 64-bit"), livent::vn ("Giữ 32-bit"),
                             livent::vn ("Nhớ lựa chọn này, lần sau không hỏi nữa"), true,
                             [safeThis, generation] (bool upgrade, bool remember)
                             {
                                 if (remember)
                                     saveVst32UpgradePref (upgrade ? 1 : 2);
                                 if (safeThis == nullptr || safeThis->projectLoadGeneration != generation)
                                     return;
                                 PluginChain::upgradeBridge32OnLoad.store (upgrade);
                                 safeThis->beginProjectPluginLoadQueue();
                             });
            return;
        }
    }

    beginProjectPluginLoadQueue();
}

void MainComponent::beginProjectPluginLoadQueue()
{
    projectLoadInProgress = true;
    pluginLoadInProgress = true; // khoa duong them VST thu cong trong khi queue dang chay
    loadingPluginName = projectPluginLoadJobs.front().name;
    cancelProjectLoadButton.setVisible (true);
    cancelProjectLoadButton.setEnabled (true);
    cancelProjectLoadButton.setButtonText (livent::vn ("Hủy nạp"));
    updateStatusText();
    resized();

    // Cho message loop ve xong project/track mot nhip roi moi khoi tao DLL dau tien.
    const auto generation = projectLoadGeneration;
    juce::Component::SafePointer<MainComponent> safeThis (this);
    juce::MessageManager::callAsync ([safeThis, generation]
    {
        if (safeThis != nullptr && safeThis->projectLoadGeneration == generation)
            safeThis->loadNextProjectPlugin();
    });
}

void MainComponent::loadNextProjectPlugin()
{
    if (! projectLoadInProgress)
        return;

    if (projectLoadCancelRequested)
    {
        if (! projectPluginWorkerActive)
            finishProjectPluginLoadQueue (true);
        return;
    }

    // Bo qua job co track da bien mat / XML hong, nhung khong lam dung ca queue.
    while (projectPluginLoadIndex < (int) projectPluginLoadJobs.size())
    {
        auto& job = projectPluginLoadJobs[(size_t) projectPluginLoadIndex];
        auto* track = mixer.getTrackById (job.trackId);

        if (track == nullptr || job.pluginXml == nullptr)
        {
            ++projectPluginLoadIndex;
            ++projectPluginLoadDone;
            continue;
        }

        loadingPluginName = job.name;
        pluginLoadTrackId = job.trackId;
        pluginLoadSlot = job.pluginXml->getIntAttribute ("slot", -1);
        projectPluginWorkerActive = true;
        updateStatusText();

        const auto generation = projectLoadGeneration;
        juce::Component::SafePointer<MainComponent> safeThis (this);

        track->getInserts().restorePluginAsync (*job.pluginXml,
            [safeThis, generation] (juce::String error)
            {
                if (safeThis == nullptr || safeThis->projectLoadGeneration != generation)
                    return;

                safeThis->projectPluginWorkerActive = false;

                if (error.isNotEmpty())
                {
                    /* Khong bung hop thoai cho tung plugin - neu project co 5 con
                       loi thi 5 hop thoai lien tiep con kho chiu hon treo app.
                       Slot giu cho van con; warnAboutMissingPlugins() se tong hop
                       mot lan sau khi queue ket thuc. */
                    PluginChain::getSettingsFolder().getChildFile ("scanlog.txt")
                        .appendText (juce::Time::getCurrentTime().toString (false, true)
                                     + "  PROJECT LOADER: " + error + "\n");

                    const auto& failedJob = safeThis->projectPluginLoadJobs[
                        (size_t) safeThis->projectPluginLoadIndex];
                    const auto* failedTrack = safeThis->mixer.getTrackById (failedJob.trackId);
                    safeThis->projectPluginLoadFailures.add (
                        (failedTrack != nullptr ? failedTrack->getName() : juce::String ("Track"))
                        + " -> " + failedJob.name + ": " + error);
                }

                ++safeThis->projectPluginLoadDone;
                ++safeThis->projectPluginLoadIndex;

                if (safeThis->projectLoadCancelRequested)
                {
                    safeThis->finishProjectPluginLoadQueue (true);
                    return;
                }

                safeThis->loadNextProjectPlugin();
            });
        return;
    }

    finishProjectPluginLoadQueue (false);
}

void MainComponent::cancelProjectPluginLoad()
{
    if (! projectLoadInProgress)
        return;

    projectLoadCancelRequested = true;
    cancelProjectLoadButton.setEnabled (false);
    cancelProjectLoadButton.setButtonText (livent::vn ("Đang hủy..."));
    loadingPluginName = projectPluginWorkerActive
                            ? livent::vn ("đợi plugin hiện tại kết thúc")
                            : juce::String();
    updateStatusText();

    /* DLL dang o giua createPluginInstance khong the kill an toan. Ta chi dung
       queue SAU plugin hien tai. Neu worker chua bat dau thi ket thuc ngay. */
    if (! projectPluginWorkerActive)
        finishProjectPluginLoadQueue (true);
}

void MainComponent::finishProjectPluginLoadQueue (bool cancelled)
{
    const bool wasLoading = projectLoadInProgress || ! projectPluginLoadJobs.empty();

    projectLoadInProgress = false;
    projectPluginWorkerActive = false;
    projectLoadCancelRequested = false;
    pluginLoadInProgress = false;
    pluginLoadTrackId = -1;
    pluginLoadSlot = -1;
    loadingPluginName.clear();

    cancelProjectLoadButton.setEnabled (true);
    cancelProjectLoadButton.setVisible (false);
    cancelProjectLoadButton.setButtonText (livent::vn ("Hủy nạp"));

    // Inspector/F3 co the dang dong theo khoa F2, nhung rebuild luc nay re va
    // dam bao neu dang hien thi thi ten cac slot da doi tu placeholder sang VST that.
    if (auto* selected = inspector.getTrack())
    {
        inspector.rebuildInserts();
        refitInspector();
        mixerView.setSelectedTrack (selected);
    }
    mixerView.rebuild();

    /* Chi bay gio project moi co state day du de lam moc "da luu". O giu cho
       cua plugin loi/huy van ghi NGUYEN XML goc nen so sanh khong lam mat state. */
    if (projectLoadFromRecovery)
    {
        projectDirty = true;
        lastSavedStateXml.clear();
    }
    else if (projectOpen)
    {
        /* Neu nguoi dung da chinh volume/tone trong luc queue dang nap thi
           KHONG duoc tu y danh dau sach. De dirty=true de luc dong app van
           hoi Luu; an toan du lieu quan trong hon mot prompt thua. */
        if (! projectDirty)
        {
            lastSavedStateXml = buildComparableProjectState();
            clearAutosave();
        }
        else
        {
            lastSavedStateXml.clear();
        }
    }

    updateTitleText();
    updateStatusText();
    resized();

    if (wasLoading)
    {
        juce::Component::SafePointer<MainComponent> safeThis (this);
        const auto generation = projectLoadGeneration;
        const auto projectFile = currentProjectFile;
        juce::Timer::callAfterDelay (200, [safeThis, cancelled, generation, projectFile]
        {
            if (safeThis == nullptr || safeThis->projectLoadGeneration != generation
                || safeThis->currentProjectFile != projectFile)
                return;

            if (! cancelled)
            {
                safeThis->warnAboutMissingPlugins();

                // Tao native editor SAU khi tat ca VST da nap va canh bao da
                // hien. Guard project/generation de khong mo cua so cua .NT cu.
                juce::Timer::callAfterDelay (250, [safeThis, generation, projectFile]
                {
                    if (safeThis != nullptr
                        && safeThis->projectLoadGeneration == generation
                        && safeThis->currentProjectFile == projectFile)
                        safeThis->openMusicVst2AfterProjectLoad();
                });
            }
        });
    }

    projectPluginLoadJobs.clear();
    projectPluginLoadIndex = 0;
    projectPluginLoadDone = 0;

    /* Neu nguoi dung chon project khac trong luc queue dang chay, no duoc mo
       NGAY SAU plugin hien tai ket thuc - khong khoi tao hai VST song song. */
    auto pending = pendingProjectAfterLoadCancel;
    pendingProjectAfterLoadCancel = juce::File();

    if (pending.existsAsFile())
    {
        juce::Component::SafePointer<MainComponent> safeThis (this);
        juce::MessageManager::callAsync ([safeThis, pending]
        {
            if (safeThis != nullptr)
                safeThis->requestOpenProject (pending);
        });
    }
}

//=============================================================================
//  Danh sach mo gan day
//=============================================================================
void MainComponent::saveRecentList()
{
    PluginChain::getSettingsFolder()
        .getChildFile ("recent.txt")
        .replaceWithText (recentFiles.toString());
}

void MainComponent::loadRecentList()
{
    auto file = PluginChain::getSettingsFolder().getChildFile ("recent.txt");

    if (file.existsAsFile())
        recentFiles.restoreFromString (file.loadFileAsString());

    recentFiles.setMaxNumberOfItems (10);
    // 06/10: GIU file da mat (o USB chua cam...) - man Tao/Mo du an hien mo
    // di va cho xoa tay; menu Mo gan day thi khoa muc do.
}

//=============================================================================
//  Tu luu + phuc hoi sau khi treo
//=============================================================================
void MainComponent::timerCallback()
{
    if (masterRecordingUiActive && ! mixer.isMasterRecording() && ! timelineExportActive)
    {
        livent::alert (livent::vn ("Bản thu đã dừng"),
                       livent::vn ("Thiết bị âm thanh đã thay đổi hoặc ngừng chạy. LiveNT đã chốt bản thu tại sample rate ban đầu."),
                       juce::MessageBoxIconType::WarningIcon);
        stopMasterRecording(); // Offer to save the closed take exactly once.
    }
    if(mixer.hasRoutingCycle())
    {
        if(!routingCycleNotified)
        {
            routingCycleNotified=true;
            livent::alert(livent::vn("Routing tạo vòng lặp"),livent::vn("Có đường Output/Send nối vòng về nguồn. LiveNT tạm ngắt nhánh vòng lặp để giữ các đường còn lại. Hãy kiểm tra Output và Send của Group/FX; menu sẽ không cho tạo thêm đường nối vòng."));
        }
    }
    else routingCycleNotified=false;

    /*  Dong ho nay chay moi giay: cap nhat so CPU o thanh duoi.
        Rieng viec TU LUU thi 60 giay moi lam mot lan - ghi file lien tuc vua
        thua vua mon o cung.  */
    updateStatusText();
    updateStartupScanProgress();
    if (mixer.isOfflineExporting()) return;

    // 07/10 _D: chi nap plugin chinh pho (Melodyne...) khi du an da nap xong VST
    // cua no (LiveNT nap tung VST mot) va khong dang thu.
    mixer.getAra().setLoadingAllowed (projectOpen && ! projectLoadInProgress && ! pluginLoadInProgress
                                      && ! mixer.isTimelineRecording()
                                      && ! mixer.isLiveMode());   // 14/10: Che do Live khong nap ARA
    mixer.syncAra();

    // Cua so DAW co the duoc tao lai (doi che do/ghim): cap nhat cho YouTube.
    if (livent::youtube::useDawYouTube())
        publishDawWindowForYouTube();

    // Hang Tone bai / Tone nhac nam duoi video khi cua so YouTube dang mo;
    // tat YouTube thi hang do hien lai tren DAW.
    tonePanel.setSongRowHidden (! livent::branding::youtubeControlsInDaw
                                && livent::youtube::useDawYouTube() && youtube.isRunning());

    // V6.6.3: neu card da khoa dang vang mat, giu audio tat va tu thu lai.
    updateSoundcardLockStartupWait();

    // V4.8: process cai dat soundcard dong binh thuong HOAC crash deu duoc
    // phat hien tai day; DAW chinh tu mo lai cau hinh cu/moi ma khong chet theo.
    // 15/10: doi driver ngam ma driver treo (khong tra loi) -> sau 20 giay giet tien trinh phu,
    // LiveNT tu mo lai cau hinh cu (finishExternalAudioSettings thay khong co "saved").
    if (audioSettingsProcess != nullptr && audioSettingsHeadless && audioSettingsProcess->isRunning()
        && juce::Time::getMillisecondCounter() - audioSettingsStartedMs > 20000u)
        audioSettingsProcess->kill();
    if (audioSettingsProcess != nullptr && ! audioSettingsProcess->isRunning())
        finishExternalAudioSettings();

    // HOTFIX11: canh soundcard rot giua buoi. Chi chay 1 Hz tren message
    // thread, tuyet doi khong chen polling/lock vao audio callback.
    updateAudioDeviceWatchdog();

    if (++autosaveTick >= 60)
    {
        autosaveTick = 0;

        /* Autosave co the goi getStateInformation() cua VST. Trong Che do
           dien uu tien audio tuyet doi, nen KHONG chup state plugin. Ngoai
           che do dien, giam tan suat xuong 60 giay de laptop yeu nhe hon. */
        /* 16/10: Che do Live (hat) KHONG tu luu dinh ky - tranh giat giua buoi.
           Mot diem cuu ho duoc ghi luc chuyen Thu am -> Live (xem setLiveMode). */
        if (projectOpen && autosaveEnabled && autosaveDirty
            && ! mixer.isLiveMode()
            && ! pluginWindows.isPerformanceMode())
            writeAutosave();
    }
}

void MainComponent::writeAutosave()
{
    /* V6.4.6: recovery LITE. Tuyet doi khong goi getStateInformation() cua
       VST trong autosave - do la mot trong nhung diem co the khoa message
       thread va lam cua so trang tinh dung luc dang lap gan plugin. */
    if (auto xml = buildProjectStateXml (false))
    {
        xml->setAttribute ("recoveryLite", 1);

        if (SafeFile::writeXml (*xml, getAutosaveFile(), false))
            autosaveDirty = false;
    }
}

void MainComponent::writeRecoveryCheckpoint()
{
    if (! projectOpen || ! autosaveEnabled || pluginWindows.isPerformanceMode())
        return;

    autosaveDirty = true;
    autosaveTick = 0;
    writeAutosave();
}

void MainComponent::clearAutosave()
{
    getAutosaveFile().deleteFile();
    autosaveDirty = false;
}

void MainComponent::checkForCrashRecovery()
{
    auto pending = getAutosaveFile();

    if (! pending.existsAsFile())
        return;

    juce::Component::SafePointer<MainComponent> safeThis (this);

    juce::AlertWindow::showAsync (
        juce::MessageBoxOptions()
            .withIconType (juce::MessageBoxIconType::QuestionIcon)
            .withTitle (livent::vn ("Lần trước thoát không sạch"))
            .withMessage (livent::vn ("LiveNT tìm thấy một bản tự động lưu từ lần chạy trước.\n"
                          "Có vẻ app bị đóng đột ngột trước khi anh kịp bấm Lưu.\n\n"
                          "Khôi phục bản đó không?"))
            .withButton (livent::vn ("Khôi phục"))
            .withButton (livent::vn ("Bỏ qua"))
            .withAssociatedComponent (livent::dialogOwner()),
        [safeThis, pending] (int result)
        {
            if (safeThis != nullptr && result == 1)
                safeThis->loadProjectFrom (pending);

            pending.deleteFile();
        });
}

//=============================================================================
void MainComponent::saveWindowLayout()
{
    if (projectOpen)
        (void) saveMusicVst2WindowPreference (currentProjectFile);

    if (auto xml = pluginWindows.getState())
        SafeFile::writeXml (*xml, PluginChain::getSettingsFolder()
                                     .getChildFile ("windows.xml"), false);
}

void MainComponent::loadWindowLayout()
{
    auto file = PluginChain::getSettingsFolder().getChildFile ("windows.xml");

    if (! file.existsAsFile())
        return;

    if (auto xml = juce::XmlDocument::parse (file))
        pluginWindows.setState (*xml);
}

bool MainComponent::saveMusicVst2WindowPreference (const juce::File& projectFile)
{
    const auto prefFile = musicVst2PreferenceFileFor (projectFile);
    if (prefFile == juce::File())
        return false;
    if (! autoOpenMusicVst2 && ! prefFile.existsAsFile())
        return true; // project chua su dung tinh nang thi khong tao file phu

    juce::XmlElement xml ("MusicVst2Window");
    xml.setAttribute ("version", 1);
    xml.setAttribute ("enabled", autoOpenMusicVst2 ? 1 : 0);

    if (auto* music = mixer.getTrackByRole (Track::Role::Music))
    {
        juce::Rectangle<int> bounds;
        bool pinned = true;
        if (pluginWindows.getPlacement (
                PluginWindowManager::makeKey (music->getId(), kMusicVst2Slot),
                bounds, pinned))
        {
            xml.setAttribute ("x", bounds.getX());
            xml.setAttribute ("y", bounds.getY());
            xml.setAttribute ("w", bounds.getWidth());
            xml.setAttribute ("h", bounds.getHeight());
            xml.setAttribute ("pin", pinned ? 1 : 0);
        }
    }

    return SafeFile::writeXml (xml, prefFile);
}

void MainComponent::loadMusicVst2WindowPreference (const juce::File& projectFile)
{
    const auto prefFile = musicVst2PreferenceFileFor (projectFile);
    if (prefFile == juce::File() || ! prefFile.existsAsFile())
        return; // project cu van co the luu enabled trong <UI>

    auto xml = juce::XmlDocument::parse (prefFile);
    if (xml == nullptr || ! xml->hasTagName ("MusicVst2Window")
        || xml->getIntAttribute ("version") != 1)
        return;

    autoOpenMusicVst2 = xml->getIntAttribute ("enabled", 0) != 0;

    if (auto* music = mixer.getTrackByRole (Track::Role::Music))
        if (xml->hasAttribute ("x") && xml->hasAttribute ("y")
            && xml->hasAttribute ("w") && xml->hasAttribute ("h"))
            pluginWindows.setPlacement (
                PluginWindowManager::makeKey (music->getId(), kMusicVst2Slot),
                { xml->getIntAttribute ("x"), xml->getIntAttribute ("y"),
                  xml->getIntAttribute ("w"), xml->getIntAttribute ("h") },
                xml->getIntAttribute ("pin", 1) != 0);
}

void MainComponent::openMusicVst2AfterProjectLoad()
{
    // 12s: Do khong AI khong con mo / khoa cua so Auto-Key o o 2 - chi mo khi khach bat "Tu mo VST so 2".
    if (! mainWindowRevealed || ! projectOpen || ! autoOpenMusicVst2 || projectLoadInProgress
        || pluginLoadInProgress || pluginWindows.isPerformanceMode())
        return;

    auto* music = mixer.getTrackByRole (Track::Role::Music);
    if (music == nullptr || music->getInserts().isSlotEmpty (kMusicVst2Slot)
        || music->getInserts().isMissing (kMusicVst2Slot))
        return;

    if (auto* p = music->getInserts().getPlugin (kMusicVst2Slot))
        if (pluginWindows.isOpen (p))
            return;

    openEditorForSlot (kMusicVst2Slot, music);
}

//=============================================================================
//  MOC 20: MOT nut "Tien ich" thay vi nhieu nut roi rac tren cung 1 hang
//=============================================================================

/*  MOC 20: THU PHONG GIAO DIEN -- man hinh HD (1366x768, hoac laptop nho)
    thi giao dien LiveNT mac dinh hoi to, tran ra ngoai. juce::Desktop co san
    1 co so thu phong AP DUNG CHO CA APP (font, nut, khoang cach... deu ty le
    lai theo), khong phai tu ve lai tung thanh phan. Luu ra file rieng, doc
    lai luc khoi dong (xem Main.cpp) de nho lua chon giua cac lan mo app. */
static juce::File getUiScaleFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
               .getChildFile ("LiveNT").getChildFile ("uiscale.txt");
}

/*  MOC 66: cong tac tu luu (menu Studio) - luu rieng thanh 1 file nho, y het
    cach lam voi uiscale.txt o tren. Day la LUA CHON CHUNG cua anh (khong
    phai cua rieng 1 du an) - anh tat no di khi chuan bi hat live, roi bat
    lai khi ngoi mix, bat ke dang mo du an nao. Neu luu theo TUNG du an
    (trong file .NT) thi cung mot du an mo luc hat / luc mix se phai doi lua
    chon lien tuc, con luu chung the nay thi doi 1 lan la ap dung cho MOI
    lan mo app ve sau, dung y anh mo ta.  */
static juce::File getAutosavePrefFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
               .getChildFile ("LiveNT").getChildFile ("autosave-pref.txt");
}

static bool loadAutosavePref()
{
    auto f = getAutosavePrefFile();

    if (! f.existsAsFile())
        return true;   // chua tung doi gi -> mac dinh BAT

    return f.loadFileAsString().trim() != "0";
}

static void saveAutosavePref (bool enabled)
{
    getAutosavePrefFile().replaceWithText (enabled ? "1" : "0");
}

/* V6.5.0: giao dien doc la tuy chon chung cua may, nhung moi project
   van co the ghi de bang thuoc tinh <UI controlLayoutVertical>. */
static juce::File getVst32UpgradePrefFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("vst32-upgrade.txt");
}

static int loadVst32UpgradePref()
{
    const auto s = getVst32UpgradePrefFile().loadFileAsString().trim();
    return s == "upgrade" ? 1 : (s == "keep" ? 2 : 0);
}

static void saveVst32UpgradePref (int mode)
{
    getVst32UpgradePrefFile().replaceWithText (mode == 1 ? "upgrade" : (mode == 2 ? "keep" : "ask"));
}

static juce::File getVerticalLayoutPrefFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("vertical-layout.txt");
}

static bool loadVerticalLayoutPref()
{
    // V0.6.7.9: mo lai bo cuc DOC. Nho theo may (khong theo du an): lan
    // truoc tat app o che do nao thi mo lai dung che do do.
    return getVerticalLayoutPrefFile().loadFileAsString().trim() == "1";
}

static void saveVerticalLayoutPref (bool enabled)
{
    auto f = getVerticalLayoutPrefFile();
    f.getParentDirectory().createDirectory();
    f.replaceWithText (enabled ? "1" : "0");
}

/* V5.2: nut BÈ la tuy chon chung cua may. Mac dinh AN vi khong phai ai
   cung dung Auto-Tune 11/Harmony Player. Bat o menu Hien thi mot lan la nho. */
static juce::File getHarmonyButtonPrefFile()
{
    // V6.5.2: tách khoá ưu tiên mới để cấu hình rất cũ "ẩn BÈ" không tiếp tục
    // làm mất nút sau khi giao diện Cài đặt được thiết kế lại. Mặc định mới = hiện.
    return PluginChain::getSettingsFolder().getChildFile ("show-harmony-button-v2.txt");
}

static bool loadHarmonyButtonPref()
{
    const auto f = getHarmonyButtonPrefFile();
    // V6.0.1: BÈ là một nút chính thức của hàng live, mặc định HIỆN để đủ
    // 9 cột và đứng ngay cạnh MÍC như bố cục mới. Người dùng vẫn có thể
    // ẩn lại trong menu Hiển thị; file cũ tiếp tục được tôn trọng.
    return ! f.existsAsFile() || f.loadFileAsString().trim() != "0";
}

static void saveHarmonyButtonPref (bool enabled)
{
    auto f = getHarmonyButtonPrefFile();
    f.getParentDirectory().createDirectory();
    f.replaceWithText (enabled ? "1" : "0");
}

/* STABILITY PACK V1:
   Mac dinh BAT. Khi bat, moi native VST64 editor phai qua Host64 probe truoc.
   Neu audio core OK nhung GUI plugin crash/treo, LiveNT mo Generic Editor thay
   vi cham native GUI trong process chinh. */
static juce::File getVstGuiSafeModePrefFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("vst-gui-safe-mode.txt");
}

// 14/10 CHE DO LIVE: tuy chon cua MAY, mac dinh TAT (= nhu truoc, van thu duoc).
static bool loadLiveModePref()
{
    const auto f = PluginChain::getSettingsFolder().getChildFile ("live-mode.txt");
    return f.existsAsFile() && f.loadFileAsString().trim() == "1";
}

static void saveLiveModePref (bool enabled)
{
    auto f = PluginChain::getSettingsFolder().getChildFile ("live-mode.txt");
    f.getParentDirectory().createDirectory();
    f.replaceWithText (enabled ? "1" : "0");
}

// Tuy chon cua MAY (khong ghi vao .NT): mac dinh BAT.
static bool loadLowLatencyLivePref()
{
    const auto f = PluginChain::getSettingsFolder().getChildFile ("low-latency-live.txt");
    return ! f.existsAsFile() || f.loadFileAsString().trim() != "0";
}

static void saveLowLatencyLivePref (bool enabled)
{
    auto f = PluginChain::getSettingsFolder().getChildFile ("low-latency-live.txt");
    f.getParentDirectory().createDirectory();
    f.replaceWithText (enabled ? "1" : "0");
}

// 13/10: bu them (ms) cho ban thu. Tuy chon cua MAY (tre card khac nhau tung may), khong ghi vao .NT.
static double loadRecordExtraMsPref()
{
    const auto f = PluginChain::getSettingsFolder().getChildFile ("record-extra-ms.txt");
    if (! f.existsAsFile()) return 0.0;
    const double v = f.loadFileAsString().trim().getDoubleValue();
    return std::isfinite (v) ? juce::jlimit (-100.0, 200.0, v) : 0.0;
}

static void saveRecordExtraMsPref (double ms)
{
    auto f = PluginChain::getSettingsFolder().getChildFile ("record-extra-ms.txt");
    f.getParentDirectory().createDirectory();
    f.replaceWithText (juce::String (ms, 2));
}

static bool loadVstGuiSafeModePref()
{
    const auto f = getVstGuiSafeModePrefFile();
    return ! f.existsAsFile() || f.loadFileAsString().trim() != "0";
}

static void saveVstGuiSafeModePref (bool enabled)
{
    auto f = getVstGuiSafeModePrefFile();
    f.getParentDirectory().createDirectory();
    f.replaceWithText (enabled ? "1" : "0");
}

// Tuy chon chung cua may: khong ghi vao .NT hay reset khi doi project.
static juce::File getAutoKeyListenPrefFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("auto-key-2-listen.txt");
}

static bool loadAutoKeyListenPref()
{
    return getAutoKeyListenPrefFile().loadFileAsString().trim() == "1";
}

static bool saveAutoKeyListenPref (bool enabled)
{
    auto f = getAutoKeyListenPrefFile();
    return f.getParentDirectory().createDirectory().wasOk()
        && f.replaceWithText (enabled ? "1" : "0");
}

/*  11i: dem an toan VST 32-bit - tuy chon chung cua may. MAC DINH BAT: chua co file = bat.  */
static juce::File getBridge32SafetyPrefFile()
{
    return PluginChain::getSettingsFolder().getChildFile ("bridge32-safety-buffer.txt");
}

static bool loadBridge32SafetyPref()
{
    return getBridge32SafetyPrefFile().loadFileAsString().trim() != "0";
}

static bool saveBridge32SafetyPref (bool enabled)
{
    auto f = getBridge32SafetyPrefFile();
    return f.getParentDirectory().createDirectory().wasOk()
        && f.replaceWithText (enabled ? "1" : "0");
}

/*  ==========  MOC 75: MO LIVENT LEN THI THAY GI  ==========

    Ba lua chon, luu thanh MOT con so trong khoidong.txt:

        0 = Nho theo tung du an   (dung dung cai da luu trong file .NT)
        1 = CHI BANG DIEU KHIEN   (mac dinh moi - anh chot)
        2 = Hien het

    Vi sao khong nhet vao file .NT: day la thoi quen dung may cua anh, khong
    phai thuoc tinh cua mot ban nhac. Luu trong .NT thi moi du an moi tao lai
    ve mac dinh, va gui du an cho khach la keo theo ca thoi quen cua minh
    sang may ho. Y het cach autosave-pref.txt dang lam.

    File nay THAY CHO inspector-startup.txt cua Moc 74 (chi lo moi bang
    Insert/Send). File cu con nam do cung khong sao - khong ai doc nua.  */
static juce::File getStartupLayoutFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
               .getChildFile ("LiveNT").getChildFile ("khoidong.txt");
}

static int loadStartupLayoutMode()
{
    auto f = getStartupLayoutFile();

    //  MOC 76: doi mac dinh tu 1 (chi bang dieu khien, an het ban tron/
    //  danh sach track/inspector) sang 0 (nho theo du an) - vi da sua
    //  mixerVisible mac dinh thanh MO (xem buildProjectStateXml/
    //  loadProjectFrom), nen mode 0 gio TU NHIEN cho ra dung ket qua
    //  "mo san" ma anh muon cho nguoi lan dau mo LiveNT (chua co du an
    //  nao de "nho theo"), ma van ton trong lua chon rieng cua tung du an
    //  ve sau neu anh chu dong an bot di.
    if (! f.existsAsFile())
        return 1;

    return juce::jlimit (0, 2, f.loadFileAsString().trim().getIntValue());
}

static void saveStartupLayoutMode (int mode)
{
    auto f = getStartupLayoutFile();

    //  Thu muc %APPDATA%\LiveNT co the chua ton tai neu day la lan chay dau
    f.getParentDirectory().createDirectory();
    f.replaceWithText (juce::String (juce::jlimit (0, 2, mode)));
}

/*  MOC 96: mat khau F2 la thiet lap cua MAY, khong phai cua project.
    File rieng de nguoi dung tu doi ma khong can sua source/build lai. */
static juce::File getWorkPanelPasswordFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
               .getChildFile ("LiveNT").getChildFile ("f2-password.txt");
}

static juce::String loadWorkPanelPassword()
{
    const auto f = getWorkPanelPasswordFile();

    if (! f.existsAsFile())
        return "2808";

    const auto value = f.loadFileAsString().trim();
    return value.isNotEmpty() ? value : juce::String ("2808");
}

static void saveWorkPanelPassword (const juce::String& password)
{
    auto f = getWorkPanelPasswordFile();
    f.getParentDirectory().createDirectory();
    f.replaceWithText (password.trim());
}

static bool loadWorkPanelPasswordRequired()
{
    auto f = getWorkPanelPasswordFile().getSiblingFile ("work-panel-lock.txt");
    if (f.existsAsFile()) return f.loadFileAsString().trim() != "0";
    // Old installations used an implicit lock. Preserve it when a password already exists.
    return getWorkPanelPasswordFile().existsAsFile();
}

static bool saveWorkPanelPasswordRequired (bool required)
{
    auto f = getWorkPanelPasswordFile().getSiblingFile ("work-panel-lock.txt");
    f.getParentDirectory().createDirectory();
    juce::TemporaryFile temp (f);
    return temp.getFile().replaceWithText (required ? "1" : "0") && temp.overwriteTargetFileWithTemporary();
}

#if JUCE_MAC
/*  MOC 66e: nho lai trinh duyet anh chon (menu Studio), y het cach lam
    voi autosave-pref.txt o tren.  */
static juce::File getBrowserPrefFile()
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
               .getChildFile ("LiveNT").getChildFile ("browser-pref.txt");
}

static juce::String loadBrowserPref()
{
    auto f = getBrowserPrefFile();
    const auto saved = f.existsAsFile() ? f.loadFileAsString().trim() : juce::String();

    // V6.5.8: Mac khong tu quet tat ca trinh duyet nua. Neu chua tung chon,
    // mac dinh chi hoi Google Chrome. Nhu vay macOS chi xin quyen Automation
    // cho DUNG mot trinh duyet thay vi lan luot hoi 5-6 app rat kho chiu.
    return saved.isNotEmpty() ? saved : juce::String ("Google Chrome");
}

static void saveBrowserPref (const juce::String& appName)
{
    auto f = getBrowserPrefFile();
    f.getParentDirectory().createDirectory();

    if (appName.isEmpty())
        f.deleteFile();
    else
        f.replaceWithText (appName);
}
#endif

double MainComponent::loadUiScale()
{
    auto f = getUiScaleFile();

    if (! f.existsAsFile())
        return 1.0;

    const double v = f.loadFileAsString().trim().getDoubleValue();
    return v > 0.4 && v < 3.0 ? v : 1.0;   // gia tri vo ly (file hong) -> ve mac dinh
}

void MainComponent::setUiScale (double scale)
{
    juce::Desktop::getInstance().setGlobalScaleFactor ((float) scale);
    getUiScaleFile().replaceWithText (juce::String (scale, 2));
}

/*  14/10: doi co chu Cai dat / Huong dan. Cua so Cai dat dang mo thi dong roi mo lai
    ngay (dung trang dang xem) de thay co moi; cua so Huong dan mo lan sau la dung co moi. */
void MainComponent::applyTextScaleFromMenu (double scale)
{
    livent::textscale::set (scale);

    if (settingsWindow != nullptr)
    {
        settingsWindow.reset();
        juce::Component::SafePointer<MainComponent> safe (this);
        juce::MessageManager::callAsync ([safe]
        {
            if (safe != nullptr && safe->settingsWindow == nullptr)
                safe->openSettingsDialog();
        });
    }
}

void MainComponent::applyUiScaleFromMenu (double scale)
{
    /*  V0.6.7.7: doi ti le giao dien (75% / 90% / 100%...) xong thi cua so
        TU VE KICH THUOC GON, khong de lai khoang trong phia duoi.

        setGlobalScaleFactor() giu nguyen kich thuoc PIXEL that cua cua so,
        nen o 75% kich thuoc logical tu phinh ra (640 -> ~850). Truoc day
        phai keo mep cua so thi compactControlPanelWindow() moi chay.
        Gio goi no ngay sau khi doi ti le: mot lan o message tick ke tiep
        (luc peer da cap nhat scale) va mot lan nua sau 200 ms cho cac
        he dieu hanh/driver man hinh cap nhat cham (Windows DPI, macOS). */
    tonePanel.closeLaughPanel();
    setUiScale (scale);

    juce::Component::SafePointer<MainComponent> safe (this);
    auto recompact = [safe]
    {
        if (safe == nullptr)
            return;

        safe->compactControlPanelWindow();
        if (safe->settingsWindow != nullptr)
            livent::fitSettingsWindow (*safe->settingsWindow, safe.getComponent());
        safe->resized();
        safe->repaint();
    };

    juce::MessageManager::callAsync (recompact);
    juce::Timer::callAfterDelay (200, recompact);
}

//=============================================================================
void MainComponent::openSoundcardRecoverySettings()
{
    // V6.6.3f: khi startup gate chan vi card cu khong con, nguoi ban co the
    // nhap mat khau F2 o bang canh bao. Main.cpp sau do vao DAW o che do cuu
    // ho va goi ham nay de mo ngay bang chon + KHOA LAI soundcard.
    openAudioSettings (true);
}

void MainComponent::switchAudioDriver (const juce::String& type, const juce::String& name, const juce::String& inputName)
{
    /*  16/10: bang Thiet lap am thanh KHONG dong nua - bao ket qua ngay tren bang
        (vong quay -> xanh / do). Khong co bang (goi tu cho khac) thi bao bang hop thoai nhu cu. */
    juce::Component::SafePointer<AudioSetupDialog> dlg (audioSetupDialogLive.getComponent());
    auto fail = [dlg] (const juce::String& message)
    {
        if (dlg != nullptr) dlg->endDriverSwitch (false, message);
        else livent::alert (livent::vn ("Không chuyển được driver"), message, juce::MessageBoxIconType::WarningIcon);
    };
    if (mixer.isMasterRecording() || mixer.isTimelineRecording() || timelineExportActive || mixer.isOfflineExporting())
    { fail (livent::vn ("Đang thu hoặc xuất âm thanh. Dừng lại rồi mới đổi driver.")); return; }
    if (soundcardLockEnabled)
    { fail (livent::vn ("Soundcard đang bị khóa. Tắt Khóa soundcard trong Cài đặt trước khi đổi driver.")); return; }
    if (audioSettingsProcess != nullptr && audioSettingsProcess->isRunning())
    { fail (livent::vn ("Đang đổi driver, chờ xong rồi chọn lại.")); return; }

    juce::XmlElement request ("DRIVER_REQUEST");
    request.setAttribute ("type", type);
    request.setAttribute ("name", name);
    request.setAttribute ("input", inputName.isNotEmpty() ? inputName : name);
    auto file = livent::safeaudio::driverRequestFile();
    file.getParentDirectory().createDirectory();
    if (! request.writeTo (file))
    {
        fail (livent::vn ("Không ghi được lựa chọn driver vào thư mục cài đặt."));
        return;
    }
    if (dlg != nullptr)
        dlg->beginDriverSwitch (name);
    reopenAudioSetupAfterSettings = false;      // 16/10: bang van mo, khong can mo lai
    openAudioSettings (false, true);
    if (audioSettingsProcess == nullptr)
    {
        file.deleteFile();
        if (dlg != nullptr) dlg->endDriverSwitch (false, livent::vn ("Không chạy được tiến trình đổi driver. Vẫn dùng driver cũ."));
    }
}

void MainComponent::openAudioSettings (bool lockAfterSave, bool headlessDriverSwitch)
{
    if (mixer.isMasterRecording() || mixer.isTimelineRecording()
        || timelineExportActive || mixer.isOfflineExporting())
    {
        livent::alert (livent::vn ("Đang thu hoặc xuất âm thanh"),
                       livent::vn ("Dừng thu hoặc chờ xuất xong trước khi đổi soundcard / sample rate."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }
    if (soundcardLockEnabled && ! lockAfterSave)
    {
        livent::alert (livent::vn ("SOUNDCARD ĐANG BỊ KHÓA"),
                       livent::vn ("Hãy tắt KHÓA SOUNDCARD trước khi đổi driver hoặc thiết bị âm thanh.\n\nThiết bị đang khóa: ")
                       + getSoundcardLockDisplayName(),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    /*  V5.2 - SAFE AUDIO + MO CUA SO TRUOC, NHA DRIVER SAU.

        Truoc day bam "Cai dat soundcard" la shutdownAudio() NGAY tren luong
        giao dien. Mot so ASIO driver mat 1-2 giay moi dong -> nhin nhu LiveNT
        bi khung. Gio process phu duoc mo TRUOC. Cua so phu hien "dang cho
        LiveNT nha soundcard", sau do DAW moi dong audio va ghi file hand-shake.
        Driver van an toan nam o process phu, nhung nguoi dung khong con bam
        nut roi thay app dung im. */
    if (audioSettingsProcess != nullptr && audioSettingsProcess->isRunning())
    {
        livent::alert (livent::vn ("Cài đặt soundcard đang mở"),
                       livent::vn ("Bảng cài đặt soundcard đang chạy ở cửa sổ riêng."));
        return;
    }

    saveDeviceSettings();

    auto settings = PluginChain::getSettingsFolder();
    settings.createDirectory();
    auto audio = settings.getChildFile ("audio.xml");
    auto lastGood = settings.getChildFile ("audio.lastgood.xml");
    auto result = livent::safeaudio::resultFile();
    auto released = livent::safeaudio::releaseReadyFile();
    auto lockFile = settings.getChildFile ("soundcard-lock.xml");
    auto preManualLock = settings.getChildFile ("soundcard-lock.pre-manual.xml");

    result.deleteFile();
    released.deleteFile();

    // V6.6.3c: neu dang chon THU CONG de khoa, giu lai khoa cu de co the
    // rollback ca audio.xml LAN soundcard-lock.xml neu card moi mo that bai
    // khi quay ve process DAW chinh.
    if (lockAfterSave)
    {
        preManualLock.deleteFile();
        if (lockFile.existsAsFile())
            lockFile.copyFileTo (preManualLock);
    }

    if (audio.existsAsFile())
    {
        lastGood.deleteFile();
        audio.copyFileTo (lastGood);
    }

    auto exe = juce::File::getSpecialLocation (juce::File::currentExecutableFile);
    auto process = std::make_unique<juce::ChildProcess>();
    const auto command = "\"" + exe.getFullPathName()
                       + (lockAfterSave ? "\" --audio-settings-wait-lock"
                                        : "\" --audio-settings-wait")
                       + (headlessDriverSwitch ? juce::String (" --audio-apply-driver") : juce::String())
                       + livent::dialogOwnerArgument();

    if (! process->start (command))
    {
        if (lockAfterSave)
            preManualLock.deleteFile();

        livent::alert (livent::vn ("Không mở được bảng soundcard"),
                       livent::vn ("LiveNT không chạy được tiến trình cài đặt phụ. Âm thanh hiện tại vẫn được giữ nguyên."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    audioSettingsLockAfterSave = lockAfterSave;
    audioSettingsHeadless = headlessDriverSwitch;
    audioSettingsStartedMs = juce::Time::getMillisecondCounter();
    audioSettingsProcess = std::move (process);
    statusLabel.setText (headlessDriverSwitch
                         ? livent::vn ("Đang chuyển driver...")
                         : lockAfterSave
                         ? livent::vn ("Đang mở bảng chọn driver/soundcard để khóa...")
                         : livent::vn ("Đang mở bảng soundcard - chuẩn bị nhả driver..."),
                         juce::dontSendNotification);
    repaint();

    juce::Component::SafePointer<MainComponent> safeThis (this);
    juce::Timer::callAfterDelay (120, [safeThis]
    {
        if (safeThis == nullptr || safeThis->audioSettingsProcess == nullptr
            || ! safeThis->audioSettingsProcess->isRunning())
            return;

        safeThis->shutdownAudio();
        livent::safeaudio::releaseReadyFile().replaceWithText ("ready");
        safeThis->statusLabel.setText (safeThis->audioSettingsHeadless
                                           ? livent::vn ("Đang mở driver mới...")
                                           : livent::vn ("Soundcard đã được nhả - chọn driver/buffer ở cửa sổ riêng..."),
                                           juce::dontSendNotification);
    });
}

void MainComponent::finishExternalAudioSettings()
{
    if (audioSettingsProcess == nullptr)
        return;

    audioSettingsProcess.reset();
    const bool headlessSwitch = std::exchange (audioSettingsHeadless, false);   // 15/10
    livent::safeaudio::driverRequestFile().deleteFile();
    const bool reopenSetup = reopenAudioSetupAfterSettings;   // 14/10: mo lai cua so Thiet lap am thanh sau khi doi driver
    reopenAudioSetupAfterSettings = false;

    auto settings = PluginChain::getSettingsFolder();
    auto audio = settings.getChildFile ("audio.xml");
    auto lastGood = settings.getChildFile ("audio.lastgood.xml");
    auto resultFile = settings.getChildFile ("audio-settings-result.txt");
    auto lockFile = settings.getChildFile ("soundcard-lock.xml");
    auto preManualLock = settings.getChildFile ("soundcard-lock.pre-manual.xml");
    livent::safeaudio::releaseReadyFile().deleteFile();
    const auto result = resultFile.existsAsFile()
                      ? resultFile.loadFileAsString().trim()
                      : juce::String();
    resultFile.deleteFile();

    // Neu helper bi crash/bi kill thi no khong ghi saved/saved-lock. Phuc hoi ban cu.
    const bool helperSaved = (result == "saved" || result == "saved-lock");
    if (! helperSaved && lastGood.existsAsFile())
        lastGood.copyFileTo (audio);

    auto saved = loadDeviceSettings();
    setAudioChannels (requestedAudioInputs, requestedAudioOutputs, saved.get());
    audioInitialisedOnce = true;
    audioWatchdogBadTicks = 0;
    audioWatchdogRetryCooldown = 0;
    audioWatchdogAttempts = 0;            // 0.6.7.5: nguoi dung vua chon lai -> cho phep thu lai tu dau
    audioGiveUpAlertShown = false;
    audioWatchdogStartupGraceTicks = 6;

    // V6.6.3c: helper vua chon thu cong va ghi soundcard-lock.xml. Nap lai
    // ngay trong process DAW de watchdog va menu dung khoa moi, khong can
    // dong/mo LiveNT mot lan nua.
    if (result == "saved-lock")
    {
        loadSoundcardLockState();
        soundcardLockWaiting = false;
        soundcardLockAlertShown = false;

        /* Helper da mo duoc card trong process phu, nhung van phai xac minh
           THEM MOT LAN trong process DAW that. Neu JUCE/driver roi sang
           Default hoac card moi khong mo duoc o day, TUYET DOI khong commit
           mot bo khoa chet. Rollback dong bo ca audio.xml va khoa cu. */
        const bool manualLockReallyWorks = soundcardLockEnabled
                                        && currentAudioMatchesSoundcardLock()
                                        && isAudioDeviceHealthy();

        if (! manualLockReallyWorks)
        {
            shutdownAudio();
            audioInitialisedOnce = false;

            if (lastGood.existsAsFile())
                lastGood.copyFileTo (audio);

            if (preManualLock.existsAsFile())
                preManualLock.copyFileTo (lockFile);
            else
                lockFile.deleteFile();

            preManualLock.deleteFile();
            loadSoundcardLockState();

            auto restored = loadDeviceSettings();
            setAudioChannels (requestedAudioInputs, requestedAudioOutputs, restored.get());
            audioInitialisedOnce = true;
            audioWatchdogBadTicks = 0;
            audioWatchdogRetryCooldown = 0;
            audioSettingsLockAfterSave = false;

            livent::alert (livent::vn ("Không thể khóa cấu hình vừa chọn"),
                           livent::vn ("Driver/soundcard vừa chọn mở được ở bảng phụ nhưng DAW chính không mở lại đúng cấu hình đó. "
                                       "LiveNT đã phục hồi soundcard và khóa cũ, không lưu một khóa lỗi."),
                           juce::MessageBoxIconType::WarningIcon);

            updateStatusText();
            inspector.rebuildRouting();
            refitInspector();
            return;
        }

        // Da qua ca hai lan mo: commit khoa moi va xoa snapshot rollback.
        preManualLock.deleteFile();
    }
    else if (audioSettingsLockAfterSave)
    {
        // Huy/loi helper: khoa cu chua bi thay. Snapshot chi de rollback neu
        // saved-lock thanh cong ma process chinh that bai, gio khong can nua.
        preManualLock.deleteFile();
    }

    audioSettingsLockAfterSave = false;

    // 16/10: doi driver ngam tu bang Thiet lap am thanh -> bao ket qua NGAY TREN BANG (xanh / do).
    juce::Component::SafePointer<AudioSetupDialog> liveDialog (headlessSwitch ? audioSetupDialogLive.getComponent() : nullptr);
    bool switchReported = false;
    auto reportSwitch = [&] (bool ok, const juce::String& title, const juce::String& message)
    {
        switchReported = true;
        if (liveDialog != nullptr) liveDialog->endDriverSwitch (ok, message);
        else if (! ok) livent::alert (title, message, juce::MessageBoxIconType::WarningIcon);
    };

    // Truong hop hiem: helper luu duoc nhung app chinh van khong mo duoc.
    // Quay ve last-good mot lan, tranh de LiveNT o trang thai khong co audio.
    if (deviceManager.getCurrentAudioDevice() == nullptr && lastGood.existsAsFile())
    {
        lastGood.copyFileTo (audio);
        auto old = loadDeviceSettings();
        setAudioChannels (requestedAudioInputs, requestedAudioOutputs, old.get());

        if (headlessSwitch)
            reportSwitch (false, livent::vn ("Không chuyển được driver"),
                          livent::vn ("Driver vừa chọn không mở được. Đã quay lại driver cũ."));
        else
        livent::alert (livent::vn ("Đã quay lại soundcard cũ"),
            livent::vn ("Cấu hình/driver vừa chọn không mở được trong LiveNT. "
                        "Chương trình đã tự phục hồi cấu hình âm thanh trước đó."),
            juce::MessageBoxIconType::WarningIcon);
    }
    else if (result.startsWith ("failed"))   // 15/10: doi driver ngam that bai -> da giu driver cu
    {
        reportSwitch (false, livent::vn ("Không chuyển được driver"),
                      result.fromFirstOccurrenceOf ("failed:", false, false) + livent::vn (" Vẫn dùng driver cũ."));
    }
    else if (result.isEmpty() && headlessSwitch)
    {
        reportSwitch (false, livent::vn ("Driver vừa chọn bị lỗi"),
                      livent::vn ("Driver không phản hồi hoặc bị lỗi khi mở. Đã quay lại driver cũ."));
    }
    else if (result.isEmpty())
    {
        livent::alert (livent::vn ("Driver vừa thử bị lỗi"),
            livent::vn ("Cửa sổ cài đặt soundcard đã đóng bất thường. "
                        "LiveNT chính vẫn chạy và đã mở lại cấu hình âm thanh cũ."),
            juce::MessageBoxIconType::WarningIcon);
    }
    else if (result == "saved-lock")
    {
        if (soundcardLockEnabled && currentAudioMatchesSoundcardLock() && isAudioDeviceHealthy())
        {
            livent::alert (livent::vn ("Đã khóa soundcard thủ công"),
                           livent::vn ("Driver: ") + soundcardLockDeviceType
                           + livent::vn ("\nThiết bị: ") + getSoundcardLockDisplayName()
                           + livent::vn ("\n\nTừ lần mở sau, thiếu/sai đúng cấu hình này thì LiveNT sẽ không vào DAW."));
        }
        else
        {
            livent::alert (livent::vn ("Đã lưu khóa nhưng chưa mở lại được"),
                           livent::vn ("Cấu hình khóa đã được ghi, nhưng process DAW hiện tại chưa mở lại đúng soundcard. "
                                       "Hãy kiểm tra driver/card trước khi thoát; lần mở sau cổng khóa sẽ chặn nếu không đúng."),
                           juce::MessageBoxIconType::WarningIcon);
        }
    }

    updateStatusText();
    inspector.rebuildRouting();
    refitInspector();

    if (headlessSwitch && ! switchReported)
    {
        auto* dev = deviceManager.getCurrentAudioDevice();
        reportSwitch (dev != nullptr,
                      livent::vn ("Không chuyển được driver"),
                      dev != nullptr ? livent::vn ("Đã chuyển sang ") + dev->getName()
                                     : livent::vn ("Chưa mở được soundcard sau khi đổi driver."));
    }

    if (reopenSetup)
    {
        juce::Component::SafePointer<MainComponent> safe (this);
        juce::Timer::callAfterDelay (300, [safe] { if (safe != nullptr) safe->openAudioSetupDialog (0); });
    }
}

bool MainComponent::isAudioDeviceHealthy() const
{
    auto* dev = deviceManager.getCurrentAudioDevice();
    if (dev == nullptr)
        return false;

    // Mot so ASIO driver van giu object sau khi USB rot. Kiem ca trang thai
    // mo/chay va lastError thay vi chi so sanh con tro nullptr.
    return dev->isOpen() && dev->isPlaying() && dev->getLastError().isEmpty();
}

void MainComponent::updateAudioDeviceWatchdog()
{
    // Khi dang CHO soundcard da khoa, watchdog cu khong duoc phep fallback
    // sang last-good/Default. updateSoundcardLockStartupWait() tu lo.
    if (soundcardLockWaiting)
        return;

    // Chua khoi tao audio xong (RuntimePermissions callback chua ve), hoac
    // LiveNT dang CO Y nha ASIO cho cua so cai dat phu -> tuyet doi khong
    // tranh driver voi chinh minh. Destructor da stopTimer() truoc shutdown.
    if (! audioInitialisedOnce || audioSettingsProcess != nullptr)
        return;

    if (audioWatchdogRetryCooldown > 0)
        --audioWatchdogRetryCooldown;

    if (isAudioDeviceHealthy())
    {
        // OS/JUCE khong duoc phep am tham doi sang card khac khi dang khoa.
        if (soundcardLockEnabled && ! currentAudioMatchesSoundcardLock())
        {
            // 06/10: driver doi ten/doc lai thong tin co the lech 1-2 nhip;
            // chi tat am khi lech lien tuc >= 3 nhip, tranh mat tieng chap chon.
            if (++soundcardLockMismatchTicks < 3)
                return;
            soundcardLockMismatchTicks = 0;
            soundcardLockWaiting = true;
            soundcardLockAlertShown = false;
            soundcardLockRetryTicks = 0;
            shutdownAudio();
            audioInitialisedOnce = false;
            return;
        }

        soundcardLockMismatchTicks = 0;
        audioEverHealthy = true;
        audioWatchdogAttempts = 0;
        audioWatchdogStartupGraceTicks = 0;
        audioWatchdogBadTicks = 0;

        // 0.6.7.5: vua vao che do an toan (lan truoc driver treo) -> bao MOT lan.
        if (audioSafeModeAtStartup)
        {
            audioSafeModeAtStartup = false;
            livent::alert (livent::vn ("Đã bỏ cấu hình âm thanh cũ"),
                           livent::vn ("Lần mở trước, driver âm thanh không phản hồi nên LiveNT bị treo.\n"
                                       "Lần này LiveNT dùng thiết bị âm thanh mặc định của máy để vào được ngay.\n\n"
                                       "Cấu hình cũ vẫn được giữ trong file audio.hung.xml, thư mục:\n")
                           + PluginChain::getSettingsFolder().getFullPathName()
                           + livent::vn ("\n\nNếu dùng soundcard rời, bấm \"Cài đặt soundcard\" để chọn lại."),
                           juce::MessageBoxIconType::InfoIcon);
        }

        if (audioWatchdogFault)
        {
            audioWatchdogFault = false;
            audioWatchdogRecoveredTicks = 3;
        }

        if (audioWatchdogRecoveredTicks > 0)
        {
            statusLabel.setText (livent::vn ("ĐÃ KẾT NỐI LẠI SOUNDCARD"),
                                 juce::dontSendNotification);
            statusLabel.setColour (juce::Label::textColourId, Col::green);
            --audioWatchdogRecoveredTicks;
        }
        return;
    }

    // 0.6.7.5: vua mo xong (driver ASIO/USB co the can vai giay moi bat dau chay)
    // thi chua duoc goi la "mat". Chi ap dung khi chua tung mo duoc lan nao.
    if (! audioEverHealthy && audioWatchdogStartupGraceTicks > 0)
    {
        --audioWatchdogStartupGraceTicks;
        statusLabel.setText (livent::vn ("ĐANG MỞ SOUNDCARD..."), juce::dontSendNotification);
        statusLabel.setColour (juce::Label::textColourId, Col::amber);
        return;
    }

    ++audioWatchdogBadTicks;
    // A single transient isPlaying=false (common while a USB/ASIO device
    // renegotiates its clock) must not tear down the live audio graph.
    if (audioWatchdogBadTicks < 2)
        return;

    audioWatchdogFault = true;
    audioWatchdogRecoveredTicks = 0;

    if (soundcardLockEnabled)
    {
        // Card dang khoa ma rot giua buoi: dung audio ngay, KHONG fallback.
        soundcardLockWaiting = true;
        soundcardLockAlertShown = false;
        soundcardLockRetryTicks = 0;
        shutdownAudio();
        audioInitialisedOnce = false;
        statusLabel.setText (livent::vn ("CHỜ SOUNDCARD: ") + getSoundcardLockDisplayName(),
                             juce::dontSendNotification);
        statusLabel.setColour (juce::Label::textColourId, Col::amber);
        return;
    }

    const bool neverOpened = ! audioEverHealthy;

    if (neverOpened)
    {
        statusLabel.setText (livent::vn ("CHƯA MỞ ĐƯỢC SOUNDCARD — bấm \"Cài đặt soundcard\" để chọn lại"),
                             juce::dontSendNotification);
        statusLabel.setColour (juce::Label::textColourId, Col::amber);
    }
    else
    {
        statusLabel.setText (livent::watchdog::shouldShowDetailedHint (audioWatchdogAttempts)
                                 ? livent::vn ("MẤT SOUNDCARD — kiểm tra cáp/driver, hoặc bấm \"Cài đặt soundcard\"")
                                 : livent::vn ("MẤT SOUNDCARD — ĐANG THỬ KẾT NỐI LẠI..."),
                             juce::dontSendNotification);
        statusLabel.setColour (juce::Label::textColourId, Col::red);
    }

    /*  0.6.7.5: CHUA TUNG mo duoc thi chi thu toi da 3 kieu roi DUNG han:
          lan 0: cau hinh da luu (co the chi la chap chon luc vua mo)
          lan 1: thiet bi mac dinh cua he dieu hanh, co micro
          lan 2: thiet bi mac dinh, CHI DAU RA (may khong co/khong cap quyen micro)
        Moi lan mo chay tren luong giao dien; neu driver treo thi lap vo han
        chinh la cai lam cua so "Not Responding" o may khach.  */
    if (neverOpened && audioWatchdogAttempts >= 3)
    {
        if (! audioGiveUpAlertShown)
        {
            audioGiveUpAlertShown = true;
            livent::stabilityLog ("AUDIO give-up", "3 lan thu deu khong mo duoc soundcard");
            livent::alert (livent::vn ("LiveNT chưa mở được soundcard"),
                           livent::vn ("Đã thử cấu hình cũ và cả thiết bị âm thanh mặc định của máy nhưng đều không mở được.\n\n")
                          #if JUCE_MAC
                           + livent::vn ("Hãy kiểm tra:\n"
                                         "• System Settings > Privacy & Security > Microphone: bật cho LiveNT\n"
                                         "• Đã cắm/bật đúng soundcard hoặc tai nghe\n\n")
                          #else
                           + livent::vn ("Hãy kiểm tra:\n"
                                         "• Settings > Privacy & security > Microphone: bật \"Let desktop apps access your microphone\"\n"
                                         "• Đã cắm/bật đúng soundcard, tai nghe hoặc micro và không bị tắt trong Sound settings\n"
                                         "• Không có phần mềm khác đang giữ driver ASIO\n\n")
                          #endif
                           + livent::vn ("Sau đó bấm \"Cài đặt soundcard\" để chọn lại thiết bị."),
                           juce::MessageBoxIconType::WarningIcon);
        }
        return;
    }

    // Khong hammer driver moi giay. Lan dau thu ngay; neu driver/USB
    // chua tro lai thi moi 4 giay thu lai mot lan (may khach chua tung mo duoc: 6 giay).
    if (audioWatchdogRetryCooldown > 0)
        return;

    const int attempt = audioWatchdogAttempts++;
    // 0.6.7.9: card da tung chay tot thi tang dan 4 -> 8 -> 16 -> 30 -> 60 giay (xem WatchdogPolicy.h),
    // khong "dap" driver moi 4 giay mai mai (ASIO Link Pro bi xep chong nhieu ban driver).
    audioWatchdogRetryCooldown = livent::watchdog::cooldownTicks (neverOpened, audioWatchdogAttempts);

    auto settings = PluginChain::getSettingsFolder();
    auto audio = settings.getChildFile ("audio.xml");
    auto lastGood = settings.getChildFile ("audio.lastgood.xml");

    juce::uint32 spentMs = 0;
    bool usedFallback = false;

    try
    {
        if (neverOpened && attempt >= 1)
        {
            usedFallback = true;
            spentMs += openAudioDeviceGuarded (nullptr,
                                               attempt >= 2 ? 0 : requestedAudioInputs,
                                               "watchdog default-device attempt " + juce::String (attempt));
        }
        else
        {
            // Thu dung CHINH cau hinh dang luu truoc. Neu USB chi chap/restart
            // ngan, driver thuong se mo lai ngay ma khong doi routing cua khach.
            auto saved = loadDeviceSettings();
            spentMs += openAudioDeviceGuarded (saved.get(), requestedAudioInputs,
                                               "watchdog saved attempt " + juce::String (attempt));

            // 0.6.7.9: neu last-good giong het cau hinh vua thu thi khong mo lan hai (nua so lan nap driver).
            if (! isAudioDeviceHealthy() && lastGood.existsAsFile() && ! lastGood.hasIdenticalContentTo (audio))
            {
                // Cau hinh moi khong mo duoc: quay ve last-good nhu duong cai dat
                // soundcard, nhung khong bung hop thoai modal giua buoi dien.
                lastGood.copyFileTo (audio);
                auto old = loadDeviceSettings();
                spentMs += openAudioDeviceGuarded (old.get(), requestedAudioInputs, "watchdog last-good");
            }
        }
    }
    catch (...)
    {
        // Watchdog la lop cuu ho. Driver nem exception thi giu DAW song va
        // de nhip sau thu lai, khong duoc de no keo app sap theo.
    }

    // Lan mo vua roi da chan giao dien > 5 giay -> dung thu lai day dac,
    // moi lan la mot lan cua so "Not Responding".
    audioWatchdogRetryCooldown = livent::watchdog::cooldownAfterSlowOpen (audioWatchdogRetryCooldown, spentMs);

    if (isAudioDeviceHealthy())
    {
        audioEverHealthy = true;
        audioWatchdogAttempts = 0;
        audioWatchdogFault = false;
        audioWatchdogBadTicks = 0;
        audioWatchdogRetryCooldown = 0;
        audioWatchdogRecoveredTicks = 3;
        statusLabel.setText (livent::vn ("ĐÃ KẾT NỐI LẠI SOUNDCARD"),
                             juce::dontSendNotification);
        statusLabel.setColour (juce::Label::textColourId, Col::green);

        if (usedFallback)
        {
            livent::stabilityLog ("AUDIO fallback-ok", "dang dung thiet bi mac dinh, attempt " + juce::String (attempt));
            livent::alert (livent::vn ("Đã dùng soundcard mặc định của máy"),
                           livent::vn ("Cấu hình soundcard đã lưu không mở được nên LiveNT chuyển sang thiết bị âm thanh mặc định của máy.")
                           + (attempt >= 2 ? livent::vn ("\nLần này chỉ có đầu ra (loa/tai nghe), chưa dùng được micro.") : juce::String())
                           + livent::vn ("\n\nNếu dùng soundcard rời, bấm \"Cài đặt soundcard\" để chọn lại."),
                           juce::MessageBoxIconType::InfoIcon);
        }

        inspector.rebuildRouting();
        refitInspector();
    }
}

void MainComponent::openPluginScanner()
{
    /*  MOC 24: bo han bang quet dung san cua JUCE (juce::PluginListComponent).

        Bang do bat anh chon quet VST3 hay VST2 rieng tung loai, kem mot menu
        "Options..." day muc khong dung toi. LiveNT thi lan nao cung muon quet
        het, nen buoc chon do chi la mot buoc thua.

        ScanDialog (file ScanDialog.h) la bang tu viet: MOT nut, bam la quet
        het moi dinh dang trong mot luot, va quet xong thi bao ket qua.  */
    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (new ScanDialog());
    o.dialogTitle = livent::vn ("Quét plugin");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = true;

    livent::bringDialogToFront (livent::launchDialog (o));
}

//=============================================================================
//  QUET TU DONG LUC KHOI DONG  (Moc 9)
//=============================================================================
void MainComponent::startBackgroundScan()
{
    // Dang quet do -> khong bung them cai nua
    if (startupScanner != nullptr && startupScanner->isThreadRunning())
        return;

    startupScanner = std::make_unique<StartupScanner>();
    startupScanReported = false;

    Splash::setStatus (livent::vn ("Đang kiểm tra VST mới..."));
    Splash::setProgress (0.18);
    Splash::setStep (Splash::Step::plugins, Splash::StepState::running,
                     juce::String (PluginChain::getKnownPlugins().getNumTypes()) + livent::vn (" VST đã có · kiểm tra VST mới"));

    /*  Cheo danh sach hien co sang ban rieng cua luong quet. PHAI goi o day --
        luong chinh -- truoc khi luong quet chay. Xem ghi chu dau StartupScan.h. */
    startupScanner->prepareOnMessageThread();

    /*  Priority::low: viec quet KHONG duoc gianh CPU voi luong am thanh.
        Cham vai giay khong sao, rot tieng moi la van de.  */
    startupScanner->startThread (juce::Thread::Priority::low);

    /*  V6.3.3: KHÔNG để một VST chậm/treo giữ người dùng ở Splash vô hạn.

        - Scanner vẫn là process/thread riêng và tiếp tục chạy nền.
        - Nếu quét xong trước 10 giây: luồng cũ đóng Splash ngay khi xong.
        - Nếu sau 10 giây vẫn đang quét: đóng Splash để Main.cpp hiện DAW,
          còn updateStartupScanProgress() tiếp tục hiện tiến trình ở thanh đáy.

        Không signalThreadShouldExit() ở đây: mục tiêu là CHO VÀO DAW TRƯỚC,
        không phải hủy quét. Plugin lỗi vẫn do OutOfProcessScanner timeout/kill. */
    {
        juce::Component::SafePointer<MainComponent> safeThis (this);

        juce::Timer::callAfterDelay (10000, [safeThis]
        {
            if (safeThis == nullptr)
                return;

            auto* scanner = safeThis->startupScanner.get();
            if (scanner == nullptr || ! scanner->isThreadRunning())
                return;

            // Splash có thể đã được đóng bởi một luồng hoàn tất khác.
            if (! Splash::isShowing())
                return;

            const auto progressText = livent::vn ("VST vẫn đang quét nền - đang vào bàn làm việc...");
            Splash::setStatus (progressText);
            Splash::forcePaintNow();

            // Chuẩn bị trạng thái trong DAW trước khi Splash biến mất.
            safeThis->startupScanProgressBar.setVisible (true);
            safeThis->statusLabel.setText (livent::vn ("Đang quét VST nền..."),
                                           juce::dontSendNotification);
            safeThis->resized();

            // Cho người dùng kịp thấy thông báo chuyển sang quét nền rồi vào DAW.
            juce::Timer::callAfterDelay (120, []
            {
                if (Splash::isShowing())
                    Splash::close();
            });
        });
    }
}

void MainComponent::updateStartupScanProgress()
{
    if (startupScanner == nullptr)
        return;

    if (startupScanner->isThreadRunning())
    {
        const auto progressText = startupScanner->getProgress();
        Splash::setStatus (progressText);

        const int done  = startupScanner->getNumFilesDone();
        const int total = startupScanner->getNumFilesTotal();
        startupScanProgressValue = total > 0 ? juce::jlimit (0.0, 1.0, (double) done / (double) total)
                                                 : -1.0;
        if (total > 0)
            Splash::setStep (Splash::Step::plugins, Splash::StepState::running,
                             livent::vn ("Quét VST mới ") + juce::String (done) + "/" + juce::String (total));

        // V6.3: splash hien tien trinh THAT, khong con dong theo dong ho 5s.
        Splash::setProgress (startupScanProgressValue >= 0.0
                                ? 0.18 + startupScanProgressValue * 0.78
                                : -1.0);

        /* Khi Splash da tat va nguoi dung dang o Hub/project, hien thanh tien
           trinh o DAY cua DAW. Nho vay scan chay lau van biet no dang lam gi. */
        const bool showInMain = ! Splash::isShowing();
        startupScanProgressBar.setVisible (showInMain);
        if (showInMain)
            statusLabel.setText (progressText, juce::dontSendNotification);
        resized();
        return;
    }

    //-- Vua quet xong -------------------------------------------------------
    if (startupScanReported)
        return;

    startupScanReported = true;
    startupScanProgressValue = 1.0;
    startupScanProgressBar.setVisible (false);
    resized();

    /*  MOC 40: KHONG bao so plugin quet duoc luc khoi dong nua.

        Con so do chi co nghia khi anh CHU DONG di quet - luc do anh dang
        cho xem ket qua. Con luc mo app thi no la mot con so nhay qua trong
        nua giay roi mat, khong lam gi duoc voi no, ma lai gay cam giac phai
        doc va doi chieu.

        Bang quet tu tay bam (ScanDialog) van bao day du nhu cu.  */
    Splash::setProgress (1.0);
    Splash::setStatus (livent::vn ("Sẵn sàng"));
    Splash::setStep (Splash::Step::plugins, Splash::StepState::done,
                     juce::String (PluginChain::getKnownPlugins().getNumTypes()) + livent::vn (" VST sẵn sàng"));
    Splash::setStep (Splash::Step::project, Splash::StepState::done);

    /* V6.3: chi den day moi dong splash. DAW KHONG lo ra trong luc scanner
       van con chay. */
    juce::Timer::callAfterDelay (320, [] { Splash::close(); });

    // 30/09: diet virus chan LiveNT-Scanner -> bao khach cach sua (sau khi vao DAW).
    if (startupScanner->looksBlockedByAntivirus())
    {
        const bool missing = startupScanner->isScannerMissing();
        juce::Timer::callAfterDelay (1500, [missing] { StartupScanner::showAntivirusWarning (missing); });
    }
}

//=============================================================================
//=============================================================================
//  MOC 41: THU AM
//=============================================================================
//=============================================================================
//  MOC 24: NOI DUNG THANH MENU
//
//  MenuBarModel lam viec theo kieu "hoi-dap": thanh menu KHONG giu san noi
//  dung, ma moi lan anh bam vao mot ten menu no lai hoi lai ba cau:
//
//     1. getMenuBarNames()   -- "tren thanh co nhung ten gi?"
//     2. getMenuForIndex()   -- "menu thu N xo xuong thi co nhung muc gi?"
//     3. menuItemSelected()  -- "nguoi ta vua bam vao muc so may."
//
//  Hoi lai MOI LAN bam la co chu y: nho vay dau tick (vd "Che do dien") va
//  danh sach "Mo gan day" luon dung voi trang thai HIEN TAI, khong bao gio
//  bi cu -- khong phai tu di cap nhat menu o cho nao khac.
//=============================================================================
void MainComponent::handleGlobalShortcut (int action)
{
    /* Duong nay LUON chay tren JUCE message thread (Main.cpp post callAsync).
       Goi lai dung mot xu ly keyPressed de local/global khong bao gio lech nhau. */
    if (! functionShortcutsReady)
        return;

    switch (action)
    {
        case 1: keyPressed (juce::KeyPress (juce::KeyPress::F2Key), this); break;
        case 2: keyPressed (juce::KeyPress (juce::KeyPress::F3Key), this); break;
        case 3: keyPressed (juce::KeyPress (juce::KeyPress::spaceKey), this); break;
        case 4: keyPressed (juce::KeyPress ('g'), this); break;
        case 5: keyPressed (juce::KeyPress ('h'), this); break;
        default: break;
    }
}

//=============================================================================
bool MainComponent::keyPressed (const juce::KeyPress& key, juce::Component*)
{
    return queueShortcut (key);
}

juce::String MainComponent::shortcutScope() const
{
    if (workWindow == nullptr) return "control";
    if (mixerVisible && (lastAreaWasMixer || (mixerWindow != nullptr && mixerWindow->isActiveWindow()))) return "f3";
    return "f2";
}

void MainComponent::rebuildShortcutCommands()
{
    std::vector<livent::shortcuts::Command> commands;
    auto add = [&] (const char* id, const char* name, const char* scope = "all")
    { commands.push_back ({ id, livent::vn (name), scope }); };
    add ("transport.toggle", "Thu/phát · Phát / Dừng");
    add ("transport.record", "Thu F2 · Bắt đầu thu");
    add ("transport.play", "Thu/phát · Phát"); add ("transport.stop", "Thu/phát · Dừng");
    add ("zoom.out", "Thu nhỏ vùng đang dùng (F2 / F3)"); add ("zoom.in", "Phóng to vùng đang dùng (F2 / F3)");
    add ("window.f2", "Mở / đóng bàn làm việc F2"); add ("window.f3", "Mở / đóng mixer F3");
    add ("window.settings", "Mở Cài đặt"); add ("window.compact", "Thu gọn / mở bảng Điều khiển");
    add ("clip.split", "Clip · Cắt tại đầu phát", "f2"); add ("clip.join", "Clip · Nối các đoạn đã chọn", "f2");
    add ("clip.mute", "Clip · Bật / tắt tiếng đoạn", "f2"); add ("clip.delete", "Clip · Xóa đoạn", "f2");
    add ("clip.duplicate", "Clip · Nhân bản", "f2"); add ("clip.all", "Clip · Chọn tất cả", "f2");
    add ("clip.undo", "Clip · Hoàn tác", "f2"); add ("clip.redo", "Clip · Làm lại", "f2");
    add ("clip.range", "Clip · Đặt vùng xuất", "f2"); add ("clip.clearRange", "Clip · Bỏ vùng xuất", "f2");
    add ("clip.escape", "Clip · Bỏ chọn / thoát công cụ cắt", "f2");
    add ("track.monitor", "Track đang chọn · Loa nghe nguồn trực tiếp");
    add ("track.mute", "Track đang chọn · Mute"); add ("track.solo", "Track đang chọn · Solo");
    add ("track.arm", "Track đang chọn · Cho phép thu F2");
    shortcutTargets.clear();
    auto button = [&] (const juce::String& id, const juce::String& name, juce::Button& b, const char* scope = "all")
    {
        commands.push_back ({ id, name, scope }); shortcutTargets.push_back ({ commands.back(), &b });
    };
    button ("main.file", livent::vn ("Tệp / Dự án"), topFileButton);
    button ("main.laugh", livent::vn ("Điều khiển · Tiếng cười"), topLaughButton);
    button ("main.export", livent::vn ("Xuất bản thu tổng"), topExportButton);
    button ("main.record", livent::vn ("Thu / dừng bản thu tổng (WET)"), topRecordButton);
    button ("main.song.save", livent::vn ("Điều khiển · Lưu bài"), topSaveSongButton);
    button ("main.song.list", livent::vn ("Điều khiển · Danh sách bài"), topSongListButton);
    // The control panel gives its named buttons stable IDs independent of translated labels.
    for (auto& pair : tonePanel.shortcutButtons()) button ("control." + pair.first, livent::vn ("Điều khiển · ") + (pair.second->getTitle().isNotEmpty() ? pair.second->getTitle() : pair.second->getButtonText().isNotEmpty() ? pair.second->getButtonText() : pair.second->getTooltip().upToFirstOccurrenceOf ("\n", false, false)), *pair.second);
    // Register the rest of the DAW's own buttons; plugin editor internals are excluded.
    std::function<void (juce::Component&, juce::String, juce::String, const char*)> walk;
    walk = [&] (juce::Component& c, juce::String path, juce::String label, const char* scope)
    {
        const auto stable = c.getProperties().getWithDefault ("shortcutStableId", juce::String()).toString();
        if (stable.isNotEmpty()) path = stable;
        if (auto* b = dynamic_cast<juce::Button*> (&c))
        {
            bool registered = false; for (const auto& t : shortcutTargets) if (t.button == b) registered = true;
            auto name = b->getTitle().isNotEmpty() ? b->getTitle() : b->getButtonText();
            if (name.isEmpty()) name = b->getTooltip().upToFirstOccurrenceOf ("\n", false, false);
            if (! registered && name.isNotEmpty()) button (path, label + " · " + name.substring (0, 90), *b, scope);
            return;
        }
        for (int i = 0; i < c.getNumChildComponents(); ++i)
            if (auto* child = c.getChildComponent (i)) walk (*child, path + "." + juce::String (i), label, scope);
    };
    walk (tonePanel, "control.extra", livent::vn ("Điều khiển"), "all");
    walk (timelineTransport, "timeline.button", "F2", "f2");
    walk (mixerView, "mixer.button", "F3", "f3");
    walk (inspector, "inspector.button", "Inspector", "f2");
    for (auto* row : trackRows) walk (*row, "track.button." + row->getTrack().getUuid(), row->getTrack().getName(), "f2");
    keyboardShortcuts.setCommands (std::move (commands));
}

bool MainComponent::queueShortcut (const juce::KeyPress& key)
{
    if (! functionShortcutsReady || livent::shortcuts::isTypingOrCapturing()
        || juce::Component::getNumCurrentlyModalComponents() > 0) return false;
    rebuildShortcutCommands();
    const auto id = keyboardShortcuts.match (key, shortcutScope());
    if (id.isEmpty()) return false;
    juce::Component::SafePointer<MainComponent> safe (this);
    juce::MessageManager::callAsync ([safe, id] { if (safe != nullptr) safe->executeShortcut (id); });
    return true;
}

bool MainComponent::executeShortcut (const juce::String& id)
{
    if (! functionShortcutsReady) return false;
    if (id == "window.f2") { toggleWorkPanels(); lastAreaWasMixer = false; return true; }
    if (id == "window.f3") { toggleMixerPanel(); if (mixerVisible) lastAreaWasMixer = true; return true; }
    if (id == "window.settings") { openSettingsDialog(); return true; }
    if (id == "window.compact") { if (projectOpen) toggleCompactMode(); return true; }
    if (id == "zoom.out" || id == "zoom.in")
    {
        if (workWindow == nullptr) return true;
        const int direction = id == "zoom.in" ? 1 : -1;
        if (shortcutScope() == "f3") mixerView.zoom (direction);
        else if (direction > 0) mixer.timelineZoomIn(); else mixer.timelineZoomOut();
        return true;
    }
    if (! projectOpen) return false;
    if (id == "transport.record")
    { if (! mixer.isTimelineRecording()) timelineTransport.performCommand (TimelineTransportBar::Command::record); return true; }
    if (id == "transport.play") { timelineTransport.performCommand (TimelineTransportBar::Command::play); return true; }
    if (id == "transport.stop") { timelineTransport.performCommand (TimelineTransportBar::Command::stop); return true; }
    if (id == "transport.toggle")
    {
        const bool wasRecording = mixer.isTimelineRecording(); mixer.toggleTimelinePlayback();
        if (wasRecording) { markProjectDirty(); updateTitleText(); } return true;
    }
    if (id.startsWith ("clip.") && workWindow != nullptr)
    {
        juce::KeyPress k;
        if (id == "clip.split") k = juce::KeyPress ('S');
        else if (id == "clip.join") k = juce::KeyPress ('N');
        else if (id == "clip.mute") k = juce::KeyPress ('M');
        else if (id == "clip.delete") k = juce::KeyPress (juce::KeyPress::deleteKey);
        else if (id == "clip.duplicate") k = juce::KeyPress ('D', juce::ModifierKeys::commandModifier, 0);
        else if (id == "clip.all") k = juce::KeyPress ('A', juce::ModifierKeys::commandModifier, 0);
        else if (id == "clip.undo") k = juce::KeyPress ('Z', juce::ModifierKeys::commandModifier, 0);
        else if (id == "clip.redo") k = juce::KeyPress ('Y', juce::ModifierKeys::commandModifier, 0);
        else if (id == "clip.range") k = juce::KeyPress ('P');
        else if (id == "clip.clearRange") k = juce::KeyPress ('P', juce::ModifierKeys::shiftModifier, 0);
        else if (id == "clip.escape") k = juce::KeyPress (juce::KeyPress::escapeKey);
        bool changed = false;
        const bool handled = k.isValid() && TrackWaveformView::handleEditKey (mixer, k, changed);
        if (changed) { markProjectDirty(); updateTitleText(); } return handled;
    }
    if (id.startsWith ("track."))
        if (auto* t = mixer.getTrack (selectedTrackIndex))
        {
            if (id == "track.monitor") t->setMonitor (! t->isMonitorOn());
            else if (id == "track.mute") t->setMute (! t->isMuted());
            else if (id == "track.solo") t->setSolo (! t->isSoloed());
            else if (id == "track.arm") mixer.setTrackRecordArmed (*t, ! mixer.isTrackRecordArmed (*t));
            else return false;
            markProjectDirty(); updateTitleText(); return true;
        }
    rebuildShortcutCommands();
    for (const auto& target : shortcutTargets)
        if (target.command.id == id && target.button != nullptr && target.button->isEnabled())
        { target.button->triggerClick(); return true; }
    return false;
}

void MainComponent::showExpandedEq(Track* source)
{
    if(!source)return;
    const auto uuid=source->getUuid();
    if(expandedEqWindow && expandedEqTrackUuid==uuid){expandedEqWindow->show();return;}
    expandedEqTrackUuid=uuid;
    auto panel=std::make_unique<ChannelEqPanel>(true);panel->setTrack(source);
    juce::Component::SafePointer<MainComponent> safe(this);
    panel->trackProvider=[safe,uuid]() -> Track*
    {if(safe)for(int i=0;i<safe->mixer.getNumTracks();++i)if(auto* t=safe->mixer.getTrack(i);t && t->getUuid()==uuid)return t;return nullptr;};
    panel->onChanged=[safe]{if(safe){safe->inspector.refreshFromTrack();safe->markProjectDirty();safe->updateTitleText();}};
    expandedEqWindow=std::make_unique<livent::UtilityWindow>(livent::vn("EQ — ")+source->getName(),std::move(panel),920,600);
    if(auto* w=dynamic_cast<juce::ResizableWindow*>(getTopLevelComponent()))expandedEqWindow->setAlwaysOnTop(w->isAlwaysOnTop());
    expandedEqWindow->show();
}
#if JUCE_WINDOWS
void MainComponent::showAudioSetupGuide()
{
    if(!audioGuideWindow)
    {
        audioGuideWindow=std::make_unique<livent::UtilityWindow>(livent::vn("Thiết lập âm thanh — 6 bước"),std::make_unique<AudioSetupGuide>(),1020,760);
        audioGuideWindow->getProperties().set("liventAudioSetupGuide",true);
        audioGuideWindow->setResizeLimits(760,540,2400,1800);
        audioGuideWindow->setAlwaysOnTop(true);
    }
    audioGuideWindow->show();
}
#endif

bool MainComponent::canRunHeavyWork()
{
    if(!projectOpen)return false;
    if(pluginLoadInProgress || importJobs>0){livent::alert(livent::vn("Đóng gói / Render"),livent::vn("Chờ nạp VST / nhập audio xong trước khi làm bước này."));return false;}
    if(mixer.isTimelinePlaying() || mixer.isTimelineRecording() || mixer.isMasterRecording() || mixer.isOfflineExporting() || mixer.hasPendingTakes())
    {livent::alert(livent::vn("Đóng gói / Render"),livent::vn("Dừng phát, thu và chờ bản thu chốt xong trước khi làm bước này."));return false;}
    for(int i=0;i<mixer.getNumTracks();++i)if(auto* t=mixer.getTrack(i))
    {
        const bool connected=t->getSource()!=Track::Source::TrackTap||t->getInputTrackId()>0;
        if(t->isPlaying() || ((t->getType()==Track::Type::Audio||t->getType()==Track::Type::Beat)&&t->isMonitorOn()&&connected&&t->getSource()!=Track::Source::AudioFile))
        {livent::alert(livent::vn("Đóng gói / Render"),livent::vn("Tắt loa Monitor của các track Mic/Nhạc vào và dừng file đang phát trước khi render / đóng gói. Bước này dùng CPU và ổ đĩa, dành cho lúc nghỉ hát live."));return false;}
    }
    return true;
}
void MainComponent::packageProject()
{
    if(!canRunHeavyWork())return;
    juce::Component::SafePointer<MainComponent> safe(this);
    livent::confirm3(livent::vn("Đóng gói dự án"),livent::vn("Gom project và tất cả audio gốc. Có kèm WAV tham chiếu sau EQ / VST / Send / Master không?"),livent::vn("Kèm WAV"),livent::vn("Chỉ project"),livent::vn("Hủy"),[safe](int result)
    {
        if(!safe||result==0||!safe->canRunHeavyWork())return;
        safe->packageChooser=std::make_unique<juce::FileChooser>(livent::vn("Lưu gói project ZIP"),(safe->currentProjectFile==juce::File()?juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("LiveNT_Project.zip"):safe->currentProjectFile.getSiblingFile("LiveNT_Project.zip")),"*.zip",true);
        safe->packageChooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting,[safe,reference=result==1](const juce::FileChooser& fc){if(safe&&fc.getResult()!=juce::File())safe->beginPackageProject(fc.getResult().withFileExtension("zip"),reference);});
    });
}
void MainComponent::beginPackageProject(const juce::File& destination,bool reference)
{
    if(!canRunHeavyWork())return;
    if(packageWorker.joinable())packageWorker.join();
    auto state=buildProjectStateXml(true);if(!state)return;
    std::shared_ptr<Mixer> renderer;double length=0;
    if(reference)
    {
        const auto error=mixer.getAra().offlineRenderError();if(error.isNotEmpty()){livent::alert(livent::vn("WAV tham chiếu"),error);return;}
        renderer=std::make_shared<Mixer>();renderer->prepare(48000,512);
        if (! renderer->setState (*state, false))
        {
            livent::alert (livent::vn ("WAV tham chiếu"),
                           livent::vn ("Không nạp được project để render. Gói chưa được tạo."));
            return;
        }
        for(int i=0;i<renderer->getNumTracks();++i)if(auto* t=renderer->getTrack(i))
        {const auto errors=t->getInserts().getLoadWarnings();if(!errors.isEmpty()){livent::alert(livent::vn("WAV tham chiếu"),errors.joinIntoString("\n"));return;}if(t->getSource()==Track::Source::AudioFile)length=juce::jmax(length,t->getLengthSeconds());}
        renderer->getAra().setLoadingAllowed(true);renderer->syncAra();
        auto archive=state->getChildByName("ARA_SESSIONS");
        const auto araError=renderer->getAra().takeLastError();if(araError.isNotEmpty()){livent::alert(livent::vn("WAV tham chiếu"),araError);return;}
        const auto verified=renderer->getAra().acceptVerifiedOfflineSnapshot(archive);if(verified.isNotEmpty()){livent::alert(livent::vn("WAV tham chiếu"),verified);return;}
        length=juce::jmax(length,renderer->getTimelineLengthSeconds());
        if(length<=0){livent::alert(livent::vn("WAV tham chiếu"),livent::vn("Chưa có audio trong project. Chọn Chỉ project để đóng gói."));return;}
        const auto prepared=renderer->beginOfflineExport(0,length);if(prepared.isNotEmpty()){livent::alert(livent::vn("WAV tham chiếu"),prepared);return;}
    }
    auto job=std::make_shared<livent::portable::Job>(std::move(state),destination,keyboardShortcuts.xml());packageJob=job;mixer.setBackgroundWorkActive(true);
    statusLabel.setText(livent::vn("Đang đóng gói project…"),juce::dontSendNotification);
    auto* progress=livent::makeAlert(livent::vn("Đóng gói project"),livent::vn("Đang gom audio và tạo ZIP. Xin chờ; có thể hủy an toàn."),juce::MessageBoxIconType::NoIcon);
    progress->addButton(livent::vn("Hủy"),0);progress->setAlwaysOnTop(true);livent::centreDialog(progress);
    progress->enterModalState(true,juce::ModalCallbackFunction::create([job,progress](int result){if(result==0)job->cancel.store(true);delete progress;}),false);
    juce::Component::SafePointer<MainComponent> safe(this);juce::Component::SafePointer<juce::AlertWindow> dialog(progress);
    packageWorker=std::thread([safe,dialog,job,renderer,length,destination]
    {
        try
        {
            if(renderer) {job->error=renderer->renderOfflineExport(job->referenceFile(),0,length,2.0,job->cancel,job->progress);renderer->endOfflineExport();}
            if(job->error.isEmpty()&&!job->cancel.load())job->run();
        }
        catch(const std::exception& e){job->error=livent::vn("Không đóng gói được: ")+juce::String(e.what());}
        catch(...){job->error=livent::vn("Plugin / file không xử lý được khi đóng gói.");}
        juce::MessageManager::callAsync([safe,dialog,job,renderer,destination]
        {
            if(dialog)dialog->exitModalState(1);
            if(!safe)return;
            if(safe->packageWorker.joinable())safe->packageWorker.join();safe->mixer.setBackgroundWorkActive(false);safe->packageJob.reset();
            if(job->cancel.load())safe->statusLabel.setText(livent::vn("Đã hủy đóng gói."),juce::dontSendNotification);
            else if(job->error.isNotEmpty())livent::alert(livent::vn("Đóng gói project"),job->error);
            else {safe->statusLabel.setText(livent::vn("Đã đóng gói project."),juce::dontSendNotification);livent::alert(livent::vn("Đã tạo ZIP"),destination.getFullPathName());}
        });
    });
}

void MainComponent::joinTimelineClips (const juce::StringArray& ids, bool renderInPlace)
{
    if (!canRunHeavyWork())return;
    if (clipJoinJob != nullptr) { livent::alert (livent::vn ("Nối đoạn"), livent::vn ("Đang nối các đoạn đã chọn.")); return; }
    if (clipJoinWorker.joinable()) clipJoinWorker.join();
    auto job = std::make_shared<livent::joining::Job>();
    const auto error = job->prepare (mixer, ids, renderInPlace);
    if (error.isNotEmpty()) { livent::alert (livent::vn ("Nối đoạn"), error); return; }
    clipJoinJob = job;
    auto* window=livent::makeAlert(livent::vn(renderInPlace?"Render tại chỗ":"Nối đoạn"),livent::vn("Đang xử lý audio; có thể hủy an toàn."),juce::MessageBoxIconType::NoIcon);
    window->addButton(livent::vn("Hủy"),0);window->setAlwaysOnTop(true);livent::centreDialog(window);
    window->enterModalState(true,juce::ModalCallbackFunction::create([window,job](int result){if(result==0)job->cancel.store(true);delete window;}),false);
    juce::Component::SafePointer<juce::AlertWindow> dialog(window);
    mixer.setBackgroundWorkActive(true);
    statusLabel.setText (livent::vn ("Đang nối các đoạn đã chọn…"), juce::dontSendNotification);
    juce::Component::SafePointer<MainComponent> safe (this);
    clipJoinWorker = std::thread ([safe, job, dialog, renderInPlace]
    {
        job->render();
        juce::MessageManager::callAsync ([safe, job, dialog, renderInPlace]
        {
            if(dialog)dialog->exitModalState(1);
            if (safe == nullptr) return;
            if (safe->clipJoinWorker.joinable()) safe->clipJoinWorker.join();
            safe->mixer.setBackgroundWorkActive(false);
            if(job->cancel.load()){safe->clipJoinJob.reset();safe->statusLabel.setText(livent::vn("Đã hủy xử lý audio."),juce::dontSendNotification);return;}
            if (job->error.isNotEmpty()) livent::alert (livent::vn ("Nối đoạn"), job->error);
            else if (job->apply (safe->mixer)) { safe->rebuildTrackList(); safe->markProjectDirty(); safe->updateTitleText(); safe->statusLabel.setText (livent::vn(renderInPlace?"Đã render sang track sạch; đoạn gốc được giữ và tắt tiếng.":"Đã nối các đoạn thành một clip."), juce::dontSendNotification); }
            else livent::alert (livent::vn ("Nối đoạn"), livent::vn ("Các đoạn đã thay đổi trong lúc nối. Chọn lại và nối lần nữa."));
            safe->clipJoinJob.reset();
        });
    });
}

//=============================================================================
// V5.8.7 - GHIM CUA SO CHINH
//=============================================================================
void MainComponent::ChildWindowRaiser::timerCallback()
{
    if (paused && paused()) return;
    seen.erase (std::remove_if (seen.begin(), seen.end(),
                                [] (const auto& p) { return p == nullptr || ! p->isShowing(); }),
                seen.end());

    auto& desktop = juce::Desktop::getInstance();
    auto* main = mainWindow ? mainWindow() : nullptr;
    int decided = -1;   // -1 = chua hoi shouldFloat() (doc file) trong nhip nay

    for (int i = 0; i < desktop.getNumComponents(); ++i)
    {
        auto* c = desktop.getComponent (i);
        if (c == nullptr || c == main || ! c->isShowing())
            continue;

        if (dynamic_cast<juce::TooltipWindow*> (c) != nullptr)
            continue;
        // A menu owns its own lifetime and input focus. Assigning the DAW
        // as owner, or activating it from this timer, can dismiss VST popups.
        if (auto* peer = c->getPeer())
            if ((peer->getStyleFlags() & juce::ComponentPeer::windowIsTemporary) != 0)
                continue;
        if ((bool) c->getProperties().getWithDefault ("liventIndependentWindow", false)) continue;
        livent::ownFloatingWindow (*c, main);

        if (std::any_of (seen.begin(), seen.end(), [c] (const auto& p) { return p.getComponent() == c; }))
            continue;

        seen.emplace_back (c);

        // Editors are owned by the DAW; their own GHIM setting is respected.
        if (c->isAlwaysOnTop()
            || dynamic_cast<juce::TooltipWindow*> (c) != nullptr
            || dynamic_cast<PluginWindow*> (c) != nullptr)
            continue;

        if (decided < 0)
            decided = (shouldFloat && shouldFloat()) ? 1 : 0;

        if (decided == 1)
        {
            c->setAlwaysOnTop (true);
            c->toFront (false);
        }
    }
}

bool MainComponent::loadMainAlwaysOnTopPreference()
{
    const auto f = PluginChain::getSettingsFolder().getChildFile ("main-always-on-top.txt");
    return ! f.existsAsFile() || f.loadFileAsString().trim() != "0";  // mặc định BẬT
}

void MainComponent::saveMainAlwaysOnTopPreference (bool on)
{
    auto f = PluginChain::getSettingsFolder().getChildFile ("main-always-on-top.txt");
    f.getParentDirectory().createDirectory();
    f.replaceWithText (on ? "1" : "0");
}

//=============================================================================
// V5.8.1 - NUT LUU / DANH SACH TREN THANH MENU MONG (WINDOWS)
//=============================================================================
void MainComponent::setupMenuActionButtons()
{
    // V6.4.0: thanh tren duy nhat: [logo] [ban quyen] ... [Thu Am] [Cuoi]
    // [Luu bai] [Danh sach] [Cai dat] va nut cua so. Khong con menu chu.
   #if ! JUCE_MAC
    closeAppButton.onClick = [this] { confirmCloseAndQuit(); };
    minimiseAppButton.onClick = [this]
    {
        if (auto* w = dynamic_cast<juce::ResizableWindow*> (getTopLevelComponent()))
            w->setMinimised (true);
    };
    addAndMakeVisible (minimiseAppButton);
    addAndMakeVisible (closeAppButton);
   #endif

    // Logo dung cho ca Windows va macOS.
    logoImage = [] () -> juce::Image
    {
       #if LIVENT_THEME_HAS_BINARYDATA
        for (int i = 0; i < BinaryData::namedResourceListSize; ++i)
            if (juce::String (BinaryData::originalFilenames[i]) == "logo.png")
            {
                int size = 0;
                if (auto* data = BinaryData::getNamedResource (BinaryData::namedResourceList[i], size))
                    return juce::ImageCache::getFromMemory (data, size);
            }
       #endif
        return {};
    }();
    projectHub.setLogo (logoImage);   // 06/10: man Tao / Mo du an mau A

    topBrandLabel.setText (juce::String::fromUTF8 (livent::branding::topBrandText),
                           juce::dontSendNotification);
    topBrandLabel.setFont (brandTitleFont (18.0f, 31.0f));
    topBrandLabel.setColour (juce::Label::textColourId, Col::text);
    topBrandLabel.setJustificationType (juce::Justification::centredLeft);
    topBrandLabel.setInterceptsMouseClicks (false, false);
    addAndMakeVisible (topBrandLabel);

    if constexpr (livent::branding::foldArrowOnStatusBar)
        addChildComponent (tonePanel.getStatusFoldButton());   // TonePanel tu bat/tat hien

    for (auto* l : { &projectNameLabel, &cpuLabel })
    {
        l->setFont (juce::Font (juce::FontOptions (12.5f)));
        l->setMinimumHorizontalScale (1.0f);
        l->setInterceptsMouseClicks (true, false);
        addAndMakeVisible (*l);
    }

    projectNameLabel.setJustificationType (juce::Justification::centredRight);
    projectNameLabel.setColour (juce::Label::textColourId, Col::text);
    cpuLabel.setJustificationType (juce::Justification::centredRight);
    cpuLabel.setColour (juce::Label::textColourId, Col::textDim);

    auto setup = [this] (juce::TextButton& b, const juce::String& text)
    {
        b.setButtonText (text);
        b.setColour (juce::TextButton::buttonColourId, Col::panel);
        b.setColour (juce::TextButton::buttonOnColourId, Col::raised);
        b.setColour (juce::TextButton::textColourOffId, Col::text);
        b.setColour (juce::TextButton::textColourOnId, Col::text);
        b.setWantsKeyboardFocus (false);
        addAndMakeVisible (b);
    };

    // THU AM - nut master record cu trong TonePanel duoc an, logic ghi giu nguyen.
    setup (topRecordButton, livent::vn ("Thu Âm"));
    topRecordButton.getProperties().set ("toolbarIcon", 1); // cham thu am ve vector
    topRecordButton.setClickingTogglesState (true);
    topRecordButton.setColour (juce::TextButton::buttonOnColourId, juce::Colour (0xff9b252b));
    topRecordButton.setTooltip (livent::vn ("Bắt đầu/dừng thu âm master"));
    topRecordButton.onClick = [this]
    {
        if (mixer.isMasterRecording())
            stopMasterRecording();
        else
            startMasterRecording();
    };

    // V6.6.5: XUAT da chuyen xuong thanh transport, ngay canh THU/DUNG/PHAT.
    // Giu member cu de project/source cu khong bi xao tron ABI noi bo, nhung khong hien tren thanh tren.
    topExportButton.setVisible (false);

    setup (topLaughButton, livent::vn ("Cười"));
    topLaughButton.getProperties().set ("toolbarIcon", 2); // mat cuoi ve vector (thanh gon: co chu "Cười")
    topLaughButton.getProperties().set ("imageIcon", livent::toolbaricons::laugh);   // 15/10: anh mat cuoi (khong chu)
    topLaughButton.setTooltip (livent::vn ("Tiếng cười · chuột phải: chọn bảng tiếng cười của DAW hoặc app tiếng cười ngoài"));
    topLaughButton.setClickingTogglesState (true);
    topLaughButton.setToggleState (tonePanel.isLaughPanelOpen(), juce::dontSendNotification);
    tonePanel.onLaughPopupChanged = [this] (bool on)
    {
        topLaughButton.setToggleState (on, juce::dontSendNotification);
    };

    topLaughButton.onClick = [this] { pressLaughButton(); };
    topLaughButton.onRightClick = [this] { showLaughMenu(); };

    setup (topSaveSongButton, livent::vn ("Lưu bài"));
    topSaveSongButton.getProperties().set ("toolbarIcon", 3); // dia mem ve vector
    topSaveSongButton.setTooltip (livent::vn ("Lưu / sửa tông và mốc tự động của bài. Chuột phải: bật/tắt tự động lưu bài"));
    topSaveSongButton.onClick = [this] { tonePanel.openSaveSongDialog(); };
    topSaveSongButton.onRightClick = [this] { tonePanel.openSongAutoSaveOptions(); };

    setup (topSongListButton, livent::vn ("Danh sách bài"));
    topSongListButton.getProperties().set ("toolbarIcon", 4); // danh sach ve vector
    topSongListButton.setTooltip (livent::vn ("Mở danh sách bài hát đã lưu"));
    topSongListButton.onClick = [this] { tonePanel.openSongLibraryWindow(); };

    setup (topYouTubeButton, "YouTube");
    topYouTubeButton.getProperties().set ("imageIcon", livent::toolbaricons::youtube);   // 15/10
    topYouTubeButton.setTooltip (livent::vn ("Mở YouTube · chuột phải: chọn mở bằng cửa sổ YouTube của DAW hoặc trình duyệt"));
    topYouTubeButton.onClick = [this] { pressYouTubeButton(); };
    topYouTubeButton.onRightClick = [this] { showYouTubeMenu(); };

    // Danh sach bai (SongLibrary) mo bai trong cua so YouTube cua DAW.
    YouTubeLauncher::openInDawHandler = [this] (const juce::String& url, juce::String& error)
    {
        publishDawWindowForYouTube();
        return youtube.openOrBringToFront (error, url);
    };
    // 15/10: nut YouTube luon hien (che do trinh duyet: bam = mo trinh duyet vao youtube.com).
    topYouTubeButton.setVisible (true);

    // 15/10: cong tac LIVE | THU nam canh cum Dung/Phat/Thu (TimelineTransportIcons so huu).
    modeSwitch.setLive (mixer.isLiveMode());
    modeSwitch.onPick = [this] (bool live)
    {
        setLiveMode (live);       // co the tu choi (dang thu...) -> keo cong tac ve dung trang thai that
        refreshModeSwitch();
    };

    // Nut "Luu bai" / "Danh sach" tren cua so YouTube.
    youtube.onWindowCommand = [this] (const juce::String& cmd) { handleYouTubeWindowCommand (cmd); };
    youtube.stateProvider   = [this] { return tonePanel.getRemoteStateText(); };
    youtube.setListeningForWindowCommands (livent::youtube::useDawYouTube());

    // HOTFIX15: dua menu Tep ra thanh nut nhanh, dat ngay canh Danh sach.
    // Van dung CHUNG menu/handler cu de khong sinh hai bo logic Tep khac nhau.
    setup (topFileButton, livent::vn ("Dự án"));   // 15/10: "Tệp" -> "Dự án" cho 4 nut deu nhau
    topFileButton.setTooltip (livent::vn ("Dự án: tạo, mở, lưu và đóng dự án"));
    topFileButton.onClick = [safeThis = juce::Component::SafePointer<MainComponent> (this)]
    {
        if (safeThis == nullptr)
            return;

        auto menu = safeThis->getMenuForIndex (MainComponent::menuFile, livent::vn ("Tệp"));
        juce::PopupMenu::Options options;
        options = options.withTargetComponent (&safeThis->topFileButton);

        menu.showMenuAsync (options, [safeThis] (int result)
        {
            if (safeThis != nullptr && result != 0)
                safeThis->menuItemSelected (result, MainComponent::menuFile);
        });
    };

    setup (topSettingsButton, livent::vn ("Cài đặt"));
    topSettingsButton.getProperties().set ("toolbarIcon", 5);   // 06/10: banh rang vector (chu ⚙ bi to)
    topSettingsButton.getProperties().set ("imageIcon", livent::toolbaricons::settings);   // 15/10: anh banh rang
    topSettingsButton.setTooltip (livent::vn ("Cài đặt"));
    topSettingsButton.setClickingTogglesState (false);
    topSettingsButton.onClick = [this] { openSettingsDialog(); };

    // 06/10: nut "?" doi thanh "▾ Gon" - thu bang dieu khien thanh thanh gon
    // 2 hang (mau 1B). Che do huong dan (re chuot) + huong dan chi tiet chuyen
    // vao Cai dat > Ban quyen.
    setup (topHelpButton, {});
    topHelpButton.getProperties().set ("captionIcon", 3);   // 15/10: o vuong tren thanh tieu de = Gon
    topHelpButton.setClickingTogglesState (false);
    topHelpButton.onClick = [this]
    {
        if (std::exchange (suppressGonClick, false))
            return;   // 07/10 _F: chuot phai = menu chon mep, khong thu gon ngay
        toggleCompactMode();
    };
    topHelpButton.setTooltip (livent::vn ("Thu gọn bảng điều khiển (F8) · chuột phải: chọn sát mép dưới / trên / tự do"));
    topHelpButton.addMouseListener (&gonRightClick, false);
    helpOverlay.exitButton = nullptr;

    compactExpandButton.setButtonText ({});
    compactExpandButton.getProperties().set ("squareIcon", 1);   // 15/10: 1 o vuong = dang thu gon, bam de mo lai
    compactExpandButton.setTooltip (livent::vn ("Mở lại giao diện đầy đủ (F8)"));
    compactExpandButton.getProperties().set ("liveChipStyle", true);
    compactExpandButton.setWantsKeyboardFocus (false);
    compactExpandButton.onClick = [this]
    {
        juce::Component::SafePointer<MainComponent> safe (this);
        juce::MessageManager::callAsync ([safe] { if (safe != nullptr) safe->toggleCompactMode(); });
    };
    addChildComponent (compactExpandButton);
    compactCloseButton.setButtonText ({});
    compactCloseButton.getProperties().set ("powerIcon", 1);
    compactCloseButton.setTooltip (livent::vn ("Đóng phần mềm"));
    compactCloseButton.getProperties().set ("liveChipStyle", true);
    compactCloseButton.setColour (juce::TextButton::textColourOffId, juce::Colours::white);
    compactCloseButton.setWantsKeyboardFocus (false);
    compactCloseButton.onClick = [this] { confirmCloseAndQuit(); };
    addChildComponent (compactCloseButton);
    compactMode = loadCompactPref();
    loadCompactPlace();
    tonePanel.setCompactMode (compactMode);
    helpOverlay.onExit = [this] { setHelpMode (false); };
    addChildComponent (helpOverlay);
    setupTopHelpTexts();

    // V0.6.7.9: mot cham doi bo cuc Ngang <-> Doc (giong nut Ngang/Doc hay
    // gap tren app live). Doi xong cua so tu thu gon dung kich thuoc.
    setup (topLayoutButton, livent::vn ("Dọc"));
    topLayoutButton.setClickingTogglesState (false);
    topLayoutButton.onClick = [this]
    {
        juce::Component::SafePointer<MainComponent> safe (this);
        // doi o tick sau de khong huy/di chuyen nut dang chay callback
        juce::MessageManager::callAsync ([safe]
        {
            if (safe == nullptr)
                return;
            safe->setVerticalControlLayout (! safe->verticalControlLayout, true, false);
            safe->refreshTopLayoutButton();
        });
    };
    refreshTopLayoutButton();

    refreshTopRecordButton();
}

void MainComponent::refreshTopLayoutButton()
{
    // Nut ghi che do SE CHUYEN SANG, de bam la biet ngay dieu gi xay ra.
    // Doc: chi ve icon khung ngang (Theme.h "layoutIcon") cho gon; Ngang: chu "Doc".
    // 15/10: bieu tuong kieu thanh tieu de: khung DUNG (sang Doc) / khung NGANG (ve Ngang).
    topLayoutButton.getProperties().set ("layoutIcon", 0);
    topLayoutButton.getProperties().set ("captionIcon", verticalControlLayout ? 2 : 1);
    topLayoutButton.setButtonText ({});
    topLayoutButton.repaint();
    topLayoutButton.setTooltip (verticalControlLayout
                                  ? livent::vn ("Chuyển bảng điều khiển sang NGANG")
                                  : livent::vn ("Chuyển bảng điều khiển sang DỌC (hẹp, đặt cạnh màn hình)"));
}

void MainComponent::refreshTopRecordButton()
{
    const bool recording = mixer.isMasterRecording();
    topRecordButton.setToggleState (recording, juce::dontSendNotification);
    topRecordButton.setButtonText (livent::vn (compactUiActive() ? "Thu" : "Thu Âm"));
}

juce::StringArray MainComponent::getMenuBarNames()
{
    return { livent::vn ("Tệp"), livent::vn ("Công cụ"), livent::vn ("Hiển thị"),
             livent::vn ("Bản quyền") };
}

juce::PopupMenu MainComponent::getMenuForIndex (int index, const juce::String&)
{
    juce::PopupMenu m;

    if (index == menuFile)
    {
        // Full layout exposes songs next to Settings on the bottom bar.
        // The compact strip keeps menu access because its bottom bar is hidden.
        if (compactUiActive())
        {
            m.addSectionHeader (livent::vn ("Bài hát"));
            m.addItem (110, livent::vn ("Lưu bài..."));
            m.addItem (111, livent::vn ("Danh sách bài hát..."));
            m.addItem (112, livent::vn ("Tự động lưu bài..."));
            m.addSeparator();
        }

        m.addSectionHeader (livent::vn ("Dự án"));
        m.addItem (101, livent::vn ("Dự án mới"));
        m.addSeparator();
        m.addItem (102, livent::vn ("Lưu"));
        m.addItem (103, livent::vn ("Lưu thành..."));
        m.addSeparator();
        m.addItem (106, livent::vn ("Lưu thông số làm mặc định"),
                   projectOpen && currentProjectFile != juce::File());
        m.addItem (107, livent::vn ("Khôi phục thông số mặc định"),
                   projectOpen && getDefaultMixFile().existsAsFile());
        m.addSeparator();
        m.addItem (104, livent::vn ("Mở file .NT..."));
        m.addItem (105, livent::vn ("Đóng dự án"), projectOpen);
        m.addItem (113, livent::vn ("Lưu dự án hiện tại làm mẫu máy này"), projectOpen);
        m.addSeparator();
        // 14/10: don dep du an thu am
        m.addItem (117, livent::vn ("Dọn file thu không dùng..."),
                   projectOpen && currentProjectFile != juce::File());
        m.addItem (116, livent::vn ("Xóa dự án thu âm..."));
        m.addSeparator();

        // V6.5.3: toàn bộ mục từng nằm ở tab "Dự án" của Cài đặt được gom
        // về đúng chỗ là nút Tệp. Như vậy Cài đặt chỉ còn các thiết lập hệ
        // thống, còn thao tác dự án nằm một nơi duy nhất.
        m.addItem (305, livent::vn ("Tự động lưu (mỗi 60 giây)"), true, autosaveEnabled);
        m.addItem (308, livent::vn ("Bài mới: tự về tông 0"), true, tonePanel.isResetToneOnNewSong());
        m.addItem (501, livent::vn ("Mở thư mục cài đặt"));
        m.addItem (114, windowsLowered ? livent::vn ("Cho phần mềm nổi lại ngay")
                                       : livent::vn ("Tạm hạ phần mềm xuống 60 giây (nhập key VST)"));
        m.addItem (115, livent::vn ("Hướng dẫn sử dụng..."));
        m.addSeparator();

        if (recentFiles.getNumFiles() > 0)
        {
            juce::PopupMenu recentMenu;

            for (int i = 0; i < recentFiles.getNumFiles(); ++i)
                recentMenu.addItem (900 + i, recentFiles.getFile (i).getFileName(),
                                    recentFiles.getFile (i).existsAsFile());

            m.addSubMenu (livent::vn ("Mở gần đây"), recentMenu);
        }

        m.addSeparator();
        m.addItem (109, livent::vn ("Thoát"));
    }
    else if (index == menuStudio)
    {
        m.addItem (301, livent::vn ("Thiết lập âm thanh...  (F4)"));   // 15/10: gop soundcard + duong am thanh
        m.addItem (307, livent::vn ("Bắn Key/Scale vào track..."));
        m.addSeparator();
        m.addItem (302, livent::vn ("Quét plugin..."));
        m.addItem (303, livent::vn ("Thư mục quét plugin..."));
        m.addSeparator();

        // Tham so thu 3 = bat/tat muc, thu 4 = co dau tick hay khong
        m.addItem (304, livent::vn ("Chế độ điện (tiết kiệm CPU)"),
                   true, pluginWindows.isPerformanceMode());
        m.addItem (309, livent::vn ("An toàn giao diện VST (khuyên dùng)"),
                   true, loadVstGuiSafeModePref());
        m.addItem (320, livent::vn ("Ưu tiên độ trễ thấp khi hát live (nhạc không kéo trễ míc)"),
                   true, mixer.isLowLatencyLive());
        m.addItem (321, livent::vn ("Bù trễ thu âm / đo trễ card..."));

       #if JUCE_MAC
        /*  MOC 66e: chon dung 1 trinh duyet de do Tone tim toi - do "quet
            gat ca 5 cai" thanh "hoi dung 1 cai", tiet kiem CPU (gop y cua
            Tinh). "Tu do doan" = cach cu, thu lan luot ca 5.  */
        juce::PopupMenu browserMenu;
        const auto currentBrowser = tonePanel.getPreferredBrowser();

        browserMenu.addItem (311, "YouTube",        true, currentBrowser == "YouTube");
        browserMenu.addItem (312, "Brave Browser",  true, currentBrowser == "Brave Browser");
        browserMenu.addItem (313, "Google Chrome",  true, currentBrowser == "Google Chrome");
        browserMenu.addItem (316, "Microsoft Edge", true, currentBrowser == "Microsoft Edge");
        browserMenu.addItem (314, "CocCoc",         true, currentBrowser == "CocCoc");
        browserMenu.addItem (315, "Safari",         true, currentBrowser == "Safari");

        m.addSubMenu (livent::vn ("Trình duyệt để dò Tone"), browserMenu);
       #endif

        //  V6.0: Tro giup khong con nam rieng tren thanh menu
        m.addSeparator();
        juce::PopupMenu helpMenu;
        helpMenu.addItem (502, livent::vn ("Mở nhật ký quét plugin (scanlog.txt)"));
        helpMenu.addItem (503, livent::vn ("Mở nhật ký ổn định (Documents)"));
        m.addSubMenu (livent::vn ("Trợ giúp"), helpMenu);
    }
    else if (index == menuView)
    {
        juce::PopupMenu zoomMenu;
        const double current = loadUiScale();
        zoomMenu.addItem (410, "75%",              true, std::abs (current - 0.75) < 0.01);
        zoomMenu.addItem (411, "90%",              true, std::abs (current - 0.9)  < 0.01);
        zoomMenu.addItem (412, livent::vn ("100% (mặc định)"),  true, std::abs (current - 1.0)  < 0.01);
        zoomMenu.addItem (413, "110%",             true, std::abs (current - 1.1)  < 0.01);
        zoomMenu.addItem (414, "125%",             true, std::abs (current - 1.25) < 0.01);
        m.addSubMenu (livent::vn ("Thu phóng giao diện"), zoomMenu);

        // 14/10: co chu RIENG cho Cai dat va Huong dan (man hinh to, chu nho)
        {
            juce::PopupMenu textMenu;
            const double ts = livent::textscale::get();
            const struct { int id; double v; const char* name; } sizes[] =
                { { 430, 1.0, "100% (mặc định)" }, { 431, 1.15, "115%" }, { 432, 1.3, "130%" },
                  { 433, 1.5, "150%" }, { 434, 1.75, "175%" }, { 435, 2.0, "200%" } };
            for (const auto& sz : sizes)
                textMenu.addItem (sz.id, livent::vn (sz.name), true, std::abs (ts - sz.v) < 0.01);
            m.addSubMenu (livent::vn ("Cỡ chữ Cài đặt / Hướng dẫn"), textMenu);
        }

        m.addSeparator();

        /*  MOC 75: bon thu PHU deu an/hien duoc. Bang dieu khien khong co
            trong danh sach nay vi no la giao dien chinh - luon hien.  */
        //  MOC 78: bo muc "Thanh menu tren cung" - thanh menu da gan cung
        //  luon hien, giu mot cong tac khong tat duoc gi chi lam roi mat.
        /*  MOC 93: hai muc "Danh sach track" va "Bang Insert/Send" da gop
            lam MOT - chung mo/dong cung mot cua so Ban lam viec, tach ra hai
            dong chi lam nguoi dung tuong la hai thu rieng. Ma so 401 khong
            con duoc dung (menuItemSelected van giu case 401 tro toi cung
            mot ham, phong file .NT / phim tat cu con goi toi).  */
        m.addItem (404, livent::vn ("Bàn làm việc  (F2)"),          projectOpen, workWindow != nullptr);
        m.addItem (402, livent::vn ("Bàn trộn  (F3)"),              workWindow != nullptr,
                   workWindow != nullptr && mixerVisible);
        m.addItem (415, livent::vn ("Kiểu giao diện...  (F5)"));
        m.addItem (418, livent::vn ("Bảng tiếng cười"), projectOpen, tonePanel.isLaughPanelOpen());
        m.addItem (419, livent::vn ("Luôn nổi"), true, loadMainAlwaysOnTopPreference());
        m.addItem (417, livent::vn ("Hiện nút BÈ (Auto-Tune 11)  (F7)"), true, harmonyButtonVisible);
        m.addItem (423, livent::vn ("Hiện thanh sóng trên nút  (F6)"),
                   true, tonePanel.isCompactMetersVisible());
        m.addItem (416, livent::vn ("Đổi mật khẩu Bàn làm việc..."));

        m.addSeparator();

        /* MOC 96: bo menu "Khi khoi dong thi...". LiveNT luon vao Hub;
           mo/tao project luon chi hien Bang dieu khien. F2 la khu co mat khau. */
    }
    else if (index == menuHelp)
    {
        m.addItem (501, livent::vn ("Mở thư mục cài đặt (%APPDATA%\\LiveNT)"));
        m.addItem (502, livent::vn ("Mở nhật ký quét plugin (scanlog.txt)"));
        m.addItem (503, livent::vn ("Mở nhật ký ổn định (Documents)"));
        m.addSeparator();
        m.addItem (504, livent::vn ("Ghi thông số VST ra file (gửi kỹ thuật)"), projectOpen);
    }
    else if (index == menuContact)
    {
        /*  V6.2.2: muc BAN QUYEN - chi hien trang thai thoi gian dang dung
            va nut kich hoat/nhap key. Khong con muc lien he mang xa hoi.  */

        //  MOC 63: hien trang thai ban quyen len dau - "vinh vien" hay
        //  "dung thu con X ngay". Muc nay chi HIEN THI, khong bam duoc
        //  (id = -1 khong khop case nao trong menuItemSelected).
        const auto info = livent::license::current();

        juce::String statusText;

        if (info.activated && info.perpetual)
        {
            statusText = livent::vn ("Bạn đang dùng bản VĨNH VIỄN");
        }
        else if (info.activated)
        {
            const auto daysLeft = (int) (info.expiry - juce::Time::getCurrentTime()).inDays() + 1;
            statusText = livent::vn ("Bạn đang dùng bản có hạn - còn ") + juce::String (juce::jmax (0, daysLeft))
                       + livent::vn (" ngày");
        }
        else
        {
           #if LIVENT_ENABLE_LICENSE
            const auto trialLeft = livent::license::trialDaysLeft();
            statusText = trialLeft > 0
                       ? livent::vn ("Bạn đang DÙNG THỬ - còn ") + juce::String (trialLeft) + livent::vn (" ngày")
                       : livent::vn ("Bản dùng thử đã HẾT HẠN");
           #else
            //  MOC 63: dang TAT ban quyen (che do phat trien) - TUYET DOI
            //  khong goi trialDaysLeft() o day, vi ham do GHI FILE dem ngay
            //  va se lam dong ho dung thu chay ngam tu luc build dev.
            statusText = livent::vn ("Chế độ phát triển - bản quyền đang tắt");
           #endif
        }

        m.addSectionHeader (statusText);

       #if LIVENT_ENABLE_LICENSE
        // V6.2.2: tab BẢN QUYỀN chỉ còn trạng thái thời gian + kích hoạt.
        m.addItem (603, info.activated ? livent::vn ("Nhập key khác...")
                                        : livent::vn ("Nhập key kích hoạt..."));
       #endif

        // Lien he: sua o Source/AppBranding.h.
        if (livent::branding::hasContact())
            m.addItem (604, juce::String::fromUTF8 (livent::branding::contactTitle) + ": "
                              + juce::String::fromUTF8 (livent::branding::contactPhone));
    }

    return m;
}

/** Chan doan: ghi danh sach thong so cua moi VST dang nap ra file de xem
    plugin (vd Antares Auto-Key 2) co dua nut Listen / Send ra cho DAW dieu
    khien hay khong. Chi doc, khong doi gi cua plugin. */
void MainComponent::dumpPluginParametersToFile()
{
    juce::String text;
    text << "LiveNT - thong so VST  " << juce::Time::getCurrentTime().toString (true, true) << "\n"
         << "Du an: " << currentProjectFile.getFullPathName() << "\n\n";

    for (int ti = 0; ti < mixer.getNumTracks(); ++ti)
    {
        auto* t = mixer.getTrack (ti);
        if (t == nullptr)
            continue;

        auto& chain = t->getInserts();
        for (int si = 0; si < PluginChain::maxSlots; ++si)
        {
            if (chain.getBridge32Client (si) != nullptr)
            {
                text << "== Track \"" << t->getName() << "\"  o " << (si + 1)
                     << "  : VST 32-bit (chay qua bridge, khong doc duoc thong so)\n\n";
                continue;
            }

            auto* p = chain.getPlugin (si);
            if (p == nullptr)
                continue;

            const auto desc = p->getPluginDescription();
            text << "== Track \"" << t->getName() << "\"  o " << (si + 1) << "  : "
                 << p->getName() << "  [" << desc.pluginFormatName << " "
                 << desc.manufacturerName << " " << desc.version << "]\n";

            if (auto* ed = p->getActiveEditor())
                text << "   cua so dang mo: " << ed->getWidth() << " x " << ed->getHeight() << "\n";

            const auto params = p->getParameters();
            text << "   so thong so: " << params.size() << "\n";

            for (auto* param : params)
            {
                if (param == nullptr)
                    continue;

                text << "   #" << param->getParameterIndex()
                     << "  \"" << param->getName (128) << "\""
                     << "  = " << param->getCurrentValueAsText()
                     << "  (" << juce::String ((double) param->getValue(), 4) << ")";

                if (param->getLabel().isNotEmpty())  text << "  don vi=" << param->getLabel();
                if (param->isBoolean())              text << "  [bat/tat]";
                if (param->isDiscrete())             text << "  [" << param->getNumSteps() << " nac]";
                if (! param->isAutomatable())        text << "  [khong tu dong hoa]";
                text << "\n";
            }
            text << "\n";
        }
    }

    const auto out = PluginChain::getSettingsFolder().getChildFile ("vst-thong-so.txt");
    if (out.replaceWithText (text))
        out.revealToUser();
    else
        livent::alert (livent::vn ("Không ghi được file"), out.getFullPathName(),
                       juce::MessageBoxIconType::WarningIcon);
}

void MainComponent::menuItemSelected (int id, int)
{
    switch (id)
    {
        case 101: newProject();           return;
        case 102: saveProject();          return;
        case 103: saveProjectAs();        return;
        case 106:   // 06/10: phai go mat khau F2 (doi mat khau F2 thi doi theo)
            withAdminPassword (livent::vn ("Lưu thông số làm mặc định"), [safe = juce::Component::SafePointer<MainComponent> (this)]
                               { if (safe != nullptr) safe->saveDefaultMix(); });
            return;
        case 107: restoreDefaultMix();    return;
        case 104: openProjectDialog();    return;
        case 105: closeProject();         return;
        case 113: saveProjectAsMachineTemplate(); return;
        case 114: lowerAllWindowsTemporarily (60); return;
        case 115: openGuideWindow (0); return;
        case 116: deleteRecordingProject(); return;      // 14/10
        case 117: cleanUnusedRecordings(); return;       // 14/10
        case 109: confirmCloseAndQuit(); return;
        case 110: tonePanel.openSaveSongMenu (&topFileButton); return;
        case 111: tonePanel.openSongLibraryWindow(); return;
        case 112: tonePanel.openSongAutoSaveOptions(); return;

        /*  "Them track" dung lai dung cai menu chuot phai da co san duoi danh
            sach track -- mot cho lam, hai duong goi. Sua kieu track o mot noi
            la ca hai duong cung duoc sua theo.  */
        case 201: showTrackListContextMenu (trackListViewport.getScreenPosition()
                                                + juce::Point<int> (40, 40), nullptr);  return;
        case 202: removeSelectedTrack();  return;

        case 301: openAudioSetupDialog (0); return;   // 14/10: gop vao 1 cua so
        case 306: openAudioSetupDialog (1); return;
        case 307: tonePanel.showTargetTrackMenu(); return;
        case 308: tonePanel.setResetToneOnNewSong (! tonePanel.isResetToneOnNewSong()); return;
        case 302: openPluginScanner();      return;
        case 303: openScanPathEditor();     return;
        case 304: togglePerformanceMode();  return;
        case 309:
            saveVstGuiSafeModePref (! loadVstGuiSafeModePref());
            livent::stabilityLog ("PREF vst-gui-safe-mode",
                                  loadVstGuiSafeModePref() ? "ON" : "OFF");
            return;
        case 320:
        {
            const bool next = ! mixer.isLowLatencyLive();
            saveLowLatencyLivePref (next);
            mixer.setLowLatencyLive (next);
            livent::stabilityLog ("PREF low-latency-live", next ? "ON" : "OFF");
            return;
        }
        case 321: openLatencyDialog(); return;
        case 305:
            autosaveEnabled = ! autosaveEnabled;
            saveAutosavePref (autosaveEnabled);   // MOC 66: luu lai, nho qua cac lan mo app
            return;

       #if JUCE_MAC
        case 310: tonePanel.setPreferredBrowser ("Google Chrome");  saveBrowserPref ("Google Chrome");  return;
        case 311: tonePanel.setPreferredBrowser ("YouTube");        saveBrowserPref ("YouTube");        return;
        case 312: tonePanel.setPreferredBrowser ("Brave Browser");  saveBrowserPref ("Brave Browser");  return;
        case 313: tonePanel.setPreferredBrowser ("Google Chrome");  saveBrowserPref ("Google Chrome");  return;
        case 314: tonePanel.setPreferredBrowser ("CocCoc");         saveBrowserPref ("CocCoc");         return;
        case 315: tonePanel.setPreferredBrowser ("Safari");         saveBrowserPref ("Safari");         return;
        case 316: tonePanel.setPreferredBrowser ("Microsoft Edge"); saveBrowserPref ("Microsoft Edge"); return;
       #endif

        case 410: applyUiScaleFromMenu (0.75);  return;
        case 411: applyUiScaleFromMenu (0.9);   return;
        case 412: applyUiScaleFromMenu (1.0);   return;
        case 413: applyUiScaleFromMenu (1.1);   return;
        case 414: applyUiScaleFromMenu (1.25);  return;
        case 430: applyTextScaleFromMenu (1.0);  return;
        case 431: applyTextScaleFromMenu (1.15); return;
        case 432: applyTextScaleFromMenu (1.3);  return;
        case 433: applyTextScaleFromMenu (1.5);  return;
        case 434: applyTextScaleFromMenu (1.75); return;
        case 435: applyTextScaleFromMenu (2.0);  return;

        case 401: toggleInspector();    return;   // MOC 74
        case 402: toggleMixerPanel();   return;
        case 404: toggleTrackList();    return;   // MOC 75
        case 415: openDawBackgroundMenu(); return;
        case 471:
            openDawBackgroundMenu();   // 12o: bang kieu rack da gop vao bang F5
            return;
        case 424:
            return;
        case 418:
            tonePanel.toggleLaughPanel();
            return;
        case 419:
        {
            const bool on = ! loadMainAlwaysOnTopPreference();
            saveMainAlwaysOnTopPreference (on);
            if (auto* w = findParentComponentOfClass<juce::DocumentWindow>())
                w->setAlwaysOnTop (on);
            return;
        }
        case 417:
            harmonyButtonVisible = ! harmonyButtonVisible;
            saveHarmonyButtonPref (harmonyButtonVisible);
            tonePanel.setHarmonyButtonVisible (harmonyButtonVisible);
            resized();
            return;
        case 423:
            tonePanel.setCompactMetersVisible (! tonePanel.isCompactMetersVisible());
            compactControlPanelWindow();
            return;
        case 416: changeWorkPanelPassword(); return;

        //  MOC 75: chon xong thi AP DUNG LUON, khong bat cho toi lan mo app
        //  sau moi thay -- doi mot muc menu ma man hinh khong nhuc nhich thi
        //  khong ai biet minh vua bam trung hay chua.
        case 420: saveStartupLayoutMode (0);                            return;
        case 421: saveStartupLayoutMode (1); applyStartupLayoutMode (1); return;
        case 422: saveStartupLayoutMode (2); applyStartupLayoutMode (2); return;

        case 501: PluginChain::getSettingsFolder().revealToUser(); return;
        case 504: dumpPluginParametersToFile(); return;
        case 502:
        {
            auto log = PluginChain::getSettingsFolder().getChildFile ("scanlog.txt");

            if (log.existsAsFile())  log.startAsProcess();
            else                     livent::alert (livent::vn ("Chưa có nhật ký"),
                                         livent::vn ("Chưa có file scanlog.txt -- nghĩa là chưa lần nào quét plugin."));
            return;
        }
        case 503:
        {
            auto documentsLog = livent::getDocumentsStabilityLogFile();
            auto appDataLog = livent::getStabilityLogFile();

            if (documentsLog.existsAsFile())
                documentsLog.startAsProcess();
            else if (appDataLog.existsAsFile())
                appDataLog.startAsProcess();
            else
                livent::alert (livent::vn ("Chưa có nhật ký"),
                               livent::vn ("Chưa có LiveNT_stability.log. Hãy thử thao tác gây lỗi một lần."));
            return;
        }

        case 603:
            showActivationDialog();
            return;

        case 604:
            copyContactPhone();
            return;

        default: break;
    }

    //-- Mo gan day ----------------------------------------------------------
    if (id >= 900)
    {
        auto file = recentFiles.getFile (id - 900);

        if (file.existsAsFile())
            requestOpenProject (file);
        else
            livent::alert (livent::vn ("Không thấy file"),
                livent::vn ("File này đã bị đổi tên hoặc xóa:\n") + file.getFullPathName(),
                juce::MessageBoxIconType::WarningIcon);
    }
}

//=============================================================================
void MainComponent::openScanPathEditor()
{
    /*  FileSearchPathListComponent la san cua JUCE: mot danh sach thu muc co
        nut +/- va keo tha. Anh muon them "D:\VST rieng" thi bam + o day,
        khong phai sua code roi build lai.

        Meo nho: cho viec LUU vao destructor. Cua so dong luc nao - bam X,
        bam Escape, hay app thoat - thi destructor cung chay, nen khong bao
        gio quen luu.  */
    struct ScanPathEditor : public juce::FileSearchPathListComponent
    {
        ScanPathEditor()
        {
            setPath (livent::loadSearchPath());
            setSize (560, 300);
        }

        ~ScanPathEditor() override   { livent::saveSearchPath (getPath()); }
    };

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (new ScanPathEditor());
    o.dialogTitle = livent::vn ("Thư mục quét plugin  (đóng cửa sổ này là tự lưu)");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = true;

    livent::bringDialogToFront (livent::launchDialog (o));
}

//=============================================================================
//  TACH BANG DO TONE RA CUA SO RIENG
//=============================================================================
namespace
{
    /** Cua so nho chua bang do tone. Bam dau X la gan lai vao LiveNT. */
    class ToneWindow : public juce::DocumentWindow
    {
    public:
        ToneWindow (std::function<void()> onCloseCallback)
            : DocumentWindow (livent::vn ("LiveNT - Đo tone"), Col::bg, DocumentWindow::allButtons),
              onClose (std::move (onCloseCallback))
        {
            setUsingNativeTitleBar (true);
            /* MOC 96: Ban lam viec nam DUOI Bang dieu khien chinh. Cua so
               chinh moi la top-most de luc hat luon nhin thay nut dieu khien. */
            setAlwaysOnTop (false);
            setResizable (true, false);
        }

        void closeButtonPressed() override   { if (onClose) onClose(); }

    private:
        std::function<void()> onClose;
    };

    /*  ==========  MOC 75: BANG CAI DAT  ==========

        Mot dong trong bang: nut ben trai + mot cau giai thich ben phai.

        Co cau giai thich la vi menu xo xuong truoc gio chi co moi cai ten -
        doc "Che do dien" hay "Tu dong luu" thi khong doan duoc no lam gi, va
        khong ai dam bam thu trong luc dang chuan bi len hat.  */
    struct SettingsItem
    {
        enum class Kind { row, section, mini, radio, segment };

        juce::String          label;
        juce::String          note;
        std::function<void()> action;
        bool                  isToggle = false;
        bool                  toggleOn = false;
        bool                  enabled  = true;

        /*  02/10: BANG CAI DAT MOI (anh chot demo 2)
            - state / enabledFn / labelFn / noteFn: doc trang thai THAT moi
              1/5 giay -> bam cong tac khong can dong bang de "lan sau hien dung".
            - section: tieu de nhom nho mau xanh.
            - mini: dong ky thuat it dung (nho, mo).
            - radio: chon 1 trong nhieu.  segment: 75% | 100% | 125%.  */
        Kind                            kind = Kind::row;
        std::function<bool()>           state;
        std::function<bool()>           enabledFn;
        std::function<juce::String()>   labelFn;
        std::function<juce::String()>   noteFn;
        juce::StringArray               segments;
        std::function<int()>            segmentIndex;
        std::function<void (int)>       onSegment;
        juce::String                    searchExtra;
    };

    static SettingsItem settingsSection (const juce::String& title)
    {
        SettingsItem s;
        s.label = title;
        s.kind = SettingsItem::Kind::section;
        s.enabled = false;
        return s;
    }

    /** Bo dau tieng Viet de tim "mat khau" van ra "mật khẩu". */
    static juce::String foldVietnamese (const juce::String& s)
    {
        static const juce::String from = juce::String::fromUTF8 (
            "àáạảãâầấậẩẫăằắặẳẵ" "èéẹẻẽêềếệểễ" "ìíịỉĩ" "òóọỏõôồốộổỗơờớợởỡ" "ùúụủũưừứựửữ" "ỳýỵỷỹ" "đ");
        static const juce::String to = juce::String::repeatedString ("a", 17) + juce::String::repeatedString ("e", 11)
                                     + juce::String::repeatedString ("i", 5)  + juce::String::repeatedString ("o", 17)
                                     + juce::String::repeatedString ("u", 11) + juce::String::repeatedString ("y", 5) + "d";
        juce::String out;
        for (auto c : s.toLowerCase())
        {
            if (c >= 0x300 && c <= 0x36f)
                continue;   // dau to hop (go Unikey kieu to hop)
            const int i = from.indexOfChar (c);
            out << (i >= 0 ? to[i] : c);
        }
        return out;
    }

    /** Viet hoa ca chu co dau (toUpperCase cua JUCE bo sot tren mot so may). */
    static juce::String upperVietnamese (const juce::String& s)
    {
        static const juce::String lo = juce::String::fromUTF8 (
            "àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ");
        static const juce::String up = juce::String::fromUTF8 (
            "ÀÁẠẢÃÂẦẤẬẨẪĂẰẮẶẲẴÈÉẸẺẼÊỀẾỆỂỄÌÍỊỈĨÒÓỌỎÕÔỒỐỘỔỖƠỜỚỢỞỠÙÚỤỦŨƯỪỨỰỬỮỲÝỴỶỸĐ");
        juce::String out;
        for (auto c : s)
        {
            const int i = lo.indexOfChar (c);
            out << (i >= 0 ? up[i] : (c < 128 ? juce::CharacterFunctions::toUpperCase (c) : c));
        }
        return out;
    }

    /** Ve mui ten "mo cua so khac" trong o vuong nho. */
    static void drawOpenArrow (juce::Graphics& g, juce::Rectangle<float> box, float alpha)
    {
        g.setColour (Col::bg.withAlpha (0.85f * alpha));
        g.fillRoundedRectangle (box, 6.0f);
        g.setColour (Col::line.withAlpha (0.85f * alpha));
        g.drawRoundedRectangle (box.reduced (0.5f), 6.0f, 1.0f);
        const auto c = box.getCentre();
        juce::Path p;
        p.startNewSubPath (c.x - 3.5f, c.y + 3.5f);
        p.lineTo (c.x + 3.5f, c.y - 3.5f);
        p.startNewSubPath (c.x - 1.0f, c.y - 3.5f);
        p.lineTo (c.x + 3.5f, c.y - 3.5f);
        p.lineTo (c.x + 3.5f, c.y + 1.0f);
        g.setColour (Col::textDim.withAlpha (alpha));
        g.strokePath (p, juce::PathStrokeType (1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    /** Một dòng cài đặt kiểu gọn: tên + mô tả, trạng thái ở mép phải. */
    /*  14/10: Chu trong Cai dat - to hon ~1px va gian chu nhe (nen toi: chu nho dinh nhau, kho doc).
        Do rong/cao dong tinh theo CHINH font nay nen bo cuc khong bi lech. */
    static juce::Font settingsFont (float size, const char* style = "Regular")
    {
        return juce::Font (juce::FontOptions (size).withStyle (style)).withExtraKerningFactor (0.022f);
    }

    /** Mau nhan cho CHU (tieu de muc, the dang chon). Nen sang: pha them mau chu cho dam, khong bi mat chu (vd vang tren kem). */
    static juce::Colour settingsAccentText()
    {
        return Col::isLight ? Col::accent.interpolatedWith (Col::text, 0.42f) : Col::accent;
    }

    class SettingsRow final : public juce::Component, public juce::SettableTooltipClient
    {
    public:
        using Kind = SettingsItem::Kind;

        explicit SettingsRow (const SettingsItem& source) : item (source)
        {
            refreshState();
            updateCursor();
            updateTooltip();
        }

        int getPreferredHeight (int width) const
        {
            if (item.kind == Kind::section) return 28;
            if (item.kind == Kind::mini)
                return juce::jmax (30, textLines (item.label, 13.5f, width - 48, 2) * 17 + 10);
            const int textW = juce::jmax (40, width - 24 - rightReserve());
            const int labelH = textLines (item.label, 14.5f, textW, 3, "SemiBold") * 19;
            const bool hasNote = item.note.isNotEmpty() || item.noteFn != nullptr;
            const int noteH = hasNote ? textLines (item.note, 12.5f, textW, 3) * 16 + 3 : 0;
            return juce::jmax (hasNote ? 50 : 40, labelH + noteH + 12);
        }

        /** Doc lai trang thai that. */
        bool refreshState()
        {
            bool changed = false;
            if (item.state)
                if (const bool v = item.state(); v != item.toggleOn) { item.toggleOn = v; changed = true; }
            if (item.enabledFn)
                if (const bool v = item.enabledFn(); v != item.enabled) { item.enabled = v; changed = true; }
            if (item.labelFn)
                if (auto v = item.labelFn(); v != item.label) { item.label = v; changed = true; }
            if (item.noteFn)
                if (auto v = item.noteFn(); v != item.note) { item.note = v; changed = true; }
            if (item.segmentIndex)
                if (const int v = item.segmentIndex(); v != segIndex) { segIndex = v; changed = true; }
            if (changed)
            {
                updateCursor();
                updateTooltip();
                repaint();
            }
            return changed;
        }

        void paint (juce::Graphics& g) override
        {
            const float alpha = item.enabled ? 1.0f : 0.38f;

            if (item.kind == Kind::section)
            {
                auto r = getLocalBounds().reduced (4, 0).removeFromBottom (18);
                g.setColour (settingsAccentText());
                g.setFont (settingsFont (12.0f, "Bold"));
                g.drawText (upperVietnamese (item.label), r, juce::Justification::centredLeft, true);
                return;
            }

            if (item.kind == Kind::mini)
            {
                auto r = getLocalBounds().reduced (12, 0);
                if (mouseOver && item.enabled)
                {
                    g.setColour (Col::panel2.withAlpha (0.7f));
                    g.fillRoundedRectangle (getLocalBounds().toFloat().reduced (1.0f), 6.0f);
                }
                g.setColour (Col::line.withAlpha (0.45f));
                g.drawHorizontalLine (getHeight() - 1, 8.0f, (float) getWidth() - 8.0f);
                g.setColour ((mouseOver ? Col::text : Col::textDim).withAlpha (alpha));
                g.setFont (settingsFont (13.5f));
                g.drawFittedText (item.label, r.withTrimmedRight (24), juce::Justification::centredLeft, 2, 1.0f);
                drawOpenArrow (g, r.removeFromRight (20).withSizeKeepingCentre (20, 20).toFloat(), 0.7f * alpha);
                return;
            }

            auto rr = getLocalBounds().toFloat().reduced (1.0f);
            auto bg = Col::panel2.withAlpha (mouseOver && item.enabled ? 0.96f : 0.72f);
            if (mouseDownHere)
                bg = Col::raised.withAlpha (0.95f);
            g.setColour (bg);
            g.fillRoundedRectangle (rr, 8.0f);
            g.setColour (Col::line.withAlpha (0.48f));
            g.drawRoundedRectangle (rr, 8.0f, 1.0f);

            auto text = getLocalBounds().reduced (12, 5);
            text.removeFromRight (rightReserve());
            const bool hasNote = item.note.isNotEmpty();
            const int labelLines = textLines (item.label, 14.5f, text.getWidth(), 3, "SemiBold");

            g.setColour (Col::text.withAlpha (alpha));
            g.setFont (settingsFont (14.5f, "SemiBold"));
            g.drawFittedText (item.label, hasNote ? text.removeFromTop (labelLines * 19) : text,
                              juce::Justification::centredLeft, labelLines, 1.0f);

            if (hasNote)
            {
                g.setColour (Col::textDim.withAlpha (alpha));
                g.setFont (settingsFont (12.5f));
                g.drawFittedText (item.note, text.withTrimmedTop (3), juce::Justification::topLeft, 3, 1.0f);
            }

            auto right = getLocalBounds().reduced (10, 0);

            if (item.isToggle)
            {
                auto pill = right.removeFromRight (40).withSizeKeepingCentre (40, 22).toFloat();
                const bool on = item.toggleOn;
                g.setColour ((on ? Col::accent : Col::bg).withAlpha (alpha));
                g.fillRoundedRectangle (pill, 11.0f);
                g.setColour ((on ? Col::accent : Col::line).withAlpha (alpha));
                g.drawRoundedRectangle (pill.reduced (0.5f), 11.0f, 1.0f);
                auto knob = juce::Rectangle<float> (16.0f, 16.0f)
                                .withCentre ({ on ? pill.getRight() - 11.0f : pill.getX() + 11.0f, pill.getCentreY() });
                g.setColour ((on ? (Col::isLight ? Col::onAccent : juce::Colours::white) : Col::textDim).withAlpha (alpha));
                g.fillEllipse (knob);
            }
            else if (item.kind == Kind::radio)
            {
                auto c = right.removeFromRight (20).withSizeKeepingCentre (18, 18).toFloat();
                g.setColour ((item.toggleOn ? Col::accent : Col::line).withAlpha (alpha));
                g.drawEllipse (c.reduced (1.0f), 2.0f);
                if (item.toggleOn)
                    g.fillEllipse (c.reduced (5.0f));
            }
            else if (item.kind == Kind::segment)
            {
                for (int i = 0; i < item.segments.size(); ++i)
                {
                    auto sb = segmentBounds (i).toFloat();
                    const bool on = i == segIndex;
                    if (on)
                    {
                        g.setColour (Col::accent.withAlpha (alpha));
                        g.fillRoundedRectangle (sb.reduced (1.0f), 5.0f);
                    }
                    g.setColour ((on ? Col::onAccent : Col::textDim).withAlpha (alpha));
                    g.setFont (settingsFont (12.5f, "SemiBold"));
                    g.drawText (item.segments[i], sb.toNearestInt(), juce::Justification::centred, false);
                }
                auto all = segmentBounds (0).getUnion (segmentBounds (item.segments.size() - 1)).toFloat();
                g.setColour (Col::line.withAlpha (0.85f * alpha));
                g.drawRoundedRectangle (all.reduced (0.5f), 6.0f, 1.0f);
            }
            else if (item.action)
            {
                drawOpenArrow (g, right.removeFromRight (26).withSizeKeepingCentre (26, 26).toFloat(), alpha);
            }
        }

        void mouseEnter (const juce::MouseEvent&) override { mouseOver = true; repaint(); }
        void mouseExit  (const juce::MouseEvent&) override { mouseOver = false; mouseDownHere = false; repaint(); }

        void mouseDown (const juce::MouseEvent& e) override
        {
            if (! item.enabled || ! e.mods.isLeftButtonDown() || item.kind == Kind::section)
                return;
            mouseDownHere = item.kind != Kind::segment;
            repaint();
        }

        void mouseUp (const juce::MouseEvent& e) override
        {
            if (item.kind == Kind::segment)
            {
                if (! item.enabled)
                    return;
                for (int i = 0; i < item.segments.size(); ++i)
                    if (segmentBounds (i).contains (e.getPosition()) && i != segIndex)
                    {
                        segIndex = i;
                        repaint();
                        if (item.onSegment)
                            item.onSegment (i);
                        return;
                    }
                return;
            }

            const bool shouldRun = item.enabled && mouseDownHere && getLocalBounds().contains (e.getPosition());
            mouseDownHere = false;

            if (shouldRun)
            {
                if (item.isToggle)
                    item.toggleOn = ! item.toggleOn;
                if (item.kind == Kind::radio)
                    item.toggleOn = true;
                repaint();
                if (item.action)
                    item.action();   // co the dong ca bang -> khong dung 'this' sau dong nay
            }
            else
            {
                repaint();
            }
        }

    private:
        static int textLines (const juce::String& value, float size, int width, int maxLines,
                              const char* style = "Regular")
        {
            const auto font = settingsFont (size, style);
            const auto pixels = juce::GlyphArrangement::getStringWidth (font, value);
            return juce::jlimit (1, maxLines, (int) std::ceil (pixels / (float) juce::jmax (40, width)));
        }

        int rightReserve() const
        {
            if (item.isToggle) return 58;
            if (item.kind == Kind::radio) return 36;
            if (item.kind == Kind::segment) return segmentsWidth() + 16;
            return 40;
        }

        void updateTooltip()
        {
            setTooltip (item.label + (item.note.isNotEmpty() ? "\n" + item.note : juce::String()));
        }

        int segmentsWidth() const { return item.segments.size() * 54; }

        juce::Rectangle<int> segmentBounds (int i) const
        {
            const int w = 54, h = 28;
            const int x0 = getWidth() - 10 - segmentsWidth();
            return { x0 + i * w, (getHeight() - h) / 2, w, h };
        }

        void updateCursor()
        {
            const bool clickable = item.enabled && item.kind != Kind::section;
            setMouseCursor (clickable ? juce::MouseCursor::PointingHandCursor
                                      : juce::MouseCursor::NormalCursor);
        }

        SettingsItem item;
        int segIndex = -1;
        bool mouseOver = false;
        bool mouseDownHere = false;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SettingsRow)
    };

    /** Nội dung một thẻ Cài đặt. Viewport giúp máy 1366x768 vẫn dùng đủ mục. */
    class SettingsPage final : public juce::Component, private juce::Timer
    {
    public:
        explicit SettingsPage (const std::vector<SettingsItem>& list,
                               juce::Component* headerToOwn = nullptr, int headerHeight = 0)
            : header (headerToOwn), headerH (header != nullptr ? headerHeight : 0)
        {
            if (header != nullptr)
                content.addAndMakeVisible (*header);

            for (const auto& it : list)
            {
                auto* row = rows.add (new SettingsRow (it));
                content.addAndMakeVisible (row);
            }

            viewport.setScrollBarsShown (true, true);
            viewport.setScrollBarThickness (9);
            viewport.setViewedComponent (&content, false);
            addAndMakeVisible (viewport);
            startTimerHz (5);
        }

        ~SettingsPage() override
        {
            stopTimer();
            viewport.setViewedComponent (nullptr, false);
        }

        int getPreferredHeight (int contentWidth = 420) const
        {
            int h = pad * 2 + headerH + (headerH > 0 ? gap : 0);
            for (auto* row : rows)
                h += row->getPreferredHeight (contentWidth - 20) + gap;
            return h;
        }

        void paint (juce::Graphics& g) override { g.fillAll (Col::panel); }

        void resized() override
        {
            viewport.setBounds (getLocalBounds());
            const int contentW = juce::jmax (360, getWidth() - 11);
            content.setSize (contentW, juce::jmax (getPreferredHeight (contentW), getHeight()));
            auto r = content.getLocalBounds().reduced (10, pad);

            if (header != nullptr)
            {
                header->setBounds (r.removeFromTop (headerH));
                r.removeFromTop (gap);
            }

            for (int i = 0; i < rows.size(); ++i)
            {
                rows[i]->setBounds (r.removeFromTop (rows[i]->getPreferredHeight (r.getWidth())));
                r.removeFromTop (gap);
            }
        }

    private:
        void timerCallback() override
        {
            if (isShowing())
            {
                bool needsLayout = false;
                for (auto* r : rows)
                {
                    if (r->refreshState() && r->getHeight() != r->getPreferredHeight (r->getWidth()))
                        needsLayout = true;
                }
                if (needsLayout)
                    resized();
            }
        }

        static constexpr int pad = 6, gap = 4;
        juce::Viewport viewport;
        juce::Component content;
        std::unique_ptr<juce::Component> header;
        int headerH = 0;
        juce::OwnedArray<SettingsRow> rows;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SettingsPage)
    };

    /** O ban quyen lon dau the "Ban quyen & Bao mat". */
    class LicenseCard final : public juce::Component
    {
    public:
        LicenseCard (const juce::String& brandIn, const juce::String& statusIn, const juce::String& subIn,
                     bool goodIn, std::function<void()> activateFn, const juce::String& activateText,
                     std::function<void()> contactFn, const juce::String& contactText)
            : brand (brandIn), status (statusIn), sub (subIn), good (goodIn)
        {
            auto setup = [this] (juce::TextButton& b, const juce::String& t, std::function<void()> fn, bool accent)
            {
                if (! fn)
                    return;
                b.setButtonText (t);
                b.setWantsKeyboardFocus (false);
                if (accent)
                    b.getProperties().set ("accentButton", true);
                b.onClick = std::move (fn);
                addAndMakeVisible (b);
            };
            setup (activateButton, activateText, std::move (activateFn), true);
            setup (contactButton, contactText, std::move (contactFn), false);
        }

        void paint (juce::Graphics& g) override
        {
            auto r = getLocalBounds().toFloat().reduced (1.0f);
            const auto tone = good ? Col::accent : Col::amber;
            g.setGradientFill (juce::ColourGradient (tone.withAlpha (0.20f), r.getX(), r.getY(),
                                                     Col::panel2.withAlpha (0.85f), r.getRight(), r.getBottom(), false));
            g.fillRoundedRectangle (r, 10.0f);
            g.setColour (tone.withAlpha (0.55f));
            g.drawRoundedRectangle (r, 10.0f, 1.0f);

            auto t = getLocalBounds().reduced (16, 12);
            g.setColour (Col::textDim);
            g.setFont (juce::Font (juce::FontOptions (11.0f).withStyle ("Bold")));
            g.drawText (upperVietnamese (brand), t.removeFromTop (16), juce::Justification::centredLeft, true);
            g.setColour (tone);
            g.setFont (juce::Font (juce::FontOptions (25.0f).withStyle ("Bold")));
            g.drawFittedText (status, t.removeFromTop (34), juce::Justification::centredLeft, 1, 0.8f);
            g.setColour (Col::textDim);
            g.setFont (juce::Font (juce::FontOptions (12.0f)));
            g.drawFittedText (sub, t.removeFromTop (18), juce::Justification::centredLeft, 1, 0.8f);
        }

        void resized() override
        {
            auto r = getLocalBounds().reduced (16, 12).removeFromBottom (30);
            if (activateButton.isVisible())
            {
                activateButton.setBounds (r.removeFromLeft (juce::jmin (170, r.getWidth() / 2)));
                r.removeFromLeft (8);
            }
            if (contactButton.isVisible())
                contactButton.setBounds (r.removeFromLeft (juce::jmin (230, r.getWidth())));
        }

    private:
        juce::String brand, status, sub;
        bool good = true;
        juce::TextButton activateButton, contactButton;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (LicenseCard)
    };

    /*  ==========  01/10: THE "GAN NUT"  ==========
        Moi dong = 1 nut / num. Bam vao -> menu chon: mac dinh, bat/tat VST o
        may cua track nao, bat/tat loa track, bat/tat Send; num thi chon am
        luong track hoac muc Send. Luu trong du an (.NT).  */
    class ButtonMapPage final : public juce::Component
    {
    public:
        ButtonMapPage (Mixer& m, livent::buttonmap::Map& mapToEdit, std::function<void()> changedCb)
            : mixer (m), map (mapToEdit), onChanged (std::move (changedCb))
        {
            using livent::buttonmap::entries;

            // 02/10: hang nut nho tren cung (Nhap / Xuat / Mac dinh / Xoa)
            auto addPill = [this] (const juce::String& t, const juce::String& tip, bool warn, std::function<void()> fn)
            {
                auto* b = pills.add (new juce::TextButton (t));
                b->setTooltip (tip);
                b->setWantsKeyboardFocus (false);
                b->getProperties().set ("liveChipStyle", true);
                b->getProperties().set ("preferFullText", true);
                if (warn)
                    b->setColour (juce::TextButton::textColourOffId, Col::amber);
                b->onClick = std::move (fn);
                content.addAndMakeVisible (b);
            };
            addPill (livent::vn ("Nhập file"), livent::vn ("Mở file .ntmap, khớp track theo TÊN trong dự án này"), false,
                     [this] { importMap(); });
            addPill (livent::vn ("Xuất file"), livent::vn ("Lưu cách gán thành file .ntmap mang sang máy khác"), false,
                     [this] { exportMap(); });
            addPill (livent::vn ("Đặt làm mặc định"), livent::vn ("Dự án mới trên máy này tự gán giống vậy (khớp theo tên track)"), false,
                     [this]
                     {
                         const bool ok = map.saveAsMachineDefault();
                         livent::alert (livent::vn ("Gán nút"),
                                        ok ? livent::vn ("Đã lưu làm mặc định cho dự án mới trên máy này.")
                                           : livent::vn ("Không ghi được file mặc định."));
                     });
            addPill (livent::vn ("Bỏ mặc định máy"), livent::vn ("Dự án mới sẽ không tự gán nữa. Không ảnh hưởng dự án đã lưu."), false,
                     [] { livent::buttonmap::Map::deleteMachineDefault(); });
            addPill (livent::vn ("Xóa hết"), livent::vn ("Mọi nút / núm của dự án này quay về như cũ (track MÍC / NHẠC)"), true,
                     [this] { map.clear(); notifyChanged(); });

            bool knobSectionAdded = false;
            {
                auto* sec = rows.add (new Row());
                sec->title = livent::vn ("Nút");
                sec->isSection = true;
                sec->setMouseCursor (juce::MouseCursor::NormalCursor);
                content.addAndMakeVisible (sec);
            }

            for (size_t i = 0; i < entries().size(); ++i)
            {
                const auto& e = entries()[i];
                if (e.isKnob && ! knobSectionAdded)
                {
                    knobSectionAdded = true;
                    auto* sec = rows.add (new Row());
                    sec->title = livent::vn ("Núm");
                    sec->isSection = true;
                    sec->setMouseCursor (juce::MouseCursor::NormalCursor);
                sec->setMouseCursor (juce::MouseCursor::NormalCursor);
                    content.addAndMakeVisible (sec);
                }
                auto* row = rows.add (new Row());
                row->title = labelFor (e);
                const juce::String id (e.id);
                const auto* defText = e.defaultText;
                row->note = [this, id, defText] { return livent::buttonmap::describe (mixer, map.get (id), defText); };
                const bool knob = e.isKnob;
                row->onClick = [this, id, knob, r = row] { showMenu (id, knob, r); };
                content.addAndMakeVisible (row);
            }

            // 06/10: VST DIEU KHIEN (bang chuot phai Mic -> EQ Manny)
            {
                auto* sec = rows.add (new Row());
                sec->title = livent::vn ("VST điều khiển (chuột phải nút Míc)");
                sec->isSection = true;
                sec->setMouseCursor (juce::MouseCursor::NormalCursor);
                content.addAndMakeVisible (sec);
            }
            for (const auto& e : livent::buttonmap::vstEntries())
            {
                auto* row = rows.add (new Row());
                row->title = livent::vn (e.label);
                const juce::String id (e.id);
                row->note = [this, id]
                {
                    auto* mic = mixer.getTrackByRole (Track::Role::Mic);
                    return id == "autoTune" ? livent::vstctl::describeAutoTune (mixer, map, mic)
                                            : livent::vstctl::describeEq (mixer, map, mic);
                };
                row->onClick = [this, id, r = row] { showVstMenu (id, r); };
                content.addAndMakeVisible (row);
            }

            viewport.setScrollBarsShown (true, true);
            viewport.setScrollBarThickness (9);
            viewport.setViewedComponent (&content, false);
            addAndMakeVisible (viewport);
        }

        ~ButtonMapPage() override { viewport.setViewedComponent (nullptr, false); }

        void paint (juce::Graphics& g) override { g.fillAll (Col::panel); }

        static constexpr int rowH = 46, secH = 26, gap = 4, pad = 6, pillH = 26;

        int pillRowsFor (int width) const
        {
            int lines = 1, x = 0;
            for (auto* b : pills)
            {
                const int w = pillWidth (*b);
                if (x > 0 && x + w > width) { ++lines; x = 0; }
                x += w + 6;
            }
            return lines;
        }

        static int pillWidth (juce::TextButton& b)
        {
            const auto f = juce::Font (juce::FontOptions (12.5f).withStyle ("SemiBold"));
            return (int) juce::GlyphArrangement::getStringWidth (f, b.getButtonText()) + 26;
        }

        int getPreferredHeight (int width = 400) const
        {
            int h = pad * 2 + pillRowsFor (width - 20) * (pillH + 6) + 4;
            for (auto* row : rows)
                h += (row->isSection ? secH : rowH) + gap;
            return h;
        }

        void resized() override
        {
            viewport.setBounds (getLocalBounds());
            const int contentW = juce::jmax (360, getWidth() - 11);
            content.setSize (contentW, juce::jmax (getPreferredHeight (contentW), getHeight()));
            auto r = content.getLocalBounds().reduced (10, pad);

            // hang nut nho, tu xuong dong khi hep
            {
                const int lines = pillRowsFor (r.getWidth());
                auto area = r.removeFromTop (lines * (pillH + 6));
                int x = area.getX(), y = area.getY();
                for (auto* b : pills)
                {
                    const int w = pillWidth (*b);
                    if (x > area.getX() && x + w > area.getRight()) { x = area.getX(); y += pillH + 6; }
                    b->setBounds (x, y, w, pillH);
                    x += w + 6;
                }
                r.removeFromTop (4);
            }

            for (auto* row : rows)
            {
                row->setBounds (r.removeFromTop (row->isSection ? secH : rowH));
                r.removeFromTop (gap);
            }
        }

    private:
        struct Row final : public juce::Component
        {
            juce::String title;
            std::function<juce::String()> note;
            std::function<void()> onClick;
            bool isAction = false;
            bool isSection = false;
            bool over = false;

            Row() { setMouseCursor (juce::MouseCursor::PointingHandCursor); }

            void paint (juce::Graphics& g) override
            {
                if (isSection)
                {
                    g.setColour (Col::accent);
                    g.setFont (juce::Font (juce::FontOptions (11.0f).withStyle ("Bold")));
                    g.drawText (upperVietnamese (title), getLocalBounds().reduced (4, 0).removeFromBottom (18),
                                juce::Justification::centredLeft, true);
                    return;
                }

                auto r = getLocalBounds().toFloat().reduced (1.0f);
                g.setColour (Col::panel2.withAlpha (over ? 0.96f : 0.72f));
                g.fillRoundedRectangle (r, 8.0f);
                g.setColour ((isAction ? Col::accent : Col::line).withAlpha (isAction ? 0.55f : 0.48f));
                g.drawRoundedRectangle (r, 8.0f, 1.0f);

                auto text = getLocalBounds().reduced (14, 6);
                text.removeFromRight (30);
                g.setColour (Col::text);
                g.setFont (juce::Font (juce::FontOptions (14.0f).withStyle ("SemiBold")));
                g.drawFittedText (title, text.removeFromTop (20), juce::Justification::centredLeft, 1, 0.88f);

                const auto n = note ? note() : juce::String();
                const bool warn = n.contains (juce::String::fromUTF8 ("⚠"));
                const bool custom = ! isAction && ! n.startsWith (livent::vn ("Mặc định"));
                g.setColour (warn ? Col::amber : (custom ? Col::accent : Col::textDim));
                g.setFont (juce::Font (juce::FontOptions (12.0f)));
                g.drawFittedText (n, text, juce::Justification::centredLeft, 2, 0.82f);

                auto c = getLocalBounds().removeFromRight (28).toFloat();
                juce::Path p;
                p.startNewSubPath (c.getCentreX() - 5.0f, c.getCentreY() - 3.0f);
                p.lineTo (c.getCentreX(), c.getCentreY() + 2.0f);
                p.lineTo (c.getCentreX() + 5.0f, c.getCentreY() - 3.0f);
                g.setColour (Col::textDim.withAlpha (0.78f));
                g.strokePath (p, juce::PathStrokeType (1.7f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            }

            void mouseEnter (const juce::MouseEvent&) override { over = ! isSection; repaint(); }
            void mouseExit  (const juce::MouseEvent&) override { over = false; repaint(); }
            void mouseUp (const juce::MouseEvent& e) override
            {
                if (! isSection && getLocalBounds().contains (e.getPosition()) && onClick)
                    onClick();
            }
        };

        static juce::String labelFor (const livent::buttonmap::Entry& e)
        {
            const juce::String id (e.id);
            // 14/10: ten nut do nguoi dung dat (chuot phai nut > Doi ten) di theo sang day.
            if (id == "remix1") return livent::buttonmap::names::displayName (id, juce::String::fromUTF8 (livent::branding::fxNameRemix1));
            if (id == "remix2") return livent::buttonmap::names::displayName (id, juce::String::fromUTF8 (livent::branding::fxNameRemix2));
            if (id == "lofi" || id == "baby" || id == "harmony")
                return livent::buttonmap::names::displayName (id, livent::vn (e.label));
            return livent::vn (e.label);
        }

        static juce::String trackLabel (Track& t)
        {
            return t.getName() + "   [" + t.getTypeName() + "]";
        }

        void notifyChanged()
        {
            for (auto* r : rows)
                r->repaint();
            if (onChanged)
                onChanged();
        }

        //  02/10: XUAT / NHAP cach gan (.ntmap = the <BUTTON_MAP> nhu trong du an)
        static juce::File mapFolder()
        {
            return juce::File::getSpecialLocation (juce::File::userDocumentsDirectory);
        }

        void exportMap()
        {
            chooser = std::make_unique<juce::FileChooser> (livent::vn ("Xuất cách gán nút"),
                                                           mapFolder().getChildFile ("gan-nut.ntmap"),
                                                           "*.ntmap");
            juce::Component::SafePointer<ButtonMapPage> safe (this);
            chooser->launchAsync (juce::FileBrowserComponent::saveMode
                                    | juce::FileBrowserComponent::canSelectFiles
                                    | juce::FileBrowserComponent::warnAboutOverwriting,
                                  [safe] (const juce::FileChooser& fc)
                                  {
                                      if (safe == nullptr)
                                          return;
                                      auto f = fc.getResult();
                                      if (f == juce::File())
                                          return;
                                      if (! f.hasFileExtension ("ntmap"))
                                          f = f.withFileExtension ("ntmap");
                                      auto xml = safe->map.toXml();
                                      const bool ok = xml != nullptr && xml->writeTo (f);
                                      livent::alert (livent::vn ("Gán nút"),
                                                     ok ? livent::vn ("Đã xuất ra:\n") + f.getFullPathName()
                                                        : livent::vn ("Không ghi được file:\n") + f.getFullPathName());
                                  });
        }

        void importMap()
        {
            chooser = std::make_unique<juce::FileChooser> (livent::vn ("Nhập cách gán nút"),
                                                           mapFolder(), "*.ntmap;*.xml");
            juce::Component::SafePointer<ButtonMapPage> safe (this);
            chooser->launchAsync (juce::FileBrowserComponent::openMode
                                    | juce::FileBrowserComponent::canSelectFiles,
                                  [safe] (const juce::FileChooser& fc)
                                  {
                                      if (safe == nullptr)
                                          return;
                                      const auto f = fc.getResult();
                                      if (! f.existsAsFile())
                                          return;
                                      auto xml = juce::XmlDocument::parse (f);
                                      if (xml == nullptr || ! xml->hasTagName ("BUTTON_MAP"))
                                      {
                                          livent::alert (livent::vn ("Gán nút"),
                                                         livent::vn ("File này không phải file gán nút (.ntmap) của LiveNT."));
                                          return;
                                      }
                                      safe->map.fromXml (xml.get());
                                      livent::buttonmap::rebindByName (safe->map, safe->mixer);
                                      safe->notifyChanged();

                                      int missing = 0;
                                      for (const auto& e : livent::buttonmap::entries())
                                      {
                                          const auto b = safe->map.get (e.id);
                                          if (! b.isDefault()
                                              && livent::buttonmap::resolveTrack (safe->mixer, b) == nullptr)
                                              ++missing;
                                      }
                                      const int n = xml->getNumChildElements();
                                      juce::String msg = livent::vn ("Đã nhập ") + juce::String (n) + livent::vn (" nút / núm.");
                                      if (missing > 0)
                                          msg << livent::vn ("\n\n") << missing
                                              << livent::vn (" mục không thấy track cùng tên trong dự án này (dòng ghi \"không thấy track\"). "
                                                             "Đặt tên track giống máy cũ hoặc gán lại các dòng đó.");
                                      livent::alert (livent::vn ("Gán nút"), msg);
                                  });
        }

        /** 06/10: Tu tim / chon tay track + o / khong dung. */
        void showVstMenu (const juce::String& id, juce::Component* anchor)
        {
            using namespace livent::buttonmap;
            const auto current = map.get (id);
            auto choices = std::make_shared<std::map<int, Binding>>();
            int nextId = 1;

            const bool forAutoTune = (id == "autoTune");
            juce::PopupMenu menu;
            (*choices)[nextId] = Binding{};
            menu.addItem (nextId++, forAutoTune
                                      ? livent::vn ("Tự tìm Auto-Tune (MÍC ô 1; không có thì mọi track) — khuyên dùng")
                                      : livent::vn ("Tự tìm Manny EQ (ưu tiên MÍC, không có thì mọi track) — khuyên dùng"),
                          true, current.isDefault());
            menu.addSeparator();

            juce::PopupMenu manual;
            for (int i = 0; i < mixer.getNumTracks(); ++i)
                if (auto* t = mixer.getTrack (i))
                {
                    juce::PopupMenu sub;
                    auto& chain = t->getInserts();
                    bool any = false;
                    for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
                    {
                        if (chain.isSlotEmpty (slot))
                            continue;
                        Binding b;
                        b.act = Act::VstSlot;
                        b.trackId = t->getId();
                        b.trackName = t->getName();
                        b.slot = slot;
                        const bool ticked = current.act == Act::VstSlot && current.trackId == b.trackId && current.slot == slot;
                        const auto name = chain.getPluginName (slot);
                        (*choices)[nextId] = b;
                        sub.addItem (nextId++, livent::vn ("Ô ") + juce::String (slot + 1) + ":  " + name
                                        + (forAutoTune ? (livent::vstctl::isAutoTune (name) ? juce::String::fromUTF8 ("   ← Auto-Tune") : juce::String())
                                                       : (livent::vstctl::isMannyEq (name) ? juce::String::fromUTF8 ("   ← EQ") : juce::String())),
                                     ! chain.isMissing (slot), ticked);
                        any = true;
                    }
                    if (any)
                        manual.addSubMenu (trackLabel (*t), sub);
                }
            menu.addSubMenu (livent::vn ("Chọn tay: track + ô VST"), manual);
            if (! forAutoTune)   // Auto-Tune luon can mot dich: chi co "Tu tim" hoac "Chon tay"
            {
                menu.addSeparator();
                Binding none;
                none.act = Act::VstNone;
                (*choices)[nextId] = none;
                menu.addItem (nextId++, livent::vn ("Không dùng (chuột phải Míc chỉ còn Auto-Tune)"), true,
                              current.act == Act::VstNone);
            }

            juce::Component::SafePointer<ButtonMapPage> safe (this);
            menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (anchor),
                                [safe, id, choices] (int result)
                                {
                                    if (safe == nullptr || result <= 0)
                                        return;
                                    auto it = choices->find (result);
                                    if (it == choices->end())
                                        return;
                                    safe->map.set (id, it->second);
                                    safe->notifyChanged();
                                });
        }

        void showMenu (const juce::String& id, bool knob, juce::Component* anchor)
        {
            using namespace livent::buttonmap;
            const auto current = map.get (id);
            auto choices = std::make_shared<std::map<int, Binding>>();
            int nextId = 1;
            auto add = [&] (juce::PopupMenu& menu, const juce::String& text, const Binding& b, bool enabled = true)
            {
                const bool ticked = ! current.isDefault() && b.act == current.act
                                 && b.trackId == current.trackId && b.slot == current.slot
                                 && b.sendTargetId == current.sendTargetId && b.sendTargetSlot == current.sendTargetSlot;
                (*choices)[nextId] = b;
                menu.addItem (nextId++, text, enabled, ticked);
            };

            juce::PopupMenu menu;
            add (menu, livent::vn ("Mặc định (như cũ)"), Binding{});
            menu.addSeparator();

            auto makeBase = [] (Track& t, Act a)
            {
                Binding b;
                b.act = a;
                b.trackId = t.getId();
                b.trackName = t.getName();
                return b;
            };

            auto sendMenu = [&] (Act a)
            {
                juce::PopupMenu m;
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                    if (auto* t = mixer.getTrack (i))
                    {
                        if (t->getNumSends() == 0)
                            continue;
                        juce::PopupMenu sub;
                        for (int s = 0; s < t->getNumSends(); ++s)
                        {
                            const auto snd = t->getSend (s);
                            auto b = makeBase (*t, a);
                            b.sendTargetId = snd.targetId;
                            b.sendTargetSlot = snd.targetSlot;
                            if (auto* dst = mixer.getTrackById (snd.targetId))
                                b.sendTargetName = dst->getName();
                            add (sub, livent::vn ("→ ") + sendLabel (mixer, snd), b);
                        }
                        m.addSubMenu (trackLabel (*t), sub);
                    }
                return m;
            };

            if (! knob)
            {
                // 11h: nut Be - chi bat/tat be (Trigger All) trong mot Auto-Tune chon tay, khong bypass VST.
                if (id == "harmony")
                {
                    juce::PopupMenu be;
                    for (int i = 0; i < mixer.getNumTracks(); ++i)
                        if (auto* t = mixer.getTrack (i))
                        {
                            juce::PopupMenu sub;
                            auto& chain = t->getInserts();
                            bool any = false;
                            for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
                            {
                                if (chain.isSlotEmpty (slot))
                                    continue;
                                const auto name = chain.getPluginName (slot);
                                const auto lower = name.toLowerCase();
                                if (! lower.contains ("auto-tune") && ! lower.contains ("autotune"))
                                    continue;
                                auto b = makeBase (*t, Act::ToggleHarmony);
                                b.slot = slot;
                                add (sub, livent::vn ("Ô ") + juce::String (slot + 1) + ":  " + name, b);
                                any = true;
                            }
                            if (any)
                                be.addSubMenu (trackLabel (*t), sub);
                        }
                    if (be.getNumItems() == 0)
                        be.addItem (-1, livent::vn ("(chưa thấy Auto-Tune trên track nào)"), false);
                    menu.addSubMenu (livent::vn ("Bật/tắt BÈ trong VST... (không tắt plugin)"), be);
                    menu.addSeparator();
                }

                juce::PopupMenu vst;
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                    if (auto* t = mixer.getTrack (i))
                    {
                        juce::PopupMenu sub;
                        auto& chain = t->getInserts();
                        for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
                        {
                            auto b = makeBase (*t, Act::ToggleInsert);
                            b.slot = slot;
                            const bool empty = chain.isSlotEmpty (slot);
                            add (sub, livent::vn ("Ô ") + juce::String (slot + 1) + ":  "
                                        + (empty ? livent::vn ("(trống)") : chain.getPluginName (slot)),
                                 b, true);
                        }
                        vst.addSubMenu (trackLabel (*t), sub);
                    }
                menu.addSubMenu (livent::vn ("Bật/tắt VST ở ô..."), vst);

                juce::PopupMenu trk;
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                    if (auto* t = mixer.getTrack (i))
                        add (trk, trackLabel (*t), makeBase (*t, Act::ToggleTrack));
                menu.addSubMenu (livent::vn ("Bật/tắt loa cả track"), trk);

                menu.addSubMenu (livent::vn ("Bật/tắt một Send"), sendMenu (Act::ToggleSend));

                // 11/10: cong tac tong - bat/tat TAT CA Send cua mot track bat ky (Group, FX Bus...).
                juce::PopupMenu allSends;
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                    if (auto* t = mixer.getTrack (i))
                    {
                        const auto ty = t->getType();
                        if (ty == Track::Type::Output || ty == Track::Type::Input
                            || ty == Track::Type::PK || ty == Track::Type::OutputBus)
                            continue;
                        add (allSends, trackLabel (*t) + "  (" + juce::String (t->getNumSends()) + livent::vn (" send)"),
                             makeBase (*t, Act::ToggleAllSends));
                    }
                menu.addSubMenu (livent::vn ("Bật/tắt TẤT CẢ Send của track (Group, FX...)"), allSends);
            }
            else
            {
                juce::PopupMenu vol;
                for (int i = 0; i < mixer.getNumTracks(); ++i)
                    if (auto* t = mixer.getTrack (i))
                        add (vol, trackLabel (*t), makeBase (*t, Act::TrackVolume));
                menu.addSubMenu (livent::vn ("Âm lượng track"), vol);
                menu.addSubMenu (livent::vn ("Mức Send"), sendMenu (Act::SendLevel));
            }

            juce::Component::SafePointer<ButtonMapPage> safe (this);
            menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (anchor),
                                [safe, id, choices] (int result)
                                {
                                    if (safe == nullptr || result <= 0)
                                        return;
                                    auto it = choices->find (result);
                                    if (it == choices->end())
                                        return;
                                    safe->map.set (id, it->second);
                                    safe->notifyChanged();
                                });
        }

        Mixer& mixer;
        livent::buttonmap::Map& map;
        std::function<void()> onChanged;
        juce::Viewport viewport;
        juce::Component content;
        juce::OwnedArray<Row> rows;
        juce::OwnedArray<juce::TextButton> pills;
        std::unique_ptr<juce::FileChooser> chooser;

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ButtonMapPage)
    };

    /** 02/10: nut tab doc co bieu tuong nho (ve bang Path, khong dung emoji). */
    class SettingsTabButton final : public juce::Button
    {
    public:
        enum class Icon { sound, vst, look, map, youtube, lock };

        SettingsTabButton (const juce::String& name, Icon iconIn) : juce::Button (name), icon (iconIn)
        {
            setTooltip (name);
            setWantsKeyboardFocus (false);
            setMouseCursor (juce::MouseCursor::PointingHandCursor);
        }

        void paintButton (juce::Graphics& g, bool over, bool down) override
        {
            auto r = getLocalBounds().toFloat().reduced (1.0f);
            const bool on = getToggleState();
            if (on)
            {
                g.setColour (Col::accent.withAlpha (0.16f));
                g.fillRoundedRectangle (r, 7.0f);
                g.setColour (Col::accent);
                g.fillRoundedRectangle (r.withWidth (3.0f), 1.5f);
            }
            else if (over || down)
            {
                g.setColour (Col::panel2.withAlpha (0.9f));
                g.fillRoundedRectangle (r, 7.0f);
            }

            const auto col = on ? settingsAccentText() : Col::text.withAlpha (0.86f);
            auto area = getLocalBounds().reduced (10, 0);
            drawIcon (g, area.removeFromLeft (18).withSizeKeepingCentre (16, 16).toFloat(), col);
            area.removeFromLeft (8);
            g.setColour (col);
            g.setFont (settingsFont (14.0f, on ? "Bold" : "Medium"));
            g.drawFittedText (getButtonText(), area, juce::Justification::centredLeft, 2, 1.0f);
        }

    private:
        void drawIcon (juce::Graphics& g, juce::Rectangle<float> b, juce::Colour col) const
        {
            g.setColour (col);
            const float x = b.getX(), y = b.getY();
            auto P = [x, y] (float px, float py) { return juce::Point<float> (x + px, y + py); };
            const juce::PathStrokeType st (1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded);
            juce::Path p;

            switch (icon)
            {
                case Icon::sound:
                {
                    juce::Path s;
                    s.startNewSubPath (P (1, 6)); s.lineTo (P (4, 6)); s.lineTo (P (8, 2));
                    s.lineTo (P (8, 14)); s.lineTo (P (4, 10)); s.lineTo (P (1, 10)); s.closeSubPath();
                    g.fillPath (s);
                    p.addCentredArc (x + 8, y + 8, 4.0f, 4.0f, 0.0f, 0.7f, 2.45f, true);
                    p.addCentredArc (x + 8, y + 8, 7.0f, 7.0f, 0.0f, 0.7f, 2.45f, true);
                    g.strokePath (p, st);
                    break;
                }
                case Icon::vst:
                    for (int i = 0; i < 3; ++i)
                    {
                        const float cx = 3.0f + i * 5.0f;
                        p.startNewSubPath (P (cx, 1)); p.lineTo (P (cx, 15));
                        const float ky = i == 0 ? 10.0f : (i == 1 ? 5.0f : 11.0f);
                        g.fillRoundedRectangle (x + cx - 2.2f, y + ky - 1.6f, 4.4f, 3.2f, 1.0f);
                    }
                    g.strokePath (p, juce::PathStrokeType (1.2f));
                    break;
                case Icon::look:
                    p.addEllipse (x + 1, y + 1, 14, 14);
                    g.strokePath (p, st);
                    g.fillEllipse (x + 4, y + 4.5f, 2.6f, 2.6f);
                    g.fillEllipse (x + 8.5f, y + 3.5f, 2.6f, 2.6f);
                    g.fillEllipse (x + 10.5f, y + 8, 2.6f, 2.6f);
                    break;
                case Icon::map:
                    p.addEllipse (x + 1, y + 1, 14, 14);
                    p.addEllipse (x + 4.5f, y + 4.5f, 7, 7);
                    g.strokePath (p, st);
                    g.fillEllipse (x + 6.6f, y + 6.6f, 2.8f, 2.8f);
                    break;
                case Icon::youtube:
                {
                    p.addRoundedRectangle (x + 0.5f, y + 2.5f, 15, 11, 3.0f);
                    g.strokePath (p, st);
                    juce::Path t;
                    t.addTriangle (P (6.2f, 5.3f), P (6.2f, 10.7f), P (10.8f, 8));
                    g.fillPath (t);
                    break;
                }
                case Icon::lock:
                    p.addCentredArc (x + 8, y + 6.5f, 3.6f, 4.0f, 0.0f, -juce::MathConstants<float>::halfPi,
                                     juce::MathConstants<float>::halfPi, true);
                    p.startNewSubPath (P (4.4f, 6.5f)); p.lineTo (P (4.4f, 8));
                    p.startNewSubPath (P (11.6f, 6.5f)); p.lineTo (P (11.6f, 8));
                    g.strokePath (p, st);
                    g.fillRoundedRectangle (x + 2.5f, y + 7.5f, 11, 7.5f, 1.8f);
                    break;
            }
        }

        Icon icon;
    };

    /** Bảng Cài đặt: thanh tren (tieu de + o tim + X), tab doc ben trai. */
    class SettingsShell final : public juce::Component
    {
    public:
        using Icon = SettingsTabButton::Icon;

        SettingsShell()
        {
            setOpaque (true);
            tabViewport.setScrollBarsShown (true, false);
            tabViewport.setScrollBarThickness (7);
            tabViewport.setViewedComponent (&tabContent, false);
            addAndMakeVisible (tabViewport);

            closeButton.setButtonText ("X");
            closeButton.setTooltip (livent::vn ("Đóng Cài đặt"));
            closeButton.setWantsKeyboardFocus (false);
            closeButton.getProperties().set ("settingsClose", true);
            closeButton.setColour (juce::TextButton::buttonColourId, Col::panel);
            closeButton.setColour (juce::TextButton::textColourOffId, Col::text);
            closeButton.onClick = [this] { requestClose(); };
            addAndMakeVisible (closeButton);

            search.setTextToShowWhenEmpty (livent::vn ("Tìm cài đặt…  (vd: mật khẩu, F4, bè)"), Col::textDim);
            search.setFont (juce::Font (juce::FontOptions (13.0f)));
            search.setIndents (28, 0);
            search.setJustification (juce::Justification::centredLeft);
            search.setColour (juce::TextEditor::backgroundColourId, Col::bg);
            search.setColour (juce::TextEditor::textColourId, Col::text);
            search.setColour (juce::TextEditor::outlineColourId, Col::line.withAlpha (0.7f));
            search.setColour (juce::TextEditor::focusedOutlineColourId, Col::accent);
            search.onTextChange = [this] { updateSearch(); };
            search.onEscapeKey = [this]
            {
                if (search.isEmpty())
                {
                    requestClose();
                    return;
                }
                search.clear();
                updateSearch();
            };
            addAndMakeVisible (search);
        }

        ~SettingsShell() override
        {
            searchPage.reset();
            tabViewport.setViewedComponent (nullptr, false);
        }

        /** searchable: cac dong cua the nay de o tim kiem tim thay. */
        void addPage (const juce::String& name, Icon icon, juce::Component* page, int preferredHeight,
                      std::vector<SettingsItem> searchable = {})
        {
            const int index = pages.size();
            auto* b = tabButtons.add (new SettingsTabButton (name, icon));
            b->setClickingTogglesState (false);
            b->onClick = [this, index] { selectPage (index); };
            tabContent.addAndMakeVisible (b);

            pages.add (page);
            addChildComponent (page);
            page->setVisible (false);
            pageNames.add (name);
            pageItems.push_back (std::move (searchable));
            preferredH = juce::jmax (preferredH, preferredHeight);
        }

        /** Chieu cao bang de the dai nhat khong phai cuon. */
        int getPreferredTotalHeight() const
        {
            return juce::jmax (topH + preferredH + 10, 12 + tabButtons.size() * (tabH + tabGap) + topH);
        }

        std::function<void()> onCloseRequested;

        /** 06/10: mo thang mot trang theo ten (vd "Gán nút" tu bang EQ mic). */
        bool selectPageNamed (const juce::String& name)
        {
            const int i = pageNames.indexOf (name);
            if (i < 0) return false;
            selectPage (i);
            return true;
        }

        void selectFirstPageIfNeeded()
        {
            if (activeIndex < 0 && pages.size() > 0)
                selectPage (0);
        }

        void paint (juce::Graphics& g) override
        {
            g.fillAll (Col::panel);
            auto r = getLocalBounds();
            auto top = r.removeFromTop (topH);
            g.setColour (Col::textDim);
            g.setFont (juce::Font (juce::FontOptions (12.5f).withStyle ("Bold")));
            g.drawText (livent::vn ("CÀI ĐẶT"), top.withTrimmedLeft (14).withWidth (80), juce::Justification::centredLeft, false);
            g.setColour (Col::line.withAlpha (0.7f));
            g.drawHorizontalLine (topH - 1, 0.0f, (float) getWidth());

            const int stripWidth = getStripWidth();
            auto strip = r.removeFromLeft (stripWidth);
            g.setColour (Col::bg.withAlpha (0.35f));
            g.fillRect (strip);
            g.setColour (Col::line.withAlpha (0.6f));
            g.drawVerticalLine (stripWidth, (float) topH, (float) getHeight());

            g.setColour (Col::line.withAlpha (0.82f));
            g.drawRoundedRectangle (getLocalBounds().toFloat().reduced (0.5f), 10.0f, 1.0f);
        }

        // 12q: keo cua so Cai dat bang thanh "CAI DAT" tren cung (cua so khong co thanh tieu de that).
        void mouseDown (const juce::MouseEvent& e) override
        {
            auto* top = getTopLevelComponent();
            dragging = top != nullptr && e.getMouseDownPosition().y < topH;
            if (dragging)
                windowDragger.startDraggingComponent (top, e);
        }
        void mouseDrag (const juce::MouseEvent& e) override
        {
            if (dragging)
                if (auto* top = getTopLevelComponent())
                    windowDragger.dragComponent (top, e, nullptr);
        }
        void mouseUp (const juce::MouseEvent&) override { dragging = false; }

        void paintOverChildren (juce::Graphics& g) override
        {
            // ve lai kinh lup tren o tim (o tim ve de len)
            const auto sb = search.getBounds().toFloat();
            const float cx = sb.getX() + 13.0f, cy = sb.getCentreY();
            juce::Path lens;
            lens.addEllipse (cx - 5.0f, cy - 5.0f, 8.5f, 8.5f);
            lens.startNewSubPath (cx + 2.4f, cy + 2.4f);
            lens.lineTo (cx + 5.5f, cy + 5.5f);
            g.setColour (Col::textDim);
            g.strokePath (lens, juce::PathStrokeType (1.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }

        void resized() override
        {
            auto r = getLocalBounds().reduced (1);
            auto top = r.removeFromTop (topH - 1);
            closeButton.setBounds (top.removeFromRight (40).withSizeKeepingCentre (28, 28));
            top.removeFromLeft (92);
            search.setBounds (top.reduced (0, 8).withTrimmedRight (4));

            auto strip = r.removeFromLeft (getStripWidth());
            tabViewport.setBounds (strip);
            tabContent.setSize (juce::jmax (1, strip.getWidth() - 8),
                                juce::jmax (strip.getHeight(), 16 + tabButtons.size() * (tabH + tabGap)));
            auto tabArea = tabContent.getLocalBounds().reduced (6, 8);
            for (auto* b : tabButtons)
            {
                b->setBounds (tabArea.removeFromTop (tabH));
                tabArea.removeFromTop (tabGap);
            }

            pageArea = r.reduced (2, 2);
            for (int i = 0; i < pages.size(); ++i)
            {
                const bool show = searchPage == nullptr && i == activeIndex;
                pages[i]->setVisible (show);
                pages[i]->setBounds (show ? pageArea : juce::Rectangle<int>());
            }
            if (searchPage != nullptr)
                searchPage->setBounds (pageArea);
        }

    private:
        static constexpr int topH = 46, tabH = 38, tabGap = 3;

        int getStripWidth() const { return getWidth() < 580 ? 124 : 160; }

        void requestClose()
        {
            // Không huỷ chính SettingsShell ngay giữa callback. Đẩy sang nhịp sau.
            auto cb = onCloseRequested;
            juce::MessageManager::callAsync ([cb] { if (cb) cb(); });
        }

        void selectPage (int index)
        {
            if (! juce::isPositiveAndBelow (index, pages.size()))
                return;

            activeIndex = index;
            if (! search.isEmpty())
                search.clear();
            closeSearchPageLater();

            for (int i = 0; i < tabButtons.size(); ++i)
                tabButtons[i]->setToggleState (i == activeIndex, juce::dontSendNotification);

            resized();
            repaint();
        }

        /** Dong trang ket qua o nhip sau (co the dang o trong callback cua chinh no). */
        void closeSearchPageLater()
        {
            if (searchPage == nullptr)
                return;
            searchPage->setVisible (false);
            auto* old = searchPage.release();
            juce::MessageManager::callAsync ([old] { delete old; });
        }

        void updateSearch()
        {
            const auto query = foldVietnamese (search.getText().trim());

            if (query.isEmpty())
            {
                closeSearchPageLater();
                for (int i = 0; i < tabButtons.size(); ++i)
                    tabButtons[i]->setToggleState (i == activeIndex, juce::dontSendNotification);
                resized();
                return;
            }

            const auto words = juce::StringArray::fromTokens (query, " ", "");
            auto matches = [&words] (const juce::String& hay)
            {
                const auto f = foldVietnamese (hay);
                for (auto& w : words)
                    if (w.isNotEmpty() && ! f.contains (w))
                        return false;
                return true;
            };

            std::vector<SettingsItem> found;
            juce::Component::SafePointer<SettingsShell> safe (this);

            for (int p = 0; p < pages.size(); ++p)
            {
                const auto& tab = pageNames[p];

                if (matches (tab))
                {
                    SettingsItem go;
                    go.label = livent::vn ("Mở thẻ: ") + tab;
                    go.note = livent::vn ("Chuyển sang thẻ ") + tab;
                    go.action = [safe, p]
                    {
                        juce::MessageManager::callAsync ([safe, p] { if (safe != nullptr) safe->selectPage (p); });
                    };
                    found.push_back (go);
                }

                for (const auto& it : pageItems[(size_t) p])
                {
                    if (it.kind == SettingsItem::Kind::section)
                        continue;
                    const auto lbl = it.labelFn ? it.labelFn() : it.label;
                    if (! matches (lbl + " " + it.note + " " + it.searchExtra + " " + tab))
                        continue;

                    auto copy = it;
                    if (copy.kind == SettingsItem::Kind::mini)
                        copy.kind = SettingsItem::Kind::row;
                    const auto baseNote = it.note;
                    copy.note = tab + (baseNote.isNotEmpty() ? livent::vn (" · ") + baseNote : juce::String());
                    if (it.noteFn)
                    {
                        auto fn = it.noteFn;
                        copy.noteFn = [fn, tab] { return tab + livent::vn (" · ") + fn(); };
                    }
                    found.push_back (copy);
                }
            }

            if (found.empty())
            {
                SettingsItem none;
                none.label = livent::vn ("Không tìm thấy cài đặt nào");
                none.note = livent::vn ("Thử gõ ngắn hơn, vd: \"khoa\", \"youtube\", \"vang\"");
                none.enabled = false;
                found.push_back (none);
            }

            closeSearchPageLater();
            searchPage.reset (new SettingsPage (found));
            addAndMakeVisible (*searchPage);

            for (auto* b : tabButtons)
                b->setToggleState (false, juce::dontSendNotification);
            resized();
        }

        int activeIndex = -1;
        int preferredH = 0;
        juce::Rectangle<int> pageArea;
        juce::TextButton closeButton;
        juce::ComponentDragger windowDragger;
        bool dragging = false;
        juce::TextEditor search;
        juce::Viewport tabViewport;
        juce::Component tabContent;
        juce::OwnedArray<SettingsTabButton> tabButtons;
        juce::OwnedArray<juce::Component> pages;
        juce::StringArray pageNames;
        std::vector<std::vector<SettingsItem>> pageItems;
        std::unique_ptr<juce::Component> searchPage;
        juce::TooltipWindow tooltips { this, 650 };

        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SettingsShell)
    };

    /** Cửa sổ không có title-bar, giống bảng Tiếng cười nhưng dành cho Cài đặt. */
    class SettingsPopupWindow final : public juce::DocumentWindow
    {
    public:
        // App zoom changes the DAW only; Settings keeps normal-size controls.
        float getDesktopScaleFactor() const override { return 1.0f; }

        SettingsPopupWindow (SettingsShell* shell, std::function<void()> closeFn)
            : juce::DocumentWindow (livent::vn ("Cài đặt"), Col::panel, 0, false),
              onClose (std::move (closeFn))
        {
            setUsingNativeTitleBar (false);
            setTitleBarHeight (0);
            setResizable (true, false);
            setDropShadowEnabled (true);
            setAlwaysOnTop (true);
            setBroughtToFrontOnMouseClick (true);
            setContentOwned (new livent::textscale::Host (shell), false);   // 14/10: co chu Cai dat
            // Create the peer after construction reaches this derived class,
            // so its scale is 1.0 even when Settings is first opened at 75%.
            addToDesktop();
        }

        void closeButtonPressed() override { requestClose(); }

        bool keyPressed (const juce::KeyPress& k) override
        {
            if (k.getKeyCode() == juce::KeyPress::escapeKey)
            {
                requestClose();
                return true;
            }
            return juce::DocumentWindow::keyPressed (k);
        }

    private:
        void requestClose()
        {
            if (closeQueued)
                return;

            closeQueued = true;
            auto cb = onClose;
            juce::MessageManager::callAsync ([cb]
            {
                if (cb)
                    cb();
            });
        }

        std::function<void()> onClose;
        bool closeQueued = false;
        JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (SettingsPopupWindow)
    };

}

//=============================================================================
//  V4.3: TUY CHINH GIAO DIEN - XEM TRUOC TRUOC KHI LUU
//=============================================================================
/*  12o: cua so + thanh tieu de + nut thanh dau + chu thuong hieu di theo kieu rack dang chon. */
void MainComponent::applyRackChrome()
{
    const auto txt = livent::rack::chromeText (Col::text);
    projectNameLabel.setColour (juce::Label::textColourId, txt);
    topBrandLabel.setColour (juce::Label::textColourId, txt);
    const auto dimTxt = livent::rack::active() ? livent::rack::textDimOnPlate() : Col::textDim;
    cpuLabel.setColour (juce::Label::textColourId, dimTxt);
    statusLabel.setColour (juce::Label::textColourId, dimTxt);
    juce::TextButton* hb[] = { &topRecordButton, &topExportButton, &topLaughButton,
                               &topSaveSongButton, &topSongListButton, &topYouTubeButton,
                               &topFileButton, &topSettingsButton, &topLayoutButton, &topHelpButton };
    for (auto* b : hb)
    {
        b->setColour (juce::TextButton::buttonColourId, livent::rack::chromePanel (Col::panel));
        b->setColour (juce::TextButton::textColourOffId, livent::rack::newStyle() ? livent::rack::fnTextColour (false) : txt);
        // 12w: kieu moi -> nut thanh dau ve thanh phim cua kieu (kieu Nhom / phang giu nguyen)
        if (livent::rack::newStyle()) b->getProperties().set ("rackChrome", true);
        else                          b->getProperties().remove ("rackChrome");
        b->repaint();
    }
    repaint();
}

void MainComponent::openDawBackgroundMenu()
{
    /*  V4.7: thay hop thoai ComboBox cu bang bo chon dang CARD nhu mockup.
        Bon chu de toi, preview truc tiep, Galaxy tach rieng. Tat ca chi la
        mau/ve 2D - khong chen bat ky viec gi vao audio thread. */
    const auto oldTheme = Col::snapshot();
    juce::Component::SafePointer<MainComponent> safe (this);

    auto refreshPreview = [safe]
    {
        if (safe == nullptr)
            return;

        safe->rebuildTrackList();
        safe->mixerView.rebuild();
        safe->tonePanel.refreshRackSkin();   // 12o: tam nhom, LCD, mau nut/num theo kieu vua chon
        safe->applyRackChrome();
        safe->repaint();
        safe->workArea.repaint();
        safe->tonePanel.repaint();
        safe->relayoutAll();
    };

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (new ThemeChooser (oldTheme, refreshPreview));
    o.dialogTitle = livent::vn ("Giao diện màu");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = true;

    if (auto* dialog = livent::launchDialog (o))
    {
        auto& displays = juce::Desktop::getInstance().getDisplays();
        if (auto* display = displays.getDisplayForRect (dialog->getScreenBounds()))
        {
            const int maxW = juce::jmax (1, display->userArea.getWidth() - 16);
            const int maxH = juce::jmax (1, display->userArea.getHeight() - 16);
            dialog->setResizeLimits (juce::jmin (360, maxW), juce::jmin (250, maxH), maxW, maxH);
        }
        livent::bringDialogToFront (dialog);
    }
}

//=============================================================================
// MOC 96: DOI MAT KHAU F2 KHONG CAN BUILD LAI
//=============================================================================
void MainComponent::changeWorkPanelPassword()
{
    auto* w = livent::makeAlert (livent::vn ("Đổi mật khẩu Bàn làm việc"),
                                     livent::vn ("Nhập mật khẩu hiện tại, rồi nhập mật khẩu mới hai lần."),
                                     juce::MessageBoxIconType::QuestionIcon);

    w->addTextEditor ("oldPass", juce::String(), livent::vn ("Mật khẩu hiện tại"), true);
    w->addTextEditor ("newPass", juce::String(), livent::vn ("Mật khẩu mới"), true);
    w->addTextEditor ("confirmPass", juce::String(), livent::vn ("Nhập lại mật khẩu mới"), true);

    w->addButton (livent::vn ("Đổi mật khẩu"), 1,
                  juce::KeyPress (juce::KeyPress::returnKey));
    w->addButton (livent::vn ("Huỷ"), 0,
                  juce::KeyPress (juce::KeyPress::escapeKey));

    w->setAlwaysOnTop (true);

    juce::Component::SafePointer<MainComponent> safe (this);

    w->setAlwaysOnTop (true);
    livent::centreDialog (w);
    w->enterModalState (true, juce::ModalCallbackFunction::create (
        [w, safe] (int result)
        {
            const auto oldPass = w->getTextEditorContents ("oldPass").trim();
            const auto newPass = w->getTextEditorContents ("newPass").trim();
            const auto confirm = w->getTextEditorContents ("confirmPass").trim();

            delete w;

            if (safe == nullptr || result != 1)
                return;

            if (oldPass != safe->workPanelPassword)
            {
                livent::alert (livent::vn ("Đổi mật khẩu"),
                               livent::vn ("Mật khẩu hiện tại không đúng."),
                               juce::MessageBoxIconType::WarningIcon);
                return;
            }

            if (newPass.length() < 4)
            {
                livent::alert (livent::vn ("Đổi mật khẩu"),
                               livent::vn ("Mật khẩu mới phải có ít nhất 4 ký tự."),
                               juce::MessageBoxIconType::WarningIcon);
                return;
            }

            if (newPass != confirm)
            {
                livent::alert (livent::vn ("Đổi mật khẩu"),
                               livent::vn ("Hai lần nhập mật khẩu mới không giống nhau."),
                               juce::MessageBoxIconType::WarningIcon);
                return;
            }

            safe->workPanelPassword = newPass;
            saveWorkPanelPassword (newPass);

            livent::alert (livent::vn ("Đổi mật khẩu"),
                           livent::vn ("Đã đổi mật khẩu Bàn làm việc."));
        }), false);

    w->toFront (true);

    livent::focusAlertTextEditorAfterShow (w, "oldPass");
}

//=============================================================================
//  MOC 75: BANG CAI DAT
//
//  Gom het moi thu truoc gio nam rai rac trong 6 menu tren cung vao MOT
//  bang co tab. Ly do: tu Moc 75 thanh menu an duoc, ma an roi thi phai con
//  MOT duong khac vao duoc moi thu -- nut CAI DAT tren bang dieu khien.
//
//  Cac nut o day KHONG viet lai gi ca: chung goi thang menuItemSelected()
//  voi dung ma so muc menu cu. Nho vay bang cai dat va thanh menu khong bao
//  gio lam hai viec khac nhau, va sua mot cho la ca hai cung doi.
//=============================================================================
void MainComponent::openSettingsDialog()
{
    // Nút Cài đặt hoạt động như công tắc: đang mở thì bấm lần nữa để thu lại.
    if (settingsWindow != nullptr)
    {
        settingsWindow.reset();
        return;
    }

    juce::Component::SafePointer<MainComponent> safe (this);

    auto menu = [safe] (int itemId, int topLevelIndex)
    {
        return [safe, itemId, topLevelIndex]
        {
            if (safe == nullptr)
                return;

            safe->menuItemSelected (itemId, topLevelIndex);

            // V6.6 FIX: chọn xong một mục Cài đặt thì đóng bảng Cài đặt.
            // Đóng ở nhịp message kế tiếp để callback hiện tại kết thúc an toàn.
            juce::MessageManager::callAsync ([safe]
            {
                if (safe != nullptr)
                {
                    safe->settingsWindow.reset();
                }
            });
        };
    };

   #if JUCE_MAC
    auto chooseBrowserForLink = [safe]
    {
        if (safe == nullptr)
            return;

        juce::PopupMenu m;
        const auto current = safe->tonePanel.getPreferredBrowser();

        m.addSectionHeader (livent::vn ("Trình duyệt lấy link"));
        m.addItem (1, "Google Chrome",  true, current == "Google Chrome");
        m.addItem (2, "Safari",         true, current == "Safari");
        m.addItem (3, "CocCoc",         true, current == "CocCoc");
        m.addItem (4, "Brave Browser",  true, current == "Brave Browser");
        m.addItem (5, "Microsoft Edge", true, current == "Microsoft Edge");
        m.addItem (6, "YouTube",        true, current == "YouTube");

        m.showMenuAsync (livent::menuAtPointer (safe.getComponent()), [safe] (int result)
        {
            if (safe == nullptr || result == 0)
                return;

            juce::String name;
            switch (result)
            {
                case 1: name = "Google Chrome";  break;
                case 2: name = "Safari";         break;
                case 3: name = "CocCoc";         break;
                case 4: name = "Brave Browser";  break;
                case 5: name = "Microsoft Edge"; break;
                case 6: name = "YouTube";        break;
                default: return;
            }

            safe->tonePanel.setPreferredBrowser (name);
            saveBrowserPref (name);

            // Dong bang de lan mo lai dong mo ta hien dung browser vua chon.
            juce::MessageManager::callAsync ([safe]
            {
                if (safe != nullptr)
                    safe->settingsWindow.reset();
            });
        });
    };
   #endif

    const auto hostBounds = getTopLevelComponent() != nullptr
                          ? getTopLevelComponent()->getScreenBounds()
                          : getScreenBounds();

    auto& displays = juce::Desktop::getInstance().getDisplays();
    auto* display = displays.getDisplayForRect (hostBounds);
    if (display == nullptr)
        display = displays.getPrimaryDisplay();

    const auto work = display != nullptr ? livent::settingsScreenBounds (display->userArea)
                                         : juce::Rectangle<int> (0, 0, 1366, 768);

    constexpr int edge = 6;
    constexpr int minPopupH = 250;

    const double textScale = livent::textscale::get();   // 14/10: 1.0 = nhu cu
    const int maxW = juce::jmax (1, work.getWidth() - edge * 2);
    const int maxH = juce::jmax (1, work.getHeight() - edge * 2);
    const int logicalMaxW = juce::jmax (1, juce::roundToInt (maxW / textScale));
    const int logicalMaxH = juce::jmax (1, juce::roundToInt (maxH / textScale));
    const int popupW = juce::jmin (logicalMaxW, 700);

    /*  02/10 (anh chot demo 2): 6 the, moi the chia nhom.
          - Cong tac Bat/Tat: bam xong BANG VAN MO, chi doi trang thai
            (doc lai trang thai that 5 lan/giay).
          - Muc mo cua so khac (dau mui ten): bang tu dong nhu cu.  */
    auto menuKeep = [safe] (int itemId, int topLevelIndex)
    {
        return [safe, itemId, topLevelIndex]
        {
            if (safe != nullptr)
                safe->menuItemSelected (itemId, topLevelIndex);
        };
    };

    auto closing = [safe] (std::function<void()> fn)
    {
        return [safe, fn]
        {
            if (safe == nullptr)
                return;
            juce::MessageManager::callAsync ([safe, fn]
            {
                if (safe == nullptr)
                    return;
                safe->settingsWindow.reset();
                if (fn)
                    fn();
            });
        };
    };

    using Kind = SettingsItem::Kind;
    auto row = [] (const juce::String& label, const juce::String& note, std::function<void()> action)
    {
        SettingsItem it;
        it.label = label;
        it.note = note;
        it.action = std::move (action);
        return it;
    };
    auto toggle = [] (const juce::String& label, const juce::String& note,
                      std::function<void()> action, std::function<bool()> state)
    {
        SettingsItem it;
        it.label = label;
        it.note = note;
        it.action = std::move (action);
        it.isToggle = true;
        it.state = std::move (state);
        it.toggleOn = it.state ? it.state() : false;
        return it;
    };
    auto mini = [] (const juce::String& label, std::function<void()> action)
    {
        SettingsItem it;
        it.label = label;
        it.action = std::move (action);
        it.kind = Kind::mini;
        return it;
    };

    auto* shell = new SettingsShell();
    auto addSettingsPage = [shell] (const juce::String& name, SettingsShell::Icon icon,
                                    const std::vector<SettingsItem>& v,
                                    juce::Component* header = nullptr, int headerH = 0)
    {
        auto* page = new SettingsPage (v, header, headerH);
        shell->addPage (name, icon, page, page->getPreferredHeight(), v);
    };

    // 1. ÂM THANH --------------------------------------------------------------
    {
        std::vector<SettingsItem> v;
        v.push_back (settingsSection (livent::vn ("Thiết bị")));
        // 15/10: soundcard + duong am thanh da gop chung 1 cua so -> chi con 1 dong.
        v.push_back (row (livent::vn ("Thiết lập âm thanh  (F4)"),
                          livent::vn ("Soundcard (ASIO / CoreAudio), tần số, bộ đệm • đầu vào / đầu ra"),
                          menu (301, menuStudio)));
        v.push_back (row (livent::vn ("Bù trễ thu âm / đo trễ card"),
                          livent::vn ("Giọng thu khớp nhạc • đo độ trễ thật bằng dây nối ngõ ra → ngõ vào"),
                          menu (321, menuStudio)));

       #if JUCE_WINDOWS
        v.push_back(row(livent::vn("Hướng dẫn thiết lập âm thanh bằng ảnh"),livent::vn("Cửa sổ riêng • vừa xem ảnh vừa thiết lập ASIO / đường âm thanh"),[safe]{if(safe)safe->showAudioSetupGuide();}));
       #endif

        v.push_back (settingsSection (livent::vn ("Khóa soundcard")));
        {
            auto it = toggle (livent::vn ("Khóa soundcard"),
                              livent::vn ("Khóa đúng driver + thiết bị đang chạy; lần sau sai / thiếu thì chặn DAW"),
                              [safe]
                              {
                                  if (safe == nullptr) return;
                                  // Bat khoa lan dau khong can mat khau; go / doi khoa thi phai co.
                                  if (! safe->soundcardLockEnabled) { safe->toggleSoundcardLock(); return; }
                                  safe->withAdminPassword (livent::vn ("Khóa soundcard"),
                                                           [safe] { if (safe != nullptr) safe->toggleSoundcardLock(); });
                              },
                              [safe] { return safe != nullptr && safe->soundcardLockEnabled; });
            it.labelFn = [safe]
            {
                if (safe == nullptr || ! safe->soundcardLockEnabled)
                    return livent::vn ("Khóa soundcard");
                return livent::vn ("Khóa soundcard: ") + safe->getSoundcardLockDisplayName();
            };
            v.push_back (it);
        }
        v.push_back (row (livent::vn ("Chọn thủ công để khóa..."),
                          livent::vn ("Tự chọn driver, vào/ra, buffer, sample rate rồi khóa đúng cấu hình đó"),
                          closing ([safe]
                          {
                              if (safe == nullptr) return;
                              if (! safe->soundcardLockEnabled) { safe->openAudioSettings (true); return; }
                              safe->withAdminPassword (livent::vn ("Khóa soundcard"),
                                                       [safe] { if (safe != nullptr) safe->openAudioSettings (true); });
                          })));

        v.push_back (settingsSection (livent::vn ("Chế độ")));
        v.push_back (toggle (livent::vn ("Chế độ Live (tắt hết tính năng thu âm)"),
                             livent::vn ("Bật khi hát live cho khách: tắt thu âm, chờ thu, bù trễ thu, Lane, vẽ sóng thu và ARA cho nhẹ máy. "
                                         "VST vẫn mở chỉnh bình thường. Tắt đi thì thu âm như trước."),
                             [safe] { if (safe != nullptr) safe->setLiveMode (! safe->mixer.isLiveMode()); },
                             [safe] { return safe != nullptr && safe->mixer.isLiveMode(); }));

        v.push_back (settingsSection (livent::vn ("Công cụ")));
        v.push_back (row (livent::vn ("Gửi Tông / Thang âm vào rãnh..."),
                          livent::vn ("Chọn rãnh và VST nhận Tông / Thang âm tự động"),
                          menu (307, menuStudio)));
        v.push_back (row (livent::vn ("Đo giật tiếng trong 10 giây"),
                          livent::vn ("Hát bình thường: tìm VST gây rè / giật, lưu báo cáo"),
                          [safe] { if (safe != nullptr) safe->runAudioDropoutDiagnosis (10); }));
        v.push_back (row (livent::vn ("Đo giật tiếng trong 60 giây"),
                          livent::vn ("Cho tiếng \"tách\" thỉnh thoảng mới có: hát nguyên 1 phút rồi xem báo cáo"),
                          [safe] { if (safe != nullptr) safe->runAudioDropoutDiagnosis (60); }));
        addSettingsPage (livent::vn ("Âm thanh"), SettingsShell::Icon::sound, v);
    }

    // 2. VST / HIỆU ỨNG --------------------------------------------------------
    {
        std::vector<SettingsItem> v;
        v.push_back (settingsSection (livent::vn ("Auto-Tune")));
        v.push_back (toggle (livent::vn ("Auto-Tune: dùng Modern Scale"),
                             livent::vn ("Bật khi Auto-Tune chọn Scales: Modern; tắt khi dùng Legacy. Áp dụng cả gửi và đọc Scale."),
                             []
                             {
                                 if (!TonePush::saveModernScalePreference(!TonePush::usesModernScale()))
                                     livent::alert (livent::vn ("Không lưu được cài đặt"),
                                                    livent::vn ("Không ghi được tùy chọn Modern Scale vào thư mục cài đặt."));
                             },
                             [] { return TonePush::usesModernScale(); }));
        // 31/10: gui tong kieu Auto-Key - moi Auto-Tune dang nhan Auto-Key deu nhan, khong can set o VST
        v.push_back (toggle (livent::vn ("Gửi tông kiểu Auto-Key (mọi Auto-Tune đều nhận)"),
                             livent::vn ("DAW ghi tông vào file Auto-Key như T-AutoKey: mọi Auto-Tune đang bật nhận Auto-Key (3, 4 con, track nào cũng được) và T-AutoTune đều nhận. "
                                         "Vẫn ghi thẳng vào Auto-Tune tìm thấy trong project để dự phòng. Đừng cắm thêm VST Auto-Key/T-AutoKey cùng lúc kẻo 2 bên gửi đè nhau."),
                             []
                             {
                                 if (! livent::akbroadcast::setEnabled (! livent::akbroadcast::enabled()))
                                     livent::alert (livent::vn ("Không lưu được cài đặt"),
                                                    livent::vn ("Không ghi được tùy chọn gửi tông kiểu Auto-Key vào thư mục cài đặt."));
                             },
                             [] { return livent::akbroadcast::enabled(); }));
        v.push_back (settingsSection (livent::vn ("Tự động")));
        // 15/10: vang tu bat khi co nhac, tu tat khi het nhac (khach ngoi noi chuyen khong bi vang)
        v.push_back (toggle (livent::vn ("Vang tự bật khi có nhạc"),
                             livent::vn ("Dò xong Key/Scale bài đang mở + có nhạc → bật Vang (máy chủ dò lỗi: có nhạc ~5 giây cũng bật). Nhạc dừng ~3 giây → tắt Vang. Bấm tay giữa bài vẫn được."),
                             [safe] { if (safe != nullptr) safe->tonePanel.setAutoVangByMusic (! safe->tonePanel.isAutoVangByMusic()); },
                             [safe] { return safe != nullptr && safe->tonePanel.isAutoVangByMusic(); }));
       #if JUCE_WINDOWS
        v.push_back (toggle (livent::vn ("Auto-Key 2 tự nghe nhạc"),
                             livent::vn ("Nghe khi track NHẠC có tiếng; không cần chạy Play / Thu"),
                             [safe]
                             {
                                 if (safe == nullptr) return;
                                 const bool enabled = ! safe->mixer.isAutoKeyListenEnabled();
                                 if (saveAutoKeyListenPref (enabled))
                                     safe->mixer.setAutoKeyListenEnabled (enabled);
                                 else
                                     livent::alert (livent::vn ("Không lưu được cài đặt"),
                                                    livent::vn ("Không ghi được chế độ Auto-Key 2 vào thư mục cài đặt."));
                             },
                             [safe] { return safe != nullptr && safe->mixer.isAutoKeyListenEnabled(); }));

        // 12s: bo muc "Tu bam Auto-Key / do tay..." - da thay bang T-AutoKey co san (khong bam chuot nua).
        // Thoi gian cho AI (vpsWaitSeconds) van doc tu file cai dat cu, mac dinh 10 giay.
       #endif
        {
            auto it = toggle (livent::vn ("Tự mở VST số 2 của track NHẠC"),
                              livent::vn ("Mở project và ô 2 có VST: hiện cửa sổ ở vị trí đã lưu"),
                              [safe]
                              {
                                  if (safe == nullptr || ! safe->projectOpen
                                      || safe->currentProjectFile == juce::File())
                                      return;

                                  const bool before = safe->autoOpenMusicVst2;
                                  safe->autoOpenMusicVst2 = ! before;
                                  if (! safe->saveMusicVst2WindowPreference (safe->currentProjectFile))
                                  {
                                      safe->autoOpenMusicVst2 = before;
                                      livent::alert (livent::vn ("Chưa lưu được tùy chọn"),
                                                     livent::vn ("Không ghi được cài đặt cửa sổ VST cạnh file project .NT."));
                                      return;
                                  }

                                  safe->markProjectDirty();
                                  safe->updateTitleText();

                                  if (safe->autoOpenMusicVst2 && ! safe->projectLoadInProgress)
                                  {
                                      const auto projectFile = safe->currentProjectFile;
                                      juce::MessageManager::callAsync ([safe, projectFile]
                                      {
                                          if (safe != nullptr && safe->currentProjectFile == projectFile)
                                              safe->openMusicVst2AfterProjectLoad();
                                      });
                                  }
                              },
                              [safe] { return safe != nullptr && safe->autoOpenMusicVst2; });
            it.enabledFn = [safe] { return safe != nullptr && safe->projectOpen
                                           && safe->currentProjectFile != juce::File(); };
            v.push_back (it);
        }

        v.push_back (settingsSection (livent::vn ("Hiệu năng")));
        v.push_back (toggle (livent::vn ("Chế độ biểu diễn - tiết kiệm CPU"),
                             livent::vn ("Giảm vẽ và cửa sổ VST để ưu tiên âm thanh"),
                             menuKeep (304, menuStudio),
                             [safe] { return safe != nullptr && safe->pluginWindows.isPerformanceMode(); }));
       #if JUCE_WINDOWS
        v.push_back (toggle (livent::vn ("Đệm an toàn cho VST 32-bit"),
                             livent::vn ("Chống \"tách\" ở buffer 256 trở xuống: VST 32-bit trễ thêm 1 block, tự bù trễ"),
                             []
                             {
                                 const bool enabled = ! Bridge32Client::safetyBufferEnabled().load();
                                 if (saveBridge32SafetyPref (enabled))
                                     Bridge32Client::safetyBufferEnabled().store (enabled);   // Mixer ap dung trong ~50 ms
                                 else
                                     livent::alert (livent::vn ("Không lưu được cài đặt"),
                                                    livent::vn ("Không ghi được tùy chọn đệm an toàn VST 32-bit vào thư mục cài đặt."));
                             },
                             [] { return Bridge32Client::safetyBufferEnabled().load(); }));
       #endif

        // 15/10: nho lua chon hoi doi VST 32-bit -> 64-bit
        v.push_back (settingsSection (livent::vn ("Dự án dùng VST 32-bit mà máy có bản 64-bit")));
        {
            const char* labels[] = { "Luôn hỏi", "Luôn đổi sang 64-bit (khuyên dùng)", "Luôn giữ 32-bit" };
            const char* notes[]  = { "Mỗi lần mở dự án đều hỏi",
                                     "Tự đổi và gắn thông số cũ sang, báo nhẹ ở thanh dưới",
                                     "Mở đúng như lúc lưu dự án" };
            for (int mode = 0; mode < 3; ++mode)
            {
                auto it = row (livent::vn (labels[mode]), livent::vn (notes[mode]),
                               [mode] { saveVst32UpgradePref (mode); });
                it.kind = Kind::radio;
                it.state = [mode] { return loadVst32UpgradePref() == mode; };
                it.toggleOn = loadVst32UpgradePref() == mode;
                it.searchExtra = "vst 32 64 bit doi hoi bridge";
                v.push_back (it);
            }
        }

        v.push_back (settingsSection (livent::vn ("Quét VST")));
        v.push_back (row (livent::vn ("Quét VST..."),
                          livent::vn ("Tìm VST mới hoặc đã thay đổi; quét lại toàn bộ khi cần"),
                          menu (302, menuStudio)));
        v.push_back (row (livent::vn ("Thư mục quét VST..."),
                          livent::vn ("Thêm hoặc bỏ đường dẫn chứa VST2 / VST3"),
                          menu (303, menuStudio)));

        v.push_back (settingsSection (livent::vn ("Kỹ thuật · ít dùng")));
        v.push_back (mini (livent::vn ("Cầu nối VST 32-bit (kiểm tra LiveNTBridge32.exe)"),
                           closing ([]
                           {
                               const auto bridge = MainComponent::getVst32BridgeFile();
                               livent::alert (livent::vn ("Cầu nối VST 32-bit"),
                                              (bridge.existsAsFile() ? livent::vn ("Đã tìm thấy:\n")
                                                                     : livent::vn ("Chưa tìm thấy:\n"))
                                              + bridge.getFullPathName());
                           })));
        v.push_back (mini (livent::vn ("Mở nhật ký quét"), menu (502, menuHelp)));
        v.push_back (mini (livent::vn ("Ghi thông số VST ra file (gửi kỹ thuật)"),
                           closing ([safe]
                           {
                               if (safe == nullptr) return;
                               if (! safe->projectOpen)
                               {
                                   livent::alert (livent::vn ("Chưa mở dự án"),
                                                  livent::vn ("Hãy mở dự án có VST cần kiểm tra rồi bấm lại."));
                                   return;
                               }
                               safe->dumpPluginParametersToFile();
                           })));
        addSettingsPage (livent::vn ("VST / Hiệu ứng"), SettingsShell::Icon::vst, v);
    }

    // 3. GIAO DIỆN (gom ca Bang dieu khien cu) ---------------------------------
    {
        std::vector<SettingsItem> v;
        v.push_back (settingsSection (livent::vn ("Màu & cỡ chữ")));
        v.push_back (row (livent::vn ("Kiểu giao diện...  (F5)"),
                          livent::vn ("25 kiểu: nền cửa sổ, F2, F3, bảng điều khiển, chữ và màn LCD đổi cùng lúc. Xem trước trực tiếp"),
                          menu (415, menuView)));
        {
            SettingsItem z;
            z.label = livent::vn ("Thu phóng");
            z.kind = Kind::segment;
            z.segments = { "75%", "100%", "125%" };
            z.searchExtra = "zoom phong to thu nho co chu";
            z.segmentIndex = []
            {
                const float sc = juce::Desktop::getInstance().getGlobalScaleFactor();
                if (std::abs (sc - 0.75f) < 0.02f) return 0;
                if (std::abs (sc - 1.0f)  < 0.02f) return 1;
                if (std::abs (sc - 1.25f) < 0.02f) return 2;
                return -1;
            };
            z.onSegment = [safe] (int i)
            {
                const int ids[] = { 410, 412, 414 };
                // doi ti le o nhip sau: bang Cai dat cung phong to/thu nho theo
                juce::MessageManager::callAsync ([safe, id = ids[juce::jlimit (0, 2, i)]]
                {
                    if (safe != nullptr)
                        safe->menuItemSelected (id, menuView);
                });
            };
            v.push_back (z);
        }
        {
            // 14/10: Co chu Cai dat / Huong dan - ngay duoi Thu phong
            SettingsItem t;
            t.label = livent::vn ("Cỡ chữ Cài đặt / Hướng dẫn");
            t.kind = Kind::segment;
            t.segments = { "100%", "130%", "150%", "175%", "200%" };
            t.searchExtra = "co chu chu to chu nho phong to man hinh lon font text size";
            t.segmentIndex = []
            {
                const double s = livent::textscale::get();
                const double vals[] = { 1.0, 1.3, 1.5, 1.75, 2.0 };
                for (int i = 0; i < 5; ++i)
                    if (std::abs (s - vals[i]) < 0.02) return i;
                return -1;
            };
            t.onSegment = [safe] (int i)
            {
                const double vals[] = { 1.0, 1.3, 1.5, 1.75, 2.0 };
                // Cai dat se dong roi mo lai o nhip sau de ve lai bang co chu moi
                juce::MessageManager::callAsync ([safe, s = vals[juce::jlimit (0, 4, i)]]
                {
                    if (safe == nullptr) return;
                    safe->settingsStartPage = livent::vn ("Giao diện");   // mo lai dung trang nay
                    safe->applyTextScaleFromMenu (s);
                });
            };
            v.push_back (t);
        }

        v.push_back (settingsSection (livent::vn ("Bảng điều khiển")));
        v.push_back (toggle (livent::vn ("Hiện nút Bè  (F7)"),
                             livent::vn ("Nút Bè cạnh Lofi để điều khiển Harmony khi hát live"),
                             menuKeep (417, menuView),
                             [safe] { return safe != nullptr && safe->harmonyButtonVisible; }));
        v.push_back (toggle (livent::vn ("Thanh sóng trên nút  (F6)"),
                             livent::vn ("Mỗi nút Tune / Nhạc / Mic / Vang có thanh sóng màu riêng"),
                             menuKeep (423, menuView),
                             [safe] { return safe != nullptr && safe->tonePanel.isCompactMetersVisible(); }));
        v.push_back (toggle (livent::vn ("Luôn nổi trên cùng"),
                             livent::vn ("Giữ Bảng điều khiển trên các cửa sổ khác khi hát live"),
                             menuKeep (419, menuView),
                             [] { return loadMainAlwaysOnTopPreference(); }));

        v.push_back (settingsSection (livent::vn ("Cửa sổ")));
        {
            // F2 mo -> hoi mat khau + mo cua so lon: dong bang Cai dat cho khoi che.
            auto it = toggle (livent::vn ("Bàn làm việc  (F2)"),
                              livent::vn ("Dòng thời gian, rãnh, chèn / gửi hiệu ứng"),
                              [safe]
                              {
                                  if (safe == nullptr) return;
                                  if (safe->workWindow != nullptr)
                                  {
                                      safe->toggleWorkPanels();
                                      return;
                                  }
                                  juce::MessageManager::callAsync ([safe]
                                  {
                                      if (safe == nullptr) return;
                                      safe->settingsWindow.reset();
                                      safe->toggleWorkPanels();
                                  });
                              },
                              [safe] { return safe != nullptr && safe->workWindow != nullptr; });
            it.enabledFn = [safe] { return safe != nullptr && (safe->projectOpen || safe->workWindow != nullptr); };
            v.push_back (it);
        }
        {
            auto it = toggle (livent::vn ("Bàn trộn  (F3)"),
                              livent::vn ("Chỉ mở được khi Bàn làm việc F2 đang hiện"),
                              [safe] { if (safe != nullptr) safe->toggleMixerPanel(); },
                              [safe] { return safe != nullptr && safe->workWindow != nullptr && safe->mixerVisible; });
            it.enabledFn = [safe] { return safe != nullptr && safe->workWindow != nullptr; };
            v.push_back (it);
        }
        addSettingsPage (livent::vn ("Giao diện"), SettingsShell::Icon::look, v);
    }

    // 4. GAN NUT (01/10) -------------------------------------------------------
    if (projectOpen)
    {
        auto* page = new ButtonMapPage (mixer, tonePanel.getButtonMap(), [safe]
        {
            if (safe == nullptr) return;
            safe->tonePanel.buttonMapChanged();
            safe->markProjectDirty();
            safe->updateTitleText();
        });
        shell->addPage (livent::vn ("Gán nút"), SettingsShell::Icon::map, page,
                        page->getPreferredHeight (popupW - 175));
    }

    // Keyboard shortcuts are separate from VST/button mapping.
    {
        rebuildShortcutCommands();
        shell->addPage (livent::vn ("Phím tắt"), SettingsShell::Icon::map,
                        new livent::shortcuts::Page (keyboardShortcuts), 510);
    }

    // 5. YOUTUBE ----------------------------------------------------------------
    //  Chon MOT nguon: cua so YouTube cua DAW, HOAC trinh duyet rieng cua
    //  khach. Hai che do khong bao gio chay cung luc -> khong bat nham link.
    {
        std::vector<SettingsItem> v;
        auto dawOn = [] { return livent::youtube::useDawYouTube(); };

        v.push_back (settingsSection (livent::vn ("Lấy link bài hát từ (chọn 1)")));
        {
            auto it = row (livent::vn ("YouTube trong DAW"),
                           livent::vn ("Chỉ bắt link từ cửa sổ YouTube của DAW"),
                           [safe] { if (safe != nullptr) safe->setYouTubeSource (livent::youtube::Source::daw); });
            it.kind = Kind::radio;
            it.state = dawOn;
            it.toggleOn = dawOn();
            v.push_back (it);
        }
        {
            auto it = row (livent::vn ("Trình duyệt riêng (Chrome, Brave, Cốc Cốc...)"),
                           livent::vn ("Tắt YouTube của DAW cho nhẹ máy; bắt link từ trình duyệt ngoài"),
                           [safe] { if (safe != nullptr) safe->setYouTubeSource (livent::youtube::Source::browser); });
            it.kind = Kind::radio;
            it.state = [dawOn] { return ! dawOn(); };
            it.toggleOn = ! dawOn();
            v.push_back (it);
        }
        {
            // 12u: giong tool - mo LiveNT tu mo trinh duyet, tat LiveNT tu dong trinh duyet
            auto it = toggle (livent::vn ("Tự mở / tự tắt trình duyệt cùng LiveNT"),
                              livent::vn ("Mở LiveNT là mở YouTube trên trình duyệt đã chọn; tắt LiveNT là đóng theo (như bấm X, tab vẫn còn)"),
                              [] { livent::browsersession::setAutoEnabled (! livent::browsersession::autoEnabled()); },
                              [] { return livent::browsersession::autoEnabled(); });
            it.enabledFn = [dawOn] { return ! dawOn(); };
            it.searchExtra = "tu mo tu tat trinh duyet youtube chrome coc coc";
            v.push_back (it);
        }

        v.push_back (settingsSection (livent::vn ("Tiện ích Tune cho trình duyệt riêng")));
        {
            auto it = row (livent::vn ("Hướng dẫn cài Tiện ích Tune"),
                           livent::vn ("Có ảnh minh họa, địa chỉ cài và nút sao chép"),
                           [safe] { if (safe != nullptr) safe->openTuneExtensionGuide(); });
            it.searchExtra = "chrome extension browser huong dan tien ich tune";
            v.push_back (it);
        }
        v.push_back (mini (livent::vn ("Sao chép địa chỉ cài Tiện ích Tune"),
                           [] { juce::SystemClipboard::copyTextToClipboard (livent::tuneGuide::address()); }));

        v.push_back (settingsSection (livent::vn ("Cửa sổ YouTube")));
       #if LIVENT_YOUTUBE_MAGNET
        {
            auto it = toggle (livent::vn ("Hút dính YouTube vào DAW"),
                              livent::vn ("Kéo YouTube thì DAW đi cùng, kéo DAW thì YouTube theo"),
                              [safe]
                              {
                                  if (safe == nullptr) return;
                                  const bool on = ! livent::youtube::loadDockEnabled();
                                  livent::youtube::saveDockEnabled (on);
                                  if (safe->youtube.isRunning())
                                      livent::youtube::sendCommand (on ? "dock=1" : "dock=0");
                              },
                              [] { return livent::youtube::loadDockEnabled(); });
            it.enabledFn = dawOn;
            v.push_back (it);
        }
        {
            SettingsItem it;
            it.label = livent::vn ("Khi DAW Ngang, YouTube nằm");
            it.kind = Kind::segment;
            it.segments = { livent::vn ("Trên"), livent::vn ("Dưới") };
            it.segmentIndex = [] { return livent::youtube::loadDockSideHorizontal() == "bottom" ? 1 : 0; };
            it.onSegment = [safe] (int i) { if (safe != nullptr) safe->setYouTubeDockSide (i == 1 ? "bottom" : "top"); };
            it.enabledFn = dawOn;
            v.push_back (it);
        }
        {
            SettingsItem it;
            it.label = livent::vn ("Khi DAW Dọc, YouTube nằm");
            it.kind = Kind::segment;
            it.segments = { livent::vn ("Trái"), livent::vn ("Phải") };
            it.segmentIndex = [] { return livent::youtube::loadDockSideVertical() == "left" ? 0 : 1; };
            it.onSegment = [safe] (int i) { if (safe != nullptr) safe->setYouTubeDockSide (i == 0 ? "left" : "right"); };
            it.enabledFn = dawOn;
            v.push_back (it);
        }
       #endif
        {
            // 15/10: laptop man hinh nho -> thu nho chu trang YouTube. Auto = tu chinh theo man hinh.
            SettingsItem it;
            it.label = livent::vn ("Cỡ chữ trang YouTube");
            it.note = livent::vn ("Auto: laptop màn hình nhỏ tự thu nhỏ cho vừa. Có thể chọn cố định.");
            it.searchExtra = "co chu youtube thu nho phong to zoom laptop man hinh nho";
            it.kind = Kind::segment;
            it.segments = { "Auto", "70%", "80%", "90%", "100%", "110%" };
            it.segmentIndex = []
            {
                const int p = livent::youtube::loadZoomPercent();
                return p == 0 ? 0 : juce::jlimit (1, 5, (p - 70) / 10 + 1);
            };
            it.onSegment = [safe] (int i) { if (safe != nullptr) safe->setYouTubeZoomPercent (i <= 0 ? 0 : 70 + (i - 1) * 10); };
            it.enabledFn = dawOn;
            v.push_back (it);
        }
        {
            // 12r: khach than phien keo to nho cua so YouTube kho -> chon 1 lan
            SettingsItem it;
            it.label = livent::vn ("Cỡ cửa sổ YouTube");
            it.note = livent::vn ("Bấm chọn 1 lần, không cần kéo chuột. DAW nhớ cho lần sau. Tự kéo = như cũ.");
            it.searchExtra = "co cua so youtube phong to thu nho nua man hinh toan man hinh keo";
            it.kind = Kind::segment;
            it.segments = { livent::vn ("Tự kéo"), livent::vn ("Nhỏ góc"), livent::vn ("Nửa trái"),
                            livent::vn ("Nửa phải"), livent::vn ("Lớn"), livent::vn ("Toàn MH") };
            it.segmentIndex = [] { return juce::jmax (0, livent::youtube::sizePresetKeys().indexOf (livent::youtube::loadSizePreset())); };
            it.onSegment = [safe] (int i)
            {
                if (safe != nullptr && juce::isPositiveAndBelow (i, livent::youtube::sizePresetKeys().size()))
                    safe->setYouTubeSizePreset (livent::youtube::sizePresetKeys()[i]);
            };
            it.enabledFn = dawOn;
            v.push_back (it);
        }
        {
            auto it = toggle (livent::vn ("Ghim cửa sổ YouTube trên cùng"),
                              livent::vn ("Cửa sổ YouTube của DAW luôn nổi trên các cửa sổ khác"),
                              [safe]
                              {
                                  if (safe != nullptr)
                                      safe->youtube.setAlwaysOnTop (! YouTubeLauncher::isAlwaysOnTop());
                              },
                              [] { return YouTubeLauncher::isAlwaysOnTop(); });
            it.enabledFn = dawOn;
            v.push_back (it);
        }
       #if JUCE_MAC
        {
            auto it = row (livent::vn ("Trình duyệt lấy link"),
                           livent::vn ("Chỉ đọc link từ trình duyệt đã chọn"),
                           chooseBrowserForLink);
            it.labelFn = [safe]
            {
                return livent::vn ("Trình duyệt lấy link: ")
                     + (safe != nullptr ? safe->tonePanel.getPreferredBrowser() : juce::String());
            };
            it.enabledFn = [dawOn] { return ! dawOn(); };
            v.push_back (it);
        }
       #endif

        v.push_back (settingsSection (livent::vn ("Mở cùng LiveNT")));
        {
            auto it = row (livent::vn ("Ứng dụng mở cùng"),
                           livent::vn ("Thêm được nhiều app; mở sau khi LiveNT hiện xong, tắt LiveNT là tắt hết"),
                           [safe] { if (safe != nullptr) safe->showCompanionAppMenu(); });
            it.labelFn = [safe]
            {
                return livent::vn ("Ứng dụng mở cùng: ")
                     + (safe != nullptr ? safe->getCompanionAppDisplayName() : juce::String());
            };
            it.searchExtra = "companion app phan mem";
            v.push_back (it);
        }
       #if JUCE_WINDOWS
        v.push_back (mini (livent::vn ("Thư mục tiện ích YouTube (bản thử)"),
                           [] { livent::youtube::ensureExtensionsFolder().startAsProcess(); }));
       #endif
        addSettingsPage ("YouTube", SettingsShell::Icon::youtube, v);
    }

    // 6. BẢN QUYỀN & BẢO MẬT ------------------------------------------------------
    {
        const auto info = livent::license::current();
        juce::String statusText, subText;
        bool good = true;

        if (info.activated && info.perpetual)
        {
            statusText = livent::vn ("Vĩnh viễn");
            subText = livent::vn ("Bản quyền đã kích hoạt");
        }
        else if (info.activated)
        {
            const auto daysLeft = (int) (info.expiry - juce::Time::getCurrentTime()).inDays() + 1;
            statusText = livent::vn ("Còn ") + juce::String (juce::jmax (0, daysLeft)) + livent::vn (" ngày");
            subText = livent::vn ("Hết hạn ") + info.expiry.formatted ("%d/%m/%Y");
            good = daysLeft > 7;
        }
        else
        {
           #if LIVENT_ENABLE_LICENSE
            const auto daysLeft = livent::license::trialDaysLeft();
            statusText = daysLeft > 0
                       ? livent::vn ("Dùng thử - còn ") + juce::String (daysLeft) + livent::vn (" ngày")
                       : livent::vn ("Hết hạn dùng thử");
            subText = livent::vn ("Chưa kích hoạt bản quyền");
            good = false;
           #else
            statusText = livent::vn ("Chế độ phát triển");
           #endif
        }
        if (info.activated && info.owner.isNotEmpty())
            subText << livent::vn ("  ·  ") << info.owner;

        std::function<void()> activateFn;
       #if LIVENT_ENABLE_LICENSE
        activateFn = menu (603, menuContact);
       #endif
        std::function<void()> contactFn;
        juce::String contactText;
        if (livent::branding::hasContact())
        {
            contactFn = [safe] { if (safe != nullptr) safe->copyContactPhone(); };
            contactText = juce::String::fromUTF8 (livent::branding::contactPhone) + livent::vn ("  ·  Chép số");
        }

        auto* card = new LicenseCard (juce::String::fromUTF8 (livent::branding::appDisplayName),
                                      statusText, subText, good,
                                      activateFn, info.activated ? livent::vn ("Nhập mã khác")
                                                                 : livent::vn ("Nhập mã bản quyền"),
                                      contactFn, contactText);

        std::vector<SettingsItem> v;
        // 06/10: huong dan chuyen tu nut "?" vao day
        v.push_back (settingsSection (livent::vn ("Hướng dẫn")));
        {
            auto it = row (livent::vn ("Hướng dẫn chi tiết..."),
                           livent::vn ("Kích hoạt bản quyền, cách dùng bảng điều khiển, preset, VST, phím tắt, thu gọn"),
                           closing ([safe] { if (safe != nullptr) safe->openGuideWindow (0); }));
            it.searchExtra = "huong dan help guide kich hoat";
            v.push_back (it);
        }
        {
            auto it = row (livent::vn ("Chế độ chỉ dẫn rê chuột"),
                           livent::vn ("Rê chuột vào nút / núm nào hiện giải thích nút đó. Esc hoặc chuột phải để thoát"),
                           closing ([safe] { if (safe != nullptr) safe->setHelpMode (true); }));
            it.searchExtra = "huong dan help ? re chuot";
            v.push_back (it);
        }
        {
            auto it = row (livent::vn ("Tạm hạ phần mềm xuống 60 giây"),
                           livent::vn ("Để nhập key VST ở chương trình riêng (IK Product Manager, Waves Central, iLok...) không bị che"),
                           closing ([safe] { if (safe != nullptr) safe->lowerAllWindowsTemporarily (60); }));
            it.searchExtra = "kich hoat vst key bi che always on top";
            v.push_back (it);
        }
        // 14/10: chon may chu do tong (thay nut "Cap nhat VPS"). Khong hien dia chi / khoa.
        v.push_back (settingsSection (livent::vn ("Máy chủ dò tông ưu tiên (chọn 1)")));
        {
            using livent::vps::ToneServer;
            auto isHc = [] { return livent::vps::toneServer() == ToneServer::hc; };
            // 16/10: AI HC la mac dinh -> dung dau.
            {
                auto it = row (livent::vn ("AI HC  (mặc định)"),
                               livent::vn ("Kho tông lớn, trả kết quả gần như tức thì · lỗi thì tự chuyển AI NT"),
                               [] { livent::vps::setToneServer (ToneServer::hc); });
                it.kind = Kind::radio;
                it.state = isHc;
                it.toggleOn = isHc();
                it.searchExtra = "may chu do tong vps ai hc server";
                v.push_back (it);
            }
            {
                auto it = row ("AI NT",
                               livent::vn ("Máy chủ dò tông NT · lỗi thì tự chuyển AI HC"),
                               [] { livent::vps::setToneServer (ToneServer::nt); });
                it.kind = Kind::radio;
                it.state = [isHc] { return ! isHc(); };
                it.toggleOn = ! isHc();
                it.searchExtra = "may chu do tong vps ai nt server";
                v.push_back (it);
            }
        }
        v.push_back (settingsSection (livent::vn ("Bảo mật")));
        v.push_back (toggle (livent::vn ("Yêu cầu mật khẩu mở Bàn làm việc"),
                            livent::vn ("Khóa chung track/VST F2 và bàn trộn F3; tắt cần xác nhận mật khẩu hiện tại"),
                            closing ([safe] { if (safe != nullptr) safe->toggleWorkPanelPasswordRequirement(); }),
                            [safe] { return safe != nullptr && safe->workPanelPasswordRequired; }));
        {
            auto it = row (livent::vn ("Đổi mật khẩu mở khóa..."),
                           livent::vn ("Mật khẩu mở Bàn làm việc F2, Bàn trộn F3 và khu chỉnh VST"),
                           closing ([safe] { if (safe != nullptr) safe->changeWorkPanelPassword(); }));
            it.searchExtra = "password pass khoa";
            v.push_back (it);
        }

        addSettingsPage (livent::vn ("Bản quyền & Bảo mật"), SettingsShell::Icon::lock, v, card, 150);
    }

    const int popupH = juce::jlimit (juce::jmin (minPopupH, logicalMaxH), logicalMaxH, shell->getPreferredTotalHeight());

    shell->setSize (popupW, popupH);
    if (settingsStartPage.isNotEmpty())
        shell->selectPageNamed (settingsStartPage);
    settingsStartPage.clear();
    shell->selectFirstPageIfNeeded();

    auto closePopup = [safe]
    {
        if (safe == nullptr)
            return;

        safe->settingsWindow.reset();
    };

    shell->onCloseRequested = closePopup;

    auto popup = std::make_unique<SettingsPopupWindow> (shell, closePopup);
    popup->setResizeLimits (juce::jmin (480, maxW), juce::jmin (minPopupH, maxH), maxW, maxH);
    popup->setSize (juce::jmin (maxW, juce::roundToInt (popupW * textScale)),
                    juce::jmin (maxH, juce::roundToInt (popupH * textScale)));   // 14/10: cua so to len theo co chu
    livent::fitSettingsWindow (*popup, this);
    settingsWindow = std::move (popup);
    settingsWindow->setVisible (true);
    settingsWindow->toFront (true);
}

//=============================================================================
//  MOC 51: BANG SETUP AUDIO - quan ly track cong vao
//=============================================================================
void MainComponent::openInputSetup (juce::Component* anchor)
{
    /*  MOC 54: doi tu menu xo xuong sang BANG.

        Menu chi lam duoc MOT viec roi tu dong dong. Ma o day anh hay lam mot
        chuoi: them mot cong vao, chon cong cho no, roi lai them cai nua -
        voi menu thi moi buoc la mot lan mo lai va tim lai dong vua sua.

        Bang thi mo mot lan, lam het roi dong. Va cho thay CUNG LUC toan bo
        cac cong vao dang co gan vao cong card nao - thu ma menu khong bao gio
        cho thay duoc. Ly do day du trong InputSetupPanel.h.  */
    juce::ignoreUnused (anchor);
    openAudioSetupDialog (1);   // 14/10: cua so gop (Dau vao). Ham cu ben duoi giu lai, khong con duoc goi.
}

void MainComponent::openAudioSetupDialog (int startPage)
{
    if (mixer.isMasterRecording() || mixer.isTimelineRecording())
    {
        // Vao xem duoc nhung khong doi duoc: van mo, cac nut doi driver tu chan khi dang thu.
    }
    juce::Component::SafePointer<MainComponent> safe (this);

    auto* content = new AudioSetupDialog (mixer, deviceManager, startPage,
        [safe]
        {
            // Nut "Doi driver...": mo bang chon an toan (tien trinh phu); xong thi mo lai cua so nay.
            if (safe == nullptr) return;
            safe->reopenAudioSetupAfterSettings = true;
            safe->openAudioSettings();
            if (safe->audioSettingsProcess == nullptr)      // khong mo duoc / bi chan (dang thu, khoa soundcard...)
                safe->reopenAudioSetupAfterSettings = false;
        },
        [safe]
        {
            if (safe == nullptr) return;
            safe->saveDeviceSettings();
            safe->afterInputTracksChanged();
        });

    // 15/10: chon driver trong danh sach -> doi ngam (khong hien bang Cai dat soundcard).
    audioSetupDialogLive = content;   // 16/10: de bao vong quay / ket qua doi driver ngay tren bang
    content->onSave = [safe] { if (safe != nullptr) { safe->saveDeviceSettings(); safe->updateStatusText(); } };   // 12o: nut "Luu va dong"
    content->onPickDriver = [safe] (const juce::String& type, const juce::String& output, const juce::String& input)
    {
        if (safe != nullptr) safe->switchAudioDriver (type, output, input);
    };
    // 15/10: Tan so / Bo dem doi NGAY tren driver dang chay (giong Cubase), giu nguyen cac cong dang bat.
    content->canChangeInline = [safe] { return safe != nullptr && ! safe->soundcardLockEnabled; };
    content->applyRateBuffer = [safe] (double rate, int buffer) -> juce::String
    {
        if (safe == nullptr) return {};
        auto& dm = safe->deviceManager;
        juce::AudioDeviceManager::AudioDeviceSetup setup;
        dm.getAudioDeviceSetup (setup);
        auto* dev = dm.getCurrentAudioDevice();
        if (dev == nullptr) return livent::vn ("Chưa mở được soundcard.");
        setup.inputChannels  = dev->getActiveInputChannels();
        setup.outputChannels = dev->getActiveOutputChannels();
        setup.useDefaultInputChannels = setup.useDefaultOutputChannels = false;
        if (rate > 0.0)  setup.sampleRate = rate;
        if (buffer > 0)  setup.bufferSize = buffer;
        const auto err = dm.setAudioDeviceSetup (setup, true);
        if (err.isNotEmpty())
        {
            // Driver tu choi -> mo lai dung cau hinh da luu.
            auto saved = safe->loadDeviceSettings();
            safe->setAudioChannels (safe->requestedAudioInputs, safe->requestedAudioOutputs, saved.get());
            return err;
        }
        safe->saveDeviceSettings();
        safe->updateStatusText();
        safe->inspector.rebuildRouting();
        return {};
    };

    auto* dialog = new livent::GuidedSetupDialog (new livent::textscale::Host (content),
                                                  livent::vn ("Thiết lập âm thanh"));
    livent::centreDialog (dialog, this);
    dialog->setAlwaysOnTop (true);
    dialog->enterModalState (true, nullptr, true);
    dialog->toFront (true);
}

void MainComponent::openInputSetupLegacy (juce::Component* anchor)
{
    juce::ignoreUnused (anchor);
    auto* panel = new InputSetupPanel (mixer, deviceManager);

    juce::Component::SafePointer<MainComponent> safe (this);
    panel->onChanged = [safe]
    {
        // InputSetupPanel có thể tự bật thêm cổng vật lý khi người dùng gán
        // NHẠC VÀO/MÍC VÀO. Lưu audio.xml ngay để lần mở sau cổng vẫn còn.
        if (safe == nullptr) return;
        safe->saveDeviceSettings();
        safe->afterInputTracksChanged();
    };

    auto* dialog=new livent::GuidedSetupDialog(panel);
    livent::centreDialog(dialog,this);dialog->setAlwaysOnTop(true);
    dialog->enterModalState(true,nullptr,true);
    dialog->toFront(true);
}



void MainComponent::afterInputTracksChanged()
{
    markProjectDirty();
    updateTitleText();
    /*  Ba noi cung phai ve lai: ban tron (them/bot cot), bang Inspector (hop
        chon nguon co them/bot muc), va danh sach track.  */
    mixerView.rebuild();

    inspector.refreshFromTrack();
    rebuildTrackList();
    resized();
}

void MainComponent::toggleMixerPanel()
{
    if (workWindow == nullptr) return;
    mixerVisible = ! mixerVisible;
    lastAreaWasMixer = mixerVisible;
    if (mixerWindow != nullptr)
    {
        mixerWindow->setVisible (mixerVisible);
        if (mixerVisible) mixerWindow->toFront (true);
    }
    else
    {
        if (mixerView.getParentComponent() != &workArea) workArea.addChildComponent (mixerView);
        mixerView.setVisible (mixerVisible);
    }
    mixerSplitter.setVisible (mixerVisible && mixerWindow == nullptr);
    if (mixerVisible) mixerView.rebuild();
    layoutWorkArea();
    menuItemsChanged();
}

//=============================================================================
//  MOC 75: AN / HIEN CAC BANG PHU
//
//  Bang dieu khien la giao dien chinh, luon hien. Bon thu con lai (thanh
//  menu, danh sach track, bang Insert/Send, ban tron) deu an duoc.
//
//  Hai ham cu cua Moc 73 (updateTonePanelParent, toggleToneWindow) da bi bo
//  o cho nay tu Moc 74.
//=============================================================================
void MainComponent::applyPanelVisibility()
{
    // V5.8.1: thanh window native tro lai. Windows dung menu bar mong trong
    // client; title/subtitle cu van an de giu giao dien compact.
   #if JUCE_MAC
    menuBar.setVisible (false);
   #else
    menuBar.setVisible (true);
   #endif
    titleLabel.setVisible (false);
    subtitleLabel.setVisible (false);

    /*  Giau CA thanh keo di cung. Khong thi con lai mot vach doc 6 px khong
        dinh vao dau, keo no van doi inspectorWidth ngam ben duoi - mo bang
        len lai thi thay be ngang tu nhien khac di ma khong hieu vi sao.

        MOC 78: giau KHUNG CUON chu khong giau inspector - tu Moc 78 inspector
        la con cua khung cuon, khong con la con cua MainComponent.  */
    inspectorViewport.setVisible (inspectorVisible);
    inspectorSplitter.setVisible (inspectorVisible);

    trackListViewport.setVisible (trackListVisible);

    /*  MOC 95: ban tron chi duoc hien khi F2 dang mo. F2 dong thi ep an,
        bat ke mixerVisible cu trong file .NT la gi. */
    if (mixerWindow == nullptr)
    {
        const bool showMixerHere = (workWindow != nullptr) && mixerVisible;
        mixerView    .setVisible (showMixerHere);
        mixerSplitter.setVisible (showMixerHere);
    }
    else
    {
        mixerWindow->setVisible (workWindow != nullptr && mixerVisible);
        mixerSplitter.setVisible (false);
    }

    //  MOC 93: ba bang co the dang o cua so ban lam viec - resized() cua
    //  MainComponent khong voi toi chung nua.
    relayoutAll();

    // Đặc biệt cần trên macOS để mục F2/F3 trên menu hệ thống đổi từ xám
    // sang bật được (và cập nhật dấu tick) ngay khi trạng thái cửa sổ đổi.
    menuItemsChanged();
    repaint();
}

void MainComponent::applyStartupLayoutMode (int mode)
{
    if (mode == 1)
    {
        //  Chi bang dieu khien
        trackListVisible = false;
        inspectorVisible = false;
        mixerVisible     = false;
    }
    else if (mode == 2)
    {
        //  Hien cac bang F2; rieng F3 van cho bam sau khi F2 da mo.
        trackListVisible = true;
        inspectorVisible = true;
        mixerVisible     = false;
    }

    //  mode 0 = nho theo du an -> giu cac co F2/Inspector theo file.
    //  MOC 95: rieng F3 khong duoc tu bung tren Bang dieu khien luc startup.
    if (workWindow == nullptr)
        mixerVisible = false;

    applyPanelVisibility();
}

void MainComponent::setInspectorVisible (bool shouldShow)
{
    inspectorVisible = shouldShow;
    applyPanelVisibility();
}

void MainComponent::toggleInspector()
{
    toggleWorkPanels();   // MOC 77: gop chung voi TrackList - xem chu thich o ham do
}

void MainComponent::toggleTrackList()
{
    toggleWorkPanels();   // MOC 77: gop chung voi Inspector - xem chu thich o ham do
}

/*  ==========  MOC 93: F2 - MO BAN LAM VIEC, CO MAT KHAU  ==========

    Moc 77 tung gop F2 va F4 lam mot; Moc 93 bo shortcut F4 CU.
    V6.6.4 tai su dung F4 cho Cai dat soundcard, KHONG lien quan F2.
    Moc 93 them hai thay doi:

      1. Ba bang (danh sach track, Insert/Send, ban tron) khong con nam chung
         cua so voi bang dieu khien nua - chung sang mot CUA SO RIENG. Anh keo
         cua so do to het man hinh de gan VST, bang dieu khien khong nhuc nhich.

      2. Mo phai go mat khau. Muc dich: may giao cho khach thi khach khong vo
         y mo ra roi doi nham chuoi VST.

    HOP THOAI CHAY BAT DONG BO. Nghia la livent::askPassword tra ve NGAY, con
    ket qua thi ve sau qua lambda - luc do ham nay da ket thuc tu lau. Nen moi
    viec that su nam trong applyWorkPanels(), va lambda bat SafePointer chu
    KHONG bat [this] tran (bai hoc Moc 22: nguoi dung co the dong app trong
    luc hop thoai con mo).  */
void MainComponent::toggleWorkPanels()
{
    if (! projectOpen && workWindow == nullptr)
    {
        livent::alert (livent::vn ("Chưa có dự án"),
                       livent::vn ("Bàn làm việc chỉ mở khi đang có một dự án."));
        return;
    }

    //  Dang mo -> dong. Dong thi khong hoi mat khau: khoa la de chan mo ra,
    //  chan dong lai chi lam kho chinh nguoi da go dung mat khau.
    if (workWindow != nullptr)
    {
        applyWorkPanels (false);
        return;
    }

    if (! workPanelPasswordRequired) { applyWorkPanels (true); return; }
    if (workPanelPasswordPromptRunning) return;
    workPanelPasswordPromptRunning = true;

    juce::Component::SafePointer<MainComponent> safe (this);

    livent::askPassword (livent::vn ("BÀN LÀM VIỆC"),
                         livent::vn ("Nhập mật khẩu để mở bảng track / Insert / Send:"),
                         workPanelPassword,
                         [safe] (bool ok)
                         {
                             if (safe == nullptr)
                                 return;
                             safe->workPanelPasswordPromptRunning = false;

                             if (ok)
                             {
                                 if (safe->projectOpen && safe->workWindow == nullptr) safe->applyWorkPanels (true);
                             }
                             else
                                 livent::alert (livent::vn ("BÀN LÀM VIỆC"),
                                                livent::vn ("Mật khẩu không đúng."),
                                                juce::MessageBoxIconType::WarningIcon);
                         }, [safe] { if (safe != nullptr) safe->workPanelPasswordPromptRunning = false; });
}

/*  06/10: thao tac cua chu may (khoa soundcard, luu thong so mac dinh) phai
    go dung mat khau Ban lam viec F2 - doi mat khau F2 thi cai nay doi theo.
    Luon hoi, ke ca khi F2 dang tat yeu cau mat khau.  */
void MainComponent::withAdminPassword (const juce::String& title, std::function<void()> action)
{
    if (workPanelPasswordPromptRunning || action == nullptr) return;
    workPanelPasswordPromptRunning = true;
    juce::Component::SafePointer<MainComponent> safe (this);
    livent::askPassword (title,
                         livent::vn ("Nhập mật khẩu Bàn làm việc (F2) để tiếp tục:"),
                         workPanelPassword,
                         [safe, title, action] (bool ok)
                         {
                             if (safe == nullptr) return;
                             safe->workPanelPasswordPromptRunning = false;
                             if (ok) action();
                             else livent::alert (title, livent::vn ("Mật khẩu không đúng."),
                                                 juce::MessageBoxIconType::WarningIcon);
                         }, [safe] { if (safe != nullptr) safe->workPanelPasswordPromptRunning = false; });
}

void MainComponent::toggleWorkPanelPasswordRequirement()
{
    if (workPanelPasswordPromptRunning) return;
    juce::Component::SafePointer<MainComponent> safe (this);
    auto saveState = [safe] (bool required)
    {
        if (safe == nullptr) return;
        if (saveWorkPanelPasswordRequired (required)) safe->workPanelPasswordRequired = required;
        else livent::alert (livent::vn ("Chưa lưu được"), livent::vn ("Không lưu được cài đặt khóa Bàn làm việc."));
    };
    if (! workPanelPasswordRequired) { saveState (true); return; }
    workPanelPasswordPromptRunning = true;
    livent::askPassword (livent::vn ("Tắt khóa Bàn làm việc"),
                        livent::vn ("Nhập mật khẩu hiện tại để cho phép mở F2/F3 không cần mật khẩu:"),
                        workPanelPassword, [safe, saveState] (bool ok)
                        {
                            if (safe == nullptr) return;
                            safe->workPanelPasswordPromptRunning = false;
                            if (ok) saveState (false);
                            else livent::alert (livent::vn ("Bàn làm việc"), livent::vn ("Mật khẩu không đúng."));
                        }, [safe] { if (safe != nullptr) safe->workPanelPasswordPromptRunning = false; });
}

void MainComponent::applyWorkPanels (bool shouldShow)
{
    inspectorVisible = shouldShow;
    trackListVisible = shouldShow;

    /* MOC 95: F3 khong nho trang thai qua mot lan dong/mo F2. Mo F2 len
       truoc het chi co track + Insert/Send; bam F3 moi bat ban tron. */
    mixerVisible = false;

    if (shouldShow)
    {
        /*  Dung lai danh sach TRUOC khi mo cua so: preferredSize cua cua so
            khong doc toi danh sach, nhung cac dong track phai co san thi lan
            xep dau tien moi ra dung chieu cao.  */
        rebuildTrackList();
        openWorkWindow();
    }
    else
    {
        closeWorkWindow();
    }

    applyPanelVisibility();
    updateWindowSizeForPanels();
}

/*  ==========  MOC 93: DOI CHA CAC BANG SANG CUA SO RIENG  ==========

    KHONG dung ban sao thu hai cua cac component - chinh trackListViewport /
    inspectorViewport / mixerView duoc doi cha. juce::Component::
    addAndMakeVisible tu go component khoi cha cu truoc khi gan cha moi, nen
    khong co luc nao mot component co hai cha.

    Cua so dung ToneWindow (dinh nghia trong TonePanel.h) - cung kieu voi cua
    so ban tron va cua so tieng cuoi, de ba cai nhin giong nhau.  */
void MainComponent::openWorkWindow()
{
    if (workWindow != nullptr)
    {
        workWindow->setVisible (true);
        workWindow->toFront (true);
        return;
    }

    workArea.onResized = [this] { layoutWorkArea(); };

    /*  MOC 94: bat phim tat cho CA cua so ban lam viec.

        Truoc day F2 / F3 chi chay khi cua so CHINH dang duoc chon. Dang chinh
        VST trong cua so ban lam viec ma bam F3 thi phim do roi vao cua so
        nay - khong ai nghe - nen nhin ra nhu "F3 khong an".

        MainComponent da la mot juce::KeyListener san (xem addKeyListener
        (this) trong ham dung), nen chi can cho workArea nhan phim roi bao
        cung mot nguoi nghe. Ket qua: bam o cua so nao cung ra dung mot hanh vi.  */
    workArea.setWantsKeyboardFocus (true);
    workArea.addKeyListener (this);

    workArea.addAndMakeVisible (inspectorViewport);
    workArea.addAndMakeVisible (inspectorSplitter);
    workArea.addAndMakeVisible (trackWidthSplitter);
    workArea.addAndMakeVisible (trackListViewport);
    workArea.addAndMakeVisible (timelineTransport);
    workArea.addAndMakeVisible (timelineRuler);
    workArea.addAndMakeVisible (timelineFooter);
    workArea.addAndMakeVisible (timelineTransportIcons);
    workArea.addChildComponent (masterMeterPanel);

    /*  Ban tron chi doi cha khi no dang DOCKED. Dang tach ra cua so rieng
        (mixerWindow) thi de nguyen o do - keo no ve day la giat mat noi dung
        cua cua so kia, con lai mot cua so trong.  */
    if (mixerWindow == nullptr)
    {
        workArea.addAndMakeVisible (mixerView);
        workArea.addAndMakeVisible (mixerSplitter);
        mixerView    .setVisible (mixerVisible);
        mixerSplitter.setVisible (mixerVisible);
    }

    /*  ==========  MOC 94: NUT X PHAI LAM Y HET F2  ==========

        LOI MOC 93: cho nay goi thang closeWorkWindow(). Ham do chi thao cua
        so va keo ba bang ve lam con cua MainComponent - no KHONG dong toi hai
        co inspectorVisible / trackListVisible.

        Hai co do van bang true, nen lan xep bo cuc ke tiep cua so chinh thay
        "hai bang dang hien" va bay chung ra ngay tren bang dieu khien - dung
        trieu chung anh gap.

        Chua bang cach goi applyWorkPanels(false): mot duong duy nhat, bam X
        hay bam F2 deu di qua do. Day la nguyen tac tu Moc 68 - MOT cong tac
        chi duoc co MOT nguoi bam.  */
    auto* w = new ToneWindow ([this] { applyWorkPanels (false); });
    w->setName (livent::vn ("LiveNT - Bàn làm việc"));
    workWindow.reset (w);
    w->getProperties().set ("liventIndependentWindow", true);
    livent::markDialogHost (*w);

    /*  Kich thuoc mo dau khi CHUA TUNG luu - rong bang cua so chinh, cao mot
        nua man hinh. Lan sau se dung con so da luu (xem duoi).  */
    int startW = juce::jmax (900, getWidth());
    int startH = 560;

    if (auto* display = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay())
    {
        const auto area = display->userArea;

        startW = juce::jmin (startW, area.getWidth()  - 40);
        startH = juce::jmin (startH, area.getHeight() - 80);
    }

    workArea.setSize (startW, startH);
    w->setContentNonOwned (&workArea, true);

    /*  ==========  MOC 94: NHO VI TRI VA KICH THUOC  ==========

        Anh keo cua so nay to ra, xep sang man hinh thu hai, chinh be ngang
        cot Insert/Send cho vua tay - lan sau mo len phai y nguyen nhu the.

        Luu o %APPDATA%\\LiveNT\\banlamviec.txt chu KHONG luu trong file .NT.
        Ly do giong het che do khoi dong (Moc 74): day la thoi quen dung may
        cua anh, khong phai noi dung ban nhac. Gui file .NT cho khach thi
        khong nen keo theo cach xep cua so tren may anh.

        restoreWindowStateFromString hieu luon ca chi so man hinh, nen keo
        sang man hinh thu hai la lan sau no tu ve dung man hinh do.  */
    const auto saved = workWindowStateFile().loadFileAsString().trim();
    bool       placed = false;

    if (saved.isNotEmpty())
        placed = w->restoreWindowStateFromString (saved);

    bool visibleOnSomeDisplay = false;

    if (placed)
    {
        const auto bounds = w->getBounds();

        if (auto* display = juce::Desktop::getInstance()
                                .getDisplays()
                                .getDisplayForRect (bounds))
        {
            const auto visible = display->userArea.getIntersection (bounds);
            visibleOnSomeDisplay = visible.getWidth() >= 120
                                && visible.getHeight() >= 80;
        }
    }

    w->setMinimised (false);

    if (! placed || ! visibleOnSomeDisplay)
    {
        if (auto* display = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay())
        {
            const auto area = display->userArea;

            w->setBounds (area.getCentreX() - w->getWidth() / 2,
                          area.getBottom()  - w->getHeight() - 30,
                          w->getWidth(), w->getHeight());
        }
    }

    w->setVisible (true);
    w->toFront (true);

    layoutWorkArea();
}

/*  MOC 94: noi luu cach xep cua so ban lam viec. Mot ham thay vi mot chuoi
    viet lai o hai cho - luu va doc phai luon tro cung mot file.  */
juce::File MainComponent::workWindowStateFile() const
{
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
              .getChildFile ("LiveNT")
              .getChildFile ("banlamviec.txt");
}

void MainComponent::closeWorkWindow()
{
    if (workWindow == nullptr)
        return;

    // Closing the password-protected work area also closes detached F3.
    dockMixerWindow (false);
    mixerVisible = false;

    /*  MOC 94: ghi lai cach xep cua so TRUOC khi xoa no - sau reset() thi
        khong con ai de hoi vi tri nua. getWindowStateAsString goi duoc ca luc
        cua so dang an, mien la no chua bi huy.  */
    if (! workWindow->isMinimised())
    {
        const auto bounds = workWindow->getBounds();

        if (auto* display = juce::Desktop::getInstance()
                                .getDisplays()
                                .getDisplayForRect (bounds))
        {
            const auto visible = display->userArea.getIntersection (bounds);

            if (visible.getWidth() >= 120 && visible.getHeight() >= 80)
            {
                const auto state = workWindow->getWindowStateAsString();
                auto       f     = workWindowStateFile();

                f.getParentDirectory().createDirectory();
                f.replaceWithText (state);
            }
        }
    }

    /*  Go noi dung ra TRUOC khi xoa cua so: workArea la thanh vien cua lop
        nay, khong phai cua cua so (setContentNonOwned). De cua so tu don la
        no xoa nham bo nho cua lop khac -> sap luc tat app.  */
    workWindow->clearContentComponent();
    workWindow.reset();

    /*  MOC 96: KHONG keo cac bang ve MainComponent nua. Chung song co dinh
        trong workArea ca khi cua so F2 dang dong. Nho vay khong con khoanh
        khac nao track/Inspector/F3 "dinh" vao Bang dieu khien. */
    if (inspectorViewport.getParentComponent() != &workArea)
        workArea.addChildComponent (inspectorViewport);
    if (inspectorSplitter.getParentComponent() != &workArea)
        workArea.addChildComponent (inspectorSplitter);
    workArea.addChildComponent (trackWidthSplitter);
    if (trackListViewport.getParentComponent() != &workArea)
        workArea.addChildComponent (trackListViewport);
    if (mixerView.getParentComponent() != &workArea)
        workArea.addChildComponent (mixerView);
    if (mixerSplitter.getParentComponent() != &workArea)
        workArea.addChildComponent (mixerSplitter);
    if (timelineTransport.getParentComponent() != &workArea)
        workArea.addChildComponent (timelineTransport);
    if (timelineRuler.getParentComponent() != &workArea)
        workArea.addChildComponent (timelineRuler);
    if (timelineFooter.getParentComponent() != &workArea)
        workArea.addChildComponent (timelineFooter);
    if (timelineTransportIcons.getParentComponent() != &workArea)
        workArea.addChildComponent (timelineTransportIcons);
    if (masterMeterPanel.getParentComponent() != &workArea)
        workArea.addChildComponent (masterMeterPanel);

    inspectorViewport.setVisible (false);
    inspectorSplitter.setVisible (false);
    trackWidthSplitter.setVisible (false);
    trackListViewport.setVisible (false);
    mixerView.setVisible (false);
    mixerSplitter.setVisible (false);
    timelineTransport.setVisible (false);
    timelineRuler.setVisible (false);
    timelineFooter.setVisible (false);
    timelineTransportIcons.setVisible (false);
    masterMeterPanel.setVisible (false);
}

/*  Xep bo cuc BEN TRONG cua so ban lam viec. Cung thu tu voi bo cuc cu hoi
    con dock chung: ban tron sat le duoi, roi Insert/Send ben trai, danh sach
    track chiem phan con lai.  */
void MainComponent::layoutWorkArea()
{
    if (workWindow == nullptr)
        return;

    auto area = workArea.getLocalBounds().reduced (3);

    if (area.getWidth() < 40 || area.getHeight() < 40)
        return;

    // 07/10 _F (demo A): thanh CONG CU nam TREN DAU vung song. Van nam ngoai
    // viewport track nen cuon danh sach bao xa cung van bam THU/DUNG/PHAT duoc.
    timelineTransport.setVisible (true);
    timelineTransport.setBounds (area.removeFromTop (timelineTransport.getPreferredHeight (area.getWidth())));
    area.removeFromTop (3);

    const bool docked = mixerVisible && mixerWindow == nullptr;
    const auto panels = livent::workspacePanel::measure (area.getHeight(), docked, mixerHeight);
    timelineTransport.setPanelVisibility (inspectorVisible, mixerVisible, masterMeterVisible);
    if (docked)
    {
        mixerView.setBounds (area.removeFromBottom (panels.mixerHeight));
        mixerSplitter.setBounds (area.removeFromBottom (panels.splitterHeight));
        mixerSplitter.toFront (false);
    }
    timelineTransportIcons.setVisible (panels.iconsHeight > 0);
    timelineTransportIcons.setBounds (area.removeFromBottom (panels.iconsHeight));

    // The Master meter belongs to the timeline area, above docked F3. Hiding
    // it returns the entire right-hand width to the ruler, tracks and footer.
    const bool showMaster = masterMeterVisible && area.getWidth() >= 560 && area.getHeight() >= 100;
    masterMeterPanel.setVisible (showMaster);
    if (showMaster)
    {
        masterMeterPanel.setBounds (area.removeFromRight (184));
        area.removeFromRight (4);
    }

    if (inspectorVisible)
    {
        layoutInspector (area.removeFromLeft (
            juce::jlimit (180, juce::jmax (180, area.getWidth() - 260), inspectorWidth)));

        inspectorSplitter.setBounds (area.removeFromLeft (6));
    }

    // 07/10 _F: thuoc thoi gian ngay tren danh sach track, thanh goi y ngay duoi
    timelineRuler.setVisible (true);
    timelineFooter.setVisible (true);
    timelineRuler.setBounds (area.removeFromTop (22));
    timelineFooter.setBounds (area.removeFromBottom (36));
    area.removeFromBottom (3);

    trackListViewport.setBounds (area);

    const int rowWidth = juce::jmax (260, trackListViewport.getWidth() - 12);
    const int timelineX = TrackRow::getTimelineStartX (rowWidth);
    trackWidthSplitter.setVisible (trackListVisible);
    trackWidthSplitter.setBounds (trackListViewport.getX() + timelineX - 3, timelineRuler.getY(), 6,
                                  juce::jmax (0, trackListViewport.getBottom() - timelineRuler.getY()));
    trackWidthSplitter.toFront (false);
    timelineRuler.setTimelineStartX (timelineX);
    timelineFooter.setTimelineStartX (timelineX);

    layoutTrackRows (rowWidth);
}

/*  MOC 93: goi lai bo cuc dung cho. Dang mo ban lam viec thi ba bang khong
    con la con cua MainComponent - goi resized() cua MainComponent khong dong
    toi chung duoc nua.  */
void MainComponent::relayoutAll()
{
    resized();

    if (workWindow != nullptr)
        layoutWorkArea();
}

/*  MOC 77: TU THU NHO / KHOI PHUC KICH THUOC CUA SO.

    Truoc day: an Inspector + TrackList di la CHI AN NOI DUNG, khung cua so
    (kich thuoc thuc su nguoi dung nhin thay) VAN GIU NGUYEN to nhu cu - de
    lai mot mang den trong rong be the, dung y anh mo ta ("khoang trong nhu
    hien tai"). Ly do: setContentOwned(..., true) trong Main.cpp CHI tu
    resize cua so THEO MainComponent::setSize() - khong tu suy ra duoc
    "noi dung con lai it thi cua so nen nho lai".

    Sua: goi ham nay MOI LAN 2 bang do doi trang thai an/hien (tu
    toggleWorkPanels(), va ca luc nap lai project/doi che do khoi dong) -
    tu tinh xem CHI CON Bang Dieu Khien hay khong, roi CHU DONG goi setSize()
    de co giao dien that su thu nho theo, khong con khoang trong vo ich.  */
/*  ==========  MOC 78: BANG INSERT/SEND CUON DUOC  ==========

    Cho ca bang vao khung cuon va cho no chieu cao dung bang noi dung can.

    Hai buoc, co y: phai cho no dung BE NGANG cua khung nhin roi chay
    resized() mot lan, thi contentHeight moi dung - ten plugin dai co the
    xuong dong, va bang hep 200 px voi bang rong 400 px khong cao bang nhau.
    Doan mot con so cao san la sai ngay lan dau anh keo thanh chia.  */
void MainComponent::layoutInspector (juce::Rectangle<int> area)
{
    if (fittingInspector)
        return;   // dang o giua mot lan chinh roi - xem fittingInspector

    const juce::ScopedValueSetter<bool> guard (fittingInspector, true);

    inspectorViewport.setBounds (area);

    //  Be ngang phan nhin thay duoc, da tru cho thanh keo neu no dang hien
    const int w = juce::jmax (120, inspectorViewport.getMaximumVisibleWidth());

    //  Buoc 1: dat be ngang dung, ep chay lai bo cuc de biet noi dung cao
    //  bao nhieu. Goi resized() bang tay vi setSize voi cung mot con so thi
    //  JUCE bo qua, khong chay lai gi ca.
    inspector.setSize (w, juce::jmax (area.getHeight(), inspector.getHeight()));
    inspector.resized();

    //  Buoc 2: gio moi biet chac chieu cao that
    inspector.setSize (w, juce::jmax (area.getHeight(), inspector.getContentHeight()));
}

void MainComponent::refitInspector()
{
    if (inspectorViewport.getWidth() > 0)
        layoutInspector (inspectorViewport.getBounds());
}

/*  ==========  MOC 78: NHO DELTA, KHONG NHO CHIEU CAO TUYET DOI  ==========

    Anh bao: "khi anh thu nho cai bang dieu khien roi anh bam hien track thi
    giao dien bang dieu khien no lai to lai - anh muon keo nho nhu nao thi
    khi an giao dien lai no khong bi thay doi".

    Ban Moc 77 nho lai CHIEU CAO CU cua cua so ngay truoc luc tu thu nho, roi
    lay nguyen con so do dat lai. Hong o cho: dang o trang thai da thu nho,
    anh keo mep cua so cho no nho them nua - con so da nho tu truoc do khong
    biet gi ve viec keo do. Bam hien track la cua so nhay ve cai chieu cao cu
    tu doi nao, cao lu len.

    Gio nho BOT BAO NHIEU PX (shrinkDelta) chu khong nho cao bao nhieu. Hien
    lai thi cong dung tung ay px vao chieu cao HIEN TAI - moi thao tac keo
    tay cua anh o giua deu duoc giu nguyen.  */
void MainComponent::updateWindowSizeForPanels()
{
    /* v4.3.1: F2/F3 chi thay doi cua so Ban lam viec. Bang dieu khien chinh
       giu NGUYEN kich thuoc nguoi dung da keo. Chi newProject()/loadProject()
       moi goi compactControlPanelWindow() mot lan de vao kich thuoc gon. */
    if (! projectOpen)
        return;

    resized();
}


/*  MOC 56: TACH BAN TRON RA CUA SO RIENG - mirror y het toggleToneWindow()
    o tren, chi khac la doi tuong dua sang cua so rieng la mixerView (docked
    sat duoi man hinh chinh) thay vi tonePanel.  */
juce::Rectangle<int> MainComponent::mixerDockArea() const
{
    auto area = workArea.getLocalBounds().reduced (3);
    area.removeFromTop (timelineTransport.getPreferredHeight (area.getWidth()) + 3);
    area.removeFromBottom (juce::jmin (area.getHeight(), livent::workspacePanel::transportHeight));
    return area;
}

void MainComponent::loadMixerLayout()
{
    auto file = PluginChain::getSettingsFolder().getChildFile ("mixer-f3.xml");
    if (auto xml = juce::XmlDocument::parse (file))
    {
        const int version = xml->getIntAttribute ("layoutVersion", 1);
        mixerHeight = juce::jlimit (180, 2000, xml->getIntAttribute ("height", livent::mixerPanel::defaultHeight));
        mixerFloatingWindowState = xml->getStringAttribute ("floatingWindow");
        masterMeterVisible = xml->getBoolAttribute ("masterMeterVisible", true);
        mixer.setMonitorDb ((float) xml->getDoubleAttribute ("monitorDb", 0.0));
        // Replace only the previous stock height; retain manually chosen window sizes.
        if (version < 3 && mixerHeight == 620) mixerHeight = livent::mixerPanel::defaultHeight;
        if (version < 5 && mixerHeight == 440) mixerHeight = livent::mixerPanel::defaultHeight;
        livent::mixerPanel::Options layout;
        layout.stripWidth = xml->getIntAttribute ("stripWidth", 96);
        layout.faderHeight = xml->getIntAttribute ("faderHeight", 128);
        layout.routingOpen = xml->getBoolAttribute ("routingOpen", false);
        layout.insertsOpen = xml->getBoolAttribute ("insertsOpen", true);
        layout.sendsOpen = xml->getBoolAttribute ("sendsOpen", false);
        mixerView.setLayout (layout);
    }
}

void MainComponent::saveMixerLayout()
{
    if (mixerWindow != nullptr && ! mixerWindow->isMinimised())
        mixerFloatingWindowState = mixerWindow->getWindowStateAsString();
    juce::XmlElement xml ("MixerF3");
    const auto& layout = mixerView.getLayout();
    xml.setAttribute ("layoutVersion", 5);
    xml.setAttribute ("masterMeterVisible", masterMeterVisible);
    xml.setAttribute ("monitorDb", (double) mixer.getMonitorDb());
    xml.setAttribute ("height", mixerHeight);
    xml.setAttribute ("floatingWindow", mixerFloatingWindowState);
    xml.setAttribute ("stripWidth", layout.stripWidth);
    xml.setAttribute ("faderHeight", layout.faderHeight);
    xml.setAttribute ("routingOpen", layout.routingOpen);
    xml.setAttribute ("insertsOpen", layout.insertsOpen);
    xml.setAttribute ("sendsOpen", layout.sendsOpen);
    SafeFile::writeXml (xml, PluginChain::getSettingsFolder().getChildFile ("mixer-f3.xml"), false);
}

void MainComponent::syncMixerPanelVisibility()
{
    // Async picker/editor completion must honour the current F3 state. Never
    // toggle it, recreate its host, or reopen a panel the user has since hidden.
    const bool show = workWindow != nullptr && mixerVisible;
    if (mixerWindow != nullptr)
    {
        // The floating host controls visibility; keep its content ready for
        // the next F3 press, including after a load finishes while it is hidden.
        mixerView.setVisible (true);
        mixerWindow->setVisible (show);
    }
    else mixerView.setVisible (show);
    mixerSplitter.setVisible (show && mixerWindow == nullptr);
    layoutWorkArea();
}

void MainComponent::refreshMixerAfterPluginEdit (Track* changedTrack, int revealedSlot)
{
    mixerView.rebuild();
    if (changedTrack != nullptr && inspector.getTrack() == changedTrack)
    {
        mixerView.setSelectedTrack (changedTrack);
        if (workWindow != nullptr && mixerVisible && juce::isPositiveAndBelow (revealedSlot, PluginChain::maxSlots))
            mixerView.revealSlot (*changedTrack, revealedSlot);
    }
    syncMixerPanelVisibility();
}

void MainComponent::dockMixerWindow (bool showPanel)
{
    saveMixerLayout();
    if (mixerWindow != nullptr)
    {
        mixerWindow->clearContentComponent();
        mixerWindow.reset();
    }
    workArea.addChildComponent (mixerView);
    mixerView.setDetached (false);
    mixerVisible = showPanel && workWindow != nullptr;
    lastAreaWasMixer = mixerVisible;
    mixerView.setVisible (mixerVisible);
    mixerSplitter.setVisible (mixerVisible);
    layoutWorkArea();
    menuItemsChanged();
}

void MainComponent::toggleMixerWindow()
{
    if (workWindow == nullptr) return;
    if (mixerWindow != nullptr) { dockMixerWindow (true); return; }
    juce::Component::SafePointer<MainComponent> safe (this);
    auto* window = new ToneWindow ([safe]
    {
        // Never destroy a window in its own close-button callback.
        juce::MessageManager::callAsync ([safe]
        { if (safe != nullptr) safe->dockMixerWindow (false); });
    });
    mixerWindow.reset (window);
    window->setName (livent::vn ("LiveNT - Mixer F3"));
    window->setLookAndFeel (&getLookAndFeel());
    window->getProperties().set ("liventIndependentWindow", true);
    livent::markDialogHost (*window);
    window->setResizeLimits (560, 320, 10000, 10000);
    mixerView.setDetached (true);
    int width = juce::jmax (900, workArea.getWidth());
    int height = juce::jmax (livent::mixerPanel::defaultHeight, mixerHeight);
    if (auto* display = juce::Desktop::getInstance().getDisplays().getDisplayForRect (workWindow->getBounds()))
    {
        width = juce::jmin (width, juce::jmax (560, display->userArea.getWidth() - 40));
        height = juce::jmin (height, juce::jmax (320, display->userArea.getHeight() - 80));
    }
    mixerView.setSize (width, height);
    window->setContentNonOwned (&mixerView, true);
    if (mixerFloatingWindowState.isEmpty() || ! window->restoreWindowStateFromString (mixerFloatingWindowState))
        window->centreAroundComponent (workWindow.get(), window->getWidth(), window->getHeight());
    mixerVisible = true;
    lastAreaWasMixer = true;
    mixerSplitter.setVisible (false);
    mixerView.setVisible (true);
    window->setVisible (true);
    window->toFront (true);
    layoutWorkArea();
    menuItemsChanged();
}

//=============================================================================
//  MOC 72: THU AM DON GIAN
//=============================================================================
void MainComponent::startMasterRecording()
{
    if (masterRecordingUiActive && ! mixer.isMasterRecording())
    {
        stopMasterRecording(); // Save a device-stopped take before starting anew.
        return;
    }
    if (timelineExportActive || timelineExportFinishing) return;
    /*  Ten file mac dinh co san ngay, khong bat anh phai nghi ra ten -
        dang chuan bi len hat thi cang it viec vat vanh cang tot.  */
    const auto suggestedName = "HatLive_" + juce::Time::getCurrentTime().formatted ("%Y%m%d_%H%M%S") + ".wav";

    const auto folder = juce::File::getSpecialLocation (juce::File::userMusicDirectory)
                           .getChildFile ("LiveNT");
    folder.createDirectory();

    auto workingFile = livent::uniqueMasterRecordingFile (folder, suggestedName);
    bool started = mixer.startMasterRecording (workingFile);

    /*  V5.8.5 macOS-safe: mot so ban app/notarize/sandbox co the khong duoc
        phep ghi thang vao ~/Music truoc khi nguoi dung chon vi tri. Audio
        thread khong nen phu thuoc permission nay. Neu Music bi tu choi, ghi
        tam vao thu muc temp cua he thong; luc DUNG moi xuat qua native Save
        panel. Windows cung duoc huong fallback nay, khong ton CPU realtime. */
    if (! started)
    {
        const auto fallbackFolder = juce::File::getSpecialLocation (juce::File::tempDirectory)
                                      .getChildFile ("LiveNT").getChildFile ("Recordings");
        fallbackFolder.createDirectory();
        workingFile = livent::uniqueMasterRecordingFile (fallbackFolder, suggestedName);
        started = mixer.startMasterRecording (workingFile);
    }

    if (! started)
    {
        refreshTopRecordButton();
        livent::alert (livent::vn ("Không bắt đầu ghi được"),
            livent::vn ("LiveNT không tạo được file làm việc trong Music hoặc thư mục tạm.\n\n")
            + livent::vn ("Kiểm tra quyền ghi và dung lượng ổ đĩa."),
            juce::MessageBoxIconType::WarningIcon);
        return;
    }

    tonePanel.setRecordingActive (true);
    masterRecordingUiActive = true;
    refreshTopRecordButton();
}

void MainComponent::stopMasterRecording()
{
    if (! mixer.isMasterRecording() && ! masterRecordingUiActive)
        return;

    //  Ha co GHI TRUOC (luong am thanh ngung ngay), roi moi hoi noi luu.
    //  File tam da co san dung o thu muc Music/LiveNT tu luc bam THU -
    //  hoi luc nay la de anh CHUYEN no sang cho khac neu muon, khong bat
    //  buoc phai chon lai moi lan.
    mixer.stopMasterRecording();

    masterRecordingUiActive = false;
    tonePanel.setRecordingActive (false);
    refreshTopRecordButton();

    const int droppedBlocks = mixer.getMasterDroppedBlocks();
    const auto droppedSamples = mixer.getMasterDroppedSamples();
    if (droppedBlocks > 0 || mixer.hasMasterFinalizationError())
    {
        livent::alert (livent::vn ("Cảnh báo bản thu"),
            livent::vn ("Bản thu gặp lỗi audio hoặc ghi/chốt file. LiveNT ghi nhận ")
                + juce::String (droppedBlocks) + livent::vn (" khối bị rớt (")
                + juce::String ((juce::int64) droppedSamples) + livent::vn (" mẫu).\n\n")
                + (mixer.hasMasterFinalizationError()
                     ? livent::vn ("Không xác nhận được WAV hoàn chỉnh khi chốt file. Hãy kiểm tra bản thu.")
                     : livent::vn ("Khoảng thiếu được giữ bằng im lặng để không dồn thời gian. File vẫn được giữ để anh lưu; hãy nghe kiểm tra lại.")),
            juce::MessageBoxIconType::WarningIcon);
    }

    const auto tempFile = mixer.getMasterRecordingFile();

    if (! tempFile.existsAsFile())
        return;

    auto chooser = std::make_shared<juce::FileChooser> (
                       livent::vn ("Lưu bản thu vào đâu?"),
                       tempFile,
                       "*.wav");

    chooser->launchAsync (juce::FileBrowserComponent::saveMode
                            | juce::FileBrowserComponent::warnAboutOverwriting,
        [tempFile, chooser] (const juce::FileChooser& fc)
        {
            auto dest = fc.getResult();

            if (dest == juce::File())
                return;   // Huy: ban goc van con nguyen o thu muc lam viec.

            /* Native NSSavePanel tren macOS co the tra ten nguoi dung go ma
               khong kem extension. File ben trong van la WAV nhung Finder/app
               khac se kho nhan. Ep duoi dung nhu luong Save Project .NT. */
            if (! dest.hasFileExtension (".wav"))
                dest = dest.withFileExtension (".wav");

            if (dest == tempFile)
                return;

            /*  XUAT AN TOAN QUA VOLUME / MACOS:
                  1) copy ban thu sang file .part CUNG thu muc dich
                  2) doi chieu dung kich thuoc
                  3) replace/rename .part -> file that trong cung filesystem
                  4) CHI xoa ban goc sau khi doc lai file dich dung

                Khong move truc tiep nua: move co the fail khi tu ~/Music/temp
                sang USB, iCloud, SMB hay volume khac. Neu bat ky buoc nao hong,
                ban thu goc van con 100%. */
            auto part = dest.getSiblingFile (dest.getFileName() + ".livent-part");
            part.deleteFile();

            const auto expectedBytes = tempFile.getSize();
            const bool copied = tempFile.copyFileTo (part);

            if (! copied || ! part.existsAsFile() || part.getSize() != expectedBytes)
            {
                part.deleteFile();
                livent::alert (livent::vn ("Xuất bản thu thất bại"),
                    livent::vn ("Không chép đủ dữ liệu tới nơi đã chọn. Bản thu gốc vẫn còn tại:\n")
                        + tempFile.getFullPathName(),
                    juce::MessageBoxIconType::WarningIcon);
                return;
            }

            bool installed = part.replaceFileIn (dest);
            if (! installed && ! dest.existsAsFile())
                installed = part.moveFileTo (dest);

            if (! installed || ! dest.existsAsFile() || dest.getSize() != expectedBytes)
            {
                part.deleteFile();
                livent::alert (livent::vn ("Xuất bản thu thất bại"),
                    livent::vn ("File đích không vượt qua kiểm tra sau khi ghi. Bản thu gốc vẫn còn tại:\n")
                        + tempFile.getFullPathName(),
                    juce::MessageBoxIconType::WarningIcon);
                return;
            }

            tempFile.deleteFile();
        });
}

//=============================================================================
// V6.6.5 - XUAT MASTER WAV / MP3
//=============================================================================
void MainComponent::showExportMenu (juce::Component* /*anchor*/)
{
    /*  V0.6.7.7: bam XUAT -> mo thang hop thoai "Xuất âm thanh" kieu Cubase
        (ExportDialog.h). Dinh dang WAV/MP3/FLAC chon ngay trong hop.  */
    chooseTimelineExport (false);
}

void MainComponent::chooseTimelineExport (bool mp3)
{
    if (timelineExportActive || timelineExportFinishing)
    {
        if (exportProgressWindow != nullptr)
            exportProgressWindow->toFront (true);
        return;
    }

    if (exportDialogWindow != nullptr)
    {
        exportDialogWindow->toFront (true);
        return;
    }

    if (! projectOpen)
    {
        livent::alert (livent::vn ("Chưa có dự án"),
                       livent::vn ("Hãy tạo hoặc mở dự án trước khi xuất."));
        return;
    }

    if(!mixer.waitForPendingTakes())
    {livent::alert(livent::vn("Bản thu đang chốt"),livent::vn("Chờ WAV hoàn tất rồi xuất lại."));return;}
    const double length = mixer.getTimelineLengthSeconds();
    if (length <= 0.0)
    {
        livent::alert (livent::vn ("Chưa có âm thanh để xuất"),
                       livent::vn ("Timeline chưa có clip nào. Thu hoặc đưa âm thanh vào timeline trước."));
        return;
    }

    if (mixer.isTimelineRecording() || mixer.isMasterRecording())
    {
        livent::alert (livent::vn ("Đang thu âm"),
                       livent::vn ("Hãy dừng thu trước khi xuất project."));
        return;
    }

    auto settings = livent::exporting::Settings::load();

    auto base = currentProjectFile != juce::File()
                  ? currentProjectFile.getFileNameWithoutExtension()
                  : juce::String ("LiveNT_") + juce::Time::getCurrentTime().formatted ("%Y%m%d_%H%M%S");
    if (base.isEmpty())
        base = "LiveNT_Export";
    settings.name = base;

    const bool hasFfmpeg = findFfmpegExecutable().existsAsFile();
    if (mp3 && hasFfmpeg)
        settings.type = livent::exporting::FileType::mp3;

    const double projectRate = mixer.getCurrentSampleRate() > 0.0 ? mixer.getCurrentSampleRate() : 48000.0;

    const auto& selection = mixer.getTimelineUi();
    const double rangeStart = mixer.hasTimelineLocators() ? mixer.getTimelineLocatorStart()
                                                        : selection.hasRange() ? selection.rangeStart : -1.0;
    const double rangeEnd = mixer.hasTimelineLocators() ? mixer.getTimelineLocatorEnd()
                                                      : selection.hasRange() ? selection.rangeEnd : -1.0;
    auto* content = new livent::exporting::DialogComponent (settings, projectRate, length, hasFfmpeg,
                                                           rangeStart, rangeEnd, mixer.supportsOfflineExport());

    juce::Component::SafePointer<MainComponent> safeThis (this);
    content->onCancel = [safeThis]
    {
        if (safeThis != nullptr && safeThis->exportDialogWindow != nullptr)
            safeThis->exportDialogWindow->exitModalState (0);
    };
    content->onExport = [safeThis] (const livent::exporting::Settings& chosen)
    {
        if (safeThis == nullptr)
            return;

        chosen.save();

        if (safeThis->exportDialogWindow != nullptr)
            safeThis->exportDialogWindow->exitModalState (1);

        // Dong hop thoai xong (message tick sau) moi bat dau render.
        juce::MessageManager::callAsync ([safeThis, chosen]
        {
            if (safeThis != nullptr)
                safeThis->startExportWithSettings (chosen);
        });
    };

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (content);
    o.dialogTitle = livent::vn ("Xuất âm thanh (Export Audio Mixdown)");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = false;
    exportDialogWindow = livent::launchDialog (o, this);
}

void MainComponent::startExportWithSettings (const livent::exporting::Settings& s)
{
    using livent::exporting::Conflict;

    auto dest = s.destination();

    if (s.type == livent::exporting::FileType::mp3 && ! findFfmpegExecutable().existsAsFile())
    {
        livent::alert (livent::vn ("Không tìm thấy FFmpeg"),
                       livent::vn ("Xuất MP3 cần FFmpeg phù hợp với máy. Hãy chọn WAV hoặc FLAC."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    if (dest.existsAsFile())
    {
        if (s.conflict == Conflict::autoNumber)
        {
            dest = dest.getNonexistentSibling (true);
        }
        else if (s.conflict == Conflict::ask)
        {
            juce::Component::SafePointer<MainComponent> safeThis (this);
            livent::confirm (livent::vn ("File đã có"),
                             livent::vn ("Đã có file:\n") + dest.getFullPathName()
                               + livent::vn ("\n\nGhi đè file này?"),
                             livent::vn ("Ghi đè"), livent::vn ("Hủy"),
                             [safeThis, dest, s] (bool yes)
                             {
                                 if (yes && safeThis != nullptr)
                                     safeThis->beginTimelineExport (dest, s);
                             });
            return;
        }
    }

    beginTimelineExport (dest, s);
}

void MainComponent::beginTimelineExport (const juce::File& destination,
                                         const livent::exporting::Settings& s)
{
    if (timelineExportActive || timelineExportFinishing)
        return;

    if (! s.realTime)
    {
        beginOfflineTimelineExport (destination, s);
        return;
    }
    timelineExportOffline = false;

    // 07/10: xuat theo vung khoa P (bôi đen -> P) hoac ca bai
    const bool ranged = s.hasRange();
    const double startAt = ranged ? s.rangeStart : 0.0;
    const double length = ranged ? s.rangeEnd - s.rangeStart : mixer.getTimelineLengthSeconds();
    if (length <= 0.0)
        return;

    /*  A1: kiem tra payload WAV cua moi nguon se duoc doc luc xuat (tren luong dieu khien, KHONG
        trong audio callback). File WAV bi cat (header noi nhieu hon du lieu that) khong duoc phep
        tro thanh doan im lang trong ban xuat. Track/clip bi mute khong tinh.  */
    {
        /*  F12: chi kiem NHUNG file engine thuc su doc: lane/take dang nghe (audition), clip khong bi mute.
            File gan san vao track chi tinh khi track khong co clip nao tren timeline.
            Khong loc theo vung xuat vi lich su FX co the can audio truoc vung do.  */
        juce::Array<juce::File> sources;
        const auto timelineState = mixer.getTimelineState();
        for (int i = 0; i < mixer.getNumTracks(); ++i)
            if (auto* t = mixer.getTrack (i))
                if (! t->isMuted() && t->getSource() == Track::Source::AudioFile)
                {
                    bool hasClips = false;
                    for (const auto& lane : timelineState)
                        if (lane.trackUuid == t->getUuid() && ! lane.clips.empty()) hasClips = true;
                    if (! hasClips) sources.addIfNotAlreadyThere (t->getLoadedFile());
                }
        for (const auto& lane : timelineState)
        {
            auto* owner = mixer.getTrackByUuid (lane.trackUuid);
            if (owner != nullptr && owner->isMuted()) continue;
            if (lane.layers.isMuted (lane.layers.audition)) continue;
            for (const auto& clip : lane.clips)
                if (clip != nullptr && clip->takeLayer == lane.layers.audition && ! clip->muted)
                    sources.addIfNotAlreadyThere (clip->file);
        }
        const auto broken = livent::firstIncompleteWav (sources);
        if (broken.isNotEmpty())
        {
            livent::alert (livent::vn ("Không thể xuất"),
                           livent::vn ("File âm thanh bị thiếu dữ liệu (file WAV bị cắt):\n") + broken
                             + livent::vn ("\n\nXuất tiếp sẽ làm đoạn đó im lặng. Hãy thay file rồi xuất lại."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }
    }

    if (mixer.isTimelinePlaying())
        mixer.toggleTimelinePlayback();

    mixer.setTimelinePositionSeconds (startAt);
    // Sau diem cuoi: NHAC/MIC im (chi con duoi vang cua VST), transport khong tu dung
    mixer.setTimelinePlayEndLimit (startAt + length);

    auto tempDir = juce::File::getSpecialLocation (juce::File::tempDirectory)
                     .getChildFile ("LiveNT").getChildFile ("Exports");
    tempDir.createDirectory();
    timelineExportTempWav = tempDir.getNonexistentChildFile ("LiveNT_Export", ".wav", false);

    const double totalSeconds = length + juce::jmax (0.0, s.tailSeconds);

    // V0.6.7.7: render tam WAV 32-bit float -> chuan hoa/doi dinh dang khong mat chat.
    mixer.setRealtimeExportSourcesOnly (true);
    if (! mixer.startMasterRecording (timelineExportTempWav, totalSeconds, 32))
    {
        mixer.setTimelinePlayEndLimit (-1.0);
        mixer.setRealtimeExportSourcesOnly (false);
        livent::alert (livent::vn ("Không thể xuất"),
                       livent::vn ("LiveNT không tạo được file WAV tạm để render Master."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    timelineExportActive        = true;
    timelineExportFinishing     = false;
    mixer.setRealtimeExportSourcesOnly (true);
    timelineExportSettings      = s;
    timelineExportLengthSeconds = length;
    timelineExportTotalSeconds  = totalSeconds;
    timelineExportLastRecorded  = 0.0;
    timelineExportStallTicks    = 0;
    timelineExportDestination   = destination;
    timelineExportCancel        = std::make_shared<std::atomic<bool>> (false);

    topExportButton.setEnabled (false);
    timelineTransport.setExportEnabled (false);
    topRecordButton.setEnabled (false);

    statusLabel.setText (livent::vn ("ĐANG XUẤT - render Master..."), juce::dontSendNotification);

    // Hop tien trinh giong "Perform Audio Export" cua Cubase
    {
        auto* ui = new livent::exporting::ProgressComponent (destination.getFileName());
        juce::Component::SafePointer<MainComponent> safeThis (this);
        ui->onAbort = [safeThis]
        {
            if (safeThis != nullptr)
                safeThis->abortTimelineExport();
        };
        exportProgressUi = ui;

        juce::DialogWindow::LaunchOptions o;
        o.content.setOwned (ui);
        o.dialogTitle = livent::vn ("Đang xuất âm thanh");
        o.dialogBackgroundColour = Col::panel;
        o.escapeKeyTriggersCloseButton = false;
        o.useNativeTitleBar = true;
        o.resizable = false;
        exportProgressWindow = livent::launchDialog (o, this);
        ui->setState (livent::vn ("Bước 1/2 - Render Master (thời gian thực)"), 0.0, totalSeconds);
    }

    const auto prepareError = mixer.startRealtimeExportPlayback (startAt, startAt + length);
    if (prepareError.isNotEmpty())
    {
        abortTimelineExport();
        livent::alert (livent::vn ("Không thể xuất"), prepareError, juce::MessageBoxIconType::WarningIcon);
        return;
    }
    timelineExportPrerollSeconds=startAt+(double)mixer.getGraphLatencySamples()/juce::jmax(1.0,mixer.getCurrentSampleRate());
    juce::Timer::callAfterDelay (100, [safeThis = juce::Component::SafePointer<MainComponent> (this)]
    {
        if (safeThis != nullptr)
            safeThis->pollTimelineExport();
    });
}

void MainComponent::beginOfflineTimelineExport (const juce::File& destination,
                                                const livent::exporting::Settings& settings)
{
    const double start = settings.hasRange() ? settings.rangeStart : 0.0;
    const double end = settings.hasRange() ? settings.rangeEnd : mixer.getTimelineLengthSeconds();
    const auto prepareError = mixer.beginOfflineExport (start, end);
    if (prepareError.isNotEmpty())
    {
        livent::alert (livent::vn ("Không thể xuất"), prepareError, juce::MessageBoxIconType::WarningIcon);
        return;
    }
    auto folder = juce::File::getSpecialLocation (juce::File::tempDirectory)
                    .getChildFile ("LiveNT").getChildFile ("Exports");
    folder.createDirectory();
    timelineExportTempWav = folder.getNonexistentChildFile ("LiveNT_Offline", ".wav", false);
    timelineExportSettings = settings;
    timelineExportDestination = destination;
    timelineExportCancel = std::make_shared<std::atomic<bool>> (false);
    timelineRenderProgress = std::make_shared<std::atomic<double>> (0.0);
    timelineRenderDone = std::make_shared<std::atomic<bool>> (false);
    timelineRenderError = std::make_shared<juce::String>();
    timelineExportOffline = timelineExportActive = true;
    topExportButton.setEnabled (false);
    timelineTransport.setExportEnabled (false);
    topRecordButton.setEnabled (false);
    statusLabel.setText (livent::vn ("ĐANG XUẤT NHANH QUA VST VÀ MASTER..."), juce::dontSendNotification);
    auto* ui = new livent::exporting::ProgressComponent (destination.getFileName());
    const juce::Component::SafePointer<MainComponent> safeThis (this);
    ui->onAbort = [safeThis] { if (safeThis != nullptr) safeThis->abortTimelineExport(); };
    exportProgressUi = ui;
    juce::DialogWindow::LaunchOptions options;
    options.content.setOwned (ui);
    options.dialogTitle = livent::vn ("Đang xuất âm thanh");
    options.dialogBackgroundColour = Col::panel;
    options.escapeKeyTriggersCloseButton = false;
    options.useNativeTitleBar = true;
    options.resizable = false;
    exportProgressWindow = livent::launchDialog (options, this);
    ui->setState (livent::vn ("Bước 1/2 - Render nhanh qua VST và Master"), 0.0, -1.0);
    const auto file = timelineExportTempWav;
    const auto cancel = timelineExportCancel;
    const auto progress = timelineRenderProgress;
    const auto done = timelineRenderDone;
    const auto error = timelineRenderError;
    try
    {
        timelineExportWorker = std::thread ([this, file, start, end, settings, cancel, progress, done, error]
        {
            try { *error = mixer.renderOfflineExport (file, start, end, settings.tailSeconds, *cancel, *progress); }
            catch (const std::exception& e) { *error = livent::vn ("Plugin lỗi khi render: ") + juce::String (e.what()); }
            catch (...) { *error = livent::vn ("Plugin lỗi khi render offline. Thử chế độ thời gian thực."); }
            done->store (true, std::memory_order_release);
        });
    }
    catch (...)
    {
        *error = livent::vn ("Không tạo được luồng render.");
        done->store (true);
    }
    pollTimelineExport();
}

void MainComponent::pollTimelineExport()
{
    if (! timelineExportActive)
        return;

    if (timelineExportOffline)
    {
        const double p = timelineRenderProgress != nullptr ? timelineRenderProgress->load() : 0.0;
        if (exportProgressUi != nullptr)
            exportProgressUi->setState (livent::vn ("Bước 1/2 - Render nhanh qua VST và Master"), 0.85 * p, -1.0);
        if (timelineRenderDone != nullptr && timelineRenderDone->load())
        {
            if (timelineExportWorker.joinable()) timelineExportWorker.join();
            mixer.endOfflineExport();
            timelineExportActive = false;
            timelineExportOffline = false;
            const auto error = *timelineRenderError;
            if (timelineExportCancel->load() || error.isNotEmpty())
            {
                timelineExportTempWav.deleteFile();
                endTimelineExportUi();
                if (error.isNotEmpty())
                    livent::alert (livent::vn ("Xuất thất bại"), error, juce::MessageBoxIconType::WarningIcon);
                else statusLabel.setText (livent::vn ("ĐÃ HỦY XUẤT"), juce::dontSendNotification);
            }
            else finishTimelineExport();
            return;
        }
        juce::Timer::callAfterDelay (100, [safeThis = juce::Component::SafePointer<MainComponent> (this)]
        { if (safeThis != nullptr) safeThis->pollTimelineExport(); });
        return;
    }

    const auto sourceError = mixer.getRealtimeExportReadError();
    if (sourceError.isNotEmpty())
    {
        abortTimelineExport();
        livent::alert (livent::vn ("Xuất thời gian thực thất bại"), sourceError,
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }
    const double recorded = mixer.getMasterRecordedSeconds();
    const double total    = juce::jmax (0.001, timelineExportTotalSeconds);
    if (mixer.getMasterDroppedBlocks() > 0 || mixer.hasMasterFinalizationError()
        || ! mixer.isMasterRecording())
    {
        abortTimelineExport();
        livent::alert (livent::vn ("Xuất thời gian thực thất bại"),
                       livent::vn ("Audio bị hụt hoặc soundcard đã dừng/thay đổi. File xuất chưa được hoàn thiện. Hãy xuất lại, hoặc dùng chế độ offline."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    // Card am thanh dung giua chung (rut USB, doi driver) -> khong cho mai.
    const double processed=mixer.getRealtimeExportProcessedSeconds();
    if (processed <= timelineExportLastRecorded + 1.0e-6)
        ++timelineExportStallTicks;
    else
        timelineExportStallTicks = 0;
    timelineExportLastRecorded = processed;

    if (exportProgressUi != nullptr)
        exportProgressUi->setState (processed<timelineExportPrerollSeconds
                                        ? livent::vn("Bước 1/2 - Dựng lịch sử FX từ đầu...")
                                        : recorded < timelineExportLengthSeconds
                                        ? livent::vn ("Bước 1/2 - Render Master (thời gian thực)")
                                        : livent::vn ("Bước 1/2 - Ghi đuôi vang..."),
                                    0.85 * processed / (timelineExportPrerollSeconds+total),
                                    juce::jmax (0.0, timelineExportPrerollSeconds+total-processed));

    // The recorder caps the file at the exact requested sample count. Polling
    // must wait for that count; a 20/50 ms tolerance used to truncate exports.
    const double sampleTolerance = 0.5 / juce::jmax (1.0, mixer.getCurrentSampleRate());
    const bool done = recorded >= total - sampleTolerance;

    if (timelineExportStallTicks > 50)   // ~5 giay khong co mau nao
    {
        abortTimelineExport();
        livent::alert (livent::vn ("Xuất bị dừng"),
                       livent::vn ("Soundcard không chạy nên không render được. Kiểm tra card âm thanh rồi xuất lại."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    if (done)
    {
        if (mixer.isTimelinePlaying())
            mixer.toggleTimelinePlayback();
        mixer.setTimelinePlayEndLimit (-1.0);
        mixer.stopMasterRecording();
        const auto finalSourceError = mixer.getRealtimeExportReadError();
        mixer.setRealtimeExportSourcesOnly (false);
        if (finalSourceError.isNotEmpty())
        {
            abortTimelineExport();
            livent::alert (livent::vn ("Xuất thời gian thực thất bại"), finalSourceError,
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }
        if (mixer.getMasterDroppedBlocks() > 0 || mixer.hasMasterFinalizationError())
        {
            abortTimelineExport();
            livent::alert (livent::vn ("Xuất thời gian thực thất bại"),
                           livent::vn ("Phát hiện audio bị hụt khi chốt WAV. Hãy xuất lại."),
                           juce::MessageBoxIconType::WarningIcon);
            return;
        }
        finishTimelineExport();
        return;
    }

    juce::Timer::callAfterDelay (100, [safeThis = juce::Component::SafePointer<MainComponent> (this)]
    {
        if (safeThis != nullptr)
            safeThis->pollTimelineExport();
    });
}

void MainComponent::abortTimelineExport()
{
    if(timelineExportFinishing && timelineExportCommitGate && !timelineExportCommitGate->requestCancel()) return;
    if (timelineExportCancel != nullptr)
        timelineExportCancel->store (true);

    if (timelineExportActive && timelineExportOffline) return; // worker finishes, then poll restores the graph

    if (timelineExportActive)
    {
        if (mixer.isTimelinePlaying())
            mixer.toggleTimelinePlayback();
        mixer.setTimelinePlayEndLimit (-1.0);
        mixer.stopMasterRecording();
        timelineExportActive = false;
        timelineExportTempWav.deleteFile();
        endTimelineExportUi();
        statusLabel.setText (livent::vn ("ĐÃ HỦY XUẤT"), juce::dontSendNotification);
    }
    // Neu dang o buoc 2, luong nen tu thay co cancel va don file; pollExportFinishing dong UI.
}

void MainComponent::endTimelineExportUi()
{
    mixer.setRealtimeExportSourcesOnly (false);
    if (exportProgressWindow != nullptr)
        exportProgressWindow->exitModalState (0);

    exportProgressUi = nullptr;
    topExportButton.setEnabled (true);
    timelineTransport.setExportEnabled (true);
    topRecordButton.setEnabled (true);
}

//=============================================================================
// 07/10: NHAP FILE VAO TIMELINE + KHOI PHUC BAN THU
//=============================================================================
//=============================================================================
// 14/10: BANG TONG QUAN KENH (nut "e" kieu Cubase)
//=============================================================================
/** Thanh tren cung: [◀] [▶] [TEN TRACK mau track] + loai track.  Ben duoi: InspectorPanel kieu 4 cot. */
    class ChannelOverviewContent final : public juce::Component, private juce::Timer
    {
    public:
        ChannelOverviewContent (Mixer& m) : mixer (m), panel (m)
        {
            for (auto* b : { &prevButton, &nextButton })
            {
                b->setWantsKeyboardFocus (false);
                addAndMakeVisible (*b);
            }
            prevButton.setTooltip (livent::vn ("Track trước"));
            nextButton.setTooltip (livent::vn ("Track sau"));
            prevButton.onClick = [this] { if (onStep) onStep (-1); };
            nextButton.onClick = [this] { if (onStep) onStep (+1); };
            addAndMakeVisible (panel);
            panel.setOverviewLayout (true);
            startTimerHz (4);
        }

        void setTrack (Track* t)
        {
            panel.setTrack (t);
            panel.setOverviewLayout (true);
            repaint();
        }

        Track* getTrack() const { return panel.getTrack(); }
        InspectorPanel& getPanel() { return panel; }
        std::function<void (int)> onStep;

        void paint (juce::Graphics& g) override
        {
            g.fillAll (workspace::bg.darker (0.25f));
            auto bar = getLocalBounds().removeFromTop (40).reduced (8, 7);
            bar.removeFromLeft (2 * 30 + 8);
            if (auto* t = panel.getTrack())
            {
                auto name = bar.removeFromLeft (juce::jmin (220, bar.getWidth() / 2));
                g.setColour (t->getColour());
                g.fillRoundedRectangle (name.toFloat(), 4.0f);
                g.setColour (t->getColour().getPerceivedBrightness() > 0.55f ? juce::Colours::black : juce::Colours::white);
                g.setFont (juce::Font (juce::FontOptions (14.0f).withStyle ("Bold")));
                g.drawText (t->getName(), name.reduced (10, 0), juce::Justification::centredLeft, true);
                bar.removeFromLeft (12);
                g.setColour (workspace::dim);
                g.setFont (juce::Font (juce::FontOptions (12.0f)));
                g.drawText (t->getTypeName() + "  ·  " + (t->getChannelMode() == Track::Chan::Mono ? "Mono" : "Stereo"),
                            bar, juce::Justification::centredLeft, true);
            }
            g.setColour (workspace::line);
            g.drawHorizontalLine (40, 0.0f, (float) getWidth());
        }

        void resized() override
        {
            auto bar = getLocalBounds().removeFromTop (40).reduced (8, 7);
            prevButton.setBounds (bar.removeFromLeft (30)); bar.removeFromLeft (4);
            nextButton.setBounds (bar.removeFromLeft (30));
            panel.setBounds (getLocalBounds().withTrimmedTop (41));
        }

    private:
        void timerCallback() override
        {
            // Track bi xoa / doi du an -> dong bang an toan.
            if (auto* t = panel.getTrack())
                if (mixer.indexOfTrack (t) < 0)
                {
                    panel.setTrack (nullptr);
                    if (auto* w = findParentComponentOfClass<juce::DocumentWindow>())
                        w->setVisible (false);
                }
        }

        Mixer& mixer;
        juce::TextButton prevButton { juce::String::fromUTF8 ("\xe2\x97\x80") }, nextButton { juce::String::fromUTF8 ("\xe2\x96\xb6") };
        InspectorPanel panel;
    };

void MainComponent::closeChannelOverview()
{
    // Goi TRUOC moi lan track bi xoa / doi du an: bang tong quan khong duoc giu con tro track chet.
    if (channelOverviewContent != nullptr)
        channelOverviewContent->setTrack (nullptr);
    if (channelOverviewWindow != nullptr)
        channelOverviewWindow->setVisible (false);
}

void MainComponent::openChannelOverview (Track* t)
{
    if (t == nullptr || ! projectOpen)
        return;

    const int at = mixer.indexOfTrack (t);
    if (at < 0)
        return;
    if (inspector.getTrack() != t)
        selectTrack (at);   // cac nut them VST / mo VST cua bang dung track dang chon

    if (channelOverviewWindow == nullptr)
    {
        auto content = std::make_unique<ChannelOverviewContent> (mixer);
        auto* c = content.get();
        auto& p = c->getPanel();

        // Dung CHUNG cac ham cua Inspector chinh (track da duoc chon o tren).
        p.getOutputChannelNames    = inspector.getOutputChannelNames;
        p.getAllOutputChannelNames = inspector.getAllOutputChannelNames;
        p.getOutputDeviceIdentity  = inspector.getOutputDeviceIdentity;
        p.getActiveOutputPairIndex = inspector.getActiveOutputPairIndex;
        p.activateOutputPair       = inspector.activateOutputPair;
        p.getInputChannelNames     = inspector.getInputChannelNames;
        p.onChoosePlugin           = [this] (int slot) { showPluginMenuForSlot (slot); };
        p.onOpenEditor             = [this] (int slot) { toggleEditorForSlot (slot); };
        p.onPluginAboutToBeRemoved = [this] (juce::AudioPluginInstance* pl) { pluginWindows.closeFor (pl); };
        p.onInsertsReordered       = inspector.onInsertsReordered;
        p.onExpandEq               = [this] (Track* tr) { showExpandedEq (tr); };
        p.onTrackChanged           = [this]
        {
            markProjectDirty();
            updateTitleText();
            for (auto* row : trackRows)
                row->refresh();
            inspector.refreshFromTrack();
        };

        c->onStep = [this] (int step)
        {
            const int n = mixer.getNumTracks();
            auto* cur = channelOverviewContent != nullptr ? channelOverviewContent->getTrack() : nullptr;
            int idx = cur != nullptr ? mixer.indexOfTrack (cur) : 0;
            for (int tries = 0; tries < n; ++tries)
            {
                idx = (idx + step + n) % n;
                if (auto* next = mixer.getTrack (idx))
                    if (next->getType() != Track::Type::Input)   // track cong vao an khoi danh sach F2
                    {
                        openChannelOverview (next);
                        return;
                    }
            }
        };

        channelOverviewContent = c;
        channelOverviewWindow = std::make_unique<livent::UtilityWindow> (livent::vn ("Tổng quan kênh"), std::move (content), 1100, 600);
        channelOverviewWindow->setResizeLimits (760, 420, 2400, 1600);
    }

    channelOverviewContent->setTrack (t);
    channelOverviewWindow->setName (livent::vn ("Tổng quan kênh — ") + t->getName());
    channelOverviewWindow->show();
}

//=============================================================================
// 14/10: DON DEP DU AN THU AM
//=============================================================================
void MainComponent::removeMissingTimelineClips()
{
    juce::StringArray ids;
    for (const auto& lane : mixer.getTimelineState())
        for (const auto& clip : lane.clips)
            if (clip != nullptr && clip->missingMedia)
                ids.add (clip->clipId);
    if (ids.isEmpty())
        return;

    if (mixer.timelineEdit ([ids] (TimelineState& s) { return livent::tledit::removeClips (s, ids); }))
    {
        projectDirty = true;
        updateTitleText();
        tonePanel.showAutoKeyStatus (livent::vn ("Đã xóa ") + juce::String (ids.size())
                                     + livent::vn (" đoạn thiếu audio. Lưu dự án để giữ thay đổi."));
    }
}

static void scanAudioFolder (const juce::File& folder, int& files, juce::int64& bytes)
{
    files = 0; bytes = 0;
    if (! folder.isDirectory())
        return;
    for (const auto& entry : juce::RangedDirectoryIterator (folder, true, "*", juce::File::findFiles))
    {
        ++files;
        bytes += entry.getFileSize();
    }
}

/** 14/10: cac du an KHAC (cung thu muc + danh sach gan day) - de biet file thu co dang duoc du an khac dung chung khong
    (vd "Luu thanh..." khong copy thu muc _Audio, du an moi van tro vao thu muc cu). */
static juce::Array<juce::File> otherProjectFiles (const juce::File& self, const juce::RecentlyOpenedFilesList& recent)
{
    juce::Array<juce::File> out;
    auto add = [&] (const juce::File& f)
    {
        if (f.existsAsFile() && f != self && f.getFileExtension().equalsIgnoreCase (".NT"))
            out.addIfNotAlreadyThere (f);
    };
    for (const auto& e : juce::RangedDirectoryIterator (self.getParentDirectory(), false, "*.NT;*.nt", juce::File::findFiles))
        add (e.getFile());
    for (int i = 0; i < recent.getNumFiles(); ++i)
        add (recent.getFile (i));
    return out;
}

/** Ten cac du an co nhac toi it nhat mot chuoi trong `needles` (khong phan biet hoa thuong). */
static juce::StringArray projectsMentioning (const juce::Array<juce::File>& projects, const juce::StringArray& needles)
{
    juce::StringArray names;
    for (const auto& pf : projects)
    {
        if (pf.getSize() > 256ll * 1024 * 1024)
            continue;
        const auto text = pf.loadFileAsString();
        for (const auto& n : needles)
            if (n.isNotEmpty() && text.containsIgnoreCase (n))
            {
                names.addIfNotAlreadyThere (pf.getFileNameWithoutExtension());
                break;
            }
    }
    return names;
}

void MainComponent::deleteRecordingProject()
{
    if (mixer.isMasterRecording() || mixer.isTimelineRecording())
    {
        livent::alert (livent::vn ("Đang thu âm"), livent::vn ("Dừng thu trước rồi mới xóa dự án."));
        return;
    }
    if (projectLoadInProgress || pluginLoadInProgress || ! projectPluginLoadJobs.empty())
    {
        livent::alert (livent::vn ("Đang nạp dự án"), livent::vn ("Chờ nạp xong plugin rồi mới xóa dự án."));
        return;
    }

    juce::Component::SafePointer<MainComponent> safeThis (this);

    auto confirmAndDelete = [safeThis] (const juce::File& nt)
    {
        if (safeThis == nullptr || ! nt.existsAsFile())
            return;

        const auto audio = nt.getSiblingFile (nt.getFileNameWithoutExtension() + "_Audio");
        int files = 0; juce::int64 bytes = 0;
        scanAudioFolder (audio, files, bytes);

        // Du an khac (vd ban "Luu thanh...") con tro vao thu muc thu am nay -> GIU thu muc, chi xoa file du an.
        juce::StringArray sharedBy;
        if (audio.isDirectory())
            sharedBy = projectsMentioning (otherProjectFiles (nt, safeThis->recentFiles),
                                           { audio.getFullPathName() + juce::File::getSeparatorString() });
        const bool keepAudio = ! sharedBy.isEmpty();

        juce::String msg;
        msg << livent::vn ("Xóa dự án \"") << nt.getFileNameWithoutExtension() << "\"?\n\n"
            << livent::vn ("•  File dự án: ") << nt.getFileName() << "\n";
        if (audio.isDirectory() && ! keepAudio)
            msg << livent::vn ("•  Thư mục thu âm: ") << audio.getFileName() << "  ("
                << files << livent::vn (" file · ") << juce::File::descriptionOfSizeInBytes (bytes) << ")\n";
        if (keepAudio)
            msg << livent::vn ("•  Thư mục thu âm \"") << audio.getFileName()
                << livent::vn ("\" đang được dự án khác dùng chung (") << sharedBy.joinIntoString (", ")
                << livent::vn (") nên sẽ được GIỮ LẠI.\n");
        msg << livent::vn ("\nCái bị xóa được chuyển vào Thùng rác - lỡ xóa nhầm vẫn khôi phục được.");

        livent::confirm (livent::vn ("Xóa dự án thu âm"), msg,
                         livent::vn ("Xóa dự án"), livent::vn ("Hủy"),
                         [safeThis, nt, audio, keepAudio] (bool ok)
                         {
                             if (! ok || safeThis == nullptr)
                                 return;

                             // Dang mo chinh du an nay -> dong ngay, KHONG hoi luu (dang xoa ma).
                             if (safeThis->projectOpen && safeThis->currentProjectFile == nt)
                             {
                                 safeThis->projectDirty = false;
                                 safeThis->closeProjectNow();
                                 if (safeThis->projectOpen)
                                     return;   // dang thu / dang chot WAV -> da bao loi, khong xoa
                             }

                             juce::StringArray failed;
                             auto trash = [&failed] (const juce::File& f)
                             {
                                 if (f.exists() && ! f.moveToTrash())
                                     failed.add (f.getFullPathName());
                             };
                             trash (nt);
                             trash (nt.getSiblingFile (nt.getFileName() + ".bak"));
                             if (! keepAudio)
                                 trash (audio);

                             safeThis->recentFiles.removeFile (nt);
                             safeThis->refreshProjectHub();

                             if (failed.isEmpty())
                                 safeThis->tonePanel.showAutoKeyStatus (livent::vn ("Đã chuyển dự án \"")
                                     + nt.getFileNameWithoutExtension() + livent::vn ("\" vào Thùng rác."));
                             else
                                 livent::alert (livent::vn ("Chưa xóa hết"),
                                                livent::vn ("Không chuyển được vào Thùng rác (file đang mở ở chương trình khác?):\n\n")
                                                    + failed.joinIntoString ("\n"),
                                                juce::MessageBoxIconType::WarningIcon);
                         });
    };

    if (projectOpen && currentProjectFile.existsAsFile())
    {
        confirmAndDelete (currentProjectFile);
        return;
    }

    // Chua mo du an nao -> chon file .NT can xoa.
    fileChooser = std::make_unique<juce::FileChooser> (livent::vn ("Chọn dự án cần xóa"),
                                                       currentProjectFile.existsAsFile() ? currentProjectFile.getParentDirectory()
                                                           : juce::File::getSpecialLocation (juce::File::userDocumentsDirectory),
                                                       "*.NT;*.nt");
    fileChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
                              [confirmAndDelete] (const juce::FileChooser& fc)
                              {
                                  const auto f = fc.getResult();
                                  if (f.existsAsFile())
                                      confirmAndDelete (f);
                              });
}

void MainComponent::cleanUnusedRecordings()
{
    if (! projectOpen || currentProjectFile == juce::File())
        return;
    if (mixer.isMasterRecording() || mixer.isTimelineRecording() || ! mixer.waitForPendingTakes())
    {
        livent::alert (livent::vn ("Đang thu âm"), livent::vn ("Dừng thu và chờ WAV chốt xong rồi mới dọn file."));
        return;
    }
    if (projectLoadInProgress || pluginLoadInProgress || ! projectPluginLoadJobs.empty())
    {
        livent::alert (livent::vn ("Đang nạp dự án"), livent::vn ("Chờ nạp xong plugin rồi mới dọn file thu."));
        return;
    }

    // Phai luu truoc: file .NT tren dia phai khop dung nhung gi dang dung.
    if (hasUnsavedChanges() && ! writeProjectTo (currentProjectFile))
        return;

    const auto folder = timelineAudioFolder();
    if (! folder.isDirectory())
    {
        livent::alert (livent::vn ("Dọn file thu"), livent::vn ("Dự án chưa có thư mục thu âm."));
        return;
    }

    // Giu lai moi file con dung, ke ca file nam trong lich su Ctrl+Z / Ctrl+Y.
    const auto used = mixer.getReferencedTimelineMedia();
    juce::Array<juce::File> unused;
    juce::int64 bytes = 0;
    for (const auto& entry : juce::RangedDirectoryIterator (folder, false, "*.wav;*.WAV;*.aif;*.aiff;*.flac;*.mp3", juce::File::findFiles))
    {
        const auto f = entry.getFile();
        if (used.contains (f.getFullPathName(), true))
            continue;
        unused.add (f);
        bytes += entry.getFileSize();
    }

    // Bo ra cac file ma du an KHAC (vd ban "Luu thanh...") van dang tro toi.
    {
        const auto others = otherProjectFiles (currentProjectFile, recentFiles);
        if (! others.isEmpty())
            for (int i = unused.size(); --i >= 0;)
                if (! projectsMentioning (others, { unused.getReference (i).getFullPathName() }).isEmpty())
                {
                    bytes -= unused.getReference (i).getSize();
                    unused.remove (i);
                }
    }

    if (unused.isEmpty())
    {
        livent::alert (livent::vn ("Dọn file thu"), livent::vn ("Không có file thu nào thừa. Mọi file trong thư mục đều đang được dùng."));
        return;
    }

    juce::Component::SafePointer<MainComponent> safeThis (this);
    livent::confirm (livent::vn ("Dọn file thu không dùng"),
                     juce::String (unused.size()) + livent::vn (" file thu không còn đoạn nào dùng tới (")
                         + juce::File::descriptionOfSizeInBytes (bytes)
                         + livent::vn (").\nChuyển vào Thùng rác cho nhẹ ổ đĩa? Dự án vẫn giữ nguyên."),
                     livent::vn ("Dọn"), livent::vn ("Hủy"),
                     [safeThis, unused] (bool ok)
                     {
                         if (! ok || safeThis == nullptr)
                             return;
                         int moved = 0;
                         for (const auto& f : unused)
                         {
                             if (f.moveToTrash()) ++moved;
                             f.getSiblingFile (f.getFileName() + ".liventpeak").deleteFile();   // file dinh song di kem
                         }
                         safeThis->tonePanel.showAutoKeyStatus (livent::vn ("Đã dọn ") + juce::String (moved)
                                                                + livent::vn (" file thu không dùng vào Thùng rác."));
                     });
}

juce::File MainComponent::timelineAudioFolder() const
{
    if (currentProjectFile != juce::File())
        return currentProjectFile.getSiblingFile (currentProjectFile.getFileNameWithoutExtension() + "_Audio");
    return juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
             .getChildFile ("LiveNT").getChildFile ("Recordings");
}

void MainComponent::importAudioToTimeline (Track* target, double atSeconds)
{
    if (! projectOpen || mixer.isTimelineRecording())
        return;

    if (target == nullptr || ! mixer.isTimelineRecordableTrack (*target))
    {
        auto* sel = mixer.getTrack (selectedTrackIndex);
        target = sel != nullptr && mixer.isTimelineRecordableTrack (*sel)
                   ? sel : mixer.getTrackByRole (Track::Role::Music);
    }
    if (target == nullptr)
    {
        livent::alert (livent::vn ("Nhập file"), livent::vn ("Dự án chưa có track NHẠC hoặc MÍC."));
        return;
    }

    const auto uuid = target->getUuid();
    const auto at = juce::jmax (0.0, atSeconds);

    importChooser = std::make_unique<juce::FileChooser> (
        livent::vn ("Nhập âm thanh vào track ") + target->getName(),
        juce::File::getSpecialLocation (juce::File::userMusicDirectory),
        "*.wav;*.mp3;*.flac;*.aif;*.aiff;*.ogg;*.m4a;*.aac;*.wma;*.mp4;*.mov;*.mkv;*.webm;*.avi");

    juce::Component::SafePointer<MainComponent> safeThis (this);
    // 07/10 _E (gop y 4): nho phien du an luc mo hop chon file. Doi / dong du
    // an trong luc chon hoac luc dang chuyen file -> bo, KHONG chen doan vao
    // du an khac (track trung uuid cua mau du an).
    const auto generation = projectLoadGeneration;
    importChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles,
        [safeThis, uuid, at, generation] (const juce::FileChooser& fc)
        {
            if (safeThis == nullptr || ! safeThis->projectOpen || safeThis->projectLoadGeneration != generation)
                return;
            const auto source = fc.getResult();
            if (! source.existsAsFile())
                return;

            auto folder = safeThis->timelineAudioFolder();
            folder.createDirectory();
            const auto dest = folder.getNonexistentChildFile (
                juce::File::createLegalFileName (source.getFileNameWithoutExtension()) + "_import", ".wav", false);
            const auto ffmpeg = safeThis->findFfmpegExecutable();

            ++safeThis->importJobs;
            safeThis->statusLabel.setText (livent::vn ("Đang nhập: ") + source.getFileName() + "...",
                                           juce::dontSendNotification);

            juce::Thread::launch ([safeThis, source, dest, ffmpeg, uuid, at, generation]
            {
                juce::String error;
                std::shared_ptr<TimelineClipData> clip;
                juce::AudioFormatManager fm;
                fm.registerBasicFormats();

                // 1) JUCE doc duoc (WAV/AIFF/FLAC/OGG, MP3 qua Windows Media / CoreAudio)
                bool decoded = false;
                if (std::unique_ptr<juce::AudioFormatReader> reader { fm.createReaderFor (source) })
                {
                    if (reader->sampleRate > 0.0 && reader->lengthInSamples > 0)
                    {
                        const int ch = juce::jlimit (1, 2, (int) reader->numChannels);
                        if (auto out = std::unique_ptr<juce::FileOutputStream> (dest.createOutputStream()))
                        {
                            juce::WavAudioFormat wav;
                            std::unique_ptr<juce::AudioFormatWriter> w (wav.createWriterFor (out.get(), reader->sampleRate,
                                                                        (unsigned int) ch, 32, {}, 0));
                            if (w != nullptr)
                            {
                                out.release();
                                juce::AudioBuffer<float> buf (ch, 65536);
                                bool ok = true;
                                for (juce::int64 pos = 0; ok && pos < reader->lengthInSamples;)
                                {
                                    const int n = (int) juce::jmin<juce::int64> (65536, reader->lengthInSamples - pos);
                                    buf.clear();
                                    ok = reader->read (&buf, 0, n, pos, true, ch > 1)
                                      && w->writeFromAudioSampleBuffer (buf, 0, n);
                                    pos += n;
                                }
                                w.reset();
                                decoded = ok;
                            }
                        }
                    }
                }

                // 2) MP4 / M4A / video...: tach tieng bang FFmpeg di kem app
                if (! decoded)
                {
                    dest.deleteFile();
                    if (! ffmpeg.existsAsFile())
                        error = livent::vn ("File này cần FFmpeg để đọc (MP4/M4A/video). Chưa tìm thấy FFmpeg cạnh LiveNT.");
                    else
                    {
                        /*  07/10 _E (gop y 3): ban cu doc HET output truoc khi cho ->
                            gioi han 10 phut khong bao gio co tac dung (FFmpeg treo
                            la luong nhap treo theo). Gio: KHONG doc output, -nostdin
                            (khong cho ban phim), hoi trang thai moi 100 ms, qua han
                            hoac app dang dong thi GIET tien trinh.  */
                        juce::StringArray args { ffmpeg.getFullPathName(), "-nostdin", "-y", "-hide_banner", "-loglevel", "error",
                                                 "-i", source.getFullPathName(), "-vn", "-map", "0:a:0",
                                                 "-ac", "2", "-c:a", "pcm_f32le", dest.getFullPathName() };
                        juce::ChildProcess proc;
                        bool ok = proc.start (args, 0);
                        bool timedOut = false;
                        if (ok)
                        {
                            const auto deadline = juce::Time::getMillisecondCounter() + 10u * 60u * 1000u;
                            while (proc.isRunning())
                            {
                                if (juce::Time::getMillisecondCounter() > deadline || safeThis == nullptr)
                                {
                                    timedOut = true;
                                    proc.kill();
                                    break;
                                }
                                juce::Thread::sleep (100);
                            }
                            ok = ! timedOut && proc.getExitCode() == 0;
                        }
                        decoded = ok && dest.existsAsFile() && dest.getSize() > 64;
                        if (! decoded)
                        {
                            dest.deleteFile();
                            error = timedOut ? livent::vn ("FFmpeg chạy quá 10 phút - đã dừng. File có thể bị hỏng.")
                                             : livent::vn ("FFmpeg không tách được tiếng từ file này.");
                        }
                    }
                }

                if (decoded)
                {
                    clip = TrackTimelineCapture::makeClipFromFile (dest, fm);
                    if (clip == nullptr)
                        error = livent::vn ("Không đọc được file sau khi chuyển.");
                    else
                    {
                        clip->name = source.getFileNameWithoutExtension();
                        // 07/10 _D: nhap tu file video -> nho video goc de mo cua so video
                        if (livent::video::isVideoFile (source))
                            clip->videoFile = source;
                    }
                }

                juce::MessageManager::callAsync ([safeThis, clip, error, uuid, at, generation, dest, name = source.getFileName()]
                {
                    if (safeThis == nullptr)
                        return;
                    --safeThis->importJobs;

                    // 07/10 _E (gop y 4): du an da doi / dong trong luc chuyen file
                    if (! safeThis->projectOpen || safeThis->projectLoadGeneration != generation)
                    {
                        dest.deleteFile();
                        juce::File (dest.getFullPathName() + ".liventpeak").deleteFile();
                        safeThis->statusLabel.setText (livent::vn ("Bỏ nhập ") + name
                                                         + livent::vn (": dự án đã đổi trong lúc chuyển file."),
                                                       juce::dontSendNotification);
                        return;
                    }

                    if (clip == nullptr)
                    {
                        safeThis->statusLabel.setText ({}, juce::dontSendNotification);
                        livent::alert (livent::vn ("Không nhập được file"), name + "\n\n" + error,
                                       juce::MessageBoxIconType::WarningIcon);
                        return;
                    }

                    auto* track = safeThis->mixer.getTrackByUuid (uuid);
                    if (track == nullptr || ! safeThis->mixer.addTimelineClip (*track, clip, at))
                    {
                        livent::alert (livent::vn ("Không nhập được file"),
                                       livent::vn ("Track đích không còn, hoặc đang thu âm."));
                        return;
                    }

                    safeThis->statusLabel.setText (livent::vn ("Đã nhập: ") + name, juce::dontSendNotification);
                    safeThis->mixer.getTimelineUi().selected = juce::StringArray (clip->clipId);
                    if (clip->videoFile != juce::File() && safeThis->videoController != nullptr
                        && ! safeThis->videoController->isOpen())
                        (void) safeThis->videoController->open();
                    safeThis->mixer.touchTimeline();
                    safeThis->markProjectDirty();
                    safeThis->updateTitleText();
                });
            });
        });
}

void MainComponent::checkInterruptedTakes()
{
    if(recordingRecoveryDialogOpen)return;
    if(mixer.isFinalizingTakes())
    {
        juce::Timer::callAfterDelay(500,[safe=juce::Component::SafePointer<MainComponent>(this)]{if(safe)safe->checkInterruptedTakes();});
        return;
    }

    if (! projectOpen || mixer.isTimelineRecording())
        return;

    auto takes = mixer.findInterruptedTakes();
    if (takes.empty())
        return;

    juce::String list;
    for (const auto& t : takes)
    {
        auto* tr = mixer.getTrackByUuid (t.trackUuid);
        const int m = (int) (t.startSeconds / 60.0);
        list << livent::vn ("  •  ") << (t.name.isNotEmpty() ? t.name : livent::vn ("Bản thu"))
             << " - " << (tr != nullptr ? tr->getName() : juce::String())
             << livent::vn (" (từ ") << m << ":" << juce::String (t.startSeconds - m * 60.0, 0).paddedLeft ('0', 2) << ")\n";
    }

    juce::Component::SafePointer<MainComponent> safeThis (this);
    recordingRecoveryDialogOpen=true;
    livent::confirm (livent::vn ("Khôi phục bản thu"),
                     livent::vn ("Lần trước LiveNT bị tắt đột ngột (hoặc chưa kịp lưu) khi đang thu.\n"
                                 "Tìm thấy bản thu chưa có trong dự án:\n\n")
                       + list + livent::vn ("\nThêm lại vào timeline? (File WAV gốc luôn được giữ nguyên.)"),
                     livent::vn ("Thêm lại"), livent::vn ("Bỏ qua"),
                     [safeThis, takes] (bool yes)
                     {
                         if (safeThis == nullptr)
                             return;
                         safeThis->recordingRecoveryDialogOpen=false;
                         if (! yes)
                         {
                             safeThis->mixer.discardInterruptedTakes (takes);
                             return;
                         }
                         const int n = safeThis->mixer.recoverInterruptedTakes (takes);
                         if (n > 0)
                         {
                             safeThis->markProjectDirty();
                             safeThis->updateTitleText();
                             safeThis->statusLabel.setText (livent::vn ("Đã khôi phục ") + juce::String (n)
                                                              + livent::vn (" bản thu - nhớ Lưu dự án"),
                                                            juce::dontSendNotification);
                         }
                     });
}

juce::File MainComponent::findFfmpegExecutable() const
{
    const auto exeDir = juce::File::getSpecialLocation (juce::File::currentExecutableFile)
                          .getParentDirectory();

    for (const auto& name : { juce::String ("ffmpeg.exe"), juce::String ("fmep.exe"),
                              juce::String ("ffmpeg"), juce::String ("fmep") })
    {
        auto f = exeDir.getChildFile (name);
        if (f.existsAsFile())
            return f;
    }

   #if JUCE_MAC
    // App bundle: Contents/MacOS/LiveNT -> Contents/Resources/ffmpeg.
    const auto resources = exeDir.getSiblingFile ("Resources");
   #if defined(__x86_64__)
    auto intelFfmpeg = resources.getChildFile ("ffmpeg-x86_64");
    if (intelFfmpeg.existsAsFile())
        return intelFfmpeg;
   #endif
    for (const auto& name : { juce::String ("ffmpeg"), juce::String ("fmep") })
    {
        auto f = resources.getChildFile (name);
        if (f.existsAsFile())
            return f;
    }

    // Tien cho may dev/khach da cai FFmpeg bang Homebrew. Ban thuong mai nen
    // bundle binary da duoc cap phep/phu hop cua rieng minh vao Resources.
    for (const auto& path : { juce::String ("/opt/homebrew/bin/ffmpeg"),
                              juce::String ("/usr/local/bin/ffmpeg") })
    {
        juce::File f (path);
        if (f.existsAsFile())
            return f;
    }
   #endif

    return {};
}

void MainComponent::finishTimelineExport()
{
    const auto sourceWav = timelineExportTempWav;
    timelineExportActive = false;

    if (! sourceWav.existsAsFile())
    {
        endTimelineExportUi();
        livent::alert (livent::vn ("Xuất thất bại"),
                       livent::vn ("Không tìm thấy file render WAV tạm."),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    timelineExportFinishing      = true;
    timelineExportFinishProgress = std::make_shared<std::atomic<double>> (0.0);
    timelineExportFinishError    = std::make_shared<juce::String>();
    timelineExportFinishDone     = std::make_shared<std::atomic<bool>> (false);

    livent::exporting::FinishJob job;
    timelineExportCommitGate=std::make_shared<livent::exporting::CommitGate>();
    job.commitGate=timelineExportCommitGate;
    job.source      = sourceWav;
    job.destination = timelineExportDestination;
    job.settings    = timelineExportSettings;
    job.ffmpeg      = findFfmpegExecutable();

    statusLabel.setText (livent::vn ("ĐANG HOÀN THIỆN FILE XUẤT..."), juce::dontSendNotification);

    auto cancel   = timelineExportCancel;
    auto progress = timelineExportFinishProgress;
    auto error    = timelineExportFinishError;
    auto doneFlag = timelineExportFinishDone;

    std::thread ([job, cancel, progress, error, doneFlag]
    {
        *error = livent::exporting::finishExport (job, *cancel, *progress);
        doneFlag->store (true);
    }).detach();

    pollExportFinishing();
}

void MainComponent::pollExportFinishing()
{
    if(exportProgressUi!=nullptr && timelineExportCommitGate)exportProgressUi->setCommitting(timelineExportCommitGate->state.load()>=2);
    if (! timelineExportFinishing || timelineExportFinishDone == nullptr)
        return;

    const double p = timelineExportFinishProgress != nullptr ? timelineExportFinishProgress->load() : 0.0;

    if (exportProgressUi != nullptr)
    {
        const auto& s = timelineExportSettings;
        juce::String what = s.type == livent::exporting::FileType::mp3
                              ? livent::vn ("Bước 2/2 - Mã hóa MP3 ") + juce::String (s.mp3Kbps) + " kbps"
                          : s.type == livent::exporting::FileType::flac
                              ? livent::vn ("Bước 2/2 - Ghi FLAC")
                              : livent::vn ("Bước 2/2 - Ghi WAV ") + juce::String (s.bitDepth) + " bit";
        exportProgressUi->setState (what, 0.85 + 0.15 * p, -1.0);
    }

    if (! timelineExportFinishDone->load())
    {
        juce::Timer::callAfterDelay (100, [safeThis = juce::Component::SafePointer<MainComponent> (this)]
        {
            if (safeThis != nullptr)
                safeThis->pollExportFinishing();
        });
        return;
    }

    timelineExportFinishing = false;
    const auto err  = timelineExportFinishError != nullptr ? *timelineExportFinishError : juce::String();
    const auto dest = timelineExportDestination;
    const auto temp = timelineExportTempWav;
    endTimelineExportUi();

    if (err == "cancel")
    {
        temp.deleteFile();
        statusLabel.setText (livent::vn ("ĐÃ HỦY XUẤT"), juce::dontSendNotification);
        return;
    }

    if (err.isNotEmpty())
    {
        livent::alert (livent::vn ("Xuất thất bại"),
                       err + livent::vn ("\n\nBản render tạm vẫn còn tại:\n") + temp.getFullPathName(),
                       juce::MessageBoxIconType::WarningIcon);
        return;
    }

    temp.deleteFile();
    statusLabel.setText (livent::vn ("ĐÃ XUẤT: ") + dest.getFileName(), juce::dontSendNotification);

    if (timelineExportSettings.openFolder)
        dest.revealToUser();
}

//=============================================================================
void MainComponent::warnAboutMissingPlugins()
{
    /*  Mo du an cua may khac, hoac vua go mot plugin ra khoi may. Cac o insert
        do gio la O GIU CHO (xem PluginChain::addMissingPlaceholder).

        11j: gop ca ba loai canh bao (thieu plugin / mo nham plugin / khac phien ban)
        vao MOT bang gon co cuon - xem MissingPluginsDialog.h. Ban cu bung toi da ba hop
        thoai chu dai, project nhieu plugin thieu thi cao qua man hinh.  */
    std::vector<livent::missingplugins::TrackInput> inputs;

    for (int i = 0; i < mixer.getNumTracks(); ++i)
    {
        if (auto* t = mixer.getTrack (i))
        {
            auto& chain = t->getInserts();
            livent::missingplugins::TrackInput in;
            in.track = t->getName();
            in.missingSlots = chain.getMissingPluginSlots();
            for (int slot = 0; slot < PluginChain::maxSlots; ++slot)
                if (! chain.isMissing (slot))
                    if (const auto name = chain.getPluginName (slot); name.isNotEmpty())
                        in.loadedSlots.emplace_back (slot, name);
            in.loadWarnings = chain.getLoadWarnings();          // nap NHAM plugin khac - xem PluginChain::setState()
            in.restoreWarnings = chain.getRestoreWarnings();    // HOTFIX18: co VST, chi state/preset cu khong doc duoc
            if (! in.missingSlots.empty() || ! in.loadWarnings.isEmpty() || ! in.restoreWarnings.isEmpty())
                inputs.push_back (std::move (in));
        }
    }

    auto rows = livent::missingplugins::buildRows (inputs, projectPluginLoadFailures);
    if (rows.empty())
        return;

    juce::Component::SafePointer<MainComponent> safeThis (this);
    auto* content = new livent::MissingPluginsPanel (rows, [safeThis]
    {
        if (safeThis != nullptr)
            safeThis->openPluginScanner();
    });

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (content);
    o.dialogTitle = livent::MissingPluginsPanel::titleFor (rows);
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = false;
    livent::launchDialog (o, this);
}

//=============================================================================
void MainComponent::openLatencyDialog()
{
    juce::Component::SafePointer<MainComponent> safeThis (this);
    auto* content = new livent::LatencyPanel (
        mixer, loopbackMeter,
        [safeThis]() -> double
        {
            if (safeThis == nullptr) return 0.0;
            if (auto* d = safeThis->deviceManager.getCurrentAudioDevice())
                return (double) (d->getInputLatencyInSamples() + d->getOutputLatencyInSamples());
            return 0.0;
        },
        [safeThis]() -> double
        {
            if (safeThis == nullptr) return 0.0;
            if (auto* d = safeThis->deviceManager.getCurrentAudioDevice())
                return d->getCurrentSampleRate();
            return 0.0;
        },
        recordExtraMs,
        [safeThis] (double ms)
        {
            if (safeThis == nullptr) return;
            safeThis->recordExtraMs = ms;
            safeThis->mixer.setTimelineLatencyCompensation (true, ms);
            saveRecordExtraMsPref (ms);
            livent::stabilityLog ("PREF record-extra-ms", juce::String (ms, 2));
        });

    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (content);
    o.dialogTitle = livent::vn ("Bù trễ thu âm");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = false;
    livent::bringDialogToFront (livent::launchDialog (o));
}

//=============================================================================
void MainComponent::updateStatusText()
{
    if (audioSettingsProcess != nullptr && audioSettingsProcess->isRunning())
    {
        statusLabel.setText (livent::vn ("Đang cài đặt soundcard ở cửa sổ an toàn..."),
                             juce::dontSendNotification);
        return;
    }

    auto* device = deviceManager.getCurrentAudioDevice();

    if (device == nullptr)
    {
        statusLabel.setText (livent::vn ("Chưa mở được card. Bấm \"Cài đặt soundcard\"."),
                             juce::dontSendNotification);
        return;
    }

    const double sr = device->getCurrentSampleRate();
    const int    bs = device->getCurrentBufferSizeSamples();

    const double latency = sr > 0.0
        ? (device->getInputLatencyInSamples() + device->getOutputLatencyInSamples()) / sr * 1000.0
        : 0.0;

    /*  MOC 66: Tinh gop y - bao mau khi CPU sap qua tai.

        deviceManager.getCpuUsage() KHONG PHAI % CPU toan may nhu Task
        Manager hien - no chi do "% thoi gian rieng cua 1 khoi am thanh da
        dung het" so voi thoi gian cho phep (VD buffer 512 mau o 44100Hz thi
        moi khoi co ~11.6ms de xu ly xong; dung het 3ms trong so do thi day
        bao 26%). Task Manager cong CA moi luong (giao dien, luong dung thu,
        luong do tone...) roi chia cho so nhan CPU toan may - hai con so do
        LUONG thu khac nhau tu dau, khong phai loi tinh sai.

        Day la gia tri TRUNG BINH cua callback theo JUCE, khong phai thong ke
        block xau nhat. Dong ho co the duoi 100% ma van co block qua han,
        hoac driver bi tre truoc khi callback bat dau. Bao vang tu 80% va
        dung phep do 10 giay de kiem chung block qua han/thieu file/bridge. */
    const double cpuFraction = deviceManager.getCpuUsage();

    juce::String txt;
    txt << device->getName() << "   |   " << juce::String (sr, 0) << livent::vn (" Hz   |   buffer ") << bs
        << livent::vn ("   |   trễ ") << juce::String (latency, 2) << livent::vn (" ms   |   ")
        << device->getActiveInputChannels().countNumberOfSetBits() << livent::vn (" đường vào   |   ")
        << mixer.getNumTracks() << livent::vn (" track");

    /*  Do tre do VST (plugin dang BAT) cong them tren duong ra tai nghe. Plugin
        bypass khong tinh. O che do hat live, nhac co VST tre rieng thi bao ra
        de biet nhac nghe tre bao nhieu (thu am da tu bu).  */
    if (sr > 0.0)
    {
        const double vstMs = 1000.0 * (double) mixer.getGraphLatencySamples() / sr;
        const double musicMs = 1000.0 * (double) mixer.getMusicLatencySamples() / sr;
        if (vstMs >= 0.05)
            txt << livent::vn ("   |   VST trễ ") << juce::String (vstMs, 1) << " ms";
        if (mixer.isLowLatencyLive() && musicMs >= 0.05)
            txt << livent::vn ("   |   nhạc trễ ") << juce::String (musicMs, 1) << livent::vn (" ms (thu đã bù)");
        /*  13/10: "Tai nghe giong" = bao lau sau khi anh phat am thi nghe lai chinh minh (card vao + ra + plugin tren
            duong giong). Dung de biet cam giac "tre" co phai do plugin khong. Chi hien khi co mic dang nghe truc tiep.  */
        const int voiceSamples = mixer.getVoiceMonitorLatencySamples();
        if (voiceSamples >= 0)
            txt << livent::vn ("   |   tai nghe giọng ") << juce::String (latency + 1000.0 * (double) voiceSamples / sr, 1) << " ms";
    }

    cpuLabel.setText ("CPU " + juce::String (cpuFraction * 100.0, 1) + "%", juce::dontSendNotification);
    cpuLabel.setColour (juce::Label::textColourId,
                        cpuFraction >= 0.95 ? Col::red
                                            : (cpuFraction >= 0.8 ? Col::amber : Col::textDim));

    if (cpuFraction >= 0.95)
        txt << livent::vn ("  — QUÁ TẢI, dễ rớt tiếng!");
    else if (cpuFraction >= 0.8)
        txt << livent::vn ("  — sắp quá tải");

    if (pluginWindows.isPerformanceMode())
        txt << livent::vn ("   |   CHẾ ĐỘ ĐIỆN");
    if (mixer.isLiveMode())
        txt << livent::vn ("   |   CHẾ ĐỘ LIVE (đã tắt thu âm)");   // 14/10

    /*  11g A2: dang PHAT timeline ma track co ban thu van bat Loa -> track do dang nghe
        mic truc tiep, ban thu khong ra tieng. Chi nhac mot dong, khong doi hanh vi.  */
    bool liveOverTakes = false;
    if (mixer.isTimelinePlaying())
    {
        const auto names = mixer.getTracksHearingLiveOverClips();
        if (! names.isEmpty())
        {
            liveOverTakes = true;
            txt << livent::vn ("   |   ĐANG BẬT LOA: ") << names.joinIntoString (", ")
                << livent::vn (" — đang nghe mic trực tiếp, tắt Loa để nghe bản thu");
        }
    }

    /*  Dang quet nen thi bao o day, de anh biet vi sao danh sach plugin con
        thieu vai cai - chu khong tuong app bo sot.  */
    if (startupScanner != nullptr && startupScanner->isThreadRunning())
        txt << "   |   " << startupScanner->getProgress();

    if (loadingPluginName.isNotEmpty())
    {
        if (projectLoadInProgress)
        {
            const int total = (int) projectPluginLoadJobs.size();
            const int current = juce::jlimit (1, juce::jmax (1, total), projectPluginLoadDone + 1);
            txt << livent::vn ("   |   ĐANG MỞ DỰ ÁN ")
                << current << "/" << total << " - " << loadingPluginName << " ...";
        }
        else
        {
            txt << livent::vn ("   |   ĐANG NẠP: ") << loadingPluginName << " ...";
        }
    }

    statusLabel.setText (txt, juce::dontSendNotification);

    statusLabel.setColour (juce::Label::textColourId,
                            cpuFraction >= 0.95 ? Col::red
                                                 : ((cpuFraction >= 0.8 || liveOverTakes) ? Col::amber : Col::textDim));

    // 07/10 (mau C): thong so card binh thuong -> an khoi thanh trang thai, hien o
    // tooltip CPU. Qua tai / dang nap / dang quet van hien chu thay cho ten bai.
    cpuLabel.setTooltip (txt);
    const bool routine = cpuFraction < 0.8 && loadingPluginName.isEmpty() && ! liveOverTakes
                      && ! (startupScanner != nullptr && startupScanner->isThreadRunning());
    lastRoutineStatus = routine ? txt : juce::String();
    if (statusBarModern() && statusAlertShown != statusHasAlert())
        resized();
}

//=============================================================================
//  AM THANH
//=============================================================================
void MainComponent::prepareToPlay (int samplesPerBlockExpected, double sampleRate)
{
    diagnosticTicksPerSample = sampleRate > 0.0
        ? (double) juce::Time::getHighResolutionTicksPerSecond() / sampleRate : 0.0;
    inputCopy.setSize (maxHardwareInputs, juce::jmax (64, samplesPerBlockExpected), false, true, true);

    /*  PHAI xoa sach. setSize khong bao dam noi dung - vung nho cu con rac,
        va rac o day chinh la du lieu buffer cu cua JUCE (buffer dung chung
        vao/ra) -> track nao tro nham kenh se doc phai TIENG LOA, thanh hu.  */
    inputCopy.clear();

    // Card that su bat bao nhieu duong vao? Chi tung ay kenh la co that.
    activeInputChannels = 0;

    if (auto* dev = deviceManager.getCurrentAudioDevice())
        activeInputChannels = juce::jmin (maxHardwareInputs, dev->getActiveInputChannels()
                                                                  .countNumberOfSetBits());

    mixer.prepare (sampleRate, samplesPerBlockExpected);
    loopbackMeter.prepare (sampleRate);

    // 07/10: tre vao/ra cua card -> bu cho track MIC luc thu (giong hat khop nhac)
    if (auto* dev = deviceManager.getCurrentAudioDevice())
        mixer.setTimelineRecordLatency (dev->getInputLatencyInSamples(), dev->getOutputLatencyInSamples());

    /*  V4.5: khi doi driver / sample rate / buffer, JUCE dung va khoi dong
        lai audio device. Plugin/driver co the bat dau o mot gia tri khac 0,
        tao mot xung rat ngan nghe nhu "sẹt" du khong phai noise nen.

        Cho dau ra fade-in 30 ms sau MOI lan prepareToPlay(). 30 ms du ngan
        de khong cam thay mat tieng, nhung du dai de cat xung/pop luc card va
        chuoi VST vua duoc prepare lai. Khong cap phat bo nho tren audio thread. */
    outputFadeTotalSamples = juce::jmax (1, (int) std::lround (sampleRate * 0.030));
    outputFadeSamplesRemaining = outputFadeTotalSamples;

    /*  ==========  MOC 23: CHO NAY NGUY HIEM NHAT CA FILE  ==========

        prepareToPlay() chay o LUONG AM THANH, va no con duoc goi ca luc app
        DANG DONG (JUCE tat card am thanh trong qua trinh huy MainComponent).
        Viec xep hang callAsync o day nghia la: mot mau viec duoc gui sang
        luong giao dien de chay "lat nua" -- ma "lat nua" thi MainComponent co
        the da bi huy xong roi.

        SafePointer tu bien thanh nullptr khi Component bi huy, nen mau viec
        do se lang le bi bo qua thay vi chay vao vung nho da chet.  */
    juce::Component::SafePointer<MainComponent> safeThis (this);

    juce::MessageManager::callAsync ([safeThis]
    {
        if (safeThis == nullptr)
            return;

        safeThis->updateStatusText();
        safeThis->inspector.rebuildRouting();
        safeThis->refitInspector();   // MOC 78
    });
}

void MainComponent::getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill)
{
    /*  CHONG SO CUC NHO (denormal).
        Duoi vang tat dan xuong den muc 0.000000000000001 thi CPU phai chuyen
        sang che do tinh so cuc nho, cham gap hang chuc lan -> may giat, tieng
        re dung luc anh vua ngung hat. Dong duoi day bao CPU: nho qua thi coi
        nhu 0 luon. Tai nguoi khong nghe duoc chenh lech do.
        Phai dat o DAU ham vi co nay gan theo tung luong.  */
    juce::ScopedNoDenormals noDenormals;
    const bool measuring = audioDiagnosticsActive.load (std::memory_order_relaxed);
    const auto started = measuring ? juce::Time::getHighResolutionTicks() : 0;

    auto* buffer = bufferToFill.buffer;
    const int start = bufferToFill.startSample;
    const int n     = bufferToFill.numSamples;

    if (buffer->getNumChannels() == 0 || n == 0)
        return;

    /*  Phai CHEP tin hieu vao ra cho khac truoc.
        JUCE dung chung mot buffer cho ca vao lan ra - neu mixer ghi ra truoc
        khi track kip doc thi track se nhan phai tieng loa thay vi tieng mic,
        thanh vong hu ngay ben trong phan mem. */
    const int numIn = juce::jmin (buffer->getNumChannels(),
                                  inputCopy.getNumChannels(),
                                  activeInputChannels);

    /* V5.8.7: JUCE/driver co the dua callback lon hon samplesPerBlockExpected.
       Khong ghi tran inputCopy/Track buffer: chia callback thanh cac khoi toi
       da bang buffer da prepare. Khong cap phat va khong resize tren audio thread. */
    const int maxN = inputCopy.getNumSamples();
    if (maxN <= 0) { bufferToFill.clearActiveBufferRegion(); return; }

    for (int done = 0; done < n; done += maxN)
    {
        const int len = juce::jmin (maxN, n - done);

        for (int ch = 0; ch < numIn; ++ch)
            inputCopy.copyFrom (ch, 0, *buffer, ch, start + done, len);

        /* Dua xuong mixer mot view chi gom SO KENH VAO CO THAT. View nay
           bat dau tai 0, vi the Mixer/Track cung doc hardwareInput tu 0. */
        float* inPtrs[maxHardwareInputs] = {};
        for (int ch = 0; ch < numIn; ++ch)
            inPtrs[ch] = inputCopy.getWritePointer (ch);

        juce::AudioBuffer<float> inputView (inPtrs, numIn, len);
        mixer.processBlock (inputView, *buffer, start + done, len);

        /*  13/10: DO TRE CARD. Dang do thi dau ra mixer bi thay bang xung do (khong lan nhac), tieng vao la
            tieng THO tu card (inputCopy chua bi mixer dong toi). Binh thuong chi ton 1 phep doc atomic.  */
        if (loopbackMeter.wantsAudio())
        {
            const float* inConst[maxHardwareInputs] = {};
            for (int ch = 0; ch < numIn; ++ch)
                inConst[ch] = inputCopy.getReadPointer (ch);
            float* outPtrs[maxHardwareInputs] = {};
            const int numOut = juce::jmin (maxHardwareInputs, buffer->getNumChannels());
            for (int ch = 0; ch < numOut; ++ch)
                outPtrs[ch] = buffer->getWritePointer (ch, start + done);
            loopbackMeter.process (inConst, numIn, outPtrs, numOut, len);
        }
    }

    /*  V4.5: fade-in chong pop sau khi doi/cai lai soundcard.
        Chi sua DAU RA sau khi mixer da xu ly xong; inputCopy hoan toan khong
        bi dong toi nen plugin van nhan dung muc mic/nhac. */
    if (outputFadeSamplesRemaining > 0 && outputFadeTotalSamples > 0)
    {
        const int before = outputFadeSamplesRemaining;
        const int fadeSamples = juce::jmin (n, before);

        const float g0 = 1.0f - (float) before / (float) outputFadeTotalSamples;
        const float g1 = 1.0f - (float) (before - fadeSamples) / (float) outputFadeTotalSamples;

        for (int ch = 0; ch < buffer->getNumChannels(); ++ch)
            buffer->applyGainRamp (ch, start, fadeSamples,
                                   juce::jlimit (0.0f, 1.0f, g0),
                                   juce::jlimit (0.0f, 1.0f, g1));

        outputFadeSamplesRemaining -= fadeSamples;
    }

    if (measuring && diagnosticTicksPerSample > 0.0)
    {
        const auto elapsed = juce::Time::getHighResolutionTicks() - started;
        const double budget = (double) n * diagnosticTicksPerSample;
        const int peakPermille = juce::roundToInt (juce::jlimit (
            0.0, 20000.0, 1000.0 * (double) elapsed / budget));
        diagnosticCallbackCount.fetch_add (1, std::memory_order_relaxed);
        if ((double) elapsed > budget)
            diagnosticOverBudgetCount.fetch_add (1, std::memory_order_relaxed);

        auto prior = diagnosticPeakPermille.load (std::memory_order_relaxed);
        while (peakPermille > prior && ! diagnosticPeakPermille.compare_exchange_weak (
                   prior, peakPermille, std::memory_order_relaxed)) {}
    }
}

void MainComponent::releaseResources()
{
    mixer.release();
}

//=============================================================================
void MainComponent::paint (juce::Graphics& g)
{
    const float scale = g.getInternalContext().getPhysicalPixelScaleFactor();
    const int pw = juce::jmax (1, juce::roundToInt ((float) getWidth()  * scale));
    const int ph = juce::jmax (1, juce::roundToInt ((float) getHeight() * scale));
    const bool rackWin = livent::rack::active();
    const juce::Colour winBgColour = Col::bg;           // 12o: nen cua so = nen chu de (chu de da dong bo ca bo kieu)
    const bool winBgGalaxy = Col::galaxyEnabled;
    const juce::Colour barCol = livent::rack::chromePanel (Col::panel);

    if (const int rackKey = livent::rack::generation() * 100 + livent::rack::index(); rackChromeApplied != rackKey)
    {
        rackChromeApplied = rackKey;   // chi hen 1 lan moi lan doi kieu (gom ca luc mo app)
        backgroundCache = juce::Image();   // 12w: nen cua so cua kieu moi doi theo kieu / mau -> ve lai anh nen 1 lan
        juce::Component::SafePointer<MainComponent> safeChrome (this);
        juce::MessageManager::callAsync ([safeChrome] { if (safeChrome != nullptr) safeChrome->applyRackChrome(); });
    }

    if (! backgroundCache.isValid() || backgroundCacheScale != scale
        || backgroundCache.getWidth() != pw || backgroundCache.getHeight() != ph
        || backgroundCacheColour != winBgColour || backgroundCacheGalaxy != winBgGalaxy)
    {
        backgroundCacheScale = scale;
        backgroundCacheColour = winBgColour;
        backgroundCacheGalaxy = winBgGalaxy;
        backgroundCache = juce::Image (juce::Image::RGB, pw, ph, false);
        juce::Graphics ig (backgroundCache);
        ig.addTransform (juce::AffineTransform::scale (scale));
        if (! livent::rack::paintWindowBackground (ig, getLocalBounds().toFloat()))   // 12w: kieu Do cung / Kinh / Trang su
            Col::paintBackground (ig, getLocalBounds().toFloat());
    }

    g.drawImage (backgroundCache, getLocalBounds().toFloat());

    // 06/10: thanh thu gon - chi ve logo ben trai, phan con lai la cac o.
    if (compactUiActive())
    {
        g.setColour (Col::line);
        g.drawRect (getLocalBounds(), 1);
        workspace::drawSharpLogo (g, logoImage, compactLogoScaled, compactLogoArea.toFloat());
        return;
    }

    // Use the same header height for painting and layout, with room for a
    // 34 px logo and natural-width brand text (two lines in narrow windows).
    const bool topAsBlock = livent::branding::equalSmallBlocks && ! verticalControlLayout;
    const int topMenuH = titleChromeHeight (verticalControlLayout);

    if (topMenuH > 0)
    {
        if (topAsBlock)
        {
            // 01/10 mau 2: thanh tren la mot khoi bo goc giong khoi Tone / nut.
            const auto f = topBlockBounds (getWidth()).toFloat().reduced (0.5f);
            if (rackWin) livent::rack::drawPlate (g, f, 8.0f, false);
            else
            {
                g.setColour (Col::panel);
                g.fillRoundedRectangle (f, 8.0f);
                g.setColour (Col::line);
                g.drawRoundedRectangle (f, 8.0f, 1.0f);
            }
        }
        else if (! livent::rack::paintChromeBar (g, getLocalBounds().removeFromTop (topMenuH).toFloat(), true))   // 12w
        {
            g.setColour (barCol);
            g.fillRect (getLocalBounds().removeFromTop (topMenuH));
            g.setColour (rackWin ? barCol.darker (0.5f) : Col::line);
            g.drawHorizontalLine (topMenuH - 1, 0.0f, (float) getWidth());
        }

        //  V6.0: logo ben trai chu Tep
        if (livent::rack::newStyle()) g.setOpacity (1.0f);   // 12w: nen thanh dau ve bang mau trong suot -> logo phai ve dac
        workspace::drawSharpLogo (g, logoImage, logoScaled, logoArea.toFloat());

        // 15/10: vach ngan nut thao tac | cum bieu tuong thanh tieu de
        if (! topCaptionDivider.isEmpty())
        {
            g.setColour (Col::line);
            g.fillRect (topCaptionDivider);
        }
    }

    const int footerY = getHeight() - statusBarHeight();
    if (livent::rack::paintChromeBar (g, juce::Rectangle<int> (0, footerY, getWidth(), statusBarHeight()).toFloat(), false))   // 12w
        return;
    if (statusBarModern())
    {
        g.setColour (barCol.darker (0.20f));
        g.fillRect (0, footerY, getWidth(), statusBarHeight());
    }
    g.setColour (Col::line.brighter (0.15f));
    g.drawHorizontalLine (footerY, 0.0f, (float) getWidth());

    // 06/10: man Tao / Mo du an tu ve (ProjectHub)
}


int MainComponent::menuBarNaturalWidth()
{
    auto names = getMenuBarNames();
    int w = 0;

    for (int i = 0; i < names.size(); ++i)
        w += getLookAndFeel().getMenuBarItemWidth (menuBar, i, names[i]);

    return w + 4;
}

void MainComponent::lookAndFeelChanged()
{
    // V6.1.3: cac Label nay tung gan mau cu bang setColour(), nen neu doi
    // dark -> light trong luc app dang mo chung se khong tu doi theo palette.
    projectNameLabel.setColour (juce::Label::textColourId, livent::rack::chromeText (Col::text));
    cpuLabel.setColour (juce::Label::textColourId, livent::rack::active() ? livent::rack::textDimOnPlate() : Col::textDim);
    statusLabel.setColour (juce::Label::textColourId, livent::rack::active() ? livent::rack::textDimOnPlate() : Col::textDim);

    for (auto* b : hubRecentButtons)
        if (b != nullptr)
        {
            b->setColour (juce::TextButton::buttonColourId, Col::panel2);
            b->setColour (juce::TextButton::textColourOffId, Col::text);
        }

    // HOTFIX9: các nút thao tác trên thanh đầu dùng đúng nền chính của DAW,
    // nên đổi theme sáng/tối không còn bốn ô trắng/chói tách khỏi thanh.
    juce::TextButton* themeButtons[] = { &topRecordButton, &topExportButton, &topLaughButton,
                                          &topSaveSongButton, &topSongListButton, &topYouTubeButton,
                                          &topFileButton, &topSettingsButton, &topLayoutButton, &topHelpButton };
    for (auto* b : themeButtons)
    {
        b->setColour (juce::TextButton::buttonColourId, livent::rack::chromePanel (Col::panel));
        b->setColour (juce::TextButton::textColourOffId, livent::rack::chromeText (Col::text));
        b->setColour (juce::TextButton::textColourOnId, Col::onAccent);
    }
    topBrandLabel.setColour (juce::Label::textColourId, livent::rack::chromeText (Col::text));

    repaint();
}

void MainComponent::mouseDown (const juce::MouseEvent& e)
{
    draggingWindow = false;

    // 06/10: thanh gon - chuot phai logo / cho trong = chon sat mep tren / duoi
    if (compactUiActive() && e.mods.isPopupMenu())
    {
        showCompactBarMenu();
        return;
    }

    // 06/10: thanh thu gon - nam LOGO de keo cua so (ca Win lan Mac)
    if (compactUiActive() && compactLogoArea.contains (e.getPosition()))
    {
        if (auto* top = getTopLevelComponent())
        {
            windowDragger.startDraggingComponent (top, e);
            draggingWindow = true;
        }
        return;
    }

   #if ! JUCE_MAC
    if (dragArea.contains (e.getPosition()) || logoArea.contains (e.getPosition()))
        if (auto* top = getTopLevelComponent())
        {
            //  Dang phong to thi khong keo (giong Windows)
            if (auto* w = dynamic_cast<juce::ResizableWindow*> (top))
                if (w->isFullScreen())
                    return;

            windowDragger.startDraggingComponent (top, e);
            draggingWindow = true;
        }
   #endif
}

void MainComponent::mouseDrag (const juce::MouseEvent& e)
{
    if (draggingWindow)
        if (auto* top = getTopLevelComponent())
        {
            windowDragger.dragComponent (top, e, nullptr);

            // 06/10: thanh gon dang "sat mep" -> chi truot ngang, van dinh mep
            if (compactUiActive() && compactDock != 0)
            {
                compactPos = top->getPosition();
                compactPosValid = true;
                placeCompactBar();
            }
        }
}

void MainComponent::mouseUp (const juce::MouseEvent&)
{
    if (draggingWindow && compactUiActive())
        if (auto* top = getTopLevelComponent())
        {
            compactPos = top->getPosition();
            compactPosValid = true;
            saveCompactPlace();
        }
    draggingWindow = false;
}

void MainComponent::mouseDoubleClick (const juce::MouseEvent& e)
{
    // The brand/logo is a drag handle, not a double-click maximise control.
    // Use the explicit window button; keep the user's current dimensions.
    juce::ignoreUnused(e);
}

void MainComponent::moved()
{
    if (tonePanel.isLaughPanelOpen())
    {
        const auto hostBounds = getTopLevelComponent() != nullptr
                              ? getTopLevelComponent()->getScreenBounds()
                              : getScreenBounds();
        tonePanel.repositionLaughPanel (hostBounds);
    }
}

void MainComponent::resized()
{
    auto area = getLocalBounds();
    helpOverlay.setBounds (getLocalBounds());   // 02/10: lop huong dan phu toan cua so
    // 15/10: Luu bai / DS bai len hang tren, Cai dat thanh anh, Gon thanh bieu tuong
    // tren thanh tieu de -> khong nut nao con dung kieu chu "chan trang" nua.
    for (auto* button : std::initializer_list<juce::TextButton*> { &topSaveSongButton, &topSongListButton, &topSettingsButton, &topHelpButton })
    {
        button->getProperties().set ("controlFooter", false);
        if (&button->getLookAndFeel() == &controlFooterLook) button->setLookAndFeel (nullptr);
    }

    if (compactUiActive())
    {
        layoutCompactBar();   // 06/10
        return;
    }
    compactExpandButton.setVisible (false);
    compactCloseButton.setVisible (false);

    titleLabel.setVisible (false);
    subtitleLabel.setVisible (false);

    {
        // V6.5.0: hai che do dung chung mot thanh thao tac.
        // Ngang: mot hang nhu cu. Doc: logo/ten o hang 1, 6 nut thao tac o hang 2.
        menuBar.setBounds (0, 0, 0, 0);

        const int titleBandH = titleChromeHeight (verticalControlLayout);   // chu thuong hieu to: +8
        auto topBand = area.removeFromTop (titleBandH).reduced (8, 4);
        if (livent::branding::equalSmallBlocks && ! verticalControlLayout)
            topBand = topBlockBounds (getWidth()).reduced (8, 6);   // nut cao 26 trong khoi 38
        refreshTopLayoutButton();   // V0.6.7.9: chu Ngang/Doc luon dung che do hien tai

        /*  15/10: MAU DA CHOT (ca Ngang lan Doc)
              Ngang: [logo] Ten ...... [Thu Am][Du an][Luu bai][DS bai] | [Doc][–][⌄][□][✕]
              Doc  : H1 [logo] Ten (dai thi tu co 2 dong) ....... [Ngang][–][⌄][□][✕]
                     H2 [Thu Am][Du an][Luu bai][DS bai]   (4 nut bang nhau)
            YouTube / Cuoi / Cai dat = 3 anh o goc phai thanh duoi (chua mo du an:
            nam cuoi hang nut vi thanh duoi kieu cu khong co cho).
            Mac: khong co – / ✕ (nut cua so cua macOS).  */
        const bool footerIcons = statusBarModern();
        const bool showFold    = projectOpen && livent::branding::foldArrowOnStatusBar;
        const bool showGon     = projectOpen;
        auto& fold = tonePanel.getStatusFoldButton();

        topRecordButton.setButtonText (livent::vn ("Thu Âm"));
        topFileButton.setButtonText (livent::vn ("Dự án"));
        topSaveSongButton.setButtonText (livent::vn ("Lưu bài"));
        topSongListButton.setButtonText (livent::vn ("DS bài"));
        topLaughButton.setButtonText ({});
        topYouTubeButton.setButtonText ({});
        topSettingsButton.setButtonText ({});
        topHelpButton.setButtonText ({});
        topExportButton.setBounds (0, 0, 0, 0);

        // Cum bieu tuong thanh tieu de, xep tu PHAI sang TRAI: ✕ □ ⌄ – [Doc/Ngang]
        auto placeCaptions = [&] (juce::Rectangle<int>& row, int capW)
        {
            auto take = [&row, capW] (juce::Component& c)
            {
                c.setBounds (row.removeFromRight (capW).withSizeKeepingCentre (capW, juce::jmin (capW, row.getHeight())));
            };
           #if ! JUCE_MAC
            take (closeAppButton);
           #else
            closeAppButton.setBounds (0, 0, 0, 0);
            minimiseAppButton.setBounds (0, 0, 0, 0);
           #endif
            if (showGon)  take (topHelpButton); else topHelpButton.setBounds (0, 0, 0, 0);
            if (showFold) { take (fold); fold.toFront (false); } else fold.setBounds ({});
           #if ! JUCE_MAC
            take (minimiseAppButton);
           #endif
            take (topLayoutButton);
        };

        if (verticalControlLayout)
        {
            auto row1 = topBand.removeFromTop (36);

            if constexpr (livent::branding::bigBrandTitle)
                row1.setLeft (row1.getX() - 5);   // 01/10: logo sat le trai hon (le 8 -> 3)
            logoArea = row1.removeFromLeft (34).withSizeKeepingCentre (34, 34);
            row1.removeFromLeft (livent::branding::bigBrandTitle ? 3 : 6);   // 01/10: chu ten sat logo hon

            placeCaptions (row1, 28);
            row1.removeFromRight (6);

            // Ten dai: BrandTitleLabel tu thu nho + xuong 2 dong (15/10).
            topBrandLabel.setBounds (row1);
            nudgeBrandLabel (topBrandLabel);
            topBrandLabel.setColour (juce::Label::textColourId, livent::rack::chromeText (Col::text));
            topBrandLabel.setFont (brandTitleFont (13.5f, 31.0f));
            topBrandLabel.setMinimumHorizontalScale (1.0f);
            dragArea = row1;

            constexpr int gap = 4;
            topBand.removeFromTop (4);
            auto row2 = topBand.removeFromTop (28);

            // Chua mo du an: thanh duoi kieu cu -> 3 anh nam cuoi hang nay.
            if (! footerIcons)
            {
                topSettingsButton.setBounds (row2.removeFromRight (30)); row2.removeFromRight (gap);
                topLaughButton.setBounds (row2.removeFromRight (30));    row2.removeFromRight (gap);
                topYouTubeButton.setBounds (row2.removeFromRight (30));  row2.removeFromRight (gap);
            }

            std::vector<juce::Component*> cols { &topRecordButton, &topFileButton };
            if (projectOpen) { cols.push_back (&topSaveSongButton); cols.push_back (&topSongListButton); }
            else             { topSaveSongButton.setBounds (0, 0, 0, 0); topSongListButton.setBounds (0, 0, 0, 0); }
            const int n = (int) cols.size();
            // Chua mo du an (man Hub rong): nut khong keo dai het hang.
            const int colW = juce::jmin (projectOpen ? 10000 : 110, (row2.getWidth() - gap * (n - 1)) / n);
            for (int i = 0; i < n; ++i)
            {
                cols[(size_t) i]->setBounds (projectOpen && i == n - 1 ? row2 : row2.removeFromLeft (colW));
                row2.removeFromLeft (gap);
            }
        }
        else
        {
            auto top = topBand;
            const bool compact = getWidth() < 820;

            if constexpr (livent::branding::equalSmallBlocks)
            {
                // 01/10: logo sat mep trai khoi, cach mep 4 px = bang cach tren/duoi.
                top.setLeft (topBlockBounds (getWidth()).getX() + 4);
                logoArea = top.removeFromLeft (34).withSizeKeepingCentre (34, 34);
            }
            else if constexpr (livent::branding::bigBrandTitle)
            {
                top.setLeft (top.getX() - 5);   // logo sat le trai hon
                logoArea = top.removeFromLeft (34);
            }
            else
                logoArea = top.removeFromLeft (34).withSizeKeepingCentre (34, 34);
            top.removeFromLeft (livent::branding::bigBrandTitle ? 3 : 6);   // 01/10: chu ten sat logo hon

            placeCaptions (top, compact ? 28 : 30);
            topCaptionDivider = top.removeFromRight (11).withSizeKeepingCentre (1, juce::jmin (20, top.getHeight()));

            const int gap = 4;

            // {nut, be rong}. 4 nut thao tac BANG NHAU; thieu cho thi co lai deu.
            struct Slot { juce::Component* c; int w; };
            std::vector<Slot> slots;
            const int eqW = compact ? 66 : 74;
            slots.push_back ({ &topRecordButton, eqW });
            slots.push_back ({ &topFileButton,   eqW });
            if (projectOpen)
            {
                slots.push_back ({ &topSaveSongButton, eqW });
                slots.push_back ({ &topSongListButton, eqW });
            }
            else
            {
                topSaveSongButton.setBounds (0, 0, 0, 0);
                topSongListButton.setBounds (0, 0, 0, 0);
            }
            if (! footerIcons)
            {
                slots.push_back ({ &topYouTubeButton,  30 });
                slots.push_back ({ &topLaughButton,    30 });
                slots.push_back ({ &topSettingsButton, 30 });
            }

            int wanted = gap * ((int) slots.size() - 1);
            for (auto& sl : slots) wanted += sl.w;

            constexpr int minBrandW = 120;
            const int availableForActions = juce::jmax (0, top.getWidth() - minBrandW - 8);
            const float squeeze = wanted > availableForActions && wanted > 0
                                ? (float) availableForActions / (float) wanted : 1.0f;

            int actionsW = 0;
            for (auto& sl : slots)
            {
                sl.w = juce::jmax (26, juce::roundToInt ((float) sl.w * squeeze));
                actionsW += sl.w;
            }
            actionsW += gap * ((int) slots.size() - 1);

            auto actions = top.removeFromRight (juce::jmin (actionsW, top.getWidth()));
            top.removeFromRight (6);

            for (size_t i = 0; i < slots.size(); ++i)
            {
                slots[i].c->setBounds (actions.removeFromLeft (slots[i].w)
                                           .withSizeKeepingCentre (slots[i].w, juce::jmin (30, actions.getHeight())));
                if (i + 1 < slots.size())
                    actions.removeFromLeft (gap);
            }

            // Ten thuong hieu lay phan con lai (hep thi tu xuong 2 dong / thu nho).
            const int brandMax = livent::branding::bigBrandTitle ? (compact ? 170 : 300)
                                                                 : (compact ? 220 : 360);
            const int brandW = juce::jmin (brandMax, top.getWidth());
            topBrandLabel.setBounds (top.removeFromLeft (brandW));
            nudgeBrandLabel (topBrandLabel);
            topBrandLabel.setColour (juce::Label::textColourId, livent::rack::chromeText (Col::text));
            topBrandLabel.setFont (brandTitleFont (18.0f,
                                                    livent::branding::equalSmallBlocks ? (compact ? 23.0f : 26.0f)
                                                                                       : (compact ? 27.0f : 31.0f)));
            topBrandLabel.setMinimumHorizontalScale (1.0f);
            top.removeFromLeft (8);
            // Keo cua so duoc o ca logo, chu ten va khoang trong ben canh.
            dragArea = topBrandLabel.getBounds().getUnion (top);

            // 01/10: chu thuong hieu to -> nut giu cao 26 px, can GIUA hang.
            if constexpr (livent::branding::bigBrandTitle)
                for (auto* c : { (juce::Component*) &topRecordButton, (juce::Component*) &topFileButton,
                                 (juce::Component*) &topSaveSongButton, (juce::Component*) &topSongListButton,
                                 (juce::Component*) &topLaughButton, (juce::Component*) &topYouTubeButton,
                                 (juce::Component*) &topSettingsButton })
                    if (! c->getBounds().isEmpty())
                        c->setBounds (c->getBounds().withSizeKeepingCentre (c->getWidth(), 26));
        }
        if (verticalControlLayout)
            topCaptionDivider = {};

        if (tonePanel.isLaughPanelOpen())
        {
            const auto hostBounds = getTopLevelComponent() != nullptr
                                  ? getTopLevelComponent()->getScreenBounds()
                                  : getScreenBounds();
            tonePanel.repositionLaughPanel (hostBounds);
        }
    }

    if (statusBarModern())
    {
        /*  [Tên bài / thời gian] [CPU] [Lưu bài] [Danh sách bài] [⚙] [Gọn]
            Thong so card (ASIO / Hz / buffer / tre...) -> re chuot vao CPU (va F4).
            Co canh bao (qua tai, mat soundcard, dang nap VST...) thi chu canh bao
            thay cho ten bai. Ten du an -> re chuot vao ten thuong hieu.          */
        const auto footer = workspace::controlFooterLayout (area.removeFromBottom (statusBarHeight()), true);
        auto statusArea = footer.information;
        projectNameLabel.setBounds ({});
        topBrandLabel.setTooltip (projectNameLabel.getText());
        // 15/10: 3 anh goc phai thanh duoi (YouTube · Cuoi · Cai dat).
        topYouTubeButton.setBounds (footer.youtube.withSizeKeepingCentre (footer.youtube.getWidth(), 28));
        topLaughButton.setBounds (footer.laugh.withSizeKeepingCentre (footer.laugh.getWidth(), 28));
        topSettingsButton.setBounds (footer.settings.withSizeKeepingCentre (footer.settings.getWidth(), 28));
        if (verticalControlLayout)
            cpuLabel.setBounds (statusArea.removeFromLeft (juce::jmin (90, statusArea.getWidth())));   // Doc: CPU ben trai
        else
            cpuLabel.setBounds (statusArea.removeFromRight (64));
        cpuLabel.setJustificationType (verticalControlLayout ? juce::Justification::centredLeft
                                                             : juce::Justification::centredRight);
        statusArea.removeFromRight (4);

        if (startupScanProgressBar.isVisible())
        {
            startupScanProgressBar.setBounds (statusArea.removeFromRight (juce::jmin (150, statusArea.getWidth() / 4)).reduced (0, 3));
            statusArea.removeFromRight (6);
        }
        if (projectLoadInProgress)
        {
            cancelProjectLoadButton.setVisible (true);
            cancelProjectLoadButton.setBounds (statusArea.removeFromRight (64));
            statusArea.removeFromRight (6);
        }
        else
            cancelProjectLoadButton.setVisible (false);

        // 15/10: mui ten thu/mo num da len thanh tieu de (⌄), xem phan topBand.
        statusLabelMaxRight = -1;

        statusAlertShown = statusHasAlert();
        if (statusAlertShown)
        {
            statusLabel.setBounds (statusArea);
            statusSong.setBounds ({});
            statusClock.setBounds ({});
        }
        else
        {
            statusLabel.setBounds ({});
            if (verticalControlLayout)
            {
                statusSong.setBounds ({}); statusClock.setBounds ({});
                statusArea = {};
            }
            statusClock.setBounds (statusArea.removeFromRight (juce::jmin (96, statusArea.getWidth() / 2)));
            statusArea.removeFromRight (4);
            statusSong.setBounds (statusArea);
        }
    }
    else
    {
        statusSong.setBounds ({});
        statusClock.setBounds ({});
        cpuLabel.setJustificationType (juce::Justification::centredRight);
        auto statusArea = area.removeFromBottom (20).reduced (10, 2);
        if (startupScanProgressBar.isVisible())
        {
            auto progressArea = statusArea.removeFromRight (juce::jmin (190, statusArea.getWidth() / 3));
            statusArea.removeFromRight (8);
            startupScanProgressBar.setBounds (progressArea);
        }

        //  V6.0: [thong tin card ...........] [ten du an] | [CPU]
        // 15/10: mui ten thu/mo hang num nam tren thanh tieu de.
        statusLabelMaxRight = -1;

        cpuLabel.setBounds (statusArea.removeFromRight (84));
        statusArea.removeFromRight (6);
        projectNameLabel.setBounds (statusArea.removeFromRight (juce::jmin (320, statusArea.getWidth() / 3)));
        statusArea.removeFromRight (8);

        if (projectLoadInProgress)
        {
            cancelProjectLoadButton.setVisible (true);
            cancelProjectLoadButton.setBounds (statusArea.removeFromRight (64));
            statusArea.removeFromRight (6);
        }
        else
        {
            cancelProjectLoadButton.setVisible (false);
        }

        if (statusLabelMaxRight > statusArea.getX())
            statusArea.setRight (juce::jmin (statusArea.getRight(), statusLabelMaxRight));
        statusLabel.setBounds (statusArea);
    }

    /*  MOC 96: khi chua co project thi noi dung chinh la HUB. Bang dieu
        khien chua ton tai ve mat su dung, nen dung tai day. */
    if (! projectOpen)
    {
        projectHub.setBounds (area);
        return;
    }

    if (! projectOpen)
    {
        auto hubArea = area.reduced (36, 28);
        const int cardW = juce::jmin (1040, hubArea.getWidth());
        const int cardH = juce::jmin (610, hubArea.getHeight());
        auto card = juce::Rectangle<int> (0, 0, cardW, cardH)
                        .withCentre (hubArea.getCentre())
                        .reduced (32, 28);

        card.removeFromTop (92);

        auto actionRow = card.removeFromTop (58);
        const int buttonGap = 16;
        const int buttonW = juce::jmin (300, juce::jmax (100, (actionRow.getWidth() - buttonGap) / 2));
        hubNewProjectButton.setBounds (actionRow.removeFromLeft (buttonW));
        actionRow.removeFromLeft (buttonGap);
        hubOpenProjectButton.setBounds (actionRow.removeFromLeft (buttonW));

        card.removeFromTop (72);

        int y = card.getY();
        for (auto* b : hubRecentButtons)
        {
            b->setBounds (card.getX(), y, card.getWidth(), 46);
            y += 54;
        }

        return;
    }

    /*  MOC 95: khong xep ban tron trong MainComponent nua. F3 chi duoc
        layoutWorkArea() xep khi cua so F2 dang mo. Day la lop chan cuoi cung
        de F3 khong the "dinh" vao Bang dieu khien. */

    /*  ==========  MOC 75: BANG DIEU KHIEN LA GIAO DIEN CHINH  ==========

        Nam NGANG tren cung phan con lai, chiem het be ngang cua so.

        Neu ca danh sach track LAN bang Insert/Send deu dang an (che do mac
        dinh "chi bang dieu khien") thi bang chiem TRON cho con lai - dung y
        anh: bang dieu khien la giao dien chinh, may thu kia moi la phu. Cho
        no cao co dinh roi de trong phan duoi thi nhin ra nhu app hong.  */
    /*  MOC 93: ba bang da chuyen sang cua so rieng, nen cua so CHINH gio luon
        o trang thai "chi con bang dieu khien" mot khi ban lam viec dang mo.
        Giu ca ve sau (! trackListVisible && ! inspectorVisible) de bo cuc cu
        van dung neu ban lam viec dang dong.  */
    /* MOC 96: cua so CHINH khong con chua track/Inspector/F3 trong bat ky
       trang thai nao. F2 la cua so rieng hoan toan. */
    const bool onlyControlPanel = true;

    if (onlyControlPanel)
    {
        /*  ==========  MOC 78: TON TRONG CHIEU CAO ANH DA KEO  ==========

            Truoc day cho nay lap day: tonePanel.setBounds (area). Nghia la o
            trang thai "chi con bang dieu khien", keo mep duoi cua bang khong
            doi duoc gi ca - lam xong mot lat resized() lai keo no ve full.

            Gio: keo roi thi dung dung con so do (getManualHeight); chua tung
            keo bao gio (= 0) thi moi lap day nhu cu. Cua so cung bam theo -
            xem updateWindowSizeForPanels().  */
        // Bo cuc doc co nhieu khoi xep theo chieu cao co dinh; khong lay
        // manualHeight cua bo cuc ngang cu de tranh cat mat cac nut o duoi.
        const int manual = verticalControlLayout ? 0 : tonePanel.getManualHeight();

        if (manual > 0)
            tonePanel.setBounds (area.removeFromTop (juce::jmin (manual, area.getHeight())));
        else
            tonePanel.setBounds (area);

        return;   // khong con gi de xep - danh sach track dang an
    }

    tonePanel.setBounds (area.removeFromTop (
        juce::jlimit (200, juce::jmax (220, area.getHeight() - 140),
                      tonePanel.getWantedHeight())));

    area.removeFromTop (6);

    /*  MOC 74: Inspector co the dang bi an. Luc do KHONG cat px nao ca -
        phan be ngang do doi thang sang danh sach track.  */
    if (inspectorVisible)
    {
        layoutInspector (area.removeFromLeft (
            juce::jlimit (180, juce::jmax (180, area.getWidth() - 260), inspectorWidth)));

        inspectorSplitter.setBounds (area.removeFromLeft (6));
    }

    //  MOC 71: khong con WaveLane de chia cot nua - danh sach track chiem
    //  het toan bo be ngang con lai.
    // 07/10 _F: thuoc thoi gian ngay tren danh sach track, thanh goi y ngay duoi
    timelineRuler.setVisible (true);
    timelineFooter.setVisible (true);
    timelineRuler.setBounds (area.removeFromTop (22));
    timelineFooter.setBounds (area.removeFromBottom (36));
    area.removeFromBottom (3);

    trackListViewport.setBounds (area);

    const int rowWidth = juce::jmax (260, trackListViewport.getWidth() - 12);
    const int timelineX = TrackRow::getTimelineStartX (rowWidth);
    trackWidthSplitter.setVisible (trackListVisible);
    trackWidthSplitter.setBounds (trackListViewport.getX() + timelineX - 3, timelineRuler.getY(), 6,
                                  juce::jmax (0, trackListViewport.getBottom() - timelineRuler.getY()));
    trackWidthSplitter.toFront (false);
    timelineRuler.setTimelineStartX (timelineX);
    timelineFooter.setTimelineStartX (timelineX);

    layoutTrackRows (rowWidth);
}

/*  ==========  MOC 93: XEP CAC DONG TRACK  ==========

    Truoc day doan nay nam thang trong resized(). Tach ra vi tu Moc 93 co HAI
    noi can goi: resized() (ban lam viec dang dong) va layoutWorkArea() (dang
    mo). Chep thanh hai ban la kieu loi kinh dien - sua mot ben, ben kia sai
    am tham (dung bai hoc getWantedHeight/resized o Moc 75).  */
void MainComponent::layoutTrackRows (int listWidth)
{
    /*  Xep tu tren xuong: gap tieu de thu muc thi dat no vao, va tu do tro di
        cac track thuoc nhom do bi giau neu thu muc dang thu gon.  */
    const int folderHeight = 22;

    /*  ==========  MOC 42: DONG TRACK KHONG KEO DAI HET  ==========

        Truoc day moi dong track keo dai het be ngang cua so. Cua so rong
        1600 px thi mot dong track cao 40 px dai 1600 px -- nhin ra mot vet
        dai ngoang, ma phan ben phai chang co gi ngoai khoang trong.

        Cubase (va moi ban thu khac) de danh sach track thanh mot COT HEP ben
        trai. Ly do khong phai tham my: mat nguoi doc theo cot de hon theo
        hang dai, va cac nut M/S/loa/chot do nam gan nhau thi tay di chuyen
        it hon -- dang hat thi tung centimet duong di cua chuot deu dang ke.

        MOC 45: khong chan cung 430 px nua - cot track gio KEO DUOC bang
        thanh chia, nen dong track cu dung het be ngang cot la dung.  */
    const int rowWidth = listWidth;

    int y = 0;

    /*  MOC 74: bang Do Tone khong con nam trong danh sach track nua (che do
        Ngang da bi bo) - no duoc dock rieng canh man hinh o dau resized().  */

    auto category = livent::grouping::category;
    for(auto* row:trackRows) row->setVisible(false);
    for(int group=0;group<3;++group)
    {
        bool open=true;
        if(group>0)
        {
            const juce::String key=group==1?"fx":"out";
            for(auto* folder:trackFolders)
                if(folder->getProperties()["trackGroup"].toString()==key)
                {folder->setBounds(0,y,juce::jmin(rowWidth,TrackRow::getTimelineStartX(rowWidth)),folderHeight); y+=folderHeight+2; open=folder->isOpen(); break;}
        }
        for(auto* row:trackRows)
        {
            auto type=row->getTrack().getType();
            if(category(type)!=group||type==Track::Type::Input||!open)continue;
            row->setVisible(true);
            const int height=row->getTrack().getRowHeight();
            row->setRowBounds({0,y,rowWidth,height}); y+=height;
        }
    }

    // V6.3.4: holder phai cao it nhat bang viewport, de nen luoi khong dung
    // lai o track cuoi ma tiep tuc xuong het Ban lam viec nhu Cubase.
    const int minCanvasHeight = juce::jmax (1, trackListViewport.getHeight());
    trackListHolder.setSize (listWidth, juce::jmax (minCanvasHeight, y + 8));
    trackListHolder.repaint();
}

//=============================================================================
//  YOUTUBE - cua so rieng, tien trinh rieng (LiveNT-YouTube)
//=============================================================================
void MainComponent::openYouTubeWindow()
{
    publishDawWindowForYouTube();
    juce::String error;
    if (! youtube.openOrBringToFront (error))
        livent::alert ("YouTube", error, juce::MessageBoxIconType::WarningIcon);
}

void MainComponent::showYouTubeMenu()
{
    const bool running = youtube.isRunning();
    const bool onTop = YouTubeLauncher::isAlwaysOnTop();

    /*  15/10: chon MO YOUTUBE BANG: cua so YouTube cua DAW / trinh duyet (co trong may).
        Cac muc chi danh cho cua so YouTube cua DAW se mo di khi dang dung trinh duyet.  */
    const bool dawMode = livent::youtube::useDawYouTube();
    const auto browserId = livent::external::loadBrowserChoice();
    const auto browsers = livent::external::installedBrowsers();

    juce::PopupMenu m;
    m.addSectionHeader (livent::vn ("MỞ YOUTUBE BẰNG"));
    m.addItem (20, livent::vn ("Cửa sổ YouTube của DAW"), true, dawMode);
    {
        juce::PopupMenu bm;
        for (int i = 0; i < browsers.size(); ++i)
            bm.addItem (30 + i, browsers[i].name, true, ! dawMode && browserId == browsers[i].id);
        if (! browsers.isEmpty())
            bm.addSeparator();
        bm.addItem (29, livent::vn ("Trình duyệt mặc định"), true,
                    ! dawMode && (browserId == "default" || ! [&] { for (auto& b : browsers) if (b.id == browserId) return true; return false; }()));
        m.addSubMenu (livent::vn ("Trình duyệt"), bm, true, nullptr, ! dawMode);
    }
    m.addSeparator();
    if (dawMode)
        m.addItem (1, running ? livent::vn ("Đưa cửa sổ YouTube lên trước")
                              : livent::vn ("Mở YouTube"));
    else
        m.addItem (21, livent::vn ("Mở YouTube trên ") + livent::external::browserDisplayName (browserId));
    m.addSeparator();
    m.addItem (2, livent::vn ("Ghim YouTube trên cùng"), dawMode, onTop);
   #if LIVENT_YOUTUBE_MAGNET
    m.addItem (4, livent::vn ("Hút dính YouTube vào DAW"), dawMode, livent::youtube::loadDockEnabled());
    // Vi tri co dinh (cung la cai dat trong Cai dat > YouTube).
    const auto sideH = livent::youtube::loadDockSideHorizontal();
    const auto sideV = livent::youtube::loadDockSideVertical();
    juce::PopupMenu sideMenu;
    sideMenu.addSectionHeader (livent::vn ("Khi DAW Ngang"));
    sideMenu.addItem (11, livent::vn ("Phía trên DAW"), true, sideH == "top");
    sideMenu.addItem (12, livent::vn ("Phía dưới DAW"), true, sideH == "bottom");
    sideMenu.addSectionHeader (livent::vn ("Khi DAW Dọc"));
    sideMenu.addItem (13, livent::vn ("Bên phải DAW"), true, sideV == "right");
    sideMenu.addItem (14, livent::vn ("Bên trái DAW"), true, sideV == "left");
    m.addSubMenu (livent::vn ("Vị trí YouTube"), sideMenu, dawMode);
   #endif
    {
        // 15/10: co chu trang YouTube (laptop man hinh nho). "Tu dong" = tu thu nho theo man hinh.
        const int zoomNow = livent::youtube::loadZoomPercent();
        juce::PopupMenu zm;
        zm.addItem (50, livent::vn ("Tự động (theo cỡ màn hình)"), true, zoomNow == 0);
        const int steps[] = { 70, 80, 90, 100, 110 };
        for (int i = 0; i < 5; ++i)
            zm.addItem (51 + i, juce::String (steps[i]) + "%", true, zoomNow == steps[i]);
        m.addSubMenu (livent::vn ("Cỡ chữ trang YouTube"), zm, dawMode);
    }
    m.addSeparator();
   #if JUCE_WINDOWS
    // May co card do hoa/driver loi: WebView2 ve ra man hinh den. Tat GPU cho
    // rieng cua so YouTube (video giai ma bang CPU, ton CPU hon mot chut).
    m.addItem (5, livent::vn ("Sửa YouTube bị đen màn hình (tắt GPU)"), true,
               livent::youtube::folder().getChildFile ("youtube-gpu-safe.txt")
                   .loadFileAsString().trim() == "1");
   #endif
   #if JUCE_WINDOWS
    m.addItem (6, livent::vn ("Thư mục tiện ích YouTube (bản thử)..."));
   #endif
    {
        // 12r: co cua so co san - khach khong quen keo chuot
        juce::PopupMenu sizes;
        const auto labels = livent::youtube::sizePresetLabels();
        const auto cur = livent::youtube::loadSizePreset();
        for (int i = 0; i < labels.size(); ++i)
            sizes.addItem (70 + i, labels[i], true, livent::youtube::sizePresetKeys()[i] == cur);
        m.addSubMenu (livent::vn ("Cỡ cửa sổ YouTube"), sizes);
    }
    m.addItem (3, livent::vn ("Đóng YouTube"), running);

    juce::StringArray browserIds;
    for (const auto& b : browsers) browserIds.add (b.id);

    juce::Component::SafePointer<MainComponent> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&topYouTubeButton),
        [safe, onTop, browserIds] (int r)
        {
            if (safe == nullptr)
                return;

            if (r == 20)      safe->setYouTubeSource (livent::youtube::Source::daw);
            else if (r == 21) safe->pressYouTubeButton();
            else if (r == 29 || (r >= 30 && r < 30 + browserIds.size()))
            {
                livent::external::saveBrowserChoice (r == 29 ? juce::String ("default") : browserIds[r - 30]);
                safe->setYouTubeSource (livent::youtube::Source::browser);
            }
            else if (r == 1) safe->openYouTubeWindow();
            else if (r == 2) safe->youtube.setAlwaysOnTop (! onTop);
            else if (r == 3) safe->youtube.close (false);
            else if (r == 6) livent::youtube::ensureExtensionsFolder().startAsProcess();
            else if (r == 5)
            {
                auto f = livent::youtube::folder().getChildFile ("youtube-gpu-safe.txt");
                const bool on = f.loadFileAsString().trim() != "1";
                f.replaceWithText (on ? "1" : "0");

                // Mo lai cua so YouTube de ap dung ngay.
                if (safe->youtube.isRunning())
                {
                    safe->youtube.close (true);
                    juce::Timer::callAfterDelay (600, [safe]
                    {
                        if (safe != nullptr)
                            safe->openYouTubeWindow();
                    });
                }
            }
            else if (r >= 70 && r < 70 + livent::youtube::sizePresetKeys().size())
                safe->setYouTubeSizePreset (livent::youtube::sizePresetKeys()[r - 70]);
            else if (r >= 50 && r <= 55)
                safe->setYouTubeZoomPercent (r == 50 ? 0 : 70 + (r - 51) * 10);
            else if (r >= 11 && r <= 14)
            {
                const char* sides[] = { "top", "bottom", "right", "left" };
                safe->setYouTubeDockSide (sides[r - 11]);
            }
            else if (r == 4)
            {
                const bool on = ! livent::youtube::loadDockEnabled();
                livent::youtube::saveDockEnabled (on);
                if (safe->youtube.isRunning())
                    livent::youtube::sendCommand (on ? "dock=1" : "dock=0");
            }
        });
}

//=============================================================================
//  15/10: NUT YOUTUBE / NUT CUOI (anh o goc phai thanh duoi)
//=============================================================================
void MainComponent::setYouTubeSizePreset (const juce::String& key)
{
    livent::youtube::saveSizePreset (key);
    if (youtube.isRunning() && key.isNotEmpty())
        livent::youtube::sendCommand ("size=" + key);   // cua so YouTube doi co ngay
}

void MainComponent::setYouTubeZoomPercent (int percent)
{
    livent::youtube::saveZoomPercent (percent);
    if (youtube.isRunning())
        livent::youtube::sendCommand ("zoom");     // cua so YouTube doi ngay, khong can mo lai
}

void MainComponent::pressYouTubeButton()
{
    if (livent::youtube::useDawYouTube())
    {
        openYouTubeWindow();
        return;
    }

    // Che do trinh duyet: mo trinh duyet da chon vao thang youtube.com.
    // BrowserWatcher van tu bat link bai -> do tong chay nhu thuong.
    // 12u: LiveNT nho trinh duyet nay de tat LiveNT thi dong theo.
    openYouTubeInBrowser (false);
}

void MainComponent::pressLaughButton()
{
    if (livent::external::laughUsesApp())
    {
        // Nut co clickingTogglesState -> tra ve dung trang thai bang tieng cuoi cua DAW.
        topLaughButton.setToggleState (tonePanel.isLaughPanelOpen(), juce::dontSendNotification);
        const auto app = livent::external::laughApp();
        if (livent::external::launchOrFocusApp (app))
            return;

        livent::confirm (livent::vn ("Chưa có app tiếng cười"),
                         app == juce::File() ? livent::vn ("Chưa chọn app tiếng cười ngoài.")
                                             : livent::vn ("Không tìm thấy:\n") + app.getFullPathName(),
                         livent::vn ("Chọn app..."), livent::vn ("Dùng bảng của DAW"),
                         [safe = juce::Component::SafePointer<MainComponent> (this)] (bool choose)
                         {
                             if (safe == nullptr) return;
                             if (choose) safe->chooseExternalLaughApp();
                             else        livent::external::setLaughUsesApp (false);
                         });
        return;
    }

    const auto hostBounds = getTopLevelComponent() != nullptr
                          ? getTopLevelComponent()->getScreenBounds()
                          : getScreenBounds();
    tonePanel.toggleLaughPanel (hostBounds);
}

void MainComponent::showLaughMenu()
{
    const bool useApp = livent::external::laughUsesApp();
    const auto app = livent::external::laughApp();
    const bool hasApp = app != juce::File() && app.exists();

    juce::PopupMenu m;
    m.addSectionHeader (livent::vn ("NÚT CƯỜI DÙNG"));
    m.addItem (1, livent::vn ("Bảng tiếng cười của DAW (mặc định)"), true, ! useApp);
    m.addItem (2, hasApp ? livent::vn ("App tiếng cười ngoài: ") + livent::external::appDisplayName (app)
                         : livent::vn ("App tiếng cười ngoài (chưa chọn)"),
               true, useApp && hasApp);
    m.addSeparator();
   #if JUCE_MAC
    m.addItem (3, livent::vn ("Chọn app tiếng cười ngoài (.app)..."));
   #else
    m.addItem (3, livent::vn ("Chọn app tiếng cười ngoài (.exe)..."));
   #endif
    m.addItem (4, livent::vn ("Mở bảng tiếng cười của DAW"));

    juce::Component::SafePointer<MainComponent> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&topLaughButton),
        [safe, hasApp] (int r)
        {
            if (safe == nullptr || r == 0) return;
            if (r == 1) livent::external::setLaughUsesApp (false);
            else if (r == 2)
            {
                if (hasApp) livent::external::setLaughUsesApp (true);
                else        safe->chooseExternalLaughApp();
            }
            else if (r == 3) safe->chooseExternalLaughApp();
            else if (r == 4)
            {
                const auto hostBounds = safe->getTopLevelComponent() != nullptr
                                      ? safe->getTopLevelComponent()->getScreenBounds()
                                      : safe->getScreenBounds();
                if (! safe->tonePanel.isLaughPanelOpen())
                    safe->tonePanel.toggleLaughPanel (hostBounds);
            }
        });
}

void MainComponent::chooseExternalLaughApp()
{
    auto start = livent::external::laughApp();
   #if JUCE_MAC
    const juce::String pattern = "*.app";
    if (start == juce::File()) start = juce::File ("/Applications");
   #else
    const juce::String pattern = "*.exe";
    if (start == juce::File())
        start = juce::File::getSpecialLocation (juce::File::globalApplicationsDirectory);
   #endif

    laughAppChooser = std::make_unique<juce::FileChooser> (livent::vn ("Chọn app tiếng cười"), start, pattern);
    juce::Component::SafePointer<MainComponent> safe (this);
    laughAppChooser->launchAsync (juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles
                                 #if JUCE_MAC
                                  | juce::FileBrowserComponent::canSelectDirectories
                                 #endif
                                  ,
        [safe] (const juce::FileChooser& fc)
        {
            if (safe == nullptr) return;
            const auto f = fc.getResult();
            if (f == juce::File() || ! f.exists()) return;
            livent::external::setLaughApp (f);
            livent::external::setLaughUsesApp (true);
            safe->topLaughButton.setTooltip (livent::vn ("Tiếng cười: ") + livent::external::appDisplayName (f)
                                             + livent::vn (" · chuột phải: đổi lựa chọn"));
        });
}

void MainComponent::applyYouTubeSource()
{
    const bool dawYouTube = livent::youtube::useDawYouTube();

    // Trinh duyet rieng: tat han cua so YouTube cua DAW de khong ton CPU/RAM.
    if (! dawYouTube && youtube.isRunning())
        youtube.close (false);

    youtube.setListeningForWindowCommands (dawYouTube);

    // 15/10: nut YouTube luon hien - che do trinh duyet thi bam = mo trinh duyet.
}

void MainComponent::setYouTubeSource (livent::youtube::Source source)
{
    const bool changed = livent::youtube::loadSource() != source;

    if (! livent::youtube::saveSource (source))
        livent::alert (livent::vn ("Không lưu được cài đặt"),
                       livent::vn ("Không ghi được lựa chọn nguồn YouTube vào thư mục cài đặt."));

    applyYouTubeSource();

    // Dong bang Cai dat de lan mo sau hai dong lua chon hien dung trang thai.
    juce::Component::SafePointer<MainComponent> safe (this);
    juce::MessageManager::callAsync ([safe, changed, source]
    {
        if (safe == nullptr)
            return;

        // 02/10: khong dong bang Cai dat - nut tron tu cap nhat.

        // Vua chuyen sang YouTube trong DAW: mo luon cua so cho khach.
        if (changed && source == livent::youtube::Source::daw)
            safe->openYouTubeWindow();
    });
}

//=============================================================================
//  LIEN HE - so dien thoai lay tu Source/AppBranding.h
//=============================================================================
void MainComponent::copyContactPhone()
{
    const auto phone = juce::String::fromUTF8 (livent::branding::contactPhone);
    if (phone.isEmpty())
        return;

    juce::SystemClipboard::copyTextToClipboard (phone.removeCharacters ("-. "));
    livent::alert (juce::String::fromUTF8 (livent::branding::contactTitle),
                   phone + livent::vn ("\n\nĐã chép số vào bộ nhớ tạm - dán vào Zalo hoặc điện thoại."));
}

//=============================================================================
//  NUT TREN CUA SO YOUTUBE -> CHUC NANG CUA DAW
//=============================================================================
void MainComponent::handleYouTubeWindowCommand (const juce::String& cmd)
{
    // Nut Tone bai / Tone nhac / Nguon duoi video: lam ngay, KHONG keo DAW
    // len truoc (bam +/- lien tuc khong duoc nhay focus qua lai).
    if (cmd != "keymenu" && tonePanel.handleRemoteCommand (cmd))
        return;

    // Dua DAW len truoc de menu / cua so danh sach khong bi YouTube che.
    // (YouTube da cho phep DAW gianh quyen truoc khi gui lenh.)
    if (auto* top = getTopLevelComponent())
    {
        if (auto* w = dynamic_cast<juce::ResizableWindow*> (top))
            if (w->isMinimised())
                w->setMinimised (false);
        top->toFront (true);
    }
   #if JUCE_MAC
    juce::Process::makeForegroundProcess();
   #endif

    juce::Component::SafePointer<MainComponent> safe (this);
    juce::MessageManager::callAsync ([safe, cmd]
    {
        if (safe == nullptr)
            return;

        if (cmd == "keymenu")
            safe->tonePanel.handleRemoteCommand (cmd);    // menu chon Tone bai o con tro chuot
        else if (cmd == "savesong")
            safe->tonePanel.openSaveSongMenu (nullptr);   // hien ngay cho con tro chuot
        else if (cmd == "songlist")
            safe->tonePanel.openSongLibraryWindow();
    });
}

//=============================================================================
//  YouTube hut dinh: ghi handle cua so DAW de LiveNT-YouTube tu bam theo.
//  Chi ghi khi thay doi (timer 1 Hz), khong dung toi audio.
//=============================================================================
void MainComponent::publishDawWindowForYouTube()
{
    auto* top = getTopLevelComponent();
    auto* peer = top != nullptr ? top->getPeer() : nullptr;
    if (peer == nullptr)
        return;

    // layout=h / layout=v: YouTube dinh tren-duoi (Ngang) hoac trai-phai (Doc).
    // project=0: DAW dang o Hub (hoac chua ve cho cu) -> YouTube chua dat canh DAW.
    const juce::String layout = juce::String ("\nlayout=") + (verticalControlLayout ? "v" : "h")
                              + "\nproject=" + (projectOpen && projectWindowPlaced ? "1" : "0");
   #if JUCE_WINDOWS
    const auto text = "hwnd=" + juce::String ((juce::int64) (juce::pointer_sized_int) peer->getNativeHandle()) + layout;
   #elif JUCE_MAC
    const auto text = "wid=" + juce::String (livent::macapp::windowNumberForView (peer->getNativeHandle())) + layout;
   #else
    const juce::String text;
   #endif

    if (text.isEmpty() || text == lastPublishedDawWindow)
        return;

    if (livent::youtube::dawWindowFile().replaceWithText (text))
        lastPublishedDawWindow = text;
}

//=============================================================================
//  Vi tri co dinh cua YouTube: Ngang -> top/bottom, Doc -> right/left.
//=============================================================================
void MainComponent::setYouTubeDockSide (const juce::String& side)
{
    if (side == "top" || side == "bottom")
        livent::youtube::saveDockSideHorizontal (side);
    else
        livent::youtube::saveDockSideVertical (side);

    livent::youtube::saveDockEnabled (true);
    publishDawWindowForYouTube();

    if (youtube.isRunning())
        livent::youtube::sendCommand ("docknow");   // dinh lai ngay vao canh moi

    // 02/10: bang Cai dat giu nguyen, o chon Tren/Duoi tu cap nhat.
}


//=============================================================================
//  02/10: CHE DO HUONG DAN (nut "?")
//=============================================================================
//=============================================================================
// 06/10: THANH THU GON (mau 1B)
//=============================================================================
bool MainComponent::loadCompactPref()
{
    return PluginChain::getSettingsFolder().getChildFile ("compact-bar.txt").loadFileAsString().trim() == "1";
}

void MainComponent::saveCompactPref (bool on)
{
    PluginChain::getSettingsFolder().getChildFile ("compact-bar.txt").replaceWithText (on ? "1" : "0");
}

void MainComponent::toggleCompactMode()
{
    if (! projectOpen)
        return;

    auto* top = getTopLevelComponent();

    /*  06/10 (sua): truoc day thu / mo xong cua so hay "nhay" sat mep tren /
        duoi vi dung chung co che nho-cho-cu cua 7 num. Gio:
          - Giao dien day du nho cho RIENG (fullBoundsBeforeCompact).
          - Thanh gon nho cho RIENG (compactPos) hoac sat mep da chon
            (chuot phai logo: Sat mep duoi / Sat mep tren / Tu do).      */
    if (! compactMode && top != nullptr)
        fullBoundsBeforeCompact = top->getBounds();
    if (compactMode && top != nullptr)
    {
        compactPos = top->getPosition();
        compactPosValid = true;
        saveCompactPlace();
    }

    compactMode = ! compactMode;
    saveCompactPref (compactMode);
    setHelpMode (false);
    tonePanel.setCompactMode (compactMode);
    autoLiftActive = false;

    if (! compactMode)
        if (auto* dw = findParentComponentOfClass<juce::DocumentWindow>())
            dw->setResizeLimits (320, 110, 6000, 4000);   // gioi han cu (Main.cpp)

    resized();
    compactControlPanelWindow();   // gon: tu goi placeCompactBar()

    if (! compactMode && top != nullptr && ! fullBoundsBeforeCompact.isEmpty())
    {
        // ve dung cho cua giao dien day du, van nam trong man hinh
        auto b = top->getBounds().withPosition (fullBoundsBeforeCompact.getPosition());
        if (auto* d = juce::Desktop::getInstance().getDisplays().getDisplayForRect (b))
            b = b.constrainedWithin (d->userArea);
        top->setTopLeftPosition (b.getPosition());
        autoLiftActive = false;
    }
    repaint();
}

void MainComponent::loadCompactPlace()
{
    /*  07/10 _F: MAC DINH thanh gon SAT MEP DUOI, ngay tren taskbar. File cu
        (khong co chu "v2") luu "tu do" vi ban cu mac dinh tu do -> chuyen
        sang DUOI mot lan, giu vi tri ngang anh da keo.  */
    const auto t = PluginChain::getSettingsFolder().getChildFile ("compact-place.txt").loadFileAsString();
    auto parts = juce::StringArray::fromTokens (t, " ", "");
    const bool v2 = parts.size() > 0 && parts[0] == "v2";
    if (v2)
        parts.remove (0);

    compactDock = (v2 && parts.size() > 0) ? juce::jlimit (0, 2, parts[0].getIntValue()) : 2;
    compactPosValid = parts.size() >= 3;
    if (compactPosValid)
        compactPos = { parts[1].getIntValue(), parts[2].getIntValue() };
}

void MainComponent::saveCompactPlace()
{
    PluginChain::getSettingsFolder().getChildFile ("compact-place.txt")
        .replaceWithText ("v2 " + juce::String (compactDock) + " " + juce::String (compactPos.x) + " " + juce::String (compactPos.y));
}

void MainComponent::showGonDockMenu()
{
    if (! projectOpen)
        return;

    juce::PopupMenu m;
    m.addSectionHeader (livent::vn ("THU GỌN"));
    juce::PopupMenu::Item bottom (livent::vn ("Thu gọn · sát mép DƯỚI (trên taskbar)"));
    bottom.setID (1).setTicked (compactDock == 2);
    bottom.shortcutKeyDescription = "F8";
    m.addItem (bottom);
    m.addItem (2, livent::vn ("Thu gọn · sát mép TRÊN"), true, compactDock == 1);
    m.addItem (3, livent::vn ("Thu gọn · tự do (để đâu nhớ đó)"), true, compactDock == 0);

    juce::Component::SafePointer<MainComponent> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&topHelpButton),
        [safe] (int r)
        {
            if (safe == nullptr || r == 0)
                return;
            safe->compactDock = r == 1 ? 2 : (r == 2 ? 1 : 0);
            safe->saveCompactPlace();
            if (! safe->compactMode)
                safe->toggleCompactMode();
            else
                safe->placeCompactBar();
        });
}

void MainComponent::placeCompactBar()
{
    auto* top = getTopLevelComponent();
    if (top == nullptr || ! compactUiActive())
        return;

    auto b = top->getBounds();
    if (compactPosValid)
        b.setPosition (compactPos);
    else if (! fullBoundsBeforeCompact.isEmpty())
    {
        // lan dau thu gon: giao dien day du dang sat day -> thanh gon cung sat day
        b.setPosition (fullBoundsBeforeCompact.getPosition());
        if (auto* fd = juce::Desktop::getInstance().getDisplays().getDisplayForRect (fullBoundsBeforeCompact))
            if (fullBoundsBeforeCompact.getBottom() >= fd->userArea.getBottom() - 12)
                b.setY (fullBoundsBeforeCompact.getBottom() - b.getHeight());
    }

    const auto& displays = juce::Desktop::getInstance().getDisplays();
    auto* d = displays.getDisplayForRect (b);
    if (d == nullptr) d = displays.getDisplayForRect (top->getBounds());
    if (d == nullptr) d = displays.getPrimaryDisplay();
    if (d == nullptr) return;
    const auto work = d->userArea;

    if (compactDock == 1)      b.setY (work.getY());
    else if (compactDock == 2) b.setY (work.getBottom() - b.getHeight());
    b = b.constrainedWithin (work);

    if (b.getPosition() != top->getPosition())
        top->setTopLeftPosition (b.getPosition());
}

void MainComponent::showCompactBarMenu()
{
    juce::PopupMenu m;
    m.addSectionHeader (livent::vn ("Thanh gọn"));
    m.addItem (1, livent::vn ("Sát mép DƯỚI (ngay trên taskbar)"), true, compactDock == 2);
    m.addItem (2, livent::vn ("Sát mép TRÊN màn hình"), true, compactDock == 1);
    m.addItem (3, livent::vn ("Tự do (để đâu nhớ đó)"), true, compactDock == 0);
    m.addSeparator();
    m.addItem (4, livent::vn ("Mở lại giao diện đầy đủ  (F8)"));

    juce::Component::SafePointer<MainComponent> safe (this);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetScreenArea (
                         juce::Rectangle<int> (juce::Desktop::getMousePosition(), juce::Desktop::getMousePosition()).expanded (1)),
        [safe] (int r)
        {
            if (safe == nullptr || r == 0) return;
            if (r == 4) { safe->toggleCompactMode(); return; }
            safe->compactDock = r == 1 ? 2 : (r == 2 ? 1 : 0);
            if (auto* top = safe->getTopLevelComponent())
            {
                safe->compactPos = top->getPosition();
                safe->compactPosValid = true;
            }
            safe->placeCompactBar();
            if (auto* top = safe->getTopLevelComponent())
                safe->compactPos = top->getPosition();
            safe->saveCompactPlace();
        });
}

void MainComponent::layoutCompactBar()
{
    constexpr int pad = 7, logoW = 46;
    std::vector<juce::Component*> keep { &tonePanel, &topRecordButton, &topLaughButton,
                                         &compactExpandButton, &compactCloseButton, &helpOverlay };
    for (auto* c : getChildren())
        if (std::find (keep.begin(), keep.end(), c) == keep.end())
            c->setBounds ({});

    const int gridH = TonePanel::compactGridHeight();
    compactLogoArea = { pad, pad + (gridH - logoW) / 2, logoW, logoW };
    const juce::Point<int> grid (pad + logoW + 8, pad);
    tonePanel.setVisible (true);
    tonePanel.setBounds (grid.x, grid.y, TonePanel::compactGridWidth(), gridH);

    auto cell = [grid] (int row, int col) { return TonePanel::compactCell (row, col) + grid; };

    topRecordButton.setVisible (true);
    topRecordButton.setButtonText (livent::vn ("Thu"));
    topRecordButton.setBounds (cell (0, 0));
    topLaughButton.setButtonText (livent::vn ("Cười"));
    topLaughButton.setVisible (true);
    topLaughButton.setBounds (cell (0, 6));

    auto last = cell (0, 7);
    const int half = (last.getWidth() - 4) / 2;
    compactExpandButton.setVisible (true);
    compactCloseButton.setVisible (true);
    compactExpandButton.setBounds (last.removeFromLeft (half));
    last.removeFromLeft (4);
    compactCloseButton.setBounds (last);
    compactExpandButton.toFront (false);
    compactCloseButton.toFront (false);
    // 06/10: Thu / Cuoi nam TREN vung cua TonePanel -> phai dua len truoc,
    // khong thi TonePanel an mat cu bam (nut Cuoi tren thanh gon khong bam duoc).
    topRecordButton.toFront (false);
    topLaughButton.toFront (false);
}

//=============================================================================
// 06/10: TAM HA PHAN MEM (nhap key VST o chuong trinh rieng)
//=============================================================================
void MainComponent::lowerAllWindowsTemporarily (int seconds)
{
    if (windowsLowered)
    {
        restoreLoweredWindows();   // bam lan nua = noi lai ngay
        return;
    }

    windowsLowered = true;
    loweredWindows.clear();

    auto& desktop = juce::Desktop::getInstance();
    for (int i = 0; i < desktop.getNumComponents(); ++i)
    {
        auto* c = desktop.getComponent (i);
        if (c == nullptr || ! c->isShowing() || ! c->isAlwaysOnTop()
            || dynamic_cast<juce::TooltipWindow*> (c) != nullptr)
            continue;
        loweredWindows.emplace_back (c);
    }

    for (auto& p : loweredWindows)
        if (auto* c = p.getComponent())
        {
            c->setAlwaysOnTop (false);
           #if JUCE_WINDOWS
            // Day xuong DUOI CUNG de cua so chuong trinh kia lo ra ngay
            if (auto* peer = c->getPeer())
                SetWindowPos ((HWND) peer->getNativeHandle(), HWND_BOTTOM, 0, 0, 0, 0,
                              SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
           #endif
        }

    youtubeLowered = youtube.isRunning() && YouTubeLauncher::isAlwaysOnTop();
    if (youtubeLowered)
        livent::youtube::sendCommand ("temporarytop=0");

    tonePanel.showAutoKeyStatus (livent::vn ("Đã tạm hạ phần mềm ") + juce::String (seconds)
                                 + livent::vn (" giây để nhập key VST. Tệp > \"Cho phần mềm nổi lại ngay\" để nổi lại."));

    const int gen = ++lowerGeneration;
    juce::Component::SafePointer<MainComponent> safe (this);
    juce::Timer::callAfterDelay (juce::jmax (5, seconds) * 1000, [safe, gen]
    {
        if (safe != nullptr && safe->windowsLowered && safe->lowerGeneration == gen)
            safe->restoreLoweredWindows();
    });
}

void MainComponent::restoreLoweredWindows()
{
    if (! windowsLowered)
        return;
    windowsLowered = false;
    ++lowerGeneration;

    for (auto& p : loweredWindows)
        if (auto* c = p.getComponent())
            if (c->isShowing())
            {
                c->setAlwaysOnTop (true);
                c->toFront (false);
            }
    loweredWindows.clear();

    if (youtubeLowered && youtube.isRunning() && YouTubeLauncher::isAlwaysOnTop())
        livent::youtube::sendCommand ("temporarytop=1");
    youtubeLowered = false;

    tonePanel.showAutoKeyStatus (livent::vn ("Phần mềm đã nổi trên cùng trở lại."));
}

//=============================================================================
// 06/10: HUONG DAN CHI TIET
//=============================================================================
void MainComponent::openGuideWindow (int page)
{
    juce::DialogWindow::LaunchOptions o;
    o.content.setOwned (new livent::textscale::Host (new livent::guide::GuideComponent (page)));   // 14/10: theo co chu da chon
    o.dialogTitle = livent::vn ("Hướng dẫn sử dụng");
    o.dialogBackgroundColour = Col::panel;
    o.escapeKeyTriggersCloseButton = true;
    o.useNativeTitleBar = true;
    o.resizable = true;

    livent::bringDialogToFront (livent::launchDialog (o));
}

void MainComponent::openTuneExtensionGuide()
{
    juce::DialogWindow::LaunchOptions options;
    options.content.setOwned (new livent::textscale::Host (new livent::tuneGuide::Guide()));
    options.dialogTitle = livent::vn ("Hướng dẫn cài Tiện ích Tune");
    options.dialogBackgroundColour = Col::panel;
    options.escapeKeyTriggersCloseButton = true;
    options.useNativeTitleBar = true; options.resizable = true;
    livent::bringDialogToFront (livent::launchDialog (options));
}

void MainComponent::setHelpMode (bool on)
{
    helpOverlay.setBounds (getLocalBounds());
    helpOverlay.setVisible (on);
    if (on)
    {
        helpOverlay.toFront (true);
        helpOverlay.grabKeyboardFocus();
    }
}

void MainComponent::setupTopHelpTexts()
{
    using livent::help::set;
    auto v = [] (const char* s) { return livent::vn (s); };
    set (topRecordButton,  v ("Thu Âm"), v ("Thu lại giọng hát + nhạc đang chơi thành file. Bấm lần nữa để dừng và lưu."));
    set (topLaughButton,   v ("Cười"),   v ("Mở bảng tiếng cười / tiếng vỗ tay... bấm để phát xen khi đang hát."));
    set (topYouTubeButton, "YouTube",     v ("Mở cửa sổ YouTube của DAW: tự dò tone bài, chặn quảng cáo, mở bài từ Danh sách."));
    set (topFileButton,    v ("Tệp"),    v ("Tạo / mở / lưu / đóng dự án (.NT), xuất âm thanh."));
    set (topLayoutButton,  v ("Ngang / Dọc"), v ("Đổi bảng điều khiển giữa kiểu Ngang và kiểu Dọc gọn."));
    set (topSettingsButton, v ("Cài đặt"), v ("Âm thanh, soundcard, VST, giao diện, YouTube, Gán nút, bản quyền..."));
    set (topHelpButton,    v ("Thu gọn"), v ("Thu bảng điều khiển thành thanh gọn 2 hàng. Bấm ▴ trên thanh gọn (hoặc F8) để mở lại."));
    set (compactExpandButton, v ("Mở lại"), v ("Mở lại giao diện đầy đủ (F8)."));
    set (compactCloseButton, v ("Đóng"), v ("Đóng phần mềm (hỏi lưu dự án nếu chưa lưu)."));
    set (minimiseAppButton, v ("Thu nhỏ"), v ("Thu nhỏ cửa sổ xuống thanh tác vụ."));
    set (closeAppButton,   v ("Đóng"),   v ("Đóng phần mềm (hỏi lưu dự án nếu chưa lưu)."));
    set (cpuLabel,         "CPU",        v ("Mức CPU đang dùng cho âm thanh. Cao quá 70-80% dễ bị rè: tăng buffer hoặc bớt VST."));
    set (projectNameLabel, v ("Dự án"),  v ("Tên dự án đang mở. Dấu * = có thay đổi chưa lưu."));
    set (statusLabel,      v ("Thông tin âm thanh"), v ("Driver, tần số mẫu, buffer, độ trễ đang chạy."));
}

void MainComponent::openMusicAutoKey(bool locked,bool startSequence)
{
   #if JUCE_WINDOWS
    if(!projectOpen || projectLoadInProgress || pluginLoadInProgress)return;
    auto* music=mixer.getTrackByRole(Track::Role::Music);
    if(music==nullptr || music->getInserts().isSlotEmpty(kMusicVst2Slot) || music->getInserts().isMissing(kMusicVst2Slot))
    {tonePanel.showAutoKeyStatus(livent::vn("Ô VST số 2 track NHẠC chưa có plugin."));return;}
    if (music->getInserts().isBridge32Slot (kMusicVst2Slot))
    {
        tonePanel.showAutoKeyStatus (livent::vn ("Cắt khung/tự bấm/giữ mở cần Auto-Key bản 64-bit; ô này đang dùng Bridge32."));
        return;
    }
    auto* p=music->getInserts().getPlugin(kMusicVst2Slot);
    if(p==nullptr)return;
    // 06/10: chi khoa/cat khung khi o so 2 that su la Auto-Key - VST khac
    // nam nham o nay thi khong duoc khoa nut dong cua no.
    if(!p->getName().toLowerCase().retainCharacters("abcdefghijklmnopqrstuvwxyz0123456789").contains("autokey"))
    {
        if(!pluginWindows.isOpen(p))openEditorForSlot(kMusicVst2Slot,music);
        tonePanel.showAutoKeyStatus(livent::vn("Ô VST số 2 track NHẠC không phải Auto-Key (")+p->getName()
                                    +livent::vn("); chỉ mở cửa sổ, không khóa / tự bấm."));
        return;
    }
    const auto key=PluginWindowManager::makeKey(music->getId(),kMusicVst2Slot);
    if (pluginWindows.isPerformanceMode())
    {
        pluginWindows.setPerformanceMode (false);
        tonePanel.showAutoKeyStatus (livent::vn ("Mở Auto-Key; đã tắt tiết kiệm CPU để hiển thị VST."));
    }
    if(!pluginWindows.isOpen(p))openEditorForSlot(kMusicVst2Slot,music);
    if(auto*w=pluginWindows.findWindow(key))
    {
        if (locked) pluginWindows.clearAutoKeyCloseLocks();
        w->setAutoKeyCloseLocked(locked);
        auto& displays = juce::Desktop::getInstance().getDisplays();
        auto* display = displays.getDisplayForRect (getScreenBounds());
        if (display == nullptr) display = displays.getPrimaryDisplay();
        // 06/10: tha rong + nho vi tri theo may (khong con ghim goc tren phai)
        const auto posFile = PluginChain::getSettingsFolder().getChildFile ("autokey-window.txt");
        auto xy = juce::StringArray::fromTokens (posFile.loadFileAsString(), " ", "");
        const bool hasSaved = xy.size() >= 2;
        w->onAutoKeyMoved = [posFile] (juce::Point<int> pos)
        {
            posFile.replaceWithText (juce::String (pos.x) + " " + juce::String (pos.y));
        };
        w->placeAutoKey (display != nullptr ? display->userArea : juce::Rectangle<int>(),
                         hasSaved, hasSaved ? juce::Point<int> (xy[0].getIntValue(), xy[1].getIntValue())
                                            : juce::Point<int>());
        w->toFront (false);
        if(startSequence)autoKeyController.start(tonePanel.isManualDetectMode());
    }
   #else
    juce::ignoreUnused (locked, startSequence);
   #endif
}

void MainComponent::openAutoKeyAutomationSettings()
{
   #if JUCE_WINDOWS
    autoKeyController.stop();juce::Component::SafePointer<MainComponent>safe(this);
    auto*panel=new livent::autokey::SettingsPanel([safe]
    {
        if(safe==nullptr)return;
        const auto request=safe->autoKeyController.requestRevision();
        juce::Timer::callAfterDelay(150,[safe,request]
        {
            if(safe==nullptr || safe->autoKeyController.requestRevision()!=request)return;
            safe->autoKeyController.stop();
            if(auto*w=safe->autoKeyController.window())
                w->setAutoKeyCloseLocked(w->isCloseLocked());
            if(safe->tonePanel.followsPluginTone())
            {
                safe->tonePanel.beginAutoKeySequence();
                safe->openMusicAutoKey(safe->tonePanel.isManualDetectMode(),true);
            }
        });},
    [safe](int target)
    {
        if(safe==nullptr)return;
        const auto request=safe->autoKeyController.requestRevision();
        juce::Timer::callAfterDelay(300,[safe,target,request]
        {
            if(safe==nullptr || safe->autoKeyController.requestRevision()!=request)return;
            safe->openMusicAutoKey(safe->tonePanel.isManualDetectMode(),false);
            safe->autoKeyController.calibrate(target);
        });});
    panel->onTest=[safe](int target)
    {
        if(safe==nullptr)return;
        const auto request=safe->autoKeyController.requestRevision();
        juce::Timer::callAfterDelay(300,[safe,target,request]
        {
            if(safe==nullptr || safe->autoKeyController.requestRevision()!=request)return;
            safe->openMusicAutoKey(safe->tonePanel.isManualDetectMode(),false);
            safe->autoKeyController.testPoint(target);
        });};
    panel->onStop=[safe]{if(safe!=nullptr)safe->autoKeyController.stop();};
    auto* content=new livent::autokey::SettingsViewport(panel);
    // 06/10: dong bang bang X ma khong Luu -> chay lai lich bam cua bai dang hat
    content->onClosedWithoutAction=[safe]
    {
        if(safe==nullptr || !safe->tonePanel.followsPluginTone() || !safe->tonePanel.isManualDetectMode())return;
        safe->tonePanel.beginAutoKeySequence();
        safe->openMusicAutoKey(true,true);
    };
    juce::DialogWindow::LaunchOptions o;o.content.setOwned(content);o.dialogTitle=livent::vn("Tự bấm Auto-Key");o.dialogBackgroundColour=Col::panel;
    o.escapeKeyTriggersCloseButton=true;o.useNativeTitleBar=true;o.resizable=false;
    if(auto*w=livent::launchDialog(o))livent::bringDialogToFront(w);
   #endif
}

void MainComponent::updateVpsConfiguration()
{
    if(vpsUpdateRunning)return;vpsUpdateRunning=true;
    tonePanel.showAutoKeyStatus(livent::vn("Đang tải cấu hình VPS..."));
    juce::Component::SafePointer<MainComponent>safe(this);
    vpsUpdatePool.addJob([safe]
    {
        int status=0;auto stream=juce::URL(livent::vps::downloadUrl()).createInputStream(
            juce::URL::InputStreamOptions(juce::URL::ParameterHandling::inAddress).withConnectionTimeoutMs(15000).withNumRedirectsToFollow(0).withStatusCode(&status));
        bool ok=false;if(stream && status==200){juce::MemoryOutputStream out;char buffer[2048];while(!stream->isExhausted()){int n=stream->read(buffer,sizeof(buffer));if(n<=0)break;if(out.getDataSize()+(size_t)n>65536)break;out.write(buffer,(size_t)n);}if(stream->isExhausted())ok=livent::vps::install(juce::JSON::parse(out.toString()));}
        juce::MessageManager::callAsync([safe,ok]{if(safe==nullptr)return;safe->vpsUpdateRunning=false;const auto current=livent::vps::current();
            safe->tonePanel.showAutoKeyStatus(ok?livent::vn("Đã cập nhật VPS: ")+current.host+":"+juce::String(current.port):livent::vn("Không cập nhật được VPS; giữ cấu hình cũ."));});
    });
}