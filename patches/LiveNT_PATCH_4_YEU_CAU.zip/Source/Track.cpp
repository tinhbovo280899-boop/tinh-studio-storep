#include "Track.h"
#include "OutputGuard.h"
#include "BuiltinKey.h"   // 12s: T-AutoKey co san (track NHAC)

//=============================================================================
Track::Track (int trackId, Type trackType, const juce::String& trackName, juce::Colour c)
    : id (trackId), type (trackType), uuid (juce::Uuid().toString()), name (trackName), colour (c)
{
    buffer.setSize (PluginChain::maxChannels, 512);
    buffer.clear();
    for (auto& cached : rtSendCache) { cached.targetId = -1; cached.enabled = false; }   // 13/10: chua doc lan nao = send tat

    // Mic thuong la mono, con lai mac dinh stereo
    channelMode.store (type == Type::Audio ? Chan::Mono : Chan::Stereo);
}

Track::~Track()
{
    transport.setSource (nullptr);
    fileBuffering.reset();
    readerSource.reset();
}

juce::String Track::getTypeName() const
{
    switch (type)
    {
        case Type::Audio:  return livent::vn ("Audio");
        case Type::Beat:   return livent::vn ("Beat");
        case Type::Group:  return livent::vn ("Group");
        case Type::FxBus:  return livent::vn ("FX Bus");
        case Type::Output: return livent::vn ("Output");
        case Type::PK:     return livent::vn ("PK");
        case Type::Input:     return livent::vn ("Đầu vào");
        case Type::OutputBus: return livent::vn ("Đầu ra");
    }
    return {};
}

//=============================================================================
void Track::setInputChannels (int left, int right)
{
    /*  MOC 52: cho phep "Khong chon" (khong doc cong nao ca) - dung khi anh
        muon mot track cong vao TAM THOI khong lay tieng tu dau, ma khong
        phai xoa han track do di. Danh dau bang -1 o CA HAI kenh; readSource()
        thay so am la bo qua, buffer track do se cu the la im lang (0), khong
        vo tinh doc nham cong 1 nhu truoc day (jmax(0, left) ep ve cong 1).  */
    if (left < 0)
    {
        inputLeft .store (-1);
        inputRight.store (-1);
        return;
    }

    inputLeft .store (left);
    inputRight.store (right);
}

void Track::setGainDb (float dB)
{
    if (! std::isfinite (dB)) dB = 0.0f;
    dB = juce::jlimit (-60.0f, 12.0f, dB);
    gainDb.store (dB);
    gainLinear.store (dB <= -59.9f ? 0.0f : juce::Decibels::decibelsToGain (dB));
}

void Track::setPan (float p)
{
    if (! std::isfinite (p)) p = 0.0f;
    pan.store (juce::jlimit (-1.0f, 1.0f, p), std::memory_order_relaxed);
}

void Track::applyPan (int numSamples) noexcept
{
    // Centre preserves existing levels. Stereo balance attenuates the opposite
    // channel, with a one-block ramp and no audio-thread allocation or lock.
    const float p = pan.load (std::memory_order_relaxed);
    const float l = p >= 1.0f ? 0.0f : p > 0.0f ? std::cos (p * juce::MathConstants<float>::halfPi) : 1.0f;
    const float r = p <= -1.0f ? 0.0f : p < 0.0f ? std::cos (-p * juce::MathConstants<float>::halfPi) : 1.0f;
    const int n = juce::jmin (numSamples, buffer.getNumSamples());
    if (n <= 0) return;
    if (buffer.getNumChannels() > 0) buffer.applyGainRamp (0, 0, n, lastPanL, l);
    if (buffer.getNumChannels() > 1) buffer.applyGainRamp (1, 0, n, lastPanR, r);
    lastPanL = l; lastPanR = r;
}

//=============================================================================
//  Send
//=============================================================================
int Track::getNumSends() const   { return numSends.load(); }

Track::Send Track::getSend (int index) const
{
    Send off;
    off.targetId = -1;
    off.enabled = false;

    if (! juce::isPositiveAndBelow (index, numSends.load()))
        return off;

    /* 13/10: luong GIAO DIEN / dieu khien doi khoa that su (audio thread chi TryLock va giu vai
       micro-giay), nen khong bao gio doc nham "send tat" nhu ban cu (ban cu tra send tat khi trung
       khoa: UI co the lat nham send, ban lai voi bien dich lai do thi dinh tuyen). */
    const juce::ScopedLock sl (sendLock);

    // UI có thể đã xóa/dồn send giữa lần kiểm tra đầu và lúc lấy được khóa.
    if (! juce::isPositiveAndBelow (index, numSends.load()))
        return off;

    return sends[index];
}

Track::Send Track::getSendRT (int index) noexcept
{
    Send off;
    off.targetId = -1;
    off.enabled = false;

    if (! juce::isPositiveAndBelow (index, juce::jmin (numSends.load(), maxSends)))
        return off;

    /* V5.8.7 / 13/10: audio thread KHONG cho khoa. Trung khoa (UI dang sua send dung luc nay) thi
       dung ban chep gan nhat: send van ra dung muc cu them toi da 1 khoi, KHONG bi tat roi bat lai
       (truoc day: send xuong 0 -> ramp -> len lai + dung lai do thi dinh tuyen = tieng "tach"). */
    const juce::ScopedTryLock sl (sendLock);
    if (! sl.isLocked())
    {
        sendLockMissCount.fetch_add (1, std::memory_order_relaxed);
        return rtSendCache[index];
    }

    if (! juce::isPositiveAndBelow (index, numSends.load()))
        return off;

    rtSendCache[index] = sends[index];
    return rtSendCache[index];
}

void Track::addSend (int targetTrackId, int targetSlot)
{
    const juce::ScopedLock sl (sendLock);
    const int n = numSends.load();

    if (n >= maxSends)
        return;

    sends[n].targetId   = targetTrackId;
    sends[n].targetSlot = targetSlot;
    sends[n].levelDb    = -6.0f;
    sends[n].enabled    = true;
    sends[n].preFader   = false;

    numSends.store (n + 1);
}

void Track::removeSend (int index)
{
    const juce::ScopedLock sl (sendLock);
    const int n = numSends.load();

    if (! juce::isPositiveAndBelow (index, n))
        return;

    for (int i = index; i < n - 1; ++i)
        sends[i] = sends[i + 1];

    numSends.store (n - 1);
}

void Track::setSendTarget (int index, int targetTrackId, int targetSlot)
{
    const juce::ScopedLock sl (sendLock);
    if (juce::isPositiveAndBelow (index, numSends.load()))
    {
        sends[index].targetId = targetTrackId;
        sends[index].targetSlot = targetSlot;
    }
}

void Track::swapSidechainSendTargetSlots (int targetTrackId, int slotA, int slotB)
{
    if (slotA < 0 || slotB < 0 || slotA == slotB)
        return;

    const juce::ScopedLock sl (sendLock);
    const int n = numSends.load();

    for (int i = 0; i < n; ++i)
    {
        auto& send = sends[i];

        if (send.targetId != targetTrackId || send.targetSlot < 0)
            continue;

        if (send.targetSlot == slotA)
            send.targetSlot = slotB;
        else if (send.targetSlot == slotB)
            send.targetSlot = slotA;
    }
}

void Track::moveSidechainSendTarget (int sourceTrackId, int sourceSlot, int destTrackId, int destSlot,
                                     bool movingSource)
{
    const juce::ScopedLock sl (sendLock);
    int n = numSends.load();
    // Routes to the overwritten plugin do not belong to the replacement.
    for (int i = n - 1; i >= 0; --i)
        if (sends[i].targetId == destTrackId && sends[i].targetSlot == destSlot)
        {
            for (int j = i; j < n - 1; ++j) sends[j] = sends[j + 1];
            --n;
        }
    if (movingSource)
        for (int i = 0; i < n; ++i)
            if (sends[i].targetId == sourceTrackId && sends[i].targetSlot == sourceSlot)
            {
                sends[i].targetId = destTrackId;
                sends[i].targetSlot = destSlot;
                if (getId() == destTrackId) sends[i].enabled = false; // avoid a new self feedback route
            }
    numSends.store (n);
}

void Track::setSendLevelDb (int index, float dB)
{
    const juce::ScopedLock sl (sendLock);
    if (juce::isPositiveAndBelow (index, numSends.load()))
        sends[index].levelDb = dB;
}

void Track::setSendPreFader (int index, bool pre)
{
    const juce::ScopedLock sl (sendLock);
    if (juce::isPositiveAndBelow (index, numSends.load()))
        sends[index].preFader = pre;
}

void Track::setSendEnabled (int index, bool on)
{
    const juce::ScopedLock sl (sendLock);
    if (juce::isPositiveAndBelow (index, numSends.load()))
        sends[index].enabled = on;
}

//=============================================================================
//  File nhac
//=============================================================================
bool Track::loadFile (const juce::File& file, juce::AudioFormatManager& formats,
                      juce::TimeSliceThread& readThread)
{
    auto ownedReader = livent::openCheckedReader (formats, file);
    auto* reader = ownedReader.get();

    if (reader == nullptr)
        return false;

    const int sourceChannels = juce::jlimit (1, 2, (int) reader->numChannels);
    auto newSource = std::make_unique<livent::CheckedAudioReaderSource>
        (std::move (ownedReader));
    /*  13/10: dem doc truoc ~4 giay (ban cu 32768 mau = 0.7 giay @48k). Dia/USB/antivirus thinh thoang
        tre vai tram ms -> dem 0.7 giay co the can giua bai = nhac "dut" roi "bup" lai. 4 giay chiu duoc
        cu giat dai ma khong ton them CPU (luong doc nen lam viec, audio thread chi chep tu RAM).  */
    const int bufferSamples = juce::jlimit (32768, 524288,
                                            (int) std::lround (juce::jmax (8000.0, reader->sampleRate) * 4.0));
    auto newBuffering = std::make_unique<livent::CheckedBufferingAudioSource>
        (newSource.get(), readThread, bufferSamples, true);

    {
        const juce::ScopedLock sl (fileLock);
        transport.setSource (newBuffering.get(), 0, nullptr, reader->sampleRate);
        fileBuffering = std::move (newBuffering);
        readerSource        = std::move (newSource);
        fileReadFailed.store (false, std::memory_order_release);
        loadedFileChannels  = sourceChannels;
        loadedFileName = file.getFileName();
        fileReferencePath = file.getFullPathName();

        /* V6.5 SAFETY: transport va transportPrepared phai duoc doi trong
           CUNG fileLock. Audio thread cung lay fileLock truoc getNextAudioBlock(),
           nen no khong the chen vao giua setSource() va prepareToPlay(). */
        if (transportPrepared)
            transport.prepareToPlay (currentBlockSize, currentSampleRate);
    }

    return true;
}

void Track::startPlayback()
{
    const juce::ScopedLock sl (fileLock);
    if (readerSource != nullptr)
    {
        requestDeclick();   // 13/10: bat dau giua bai khong "tach"
        transport.start();
    }
}

bool Track::prepareFileExport()
{
    const juce::ScopedLock sl (fileLock);
    if (! readerSource || ! fileBuffering || readerSource->hasFailed()) return false;
    transport.setPosition (0);
    fileBuffering->clearUnderrun();
    fileReadFailed.store (false, std::memory_order_release);
    const int needed = (int) juce::jmin<juce::int64> (fileBuffering->getTotalLength(),
        (juce::int64) std::ceil (currentBlockSize * readerSource->sourceRate() / currentSampleRate) + 256);
    juce::AudioSourceChannelInfo request (nullptr, 0, needed);
    return needed == 0 || (fileBuffering->waitForNextAudioBlockReady (request, 2000) && ! readerSource->hasFailed());
}

void Track::stopPlayback()
{
    /* FIX: KHONG giu fileLock o day. AudioTransportSource::stop() ngu toi da
       500 x 2 ms cho audio callback xac nhan da dung, nhung readSource() chi
       TryLock fileLock -> giu lock thi callback khong bao gio xac nhan, UI dong
       bang ~1 giay moi lan bam DUNG va nhac bi cat ngang (khong fade). Transport
       da co callbackLock rieng; loadFile/setSource cung chay tren message thread
       nen khong the chen vao giua. */
    transport.stop();
}

void Track::setPlayPosition (double seconds)
{
    const juce::ScopedLock sl (fileLock);
    transport.setPosition (seconds);
    requestDeclick();   // 13/10: tua = mau dau moi cach xa mau cuoi cu
    if (fileBuffering) fileBuffering->clearUnderrun();
    fileReadFailed.store (false, std::memory_order_release);
}

bool   Track::isPlaying() const          { return transport.isPlaying(); }
double Track::getPositionSeconds() const { return transport.getCurrentPosition(); }
double Track::getLengthSeconds() const   { return transport.getLengthInSeconds(); }

//=============================================================================
void Track::prepare (double sampleRate, int blockSize)
{
    currentSampleRate = sampleRate;
    currentBlockSize  = blockSize;

    buffer.setSize (PluginChain::maxChannels, blockSize, false, true, true);
    buffer.clear();
    midi.ensureSize (256);

    // V5.8.7: bat dau moi lan prepare tu im lang, sau do ramp vao trong 1 block.
    lastPanL = lastPanR = 1.0f;
    lastMainRouteGain = 0.0f;
    std::fill (std::begin (lastSendRouteGain), std::end (lastSendRouteGain), 0.0f);
    lastTrackTapGain = 0.0f;
    lastOutputMixIds.fill (0);
    lastOutputMixGains.fill (0);
    lastHardwareOutGain = 0.0f;
    sourceBridge.reset();
    sourceMix = SourceMix {};
    declickRequested.store (false);
    lastInsertsOn = allInsertsOn.load();
    insertsFadeLeft = 0;
    insertsDryScratch.setSize (2, juce::jmax (1, blockSize), false, true, true);
    meterRelease = std::exp (-(float) juce::jmax (1, blockSize)
                             / (float) juce::jmax (1.0, sampleRate * 0.30));

    channelEq.prepare (sampleRate);
    leveler.prepare (sampleRate);
    denoise.prepare (sampleRate);                // 12s
    inserts.prepare (sampleRate, blockSize);

    const juce::ScopedLock sl (fileLock);
    transport.prepareToPlay (blockSize, sampleRate);
    transportPrepared = true;
}

void Track::release()
{
    inserts.release();

    const juce::ScopedLock sl (fileLock);
    transport.releaseResources();
    transportPrepared = false;
}

//=============================================================================
//  Luong audio
//=============================================================================
void Track::clearBuffer (int numSamples)
{
    // Track chi route/monitor 2 kenh dau. Cac kenh phu 2..N duoc PluginChain
    // tu xoa ngay truoc khi giao cho plugin can sidechain/multibus. Khong can
    // clear 16 kenh moi block - giam bo nho va CPU tren laptop yeu.
    const int mainChannels = juce::jmin (2, buffer.getNumChannels());
    for (int ch = 0; ch < mainChannels; ++ch)
        buffer.clear (ch, 0, numSamples);
}

void Track::readSource (const juce::AudioBuffer<float>& hardwareInput,
                        int startSample, int numSamples)
{
    /*  Group / FX / Output / PK khong co nguon rieng tu card.

        MOC 28: PK nam trong nhom nay -- tieng cua no do Mixer chep sang tu
        track ma no nghe trom, VA chep o cuoi chuoi xu ly chu khong phai o
        day (xem Mixer::processBlock). Ghi vao day thi qua som, luc do track
        nguon con chua chay xong.  */
    if (type == Type::Group || type == Type::FxBus
        || type == Type::Output || type == Type::OutputBus || type == Type::PK)
        return;

    /*  MOC 51: track lay tieng TU MOT TRACK KHAC thi khong doc card.

        Mixer se chep tieng sang sau khi track nguon chay xong day plugin cua
        no - xem Mixer::processBlock. Doc card o day nua la cong hai lan.  */
    if (source.load (std::memory_order_acquire) == Source::TrackTap)
        return;

    /*  ==========  MOC 57: MOI LOAI TRACK DEU PHAT DUOC FILE  ==========

        Truoc day dong nay doi CA HAI dieu kien: phai la track loai Beat, VA
        nguon phai la file. Hoi do dung, vi chi track NHAC moi mo file nhac.

        Nhung tu Moc 41 co thu am, va "nghe lai ban thu" chinh la doi nguon
        track sang file. Track MIC la loai Audio chu khong phai Beat, nen no
        khong lot qua duoc dong nay - no roi thang xuong phan doc card ben
        duoi, tuc la van nghe MIC TRUC TIEP chu khong phai ban thu.

        Trieu chung khop tung chu: thu ca hai track, bam nghe lai thi NHAC ra
        tieng (Beat - lot qua duoc), con MIC im hoac chi ra tieng mic dang hat
        (Audio - bi chan). Song van ve dung tren man hinh vi song ve tu mang
        dinh da luu, khong lien quan gi toi duong phat.

        Bo dieu kien loai track: cu track nao dat nguon la FILE thi phat file.
        Track NHAC van chay y nhu cu vi no cung thoa dieu kien nay.  */
    if (source.load (std::memory_order_acquire) == Source::AudioFile)
    {
        const juce::ScopedTryLock stl (fileLock);

        if (! stl.isLocked())
        {
            fileLockMissCount.fetch_add (1, std::memory_order_relaxed);
            if (transport.isPlaying()) fileReadFailed.store (true, std::memory_order_release);
            return;
        }

        if (readerSource == nullptr)
            return;

        float* two[2] = { buffer.getWritePointer (0), buffer.getWritePointer (1) };
        juce::AudioBuffer<float> stereoView (two, 2, numSamples);
        juce::AudioSourceChannelInfo info (&stereoView, 0, numSamples);
        transport.getNextAudioBlock (info);
        if (readerSource->hasFailed() || (fileBuffering && fileBuffering->hasUnderrun()))
            fileReadFailed.store (true, std::memory_order_release);

        // V6.6.4 COMMERCIAL: MONO la mono o NGUON, truoc inserts.
        // Neu file goc da mono thi giu nguyen muc am va copy L -> R. Neu file
        // goc stereo nhung track duoc dat Mono thi downmix 0.5*(L+R), sau do
        // dua cung mot mau sang hai kenh. Stereo effect o inserts VAN duoc phep
        // tao L/R khac nhau ve sau - khong ep mono sau effect.
        if (channelMode.load() == Chan::Mono)
        {
            float* outL = buffer.getWritePointer (0);
            float* outR = buffer.getWritePointer (1);

            if (loadedFileChannels <= 1)
            {
                juce::FloatVectorOperations::copy (outR, outL, numSamples);
            }
            else
            {
                for (int i = 0; i < numSamples; ++i)
                {
                    const float mono = 0.5f * (outL[i] + outR[i]);
                    outL[i] = mono;
                    outR[i] = mono;
                }
            }
        }
        return;
    }

    const int numHw = hardwareInput.getNumChannels();
    const int l = inputLeft.load();
    const int r = inputRight.load();

    if (! juce::isPositiveAndBelow (l, numHw))
        return;

    const float* left = hardwareInput.getReadPointer (l, startSample);

    if (channelMode.load() == Chan::Stereo && juce::isPositiveAndBelow (r, numHw))
    {
        buffer.copyFrom (0, 0, left, numSamples);
        buffer.copyFrom (1, 0, hardwareInput.getReadPointer (r, startSample), numSamples);
    }
    else
    {
        // Mono: nhan doi ra ca hai kenh
        buffer.copyFrom (0, 0, left, numSamples);
        buffer.copyFrom (1, 0, left, numSamples);
    }
}

void Track::bridgeSource (int numSamples, bool forceArm) noexcept
{
    if (numSamples <= 0 || buffer.getNumChannels() < 1 || numSamples > buffer.getNumSamples())
        return;
    if (declickRequested.exchange (false, std::memory_order_acq_rel) || forceArm)
        sourceBridge.arm();
    sourceBridge.process (buffer.getWritePointer (0),
                          buffer.getNumChannels() > 1 ? buffer.getWritePointer (1) : nullptr,
                          numSamples, livent::declick::rampSamplesFor (currentSampleRate));
}

void Track::copyFromTrackTap (const juce::AudioBuffer<float>& sourceBuffer,
                              int numSamples, float targetGain)
{
    const int nch = juce::jmin (2, buffer.getNumChannels(), sourceBuffer.getNumChannels());
    if (nch <= 0 || numSamples <= 0)
        return;

    const float start = lastTrackTapGain;
    const float target = juce::jmax (0.0f, targetGain);
    lastTrackTapGain = target;

    // V6.6.4 COMMERCIAL: target MONO phai nhan NGUON mono that, ke ca khi
    // track dau vao phia truoc dang co insert stereo. Downmix truoc inserts
    // cua target; sau do plugin stereo tren target van duoc tu do tao stereo.
    if (channelMode.load() == Chan::Mono && buffer.getNumChannels() >= 2)
    {
        const float* srcL = sourceBuffer.getReadPointer (0);
        const float* srcR = sourceBuffer.getNumChannels() > 1
                           ? sourceBuffer.getReadPointer (1) : srcL;
        float* dstL = buffer.getWritePointer (0);
        float* dstR = buffer.getWritePointer (1);

        const float delta = (target - start) / (float) juce::jmax (1, numSamples);
        float g = start;
        for (int i = 0; i < numSamples; ++i)
        {
            const float mono = 0.5f * (srcL[i] + srcR[i]);
            const float v = mono * g;
            dstL[i] = v;
            dstR[i] = v;
            g += delta;
        }
        return;
    }

    for (int ch = 0; ch < nch; ++ch)
        buffer.copyFromWithRamp (ch, 0, sourceBuffer.getReadPointer (ch),
                                 numSamples, start, target);
}

void Track::setOutputBusMixSources (const juce::Array<int>& sources)
{
    int count = 0;
    for (int id : sources)
    {
        if (id <= 0 || count >= maxOutputMixSources) continue;
        bool duplicate = false;
        for (int i = 0; i < count; ++i)
            if (outputBusMixSources[(size_t)i].load() == id) duplicate = true;
        if (! duplicate) outputBusMixSources[(size_t)count++].store (id);
    }
    outputBusMixCount.store (count);
    outputBusSourceId.store (count > 0 ? -2 : -1);
}

void Track::removeOutputBusMixSource (int sourceId)
{
    if (getOutputBusSourceId() != -2) return;
    int count = 0;
    const int oldCount = getOutputBusMixCount();
    for (int i = 0; i < oldCount; ++i)
    {
        const int id = outputBusMixSources[(size_t)i].load();
        if (id != sourceId) outputBusMixSources[(size_t)count++].store (id);
    }
    outputBusMixCount.store (count);
    if (count == 0) outputBusSourceId.store (-1);
}

void Track::addOutputMixTap (const Track& sourceTrack, int numSamples, float targetGain, int index, const juce::AudioBuffer<float>* compensated)
{
    if (index < 0 || index >= maxOutputMixSources || numSamples <= 0) return;
    const auto slot = (size_t)index;
    if (lastOutputMixIds[slot] != sourceTrack.getId())
    {
        lastOutputMixIds[slot] = sourceTrack.getId();
        lastOutputMixGains[slot] = 0;
    }
    const float start = lastOutputMixGains[slot];
    const float target = juce::jmax (0.0f, targetGain);
    lastOutputMixGains[slot] = target;
    const auto& src = compensated != nullptr ? *compensated : sourceTrack.buffer;
    const int channels = juce::jmin (2, buffer.getNumChannels(), src.getNumChannels());
    for (int ch = 0; ch < channels; ++ch)
        buffer.addFromWithRamp (ch, 0, src.getReadPointer (ch), numSamples, start, target);
}

void Track::feedBuiltinKey (int numSamples) noexcept
{
    if (role == Role::Music && ! offlineRendering && buffer.getNumChannels() > 0)
        livent::builtinkey::Detector::get().feed (getId(), buffer.getReadPointer (0),
                                                  buffer.getNumChannels() > 1 ? buffer.getReadPointer (1) : nullptr,
                                                  numSamples, currentSampleRate);
}

void Track::runInserts (int numSamples)
{
    /*  13/10 CHONG NO TIENG: bat/tat cong tac INSERT tong khong con nhay bac.
        Trong ~5 ms sau khi bam, chuoi van chay va tron dan giua ban "co insert" va "khong insert"
        (giong bypass tung plugin). Het doan tron thi moi that su bo qua chuoi de nhe CPU.  */
    const bool insertsOn = allInsertsOn.load();
    if (insertsOn != lastInsertsOn)
    {
        lastInsertsOn = insertsOn;
        insertsFadeLeft = livent::declick::rampSamplesFor (currentSampleRate);
        insertsFadeTotal = insertsFadeLeft;
    }
    const bool fading = insertsFadeLeft > 0 && numSamples <= insertsDryScratch.getNumSamples()
                        && buffer.getNumChannels() >= 2;
    if (! fading)
        insertsFadeLeft = 0;
    const bool effectiveOn = insertsOn || fading;

    if (fading)
    {
        for (int ch = 0; ch < 2; ++ch)
        {
            // Bus FX khong co "kho": tat chuoi = im lang, nen tron ve 0.
            if (type == Type::FxBus) insertsDryScratch.clear (ch, 0, numSamples);
            else insertsDryScratch.copyFrom (ch, 0, buffer, ch, 0, numSamples);
        }
    }

    // An FX return is wet-only when its chain is empty, still loading, missing,
    // or disabled as a whole. Per-plugin bypass keeps that plugin's own policy.
    if (type == Type::FxBus && (! effectiveOn || ! inserts.hasAnyLoadedPlugin()))
    {
        buffer.clear (0, numSamples);
        silentSampleCount = 0;
        insertsFadeLeft = 0;
        return;
    }
    // Capture has already written DRY audio before this stage.
    // Cong tac tong INSERT tat => EQ kenh cung bypass (tuyet doi khong tac dung).
    channelEq.setHostBypass (! effectiveOn);
    /*  Cong tac tong tat -> bo qua CA chuoi. Tin hieu di thang, khong plugin
        nao chay, va CPU tut ngay lap tuc. Rat huu dung khi dang hat ma may
        bat dau rot tieng: tat het insert la co tieng lai ngay.
        15/10: van goi EQ (dang bypass) de no tu tron ra em, khong nhay tieng. */
    if (! effectiveOn)
    {
        feedBuiltinKey (numSamples);   // 12s: tat INSERT tong -> nhac khong qua VST, van do duoc
        channelEq.process (buffer, numSamples);
        return;
    }

    // Hoan tat doan tron: dung "kho" da chup truoc chuoi + EQ, he so wet doi tuyen tinh.
    auto finishInsertFade = [this, numSamples, insertsOn, fading]
    {
        if (! fading)
            return;
        const float inv = 1.0f / (float) juce::jmax (1, insertsFadeTotal);
        for (int ch = 0; ch < 2; ++ch)
        {
            float* wet = buffer.getWritePointer (ch);
            const float* dry = insertsDryScratch.getReadPointer (ch);
            for (int i = 0; i < numSamples; ++i)
            {
                const float p = juce::jlimit (0.0f, 1.0f, 1.0f - (float) (insertsFadeLeft - i) * inv);
                const float w = insertsOn ? p : 1.0f - p;
                wet[i] = wet[i] * w + dry[i] * (1.0f - w);
            }
        }
        insertsFadeLeft = juce::jmax (0, insertsFadeLeft - numSamples);
    };

    /*  MOC 66: "SMART SILENCE" kieu Cubase - Tinh gop y.

        Truoc day: du buffer dau vao IM RE HOAN TOAN (khong ai hat, khong
        nhac chay), LiveNT van goi inserts.process() nhu binh thuong moi
        khoi - Auto-Tune, EQ, Comp... van phai tinh toan tren toan so 0,
        ton dung CPU nhu luc co tieng that.

        CAI KHO: khong the CHI can thay buffer im la BO QUA NGAY - cac
        plugin nhu Reverb/Delay co DUOI VANG con ngan dai SAU KHI tin hieu
        goc da tat (vd hat xong mot cau, tieng vang con ngan vai giay moi
        het). Neu cat NGAY luc vua im la mat dut cai duoi do, nghe hut
        tieng rat lo.

        CACH LAM: dem SO MAU LIEN TUC im lang. Chi khi da im DU LAU (default
        3 giay - qua du de moi loai reverb/delay thong thuong tu nhien tat
        han duoi vang cua no qua NHIEU KHOI process() that su, khong phai
        boi qua) thi moi bat dau BO QUA khong goi plugin nua. Trong 3 giay
        dau tien sau khi im, plugin VAN duoc goi binh thuong - dung de duoi
        vang tu nhien chay het, dung nhu thiet ke that.

        Vua co tieng tro lai (du chi 1 mau khong im) la RESET ve xu ly binh
        thuong NGAY LAP TUC, khong co do tre nao ca - chi tiet kiem luc THAT
        SU khong ai dang dung toi, khong bao gio lam mat tieng that.

        MOC 66g FIX: gia dinh tren SAI voi mot loai plugin - loai TU TAO RA
        TIENG, khong phu thuoc dau vao track (nhac cu ao, hoac Sessionwire
        Receive - nhan tieng tu ket noi mang, KHONG lien quan gi den viec
        track co dang duoc hat vao hay khong). Voi loai nay, "dau vao track
        im re" KHONG co nghia la "khong co gi de xu ly" - plugin van co the
        dang tao ra tieng that (tu mang, tu MIDI...). Neu ap Smart Silence
        cho no, sau 3 giay se NGUNG GOI CA CHUOI PLUGIN - dung nhu loi Tinh
        gap: them Sessionwire Receive khong bao loi gi, nhung khong bao gio
        nhan duoc tieng, vi no khong con duoc goi de "hoi" xem co tieng tu
        mang hay khong nua.

        Cach chua: TRUOC KHI kiem tra im lang, hoi xem chuoi insert co
        plugin loai nay khong - co thi BO QUA HAN Smart Silence cho track
        nay, luon xu ly binh thuong (chap nhan ton CPU, dung dan quan trong
        hon toi uu trong truong hop nay).  */
    // Tail metadata cannot prove that a plugin will stay silent: a delay may
    // produce its first echo much later. Process every loaded chain, including
    // sidechain-only blocks; only an empty chain can safely sleep.
    const bool mustAlwaysProcessInserts = offlineRendering || type == Type::FxBus || fading
                                       || inserts.hasAnyLoadedPlugin();

    if (mustAlwaysProcessInserts)
    {
        silentSampleCount = 0;   // dam bao khong "ket" o trang thai da tinh tu truoc
    }
    else
    {
    const bool silentNow = buffer.getMagnitude (0, 0, numSamples) < 0.0001f
                        && (buffer.getNumChannels() < 2
                            || buffer.getMagnitude (1, 0, numSamples) < 0.0001f);

    if (silentNow)
    {
        silentSampleCount += numSamples;

        // FX returns are excluded above. Ordinary tracks sleep only after the
        // grace period without input or audible plugin output.
        const double holdSeconds = silenceHoldSeconds;
        const int64_t holdSamples = (int64_t) (currentSampleRate * holdSeconds);

        if (silentSampleCount > holdSamples)
        {
            /*  Da im qua du lau (het thoi gian an han cho duoi vang) - bo
                qua han, KHONG goi plugin nao trong chuoi insert nua. Buffer
                da san la 0.0f tu truoc (im lang that su), nen khong can xoa
                gi them - chi don gian la KHONG DUNG CPU xu ly no.  */
            return;
        }

        // Con trong thoi gian an han - van xu ly binh thuong de duoi vang chay tu nhien
    }
    else
    {
        silentSampleCount = 0;   // co tieng that -> ve trang thai binh thuong ngay
    }
    }   // end else (khong co plugin loai tu tao tieng)

    midi.clear();

    // FX buses are processed by their VSTs; keep noise reduction on non-FX tracks.
    if (type != Type::FxBus)
        denoise.process (buffer, numSamples);   // 0 % = bypass

    float* pointers[PluginChain::maxChannels];

    for (int ch = 0; ch < PluginChain::maxChannels; ++ch)
        pointers[ch] = buffer.getWritePointer (ch);

    juce::AudioBuffer<float> view (pointers, PluginChain::maxChannels, numSamples);
    inserts.process (view, midi);
    /*  OUTPUT GUARD: plugin nha NaN/Inf -> xoa khoi nay (im) thay vi day rac
        sang send/bus/loa roi lam hong ca vang/delay phia sau. Chi kiem 2 kenh
        chinh; ~vai trieu phep cong moi giay, khong dang ke.  */
    if (! livent::outputguard::allFinite (buffer.getReadPointer (0), numSamples)
        || (buffer.getNumChannels() > 1 && ! livent::outputguard::allFinite (buffer.getReadPointer (1), numSamples)))
    {
        buffer.clear (0, numSamples);
        nonFiniteBlocks.fetch_add (1, std::memory_order_relaxed);
        exportNonFinite.fetch_add (1, std::memory_order_relaxed);   // C01: audio thread chi tang bo dem, khong cap phat/ghi log
    }
    /*  15/10: thu tu giong Cubase - Inserts (VST) -> EQ kenh -> Fader -> Sends.
        Truoc day EQ chay TRUOC chuoi insert. EQ dat sau output guard de bo dem
        NaN van bat dung loi cua plugin (EQ tu xoa NaN nen se che mat). */
    /*  12s: T-AutoKey co san nghe track NHAC NGAY SAU chuoi VST (da qua con nang / ha tong),
        truoc EQ kenh va fader. Ngu thi chi la 1 phep doc bien, khong ton gi.  */
    feedBuiltinKey (numSamples);
    channelEq.process (buffer, numSamples);
    finishInsertFade();
    // On ordinary tracks, audible plugin output also keeps Smart Silence awake.
    if (buffer.getMagnitude (0, 0, numSamples) >= 0.00001f
        || (buffer.getNumChannels() > 1 && buffer.getMagnitude (1, 0, numSamples) >= 0.00001f))
        silentSampleCount = 0;
}

void Track::addToBus (juce::AudioBuffer<float>& destination, int numSamples,
                      float extraGain, int routeIndex, bool applyFader, const juce::AudioBuffer<float>* compensated)
{
    const auto& audio = compensated != nullptr ? *compensated : buffer;
    // 06/10: send TRUOC fader thi khong nhan volume track
    const float target = juce::jmax (0.0f, (applyFader ? gainLinear.load() : 1.0f) * extraGain);

    float* last = &lastMainRouteGain;
    if (routeIndex >= 0 && routeIndex < maxSends)
        last = &lastSendRouteGain[routeIndex];

    const float start = *last;
    *last = target;

    if (start <= 0.0f && target <= 0.0f)
        return;

    /*  V5.8.7 LIVE: ramp trong DUNG 1 audio block. Khong co timer, khong cap
        phat, khong khoa. Keo fader / bam M / tat Loa / tat SEND vi the khong
        nhay gain thang dung nua, tranh 'tach' va zipper noise luc dang hat. */
    destination.addFromWithRamp (0, 0, audio.getReadPointer (0),
                                 numSamples, start, target);

    if (destination.getNumChannels() > 1)
        destination.addFromWithRamp (1, 0, audio.getReadPointer (1),
                                     numSamples, start, target);
}

void Track::updateMeter (int numSamples)
{
    /*  ==========  MOC 49: DONG HO PHAI NOI DUNG SU THAT  ==========

        Loi anh gap: tat MIC hay tat NHAC ma dong ho VAN nhay.

        Ly do: cho nay chi doc buffer roi nhan voi am luong. Ma nut M (tat
        tieng) va nut Loa KHONG nam trong am luong -- chung duoc xu ly o mot
        cho khac han (Mixer::routeToTarget quyet dinh co do tieng sang track
        dich hay khong). Buffer thi van day tin hieu nhu thuong, nen dong ho
        van nhay du khong con giot tieng nao ra loa.

        Nhin dong ho nhay trong khi tai khong nghe gi la kieu nhap nhang te
        nhat luc dang dien: anh se tuong card hong, hay tuong minh tat nham
        track khac, va di kiem tra lung tung giua buoi hat.

        Chua: hoi dung nhung dieu kien ma routeToTarget dung, roi ha dong ho
        ve 0 neu tieng khong di duoc toi dau.  */
    // 12r: do muc tung kenh MOT lan, dung chung cho dong ho tong va dong ho L/R.
    const float magL = buffer.getMagnitude (0, 0, numSamples);
    const float magR = buffer.getNumChannels() > 1 ? buffer.getMagnitude (1, 0, numSamples) : magL;
    const float peak = juce::jmax (magL, magR);

    /*  Bus (Group/FxBus) va duong ra tong khong co nut Loa tren giao dien,
        nen chi xet nut M cho chung. Track thuong thi xet ca hai.

        MOC 52: track Input (MONO IN/STEREO IN) cung xep vao day - no khong
        co nut Loa nao tren ban tron ca, nen dong ho muc phai LUON phan anh
        dung tin hieu dang vao, khong duoc tuy thuoc co Loa hay khong.  */
    const bool isBus = type == Type::Group || type == Type::FxBus
                    || type == Type::Output || type == Type::OutputBus || type == Type::Input;

    const bool timelineContent = type == Type::Audio || type == Type::Beat;
    const bool audible = ! muted.load() && (isBus || timelineContent || monitorOn.load());

    const float now = peak * gainLinear.load();
    const float held = juce::jmax (now, meterLevel.load() * meterRelease);
    meterLevel.store (audible && held > 1.0e-5f ? held : 0.0f);

    // 16/10: tung kenh cho dong ho stereo (mono thi L = R = muc chung)
    const float g = gainLinear.load();
    const float nowL = magL * g;
    const float nowR = magR * g;
    const float heldL = juce::jmax (nowL, meterLevelL.load() * meterRelease);
    const float heldR = juce::jmax (nowR, meterLevelR.load() * meterRelease);
    meterLevelL.store (audible && heldL > 1.0e-5f ? heldL : 0.0f);
    meterLevelR.store (audible && heldR > 1.0e-5f ? heldR : 0.0f);
}

//=============================================================================
//  Luu / nap trang thai track
//=============================================================================
std::unique_ptr<juce::XmlElement> Track::getState (bool includePluginState) const
{
    auto xml = std::make_unique<juce::XmlElement> ("TRACK");

    xml->setAttribute ("id",       id);
    xml->setAttribute ("uuid",     uuid);
    xml->setAttribute ("role",     (int) role);
    xml->setAttribute ("type",     (int) type);
    xml->setAttribute ("name",     name);
    xml->setAttribute ("colour",   (int) colour.getARGB());
    xml->setAttribute ("source",   (int) source.load (std::memory_order_acquire));
    xml->setAttribute ("chanMode", channelMode.load() == Chan::Stereo ? 1 : 0);
    xml->setAttribute ("inL",      inputLeft.load());
    xml->setAttribute ("inR",      inputRight.load());
    xml->setAttribute ("outTo",    outputTargetId.load());
    xml->setAttribute ("outPairs", (int) outPairMask.load());   // MOC 28
    xml->setAttribute ("fixed",    fixedTrack.load() ? 1 : 0);  // MOC 35
    xml->setAttribute ("inFrom",   inputTrackId.load());          // MOC 51
    if (type == Type::OutputBus)
    {
        xml->setAttribute ("outputSource", outputBusSourceId.load());
        const int count = getOutputBusSourceId() == -2 ? getOutputBusMixCount() : 0;
        xml->setAttribute ("outputMixCount", count);
        for (int i = 0; i < count; ++i)
            xml->setAttribute ("outputMix" + juce::String (i), getOutputBusMixSource (i));
    }
    xml->setAttribute ("gain",     gainDb.load());
    xml->setAttribute ("pan",      pan.load());
    xml->setAttribute ("mute",     muted.load() ? 1 : 0);
    xml->setAttribute ("solo",     soloed.load() ? 1 : 0);
    xml->setAttribute ("monitor",  monitorOn.load() ? 1 : 0);
    xml->setAttribute ("sendsOn",   allSendsOn.load() ? 1 : 0);
    xml->setAttribute ("sendTrim",  sendTrimDb.load());
    xml->setAttribute ("insertsOn", allInsertsOn.load() ? 1 : 0);
    xml->setAttribute ("file",     fileReferencePath);
    xml->setAttribute ("rowH",     rowHeight.load());
    xml->setAttribute ("waveZoom", waveformZoom.load());

    xml->addChildElement (channelEq.getState().release());
    xml->setAttribute ("bfx", getBuiltinFxString());   // 12r
    xml->addChildElement (inserts.getState (includePluginState).release());

    auto* sendsXml = xml->createNewChildElement ("SEND");

    {
        const juce::ScopedLock sl (sendLock);
        for (int i = 0; i < numSends.load(); ++i)
        {
            auto* e = sendsXml->createNewChildElement ("SEND");
            e->setAttribute ("target",  sends[i].targetId);
            e->setAttribute ("level",   sends[i].levelDb);
            e->setAttribute ("enabled", sends[i].enabled ? 1 : 0);
            e->setAttribute ("slot",    sends[i].targetSlot);
            if (sends[i].preFader)
                e->setAttribute ("pre", 1);   // 06/10: chi ghi khi TRUOC fader
        }
    }

    return xml;
}

void Track::setState (const juce::XmlElement& xml,
                      juce::AudioFormatManager* formats,
                      juce::TimeSliceThread* readThread,
                      bool deferPluginLoading)
{
    setUuid (xml.getStringAttribute ("uuid"));
    role   = (Role) xml.getIntAttribute ("role", (int) Role::None);
    name   = xml.getStringAttribute ("name", name);
    colour = juce::Colour ((juce::uint32) xml.getIntAttribute ("colour", (int) colour.getARGB()));
    fixedTrack.store (xml.getIntAttribute ("fixed", 0) != 0);
    rowHeight   .store (juce::jlimit (minRowHeight, maxRowHeight,
                                       xml.getIntAttribute ("rowH", defaultRowHeight)));
    setWaveformZoom ((float) xml.getDoubleAttribute ("waveZoom", 1.0));

    // Loading a normal project may replace the source audio; restoring a mix
    // default deliberately never comes through this path.
    const auto path = xml.getStringAttribute ("file");
    {
        const juce::ScopedLock sl (fileLock);
        // Full state restore must not keep a previous reader when the new
        // project references missing/bad media or explicitly has no file.
        transport.setSource (nullptr);
        readerSource.reset();
        fileReadFailed.store (false, std::memory_order_release);
        loadedFileChannels = 0;
        fileReferencePath = path;
        loadedFileName = path.isNotEmpty() ? juce::File (path).getFileName()
                                           : juce::String();
    }
    if (path.isNotEmpty() && formats != nullptr && readThread != nullptr)
    {
        juce::File f (path);
        if (f.existsAsFile())
            loadFile (f, *formats, *readThread);
    }

    restoreMixState (xml, deferPluginLoading);
}

void Track::restoreMixState (const juce::XmlElement& xml, bool deferPluginLoading)
{
    channelEq.setState (xml.getChildByName ("CHANNEL_EQ"));
    setBuiltinFxString (xml.getStringAttribute ("bfx"));   // 12r: du an cu khong co -> giu mac dinh (tat)
    source.store ((Source) xml.getIntAttribute ("source", (int) source.load (std::memory_order_acquire)), std::memory_order_release);

    channelMode.store (xml.getIntAttribute ("chanMode", 1) == 1 ? Chan::Stereo : Chan::Mono);
    inputLeft     .store (xml.getIntAttribute ("inL", 0));
    inputRight    .store (xml.getIntAttribute ("inR", 1));
    outputTargetId.store (xml.getIntAttribute ("outTo", 0));

    /*  MOC 28: mac dinh 1 = cap cong 1/2. Du an cu khong co thuoc tinh nay
        thi ve dung hanh vi truoc day (ra cap dau tien), khong ai mat tieng. */
    outPairMask.store ((juce::uint32) xml.getIntAttribute ("outPairs", 1));
    inputTrackId.store (xml.getIntAttribute ("inFrom", 0));
    setOutputBusSourceId (xml.getIntAttribute ("outputSource", 0));
    if (type == Type::OutputBus && xml.getIntAttribute ("outputSource", 0) == -2)
    {
        juce::Array<int> sources;
        const int count = juce::jlimit (0, maxOutputMixSources, xml.getIntAttribute ("outputMixCount", 0));
        for (int i = 0; i < count; ++i)
            sources.add (xml.getIntAttribute ("outputMix" + juce::String (i), 0));
        setOutputBusMixSources (sources);
    }

    setGainDb ((float) xml.getDoubleAttribute ("gain", 0.0));
    setPan ((float) xml.getDoubleAttribute ("pan", 0.0));
    muted     .store (xml.getIntAttribute ("mute") != 0);
    soloed    .store (xml.getIntAttribute ("solo") != 0);
    monitorOn .store (xml.getIntAttribute ("monitor", 1) != 0);
    allSendsOn  .store (xml.getIntAttribute ("sendsOn", 1) != 0);
    setSendTrimDb ((float) xml.getDoubleAttribute ("sendTrim", 0.0));
    allInsertsOn.store (xml.getIntAttribute ("insertsOn", 1) != 0);
    if (auto* insertsXml = xml.getChildByName ("INSERT"))
        inserts.setState (*insertsXml, deferPluginLoading);

    {
        const juce::ScopedLock sl (sendLock);
        numSends.store (0);

        if (auto* sendsXml = xml.getChildByName ("SEND"))
        {
            int n = 0;

            for (auto* e : sendsXml->getChildWithTagNameIterator ("SEND"))
            {
                if (n >= maxSends)
                    break;

                sends[n].targetId = e->getIntAttribute ("target");
                sends[n].levelDb  = (float) e->getDoubleAttribute ("level", -6.0);
                sends[n].enabled  = e->getIntAttribute ("enabled", 1) != 0;
                sends[n].targetSlot = e->getIntAttribute ("slot", -1);
                sends[n].preFader   = e->getIntAttribute ("pre", 0) != 0;
                ++n;
            }

            numSends.store (n);
        }
    }
}
