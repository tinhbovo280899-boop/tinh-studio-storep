# Sources and notices

JUCE 8.0.12 and its module dependency notices are retained in `third_party/JUCE`. See `third_party/JUCE/LICENSE.md` and the notices supplied with each module.

The user supplied `1_UAD_Lexicon_224_Reverb.zip`, which contains three C++ DSP implementations, factory preset data and GUI images for Lexicon 224, Teletronix LA-2A and UA 1176. Original comments, resource attribution and graphical marks are retained. This does not establish that the C++ models are recovered original manufacturer source or that the project is approved by that manufacturer.

The new JUCE processor/editor, CMake integration, build/export script and corrective changes support the user's source project. No original manufacturer binary, activation material or private key is included. VST3 interfaces and their notices are included with JUCE.
