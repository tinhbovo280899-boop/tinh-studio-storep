# T Studio — Lex224 / LA2A / 1176 1.0.0

Gói mã nguồn đã sửa gồm ba plugin độc lập: **T-Lex224-R**, **T-LA2A-TC**, **T-1176-FET**. Kèm JUCE 8.0.12, 110 factory preset và file BAT xuất VST3 Windows x64.

## Build và dùng trong Cubase

1. Giải nén **toàn bộ ZIP** vào thư mục mới, đường dẫn ngắn, ví dụ `C:\TStudio\ReverbCompressors`. Không chạy BAT trong cửa sổ xem ZIP.
2. Cài **Visual Studio 2022 hoặc Build Tools 2022**, chọn **Desktop development with C++**, MSVC x64/x86 và Windows SDK. Script cũng nhận Visual Studio 2019/2026 nếu CMake hỗ trợ generator tương ứng.
3. Cài **CMake 3.22+**, thêm vào PATH; hoặc cài công cụ CMake của Visual Studio. JUCE đã đi kèm, không cần tải Git/Python/JUCE để build.
4. Bấm đúp **`1_BUILD_AND_EXPORT_WINDOWS.bat`**. Lần đầu phải biên dịch JUCE nên có thể mất vài phút.
5. Khi hoàn tất, Explorer mở `_EXPORT\Build-...\VST3`, chứa đủ ba thư mục `.vst3`. Đường dẫn mới nhất cũng có trong `_EXPORT\LATEST_EXPORT.txt`.
6. Đóng Cubase, chép **nguyên ba thư mục `.vst3`** vào `C:\Program Files\Common Files\VST3`, rồi mở Cubase/quét plugin. Windows có thể hỏi quyền quản trị khi chép vào Program Files.

Không chỉ chép binary bên trong `Contents`. Script không tự ghi đè plugin đã cài; mỗi lần xuất có thư mục riêng. Nếu build lỗi, xem `_BUILD_LOGS\...\configure.log` và `build.log`. Các export thành công trước đó được giữ lại.

Tên và ID mới giúp bộ này tồn tại cùng plugin hãng hoặc bộ T Studio trước. Không tự chuyển session/state từ những plugin đó.

## Những phần đã sửa

**Lex224:** sửa đầu đọc Pre-delay để 0 ms thực sự đọc mẫu vừa ghi, thay vì quay cả vòng buffer; reset đầy đủ LFO/RNG; làm mượt vị trí tap khi đổi Pre-delay/Program; tính feedback từ độ dài vòng tank thực. Trước đó code dùng 85 ms ước lượng nên thời gian vang lệch lớn. Với Bass/Mid cùng đặt 3 s, ba voicing đo ở 1 kHz từ khoảng 7,35–8,75 s xuống khoảng 3,04–3,15 s. Các preset giữ nguyên giá trị, nhưng đuôi vang thay đổi theo phần sửa này. Xem phép đo và giới hạn trong `Validation/REVIEW.md`.

**LA2A:** quy đổi tốc độ tích/nhả bộ nhớ optical theo sample rate, giữ đặc tính tại 48 kHz. Đồng hồ dùng mức RMS với hằng số 300 ms, thay vì mẫu âm thanh cuối block; các chế độ Output +10/+4 có độ nhạy khác nhau.

**1176:** Meter Off đưa audio về dry; thời gian hồi chỉ thị GR nhất quán theo sample rate; VU 300 ms; sửa frame hình nút Ratio cho khớp 4:1/8:1/12:1/20:1/All Buttons. Shift-click cột Ratio chọn All Buttons. Attack ở đầu hành trình vẫn là Off theo core được gửi.

**Cả bộ:** kiểm tra sample rate, NaN/Inf, con trỏ/null và tham số; sửa phụ thuộc `M_PI`/header integer để thuận tiện MSVC; bổ sung CMake, VST3 wrapper, giao diện native, automation, lưu/khôi phục trạng thái và bypass chuyển tiếp 20 ms. Không có limiter ép audio về ±1. Tài nguyên sprite được xếp lại thành atlas nhỏ hơn, giữ nguyên từng pixel frame.

## Dùng T-Lex224-R trên FX Send

Bật **Wet Solo** để return chỉ có wet. Khi Wet Solo bật, giá trị Mix được giữ nhưng đầu ra dùng wet 100%. System Noise bật sẽ thêm nhiễu/quantization theo mô hình được gửi; tắt nếu muốn return sạch. Default hiện tắt System Noise.

Program có chín voicing trên mạng tank figure-8 của core được gửi. Nhãn hai chương trình cuối khớp panel: Room A và Constant Plate, sau đó Chorus trong danh sách. Chưa xác nhận đây là chín thuật toán riêng của hãng.

**Rear Outputs và Legacy Bug Flag chưa có nhánh DSP riêng trong core stereo được gửi.** Giá trị vẫn được lưu/recall preset; Rear Outputs được khóa trên giao diện, Legacy Bug Flag được ẩn. Các sửa an toàn luôn có hiệu lực. Immediate bỏ ramp cho giá trị thông thường; Pre-delay/tank tap vẫn được làm mượt để tránh nhảy đầu đọc. Không có chức năng Hold/freeze được bổ sung từ nhãn PCB trên ảnh.

## Phạm vi kiểm tra

Đã kiểm tra core, factory preset, state, các điều khiển GUI có hỗ trợ, bypass, lifecycle và cấp phát C++ trong luồng audio; build ba VST3 thật trên Linux và chạy host thử. Log và báo cáo đi kèm trong `Validation`.

**ZIP là mã nguồn, chưa chứa VST3 Windows build sẵn. Chưa build bằng MSVC hoặc chạy Windows/Cubase 15.** BAT/PowerShell được kiểm tra phần điều phối trên PowerShell 7/Linux, không thay thế chạy bằng cmd.exe/Windows PowerShell 5.1 trên máy Windows thật.

DSP là các triển khai C++ anh gửi, đã vá lỗi nêu trên. Chưa có bằng chứng khôi phục 100% DSP hãng hoặc âm thanh giống UAD 1:1. Core vẫn dùng mô hình reverb/compressor được gửi; chưa nghe A/B với plugin hãng/vocal thật. Giao diện dùng ảnh được gửi và control JUCE mới, không phụ thuộc backend web UA.

Plugin báo 0 sample độ trễ xử lý. Pre-delay của reverb là một phần hiệu ứng; ASIO, soundcard và chuỗi plugin vẫn góp độ trễ khi hát. Thang VU của project dùng chuẩn tham chiếu +4 tại -18 dBFS, +10 kém nhạy hơn 6 dB và +8 kém nhạy hơn 4 dB; chưa phải hiệu chuẩn đối chiếu bản hãng.

## Cấu trúc và build thủ công

- `Source/`: wrapper, giao diện, ánh xạ tham số/preset.
- `plugins/*/core/`: core DSP và factory preset C++.
- `plugins/*/presets_json/`: dữ liệu preset đầu vào.
- `Resources/`: atlas ảnh giao diện.
- `tools/Build-Windows.ps1`: phát hiện VS/CMake, build Release x64, kiểm tra đủ ba binary PE32+ x64, xuất toàn bộ bundle và manifest SHA-256.
- `tests/`, `Validation/`: regression, phép đo và bằng chứng sửa lỗi.

Target CMake: `TLex224R_VST3`, `TLA2ATC_VST3`, `TFET1176_VST3`. Có thể mở `CMakeLists.txt` trong Visual Studio hoặc chạy:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\Build-Windows.ps1 -Generator "Visual Studio 17 2022" -Parallel 2
```

Không kèm DLL hãng, dữ liệu kích hoạt, private key hoặc hệ thống license mới. Giấy phép/ghi công xem `THIRD_PARTY_NOTICES.md` và `third_party/JUCE/LICENSE.md`.
