#include "plugins/Lex224/core/UADLexicon224.h"
#include "plugins/LA2A/core/UADTeletronixLA2A.h"
#include "plugins/FET1176/core/UAD1176Compressor.h"
#include <array>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <iterator>
#include <limits>
#include <vector>
#include <type_traits>
using Lex=uad_uadlexicon224::UADLexicon224;
using LA=uad_uadteletronixla2a::UADTeletronixLA2A;
using FET=uad_uad1176compressor::UAD1176Compressor;
static int checks=0,failures=0;
#define CHECK(x) do{++checks;if(!(x)){if(failures<16)std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;}}while(false)
static auto verbPreset(){auto p=uad_uadlexicon224::kFactoryPresets[54];p.sys_noise=0;p.wet_solo=1;p.power=1;return p;}
static void zeroPredelay(){
 Lex v;auto p=verbPreset();p.predelay=0;v.setParameters(p);v.prepare(48000);
 std::array<float,512> l{},r{};l[0]=r[0]=.1f;v.processBlock(l.data(),r.data(),int(l.size()));
 double energy=0;for(float x:l)energy+=double(x)*x;
 std::printf("ZERO_PREDELAY first_512_energy=%.12g\n",energy);CHECK(energy>1.e-10);
}
static void resetReproducible(){
 Lex v;auto p=verbPreset();p.predelay=.1f;p.enh_step=.7f;p.pitch_step=.6f;p.sys_noise=1;v.prepare(48000);v.setParameters(p);
 constexpr int count=48000;std::vector<float>a(count),b(count),ar(count),br(count);a[0]=b[0]=ar[0]=br[0]=.1f;
 v.reset();v.processBlock(a.data(),ar.data(),count);v.reset();v.processBlock(b.data(),br.data(),count);
 double error=0;for(int i=0;i<count;++i)error=std::max(error,std::abs(double(a[i])-b[i]));
 std::printf("RESET_REPRODUCIBLE Lex224 max_difference=%.12g\n",error);CHECK(error==0);
}
static double opticalEnvelope(double rate){
 LA p;p.prepare(rate);p.setParameters(.8f,.3f,0,.5f,1);
 const int on=int(rate*.2),end=int(rate*1.0);std::array<float,128> x{};
 for(int start=0;start<end;){int n=std::min(128,end-start);for(int i=0;i<n;++i)x[size_t(i)]=(start+i<on)?.4f:0.f;p.processBlock(x.data(),nullptr,n);start+=n;}
 return p.getGainReductiondB();
}
static void rateMemory(){
 double a=opticalEnvelope(48000),b=opticalEnvelope(96000);
 std::printf("OPTICAL_MEMORY at48k=%.9f at96k=%.9f difference=%.9f dB\n",a,b,std::abs(a-b));CHECK(std::abs(a-b)<.03);
}
template<class T>static void vuAtZero(const char* name){
 T p;p.prepare(48000);
 if constexpr(std::is_same_v<T,LA>)p.setParameters(0,.3f,0,1,1);else p.setParameters(.3f,.6f,0,.5f,0,.333333f,1);
 std::array<float,128>x{};constexpr int count=48001;
 for(int start=0;start<count;){int n=std::min(128,count-start);for(int i=0;i<n;++i)x[size_t(i)]=.1f*std::sin(float(2*3.141592653589793*1000*(start+i)/48000.));if(start+n==count)x[size_t(n-1)]=0;p.processBlock(x.data(),nullptr,n);start+=n;}
 double vu=p.getOutputVUdB();std::printf("VU_AT_ZERO %s last_input=0 meter=%.9f dB\n",name,vu);CHECK(vu>-40&&vu<-15);
}
template<class T>static void safety(const char* name,int presets){
 for(double rate:{8000.,16000.,44100.,48000.,96000.,192000.,std::numeric_limits<double>::infinity()}){
  T p;p.prepare(rate);p.loadPreset(presets-1);std::array<float,128>l{},r{};
  for(int k=0;k<100;++k){for(int i=0;i<128;++i){l[size_t(i)]=.08f*std::sin(float((k*128+i)*.071));r[size_t(i)]=.04f*std::cos(float((k*128+i)*.053));}
   if(k==10){l[9]=std::numeric_limits<float>::infinity();r[10]=std::numeric_limits<float>::quiet_NaN();}
   p.processBlock(l.data(),r.data(),128);for(int i=0;i<128;++i)CHECK(std::isfinite(l[size_t(i)])&&std::isfinite(r[size_t(i)]));
  }
  p.reset();l.fill(0);r.fill(0);p.processBlock(l.data(),r.data(),128);for(int i=0;i<128;++i)CHECK(std::isfinite(l[size_t(i)])&&std::isfinite(r[size_t(i)]));
 }
 for(int n=0;n<presets;++n){T p;p.prepare(48000);p.loadPreset(n);std::array<float,256>l{},r{};
  for(int k=0;k<20;++k){l.fill(0);r.fill(0);if(k==0)l[0]=r[0]=.2f;p.processBlock(l.data(),r.data(),256);for(int i=0;i<256;++i)CHECK(std::isfinite(l[size_t(i)])&&std::isfinite(r[size_t(i)]));}
 }
 std::printf("SAFETY_AND_PRESETS %s count=%d completed\n",name,presets);
}
static void invalidParams(){
 const float bad=std::numeric_limits<float>::quiet_NaN();LA a;FET b;Lex c;
 a.setParameters(bad,bad,bad,bad,bad);b.setParameters(bad,bad,bad,bad,bad,bad,bad);
 auto p=verbPreset();p.bass=p.mid=p.predelay=p.program=p.mix=bad;c.setParameters(p);
 std::array<float,128>x{},y{};x[0]=y[0]=.1f;a.processBlock(x.data(),y.data(),128);b.processBlock(x.data(),y.data(),128);c.processBlock(x.data(),y.data(),128);
 for(int i=0;i<128;++i)CHECK(std::isfinite(x[size_t(i)])&&std::isfinite(y[size_t(i)]));
 c.processBlock(nullptr,nullptr,128);a.processBlock(nullptr,nullptr,128);b.processBlock(nullptr,nullptr,128);
}
static void delayConvention(){
 Lex::ModDelayLine d;d.init(64,16);
 for(int i=0;i<150;++i){d.write(float(i));CHECK(d.readInterp(0)==float(i));if(i>0)CHECK(d.readInterp(1)==float(i-1));if(i>7)CHECK(d.readInterp(7.5f)==float(i)-7.5f);}
 CHECK(d.readInterp(std::numeric_limits<float>::infinity())==0);
 std::printf("DELAY_CONVENTION zero/integer/fractional/wrap/Inf completed\n");
}
static void meterAndOff(){
 LA la;la.setParameters(0,.3f,0,.5f,1);la.reset();CHECK(la.getVUNeedleFrame()==65);
 FET fet;fet.setParameters(.3f,.6f,.5f,.5f,0,1,1);fet.reset();CHECK(fet.getVUNeedleFrame()==67);
 fet.setParameters(1,1,1,1,1,0,1);std::array<float,128>x{};x.fill(.123f);fet.processBlock(x.data(),nullptr,128);for(float value:x)CHECK(value==.123f);
 std::printf("METERS GR-zero calibration and FET Meter-Off dry bypass completed\n");
}
static void tankStress(){
 double peak=0;
 for(double rate:{8000.,48000.,96000.})for(int program=0;program<9;++program){
  Lex v;auto preset=verbPreset();preset.program=float(program)/8;preset.bass=preset.mid=preset.treble_decay=1;preset.enh_step=preset.pitch_step=1;preset.diffusion=1;preset.predelay=0;
  v.prepare(rate);v.setParameters(preset);v.reset();std::array<float,128>l{},r{};std::uint32_t rng=123;
  const int length=int(rate*2);
  for(int start=0;start<length;){const int n=std::min(128,length-start);
   for(int i=0;i<n;++i){rng=1664525u*rng+1013904223u;l[size_t(i)]=start<int(rate*.5)?float(double(rng)/4294967296.-.5)*.1f:0;r[size_t(i)]=-l[size_t(i)];}
   v.processBlock(l.data(),r.data(),n);
   for(int i=0;i<n;++i){CHECK(std::isfinite(l[size_t(i)])&&std::isfinite(r[size_t(i)]));peak=std::max({peak,std::abs(double(l[size_t(i)])),std::abs(double(r[size_t(i)]))});}
   start+=n;
  }
 }
 CHECK(peak<10);std::printf("TANK_STRESS nine programs, 8/48/96 kHz, maximum decay/diffusion/modulation peak=%.9f completed\n",peak);
}
int main(int argc,char** argv){
 zeroPredelay();resetReproducible();rateMemory();vuAtZero<LA>("LA2A");vuAtZero<FET>("1176");
 if(argc<2||std::strcmp(argv[1],"--baseline")!=0){delayConvention();meterAndOff();safety<Lex>("Lex224",55);safety<LA>("LA2A",29);safety<FET>("1176",26);invalidParams();tankStress();}
 std::printf("CORE REGRESSION: %d checks, %d failures\n",checks,failures);return failures?1:0;
}
