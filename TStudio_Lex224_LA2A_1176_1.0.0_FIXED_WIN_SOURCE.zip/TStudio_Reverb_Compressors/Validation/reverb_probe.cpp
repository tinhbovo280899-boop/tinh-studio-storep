#include "plugins/Lex224/core/UADLexicon224.h"
#include <vector>
extern "C" void renderImpulse(float* output,int frames,int rate,int program,float seconds){
 using namespace uad_uadlexicon224;UADLexicon224 v;auto p=kFactoryPresets[54];
 p.program=float(program)/8;p.bass=float(std::log(seconds/.6)/std::log(70/.6));p.mid=float(std::log(seconds/.25)/std::log(26/.25));
 p.predelay=.02f;p.treble_decay=1;p.crossover=.5f;p.diffusion=.5f;p.sys_noise=0;p.enh_step=0;p.pitch_step=0;p.decay_opt=0;p.wet_solo=1;p.mix=1;
 v.prepare(rate);v.setParameters(p);v.reset();std::vector<float> l(size_t(frames),0),r(size_t(frames),0);l[0]=r[0]=.1f;
 for(int start=0;start<frames;start+=128)v.processBlock(l.data()+start,r.data()+start,std::min(128,frames-start));
 for(int i=0;i<frames;++i){output[2*i]=l[size_t(i)];output[2*i+1]=r[size_t(i)];}
}
