#include "UAD1176Compressor.h"

namespace uad_uad1176compressor {

static const double kRatioValues[5] = { 4.0, 8.0, 12.0, 20.0, 16.0 };
static const double kThresholdOffsetsdB[5] = { -18.0, -15.5, -13.5, -11.0, -21.0 };

void UAD1176Compressor::prepare(double sampleRate) {
    sampleRate_ = std::isfinite(sampleRate)&&sampleRate>=8000.0&&sampleRate<=768000.0?sampleRate:48000.0;
    grRelease_=std::pow(.998,48000.0/sampleRate_);
    vuCoefficient_=std::exp(-1.0/(.300*sampleRate_));
    reset();
}

void UAD1176Compressor::reset() {
    fetEnv_ = 0.0;
    currentGRdB_ = 0.0;
    currentVUdB_ = -60.0;
    vuEnvelope_=0;
}

void UAD1176Compressor::loadPreset(int index) {
    int count = sizeof(kFactoryPresets) / sizeof(kFactoryPresets[0]);
    if (index < 0 || index >= count) return;
    const auto& p = kFactoryPresets[index];
    setParameters(p.input, p.output, p.attack, p.release, p.ratio, p.meter, p.power);
}

void UAD1176Compressor::setParameters(float inputNorm, float outputNorm, float attackNorm, float releaseNorm,
                                      float ratioNorm, float meterNorm, float powerNorm) {
    input_ = std::isfinite(inputNorm) ? std::clamp(inputNorm, 0.0f, 1.0f) : input_;
    output_ = std::isfinite(outputNorm) ? std::clamp(outputNorm, 0.0f, 1.0f) : output_;
    attack_ = std::isfinite(attackNorm) ? std::clamp(attackNorm, 0.0f, 1.0f) : attack_;
    release_ = std::isfinite(releaseNorm) ? std::clamp(releaseNorm, 0.0f, 1.0f) : release_;
    ratio_ = std::isfinite(ratioNorm) ? std::clamp(ratioNorm, 0.0f, 1.0f) : ratio_;
    meter_ = std::isfinite(meterNorm) ? std::clamp(meterNorm, 0.0f, 1.0f) : meter_;
    power_ = std::isfinite(powerNorm) ? std::clamp(powerNorm, 0.0f, 1.0f) : power_;

    ratioIdx_ = std::clamp((int)std::round(ratio_ * 4.0f), 0, 4);
}

void UAD1176Compressor::processBlock(float* left, float* right, int numSamples) {
    if(left==nullptr||numSamples<=0)return;
    for(int i=0;i<numSamples;++i){left[i]=std::isfinite(left[i])?std::clamp(left[i],-64.f,64.f):0.f;if(right)right[i]=std::isfinite(right[i])?std::clamp(right[i],-64.f,64.f):0.f;}
    if (power_ < 0.5f || meter_ < 0.1f) {
        currentGRdB_ = 0.0;
        currentVUdB_ = -60.0;
        return;
    }

    // Input knob (-36 dB .. +18 dB drive into FET stage)
    double inDrivedB = (static_cast<double>(input_) - 0.30) * 54.0;
    double inDriveLin = std::pow(10.0, inDrivedB / 20.0);

    // Output knob (-36 dB .. +18 dB Class-A/AB line amp level)
    double outGaindB = (static_cast<double>(output_) - 0.60) * 48.0;
    double outGainLin = std::pow(10.0, outGaindB / 20.0);

    // Attack: 800 us (0.0008s) at attack_=0.02 down to 20 us (0.00002s) at attack_=1.0
    bool compEnabled = (attack_ >= 0.01f);
    double attackSec = 0.00080 * std::pow(0.00002 / 0.00080, static_cast<double>(attack_));
    double attCoeff = std::exp(-1.0 / std::max(1.0, attackSec * sampleRate_));

    // Release: 1.1s at release_=0.0 down to 0.050s at release_=1.0
    double releaseSec = 1.100 * std::pow(0.050 / 1.100, static_cast<double>(release_));
    double relCoeff = std::exp(-1.0 / (releaseSec * sampleRate_));

    double ratio = kRatioValues[ratioIdx_];
    double threshdB = kThresholdOffsetsdB[ratioIdx_];
    double threshLin = std::pow(10.0, threshdB / 20.0);
    bool allButtonMode = (ratioIdx_ == 4);

    for (int i = 0; i < numSamples; ++i) {
        double L = static_cast<double>(left[i]) * inDriveLin;
        double R = (right ? static_cast<double>(right[i]) : left[i]) * inDriveLin;

        double grLin = 1.0;
        if (compEnabled) {
            double det = std::max(std::abs(L), std::abs(R));
            if (det > fetEnv_) {
                fetEnv_ = attCoeff * fetEnv_ + (1.0 - attCoeff) * det;
            } else {
                fetEnv_ = relCoeff * fetEnv_ + (1.0 - relCoeff) * det;
            }

            if (fetEnv_ > threshLin) {
                double overdB = 20.0 * std::log10(fetEnv_ / threshLin);
                double grdB = overdB * (1.0 / ratio - 1.0);
                if (allButtonMode) {
                    // All-Button "British Mode" plateau nonlinearity
                    grdB *= 1.18;
                }
                grLin = std::pow(10.0, grdB / 20.0);
                currentGRdB_ = -grdB;
            } else {
                currentGRdB_ *= grRelease_;
            }
        } else {
            currentGRdB_ = 0.0;
        }

        L *= grLin;
        R *= grLin;

        // FET + Class-A/AB Output Transformer Harmonic Saturation (extra grit in All-Button mode)
        double satDrive = allButtonMode ? 1.45 : 0.92;
        auto fetLineStage = [&](double x) -> double {
            double v = x * satDrive;
            double asym = std::tanh(v) + (allButtonMode ? 0.055 : 0.022) * v * v / (1.0 + v * v);
            return asym / satDrive;
        };

        L = fetLineStage(L) * outGainLin;
        R = fetLineStage(R) * outGainLin;

        double outAbs = 0.5 * (std::abs(L) + std::abs(R));
        vuEnvelope_=vuCoefficient_*vuEnvelope_+(1-vuCoefficient_)*outAbs*outAbs;
        currentVUdB_=10.0*std::log10(std::max(1e-12,vuEnvelope_));

        left[i] = static_cast<float>(L);
        if (right) right[i] = static_cast<float>(R);
    }
}

int UAD1176Compressor::getVUNeedleFrame() const {
    if (power_ < 0.5f || meter_ < 0.1f) return 0;
    // Frame 67 aligns with the 0 VU mark of the supplied artwork.
    if (meter_ >= 0.85f) {
        return std::clamp((int)std::round(67.0*std::pow(10.0,-currentGRdB_/20.0)),0,100);
    }
    // Project calibration: +4 is 0 VU at -18 dBFS; +8 is 4 dB less sensitive.
    const double vu=currentVUdB_+(meter_>.5f?14.0:18.0);
    const double frame=67.0*std::pow(10.0,vu/20.0);
    return std::clamp((int)std::round(frame),0,100);
}

} // namespace uad_uad1176compressor
