#pragma once
#include <cmath>
#include <algorithm>
#include "Presets.h"

namespace uad_uad1176compressor {

/**
 * UADx UA 1176 Classic FET Compressor — Complete C++ DSP Implementation
 *
 * Models the UREI / Universal Audio 1176LN Blackface Solid-State FET Limiting Amplifier:
 * 1. Input T-Pad Attenuator & UTC O-12 Input Transformer (`input` 0.0..1.0):
 *    - Simultaneously drives signal into the FET gain reduction stage and lowers the effective
 *      compression threshold.
 * 2. Ultra-Fast Field-Effect Transistor (FET) Feedback Gain Reduction Stage:
 *    - `attack`: 20 microseconds (fastest, dial 7 / norm 1.0) to 800 microseconds (slowest, dial 1 / norm 0.02).
 *      When `attack < 0.01`, engages **Attack OFF (Compression Bypass)** mode so audio passes
 *      solely through the FET bias + Class-A/AB transformer preamp/line stages!
 *    - `release`: 50 ms (fastest, dial 7 / norm 1.0) to 1100 ms (slowest, dial 1 / norm 0.0),
 *      with program-dependent fast transient recovery.
 *    - `ratio`: 5 states:
 *      - `0.00` (Index 0): **4:1** Moderate compression with gentle FET knee
 *      - `0.25` (Index 1): **8:1** Firm compression
 *      - `0.50` (Index 2): **12:1** Limiting
 *      - `0.75` (Index 3): **20:1** Hard limiting (higher threshold)
 *      - `1.00` (Index 4): **All-Button Mode ("British Mode")** — all 4 ratio buttons depressed simultaneously
 *        (Shift+Click in GUI), producing an aggressive ~12:1..20:1 plateau knee, shifted FET bias point,
 *        explosive room/drum pumping, and rich FET odd/even harmonic overdrive!
 * 3. Class-A/AB Line Output Amplifier & Bill Putnam Output Transformer (`output` 0.0..1.0)
 * 4. 101-Frame VU/GR Meter Pointer (`getVUNeedleFrame()` 0..100 matching `UA_1176_meter_POINTER-ON.png`)
 */
class UAD1176Compressor {
public:
    UAD1176Compressor() { prepare(48000.0); }

    void prepare(double sampleRate);
    void reset();

    void setParameters(float inputNorm, float outputNorm, float attackNorm, float releaseNorm,
                       float ratioNorm, float meterNorm, float powerNorm);
    void loadPreset(int index);

    void processBlock(float* left, float* right, int numSamples);

    double getGainReductiondB() const { return currentGRdB_; }
    double getOutputVUdB() const { return currentVUdB_; }
    int getRatioIndex() const { return ratioIdx_; } // 0=4:1, 1=8:1, 2=12:1, 3=20:1, 4=All-Button
    int getVUNeedleFrame() const;                   // 0..100 matching UA_1176_meter_POINTER-ON.png

private:
    double sampleRate_ = 48000.0;

    float input_ = 0.35f;
    float output_ = 0.65f;
    float attack_ = 0.50f;
    float release_ = 0.70f;
    float ratio_ = 0.0f;
    float meter_ = 1.0f;
    float power_ = 1.0f;

    int ratioIdx_ = 0;
    double fetEnv_ = 0.0;
    double currentGRdB_ = 0.0;
    double currentVUdB_ = -60.0;
    double vuEnvelope_=0.0,vuCoefficient_=0.0,grRelease_=0.998;
};

} // namespace uad_uad1176compressor
