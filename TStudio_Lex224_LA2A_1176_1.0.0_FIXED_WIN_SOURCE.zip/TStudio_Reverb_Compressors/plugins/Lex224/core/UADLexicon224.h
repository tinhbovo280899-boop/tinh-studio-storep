#pragma once
#include <cmath>
#include <vector>
#include <string>
#include <algorithm>
#include <cstdint>
#include "Presets.h"

namespace uad_uadlexicon224 {
inline constexpr double kPi=3.141592653589793238462643383279502884;

/**
 * UADx Lexicon 224 Digital Reverb — Complete C++ DSP Implementation
 *
 * Models the classic 1978 Lexicon 224 Digital Reverberator:
 * - All 9 Hardware Programs (1..8 + Hidden Program 9 Chorus):
 *   0: Small Concert Hall B
 *   1: Vocal Plate
 *   2: Large Concert Hall B
 *   3: Acoustic Chamber
 *   4: Percussion Plate A
 *   5: Small Concert Hall A
 *   6: Room A
 *   7: Constant Density Plate A
 *   8: Chorus (Shift+Click hidden program)
 * - 4-Stage Input Diffusion Allpass Cascade (`diffusion` 1..64)
 * - Pre-Delay Line (`predelay` up to 250 ms) + Distance/Depth Early-Reflection Network (`depth`)
 * - Modulated Figure-8 Reverberation Tank with Independent Bass & Mid Decay (`bass` 0.6s..70s,
 *   `mid` 0.2s..26s) split at variable `crossover` (100 Hz .. 6.4 kHz) + `treble_decay` HF roll-off
 * - Mode Enhancement (`enh_step` 0..15) & Pitch Shift (`pitch_step` 0..15) tank delay modulation
 * - Decay Optimization (`decay_opt` + `opt_step` 0..15) dynamic transient tail control
 * - Authentic 12-bit Floating-Point Step-Gain AD/DA Converter & Analog Transformer + System Noise (`sys_noise`)
 */
class UADLexicon224 {
public:
    struct AllpassSection {
        std::vector<float> buf;
        int writeIdx = 0;
        int delaySamples = 100;
        float g = 0.65f;

        void init(int maxSamples, int del, float coeff) {
            buf.assign(std::max(16, maxSamples), 0.0f);
            delaySamples = std::clamp(del, 4, (int)buf.size() - 2);
            writeIdx = 0;
            g = coeff;
        }
        void clear() { std::fill(buf.begin(), buf.end(), 0.0f); writeIdx = 0; }

        inline float process(float x) {
            int rIdx = writeIdx - delaySamples;
            if (rIdx < 0) rIdx += (int)buf.size();
            float d = buf[rIdx];
            float v = x - g * d;
            buf[writeIdx] = v;
            if (++writeIdx >= (int)buf.size()) writeIdx = 0;
            return d + g * v;
        }
    };

    struct ModDelayLine {
        std::vector<float> buf;
        int writeIdx = 0;
        int baseDelay = 1000;

        void init(int maxSamples, int baseDel) {
            buf.assign(std::max(64, maxSamples), 0.0f);
            baseDelay = std::clamp(baseDel, 16, (int)buf.size() - 32);
            writeIdx = 0;
        }
        void clear() { std::fill(buf.begin(), buf.end(), 0.0f); writeIdx = 0; }

        inline void write(float x) {
            buf[writeIdx] = x;
            if (++writeIdx >= (int)buf.size()) writeIdx = 0;
        }

        inline float readInterp(float delaySamples) const {
            if (buf.empty() || !std::isfinite(delaySamples)) return 0.0f;
            delaySamples=std::clamp(delaySamples,0.0f,float(buf.size()-2));
            // write() has already advanced the pointer. Zero delay is the
            // sample just written, rather than one complete ring-buffer lap.
            float rPos = (float)(writeIdx-1) - delaySamples;
            while (rPos < 0.0f) rPos += (float)buf.size();
            while (rPos >= (float)buf.size()) rPos -= (float)buf.size();
            int idx0 = (int)rPos;
            int idx1 = (idx0 + 1) % (int)buf.size();
            float frac = rPos - (float)idx0;
            return buf[idx0] + frac * (buf[idx1] - buf[idx0]);
        }
    };

    UADLexicon224() { prepare(48000.0); }

    void prepare(double sampleRate);
    void reset();

    void setParameters(const FactoryPreset& p);
    void loadPreset(int index);

    void processBlock(float* left, float* right, int numSamples);

    // Getters for GUI LED display and 11-frame Input Gain LED meters
    int getProgramIndex() const { return programIdx_; }
    double getMidDecaySeconds() const { return midDecaySec_; }
    double getBassDecaySeconds() const { return bassDecaySec_; }
    int getGainMeterFrameL() const { return meterFrameL_; } // 0..10
    int getGainMeterFrameR() const { return meterFrameR_; } // 0..10

private:
    void updateParameters();

    double sampleRate_ = 48000.0;
    FactoryPreset params_ = {
        "Default", 0.0f, 0.5f, 0.5f, 0.45f, 0.65f, 0.35f, 0.1f, 0.65f,
        1.0f, 1.0f, 0.0f, 0.5f, 0.0f, 0.2667f, 0.1333f, 0.0f, 0.2667f,
        0.5f, 0.5f, 0.5f, 0.5f, 1.0f, 1.0f, 1.0f
    };

    int programIdx_ = 0;
    double bassDecaySec_ = 2.2;
    double midDecaySec_ = 1.8;
    double crossoverHz_ = 800.0;
    double trebleCutoffHz_ = 6500.0;
    double predelayMs_ = 24.0;

    // Pre-delay + 4 Input Diffusers
    ModDelayLine predelayL_, predelayR_;
    AllpassSection inDiffL_[4], inDiffR_[4];

    // Figure-8 Tank: 2 Tank Allpasses + 2 Modulated Delay Lines per side
    AllpassSection tankAp1L_, tankAp2L_;
    AllpassSection tankAp1R_, tankAp2R_;
    ModDelayLine tankDel1L_, tankDel2L_;
    ModDelayLine tankDel1R_, tankDel2R_;

    // Split Bass/Mid Crossover States & Treble Roll-off States inside tank
    float lpStateL_ = 0.0f, lpStateR_ = 0.0f;
    float trebleLpL_ = 0.0f, trebleLpR_ = 0.0f;

    float tankFeedbackL_ = 0.0f, tankFeedbackR_ = 0.0f;
    double lfoPhase1_ = 0.0, lfoPhase2_ = 1.57;
    uint32_t rngState_ = 0x12345678u;

    int meterFrameL_ = 0;
    int meterFrameR_ = 0;
    double delaySmoothingCoefficient_=0;
    double predelayCurrent_=0,tankScaleCurrent_=1;
};

} // namespace uad_uadlexicon224
