#include "UADLexicon224.h"

namespace uad_uadlexicon224 {

struct ProgramRoomScale {
    float sizeScale;
    float diffGain;
    float earlyBlend;
    float modDepthSamples;
};

// 9 Lexicon 224 Programs (Small Hall B, Vocal Plate, Large Hall B, Chamber, Perc Plate A, Small Hall A, Const Plate A, Resonant Chord, Chorus)
static const ProgramRoomScale kProgramScales[9] = {
    { 0.78f, 0.68f, 0.25f,  8.5f }, // 0: Small Concert Hall B
    { 0.65f, 0.74f, 0.15f,  6.0f }, // 1: Vocal Plate
    { 1.18f, 0.70f, 0.22f, 11.5f }, // 2: Large Concert Hall B
    { 0.85f, 0.65f, 0.30f,  7.0f }, // 3: Acoustic Chamber
    { 0.58f, 0.76f, 0.12f,  5.0f }, // 4: Percussion Plate A
    { 0.82f, 0.66f, 0.28f,  7.5f }, // 5: Small Concert Hall A
    { 0.72f, 0.75f, 0.18f,  6.5f }, // 6: Room A
    { 0.95f, 0.82f, 0.20f,  3.5f }, // 7: Constant Density Plate A
    { 0.35f, 0.55f, 0.65f, 22.0f }  // 8: Chorus
};

void UADLexicon224::prepare(double sampleRate) {
    sampleRate_ = std::isfinite(sampleRate)&&sampleRate>=8000.0&&sampleRate<=768000.0?sampleRate:48000.0;
    double scale = sampleRate_ / 48000.0;
    delaySmoothingCoefficient_=1.0-std::exp(-1.0/(.020*sampleRate_));

    predelayL_.init((int)(0.35 * sampleRate_) + 64, (int)(0.024 * sampleRate_));
    predelayR_.init((int)(0.35 * sampleRate_) + 64, (int)(0.024 * sampleRate_));

    const int inDelL[4] = { 142, 107, 379, 277 };
    const int inDelR[4] = { 149, 113, 389, 283 };
    for (int i = 0; i < 4; ++i) {
        inDiffL_[i].init((int)(inDelL[i] * scale * 2.0) + 32, (int)(inDelL[i] * scale), (i < 2) ? 0.75f : 0.625f);
        inDiffR_[i].init((int)(inDelR[i] * scale * 2.0) + 32, (int)(inDelR[i] * scale), (i < 2) ? 0.75f : 0.625f);
    }

    tankAp1L_.init((int)(908 * scale * 2.0) + 64, (int)(672 * scale), -0.70f);
    tankAp2L_.init((int)(2656 * scale * 2.0) + 64, (int)(1800 * scale), 0.50f);
    tankAp1R_.init((int)(956 * scale * 2.0) + 64, (int)(708 * scale), -0.70f);
    tankAp2R_.init((int)(2712 * scale * 2.0) + 64, (int)(1856 * scale), 0.50f);

    tankDel1L_.init((int)(6500 * scale) + 128, (int)(4453 * scale));
    tankDel2L_.init((int)(5500 * scale) + 128, (int)(3720 * scale));
    tankDel1R_.init((int)(6500 * scale) + 128, (int)(4217 * scale));
    tankDel2R_.init((int)(5500 * scale) + 128, (int)(3163 * scale));

    updateParameters();
    reset();
}

void UADLexicon224::reset() {
    predelayL_.clear();
    predelayR_.clear();
    for (int i = 0; i < 4; ++i) {
        inDiffL_[i].clear();
        inDiffR_[i].clear();
    }
    tankAp1L_.clear(); tankAp2L_.clear();
    tankAp1R_.clear(); tankAp2R_.clear();
    tankDel1L_.clear(); tankDel2L_.clear();
    tankDel1R_.clear(); tankDel2R_.clear();
    lpStateL_ = lpStateR_ = 0.0f;
    trebleLpL_ = trebleLpR_ = 0.0f;
    tankFeedbackL_ = tankFeedbackR_ = 0.0f;
    meterFrameL_ = meterFrameR_ = 0;
    lfoPhase1_=0.0; lfoPhase2_=1.57; rngState_=0x12345678u;
    predelayCurrent_=predelayMs_*.001*sampleRate_;
    tankScaleCurrent_=(sampleRate_/48000.0)*kProgramScales[programIdx_].sizeScale;
}

void UADLexicon224::loadPreset(int index) {
    int count = sizeof(kFactoryPresets) / sizeof(kFactoryPresets[0]);
    if (index < 0 || index >= count) return;
    setParameters(kFactoryPresets[index]);
}

void UADLexicon224::setParameters(const FactoryPreset& p) {
    // Preserve the previous valid setting when a host supplies NaN/Inf.
    #define COPY_PARAMETER(field) if(std::isfinite(p.field))params_.field=std::clamp(p.field,0.f,1.f)
    COPY_PARAMETER(program);COPY_PARAMETER(bass);COPY_PARAMETER(mid);COPY_PARAMETER(crossover);
    COPY_PARAMETER(treble_decay);COPY_PARAMETER(depth);COPY_PARAMETER(predelay);COPY_PARAMETER(diffusion);
    COPY_PARAMETER(immediate);COPY_PARAMETER(sys_noise);COPY_PARAMETER(rear_outs);COPY_PARAMETER(mix);
    COPY_PARAMETER(wet_solo);COPY_PARAMETER(enh_step);COPY_PARAMETER(pitch_step);COPY_PARAMETER(decay_opt);
    COPY_PARAMETER(opt_step);COPY_PARAMETER(in_gain_l);COPY_PARAMETER(in_gain_r);COPY_PARAMETER(out_lvl_l);
    COPY_PARAMETER(out_lvl_r);COPY_PARAMETER(link);COPY_PARAMETER(bug_fixes);COPY_PARAMETER(power);
    #undef COPY_PARAMETER
    updateParameters();
}

void UADLexicon224::updateParameters() {
    programIdx_ = std::clamp((int)std::round(params_.program * 8.0f), 0, 8);
    bassDecaySec_ = 0.6 * std::pow(70.0 / 0.6, (double)std::clamp(params_.bass, 0.0f, 1.0f));
    midDecaySec_ = 0.25 * std::pow(26.0 / 0.25, (double)std::clamp(params_.mid, 0.0f, 1.0f));
    crossoverHz_ = 100.0 * std::pow(6400.0 / 100.0, (double)std::clamp(params_.crossover, 0.0f, 1.0f));
    trebleCutoffHz_ = 800.0 * std::pow(15000.0 / 800.0, (double)std::clamp(params_.treble_decay, 0.0f, 1.0f));
    predelayMs_ = 250.0 * (double)std::clamp(params_.predelay, 0.0f, 1.0f);

    float diffNorm = std::clamp(params_.diffusion, 0.0f, 1.0f);
    float diffG = 0.20f + 0.58f * diffNorm * kProgramScales[programIdx_].diffGain / 0.70f;
    for (int i = 0; i < 4; ++i) {
        inDiffL_[i].g = diffG;
        inDiffR_[i].g = diffG;
    }
}

void UADLexicon224::processBlock(float* left, float* right, int numSamples) {
    if(left==nullptr||numSamples<=0)return;
    for(int i=0;i<numSamples;++i){left[i]=std::isfinite(left[i])?std::clamp(left[i],-64.f,64.f):0.f;if(right)right[i]=std::isfinite(right[i])?std::clamp(right[i],-64.f,64.f):0.f;}
    if (params_.power < 0.5f) {
        meterFrameL_ = meterFrameR_ = 0;
        return;
    }

    const auto& prog = kProgramScales[programIdx_];
    double scale = (sampleRate_ / 48000.0) * prog.sizeScale;

    float inGainL = std::pow(10.0f, (params_.in_gain_l - 0.5f) * 24.0f / 20.0f);
    float inGainR = (params_.link >= 0.5f) ? inGainL : std::pow(10.0f, (params_.in_gain_r - 0.5f) * 24.0f / 20.0f);
    float outGainL = std::pow(10.0f, (params_.out_lvl_l - 0.5f) * 24.0f / 20.0f);
    float outGainR = (params_.link >= 0.5f) ? outGainL : std::pow(10.0f, (params_.out_lvl_r - 0.5f) * 24.0f / 20.0f);

    float wetMix = (params_.wet_solo >= 0.5f) ? 1.0f : std::clamp(params_.mix, 0.0f, 1.0f);
    float dryMix = (params_.wet_solo >= 0.5f) ? 0.0f : (1.0f - wetMix);

    // Calculate Bass and Mid loop feedback gains from RT60
    // One decay factor is applied per branch. Use the average actual branch
    // delay, including the two tank allpasses, rather than a fictitious 85 ms.
    const double apSamples=.5*(tankAp1L_.delaySamples+tankAp2L_.delaySamples+tankAp1R_.delaySamples+tankAp2R_.delaySamples);
    double loopTimeSec=(apSamples+.5*(4453+3720+4217+3163)*scale)/sampleRate_;
    float gMid = (float)std::pow(10.0, -3.0 * loopTimeSec / std::max(0.15, midDecaySec_));
    float gBass = (float)std::pow(10.0, -3.0 * loopTimeSec / std::max(0.20, bassDecaySec_));
    gMid = std::clamp(gMid, 0.0f, 0.9995f);
    gBass = std::clamp(gBass, 0.0f, 0.9995f);

    // Crossover 1-pole coefficient & Treble Roll-off 1-pole coefficient
    float xoverAlpha = (float)(1.0 - std::exp(-2.0 * kPi * crossoverHz_ / sampleRate_));
    float trebleAlpha = (float)(1.0 - std::exp(-2.0 * kPi * trebleCutoffHz_ / sampleRate_));

    float predelaySamp = (float)(predelayMs_ * 0.001 * sampleRate_);
    float depthBlend = std::clamp(params_.depth, 0.0f, 1.0f);

    double lfoInc1 = 2.0 * kPi * (0.55 + 0.95 * params_.enh_step) / sampleRate_;
    double lfoInc2 = 2.0 * kPi * (0.71 + 1.15 * params_.pitch_step) / sampleRate_;
    float modExcursion = prog.modDepthSamples * float(sampleRate_/48000.0) * (0.4f + 0.6f * (params_.enh_step + params_.pitch_step));

    bool sysNoiseActive = (params_.sys_noise >= 0.5f);
    bool decayOptActive = (params_.decay_opt >= 0.5f);

    float peakInL = 0.0f, peakInR = 0.0f;

    for (int i = 0; i < numSamples; ++i) {
        float dryL = left[i] * inGainL;
        float dryR = (right ? right[i] : left[i]) * inGainR;
        peakInL = std::max(peakInL, std::abs(dryL));
        peakInR = std::max(peakInR, std::abs(dryR));

        float inMonoL = dryL;
        float inMonoR = dryR;

        // 12-bit Floating-Point Step-Gain AD Converter quantization + System Noise when enabled
        if (sysNoiseActive) {
            rngState_ = rngState_ * 1664525u + 1013904223u;
            float dither = ((float)(rngState_ & 0xFFFF) / 32768.0f - 1.0f) * 1.8e-5f;
            inMonoL = std::round(inMonoL * 2048.0f) / 2048.0f + dither;
            inMonoR = std::round(inMonoR * 2048.0f) / 2048.0f - dither;
        }

        // Pre-Delay
        predelayCurrent_+=delaySmoothingCoefficient_*(predelaySamp-predelayCurrent_);
        tankScaleCurrent_+=delaySmoothingCoefficient_*(scale-tankScaleCurrent_);
        predelayL_.write(inMonoL);
        predelayR_.write(inMonoR);
        float pdL = predelayL_.readInterp(float(predelayCurrent_));
        float pdR = predelayR_.readInterp(float(predelayCurrent_));

        // 4-Stage Input Diffusion Allpass Cascade
        float diffL = pdL, diffR = pdR;
        for (int s = 0; s < 4; ++s) {
            diffL = inDiffL_[s].process(diffL);
            diffR = inDiffR_[s].process(diffR);
        }

        // Dynamic Decay Optimization (slightly damps feedback during hot input transients)
        float optDuck = 1.0f;
        if (decayOptActive) {
            float inEnv = 0.5f * (std::abs(dryL) + std::abs(dryR));
            optDuck = 1.0f - std::clamp(inEnv * params_.opt_step * 0.18f, 0.0f, 0.12f);
        }

        // LFO Modulation for Figure-8 Tank Delay Lines
        lfoPhase1_ += lfoInc1;
        if (lfoPhase1_ > 2.0 * kPi) lfoPhase1_ -= 2.0 * kPi;
        lfoPhase2_ += lfoInc2;
        if (lfoPhase2_ > 2.0 * kPi) lfoPhase2_ -= 2.0 * kPi;

        float mod1 = (float)std::sin(lfoPhase1_) * modExcursion;
        float mod2 = (float)std::cos(lfoPhase2_) * modExcursion;

        // Left Tank Branch (fed from Right Tank Feedback)
        float tL = diffL + tankFeedbackR_;
        tL = tankAp1L_.process(tL);
        tankDel1L_.write(tL);
        float d1L = tankDel1L_.readInterp((float)(4453.0 * tankScaleCurrent_) + mod1);

        // Split Bass/Mid Crossover + Treble Damping in Left Tank
        lpStateL_ += xoverAlpha * (d1L - lpStateL_);
        float hpL = d1L - lpStateL_;
        float splitL = (lpStateL_ * gBass + hpL * gMid) * optDuck;
        trebleLpL_ += trebleAlpha * (splitL - trebleLpL_);

        float tL2 = tankAp2L_.process(trebleLpL_);
        tankDel2L_.write(tL2);
        float d2L = tankDel2L_.readInterp((float)(3720.0 * tankScaleCurrent_) - mod2);

        // Right Tank Branch (fed from Left Tank Feedback)
        float tR = diffR + tankFeedbackL_;
        tR = tankAp1R_.process(tR);
        tankDel1R_.write(tR);
        float d1R = tankDel1R_.readInterp((float)(4217.0 * tankScaleCurrent_) + mod2);

        // Split Bass/Mid Crossover + Treble Damping in Right Tank
        lpStateR_ += xoverAlpha * (d1R - lpStateR_);
        float hpR = d1R - lpStateR_;
        float splitR = (lpStateR_ * gBass + hpR * gMid) * optDuck;
        trebleLpR_ += trebleAlpha * (splitR - trebleLpR_);

        float tR2 = tankAp2R_.process(trebleLpR_);
        tankDel2R_.write(tR2);
        float d2R = tankDel2R_.readInterp((float)(3163.0 * tankScaleCurrent_) - mod1);

        tankFeedbackL_ = d2L;
        tankFeedbackR_ = d2R;

        // Multi-tap stereo output summation (Lexicon 224 accumulator taps + Depth early/late balance)
        float lateL = 0.6f * (d1R + d2L - 0.35f * d1L);
        float lateR = 0.6f * (d1L + d2R - 0.35f * d1R);
        float wetL = (1.0f - 0.35f * depthBlend) * diffL * prog.earlyBlend + lateL;
        float wetR = (1.0f - 0.35f * depthBlend) * diffR * prog.earlyBlend + lateR;

        left[i] = (dryL * dryMix + wetL * wetMix) * outGainL;
        if (right) right[i] = (dryR * dryMix + wetR * wetMix) * outGainR;
    }

    meterFrameL_ = std::clamp((int)std::round(std::pow(std::clamp(peakInL, 0.0f, 1.0f), 0.5f) * 10.0f), 0, 10);
    meterFrameR_ = std::clamp((int)std::round(std::pow(std::clamp(peakInR, 0.0f, 1.0f), 0.5f) * 10.0f), 0, 10);
}

} // namespace uad_uadlexicon224
