#pragma once
#include <cmath>
#include <algorithm>
#include "Presets.h"

namespace uad_uadteletronixla2a {
inline constexpr double kPi=3.141592653589793238462643383279502884;

/**
 * UADx Teletronix LA-2A Tube Compressor — Complete C++ DSP Implementation
 *
 * Models the Teletronix LA-2A Silver Electro-Optical Leveling Amplifier:
 * 1. UTC HA-100X Input Transformer + 12AX7 Input Voltage Amplifier
 * 2. T4B Electro-Optical Attenuator Cell:
 *    - Electroluminescent (EL) panel + dual CdS photoresistor bridge
 *    - Program-dependent attack (~10 ms average)
 *    - Dual-stage non-linear release: fast initial release (~60 ms for the first 50% recovery)
 *      followed by a slow phosphor memory release (0.8s .. 4.5s depending on exposure duration & depth)
 *    - `comp_limit`: Compress (~3:1 soft optical knee) vs Limit (~12:1 firm optical knee)
 * 3. 12AX7 / 12BH7 Tube Makeup Amplifier + UTC A-24 Output Transformer (`gain` 0..100 -> 0..+40 dB)
 * 4. 105-Frame VU/GR Meter Needle output (`getVUNeedleFrame()` 0..104 matching `UA_LA-2A_needle_ON.png`)
 */
class UADTeletronixLA2A {
public:
    UADTeletronixLA2A() { prepare(48000.0); }

    void prepare(double sampleRate);
    void reset();

    void setParameters(float peakReductNorm, float gainNorm, float compLimitNorm,
                       float meterModeNorm, float powerNorm);
    void loadPreset(int index);

    void processBlock(float* left, float* right, int numSamples);

    double getGainReductiondB() const { return currentGRdB_; }
    double getOutputVUdB() const { return currentVUdB_; }
    int getVUNeedleFrame() const; // 0..104 matching UA_LA-2A_needle_ON.png (105 frames)

private:
    double sampleRate_ = 48000.0;

    float peak_reduct_ = 0.45f;
    float gain_ = 0.35f;
    float comp_limit_ = 0.0f;
    float meter_ = 0.5f;
    float power_ = 1.0f;

    // T4B dual-envelope state + exposure memory integrator
    double fastEnv_ = 0.0;
    double slowEnv_ = 0.0;
    double memoryCharge_ = 0.0;

    double attCoeff_ = 0.0;
    double relFastCoeff_ = 0.0;
    double relSlowBaseCoeff_ = 0.0;

    // Sidechain high-frequency pre-emphasis filter state
    double scHpStateL_ = 0.0, scHpStateR_ = 0.0;

    // Transformer low-end warmth state
    double xfmrLpL_ = 0.0, xfmrLpR_ = 0.0;

    double currentGRdB_ = 0.0;
    double currentVUdB_ = -60.0;
    double memoryIncrement_=0.00005,memoryDecay_=0.99995,grRelease_=0.999;
    double vuEnvelope_=0.0,vuCoefficient_=0.0;
};

} // namespace uad_uadteletronixla2a
