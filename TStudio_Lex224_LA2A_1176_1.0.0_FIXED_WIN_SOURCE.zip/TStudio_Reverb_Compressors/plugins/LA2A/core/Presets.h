#pragma once
#include <vector>
#include <string>

namespace uad_uadteletronixla2a {

struct FactoryPreset {
    const char* name;
    float peak_reduct;
    float gain;
    float comp_limit;
    float meter;
    float power;
};

static const FactoryPreset kFactoryPresets[29] = {
    {"Acoustic Guitar", 0.369995f, 0.364990f, 1.000000f, 0.500000f, 1.000000f},
    {"Background Vocals", 0.539948f, 0.479980f, 0.000000f, 0.500000f, 1.000000f},
    {"Ballad Vocal", 0.268494f, 0.314972f, 1.000000f, 0.500000f, 1.000000f},
    {"Bass Direct", 0.404938f, 0.375000f, 0.000000f, 0.500000f, 1.000000f},
    {"Bass Presence", 0.529968f, 0.494995f, 1.000000f, 0.500000f, 1.000000f},
    {"Bass Tamer", 0.684998f, 0.654999f, 1.000000f, 0.500000f, 1.000000f},
    {"Belting Vocal", 0.629974f, 0.549988f, 1.000000f, 0.500000f, 1.000000f},
    {"Big Drum Boost", 0.684998f, 0.649994f, 1.000000f, 0.500000f, 1.000000f},
    {"Breathy Vocal", 0.719971f, 0.654999f, 0.000000f, 0.500000f, 1.000000f},
    {"Colorful Space", 1.000000f, 0.719971f, 0.000000f, 0.500000f, 1.000000f},
    {"Female Vox", 0.239960f, 0.290009f, 0.000000f, 0.500000f, 1.000000f},
    {"Gentle Guitar", 0.223480f, 0.294983f, 0.000000f, 0.500000f, 1.000000f},
    {"Great Snare", 0.364990f, 0.359985f, 0.000000f, 0.500000f, 1.000000f},
    {"Guitar Heat", 0.449951f, 0.439972f, 1.000000f, 0.500000f, 1.000000f},
    {"Juicy Rhodes", 0.223480f, 0.279999f, 1.000000f, 0.500000f, 1.000000f},
    {"Keys Forward", 0.268494f, 0.314972f, 0.000000f, 0.500000f, 1.000000f},
    {"Male Vox", 0.614960f, 0.549988f, 1.000000f, 0.500000f, 1.000000f},
    {"Nice Bass", 0.499969f, 0.464996f, 0.000000f, 0.500000f, 1.000000f},
    {"Piano Room", 0.500000f, 0.449982f, 0.000000f, 0.500000f, 1.000000f},
    {"Pop Vocal", 0.394989f, 0.389984f, 0.000000f, 0.500000f, 1.000000f},
    {"Present Female Vox", 0.494965f, 0.444977f, 0.000000f, 0.500000f, 1.000000f},
    {"Pumping Drums", 0.440002f, 0.434998f, 1.000000f, 0.500000f, 1.000000f},
    {"R&B Vocal", 0.399963f, 0.389984f, 0.000000f, 0.500000f, 1.000000f},
    {"Rap Vocal", 0.401001f, 0.384979f, 1.000000f, 0.500000f, 1.000000f},
    {"Rhythm Guitar", 0.519989f, 0.474976f, 0.000000f, 0.500000f, 1.000000f},
    {"Rock Vocal", 0.694977f, 0.644989f, 0.000000f, 0.500000f, 1.000000f},
    {"Splatty Keys", 0.580994f, 0.524994f, 1.000000f, 0.500000f, 1.000000f},
    {"Vocal Adlib", 0.444977f, 0.409973f, 0.000000f, 0.500000f, 1.000000f},
    {"Default", 0.277496f, 0.321899f, 0.000000f, 0.500000f, 1.000000f},
};
} // namespace uad_uadteletronixla2a
