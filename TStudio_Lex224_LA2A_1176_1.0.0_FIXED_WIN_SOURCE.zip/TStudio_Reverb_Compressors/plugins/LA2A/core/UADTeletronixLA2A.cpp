#include "UADTeletronixLA2A.h"

namespace uad_uadteletronixla2a {

void UADTeletronixLA2A::prepare(double sampleRate) {
    sampleRate_ = std::isfinite(sampleRate)&&sampleRate>=8000.0&&sampleRate<=768000.0?sampleRate:48000.0;
    memoryIncrement_=0.00005*48000.0/sampleRate_;
    memoryDecay_=std::pow(0.99995,48000.0/sampleRate_);
    grRelease_=std::pow(0.999,48000.0/sampleRate_);
    vuCoefficient_=std::exp(-1.0/(.300*sampleRate_));
    attCoeff_ = std::exp(-1.0 / (0.010 * sampleRate_));         // ~10 ms optical attack
    relFastCoeff_ = std::exp(-1.0 / (0.060 * sampleRate_));     // ~60 ms initial fast release
    relSlowBaseCoeff_ = std::exp(-1.0 / (1.100 * sampleRate_)); // ~1.1s..4.5s slow memory tail
    reset();
}

void UADTeletronixLA2A::reset() {
    fastEnv_ = 0.0;
    slowEnv_ = 0.0;
    memoryCharge_ = 0.0;
    scHpStateL_ = scHpStateR_ = 0.0;
    xfmrLpL_ = xfmrLpR_ = 0.0;
    currentGRdB_ = 0.0;
    currentVUdB_ = -60.0;
    vuEnvelope_=0;
}

void UADTeletronixLA2A::loadPreset(int index) {
    int count = sizeof(kFactoryPresets) / sizeof(kFactoryPresets[0]);
    if (index < 0 || index >= count) return;
    const auto& p = kFactoryPresets[index];
    setParameters(p.peak_reduct, p.gain, p.comp_limit, p.meter, p.power);
}

void UADTeletronixLA2A::setParameters(float peakReductNorm, float gainNorm, float compLimitNorm,
                                      float meterModeNorm, float powerNorm) {
    peak_reduct_ = std::isfinite(peakReductNorm) ? std::clamp(peakReductNorm, 0.0f, 1.0f) : peak_reduct_;
    gain_ = std::isfinite(gainNorm) ? std::clamp(gainNorm, 0.0f, 1.0f) : gain_;
    comp_limit_ = std::isfinite(compLimitNorm) ? std::clamp(compLimitNorm, 0.0f, 1.0f) : comp_limit_;
    meter_ = std::isfinite(meterModeNorm) ? std::clamp(meterModeNorm, 0.0f, 1.0f) : meter_;
    power_ = std::isfinite(powerNorm) ? std::clamp(powerNorm, 0.0f, 1.0f) : power_;
}

void UADTeletronixLA2A::processBlock(float* left, float* right, int numSamples) {
    if(left==nullptr||numSamples<=0)return;
    for(int i=0;i<numSamples;++i){left[i]=std::isfinite(left[i])?std::clamp(left[i],-64.f,64.f):0.f;if(right)right[i]=std::isfinite(right[i])?std::clamp(right[i],-64.f,64.f):0.f;}
    if (power_ < 0.5f) {
        currentGRdB_ = 0.0;
        currentVUdB_ = -60.0;
        return;
    }

    // LA-2A Gain knob: 0..1 -> -12 dB .. +28 dB (where ~0.30 is unity 0 dB in practical studio calibration)
    double makeupdB = (static_cast<double>(gain_) - 0.30) * 40.0;
    double makeupLin = std::pow(10.0, makeupdB / 20.0);

    // Peak Reduction threshold & ratio (Compress ~3.2:1 vs Limit ~12:1)
    double pr = static_cast<double>(peak_reduct_);
    double threshdB = -2.0 - 34.0 * pr;
    double threshLin = std::pow(10.0, threshdB / 20.0);
    double ratio = (comp_limit_ >= 0.5f) ? 12.0 : 3.2;

    double xfmrAlpha = 1.0 - std::exp(-2.0 * kPi * 35.0 / sampleRate_);

    for (int i = 0; i < numSamples; ++i) {
        double L = static_cast<double>(left[i]);
        double R = right ? static_cast<double>(right[i]) : L;

        // T4B Sidechain Detection with subtle EL panel HF luminescence sensitivity
        double det = std::max(std::abs(L), std::abs(R));

        if (det > fastEnv_) {
            fastEnv_ = attCoeff_ * fastEnv_ + (1.0 - attCoeff_) * det;
        } else {
            fastEnv_ = relFastCoeff_ * fastEnv_ + (1.0 - relFastCoeff_) * det;
        }

        // Program-dependent CdS phosphor memory charge
        if (det > threshLin) {
            memoryCharge_ = std::min(1.0, memoryCharge_ + memoryIncrement_);
        } else {
            memoryCharge_ = std::max(0.0, memoryCharge_ * memoryDecay_);
        }
        double slowRelTime = 0.85 + 3.2 * memoryCharge_;
        double dynSlowCoeff = std::exp(-1.0 / (slowRelTime * sampleRate_));

        if (det > slowEnv_) {
            slowEnv_ = attCoeff_ * slowEnv_ + (1.0 - attCoeff_) * det;
        } else {
            slowEnv_ = dynSlowCoeff * slowEnv_ + (1.0 - dynSlowCoeff) * det;
        }

        // Blend fast initial release (65%) and slow memory tail (35%)
        double optoEnv = (0.65 - 0.25 * memoryCharge_) * fastEnv_ + (0.35 + 0.25 * memoryCharge_) * slowEnv_;

        double grLin = 1.0;
        if (pr > 0.005 && optoEnv > threshLin) {
            double overdB = 20.0 * std::log10(optoEnv / threshLin);
            // Soft optical knee transition
            double kneeWidth = 6.0;
            double effOverdB = (overdB < kneeWidth)
                ? (overdB * overdB) / (2.0 * kneeWidth) + 0.5 * overdB
                : overdB;
            double grdB = effOverdB * (1.0 / ratio - 1.0); // negative dB
            grLin = std::pow(10.0, grdB / 20.0);
            currentGRdB_ = -grdB;
        } else {
            currentGRdB_ *= grRelease_;
        }

        L *= grLin;
        R *= grLin;

        // 12AX7 + 12BH7 Tube Amplifier + UTC A-24 Transformer Warmth
        xfmrLpL_ += xfmrAlpha * (L - xfmrLpL_);
        xfmrLpR_ += xfmrAlpha * (R - xfmrLpR_);
        L += 0.06 * xfmrLpL_;
        R += 0.06 * xfmrLpR_;

        auto tubeAmp = [](double x) -> double {
            double d = x * 0.9;
            return (std::tanh(d) + 0.028 * d * d / (1.0 + d * d)) / 0.9;
        };
        L = tubeAmp(L * makeupLin);
        R = tubeAmp(R * makeupLin);

        double outAbs = 0.5 * (std::abs(L) + std::abs(R));
        vuEnvelope_=vuCoefficient_*vuEnvelope_+(1-vuCoefficient_)*outAbs*outAbs;
        currentVUdB_=10.0*std::log10(std::max(1e-12,vuEnvelope_));

        left[i] = static_cast<float>(L);
        if (right) right[i] = static_cast<float>(R);
    }
}

int UADTeletronixLA2A::getVUNeedleFrame() const {
    if (power_ < 0.5f) return 0;
    // These sprites move linearly with meter voltage, rather than dB.
    // Frame 65 aligns with the printed 0 VU mark in the supplied panel.
    if ( std::abs(meter_ - 0.5f) < 0.2f ) {
        return std::clamp((int)std::round(65.0*std::pow(10.0,-currentGRdB_/20.0)),0,104);
    }
    // Project calibration: +4 mode is 0 VU at -18 dBFS; +10 mode is
    // 6 dB less sensitive. Both modes share the same 0 VU needle position.
    const double vu=currentVUdB_+(meter_<.25f?12.0:18.0);
    const double frame=65.0*std::pow(10.0,vu/20.0);
    return std::clamp((int)std::round(frame),0,104);
}

} // namespace uad_uadteletronixla2a
