#include "PluginProcessor.h"
#include <limits>
namespace studio {
juce::String parameterText(const ParameterSpec& s,float v){
 v=juce::jlimit(0.f,1.f,v);
 if(s.kind==Kind::Choice){const auto names=juce::StringArray::fromTokens(s.choices,"|","");return names[juce::jlimit(0,names.size()-1,juce::roundToInt(v*float(names.size()-1)))];}
 if(s.kind==Kind::Switch)return v>=.5f?"On":"Off";
 if(s.kind==Kind::Legacy)return "Stored only";
 switch(s.unit){
 case Unit::Bass:return juce::String(.6*std::pow(70/.6,double(v)),2)+" s";
 case Unit::Mid:return juce::String(.25*std::pow(26/.25,double(v)),2)+" s";
 case Unit::Xover:return juce::String(100*std::pow(64.,double(v)),0)+" Hz";
 case Unit::Treble:return juce::String(800*std::pow(15000./800,double(v)),0)+" Hz";
 case Unit::Predelay:return juce::String(v*250,1)+" ms";
 case Unit::Trim:return juce::String((v-.5f)*24,1)+" dB";
 case Unit::Attack:return v<.01f?"Off":juce::String(800*std::pow(.025,double(v)),0)+" us";
 case Unit::Release:return juce::String(1100*std::pow(50./1100,double(v)),0)+" ms";
 case Unit::Steps:return juce::String(v*15,1);
 case Unit::Percent:return juce::String(v*100,1)+" %";
 case Unit::Dial100:return juce::String(v*100,1);
 default:return juce::String(v,3);
 }
}
juce::AudioProcessorValueTreeState::ParameterLayout PluginProcessor::makeLayout(){
 juce::AudioProcessorValueTreeState::ParameterLayout layout;
 for(const auto& s:parameterSpecs){
  if(s.kind==Kind::Switch){layout.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{s.id,1},s.label,s.defaultValue>=.5f));continue;}
  float step=0;if(s.kind==Kind::Choice)step=1.f/float(juce::StringArray::fromTokens(s.choices,"|","").size()-1);if(s.kind==Kind::Legacy)step=1;
  layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{s.id,1},s.label,juce::NormalisableRange<float>(0,1,step),s.defaultValue,
   juce::AudioParameterFloatAttributes().withStringFromValueFunction([s](float v,int){return parameterText(s,v);})));
 }
 return layout;
}
PluginProcessor::PluginProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),state(*this,nullptr,"TStudioReverbCompressors",makeLayout()){
 for(size_t i=0;i<values.size();++i)values[i]=state.getRawParameterValue(parameterSpecs[i].id);
}
bool PluginProcessor::isBusesLayoutSupported(const BusesLayout& b) const {
 return b.getMainInputChannelSet()==b.getMainOutputChannelSet()&&(b.getMainOutputChannelSet()==juce::AudioChannelSet::mono()||b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo());
}
float PluginProcessor::parameter(int i) const noexcept {const auto x=values[size_t(i)]->load(std::memory_order_relaxed);return std::isfinite(x)?juce::jlimit(0.f,1.f,x):parameterSpecs[size_t(i)].defaultValue;}
float PluginProcessor::parameter(const juce::String& id) const noexcept {for(int i=0;i<parameterCount;++i)if(id==parameterSpecs[size_t(i)].id)return parameter(i);return 0;}
bool PluginProcessor::powered() const noexcept {
 #if TSTUDIO_PRODUCT==2
 return parameter(6)>=.5f&&parameter(5)>=.1f;
 #else
 return parameter(dspParameterCount-1)>=.5f;
 #endif
}
double PluginProcessor::getTailLengthSeconds() const {
 #if TSTUDIO_PRODUCT==0
 return parameter(9)>=.5f?std::numeric_limits<double>::infinity():120.;
 #else
 return .5;
 #endif
}
void PluginProcessor::prepareToPlay(double sampleRate,int block){
 const double sr=std::isfinite(sampleRate)&&sampleRate>=8000&&sampleRate<=768000?sampleRate:48000.;
 dry.setSize(2,std::max(512,block),false,true,true);engine.prepare(sr);for(auto& s:controls)s.reset(sr,.020);bypassRamp.reset(sr,.020);setLatencySamples(0);reset();
}
void PluginProcessor::setEngineParameters(){
 std::array<float,dspParameterCount> v{};for(size_t i=0;i<v.size();++i)v[i]=controls[i].getCurrentValue();
 // Keep the core warm during host/native bypass. The two stereo-only legacy
 // metadata fields remain stored, without pretending to implement UA modes.
 v.back()=1;
 #if TSTUDIO_PRODUCT==2
 if(v[5]<.1f)v[5]=1;
 #endif
 setCore(engine,v);
}
void PluginProcessor::reset(){
 for(int i=0;i<dspParameterCount;++i)controls[size_t(i)].setCurrentAndTargetValue(parameter(i));
 setEngineParameters();engine.reset();controlRemaining=0;bypassRamp.setCurrentAndTargetValue(hostBypass||parameter(parameterCount-1)>=.5f||!powered()?1.f:0.f);
 inputDb=-100;outputDb=-100;gainReductionDb=0;vuDb=-100;needleFrame=0;inputFrameL=0;inputFrameR=0;
 #if TSTUDIO_PRODUCT!=0
 needleFrame=powered()?engine.getVUNeedleFrame():0;
 #endif
}
void PluginProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&){
 juce::ScopedNoDenormals noDenormals;const int channels=std::min(2,buffer.getNumChannels()),frames=buffer.getNumSamples();if(channels<1||frames<=0)return;if(dry.getNumSamples()==0){buffer.clear();return;}
 for(int c=getTotalNumInputChannels();c<buffer.getNumChannels();++c)buffer.clear(c,0,frames);
 for(int i=0;i<dspParameterCount;++i){const auto v=parameter(i);auto& s=controls[size_t(i)];const auto k=parameterSpecs[size_t(i)].kind;
  #if TSTUDIO_PRODUCT==0
  const bool immediate=parameter(8)>=.5f;
  #else
  constexpr bool immediate=false;
  #endif
  if(immediate||k==Kind::Switch||k==Kind::Choice||k==Kind::Legacy)s.setCurrentAndTargetValue(v);else s.setTargetValue(v);
 }
 bypassRamp.setTargetValue(hostBypass||parameter(parameterCount-1)>=.5f||!powered()?1.f:0.f);float inputPeak=0,outputPeak=0;
 for(int start=0;start<frames;){
  if(controlRemaining==0){setEngineParameters();controlRemaining=32;}const int n=std::min({frames-start,controlRemaining,dry.getNumSamples()});
  for(int c=0;c<channels;++c){auto* src=buffer.getWritePointer(c,start);auto* dst=dry.getWritePointer(c);for(int i=0;i<n;++i){float x=std::isfinite(src[i])?juce::jlimit(-64.f,64.f,src[i]):0;src[i]=dst[i]=x;inputPeak=std::max(inputPeak,std::abs(x));}}
  engine.processBlock(buffer.getWritePointer(0,start),channels>1?buffer.getWritePointer(1,start):nullptr,n);
  for(int i=0;i<n;++i){const auto b=bypassRamp.getNextValue();for(int c=0;c<channels;++c){auto* dst=buffer.getWritePointer(c,start);dst[i]+=(dry.getSample(c,i)-dst[i])*b;outputPeak=std::max(outputPeak,std::abs(dst[i]));}}
  for(auto& s:controls)s.skip(n);start+=n;controlRemaining-=n;
 }
 inputDb.store(juce::Decibels::gainToDecibels(inputPeak,-100.f),std::memory_order_relaxed);outputDb.store(juce::Decibels::gainToDecibels(outputPeak,-100.f),std::memory_order_relaxed);
 #if TSTUDIO_PRODUCT==0
 inputFrameL=powered()?engine.getGainMeterFrameL():0;inputFrameR=powered()?engine.getGainMeterFrameR():0;
 #else
 gainReductionDb=powered()?float(engine.getGainReductiondB()):0;vuDb=powered()?float(engine.getOutputVUdB()):-100;needleFrame=powered()?engine.getVUNeedleFrame():0;
 #endif
}
void PluginProcessor::processBlockBypassed(juce::AudioBuffer<float>& b,juce::MidiBuffer& m){hostBypass=true;processBlock(b,m);hostBypass=false;}
void PluginProcessor::setCurrentProgram(int i){if(i<0||i>=presetCount)return;const auto v=presetValues(i);for(int j=0;j<dspParameterCount;++j)if(auto* param=state.getParameter(parameterSpecs[size_t(j)].id))param->setValueNotifyingHost(v[size_t(j)]);currentProgram=i;}
const juce::String PluginProcessor::getProgramName(int i){return i>=0&&i<presetCount?juce::String::fromUTF8(presetName(i)):juce::String{};}
void PluginProcessor::getStateInformation(juce::MemoryBlock& destination){auto tree=state.copyState();tree.setProperty("product",productName,nullptr);tree.setProperty("factoryPreset",currentProgram.load(),nullptr);auto xml=tree.createXml();copyXmlToBinary(*xml,destination);}
void PluginProcessor::setStateInformation(const void* data,int size){if(auto xml=getXmlFromBinary(data,size)){if(!xml->hasTagName(state.state.getType().toString()))return;auto tree=juce::ValueTree::fromXml(*xml);if(tree.getProperty("product").toString()!=productName)return;int index=int(tree.getProperty("factoryPreset",defaultPreset));state.replaceState(tree);currentProgram=juce::jlimit(0,presetCount-1,index);}}
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new studio::PluginProcessor;}
