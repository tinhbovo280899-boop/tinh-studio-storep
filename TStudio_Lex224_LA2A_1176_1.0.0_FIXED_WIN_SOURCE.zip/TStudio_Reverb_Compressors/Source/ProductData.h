#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <array>
#include <vector>
#include <iterator>
namespace studio {
enum class Kind {Float,Switch,Choice,Legacy};
enum class Unit {Raw,Bass,Mid,Xover,Treble,Predelay,Percent,Steps,Trim,Dial100,Attack,Release};
struct ParameterSpec {const char* id;const char* label;Kind kind;float defaultValue;const char* choices;Unit unit;};
struct AtlasSpec {const char* resource;int width,height,frames,columns;};
struct ControlLayout {const char* id;juce::Rectangle<int> bounds;AtlasSpec atlas;int style;};
}
#if TSTUDIO_PRODUCT == 0
#include "../plugins/Lex224/core/UADLexicon224.h"
namespace studio {
using Core=uad_uadlexicon224::UADLexicon224;
inline constexpr const char* productName="T-Lex224-R";
inline constexpr const char* panelResource="lex_panel_png";
inline constexpr int panelWidth=671,panelHeight=621,faceWidth=381;
inline constexpr int dspParameterCount=24,parameterCount=dspParameterCount+1,defaultPreset=54,presetCount=55;
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
{"program","Program",Kind::Choice,0.625000000f,"Small Hall B|Vocal Plate|Large Hall B|Chamber|Percussion Plate|Small Hall A|Room A|Constant Plate|Chorus",Unit::Raw},
{"bass","Bass Decay",Kind::Float,0.500000000f,"",Unit::Bass},
{"mid","Mid Decay",Kind::Float,0.343750000f,"",Unit::Mid},
{"crossover","Crossover",Kind::Float,0.156250000f,"",Unit::Xover},
{"treble_decay","Treble Decay",Kind::Float,0.875000000f,"",Unit::Treble},
{"depth","Depth",Kind::Float,0.332001000f,"",Unit::Percent},
{"predelay","Pre-delay",Kind::Float,0.000000000f,"",Unit::Predelay},
{"diffusion","Diffusion",Kind::Float,0.437500000f,"",Unit::Percent},
{"immediate","Immediate",Kind::Switch,0.000000000f,"",Unit::Raw},
{"sys_noise","System Noise",Kind::Switch,0.000000000f,"",Unit::Raw},
{"rear_outs","Rear Outputs (stored only)",Kind::Legacy,0.000000000f,"",Unit::Raw},
{"mix","Mix",Kind::Float,0.500000000f,"",Unit::Percent},
{"wet_solo","Wet Solo",Kind::Switch,1.000000000f,"",Unit::Raw},
{"enh_step","Enhancement",Kind::Float,0.066667000f,"",Unit::Steps},
{"pitch_step","Pitch Modulation",Kind::Float,0.000000000f,"",Unit::Steps},
{"decay_opt","Decay Optimization",Kind::Switch,1.000000000f,"",Unit::Raw},
{"opt_step","Optimization Amount",Kind::Float,0.266667000f,"",Unit::Steps},
{"in_gain_l","Input L",Kind::Float,0.500000000f,"",Unit::Trim},
{"in_gain_r","Input R",Kind::Float,0.500000000f,"",Unit::Trim},
{"out_lvl_l","Output L",Kind::Float,0.500000000f,"",Unit::Trim},
{"out_lvl_r","Output R",Kind::Float,0.500000000f,"",Unit::Trim},
{"link","Link L/R",Kind::Switch,1.000000000f,"",Unit::Raw},
{"bug_fixes","Legacy Bug Flag (stored only)",Kind::Legacy,1.000000000f,"",Unit::Raw},
{"power","Power",Kind::Switch,1.000000000f,"",Unit::Raw},
{"bypass","Bypass",Kind::Switch,0.f,"",Unit::Raw}}};
inline const char* presetName(int i){return uad_uadlexicon224::kFactoryPresets[size_t(i)].name;}
inline std::array<float,dspParameterCount> presetValues(int index){const auto& p=uad_uadlexicon224::kFactoryPresets[size_t(index)];return {p.program,p.bass,p.mid,p.crossover,p.treble_decay,p.depth,p.predelay,p.diffusion,p.immediate,p.sys_noise,p.rear_outs,p.mix,p.wet_solo,p.enh_step,p.pitch_step,p.decay_opt,p.opt_step,p.in_gain_l,p.in_gain_r,p.out_lvl_l,p.out_lvl_r,p.link,p.bug_fixes,p.power};}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v){
core.setParameters(uad_uadlexicon224::FactoryPreset{"Host",v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9],v[10],v[11],v[12],v[13],v[14],v[15],v[16],v[17],v[18],v[19],v[20],v[21],v[22],v[23]});}
inline const std::vector<ControlLayout> controlLayouts {
{"bass",{49,337,48,159},{"lex_slider_png",96,90,1,1},1},
{"mid",{97,337,48,159},{"lex_slider_png",96,90,1,1},1},
{"crossover",{145,337,48,159},{"lex_slider_png",96,90,1,1},1},
{"treble_decay",{193,337,48,159},{"lex_slider_png",96,90,1,1},1},
{"depth",{241,337,48,159},{"lex_slider_png",96,90,1,1},1},
{"predelay",{289,337,48,159},{"lex_slider_png",96,90,1,1},1},
{"in_gain_l",{97,40,35,35},{"lex_pot_png",70,70,31,6},0},
{"in_gain_r",{137,40,35,35},{"lex_pot_png",70,70,31,6},0},
{"out_lvl_l",{212,40,35,35},{"lex_pot_png",70,70,31,6},0},
{"out_lvl_r",{252,40,35,35},{"lex_pot_png",70,70,31,6},0},
{"power",{330,40,33,33},{"lex_power_png",66,66,2,2},0},
{"link",{182,56,18,17},{"lex_link_png",36,34,2,2},6},
{"immediate",{51,244,35,60},{"lex_small_l_png",70,120,4,3},5},
{"sys_noise",{86,244,35,60},{"lex_small_png",70,120,4,3},5},
{"rear_outs",{121,244,35,60},{"lex_small_png",70,120,4,3},5},
{"decay_opt",{191,244,35,60},{"lex_small_png",70,120,4,3},5},
{"wet_solo",{296,244,35,60},{"lex_small_r_png",70,120,4,3},5},
{"diffusion",{51,511,90,50},{"lex_slider_png",96,90,1,1},2},
{"enh_step",{145,511,90,50},{"lex_slider_png",96,90,1,1},2},
{"opt_step",{239,511,90,50},{"lex_slider_png",96,90,1,1},2},
};
}
#elif TSTUDIO_PRODUCT == 1
#include "../plugins/LA2A/core/UADTeletronixLA2A.h"
namespace studio {
using Core=uad_uadteletronixla2a::UADTeletronixLA2A;
inline constexpr const char* productName="T-LA2A-TC";
inline constexpr const char* panelResource="la_panel_png";
inline constexpr int panelWidth=950,panelHeight=263,faceWidth=950;
inline constexpr int dspParameterCount=5,parameterCount=dspParameterCount+1,defaultPreset=28,presetCount=29;
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
{"peak_reduct","Peak Reduction",Kind::Float,0.277496000f,"",Unit::Dial100},
{"gain","Gain",Kind::Float,0.321899000f,"",Unit::Dial100},
{"comp_limit","Limit",Kind::Switch,0.000000000f,"",Unit::Raw},
{"meter","Meter",Kind::Choice,0.500000000f,"Output +10|Gain Reduction|Output +4",Unit::Raw},
{"power","Power",Kind::Switch,1.000000000f,"",Unit::Raw},
{"bypass","Bypass",Kind::Switch,0.f,"",Unit::Raw}}};
inline const char* presetName(int i){return uad_uadteletronixla2a::kFactoryPresets[size_t(i)].name;}
inline std::array<float,dspParameterCount> presetValues(int index){const auto& p=uad_uadteletronixla2a::kFactoryPresets[size_t(index)];return {p.peak_reduct,p.gain,p.comp_limit,p.meter,p.power};}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v){
core.setParameters(v[0],v[1],v[2],v[3],v[4]);}
inline const std::vector<ControlLayout> controlLayouts {
{"gain",{230,112,84,84},{"la_knob_png",168,168,103,11},0},
{"peak_reduct",{636,112,84,84},{"la_knob_png",168,168,103,11},0},
{"meter",{759,47,84,84},{"la_rotary_png",168,168,3,2},0},
{"comp_limit",{70,150,56,56},{"la_limit_png",112,112,2,2},0},
{"power",{773,150,56,56},{"la_power_png",112,112,2,2},0},
};
}
#elif TSTUDIO_PRODUCT == 2
#include "../plugins/FET1176/core/UAD1176Compressor.h"
namespace studio {
using Core=uad_uad1176compressor::UAD1176Compressor;
inline constexpr const char* productName="T-1176-FET";
inline constexpr const char* panelResource="fet_panel_png";
inline constexpr int panelWidth=950,panelHeight=175,faceWidth=950;
inline constexpr int dspParameterCount=7,parameterCount=dspParameterCount+1,defaultPreset=25,presetCount=26;
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
{"input","Input",Kind::Float,0.199982000f,"",Unit::Dial100},
{"output","Output",Kind::Float,0.625946000f,"",Unit::Dial100},
{"attack","Attack",Kind::Float,0.500000000f,"",Unit::Attack},
{"release","Release",Kind::Float,0.665985000f,"",Unit::Release},
{"ratio","Ratio",Kind::Choice,0.000000000f,"4:1|8:1|12:1|20:1|All Buttons",Unit::Raw},
{"meter","Meter / Off",Kind::Choice,1.000000000f,"Off|Output +4|Output +8|Gain Reduction",Unit::Raw},
{"power","Power",Kind::Switch,1.000000000f,"",Unit::Raw},
{"bypass","Bypass",Kind::Switch,0.f,"",Unit::Raw}}};
inline const char* presetName(int i){return uad_uad1176compressor::kFactoryPresets[size_t(i)].name;}
inline std::array<float,dspParameterCount> presetValues(int index){const auto& p=uad_uad1176compressor::kFactoryPresets[size_t(index)];return {p.input,p.output,p.attack,p.release,p.ratio,p.meter,p.power};}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v){
core.setParameters(v[0],v[1],v[2],v[3],v[4],v[5],v[6]);}
inline const std::vector<ControlLayout> controlLayouts {
{"input",{91,42,90,90},{"fet_knob_png",180,180,109,11},0},
{"output",{278,42,90,90},{"fet_knob_png",180,180,109,11},0},
{"attack",{445,19,60,60},{"fet_small_png",120,120,101,11},0},
{"release",{445,95,60,60},{"fet_small_png",120,120,101,11},0},
{"ratio",{575,13,45,143},{"fet_ratio_png",90,286,16,8},3},
{"meter",{812,13,45,143},{"fet_meter_png",90,286,4,4},4},
};
}
#endif
