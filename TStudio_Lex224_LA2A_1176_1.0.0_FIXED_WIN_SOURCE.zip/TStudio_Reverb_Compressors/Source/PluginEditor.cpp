#include "PluginProcessor.h"
#include "StudioImages.h"
#include <functional>
namespace studio {
static juce::Image resourceImage(const char* id){int n=0;auto* data=StudioImages::getNamedResource(id,n);return data&&n>0?juce::ImageCache::getFromMemory(data,n):juce::Image{};}
struct Sprite {
 AtlasSpec spec;juce::Image image;
 explicit Sprite(AtlasSpec s):spec(s),image(resourceImage(s.resource)){}
 void drawFrame(juce::Graphics& g,juce::Rectangle<float> bounds,int frame) const {
  if(!image.isValid())return;frame=juce::jlimit(0,spec.frames-1,frame);
  auto crop=image.getClippedImage({(frame%spec.columns)*spec.width,(frame/spec.columns)*spec.height,spec.width,spec.height});
  g.drawImage(crop,bounds,juce::RectanglePlacement::stretchToFit);
 }
 void draw(juce::Graphics& g,juce::Rectangle<float> b,float n) const {drawFrame(g,b,juce::roundToInt(n*float(spec.frames-1)));}
};
class SpriteSlider final:public juce::Slider {
public:
 SpriteSlider(AtlasSpec a,int s):sprite(a),style(s){setSliderStyle(style==1?LinearVertical:style==2?LinearHorizontal:RotaryHorizontalVerticalDrag);setTextBoxStyle(NoTextBox,false,0,0);setMouseDragSensitivity(180);setWantsKeyboardFocus(false);}
 juce::RangedAudioParameter* hostParameter=nullptr;
 void paint(juce::Graphics& g) override {
  const float v=float(valueToProportionOfLength(getValue()));auto b=getLocalBounds().toFloat();
  if(style==1){sprite.drawFrame(g,{0,(1-v)*(b.getHeight()-45),b.getWidth(),45},0);return;}
  if(style==2){g.setColour(juce::Colours::grey);g.fillRoundedRectangle(b.reduced(5,b.getHeight()*.43f),3);sprite.drawFrame(g,{v*(b.getWidth()-22),b.getHeight()*.22f,22,b.getHeight()*.56f},0);return;}
  if(style==3){static constexpr int map[]{8,4,2,1,15};sprite.drawFrame(g,b,map[juce::jlimit(0,4,juce::roundToInt(v*4))]);return;}
  if(style==4){sprite.drawFrame(g,b,3-juce::jlimit(0,3,juce::roundToInt(v*3)));return;}
  sprite.draw(g,b,v);
 }
 void mouseDown(const juce::MouseEvent& e) override {
  if(style!=3&&style!=4){Slider::mouseDown(e);return;}
  const int row=juce::jlimit(0,3,juce::roundToInt((e.position.y-22)/30));
  const float value=style==3?(e.mods.isShiftDown()?1.f:float(3-row)/4.f):float(3-row)/3.f;
  if(hostParameter)hostParameter->beginChangeGesture();setValue(value,juce::sendNotificationSync);if(hostParameter)hostParameter->endChangeGesture();
 }
 void mouseDrag(const juce::MouseEvent& e) override {if(style!=3&&style!=4)Slider::mouseDrag(e);}
 void mouseUp(const juce::MouseEvent& e) override {if(style!=3&&style!=4)Slider::mouseUp(e);}
private:Sprite sprite;int style;
};
class SpriteButton final:public juce::Button {
public:
 SpriteButton(AtlasSpec a,int s):Button(""),sprite(a),style(s){setClickingTogglesState(true);setWantsKeyboardFocus(false);}
 std::function<float()> frameValue;
 void paintButton(juce::Graphics& g,bool,bool) override {
  float value=frameValue?frameValue():(getToggleState()?1.f:0.f);if(style==5)value=value>0?.333333f:0;if(style==6)value=1-value;
  if(!isEnabled())g.setOpacity(.4f);sprite.draw(g,getLocalBounds().toFloat(),value);
 }
private:Sprite sprite;int style;
};
class PluginEditor final:public juce::AudioProcessorEditor,private juce::Timer {
public:
 explicit PluginEditor(PluginProcessor& p):AudioProcessorEditor(p),processor(p),panel(resourceImage(panelResource)),tooltips(this,700){
  setOpaque(true);setWantsKeyboardFocus(false);preset.setComponentID("factoryPreset");for(int i=0;i<presetCount;++i)preset.addItem(juce::String::fromUTF8(presetName(i)),i+1);
  preset.setSelectedId(p.getCurrentProgram()+1,juce::dontSendNotification);preset.onChange=[this]{processor.setCurrentProgram(preset.getSelectedId()-1);};addAndMakeVisible(preset);
  bypass.setButtonText("BYPASS");bypass.setComponentID("param_bypass");addAndMakeVisible(bypass);bypassAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,"bypass",bypass);
  std::array<bool,parameterCount> drawn{};drawn.back()=true;
  for(const auto& layout:controlLayouts){const int i=indexFor(layout.id);jassert(i>=0);drawn[size_t(i)]=true;const auto& spec=parameterSpecs[size_t(i)];
   if(spec.kind==Kind::Switch||spec.kind==Kind::Legacy){
    auto b=std::make_unique<SpriteButton>(layout.atlas,layout.style);b->setComponentID("param_"+juce::String(layout.id));b->setTooltip(spec.kind==Kind::Legacy?"Unavailable in this stereo version; preset value is retained.":spec.label);
    b->setEnabled(spec.kind!=Kind::Legacy);addAndMakeVisible(*b);positions.push_back({b.get(),layout.bounds});buttonAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,layout.id,*b));buttons.push_back(std::move(b));
   }else{
    auto s=std::make_unique<SpriteSlider>(layout.atlas,layout.style);s->setComponentID("param_"+juce::String(layout.id));s->setTooltip(spec.label);s->setDoubleClickReturnValue(true,spec.defaultValue);s->hostParameter=p.state.getParameter(spec.id);
    s->onValueChange=[this,i]{selected=i;repaint();};addAndMakeVisible(*s);positions.push_back({s.get(),layout.bounds});sliderAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,spec.id,*s));sliders.push_back(std::move(s));
   }
  }
  int row=0;
  for(int i=0;i<dspParameterCount;++i)if(!drawn[size_t(i)]){const auto& spec=parameterSpecs[size_t(i)];
   if(spec.kind==Kind::Legacy){auto s=std::make_unique<juce::Slider>();s->setComponentID("param_"+juce::String(spec.id));s->setEnabled(false);addChildComponent(*s);sliderAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,spec.id,*s));genericSliders.push_back(std::move(s));continue;}
   const juce::Rectangle<int> bounds=TSTUDIO_PRODUCT==0?juce::Rectangle<int>{398,54+row*60,250,25}:juce::Rectangle<int>{330,-33,140,25};
   if(spec.kind==Kind::Switch){auto b=std::make_unique<juce::ToggleButton>(spec.label);b->setComponentID("param_"+juce::String(spec.id));addAndMakeVisible(*b);positions.push_back({b.get(),bounds});buttonAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,spec.id,*b));genericButtons.push_back(std::move(b));}
   else if(spec.kind==Kind::Choice){auto c=std::make_unique<juce::ComboBox>();c->setComponentID("param_"+juce::String(spec.id));auto names=juce::StringArray::fromTokens(spec.choices,"|","");for(int k=0;k<names.size();++k)c->addItem(names[k],k+1);addAndMakeVisible(*c);positions.push_back({c.get(),bounds});comboAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment>(p.state,spec.id,*c));combos.push_back(std::move(c));}
   else {auto s=std::make_unique<juce::Slider>();s->setSliderStyle(juce::Slider::LinearHorizontal);s->setTextBoxStyle(juce::Slider::TextBoxRight,false,85,24);s->setComponentID("param_"+juce::String(spec.id));s->setTooltip(spec.label);s->onValueChange=[this,i]{selected=i;repaint();};addAndMakeVisible(*s);positions.push_back({s.get(),bounds});sliderAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,spec.id,*s));genericSliders.push_back(std::move(s));}
   genericRows.push_back({i,bounds});++row;
  }
  #if TSTUDIO_PRODUCT==0
  lexMeter=std::make_unique<Sprite>(AtlasSpec{"lex_meter_png",194,34,11,2});
  for(int i=0;i<8;++i){auto b=std::make_unique<SpriteButton>(AtlasSpec{"lex_small_png",70,120,4,3},5);b->setClickingTogglesState(false);b->setTooltip(juce::StringArray::fromTokens(parameterSpecs[0].choices,"|","")[i]);b->frameValue=[this,i]{return juce::roundToInt(processor.parameter(0)*8)==i?1.f:0.f;};b->onClick=[this,i]{set("program",float(i)/8);};addAndMakeVisible(*b);positions.push_back({b.get(),{51+35*i,178,35,60}});buttons.push_back(std::move(b));}
  for(int i=0;i<2;++i){auto b=std::make_unique<SpriteButton>(AtlasSpec{"lex_small_png",70,120,4,3},5);b->setClickingTogglesState(false);b->setTooltip(i?"Increase Mix":"Decrease Mix");b->onClick=[this,i]{set("mix",juce::jlimit(0.f,1.f,processor.parameter("mix")+(i?.03125f:-.03125f)));};addAndMakeVisible(*b);positions.push_back({b.get(),{226+35*i,244,35,60}});buttons.push_back(std::move(b));}
  auto enh=std::make_unique<SpriteButton>(AtlasSpec{"lex_small_png",70,120,4,3},5);enh->setClickingTogglesState(false);enh->frameValue=[this]{return processor.parameter("enh_step")>0?1.f:0.f;};enh->onClick=[this]{set("enh_step",processor.parameter("enh_step")>0?0.f:.066667f);};enh->setTooltip("Enable / disable enhancement");addAndMakeVisible(*enh);positions.push_back({enh.get(),{156,244,35,60}});buttons.push_back(std::move(enh));
  #elif TSTUDIO_PRODUCT==1
  needleOn=std::make_unique<Sprite>(AtlasSpec{"la_needle_on_png",284,102,105,7});needleOff=std::make_unique<Sprite>(AtlasSpec{"la_needle_off_png",284,102,105,7});dim=resourceImage("la_dim_png");
  #else
  needleOn=std::make_unique<Sprite>(AtlasSpec{"fet_needle_on_png",260,132,101,8});needleOff=std::make_unique<Sprite>(AtlasSpec{"fet_needle_off_png",260,132,101,8});dim=resourceImage("fet_dim_png");
  #endif
  setResizable(true,true);getConstrainer()->setFixedAspectRatio(double(panelWidth)/double(panelHeight+header+footer));setResizeLimits(int(panelWidth*.75),int((panelHeight+header+footer)*.75),int(panelWidth*1.5),int((panelHeight+header+footer)*1.5));setSize(panelWidth,panelHeight+header+footer);startTimerHz(30);
 }
 ~PluginEditor() override {stopTimer();preset.onChange=nullptr;}
 void paint(juce::Graphics& g) override {
  const float sx=float(getWidth())/panelWidth,sy=float(getHeight())/(panelHeight+header+footer);g.fillAll(juce::Colour(0xff181c22));g.setColour(juce::Colour(0xff8bd8d9));g.setFont(15.f*sy);g.drawText(juce::String("T STUDIO / ")+productName,8,0,int(250*sx),int(header*sy),juce::Justification::centredLeft);
  g.drawImage(panel,scaled({0,0,faceWidth,panelHeight}),juce::RectanglePlacement::stretchToFit);
  #if TSTUDIO_PRODUCT==0
  if(lexMeter){lexMeter->drawFrame(g,scaled({73,93,97,17}),processor.inputFrameL.load());lexMeter->drawFrame(g,scaled({73,111,97,17}),processor.inputFrameR.load());}
  g.setColour(juce::Colour(0xffff5038));g.setFont(15.f*sy);g.drawText(parameterText(parameterSpecs[size_t(selected)],processor.parameter(selected)),scaled({203,93,102,34}).toNearestInt(),juce::Justification::centred);
  g.setColour(juce::Colours::lightgrey);g.setFont(13.f*sy);
  for(const auto& row:genericRows)g.drawText(parameterSpecs[size_t(row.index)].label,scaled({row.bounds.getX(),row.bounds.getY()-20,250,19}).toNearestInt(),juce::Justification::centredLeft);
  int row=0;for(int i:{1,2,3,4,5,6,7,13,16,17,18,19,20}){const int y=235+row*23;g.setColour(juce::Colour(0xffacb9c7));g.drawText(parameterSpecs[size_t(i)].label,scaled({398,y,135,22}).toNearestInt(),juce::Justification::centredLeft);g.setColour(juce::Colours::white);g.drawText(parameterText(parameterSpecs[size_t(i)],processor.parameter(i)),scaled({533,y,115,22}).toNearestInt(),juce::Justification::centredRight);++row;}
  g.setColour(juce::Colour(0xff8bd8d9));g.drawText("FX Send: enable Wet Solo",scaled({398,580,255,22}).toNearestInt(),juce::Justification::centredLeft);
  #else
  const bool power=processor.powered();
  const juce::Rectangle<int> area=TSTUDIO_PRODUCT==1?juce::Rectangle<int>{404,99,142,51}:juce::Rectangle<int>{651,43,130,66};
  if(!power)g.drawImage(dim,scaled(TSTUDIO_PRODUCT==1?juce::Rectangle<int>{394,72,162,78}:juce::Rectangle<int>{644,39,148,82}),juce::RectanglePlacement::stretchToFit);
  auto* needle=power?needleOn.get():needleOff.get();if(needle)needle->drawFrame(g,scaled(area),processor.needleFrame.load());
  #endif
  g.setColour(juce::Colours::lightgrey);g.setFont(12.f*sy);g.drawText(juce::String(parameterSpecs[size_t(selected)].label)+": "+parameterText(parameterSpecs[size_t(selected)],processor.parameter(selected)),8,int((header+panelHeight+1)*sy),int((panelWidth-16)*sx),int(23*sy),juce::Justification::centredLeft);
  const auto meters="IN "+juce::String(processor.inputDb.load(),1)+" dBFS    OUT "+juce::String(processor.outputDb.load(),1)+" dBFS"+(TSTUDIO_PRODUCT==0?juce::String{}:"    GR "+juce::String(processor.gainReductionDb.load(),1)+" dB");g.setColour(juce::Colour(0xffa6b5c6));g.setFont(11.f*sy);g.drawText(meters,8,int((header+panelHeight+24)*sy),int((panelWidth-16)*sx),int(21*sy),juce::Justification::centredLeft);
 }
 void resized() override {const float sx=float(getWidth())/panelWidth,sy=float(getHeight())/(panelHeight+header+footer);preset.setBounds(int((panelWidth-410)*sx),int(7*sy),int(285*sx),int(25*sy));bypass.setBounds(int((panelWidth-112)*sx),int(7*sy),int(100*sx),int(25*sy));for(auto& x:positions)x.component->setBounds(scaled(x.bounds).toNearestInt());}
private:
 static int indexFor(const char* id){for(int i=0;i<parameterCount;++i)if(juce::String(id)==parameterSpecs[size_t(i)].id)return i;return -1;}
 void set(const char* id,float v){if(auto* param=processor.state.getParameter(id)){param->beginChangeGesture();param->setValueNotifyingHost(v);param->endChangeGesture();}}
 juce::Rectangle<float> scaled(juce::Rectangle<int> b) const {const float sx=float(getWidth())/panelWidth,sy=float(getHeight())/(panelHeight+header+footer);return {b.getX()*sx,(b.getY()+header)*sy,b.getWidth()*sx,b.getHeight()*sy};}
 void timerCallback() override {if(preset.getSelectedId()!=processor.getCurrentProgram()+1)preset.setSelectedId(processor.getCurrentProgram()+1,juce::dontSendNotification);repaint();}
 struct Positioned {juce::Component* component;juce::Rectangle<int> bounds;};struct Row {int index;juce::Rectangle<int> bounds;};
 static constexpr int header=40,footer=48;
 PluginProcessor& processor;juce::Image panel,dim;juce::TooltipWindow tooltips;juce::ComboBox preset;juce::ToggleButton bypass;int selected=0;
 std::vector<std::unique_ptr<SpriteSlider>> sliders;std::vector<std::unique_ptr<SpriteButton>> buttons;
 std::vector<std::unique_ptr<juce::Slider>> genericSliders;std::vector<std::unique_ptr<juce::ToggleButton>> genericButtons;std::vector<std::unique_ptr<juce::ComboBox>> combos;
 std::vector<Positioned> positions;std::vector<Row> genericRows;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAttachments;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment>> comboAttachments;
 std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;
 std::unique_ptr<Sprite> lexMeter,needleOn,needleOff;
};
juce::AudioProcessorEditor* PluginProcessor::createEditor(){return new PluginEditor(*this);}
}
