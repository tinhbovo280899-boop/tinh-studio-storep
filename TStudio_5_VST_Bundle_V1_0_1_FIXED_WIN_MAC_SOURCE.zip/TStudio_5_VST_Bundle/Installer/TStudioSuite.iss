#ifndef BundleVersion
  #define BundleVersion "1.0.1"
#endif
#ifndef StageDir
  #define StageDir AddBackslash(SourcePath) + "..\dist\windows"
#endif

[Setup]
AppId={{B971B46C-C0B2-44ED-BE2E-A7664417F8D8}
AppName=T Studio 5 VST Bundle
AppVersion={#BundleVersion}
AppPublisher=T Studio
DefaultDirName={autopf}\T Studio\5 VST Bundle
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\Installers
OutputBaseFilename=TStudio_5VST_{#BundleVersion}_Windows_x64_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UninstallDisplayName=T Studio 5 VST Bundle

[Files]
Source: "{#StageDir}\VST3\T-BE.vst3\*"; DestDir: "{commoncf64}\VST3\T-BE.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-Comp.vst3\*"; DestDir: "{commoncf64}\VST3\T-Comp.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-DeNoise.vst3\*"; DestDir: "{commoncf64}\VST3\T-DeNoise.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-EQ.vst3\*"; DestDir: "{commoncf64}\VST3\T-EQ.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-Pitch.vst3\*"; DestDir: "{commoncf64}\VST3\T-Pitch.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\HUONG_DAN.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs

[Messages]
WelcomeLabel2=This installer installs all five T Studio VST3 plugins. Close your DAW before continuing.
