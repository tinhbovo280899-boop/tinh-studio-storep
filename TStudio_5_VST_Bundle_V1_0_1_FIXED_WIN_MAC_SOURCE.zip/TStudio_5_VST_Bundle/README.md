# T Studio 5 VST Bundle 1.0.1

Một gói nguồn và quy trình tạo **một bộ cài cho năm VST3 riêng**:
T-BE 2.0.1, T-Comp 2.1.3, T-DeNoise 1.1.1, T-EQ 2.0.3, T-Pitch 1.1.1.
Không yêu cầu kích hoạt. Mã nhận dạng và tham số được giữ nguyên để đọc project cũ.

Đọc GHI_CHU_BAN_SUA_1_0_1.md và VALIDATION.txt để biết thay đổi và phạm vi kiểm tra.
Đây là ZIP mã nguồn; không có EXE/PKG hoặc VST3 Windows/macOS đã biên dịch.

## Windows

Cần Visual Studio C++ (Desktop development with C++), CMake 3.22+ tương thích
Visual Studio và Inno Setup 6.3+ để tạo EXE. Giải nén vào thư mục mới, ví dụ
C:\TStudio5, rồi chạy 1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat.

Script build cả năm plugin, chạy kiểm thử, stage đủ VST3 rồi tạo:
Installers/TStudio_5VST_1.0.1_Windows_x64_Setup.exe.
Đóng DAW trước khi cài, sau đó quét lại VST3. Đường dẫn cài:
C:\Program Files\Common Files\VST3.

Chỉ cần VST3: chạy 2_CHI_BUILD_WINDOWS.bat, không cần Inno Setup.
Kết quả ở dist/windows/VST3. Log ở build/logs.
Máy ít RAM có thể giảm số job:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tools\windows.ps1 -Action All -Jobs 2
```

## macOS

Cần Xcode Command Line Tools và CMake 3.22+.
Chạy 1_BUILD_VA_TAO_BO_CAI_MAC.command. Build/test Universal arm64+x86_64 rồi tạo
Installers/TStudio_5VST_1.0.1_macOS_universal.pkg.
PKG cài vào /Library/Audio/Plug-Ins/VST3. Chưa có Developer ID/notarization.
Native build và cài đặt trên Windows/macOS vẫn cần được xác minh trên máy đích.

## Build/test trực tiếp

JUCE 8.0.12 và Signalsmith đã có trong gói; không cần tải chúng qua mạng khi build.

```sh
cmake -S . -B build/manual -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DTBUNDLE_BUILD_HOST_TESTS=ON
cmake --build build/manual --config Release --parallel 4
ctest --test-dir build/manual -C Release --output-on-failure
cmake --install build/manual --config Release --component Plugins --prefix dist/manual
```

Chỉ chạy ba chương trình DSP gốc của BE/Comp/EQ:

```sh
cmake -S . -B build/tests -DCMAKE_BUILD_TYPE=Release -DTBUNDLE_BUILD_PLUGINS=OFF -DBUILD_TESTING=ON -DTBUNDLE_BUILD_HOST_TESTS=OFF
cmake --build build/tests --config Release --parallel 4
ctest --test-dir build/tests -C Release --output-on-failure
```

Test host gốc DeNoise/Pitch được giữ nguyên. tests/regression bổ sung kiểm tra
state sạch/profile, sample rate, reset, host bypass, nonfinite input, cấp phát
và đối chiếu với mã đầu vào trong tests/reference. Những bản reference được
đổi namespace/tên class để biên dịch cùng bản mới, không được dùng để phát âm thanh.

README gốc của từng plugin là tài liệu tham khảo của dự án đầu vào; dùng hướng
dẫn ở thư mục gốc cho bản bundle này. Thông báo/giấy phép nằm trong Licenses,
ThirdParty/JUCE, plugins/T-Pitch/third_party và thư mục T-BE.
