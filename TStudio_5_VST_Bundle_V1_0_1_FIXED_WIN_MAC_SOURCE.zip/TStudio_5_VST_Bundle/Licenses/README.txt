JUCE-LICENSE.md: notice for the included JUCE 8.0.12 framework.
T-BE_LICENSE.txt: original T Studio notice for T-BE source.
T-BE_THIRD_PARTY_NOTICES.md: original T-BE standalone-package notes;
this combined bundle includes JUCE under ThirdParty/JUCE.
Signalsmith notices: original MIT licenses for T-Pitch dependencies.
All other source copyright comments remain in their original files.
