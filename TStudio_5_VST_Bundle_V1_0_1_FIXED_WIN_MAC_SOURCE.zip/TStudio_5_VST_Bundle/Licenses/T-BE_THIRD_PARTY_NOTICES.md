# Third-party software

## JUCE 8.0.12

Source: https://github.com/juce-framework/JUCE/tree/8.0.12 — Copyright Raw Material Software Limited.
Not included in this package: CMake downloads it on the first build (same as T-Comp), or uses a local JUCE folder. JUCE is available under AGPLv3 or a JUCE commercial licence
(including the free Starter/Personal tier below its revenue limit). To sell T-BE as closed source,
use a JUCE licence tier that fits your revenue.

T-BE V2 no longer uses Rubber Band (GPL). The pitch shifter (src/Psola.*) and pitch tracker are original code.
