# T Studio 5 VST Bundle — bản sửa 1.0.1

Gồm T-BE 2.0.1, T-Comp 2.1.3, T-DeNoise 1.1.1, T-EQ 2.0.3 và T-Pitch 1.1.1.
Giữ tên plugin, manufacturer/plugin codes, bundle IDs, parameter IDs và state roots.

- **T-DeNoise:** nạp state không có profile sẽ xóa profile cũ. Get/set state làm
  việc với snapshot riêng; luồng audio chỉ try-lock khi sao chép dữ liệu cố định,
  không chờ xử lý XML/base64. Chặn FFT size/profile sai, NaN/Inf và power âm.
- **Profile DeNoise:** lưu thêm sample rate; ánh xạ theo Hz khi đổi FFT size hoặc
  sample rate, thay vì làm đỉnh 3 kHz thành 6 kHz khi chuyển 48 -> 96 kHz.
  Hệ số power có tính đến cả số mẫu và sample rate. Phần trên Nyquist của profile
  nguồn được để 0 vì không có thông tin, thay vì lặp lại bin cao nhất.
- **Learn đoạn im lặng:** khi Adaptive tắt và profile không chứa noise, không áp
  mức giảm cố định lên vocal. Mô hình khử noise có năng lượng vẫn giữ công thức cũ.
- **Reset DeNoise/Pitch:** xóa lịch sử STFT, pitch tracker và đường dry để không
  phát tiếng của đoạn trước sau reset/seek. Giữ profile đã học khi reset.
  HPF được tính lại sau prepare/sample-rate change. DeNoise khởi tạo output gain
  theo nút Output, bỏ fade từ 0 không chủ ý ở đầu phiên.
- **T-Comp/T-EQ:** host bypass đi qua đường bypass làm mượt của DSP; Comp vẫn
  giữ trễ lookahead cho tín hiệu dry. Giữ bypass ID cũ của VST3, không đổi sang
  getBypassParameter để tránh làm hỏng automation cũ. Nối reset host với reset DSP.
- **T-BE:** đọc key, scale và trạng thái từ cùng một atomic record, tránh lấy
  key của lần cập nhật này ghép với scale lần khác. Parser và đường dẫn handoff
  không đổi; thuật toán bè và preset gốc được giữ nguyên.
- **Dữ liệu lỗi:** ngăn NaN/Inf đi vào tracker/FFT của DeNoise/Pitch; bảo vệ input
  và các control trước phép chuyển sang enum của Comp/EQ/BE. Thêm các biên hợp lệ
  cho Comp và sample rate. Không dùng các bộ chặn này để ép mức vocal bình thường.
- **Build:** chạy các test gốc và hồi quy trước staging/installer; dùng lại JUCE
  objects đã build khi tạo host tests. Bundle version 1.0.1, từng plugin tăng patch.

Profile cũ không lưu sample rate được hiểu theo sample rate của project hiện tại.
Nếu chuyển sample rate với profile cũ, hãy Learn lại rồi lưu project một lần.
Profile mới lưu rõ sample rate nên ánh xạ được khi đổi sang project khác.

Giữ các chế độ và thời gian khối của Signalsmith. T-Pitch Giọng Live vẫn có khoảng
50 ms latency ở 48 kHz, Giọng/Nhạc khoảng 120 ms theo thiết kế cũ. Đổi Mode trong
lúc phát có thể ngắt ngắn vì phải reset engine và thay latency; bản này không biến
việc đổi mode thành chuyển tiếp không gián đoạn. Kiểm tra latency trong DAW thực.

Không có yêu cầu kích hoạt/key mới. Giấy phép và thông báo JUCE, Signalsmith,
nguồn T-BE được giữ nguyên. ZIP chứa nguồn và script tạo bộ cài; Windows/macOS
native, bộ cài và so sánh nghe trên vocal thật chưa được xác minh trong môi trường này.
