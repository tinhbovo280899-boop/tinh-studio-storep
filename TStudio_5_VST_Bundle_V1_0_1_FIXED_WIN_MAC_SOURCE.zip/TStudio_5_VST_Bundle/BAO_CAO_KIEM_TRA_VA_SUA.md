# Kiểm tra và sửa T Studio 5 VST Bundle

Đầu vào: TStudio_5_VST_BUNDLE_WIN_MAC_SOURCE.zip, SHA256
`e8cc6794a4c999228b4f48a1394f6de76e73c872241818ff6ca07747798e7c84`.
Bản gốc được giữ riêng; gói này là bản sửa 1.0.1.

Các lỗi tái hiện ở bản gốc:

- DeNoise: đã Learn rồi nạp state sạch với Adaptive Off vẫn báo còn profile cũ.
- DeNoise/Pitch: sau host reset, phát toàn số 0 vẫn có đỉnh khoảng 0,2 của đoạn
  trước. Wrapper không nối reset với bộ đệm STFT/pitch/dry.
- Một mẫu NaN đầu vào: DeNoise có 15.232/15.360 mẫu không hữu hạn trong phép thử;
  Pitch có 10.816/25.600 mẫu không hữu hạn.
- Profile có đỉnh 3kHz ở 48kHz chuyển sang 96kHz bị đưa lên 6kHz vì chỉ ánh xạ
  theo FFT size và bỏ qua sample rate.
- Learn digital silence, Adaptive Off: giọng thử sau đó bị giảm đúng 12dB dù
  profile không chứa noise. Bản sửa không áp floor giảm cho mô hình noise rỗng.

Các vấn đề xác định qua đường gọi trong mã, có bài hồi quy cho bản sửa:

- Comp/EQ không override host bypass/reset. Comp DSP đã có đường dry trễ đúng,
  nhưng nút host bypass đi thẳng qua AudioProcessor mặc định nên bỏ mất trễ đó.
  Bản sửa dùng đường bypass đã làm mượt, giữ cả ID bypass cũ của VST3.
- get/set profile DeNoise từng đọc/ghi trực tiếp working buffer trong khi audio
  có thể đang học. Bản sửa dùng snapshot riêng và try-lock ở audio, không đưa
  XML/base64 hay chờ khóa vào callback. Profile sai FFT size/NaN/Inf bị bỏ.
- T-BE từng đọc key/scale bằng hai atomic độc lập. Bản sửa lấy cả hai và status
  từ một record, giữ parser và đường dẫn handoff.
- HPF/tracker/dry cần xóa lịch sử khi prepare/reset; output gain DeNoise được
  khởi tạo theo giá trị đã lưu thay vì fade từ 0 ngoài ý muốn.

Toàn bộ 5 chương trình kiểm thử gốc đã chạy qua trước và sau khi sửa. Các test
mới bổ sung trường hợp state, reset, bypass, dữ liệu lỗi và đối chiếu mã cũ.
10/10 nhóm CTest và 30 ca nạp/chạy VST3 Linux đều đạt. Xem VALIDATION.txt và
Validation/full-test-output.log để thấy kết quả chi tiết.

BE không đổi lõi bè; Comp/EQ/Pitch giữ kết quả đối chứng trong các fixture đã
thử; DeNoise giữ đầu ra đối chứng sau phần startup được sửa. Các ca đã thử
không chứng minh không còn mọi lỗi hay chất tiếng tương đương hãng. Chưa nghe
vocal thật, chưa chạy native Windows/macOS hoặc cài và thử trong DAW.
