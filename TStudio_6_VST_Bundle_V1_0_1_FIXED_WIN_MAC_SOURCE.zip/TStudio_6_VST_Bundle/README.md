# T Studio 6 VST Bundle 1.0.1

Gói mã nguồn và quy trình tạo **một bộ cài cho sáu VST3 riêng**: Kaleidoscopes,
T-API550, T-ConsoleEQ, T-HDelay, T-NS1 và T-Vitamin. Kaleidoscopes vẫn có bốn
mô hình bên trong. Không yêu cầu nhập key hoặc kích hoạt.

Đây là **ZIP mã nguồn**, chưa có bộ cài EXE/PKG Windows/macOS đã biên dịch.
Mã nhận dạng plugin, tên tham số và gốc state được giữ nguyên để đọc project cũ.
Xem GHI_CHU_BAN_SUA_1_0_1.md để biết thay đổi DSP, hành vi và giới hạn.

## Windows

1. Giải nén toàn bộ ZIP vào thư mục mới, ví dụ C:\TStudio6.
2. Cần Visual Studio C++ (Desktop development with C++), CMake 3.22+ và
   Inno Setup 6.3+ để tạo EXE. JUCE 8.0.12 đã nằm trong gói.
3. Chạy 1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat. Script build, chạy kiểm thử,
   xuất đủ sáu VST3 rồi tạo Installers/TStudio_6VST_1.0.1_Windows_x64_Setup.exe.
4. Đóng DAW, chạy EXE rồi quét lại plugin. Thư mục cài VST3:
   C:\Program Files\Common Files\VST3.

Chạy 2_CHI_BUILD_WINDOWS.bat nếu chỉ cần build VST3, không cần Inno Setup.
VST3 sau build nằm trong dist/windows/VST3; log nằm trong build/logs.
Nếu ít RAM, chạy:

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File tools\windows.ps1 -Action All -Jobs 2
```

## macOS

Cần Xcode Command Line Tools và CMake 3.22+. Chạy
1_BUILD_VA_TAO_BO_CAI_MAC.command để build và kiểm thử Universal arm64/x86_64,
sau đó tạo Installers/TStudio_6VST_1.0.1_macOS_universal.pkg.
PKG cài sáu VST3 vào /Library/Audio/Plug-Ins/VST3.

Quy trình chưa có chứng thư Developer ID hoặc notarization. Native build, bộ cài
và DAW Windows/macOS vẫn cần được kiểm tra trên máy đích; xem VALIDATION.txt.

## Build và kiểm thử trực tiếp

```sh
cmake -S . -B build/manual -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build/manual --config Release --parallel 4
ctest --test-dir build/manual -C Release --output-on-failure
cmake --install build/manual --config Release --component Plugins --prefix dist/manual
```

Build engine độc lập, không cần JUCE/platform GUI dependencies:

```sh
cmake -S . -B build/engines -DTBUNDLE_BUILD_PLUGINS=OFF -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build/engines --config Release --parallel 4
ctest --test-dir build/engines -C Release --output-on-failure
```

Bộ kiểm thử mới đối chiếu các engine với mã đầu vào trong tests/reference,
kiểm tra DC, buffer delay, dữ liệu không hữu hạn, khởi tạo/reset HDelay,
khôi phục preset NS1 và cấp phát bộ nhớ của Vitamin. NS1 Gentle giữ mức khử
cũ; bài thử giảm noise sử dụng mức tham chiếu riêng cho từng preset, không
coi một ngưỡng chung là yêu cầu cho mọi preset. Hành vi Solo Vitamin được giữ nguyên.

Một cây JUCE dùng chung cho sáu target. Không cần tải JUCE qua mạng khi build.
README trong thư mục plugin là tài liệu tham khảo của bản đầu vào;
hãy dùng hướng dẫn ở thư mục gốc cho bản bundle này.

Thông báo và giấy phép mã nguồn được giữ trong Licenses và ThirdParty/JUCE.
Không thay đổi điều khoản giấy phép JUCE hoặc nguồn bên thứ ba.
BUNDLE_INFO.json, SOURCE_SHA256SUMS.txt và CHANGED_FILES.json ghi nhận
phiên bản, nhận dạng plugin và các thay đổi của bản sửa.
