JUCE-LICENSE.md records the included framework license notice.
T-ConsoleEQ_WetEQ_MIT.txt applies to the original WetEQ source retained in T-ConsoleEQ.
Other copyright notices remain in their original source files.
