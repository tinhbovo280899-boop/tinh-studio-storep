#ifndef BundleVersion
  #define BundleVersion "1.0.1"
#endif
#ifndef StageDir
  #define StageDir AddBackslash(SourcePath) + "..\dist\windows"
#endif

[Setup]
AppId={{8939849C-4B25-493B-952D-557CD23B5298}
AppName=T Studio 6 VST Bundle
AppVersion={#BundleVersion}
AppPublisher=T Studio
DefaultDirName={autopf}\T Studio\6 VST Bundle
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\Installers
OutputBaseFilename=TStudio_6VST_{#BundleVersion}_Windows_x64_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UninstallDisplayName=T Studio 6 VST Bundle

[Files]
Source: "{#StageDir}\VST3\Kaleidoscopes.vst3\*"; DestDir: "{commoncf64}\VST3\Kaleidoscopes.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-API550.vst3\*"; DestDir: "{commoncf64}\VST3\T-API550.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-ConsoleEQ.vst3\*"; DestDir: "{commoncf64}\VST3\T-ConsoleEQ.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-HDelay.vst3\*"; DestDir: "{commoncf64}\VST3\T-HDelay.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-NS1.vst3\*"; DestDir: "{commoncf64}\VST3\T-NS1.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-Vitamin.vst3\*"; DestDir: "{commoncf64}\VST3\T-Vitamin.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\HUONG_DAN.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs

[Messages]
WelcomeLabel2=This installer installs all six T Studio VST3 plugins. Close your DAW before continuing.
