# Thay đổi 1.0.1

- **CLA-2A trong Kaleidoscopes:** bỏ hằng số gây DC −0,0025 ở đầu vào im lặng;
  thêm DC blocker 5 Hz theo sample rate sau tầng tube. Giữ công thức nén,
  gain reduction, tube curve và tùy chọn hum. Không thêm latency.
- **MetaFlanger:** cấp phát đủ 125 ms cộng phần dư nội suy cho toàn bộ Delay/Depth.
  Thiết lập từng bị kẹp ở khoảng 65 ms sẽ có chuyển động đúng toàn hành trình.
- **HDelay:** nạp thông số/tempo trước prepare; chốt thời gian trước mẫu audio đầu;
  giữ glide 35 ms khi đổi thời gian trong lúc đang chạy. Reset xóa vòng đệm và
  filter, không phát echo cũ. Tail là ước lượng dự phòng; feedback cao có thể tự
  dao động nên báo tail vô hạn, kể cả khi limiter giữ biên độ. Đây là metadata,
  không phải phép đo RT60. Analog vẫn có hiss nhỏ khi im lặng như bản cũ.
- **Vitamin:** cache con trỏ tham số năm dải ngoài audio callback; không tạo chuỗi
  mỗi block. Meter dải được chuyển qua atomic. Giữ hành vi Solo/Direct cũ.
- **NS1:** lưu chỉ số preset cùng APVTS và đọc profile tần số từ chỉ số atomic;
  sửa meter UI đọc trực tiếp float của audio thread. Giữ thuật toán và năm preset,
  gồm Gentle Dialogue Clean. Kiểm thử noise đổi từ ngưỡng chung >8 dB sang tham
  chiếu riêng: 10,02 / 13,65 / 16,64 / 24,01 / 7,38 dB, dung sai ±0,20 dB.
  Đây là hồi quy trên tín hiệu thử, không cam kết SNR vocal.
- **State/UI:** lưu và khôi phục chỉ số preset API550/HDelay/NS1/Vitamin và
  Kaleidoscopes; dropdown cập nhật khi host nạp state. Giữ parameter IDs,
  plugin codes, manufacturer codes, bundle IDs và state roots.
- **Dữ liệu lỗi:** HDelay/NS1/Vitamin chặn NaN/Inf ở đầu vào và settings;
  ràng buộc sample rate và biên an toàn rộng cho dữ liệu tràn. Audio hợp lệ
  trong các preset đối chứng không đổi bởi các bộ chặn này.
- **Build:** bỏ đường dẫn sai eq_engine.cpp khỏi host tests; dùng engine/JUCE
  đã biên dịch của từng plugin. Script chính chạy kiểm thử trước khi thay bản
  stage và tạo bộ cài. Tăng phiên bản bundle và sản phẩm lên 1.0.1.

Project cũ vẫn đọc được APVTS. State cũ của NS1 thiếu chỉ số profile không thể
suy ra chắc chắn profile gốc từ các núm đã chỉnh tay: bản sửa dùng profile mặc
định cho state không có trường mới. Chọn lại preset mong muốn và lưu project
một lần để những lần mở sau giữ đúng profile.

Hai EQ không đổi lõi âm thanh. CLA-2A hết lệch DC; MetaFlanger hành trình lớn
và echo ban đầu HDelay thay đổi theo các lỗi được sửa. Chưa xác minh tương
đương thuật toán hoặc âm thanh của sản phẩm hãng.

Gói tải xuống là nguồn kèm script tạo bộ cài. Không đóng kèm binary hãng,
key cá nhân hoặc bộ cài Windows/macOS chưa được build/kiểm tra ở đây.
