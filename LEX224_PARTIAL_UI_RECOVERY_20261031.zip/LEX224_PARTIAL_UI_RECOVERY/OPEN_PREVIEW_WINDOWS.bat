@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python serve_preview.py
) else (
  py -3 serve_preview.py
)
if errorlevel 1 pause
