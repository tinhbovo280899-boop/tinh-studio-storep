# Lexicon 224 — kết quả trích xuất một phần

**Không khôi phục được 100% mã nguồn DSP gốc.** Gói này chứa tài nguyên và mã giao diện đã có trong ZIP anh gửi, bản JavaScript định dạng lại và dữ liệu phân tích. Nó chưa phải project C++/JUCE/TypeScript gốc, VST3 đã dựng lại hoặc plugin có thể xử lý âm thanh.

## Thu được gì

- 49 tệp của thư mục giao diện, gồm 45 ảnh PNG với bản 1×/2×, HTML, JavaScript và hai JSON; giữ nguyên byte so với đầu vào.
- Giao diện gốc 381 × 621 CSS pixel đã mở bằng Chromium qua HTTP localhost. Ảnh thực tế ở `ANALYSIS/original-web-gui-initial.png`.
- `READABLE_UI/bundle.readable.js`: 28.494 dòng sau định dạng, phần lớn bao gồm framework và thư viện giao diện. 83 module webpack có nội dung được tách riêng; các slot trống không tính là module mã.
- Các CSS/HTML được nhúng trong JavaScript được trích ra để đọc, cùng danh sách ID tĩnh của giao diện. Đường dẫn ảnh trong CSS vẫn là đường dẫn tương đối gốc; đây là tài liệu tham khảo, không phải bộ build frontend mới.
- 55 factory preset JSON được giữ nguyên. Chunk base64 được giải ra thành dữ liệu word trong báo cáo, nhưng chưa xác minh ánh xạ từng word sang tham số; không gọi đó là thuật toán reverb.

JavaScript dễ đọc có cùng cây cú pháp AST với bundle gốc sau khi bỏ vị trí và cách viết literal; kiểm tra này không phục hồi tên biến đã bị rút gọn, TypeScript, comment hay source map đã mất. Đây là mã giao diện phía client, không chứa thuật toán âm thanh C++.

## Vì sao chưa lấy được DSP

ZIP chứa một `.lunacomponent` cho hệ thống host của UA, với `algo.bundle/.../Windows/uaudio_lexicon_224.x64.dll` bản 1.4.16. DLL là PE32+ x64 đã biên dịch, có metadata PACE/iLok, section `.guard`, các export bị bọc và vùng `.text` chính có entropy khoảng 7,999991 bit/byte. Không có tệp `.cpp/.h/.ts/.map/.pdb` trong gói.

Đã đọc cấu trúc PE/export và thử disassembly tại entrypoint cùng ba export chính. Bootstrap có mã máy đọc được, còn các byte ở export xử lý không cho một luồng DSP có thể tin cậy để dựng lại thuật toán. `entrypoints.asm.txt` là dấu vết phân tích thô; những lệnh x86 giải mã từ dữ liệu được bảo vệ không được coi là mã nguồn DSP đã phục hồi. Chỉ riêng entropy cao cũng không phải chứng minh độc lập rằng mọi byte đều mã hóa; kết luận dựa trên cả metadata, bố cục PE và kết quả đọc mã.

Kể cả với DLL không có lớp bảo vệ, dịch ngược thường chỉ tạo mã giả tương đương một phần. Tên biến, comment, kiểu dữ liệu gốc, cấu trúc project và nhiều thông tin đã mất sau tối ưu hóa không thể khôi phục đúng 100% từ binary này.

## Mở giao diện để xem

- Windows có Python 3: chạy `OPEN_PREVIEW_WINDOWS.bat`.
- macOS/Linux có Python 3: chạy `python3 serve_preview.py`.
- Hoặc chạy HTTP server của anh trong thư mục này và mở `preview.html`.

Preview dùng nguyên giao diện web gốc, không nạp DLL. Do thiếu dịch vụ host/DSP của UA, trạng thái đèn, giá trị nút và meter không đại diện cho plugin đang chạy; một số thao tác không hoạt động. Nó không tạo tiếng vang và không thể đưa vào Cubase như một VST3.

`ORIGINAL_FILES_SHA256.json` đối chiếu toàn bộ 104 tệp giao diện/preset với đầu vào. Các ảnh và mã UA/Lexicon được giữ tên/tác giả của tài nguyên gốc. Không ghép các tài nguyên này vào sản phẩm T Studio trong lượt này. DLL DSP, license blobs và các tệp kích hoạt không nằm trong gói trích xuất.


## Kiểm tra gói

85 tệp JavaScript qua kiểm tra cú pháp Node; 104 tệp giao diện/preset gốc khớp SHA-256. Ba lần render trình duyệt gồm bản gốc 1×, bản dễ đọc 1× và bản gốc 2× đều không có page error hoặc tài nguyên HTTP lỗi. Bản gốc/bản dễ đọc ở 1× có sai khác pixel tối đa bằng 0 trong trạng thái chưa kết nối host. Chưa kiểm tra chức năng DSP/audio hoặc chạy launcher native Windows/macOS.
