// Extracted webpack module 87. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-checkbox",
        o = '\x3c!-- BG: HBGF-1335: This component is deprecated: does not use "canonical" naming for container, display and click-region pattern--\x3e\n\n\x3c!-- Container --\x3e\n<div class="container ${disabled ? \'disabled\' : \'\'}">\n\n  \x3c!-- BG: HBGF-1335: Prevent implicit compositing by placing "static" click region underneath composited display --\x3e\n  \x3c!-- Click region --\x3e\n  <label class="click-region">\n    <input type="checkbox" checked.two-way="value" disabled.bind="disabled" mousedown.delegate="onMouseDown($event)">\n  </label>\n\n  \x3c!-- Display --\x3e\n  <div \n    class="display indicator ${value ? \'active\' : \'\'}"\n    skin-site="value.bind: skin; type.bind: skinType"\n    ref="$display"\n  >\n  </div>\n</div>\n';
    t.default = o;
    const a = [r.j.defer(".css", ':host {\n  display: inline-block;\n  position: relative;\n  --ua-checkbox-size-default: 16px;\n  width: var(--ua-checkbox-size, var(--ua-checkbox-size-default));\n  height: var(--ua-checkbox-size, var(--ua-checkbox-size-default));\n}\n\n:host(:focus) {\n  outline: none;\n}\n\n.container {\n  position: relative;\n  width: 100%;\n  height: 100%;\n}\n\n.click-region {\n  position: absolute;\n  top: calc(-1 * var(--ua-checkbox-click-region-top, 0px));\n  left: calc(-1 * var(--ua-checkbox-click-region-left, 0px));\n  height: calc(100% + var(--ua-checkbox-click-region-top, 0px) + var(--ua-checkbox-click-region-bottom, 0px));\n  width: calc(100% + var(--ua-checkbox-click-region-left, 0px) + var(--ua-checkbox-click-region-right, 0px));\n  border: var(--ua-click-region-border, none);\n}\n\n.display {\n  pointer-events: none;\n}\n\n/* Hide the browser\'s default checkbox */\ninput {\n  position: absolute;\n  opacity: 0;\n  /*cursor: pointer;*/\n  height: 100%;\n  width: 100%;\n}\n\n/* Create a custom checkbox */\n.indicator {\n  position: absolute;\n  height: 100%;\n  width: 100%;\n  background-color: var(--ua-checkbox-background, transparent);\n  border: var(--ua-checkbox-border, 1px solid #5F5F5F);\n  border-radius: var(--ua-checkbox-radius, 2px);\n}\n\n/* Create the checkmark/indicator (hidden when not checked) */\n.indicator:after {\n  content: "";\n  position: absolute;\n  opacity: 0;\n  top: -2.5%;\n  left: 29%;\n  width: 30%;\n  height: 75%;\n  border-style: solid;\n  border-color: var(--ua-checkbox-indicator-color, transparent);\n  border-width: 0  calc(var(--ua-checkbox-size, var(--ua-checkbox-size-default)) / 8)  calc(var(--ua-checkbox-size, var(--ua-checkbox-size-default)) / 8) 0;\n  transform: rotate(45deg);\n  transition: all 150ms ease-in-out;\n}\n\n/* When the checkbox is checked, add a blue background */\n.indicator.active {\n  background-color: var(--ua-checkbox-background-active, #2196F3);\n  border: var(--ua-checkbox-border-active, 1px solid var(--ua-checkbox-background-active, #2196F3));\n}\n\n/* Style the checkmark/indicator */\n.indicator.active:after {\n  border-color: var(--ua-checkbox-indicator-active-color, white);\n  opacity: 1;\n}\n\n.disabled {\n  opacity: var(--ua-disabled-opacity, 1.0);\n}\n')],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
