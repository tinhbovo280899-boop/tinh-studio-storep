// Extracted webpack module 11. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "l", (function() {
        return o
    })), n.d(t, "h", (function() {
        return a
    })), n.d(t, "m", (function() {
        return c
    })), n.d(t, "g", (function() {
        return l
    })), n.d(t, "c", (function() {
        return u
    })), n.d(t, "a", (function() {
        return h
    })), n.d(t, "d", (function() {
        return d
    })), n.d(t, "b", (function() {
        return p
    })), n.d(t, "e", (function() {
        return f
    })), n.d(t, "f", (function() {
        return g
    })), n.d(t, "k", (function() {
        return m
    })), n.d(t, "i", (function() {
        return v
    })), n.d(t, "j", (function() {
        return b
    })), n.d(t, "n", (function() {
        return y
    }));
    n(29);
    var i, r = n(3),
        s = n(46);
    const o = e => Object(r.h)(e) ? "mouse" : Object(r.k)(e) ? "wheel" : Object(r.j)(e) ? "touch" : "mouse",
        a = e => {
            switch (e) {
                case "mousedown":
                case "touchstart":
                    return "down";
                case "mousemove":
                case "touchmove":
                    return "move";
                case "mouseup":
                case "touchend":
                case "touchcancel":
                    return "up";
                default:
                    return e
            }
        },
        c = e => "down" === e || "move" === e || "up" === e;
    var l;
    ! function(e) {
        e.start = "start", e.change = "change", e.revert = "revert", e.default = "default", e.end = "end"
    }(l || (l = {}));
    const u = {
            reconciliation: {
                END: !0
            },
            meter: {
                defaultMeterValue: 0,
                ignorePluginPower: !1
            }
        },
        h = {
            icon: "",
            loading_image: "",
            name: "PLUGIN_NAME",
            window: {
                width: 400,
                height: 400
            }
        },
        d = {
            UA_FINAL_CANDIDATE_BUILD: !1
        },
        p = s,
        f = {
            guiManifestJson: "manifest.json",
            hbgfDevFeaturesJson: "hbgf_dev_features.json"
        },
        g = !!(null === (i = window) || void 0 === i ? void 0 : i.ua_amber_env),
        m = () => window,
        v = () => {
            const e = m().hbgf_store;
            return null == e ? void 0 : e.get("environment")
        },
        b = e => {
            const t = v();
            return null == t ? void 0 : t[e]
        },
        y = (e, t) => {
            const n = v();
            return !!n && (n[e] = t, !0)
        }
});
