// Extracted webpack module 2. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    var i, r = n(18);
    ! function(e) {
        e[e.error = 0] = "error", e[e.warn = 1] = "warn", e[e.info = 2] = "info", e[e.debug = 3] = "debug"
    }(i || (i = {}));
    const s = {
            level: 1,
            write(e, ...t) {},
            error: (e, ...t) => new Error("Code " + e)
        },
        o = {
            enabled: !1,
            liveLoggingEnabled: !1,
            liveWriter: null,
            enter(e, t, n) {},
            leave() {},
            writeStack(e) {},
            flushAll(e) {},
            enableLiveLogging: function(e) {
                return
            },
            disableLiveLogging() {}
        };
    const a = new WeakMap;

    function c(e) {
        switch (typeof e) {
            case "function":
                return e;
            case "object":
                if (null === e) throw new TypeError("Attempted to perform get() or define() metadata operation on null value.");
                return e;
            default:
                throw new TypeError(`Attempted to perform get() or define() metadata operation on ${typeof e} value: ${e}.`)
        }
    }

    function l(e) {
        switch (typeof e) {
            case "undefined":
            case "string":
            case "symbol":
                return e;
            default:
                return "" + e
        }
    }

    function u(e, t, n) {
        let i = a.get(e);
        if (void 0 === i) {
            if (!n) return;
            i = new Map, a.set(e, i)
        }
        let r = i.get(t);
        if (void 0 === r) {
            if (!n) return;
            r = new Map, i.set(t, r)
        }
        return r
    }

    function h(e, t, n) {
        const i = u(t, n, !1);
        return void 0 !== i && i.has(e)
    }

    function d(e, t, n) {
        const i = u(t, n, !1);
        if (void 0 !== i) return i.get(e)
    }

    function p(e, t, n, i) {
        u(n, i, !0).set(e, t)
    }

    function f(e, t) {
        const n = [],
            i = u(e, t, !1);
        if (void 0 === i) return n;
        const r = i.keys();
        let s = 0;
        for (const e of r) n[s] = e, ++s;
        return n
    }

    function g(e, t, n, i) {
        return p(e, t, c(n), l(i))
    }

    function m(e, t, n) {
        return function e(t, n, i) {
            if (h(t, n, i)) return !0;
            const r = Object.getPrototypeOf(n);
            return null !== r && e(t, r, i)
        }(e, c(t), l(n))
    }

    function v(e, t, n) {
        return h(e, c(t), l(n))
    }

    function b(e, t, n) {
        return function e(t, n, i) {
            if (h(t, n, i)) return d(t, n, i);
            const r = Object.getPrototypeOf(n);
            return null !== r ? e(t, r, i) : void 0
        }(e, c(t), l(n))
    }

    function y(e, t, n) {
        return d(e, c(t), l(n))
    }

    function w(e, t) {
        return function e(t, n) {
            const i = f(t, n),
                r = Object.getPrototypeOf(t);
            if (null === r) return i;
            const s = e(r, n),
                o = i.length;
            if (0 === o) return s;
            const a = s.length;
            if (0 === a) return i;
            const c = new Set,
                l = [];
            let u, h = 0;
            for (let e = 0; e < o; ++e) u = i[e], c.has(u) || (c.add(u), l[h] = u, ++h);
            for (let e = 0; e < a; ++e) u = s[e], c.has(u) || (c.add(u), l[h] = u, ++h);
            return l
        }(c(e), l(t))
    }

    function k(e, t) {
        return f(c(e), l(t))
    }

    function x(e, t, n) {
        return function(e, t, n) {
            const i = u(e, n, !1);
            return void 0 !== i && i.delete(t)
        }(c(t), e, l(n))
    }
    const _ = {
        define: g,
        has: m,
        hasOwn: v,
        get: b,
        getOwn: y,
        getKeys: w,
        getOwnKeys: k,
        delete: x
    };

    function S(e, t, n) {
        Reflect.defineProperty(e, t, {
            writable: !0,
            enumerable: !1,
            configurable: !0,
            value: n
        })
    }
    S(_, "$Internal", a);
    const O = "metadata" in Reflect,
        C = "decorate" in Reflect,
        A = "defineMetadata" in Reflect,
        T = "hasMetadata" in Reflect,
        E = "hasOwnMetadata" in Reflect,
        j = "getMetadata" in Reflect,
        M = "getOwnMetadata" in Reflect,
        L = "getMetadataKeys" in Reflect,
        P = "getOwnMetadataKeys" in Reflect,
        R = "deleteMetadata" in Reflect;
    (O || C || A || T || E || j || M || L || P || R) && !(O && C && A && T && E && j && M && L && P && R) && console.warn("Partial existing Reflect.metadata polyfill found. Working environment cannot be guaranteed. Please file an issue at https://github.com/aurelia/aurelia/issues so that we can look into compatibility options for this scenario."), O || S(Reflect, "metadata", (function(e, t) {
        return function(n, i) {
            p(e, t, c(n), function(e) {
                switch (typeof e) {
                    case "undefined":
                    case "string":
                    case "symbol":
                        return e;
                    default:
                        throw new TypeError(`Invalid metadata propertyKey: ${e}.`)
                }
            }(i))
        }
    })), C || S(Reflect, "decorate", (function(e, t, n, i) {
        if (void 0 !== n) {
            if (!Array.isArray(e)) throw new TypeError;
            if ("object" != typeof t || null === t) throw new TypeError;
            if (("object" != typeof i || null === i) && "function" != typeof i && null != i) throw new TypeError;
            return null === i && (i = void 0),
                function(e, t, n, i) {
                    for (let r = e.length - 1; r >= 0; --r) {
                        const s = (0, e[r])(t, n, i);
                        if (null != s) {
                            if (("object" != typeof s || null === s) && "function" != typeof s) throw new TypeError;
                            i = s
                        }
                    }
                    return i
                }(e, t, n = function(e) {
                    switch (typeof e) {
                        case "string":
                        case "symbol":
                            return e;
                        default:
                            return "" + e
                    }
                }(n), i)
        }
        if (!Array.isArray(e)) throw new TypeError;
        if ("function" != typeof t) throw new TypeError;
        return function(e, t) {
            for (let n = e.length - 1; n >= 0; --n) {
                const i = (0, e[n])(t);
                if (null != i) {
                    if ("function" != typeof i) throw new TypeError;
                    t = i
                }
            }
            return t
        }(e, t)
    })), A || S(Reflect, "defineMetadata", g), T || S(Reflect, "hasMetadata", m), E || S(Reflect, "hasOwnMetadata", v), j || S(Reflect, "getMetadata", b), M || S(Reflect, "getOwnMetadata", y), L || S(Reflect, "getMetadataKeys", w), P || S(Reflect, "getOwnMetadataKeys", k), R || S(Reflect, "deleteMetadata", x);
    class I {
        constructor(e) {
            this.context = e
        }
        find(e, t) {
            const n = e.keyFrom(t);
            let i = this.context.resourceResolvers,
                r = i[n];
            if (void 0 === r && (i = this.context.root.resourceResolvers, r = i[n]), null != r && r.getFactory) {
                const t = r.getFactory(this.context);
                if (null != t) {
                    const n = _.getOwn(e.name, t.Type);
                    return void 0 === n ? null : n
                }
            }
            return null
        }
        create(e, t) {
            const n = e.keyFrom(t);
            let i = this.context.resourceResolvers,
                r = i[n];
            if (void 0 === r && (i = this.context.root.resourceResolvers, r = i[n]), null != r) {
                const e = r.resolve(this.context, this.context);
                return void 0 === e ? null : e
            }
            return null
        }
    }
    const D = {
            name: "au:annotation",
            appendTo(e, t) {
                const n = _.getOwn(D.name, e);
                void 0 === n ? _.define(D.name, [t], e) : n.push(t)
            },
            set(e, t, n) {
                _.define(D.keyFor(t), n, e)
            },
            get: (e, t) => _.getOwn(D.keyFor(t), e),
            getKeys(e) {
                let t = _.getOwn(D.name, e);
                return void 0 === t && _.define(D.name, t = [], e), t
            },
            isKey: e => e.startsWith(D.name),
            keyFor: (e, t) => void 0 === t ? `${D.name}:${e}` : `${D.name}:${e}:${t}`
        },
        N = {
            name: "au:resource",
            appendTo(e, t) {
                const n = _.getOwn(N.name, e);
                void 0 === n ? _.define(N.name, [t], e) : n.push(t)
            },
            has: e => _.hasOwn(N.name, e),
            getAll(e) {
                const t = _.getOwn(N.name, e);
                return void 0 === t ? r.a.emptyArray : t.map(t => _.getOwn(t, e))
            },
            getKeys(e) {
                let t = _.getOwn(N.name, e);
                return void 0 === t && _.define(N.name, t = [], e), t
            },
            isKey: e => e.startsWith(N.name),
            keyFor: (e, t) => void 0 === t ? `${N.name}:${e}` : `${N.name}:${e}:${t}`
        },
        V = {
            annotation: D,
            resource: N
        },
        $ = Object.prototype.hasOwnProperty;

    function F(e, t, n, i) {
        let r = _.getOwn(V.annotation.keyFor(e), n);
        return void 0 === r ? (r = t[e], void 0 === r ? (r = n[e], void 0 !== r && $.call(n, e) ? r : i()) : r) : r
    }

    function U(e, t, n) {
        let i = _.getOwn(V.annotation.keyFor(e), t);
        return void 0 === i ? (i = t[e], void 0 !== i && $.call(t, e) ? i : n()) : i
    }

    function B(e, t, n) {
        const i = t[e];
        return void 0 === i ? n() : i
    }
    const z = {};

    function H(e) {
        switch (typeof e) {
            case "number":
                return !0;
            case "string": {
                const t = z[e];
                if (void 0 !== t) return t;
                const {
                    length: n
                } = e;
                if (0 === n) return z[e] = !1;
                let i = 0;
                for (let t = 0; t < n; ++t)
                    if (i = e.charCodeAt(t), i < 48 || i > 57) return z[e] = !1;
                return z[e] = !0
            }
            default:
                return !1
        }
    }

    function W(e) {
        switch (typeof e) {
            case "number":
            case "bigint":
                return !0;
            default:
                return !1
        }
    }

    function q(e) {
        switch (typeof e) {
            case "string":
                return !0;
            case "object":
                return e instanceof Date;
            default:
                return !1
        }
    }
    const G = function() {
            let e;
            ! function(e) {
                e[e.none = 0] = "none", e[e.digit = 1] = "digit", e[e.upper = 2] = "upper", e[e.lower = 3] = "lower"
            }(e || (e = {}));
            const t = Object.freeze(Object.assign(Object.create(null), {
                0: !0,
                1: !0,
                2: !0,
                3: !0,
                4: !0,
                5: !0,
                6: !0,
                7: !0,
                8: !0,
                9: !0
            }));

            function n(e) {
                return "" === e ? 0 : e !== e.toUpperCase() ? 3 : e !== e.toLowerCase() ? 2 : !0 === t[e] ? 1 : 0
            }
            return function(e, t) {
                const i = e.length;
                if (0 === i) return e;
                let r, s = !1,
                    o = "",
                    a = "",
                    c = 0,
                    l = e.charAt(0),
                    u = n(l);
                for (let h = 0; h < i; ++h) r = c, a = l, c = u, l = e.charAt(h + 1), u = n(l), 0 === c ? o.length > 0 && (s = !0) : (!s && o.length > 0 && 2 === c && (s = 3 === r || 3 === u), o += t(a, s), s = !1);
                return o
            }
        }(),
        K = function() {
            const e = Object.create(null);

            function t(e, t) {
                return t ? e.toUpperCase() : e.toLowerCase()
            }
            return function(n) {
                let i = e[n];
                return void 0 === i && (i = e[n] = G(n, t)), i
            }
        }(),
        Y = function() {
            const e = Object.create(null);
            return function(t) {
                let n = e[t];
                return void 0 === n && (n = K(t), n.length > 0 && (n = n[0].toUpperCase() + n.slice(1)), e[t] = n), n
            }
        }(),
        X = function() {
            const e = Object.create(null);

            function t(e, t) {
                return t ? "-" + e.toLowerCase() : e.toLowerCase()
            }
            return function(n) {
                let i = e[n];
                return void 0 === i && (i = e[n] = G(n, t)), i
            }
        }();

    function J(e) {
        const {
            length: t
        } = e, n = Array(t);
        for (let i = 0; i < t; ++i) n[i] = e[i];
        return n
    }
    const Q = {};

    function Z(e) {
        return void 0 === Q[e] && (Q[e] = 0), ++Q[e]
    }

    function ee(e, t) {
        return e - t
    }
    const te = r.a.emptyArray;

    function ne(e, t, n) {
        if (null == e || e === te) return null == t || t === te ? te : n ? t.slice(0) : t;
        if (null == t || t === te) return n ? e.slice(0) : e;
        const i = {},
            r = n ? e.slice(0) : e;
        let s, o = e.length,
            a = t.length;
        for (; o-- > 0;) i[e[o]] = !0;
        for (; a-- > 0;) s = t[a], void 0 === i[s] && (r.push(s), i[s] = !0);
        return r
    }

    function ie(...e) {
        const t = [];
        let n = 0;
        const i = e.length;
        let r, s = 0;
        for (let o = 0; o < i; ++o)
            if (r = e[o], void 0 !== r) {
                s = r.length;
                for (let e = 0; e < s; ++e) t[n++] = r[e]
            } return t
    }

    function re(...e) {
        const t = e.length;
        let n;
        for (let i = 0; i < t; ++i)
            if (n = e[i], void 0 !== n) return n;
        throw new Error("No default value found")
    }
    const se = function() {
        const e = Function.prototype,
            t = Object.getPrototypeOf,
            n = new WeakMap;
        let i = e,
            r = 0,
            s = void 0;
        return function(o) {
            if (s = n.get(o), void 0 === s)
                for (n.set(o, s = [i = o]), r = 0;
                    (i = t(i)) !== e;) s[++r] = i;
            return s
        }
    }();

    function oe(e) {
        const t = e.slice(),
            n = Object.keys(e),
            i = n.length;
        let r;
        for (let s = 0; s < i; ++s) r = n[s], H(r) || (t[r] = e[r]);
        return t
    }
    class ae {
        constructor() {}
        static createContainer(...e) {
            return 0 === e.length ? new ye(null) : new ye(null).register(...e)
        }
        static getDesignParamtypes(e) {
            return _.getOwn("design:paramtypes", e)
        }
        static getAnnotationParamtypes(e) {
            const t = V.annotation.keyFor("di:paramtypes");
            return _.getOwn(t, e)
        }
        static getOrCreateAnnotationParamTypes(e) {
            const t = V.annotation.keyFor("di:paramtypes");
            let n = _.getOwn(t, e);
            return void 0 === n && (_.define(t, n = [], e), V.annotation.appendTo(e, t)), n
        }
        static getDependencies(e) {
            const t = V.annotation.keyFor("di:dependencies");
            let n = _.getOwn(t, e);
            if (void 0 === n) {
                const i = e.inject;
                if (void 0 === i) {
                    const t = ae.getDesignParamtypes(e),
                        i = ae.getAnnotationParamtypes(e);
                    if (void 0 === t)
                        if (void 0 === i) {
                            const t = Object.getPrototypeOf(e);
                            n = "function" == typeof t && t !== Function.prototype ? oe(ae.getDependencies(t)) : []
                        } else n = oe(i);
                    else if (void 0 === i) n = oe(t);
                    else {
                        n = oe(t);
                        let e, r = i.length;
                        for (let t = 0; t < r; ++t) e = i[t], void 0 !== e && (n[t] = e);
                        const s = Object.keys(i);
                        let o;
                        r = s.length;
                        for (let e = 0; e < r; ++e) o = s[e], H(o) || (n[o] = i[o])
                    }
                } else n = oe(i);
                _.define(t, n, e), V.annotation.appendTo(e, t)
            }
            return n
        }
        static createInterface(e) {
            const t = function(e, n, i) {
                if (null == e) throw s.error(16, t.friendlyName, t);
                return ae.getOrCreateAnnotationParamTypes(e)[i] = t, e
            };
            return t.friendlyName = null == e ? "Interface" : e, t.noDefault = function() {
                return t
            }, t.withDefault = function(e) {
                return t.withDefault = function() {
                    throw s.error(17, t)
                }, t.register = function(n, i) {
                    const r = null == i ? t : i;
                    return e({
                        instance: e => n.registerResolver(r, new pe(r, 0, e)),
                        singleton: e => n.registerResolver(r, new pe(r, 1, e)),
                        transient: e => n.registerResolver(r, new pe(r, 2, e)),
                        callback: e => n.registerResolver(r, new pe(r, 3, e)),
                        aliasTo: e => n.registerResolver(r, new pe(r, 5, e))
                    })
                }, t
            }, t
        }
        static inject(...e) {
            return function(t, n, i) {
                if ("number" == typeof i) {
                    const n = ae.getOrCreateAnnotationParamTypes(t),
                        r = e[0];
                    void 0 !== r && (n[i] = r)
                } else if (n) {
                    const i = ae.getOrCreateAnnotationParamTypes(t.constructor),
                        r = e[0];
                    void 0 !== r && (i[n] = r)
                } else if (i) {
                    const t = i.value,
                        n = ae.getOrCreateAnnotationParamTypes(t);
                    let r;
                    for (let t = 0; t < e.length; ++t) r = e[t], void 0 !== r && (n[t] = r)
                } else {
                    const n = ae.getOrCreateAnnotationParamTypes(t);
                    let i;
                    for (let t = 0; t < e.length; ++t) i = e[t], void 0 !== i && (n[t] = i)
                }
            }
        }
        static transient(e) {
            return e.register = function(t) {
                return ke.transient(e, e).register(t, e)
            }, e
        }
        static singleton(e) {
            return e.register = function(t) {
                return ke.singleton(e, e).register(t, e)
            }, e
        }
    }
    const ce = ae.createInterface("IContainer").noDefault(),
        le = ce;

    function ue(e) {
        return function(t) {
            const n = function(e, t, i) {
                ae.inject(n)(e, t, i)
            };
            return n.resolve = function(n, i) {
                return e(t, n, i)
            }, n
        }
    }
    ae.inject;
    const he = ue((e, t, n) => n.getAll(e));
    ue((e, t, n) => {
        let i = null;
        return () => (null == i && (i = n.get(e)), i)
    }), ue((e, t, n) => n.has(e, !0) ? n.get(e) : null);
    var de;
    ! function(e) {
        e[e.instance = 0] = "instance", e[e.singleton = 1] = "singleton", e[e.transient = 2] = "transient", e[e.callback = 3] = "callback", e[e.array = 4] = "array", e[e.alias = 5] = "alias"
    }(de || (de = {}));
    class pe {
        constructor(e, t, n) {
            this.key = e, this.strategy = t, this.state = n
        }
        register(e, t) {
            return e.registerResolver(t || this.key, this)
        }
        resolve(e, t) {
            switch (this.strategy) {
                case 0:
                    return this.state;
                case 1: {
                    this.strategy = 0;
                    const n = e.getFactory(this.state);
                    if (null === n) throw new Error(`Resolver for ${String(this.key)} returned a null factory`);
                    return this.state = n.construct(t)
                }
                case 2: {
                    const n = e.getFactory(this.state);
                    if (null === n) throw new Error(`Resolver for ${String(this.key)} returned a null factory`);
                    return n.construct(t)
                }
                case 3:
                    return this.state(e, t, this);
                case 4:
                    return this.state[0].resolve(e, t);
                case 5:
                    return e.get(this.state);
                default:
                    throw s.error(6, this.strategy)
            }
        }
        getFactory(e) {
            let t;
            switch (this.strategy) {
                case 1:
                case 2:
                    return e.getFactory(this.state);
                case 5:
                    return t = e.getResolver(this.state), null == t || void 0 === t.getFactory ? null : t.getFactory(e);
                default:
                    return null
            }
        }
    }
    class fe {
        constructor(e, t, n) {
            this.Type = e, this.invoker = t, this.dependencies = n, this.transformers = null
        }
        construct(e, t) {
            const n = this.transformers;
            let i = void 0 !== t ? this.invoker.invokeWithDynamicDependencies(e, this.Type, this.dependencies, t) : this.invoker.invoke(e, this.Type, this.dependencies);
            if (null == n) return i;
            for (let e = 0, t = n.length; e < t; ++e) i = n[e](i);
            return i
        }
        registerTransformer(e) {
            return null == this.transformers && (this.transformers = []), this.transformers.push(e), !0
        }
    }
    const ge = function() {
            function e(e, t, n, i) {
                let r, o = n.length,
                    a = new Array(o);
                for (; o-- > 0;) {
                    if (r = n[o], null == r) throw s.error(7, `Index ${o}.`);
                    a[o] = e.get(r)
                }
                return void 0 !== i && (a = a.concat(i)), Reflect.construct(t, a)
            }
            const t = [{
                    invoke: (e, t) => new t,
                    invokeWithDynamicDependencies: e
                }, {
                    invoke: (e, t, n) => new t(e.get(n[0])),
                    invokeWithDynamicDependencies: e
                }, {
                    invoke: (e, t, n) => new t(e.get(n[0]), e.get(n[1])),
                    invokeWithDynamicDependencies: e
                }, {
                    invoke: (e, t, n) => new t(e.get(n[0]), e.get(n[1]), e.get(n[2])),
                    invokeWithDynamicDependencies: e
                }, {
                    invoke: (e, t, n) => new t(e.get(n[0]), e.get(n[1]), e.get(n[2]), e.get(n[3])),
                    invokeWithDynamicDependencies: e
                }, {
                    invoke: (e, t, n) => new t(e.get(n[0]), e.get(n[1]), e.get(n[2]), e.get(n[3]), e.get(n[4])),
                    invokeWithDynamicDependencies: e
                }],
                n = {
                    invoke: e,
                    invokeWithDynamicDependencies: e
                };
            return function(e) {
                const i = ae.getDependencies(e),
                    r = t.length > i.length ? t[i.length] : n;
                return new fe(e, r, i)
            }
        }(),
        me = {
            resolve: (e, t) => t
        };

    function ve(e) {
        return "function" == typeof e.register
    }
    const be = function() {
        let e = 0;
        return function() {
            return ++e
        }
    }();
    class ye {
        constructor(e) {
            this.parent = e, this.id = be(), this.registerDepth = 0, null === e ? (this.path = this.id.toString(), this.root = this, this.resolvers = new Map, this.resourceResolvers = Object.create(null)) : (this.path = `${e.path}.${this.id}`, this.root = e.root, this.resolvers = new Map, this.resourceResolvers = Object.assign(Object.create(null), this.root.resourceResolvers)), this.resolvers.set(ce, me)
        }
        register(...e) {
            if (100 == ++this.registerDepth) throw new Error("Unable to autoregister dependency");
            let t, n, i, r, s;
            for (let o = 0, a = e.length; o < a; ++o)
                if (t = e[o], ve(t)) t.register(this);
                else if (V.resource.has(t)) {
                const e = V.resource.getAll(t);
                if (1 === e.length) e[0].register(this);
                else {
                    const t = e.length;
                    for (let n = 0; n < t; ++n) e[n].register(this)
                }
            } else if (void 0 !== t.prototype) ke.singleton(t, t).register(this);
            else
                for (n = Object.keys(t), r = 0, s = n.length; r < s; ++r) i = t[n[r]], ve(i) ? i.register(this) : this.register(i);
            return --this.registerDepth, this
        }
        registerResolver(e, t) {
            _e(e);
            const n = this.resolvers,
                i = n.get(e);
            return null == i ? (n.set(e, t), function(e) {
                return "string" == typeof e && e.indexOf(":") > 0
            }(e) && (this.resourceResolvers[e] = t)) : i instanceof pe && 4 === i.strategy ? i.state.push(t) : n.set(e, new pe(e, 4, [i, t])), t
        }
        registerTransformer(e, t) {
            const n = this.getResolver(e);
            if (null == n) return !1;
            if (n.getFactory) {
                const e = n.getFactory(this);
                return null != e && e.registerTransformer(t)
            }
            return !1
        }
        getResolver(e, t = !0) {
            if (_e(e), void 0 !== e.resolve) return e;
            let n, i = this;
            for (; null != i;) {
                if (n = i.resolvers.get(e), null != n) return n;
                if (null == i.parent) return t ? this.jitRegister(e, i) : null;
                i = i.parent
            }
            return null
        }
        has(e, t = !1) {
            return !!this.resolvers.has(e) || !(!t || null == this.parent) && this.parent.has(e, !0)
        }
        get(e) {
            if (_e(e), void 0 !== e.resolve) return e.resolve(this, this);
            let t, n = this;
            for (; null != n;) {
                if (t = n.resolvers.get(e), null != t) return t.resolve(n, this);
                if (null == n.parent) return t = this.jitRegister(e, n), t.resolve(n, this);
                n = n.parent
            }
            throw new Error("Unable to resolve key: " + e)
        }
        getAll(e) {
            _e(e);
            let t, n = this;
            for (; null != n;) {
                if (t = n.resolvers.get(e), null != t) return Se(t, n, this);
                if (null == this.parent) return r.a.emptyArray;
                n = n.parent
            }
            return r.a.emptyArray
        }
        getFactory(e) {
            const t = V.annotation.keyFor("di:factory");
            let n = _.getOwn(t, e);
            return void 0 === n && (_.define(t, n = ge(e), e), V.annotation.appendTo(e, t)), n
        }
        createChild() {
            return new ye(this)
        }
        jitRegister(e, t) {
            if ("function" != typeof e) throw new Error(`Attempted to jitRegister something that is not a constructor: '${e}'. Did you forget to register this resource?`);
            if (ve(e)) {
                const n = e.register(t, e);
                if (!(n instanceof Object) || null == n.resolve) {
                    const n = t.resolvers.get(e);
                    if (null != n) return n;
                    throw s.error(40)
                }
                return n
            }
            if (V.resource.has(e)) {
                const n = V.resource.getAll(e);
                if (1 === n.length) n[0].register(t);
                else {
                    const e = n.length;
                    for (let i = 0; i < e; ++i) n[i].register(t)
                }
                const i = t.resolvers.get(e);
                if (null != i) return i;
                throw s.error(40)
            } {
                const n = new pe(e, 1, e);
                return t.resolvers.set(e, n), n
            }
        }
    }
    class we {
        constructor(e, t) {
            this.key = e, this.params = t
        }
        register(e) {
            if (e.has(this.key, !0)) {
                e.get(this.key).register(e, ...this.params)
            } else e.register(...this.params.filter(e => "object" == typeof e))
        }
    }
    const ke = Object.freeze({
        instance: (e, t) => new pe(e, 0, t),
        singleton: (e, t) => new pe(e, 1, t),
        transient: (e, t) => new pe(e, 2, t),
        callback: (e, t) => new pe(e, 3, t),
        alias: (e, t) => new pe(t, 5, e),
        defer: (e, ...t) => new we(e, t)
    });
    class xe {
        constructor() {
            this.instance = null
        }
        prepare(e) {
            this.instance = e
        }
        resolve(e, t) {
            if (void 0 === this.instance) throw s.error(50);
            return this.instance
        }
        dispose() {
            this.instance = null
        }
    }

    function _e(e) {
        if (null == e || e === Object) throw s.error(5)
    }

    function Se(e, t, n) {
        if (e instanceof pe && 4 === e.strategy) {
            const i = e.state;
            let r = i.length;
            const s = new Array(r);
            for (; r--;) s[r] = i[r].resolve(t, n);
            return s
        }
        return [e.resolve(t, n)]
    }
    encodeURIComponent;
    const Oe = function() {
        const e = r.a.now,
            t = [];
        let n;
        const i = {
            createTimer: function(i) {
                t.push(i);
                let r = 0,
                    s = 0;
                return {
                    enter: function() {
                        1 == ++r && (s = e(), ++n[i].topLevelCount);
                        ++n[i].totalCount
                    },
                    leave: function() {
                        0 == --r && (n[i].duration += e() - s)
                    }
                }
            },
            enable: function() {
                n = {};
                for (const e of t) n[e] = {
                    name: e,
                    duration: 0,
                    topLevelCount: 0,
                    totalCount: 0
                };
                i.enabled = !0
            },
            disable: function() {
                i.enabled = !1
            },
            report: function(e) {
                Object.keys(n).map(e => n[e]).sort((e, t) => t.duration - e.duration).forEach(t => {
                    e(t.name, t.duration, t.topLevelCount, t.totalCount)
                })
            },
            enabled: !1
        };
        return i
    }();
    class Ce {
        constructor(e, t) {
            this.messageType = e, this.callback = t
        }
        handle(e) {
            e instanceof this.messageType && this.callback.call(null, e)
        }
    }

    function Ae(e, t, n) {
        try {
            e(t, n)
        } catch (e) {
            s.error(0, e)
        }
    }

    function Te(e, t) {
        try {
            e.handle(t)
        } catch (e) {
            s.error(0, e)
        }
    }
    ae.createInterface("IEventAggregator").withDefault(e => e.singleton(Ee));
    class Ee {
        constructor() {
            this.eventLookup = {}, this.messageHandlers = []
        }
        publish(e, t) {
            let n, i;
            if (!e) throw s.error(0);
            if ("string" == typeof e) {
                const r = e;
                if (n = this.eventLookup[r], null != n)
                    for (n = n.slice(), i = n.length; i--;) Ae(n[i], t, r)
            } else {
                const t = e;
                for (n = this.messageHandlers.slice(), i = n.length; i--;) Te(n[i], t)
            }
        }
        subscribe(e, t) {
            let n, i;
            if (!e) throw s.error(0);
            if ("string" == typeof e) {
                const r = e;
                n = t, void 0 === this.eventLookup[r] && (this.eventLookup[r] = []), i = this.eventLookup[r]
            } else n = new Ce(e, t), i = this.messageHandlers;
            return i.push(n), {
                dispose() {
                    const e = i.indexOf(n); - 1 !== e && i.splice(e, 1)
                }
            }
        }
        subscribeOnce(e, t) {
            const n = this.subscribe(e, (e, i) => (n.dispose(), t(e, i)));
            return n
        }
    }
    n.d(t, "n", (function() {
        return he
    })), n.d(t, "a", (function() {
        return ae
    })), n.d(t, "c", (function() {
        return ce
    })), n.d(t, "d", (function() {
        return le
    })), n.d(t, "j", (function() {
        return ke
    })), n.d(t, "e", (function() {
        return xe
    })), n.d(t, "f", (function() {
        return _
    })), n.d(t, "g", (function() {
        return r.a
    })), n.d(t, "k", (function() {
        return s
    })), n.d(t, "m", (function() {
        return o
    })), n.d(t, "h", (function() {
        return Oe
    })), n.d(t, "i", (function() {
        return V
    })), n.d(t, "l", (function() {
        return I
    })), n.d(t, "r", (function() {
        return F
    })), n.d(t, "s", (function() {
        return U
    })), n.d(t, "t", (function() {
        return B
    })), n.d(t, "b", (function() {
        return Ee
    })), n.d(t, "w", (function() {
        return H
    })), n.d(t, "o", (function() {
        return K
    })), n.d(t, "y", (function() {
        return X
    })), n.d(t, "C", (function() {
        return Y
    })), n.d(t, "D", (function() {
        return J
    })), n.d(t, "B", (function() {
        return Z
    })), n.d(t, "p", (function() {
        return ee
    })), n.d(t, "A", (function() {
        return ne
    })), n.d(t, "v", (function() {
        return W
    })), n.d(t, "x", (function() {
        return q
    })), n.d(t, "z", (function() {
        return ie
    })), n.d(t, "q", (function() {
        return re
    })), n.d(t, "u", (function() {
        return se
    }))
});
