// Extracted webpack module 46. Requires the original bundle runtime.
module.exports = (function(e) {
    e.exports = JSON.parse('{"hbgf_dev_features":{"component_click_regions":{"plugin_toolbar_display_name":"Component click regions","initial_value":false},"graphics_info_overlay":{"plugin_toolbar_display_name":"Graphics info overlay","initial_value":false},"browser_context_menu":{"plugin_toolbar_display_name":"Browser context menu","initial_value":false}}}')
});
