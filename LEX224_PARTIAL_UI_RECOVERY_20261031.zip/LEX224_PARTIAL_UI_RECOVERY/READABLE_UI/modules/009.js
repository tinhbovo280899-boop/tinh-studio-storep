// Extracted webpack module 9. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return r
    }));
    var i = n(0);
    class r {
        constructor() {
            this.executingLoop = !1, this.policy = "raf", this.tasks = new Map
        }
        generate(e, t) {
            return new Promise(n => {
                try {
                    t()
                } catch (t) {
                    console.error("Encountered error running task", e), console.error(t)
                }
                return n()
            })
        }
        execute() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                if (this.tasks.size < 1) return;
                const e = [];
                for (const [t, n] of this.tasks.entries()) {
                    const i = this.generate(t, n);
                    e.push(i)
                }
                const t = Promise.all(e);
                this.tasks.clear(), yield t
            }))
        }
        wait() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                "raf" === this.policy ? yield new Promise(e => requestAnimationFrame(e)): "microtask" === this.policy && (yield new Promise(e => queueMicrotask(e)))
            }))
        }
        executeLoop() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                if (!this.executingLoop) {
                    for (this.executingLoop = !0; this.tasks.size > 0;) yield this.wait(), yield this.execute();
                    this.executingLoop = !1
                }
            }))
        }
        schedule(e, t = Symbol()) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return this.tasks.set(t, e), 1 === this.tasks.size && (yield this.executeLoop()), t
            }))
        }
        deschedule(e) {
            return this.tasks.delete(e)
        }
    }
});
