// Extracted webpack module 7. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";

    function i(e, t, n) {
        let i = e;
        return (e < t || e > n) && (i = Math.min(Math.max(e, t), n)), i
    }

    function r(e, t) {
        return Number(Math.round(e + "e" + t) + "e-" + t)
    }

    function s(e) {
        return null == e ? Number.NaN : "string" == typeof e ? parseFloat(e) : e
    }
    n.d(t, "a", (function() {
        return i
    })), n.d(t, "c", (function() {
        return r
    })), n.d(t, "b", (function() {
        return s
    }))
});
