// Extracted webpack module 76. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return m
        }));
        var i = n(0),
            r = n(1),
            s = n(27),
            o = n(5),
            a = n(12),
            c = n(94),
            l = n(3),
            u = n(4),
            h = n.n(u),
            d = n(8),
            p = n(13),
            f = n(9);
        let g = c;
        l.i && (g = h.a.readFileSync(h.a.resolve(e, "./ua-listbox.html"), "utf-8"));
        let m = class extends d.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.selectedOption = null, this.valueType = o.c.real, this.listContainerStyle = null, this.options = []
            }
            getHardwareAcceleratedDisplay() {
                return this.$container
            }
            valueChanged() {
                const e = this.findOptionWithValue(this.options, this.value);
                this.selectedOption && (this.selectedOption.selected = !1), this.selectedOption = e, this.selectedOption ? (this.$select && (this.$select.value = this.selectedOption.value), this.selectedOption.selected = !0) : this.$select && (this.$select.value = ""), Object(a.d)(this.element)
            }
            binding() {
                this.optionsChanged()
            }
            configureFromUANet(e, t, n) {
                n.valueType = this.valueType
            }
            select(e) {
                this.value = e.value
            }
            findOptionWithValue(e, t) {
                for (let n of e) {
                    if (n.value === t) return n;
                    if (n.options && n.options.length) {
                        const e = this.findOptionWithValue(n.options, t);
                        if (e) return e
                    }
                }
                return null
            }
            optionsChanged() {
                this.options.forEach(e => e.setOwner(this)), this.valueChanged()
            }
        };
        Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], m.prototype, "selectedOption", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", String)], m.prototype, "valueType", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], m.prototype, "listContainerStyle", void 0), Object(i.__decorate)([Object(r.children)({
            filter: (e, t, n) => n instanceof s.a
        }), Object(i.__metadata)("design:type", Array)], m.prototype, "options", void 0), m = Object(i.__decorate)([l.i ? Object(r.customElement)({
            name: "ua-listbox",
            template: g
        }) : Object(r.customElement)(g), Object(i.__metadata)("design:paramtypes", [HTMLElement, p.a, f.a])], m)
    }).call(this, "/")
});
