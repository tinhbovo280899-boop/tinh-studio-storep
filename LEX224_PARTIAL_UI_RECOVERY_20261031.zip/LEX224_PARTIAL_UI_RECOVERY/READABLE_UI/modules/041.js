// Extracted webpack module 41. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return i
    })), n.d(t, "b", (function() {
        return p
    }));
    var i, r = n(0),
        s = n(1),
        o = n(7),
        a = n(20),
        c = n(23),
        l = n(15),
        u = n(8),
        h = n(16),
        d = n(9);
    ! function(e) {
        e.vertical = "vertical", e.horizontal = "horizontal"
    }(i || (i = {}));
    let p = class extends u.b {
        constructor(e, t, n, r) {
            super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.resourceManager = r, this.net = null, this.frameSize = 0, this.frameCount = 0, this.suffix = "", this.labels = null, this.direction = c.a.normal, this.packing = i.vertical, this.hoverOn = "self", this.isHovering = !1, this.onMouseEnter = () => {
                this.isHovering || (this.isHovering = !0, this.setBackgroundImage(this.hoverImageName))
            }, this.onMouseLeave = () => {
                this.isHovering && (this.isHovering = !1, this.setBackgroundImage(this.imageName))
            }, this.initClassState()
        }
        getHardwareAcceleratedDisplay() {
            return this.element
        }
        getUANetValue(e) {
            return this.positionNormalized
        }
        setUANetValue(e, t) {
            this.positionNormalized = t
        }
        binding() {
            if (!this.imageName) {
                let e = this.net;
                if (!e || !e.value) throw new Error("The ua-film-strip element must have an image-name or be used inside an element with a ua-net attribute set.");
                this.imageName = e.value
            }
            this.packing === i.vertical ? this.element.style.height || (this.element.style.height = this.frameSize + "px") : this.element.style.width || (this.element.style.width = this.frameSize + "px"), this.setBackgroundImage(this.imageName)
        }
        frameMapChanged() {
            this.positionChanged()
        }
        attached() {
            if (this.hoverImageName) {
                const e = this.getHoverElement();
                e.addEventListener("mouseenter", this.onMouseEnter), e.addEventListener("mouseleave", this.onMouseLeave)
            }
            "none" !== window.getComputedStyle(this.element).display && (this.element.style.display = "block"), null !== this.position && void 0 !== this.position ? this.positionChanged() : this.positionNormalizedChanged()
        }
        detached() {
            if (this.hoverImageName) {
                const e = this.getHoverElement();
                e.removeEventListener("mouseenter", this.onMouseEnter), e.removeEventListener("mouseleave", this.onMouseLeave)
            }
        }
        imageNameChanged() {
            this.imageName && this.setBackgroundImage(this.imageName)
        }
        positionNormalizedChanged() {
            let e = this.labels,
                t = "boolean" == typeof this.positionNormalized ? this.positionNormalized ? 1 : 0 : this.positionNormalized;
            null == t && (t = 0), null !== e && (t = e instanceof Array ? e[t] || 0 : e.get(t) || 0), this.position = Math.round((this.frameCount - 1) * t)
        }
        positionChanged() {
            const e = this.position || 0;
            let t = Object(o.a)(e, 0, this.frameCount - 1);
            this.direction == c.a.reverse && (t = this.frameCount - 1 - t), "function" == typeof this.frameMap && (t = this.frameMap({
                index: t
            }).index);
            const n = t * this.frameSize;
            this.uaScheduler.schedule(() => this.updatePositionPx(n))
        }
        updatePositionPx(e) {
            this.packing === i.vertical ? this.element.style.backgroundPositionY = -e + "px" : this.element.style.backgroundPositionX = -e + "px"
        }
        setBackgroundImage(e) {
            const t = this.resourceManager.imagePathFromName(`${e}${this.suffix}`),
                n = this.resourceManager.imageSetFromName(`${e}${this.suffix}`);
            Object(l.d)(this.element, t, n)
        }
        getHoverElement() {
            if (!this.hoverElement) switch (this.hoverOn) {
                case "previous":
                    this.hoverElement = this.element.previousElementSibling;
                    break;
                case "next":
                    this.hoverElement = this.element.nextElementSibling;
                    break;
                case "parent":
                    this.hoverElement = this.element.parentElement;
                    break;
                case "parent-previous":
                    this.hoverElement = this.element.parentElement.previousElementSibling;
                    break;
                case "parent-next":
                    this.hoverElement = this.element.parentElement.nextElementSibling;
                    break;
                default:
                    this.hoverElement = this.element
            }
            return this.hoverElement
        }
    };
    Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Number)], p.prototype, "position", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Number)], p.prototype, "positionNormalized", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], p.prototype, "imageName", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], p.prototype, "hoverImageName", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Object)], p.prototype, "net", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Number)], p.prototype, "frameSize", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Number)], p.prototype, "frameCount", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], p.prototype, "suffix", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Object)], p.prototype, "labels", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], p.prototype, "direction", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], p.prototype, "packing", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], p.prototype, "hoverOn", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Function)], p.prototype, "frameMap", void 0), p = Object(r.__decorate)([Object(s.customElement)("ua-film-strip"), Object(r.__metadata)("design:paramtypes", [HTMLElement, h.a, d.a, a.a])], p)
});
