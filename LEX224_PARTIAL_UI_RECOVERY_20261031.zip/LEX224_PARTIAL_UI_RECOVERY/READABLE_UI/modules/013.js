// Extracted webpack module 13. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return o
    }));
    var i = n(10),
        r = n(7),
        s = n(3);
    class o {
        constructor() {
            this.isFineTuneEventTimer = 0, this.isFineTuneEventTimerRunning = !1, this.mod120Detected = !1, this.MAX_OUTSIDE_RANGE_MVMT_PX = 5, this.MIN_OUTSIDE_RANGE_MVMT_PX = 2, this.platform = s.e()
        }
        getWheelEventDeltas(e) {
            const {
                event: t,
                isTrackPad: n
            } = e;
            let i = t.deltaX,
                r = t.deltaY;
            n || (i *= -1);
            const s = this.determineNaturalScrollDeltaModifier(t);
            return i *= s, r *= s, -0 == i && (i = 0), -0 == r && (r = 0), {
                deltaX: i,
                deltaY: r
            }
        }
        getStep(e) {
            const {
                trackerState: t
            } = e;
            return t.fineTune ? t.fineStep : t.step
        }
        getStepPx(e) {
            const t = this.getScaledRange(e),
                n = this.getMaxIndex(e);
            return Math.round(t / n)
        }
        getMovementDirectionOutsideRange({
            movementPx: e,
            index: t,
            minIndex: n,
            maxIndex: i
        }) {
            const r = Math.sign(e);
            return r < 0 && t <= n ? -1 : r > 0 && t >= i ? 1 : 0
        }
        getMaxOutsideRangeMovementPx(e) {
            const t = this.getStepPx(e);
            return Object(r.a)(t, this.MIN_OUTSIDE_RANGE_MVMT_PX, this.MAX_OUTSIDE_RANGE_MVMT_PX)
        }
        isTrackPad(e) {
            if (!this.isWheelEvent(e)) return console.warn("isTrackPad should only be called for wheel events."), !1;
            if (!this.isTWKWheelEvent(e)) return console.warn("isTrackPad should only be called for wheel events with wheelDeltaY and wheelDeltaX properties."), !1;
            let t = !1;
            return 0 != e.wheelDeltaY ? "mac" == s.e() ? e.wheelDeltaY === -3 * e.deltaY || e.wheelDeltaY + 1 === -3 * e.deltaY || e.wheelDeltaY - 1 == -3 * e.deltaY ? t = this.notMod120(e.wheelDeltaY) : this.mod120Detected = !0 : t = this.notMod120(e.wheelDeltaY) : 0 != e.wheelDeltaX && (t = this.notMod120(e.wheelDeltaX)), t
        }
        notMod120(e) {
            let t = !0;
            return Math.abs(e) % 120 != 0 ? this.mod120Detected = !1 : this.mod120Detected ? t = !1 : this.mod120Detected = !0, t
        }
        determineNaturalScrollDeltaModifier(e) {
            return e.webkitDirectionInvertedFromDevice ? -1 : 1
        }
        isWheelEvent(e) {
            return "wheel" === e.type
        }
        isTWKWheelEvent(e) {
            return "wheelDeltaY" in e && "wheelDeltaX" in e
        }
        isFineTuneEvent(e) {
            let t = !1;
            return e.shiftKey ? (t = !0, "wheel" === e.type && (this.isFineTuneEventTimer = (new Date).getTime(), this.isFineTuneEventTimerRunning = !0)) : this.isFineTuneEventTimerRunning && ("wheel" === e.type && (new Date).getTime() - this.isFineTuneEventTimer < 1200 ? t = !0 : this.isFineTuneEventTimerRunning = !1), t
        }
        isRevertTouchEvent(e) {
            return !1
        }
        isDefaultEvent(e) {
            if (!s.h(e) && !s.j(e)) return !1;
            return "win" === this.platform ? e.ctrlKey : e.altKey
        }
        isRevertEvent(e) {
            return !1
        }
        isHorizontal(e) {
            return e === i.a.horizontal || e === i.a.horizontalReverse
        }
        isVertical(e) {
            return e === i.a.vertical || e === i.a.verticalReverse || e === i.a.both || e === i.a.bothReverse
        }
        isReverse(e) {
            return e === i.a.horizontalReverse || e === i.a.verticalReverse || e === i.a.bothReverse
        }
        getDecimalPlaces(e) {
            if (Number.isInteger(e)) return;
            const t = e.toString(),
                n = t.indexOf(".");
            if (n < 0) return;
            return t.substring(n + 1).length
        }
        getValueFromIndex(e) {
            const {
                index: t,
                currentValue: n,
                states: i,
                numSteps: r
            } = e;
            let s;
            return s = this.isStatesValid(i) ? this.getRealValueFromIndex({
                index: t,
                states: i,
                currentValue: n
            }) : this.getNormalizedValueFromIndex({
                index: t,
                numSteps: r
            }), s
        }
        getNormalizedValueFromIndex(e) {
            const {
                index: t,
                numSteps: n
            } = e;
            let i;
            return i = Object(r.a)(t, 0, n - 1) / (n - 1), i = Object(r.a)(i, 0, 1), i
        }
        getRealValueFromIndex(e) {
            const {
                index: t,
                states: n,
                currentValue: i
            } = e;
            let r = Math.round(t);
            r !== t && console.warn("index is not integer " + t);
            let s = i;
            return this.isStatesValid(n) && void 0 !== n[r] ? s = n[r] : console.warn("could not determine real value from index " + r), s
        }
        getIndexFromRealValue(e) {
            const {
                value: t,
                states: n,
                curIndex: i
            } = e;
            let r = null != i ? i : -1;
            if (this.isStatesValid(n)) {
                const e = n.findIndex(e => e === t); - 1 === e ? (console.warn("real value not an index: " + t), console.log(n)) : r = e
            }
            return r
        }
        getIndexFromNormalizedValue(e) {
            const {
                value: t,
                curStep: n
            } = e;
            let i = null;
            return i = Math.round(t / n), i = Object(r.a)(i, 0, Math.round(1 / n)), i
        }
        getMaxIndex(e) {
            const {
                discrete: t,
                states: n,
                max: i,
                min: r,
                curStep: s
            } = e.trackerState;
            return t ? this.isStatesValid(n) ? n.length - 1 : i - r : s ? Math.round(1 / s) : 0
        }
        getNumSteps(e) {
            const t = Object.assign({}, e.trackerState);
            return t.discrete ? this.getMaxIndex({
                trackerState: t
            }) + 1 : 0
        }
        getNormalizedValueFromTracker(e) {
            const t = Object.assign({}, e.trackerState),
                n = this.getNumSteps({
                    trackerState: t
                });
            return t.discrete ? this.getNormalizedValueFromIndex({
                index: t.index,
                numSteps: n
            }) : t.value
        }
        getEndlessIndex(e) {
            const {
                proposedIndex: t,
                minIndex: n,
                maxIndex: i
            } = e, s = i - n + 1;
            let o = t % s;
            return o < n && (o = s + o), o = Object(r.a)(o, n, i), o
        }
        getNormalizedValueFromMovement(e) {
            const {
                initialNormalizedValue: t,
                movementPx: n,
                rangePx: i,
                endless: s
            } = e;
            let o = t;
            const a = n / i;
            let c = t + a;
            return s ? (c %= 1, -1 === Math.sign(c) && (c = 1 + c)) : c = t + a, o = Object(r.a)(c, 0, 1), o
        }
        quantizeNormalized(e) {
            const {
                trackerState: t,
                normalizedValue: n
            } = e, {
                curStep: i,
                min: s,
                max: o
            } = e.trackerState, a = this.getDecimalPlaces(i), c = this.getMaxIndex({
                trackerState: t
            });
            let l = 0;
            const u = Object(r.a)(Math.round(n * c), 0, c);
            let h = Object(r.a)(u * i, s, o);
            return h = Number(h.toPrecision(a)), l = n - h, {
                newIndex: u,
                newNormalizedValue: h,
                remainder: l
            }
        }
        getStepScaling(e) {
            const {
                states: t
            } = e;
            let n = 1;
            const i = t.length;
            return i - 1 >= 1 && (n = 1 - .5 / (i - 1)), n
        }
        getValueFromWheel(e) {
            var t;
            const {
                trackerState: n
            } = e, {
                value: i,
                index: s,
                states: o,
                endless: a,
                mousewheelRangePx: c,
                trackpadRangePx: l,
                discrete: u,
                fineTune: h,
                fineTuneScaling: d,
                isTrackPad: p
            } = e.trackerState;
            if (0 === Math.abs(n.movementPx)) return Object.assign({}, n);
            let f = i,
                g = s,
                m = 0,
                v = 0;
            const b = n.movementPx + (null !== (t = n.moveRemainderPx) && void 0 !== t ? t : 0),
                y = u ? this.getStepScaling({
                    states: o
                }) : 1,
                w = (h && d ? y * d : y) * (p ? l : c),
                k = Math.sign(b);
            if (u) {
                const e = 0,
                    t = this.getMaxIndex({
                        trackerState: n
                    });
                let c = w / (t - e);
                p && (c = Object(r.a)(c, 15, 650));
                let l = s;
                Math.abs(b) >= c / 2 && (v = k * Math.round(Math.abs(b / c)));
                const u = 1;
                !p && !h && 0 == Math.abs(v) && Math.abs(b) >= u && (v = k), Math.abs(v) >= 1 && (l = s + v, a && (l = this.getEndlessIndex({
                    proposedIndex: l,
                    minIndex: e,
                    maxIndex: t
                })), g = Object(r.a)(l, e, t), f = this.getRealValueFromIndex({
                    index: g,
                    states: o,
                    currentValue: i
                }))
            } else {
                let e = i;
                e = this.getNormalizedValueFromMovement({
                    initialNormalizedValue: e,
                    movementPx: b,
                    rangePx: w,
                    endless: a
                });
                const t = this.quantizeNormalized({
                    trackerState: n,
                    normalizedValue: e
                });
                f = t.newNormalizedValue, g = t.newIndex, v = g - n.index
            }
            return 0 == Math.abs(v) && (m = b), "number" == typeof f && 0 === Math.abs(f) && (f = 0), Object.assign(Object.assign({}, e.trackerState), {
                value: f,
                index: g,
                moveRemainderPx: m
            })
        }
        getValueFromMovement(e) {
            const {
                trackerState: t
            } = e, {
                value: n,
                initialNormalizedValue: i,
                index: r,
                rangePx: s,
                movementPx: o,
                totalMovementPx: a,
                discrete: c,
                states: l,
                endless: u
            } = e.trackerState;
            let h = 0;
            const d = this.getScaledRange({
                trackerState: t
            });
            if (0 === Math.abs(a)) return Object.assign(Object.assign({}, t), {
                value: n,
                index: r,
                moveRemainderPx: h
            });
            const p = this.getNormalizedValueFromMovement({
                    initialNormalizedValue: i,
                    movementPx: a,
                    rangePx: d,
                    endless: u
                }),
                {
                    newIndex: f,
                    newNormalizedValue: g,
                    remainder: m
                } = this.quantizeNormalized({
                    trackerState: t,
                    normalizedValue: p
                }),
                v = c ? this.getRealValueFromIndex({
                    index: f,
                    states: l,
                    currentValue: n
                }) : g;
            return h = Math.round(s * m), Object.assign(Object.assign({}, e.trackerState), {
                value: v,
                index: f,
                moveRemainderPx: h
            })
        }
        getScaledRange(e) {
            const {
                fineTune: t,
                fineTuneScaling: n,
                rangePx: i
            } = e.trackerState;
            return t && n ? i * n : i
        }
        getValueFromPos(e) {
            const {
                trackerState: t
            } = e, {
                value: n,
                index: i,
                startPx: s,
                rangePx: o,
                orientation: a,
                posX: c,
                posY: l,
                states: u,
                discrete: h,
                min: d,
                max: p,
                offsetPx: f,
                indicatorJumpToPosition: g
            } = e.trackerState, m = this.isHorizontal(a) ? c : l;
            if (null == s || null == m) return console.warn("getValueFromPos: cannot calculate value without startPx and posPx"), console.warn({
                startPx: s,
                posPx: m
            }), Object.assign(Object.assign({}, t), {
                value: n,
                index: i,
                moveRemainderPx: 0
            });
            let v = n,
                b = i;
            const y = this.getScaledRange({
                    trackerState: t
                }),
                w = g ? 0 : null != f ? f : 0;
            let k = Object(r.a)(m - w - s, 0, o);
            if ((this.isHorizontal(a) ? this.isReverse(a) : !this.isReverse(a)) && (k = Object(r.a)(y - k, 0, y)), h) {
                const e = this.getMaxIndex({
                        trackerState: t
                    }),
                    i = 0,
                    s = o / (p - d);
                b = Object(r.a)(Math.round(k / s), i, e), v = this.getRealValueFromIndex({
                    index: b,
                    states: u,
                    currentValue: n
                })
            } else {
                let e = Object(r.a)(k / o, 0, 1);
                const n = this.quantizeNormalized({
                    trackerState: t,
                    normalizedValue: e
                });
                v = n.newNormalizedValue, b = n.newIndex
            }
            return "number" == typeof v && 0 === Math.abs(v) && (v = 0), Object.assign(Object.assign({}, t), {
                value: v,
                index: b,
                moveRemainderPx: 0
            })
        }
        getValueFromInteraction(e) {
            let t = Object.assign({}, e.trackerState);
            switch (t.interactionType) {
                case "position":
                    t = this.getValueFromPos({
                        trackerState: t
                    });
                    break;
                case "wheel":
                    t = this.getValueFromWheel({
                        trackerState: t
                    });
                    break;
                case "movement":
                    t = this.getValueFromMovement({
                        trackerState: t
                    });
                    break;
                default:
                    console.warn("invalid interactionType")
            }
            return t
        }
        getMovementFromChange(e) {
            const {
                interactionType: t,
                orientation: n,
                changeX: r,
                changeY: s
            } = e;
            let o = n;
            "wheel" === t && (o = this.isReverse(n) ? i.a.bothReverse : i.a.both);
            let a = 0;
            switch (o) {
                case i.a.horizontal:
                    a = r;
                    break;
                case i.a.horizontalReverse:
                    a = -r;
                    break;
                case i.a.vertical:
                    a = -s;
                    break;
                case i.a.verticalReverse:
                    a = s;
                    break;
                case i.a.bothReverse:
                    a = Math.sign(r) > 0 && Math.sign(s) < 0 || Math.sign(r) < 0 && Math.sign(s) > 0 ? Math.sign(s - r) * Math.sqrt(Math.pow(r, 2) + Math.pow(s, 2)) : Math.sign(s - r) * Math.sqrt(Math.abs(Math.sign(-1 * r) * Math.pow(r, 2) - Math.sign(-1 * s) * Math.pow(s, 2)));
                    break;
                case i.a.both:
                    a = Math.sign(r) > 0 && Math.sign(s) < 0 || Math.sign(r) < 0 && Math.sign(s) > 0 ? Math.sign(r - s) * Math.sqrt(Math.pow(r, 2) + Math.pow(s, 2)) : Math.sign(r - s) * Math.sqrt(Math.abs(Math.sign(r) * Math.pow(r, 2) - Math.sign(s) * Math.pow(s, 2)));
                    break;
                default:
                    console.warn("unexpected orientation: " + o), a = Math.sign(r - s) * Math.sqrt(Math.abs(Math.sign(r) * Math.pow(r, 2) - Math.sign(s) * Math.pow(s, 2)))
            }
            return a
        }
        calculateMovementOnPrimaryAxis(e) {
            let {
                changeX: t,
                changeY: n,
                orientation: i,
                movementPx: r,
                totalMovementPx: s,
                interactionType: o
            } = e.trackerState, a = Object.assign({}, e.trackerState);
            return r = this.getMovementFromChange({
                interactionType: o,
                orientation: i,
                changeX: t,
                changeY: n
            }), s += r, -0 === r && (r = 0), -0 === s && (s = 0), a.movementPx = r, a.totalMovementPx = s, a
        }
        calculateOutsideRangeMovement(e) {
            let t = Object.assign({}, e.trackerState);
            if (e.trackerState.endless) return t;
            const {
                movementPx: n,
                totalMovementPx: i,
                index: r
            } = t, s = this.getMaxIndex({
                trackerState: t
            }), o = this.getMovementDirectionOutsideRange({
                movementPx: n,
                index: r,
                maxIndex: s,
                minIndex: 0
            }), a = Math.sign(i) === Math.sign(n);
            if (!t.endless && o && a && (t = this.resetDrag({
                    trackerState: t
                }), "movement" === t.interactionType)) {
                const e = this.getMaxOutsideRangeMovementPx({
                    trackerState: t
                });
                t.movementPx = e * o, t.totalMovementPx = e * o
            }
            return t
        }
        getMouseEventStats({
            event: e
        }) {
            return {
                deviceStats: {
                    width: screen.width,
                    height: screen.height,
                    availWidth: screen.availWidth,
                    availHeight: screen.availHeight,
                    availLeft: screen.availLeft,
                    availTop: screen.availTop,
                    innerWidth: window.innerWidth,
                    innerHeight: window.innerHeight,
                    outerWidth: window.outerWidth,
                    outerHeight: window.outerHeight,
                    screenX: window.screenX,
                    screenY: window.screenY
                },
                pointerStats: {
                    movementX: e.movementX,
                    movementY: e.movementY,
                    screenX: e.screenX,
                    screenY: e.screenY,
                    clientX: e.clientX,
                    clientY: e.clientY,
                    pageX: e.pageX,
                    pageY: e.pageY,
                    x: e.x,
                    y: e.y,
                    offsetX: e.offsetX,
                    offsetY: e.offsetY
                }
            }
        }
        getMouseOutOfBounds(e) {
            var t, n, i;
            const r = null !== (t = e.epsilon) && void 0 !== t ? t : 1,
                s = e.event;
            let o, a, c = 0,
                l = 0,
                u = 0,
                h = 0;
            return o = null !== (n = screen.availLeft) && void 0 !== n ? n : 0, a = null !== (i = screen.availTop) && void 0 !== i ? i : screen.height - screen.availHeight, s.screenX <= o + r ? c = -1 : s.screenX >= o + screen.availWidth - r && (c = 1), s.screenY <= a + r ? l = -1 : s.screenY >= a + screen.availHeight - r && (l = 1), s.clientX <= 0 + r ? u = -1 : s.clientX >= window.innerWidth - r && (u = 1), s.clientY <= 0 + r ? h = -1 : s.clientY >= window.innerHeight - r && (h = 1), {
                isOffVisualViewportX: u,
                isOffVisualViewportY: h,
                isOffScreenX: c,
                isOffScreenY: l
            }
        }
        isOffScreen({
            event: e
        }) {
            const t = this.getMouseOutOfBounds({
                event: e
            });
            return (t.isOffScreenX > 0 || t.isOffScreenY > 0) && null != e.movementX && null != e.movementY
        }
        processOffscreenMouseEvent(e) {
            const {
                lastScreenX: t,
                lastScreenY: n,
                event: i
            } = e;
            let {
                changeX: r,
                changeY: s
            } = e;
            return r = i.movementX, s = i.movementY, 0 === r && 0 === s && null != t && null != n && (r = i.screenX - t, s = i.screenY - n), {
                changeX: r,
                changeY: s
            }
        }
        processEvent(e) {
            let {
                event: t,
                movementPx: n,
                totalMovementPx: i,
                dragging: r,
                lastScreenX: s,
                lastScreenY: o,
                posX: a,
                posY: c,
                isOffScreen: l
            } = e.trackerState, u = 0, h = 0, d = !1;
            if (t) switch (t.type) {
                case "touchstart":
                    r = !0, n = 0, i = 0, a = t.targetTouches[0].clientX, c = t.targetTouches[0].clientY, s = t.targetTouches[0].screenX, o = t.targetTouches[0].screenY;
                    break;
                case "touchmove":
                    r = !0, null != s && (u = t.targetTouches[0].screenX - s), null != o && (h = t.targetTouches[0].screenY - o), s = t.targetTouches[0].screenX, o = t.targetTouches[0].screenY, a = t.targetTouches[0].clientX, c = t.targetTouches[0].clientY;
                    break;
                case "touchend":
                case "touchcancel":
                    r = !1, n = 0, u = 0, h = 0;
                    break;
                case "mousedown": {
                    const e = t;
                    r = !0, n = 0, i = 0, s = e.screenX, o = e.screenY, a = e.clientX, c = e.clientY;
                    break
                }
                case "mousemove": {
                    const e = t,
                        n = l;
                    if (l = this.isOffScreen({
                            event: e
                        }), r = !0, "mac" === this.platform && l) {
                        const t = this.processOffscreenMouseEvent({
                            event: e,
                            changeX: u,
                            changeY: h,
                            lastScreenX: s,
                            lastScreenY: o
                        });
                        u = t.changeX, h = t.changeY
                    } else if ("win" !== this.platform || !l && n === l) null != s && null != o ? (u = e.screenX - s, h = e.screenY - o) : (console.warn("lastScreenX, lastScreenY undefined", {
                        lastScreenX: s,
                        lastScreenY: o
                    }), u = 0, h = 0);
                    else {
                        const t = 10;
                        u = e.movementX, h = e.movementY, Math.abs(u) > t && (u = 1 * Math.sign(u)), Math.abs(h) > t && (h = 1 * Math.sign(h))
                    }
                    s = e.screenX, o = e.screenY, a = e.clientX, c = e.clientY;
                    break
                }
                case "mouseup":
                    r = !1, u = 0, h = 0;
                    break;
                case "wheel": {
                    n = 0, d = this.isTrackPad(t);
                    const {
                        deltaX: e,
                        deltaY: i
                    } = this.getWheelEventDeltas({
                        event: t,
                        isTrackPad: d
                    }), r = .7, s = d ? r : 1;
                    u = Math.round(e * s), h = Math.round(i * s);
                    const o = 80,
                        a = 100;
                    h = h / (Math.abs(h) + o) * a, u = u / (Math.abs(u) + o) * a;
                    break
                }
                default:
                    console.warn("unexpected event type")
            }
            return Object.assign(Object.assign({}, e.trackerState), {
                posX: a,
                posY: c,
                changeX: u,
                changeY: h,
                lastScreenX: s,
                lastScreenY: o,
                dragging: r,
                movementPx: n,
                totalMovementPx: i,
                isTrackPad: d,
                isOffScreen: l
            })
        }
        getIndexFromValue(e) {
            const t = Object.assign({}, e.trackerState);
            return t.discrete ? this.getIndexFromRealValue({
                value: t.value,
                states: t.states
            }) : this.getIndexFromNormalizedValue({
                value: t.value,
                curStep: t.curStep
            })
        }
        validateTrackerState(e) {
            const {
                event: t,
                discrete: n,
                min: i,
                max: r,
                step: s,
                rangePx: o,
                mousewheelRangePx: a,
                trackpadRangePx: c,
                fineStep: l,
                startPx: u,
                states: h,
                dragging: d,
                orientation: p,
                endless: f,
                fineTuneScaling: g
            } = e.trackerState, m = e => (console.warn(e), !1);
            if (!t || !t.type) return m("event with type must exist");
            if ("wheel" === t.type && d) return m("cannot handle wheel events while dragging");
            if (void 0 === t) return m("event is undefined");
            if (void 0 === p) return m("orientation is undefined");
            if (void 0 === o) return m("range is undefined");
            if (void 0 === a) return m("mousewheelRangePx is undefined");
            if (void 0 === c) return m("trackpadRangePx is undefined");
            if (void 0 === f) return m("endless is undefined");
            if (n) {
                if (!Number.isInteger(i)) return m("min should be an integer");
                if (!Number.isInteger(r)) return m("max should be an integer");
                if (!(r > i)) return m("max should be >= min");
                if (!(r - i + 1 > 0)) return m("numSteps should be > 0");
                if (r < 1) return m("max should be >= 1");
                if (!this.isStatesValid(h)) return m("discrete controls must have a real_values array")
            } else {
                if (!(i >= 0 && i <= 1)) return m("min should exist in (0,1)");
                if (!(r >= 0 && r <= 1)) return m("max should exist in (0,1)");
                if (!(r >= i)) return m("max should be >= min");
                if (null == s) return m("step should be defined for continuous");
                if (!(s > 0 && s < 1)) return m("step should exist in (0,1)");
                if (null == l) return m("fineStep should be defined for continuous");
                if (!(l > 0 && l < 1)) return m("fineStep should exist in (0,1)");
                if (!(l <= s)) return m("fineStep should be < step")
            }
            return "number" != typeof u || u >= 0 ? Number.isNaN(s) ? m("step should not be NaN") : Number.isNaN(l) ? m("fineStep should not be NaN") : Number.isInteger(o) ? o >= 1 ? g >= 1 || m("fineTuneScaling should be >=1") : m("rangePx should be >=1") : m("rangePx should be an integer") : m("start should be >= 0")
        }
        isStatesValid(e) {
            return !!(e && Array.isArray(e) && e.length)
        }
        ensureIntegerRange(e) {
            return Number.isInteger(e) ? e : Math.trunc(e) + 1
        }
        ensureRangeReachesAllStates(e) {
            const {
                range: t,
                steps: n
            } = Object.assign({}, e);
            return !t || t < n + 1 ? n + 1 : t
        }
        configureTrackerState(e) {
            let t = Object.assign({}, e.trackerState);
            if (t.curStep = this.getStep({
                    trackerState: t
                }), t.index = this.getIndexFromValue({
                    trackerState: t
                }), t.interactionType = "wheel" === t.event.type ? "wheel" : "number" != typeof t.startPx || t.fineTune ? "movement" : "position", t.rangePx = this.ensureIntegerRange(t.rangePx), t.mousewheelRangePx = this.ensureIntegerRange(t.mousewheelRangePx), t.trackpadRangePx = this.ensureIntegerRange(t.trackpadRangePx), null == t.startPx) {
                const e = t.discrete ? this.getNumSteps({
                    trackerState: t
                }) : t.curStep ? Math.round(1 / t.curStep) : 1;
                t.rangePx = this.ensureRangeReachesAllStates({
                    range: t.rangePx,
                    steps: e
                }), t.mousewheelRangePx = this.ensureRangeReachesAllStates({
                    range: t.mousewheelRangePx,
                    steps: e
                }), t.trackpadRangePx = this.ensureRangeReachesAllStates({
                    range: t.trackpadRangePx,
                    steps: e
                })
            }
            return t
        }
        hasFineTuneChanged(e) {
            const t = Object.assign({}, e.trackerState);
            let n = !1;
            return null == this.lastFineTune ? this.lastFineTune = t.fineTune : this.lastFineTune != t.fineTune && (n = !0), this.lastFineTune = t.fineTune, n
        }
        resetDrag(e) {
            let t = Object.assign({}, e.trackerState);
            return t.initialNormalizedValue = t.discrete ? this.getNormalizedValueFromIndex({
                index: t.index,
                numSteps: this.getNumSteps({
                    trackerState: t
                })
            }) : t.value, t.movementPx = 0, t.totalMovementPx = 0, t
        }
        trackInteraction(e) {
            let t = Object.assign({}, e.trackerState);
            if (t = this.configureTrackerState({
                    trackerState: t
                }), !this.validateTrackerState({
                    trackerState: t
                })) return console.warn("invalid tracker config"), {
                hasMoved: !1,
                error: !0,
                trackerState: e.trackerState
            };
            this.hasFineTuneChanged({
                trackerState: t
            }) && (t = this.resetDrag({
                trackerState: t
            })), t = this.processEvent({
                trackerState: t
            }), t = this.calculateMovementOnPrimaryAxis({
                trackerState: t
            }), t = this.calculateOutsideRangeMovement({
                trackerState: t
            });
            const n = t.index;
            t = this.getValueFromInteraction({
                trackerState: t
            });
            let i = !1;
            return t.index !== n && (i = !0, t.movementPx = 0), "mousedown" != t.event.type && "touchstart" != t.event.type && "touchend" != t.event.type && "touchcancel" != t.event.type && "mouseup" != t.event.type || (t = this.resetDrag({
                trackerState: t
            })), {
                hasMoved: i,
                trackerState: t
            }
        }
    }
});
