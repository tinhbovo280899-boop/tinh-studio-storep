// Extracted webpack module 18. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e, i) {
        n.d(t, "a", (function() {
            return k
        }));
        const r = function() {
                if (void 0 !== e) return e;
                if ("undefined" != typeof self) return self;
                if ("undefined" != typeof window) return window;
                try {
                    return new Function("return this")()
                } catch (e) {
                    return {}
                }
            }(),
            s = "undefined" != typeof window && void 0 !== window.document,
            o = "object" == typeof self && null != self.constructor && "DedicatedWorkerGlobalScope" === self.constructor.name,
            a = void 0 !== i && null != i.versions && null != i.versions.node,
            c = function() {
                let e, t, n, i, s;
                if (null != r.performance && null != r.performance.now) {
                    const e = r.performance;
                    return function() {
                        return e.now()
                    }
                }
                if (null != r.process && null != r.process.hrtime) {
                    const o = function() {
                        return (e() - i) / 1e6
                    };
                    return t = r.process.hrtime, e = function() {
                        const e = t();
                        return 1e9 * e[0] + e[1]
                    }, n = e(), s = 1e9 * r.process.uptime(), i = n - s, o
                } {
                    const e = function() {
                        return Date.now() - i
                    };
                    return i = Date.now(), e
                }
            }(),
            {
                $mark: l,
                $measure: u,
                $getEntriesByName: h,
                $getEntriesByType: d,
                $clearMarks: p,
                $clearMeasures: f
            } = function() {
                if (null != r.performance && null != r.performance.mark && null != r.performance.measure && null != r.performance.getEntriesByName && null != r.performance.getEntriesByType && null != r.performance.clearMarks && null != r.performance.clearMeasures) {
                    const e = r.performance;
                    return {
                        $mark: function(t) {
                            e.mark(t)
                        },
                        $measure: function(t, n, i) {
                            e.measure(t, n, i)
                        },
                        $getEntriesByName: function(t) {
                            return e.getEntriesByName(t)
                        },
                        $getEntriesByType: function(t) {
                            return e.getEntriesByType(t)
                        },
                        $clearMarks: function(t) {
                            e.clearMarks(t)
                        },
                        $clearMeasures: function(t) {
                            e.clearMeasures(t)
                        }
                    }
                }
                if (null != r.process && null != r.process.hrtime) {
                    const e = [],
                        t = {},
                        n = function(t, n) {
                            let i = 0;
                            const r = e.length,
                                s = [];
                            for (; i < r; i++) e[i][t] === n && s.push(e[i]);
                            return s
                        },
                        i = function(t, n) {
                            let i, r = e.length;
                            for (; r--;) i = e[r], i.entryType !== t || void 0 !== n && i.name !== n || e.splice(r, 1)
                        };
                    return {
                        $mark: function(n) {
                            const i = {
                                name: n,
                                entryType: "mark",
                                startTime: c(),
                                duration: 0
                            };
                            e.push(i), t[n] = i
                        },
                        $measure: function(n, i, r) {
                            let s, o;
                            if (null != r) {
                                if (null == t[r]) throw new SyntaxError(`Failed to execute 'measure' on 'Performance': The mark '${r}' does not exist.`);
                                o = void 0 !== t[r] ? t[r].startTime : c()
                            } else o = c();
                            if (null != i) {
                                if (null == t[i]) throw new SyntaxError(`Failed to execute 'measure' on 'Performance': The mark '${i}' does not exist.`);
                                s = void 0 !== t[i] ? t[i].startTime : 0
                            } else s = 0;
                            e.push({
                                name: n,
                                entryType: "measure",
                                startTime: s,
                                duration: o - s
                            })
                        },
                        $getEntriesByName: function(e) {
                            return n("name", e)
                        },
                        $getEntriesByType: function(e) {
                            return n("entryType", e)
                        },
                        $clearMarks: function(e) {
                            i("mark", e)
                        },
                        $clearMeasures: function(e) {
                            i("measure", e)
                        }
                    }
                }
                return {}
            }(),
            {
                $raf: g,
                $caf: m
            } = function() {
                let e = r.requestAnimationFrame,
                    t = r.cancelAnimationFrame;
                if (void 0 === e || void 0 === t) {
                    let n = 0,
                        i = 0;
                    const r = [],
                        s = 1e3 / 60;
                    e = function(e) {
                        let t, o;
                        return 0 === r.length && (t = c(), o = Math.max(0, s - (t - n)), n = o + t, setTimeout((function() {
                            const e = r.slice(0);
                            r.length = 0;
                            for (let t = 0; t < e.length; ++t)
                                if (!e[t].cancelled) try {
                                    e[t].callback(n)
                                } catch (e) {
                                    setTimeout((function() {
                                        throw e
                                    }), 0)
                                }
                        }), Math.round(o))), r.push({
                            handle: ++i,
                            callback: e,
                            cancelled: !1
                        }), i
                    }, t = function(e) {
                        for (let t = 0; t < r.length; ++t) r[t].handle === e && (r[t].cancelled = !0)
                    }
                }
                const n = function(t) {
                    return e.call(r, t)
                };
                return n.cancel = function(e) {
                    t.call(r, e)
                }, r.requestAnimationFrame = e, r.cancelAnimationFrame = t, {
                    $raf: n,
                    $caf: t
                }
            }(),
            v = Object.prototype.hasOwnProperty,
            b = Object.freeze([]),
            y = Object.freeze({}),
            w = Object.freeze({
                isBrowserLike: s,
                isWebWorkerLike: o,
                isNodeLike: a,
                global: r,
                emptyArray: b,
                emptyObject: y,
                noop: function() {},
                now: c,
                mark: l,
                measure: u,
                getEntriesByName: h,
                getEntriesByType: d,
                clearMarks: p,
                clearMeasures: f,
                hasOwnProperty: v,
                requestAnimationFrame: e => g(e),
                cancelAnimationFrame: e => m(e),
                clearInterval(e) {
                    r.clearInterval(e)
                },
                clearTimeout(e) {
                    r.clearTimeout(e)
                },
                setInterval: (e, t, ...n) => r.setInterval(e, t, ...n),
                setTimeout: (e, t, ...n) => r.setTimeout(e, t, ...n),
                restore() {
                    Object.assign(k, w)
                }
            }),
            k = {
                ...w
            }
    }).call(this, n(152), n(43))
});
