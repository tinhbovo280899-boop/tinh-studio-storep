// Extracted webpack module 153. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.ApplicationRoot = t.show = t.hide = void 0;
    const i = n(0),
        r = (0, i.__importStar)(n(157)),
        s = n(1),
        o = n(6),
        a = n(63),
        c = n(83);
    t.hide = ({
        state: e
    }) => {
        e.style = Object.assign(Object.assign({}, e.style), {
            display: "none"
        })
    };
    t.show = ({
        state: e
    }) => {
        e.style = Object.assign(Object.assign({}, e.style), {
            display: ""
        })
    };
    let l = class extends c.State {
        constructor(e) {
            super(), this.plug = e, this.styles = {
                backPanel: {
                    position: "absolute",
                    top: "0px",
                    left: "0px",
                    overflow: "hidden",
                    width: "381px",
                    height: "621px",
                    backgroundRepeat: "no-repeat",
                    backgroundImage: ["url(./images/UA_Lexicon224_panel.png)", "-webkit-image-set(\n          url(./images/UA_Lexicon224_panel.png) 1x,\n          url(./images/@2x/UA_Lexicon224_panel@2x.png) 2x\n        )", "image-set(\n          url(./images/UA_Lexicon224_panel.png) 1x,\n          url(./images/@2x/UA_Lexicon224_panel@2x.png) 2x\n        )"]
                },
                pcbCover: {
                    position: "absolute",
                    left: "0px",
                    top: "0px",
                    width: "381px",
                    height: "81px",
                    backgroundRepeat: "no-repeat",
                    backgroundImage: ["url(./images/UA_Lexicon224_PCB-cover.png)", "-webkit-image-set(\n          url(./images/UA_Lexicon224_PCB-cover.png) 1x,\n          url(./images/@2x/UA_Lexicon224_PCB-cover@2x.png) 2x\n        )", "image-set(\n          url(./images/UA_Lexicon224_PCB-cover.png) 1x,\n          url(./images/@2x/UA_Lexicon224_PCB-cover@2x.png) 2x\n        )"]
                },
                potKnob: {
                    position: "absolute",
                    top: "40px",
                    width: "35px",
                    height: "35px"
                },
                hiddenButton: {
                    position: "absolute",
                    width: "71px",
                    height: "11px"
                }
            }, this.shiftKeyPressed = !1, this.buttonDown = !1, this.timeoutID = void 0, this.programButtons = [], this.lastLinkState = -1;
            const t = e => {
                this.shiftKeyPressed = e.shiftKey
            };
            document.addEventListener("keydown", t), document.addEventListener("keyup", t), this.setupParamListeners(), this.initComponentsAndTemplates(), this.updateHandler(), this.linkHasChanged()
        }
        setupParamListeners() {
            this.plug.registerMultiCallbackListener({
                listeners: [{
                    selector: "effect",
                    id: "effect",
                    properties: {
                        stem_format: {}
                    }
                }, {
                    selector: "effect",
                    id: "effect",
                    properties: {
                        output_stem_format: {}
                    }
                }, {
                    selector: "controls",
                    id: "program",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "immediate",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "sys_noise",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "rear_outs",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "mix",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "wet_solo",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "mode_enh",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "decay_opt",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "power",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "private_data",
                    id: "pcb_open",
                    properties: {
                        data: {}
                    }
                }, {
                    selector: "private_data",
                    id: "led_hold",
                    properties: {
                        data: {}
                    }
                }],
                callback: () => this.updateHandler()
            }), this.plug.registerCallbackListener({
                selector: "controls",
                id: "link",
                properties: {
                    real_value: {
                        allowTaggedUANET: ["get", "set"],
                        ignoreShortCircuit: !0
                    }
                },
                callback: e => {
                    this.linkHasChanged()
                }
            })
        }
        getChannelConfiguration(e) {
            const {
                stem_format: t,
                output_stem_format: n
            } = e;
            return "mono" === t && "mono" === n ? "MIMO" : "mono" === t && "stereo" === n ? "MISO" : "stereo" === t && "mono" === n ? "SIMO" : "stereo" === t && "stereo" === n ? "SISO" : void console.log("ApplicationRoot.getChannelConfiguration: Error: unsupported config", e)
        }
        linkHasChangedFromGUI() {
            return (e, {
                state: t
            }) => {
                if (1 == this.getState({
                        selector: "components",
                        id: "link"
                    }).disabled) return;
                if (1 != this.plug.getRealValue("power")) return;
                if ("mousedown" == t.type || "touchstart" == t.type) {
                    const e = t.value;
                    this.plug.setTouch("link", !0), this.plug.setWithReceipt({
                        selector: "controls",
                        id: "link",
                        property: "real_value",
                        payload: e
                    }), this.plug.setTouch("link", !1)
                }
            }
        }
        linkHasChanged() {
            const e = this.plug.getStoreValue({
                selector: "controls",
                id: "link",
                property: "real_value"
            });
            if (this.lastLinkState != e) {
                const t = e;
                this.updateLinkedComponent({
                    linked: t,
                    channelComponent: "in_gain_r",
                    linkedComponent: "in_gain_linked"
                }), this.updateLinkedComponent({
                    linked: t,
                    channelComponent: "out_lvl_r",
                    linkedComponent: "out_lvl_linked"
                }), this.updateLinkedComponent({
                    linked: t,
                    channelComponent: "in_gain_r",
                    linkedComponent: "in_gain_linked"
                }), this.updateLinkedComponent({
                    linked: t,
                    channelComponent: "out_lvl_r",
                    linkedComponent: "out_lvl_linked"
                }), this.updateState({
                    selector: "components",
                    id: "link",
                    updater: ({
                        state: t
                    }) => {
                        t.value = e
                    }
                })
            }
            this.lastLinkState = e
        }
        updateLinkedComponent(e) {
            const {
                linked: n,
                channelComponent: i,
                linkedComponent: r
            } = e;
            this.updateState({
                selector: "components",
                id: i,
                updater: n ? t.hide : t.show
            }), this.updateState({
                selector: "components",
                id: r,
                updater: n ? t.show : t.hide
            })
        }
        updateHandler() {
            const e = this.plug.getStoreValue({
                    selector: "controls",
                    id: "program",
                    property: "real_value"
                }),
                n = this.plug.getStoreValue({
                    selector: "controls",
                    id: "power",
                    property: "real_value"
                }),
                i = this.getChannelConfiguration({
                    stem_format: this.plug.getStoreValue({
                        selector: "effect",
                        id: "effect",
                        property: "stem_format"
                    }),
                    output_stem_format: this.plug.getStoreValue({
                        selector: "effect",
                        id: "effect",
                        property: "output_stem_format"
                    })
                }),
                r = ({
                    state: e
                }) => {
                    e.skinOptions = {
                        frameMap: function({
                            index: e
                        }) {
                            return {
                                index: [3, 1][e]
                            }
                        }
                    }
                },
                s = ({
                    state: e
                }) => {
                    e.skinOptions = {
                        frameMap: function({
                            index: e
                        }) {
                            return {
                                index: [0, 2][e]
                            }
                        }
                    }
                },
                o = ({
                    state: e
                }) => {
                    e.skinOptions = {
                        frameMap: function({
                            index: e
                        }) {
                            return {
                                index: [0, 1][e]
                            }
                        }
                    }
                },
                c = ({
                    state: e
                }) => {
                    e.skinOptions = {
                        frameMap: function() {
                            return {
                                index: this.direction == a.AnimationDirection.reverse
                            }
                        }
                    }, e.disabled = !0
                },
                l = ({
                    state: e
                }) => {
                    e.skinOptions = {
                        frameMap: {}
                    }, e.disabled = !1
                };
            for (let t = 0; t < 8; t++) this.updateState({
                selector: "components",
                id: this.programButtons[t],
                updater: !n || e != t && 8 != e ? s : r
            });
            ["diffusion-down", "diffusion-up"].forEach(t => {
                this.updateState({
                    selector: "components",
                    id: t,
                    updater: n && 3 != e ? o : s
                })
            }), ["immediate", "sys_noise", "rear_outs", "wet_solo", "mode_enh", "decay_opt"].forEach(e => {
                const t = this.plug.getStoreValue({
                    selector: "controls",
                    id: e,
                    property: "real_value"
                });
                this.updateState({
                    selector: "components",
                    id: e,
                    updater: n && t ? r : s
                })
            }), ["mix-down", "mix-up"].forEach(e => {
                const t = this.plug.getStoreValue({
                    selector: "controls",
                    id: "wet_solo",
                    property: "real_value"
                });
                this.updateState({
                    selector: "components",
                    id: e,
                    updater: n && !t ? o : s
                })
            }), ["mode_enh-down", "mode_enh-up"].forEach(e => {
                const t = this.plug.getStoreValue({
                    selector: "controls",
                    id: "mode_enh",
                    property: "real_value"
                });
                this.updateState({
                    selector: "components",
                    id: e,
                    updater: n && t ? o : s
                })
            }), ["decay_opt-down", "decay_opt-up"].forEach(e => {
                const t = this.plug.getStoreValue({
                    selector: "controls",
                    id: "decay_opt",
                    property: "real_value"
                });
                this.updateState({
                    selector: "components",
                    id: e,
                    updater: n && t ? o : s
                })
            }), ["bug_fixes", "link"].forEach(e => {
                this.updateState({
                    selector: "components",
                    id: e,
                    updater: n ? l : c
                })
            }), this.updateState({
                selector: "components",
                id: "link",
                updater: ({
                    state: e
                }) => {
                    e.disabled = !n || "MIMO" == i
                }
            });
            const u = this.plug.getStoreValue({
                    selector: "private_data",
                    id: "pcb_open",
                    property: "data"
                }),
                h = this.plug.getStoreValue({
                    selector: "private_data",
                    id: "led_hold",
                    property: "data"
                });
            this.updateState({
                selector: "components",
                id: "pcb_cover",
                updater: u ? t.hide : t.show
            }), this.updateState({
                selector: "components",
                id: "open_close",
                updater: ({
                    state: e
                }) => {
                    e.value = u
                }
            }), this.updateState({
                selector: "components",
                id: "hold_switch",
                updater: ({
                    state: e
                }) => {
                    e.value = h
                }
            })
        }
        initComponentsAndTemplates() {
            this.initComponentAndTemplate({
                id: "pitch_shift-down",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "16px",
                        top: "40px",
                        width: "33px",
                        height: "38px"
                    },
                    skin: "PitchShift",
                    mode: "momentary",
                    interaction: () => this.incDecButtons("pitch_-_+", -1)
                }
            }), this.initComponentAndTemplate({
                id: "pitch_shift-up",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "54px",
                        top: "40px",
                        width: "33px",
                        height: "38px"
                    },
                    skin: "PitchShift",
                    mode: "momentary",
                    interaction: () => this.incDecButtons("pitch_-_+", 1)
                }
            }), this.initComponentAndTemplate({
                id: "pitch_shift-default",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: Object.assign(Object.assign({}, this.styles.hiddenButton), {
                        left: "16px",
                        top: "32px"
                    }),
                    interaction: () => this.defaultButtons(["pitch_-_+"])
                }
            }), this.initComponentAndTemplate({
                id: "in_gain_l",
                state: {
                    "ua-param": "in_gain_l",
                    misc: {
                        tag: "ua-knob"
                    },
                    style: Object.assign(Object.assign({}, this.styles.potKnob), {
                        left: "97px"
                    }),
                    skin: "PotKnob"
                }
            }), this.initComponentAndTemplate({
                id: "in_gain_linked",
                state: {
                    "ua-param": "in_gain_l",
                    misc: {
                        tag: "ua-knob"
                    },
                    style: Object.assign(Object.assign({}, this.styles.potKnob), {
                        left: "137px"
                    }),
                    skin: "PotKnob"
                }
            }), this.initComponentAndTemplate({
                id: "in_gain_r",
                state: {
                    "ua-param": "in_gain_r",
                    misc: {
                        tag: "ua-knob"
                    },
                    style: Object.assign(Object.assign({}, this.styles.potKnob), {
                        left: "137px"
                    }),
                    skin: "PotKnob"
                }
            }), this.initComponentAndTemplate({
                id: "in_gain-default",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: Object.assign(Object.assign({}, this.styles.hiddenButton), {
                        left: "99px",
                        top: "32px"
                    }),
                    interaction: () => this.defaultButtons(["in_gain_l", "in_gain_r"])
                }
            }), this.initComponentAndTemplate({
                id: "link",
                state: {
                    value: 0,
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "182px",
                        top: "56px",
                        width: "18px",
                        height: "17px"
                    },
                    skin: "LinkLED",
                    skinOptions: {},
                    disabled: !1,
                    interaction: () => this.linkHasChangedFromGUI()
                }
            }), this.initComponentAndTemplate({
                id: "bug_fixes",
                state: {
                    "ua-param": "bug_fixes",
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "177px",
                        top: "35px",
                        width: "28px",
                        height: "17px"
                    },
                    skin: "UALogo",
                    skinOptions: {},
                    disabled: !1
                }
            }), this.initComponentAndTemplate({
                id: "out_lvl_l",
                state: {
                    "ua-param": "out_lvl_l",
                    misc: {
                        tag: "ua-knob"
                    },
                    style: Object.assign(Object.assign({}, this.styles.potKnob), {
                        left: "212px"
                    }),
                    skin: "PotKnob"
                }
            }), this.initComponentAndTemplate({
                id: "out_lvl_linked",
                state: {
                    "ua-param": "out_lvl_l",
                    misc: {
                        tag: "ua-knob"
                    },
                    style: Object.assign(Object.assign({}, this.styles.potKnob), {
                        left: "252px"
                    }),
                    skin: "PotKnob"
                }
            }), this.initComponentAndTemplate({
                id: "out_lvl_r",
                state: {
                    "ua-param": "out_lvl_r",
                    misc: {
                        tag: "ua-knob"
                    },
                    style: Object.assign(Object.assign({}, this.styles.potKnob), {
                        left: "252px"
                    }),
                    skin: "PotKnob"
                }
            }), this.initComponentAndTemplate({
                id: "out_lvl-default",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: Object.assign(Object.assign({}, this.styles.hiddenButton), {
                        left: "214px",
                        top: "32px"
                    }),
                    interaction: () => this.defaultButtons(["out_lvl_l", "out_lvl_r"])
                }
            }), this.initComponentAndTemplate({
                id: "hold_switch",
                state: {
                    misc: {
                        tag: "ua-slider"
                    },
                    style: {
                        position: "absolute",
                        left: "301px",
                        top: "40px",
                        width: "30px",
                        height: "40px"
                    },
                    skin: "DispSwitch",
                    orientation: a.Orientation.vertical,
                    value: 0,
                    discrete: !0,
                    states: [0, 1],
                    interaction: () => this.toggleSwitch("led_hold")
                }
            }), this.initComponentAndTemplate({
                id: "power",
                state: {
                    "ua-param": "power",
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "331px",
                        top: "40px",
                        width: "33px",
                        height: "33px"
                    },
                    skin: "PowerSwitch"
                }
            }), this.initComponentAndTemplate({
                id: "pcb_cover",
                state: {
                    misc: {
                        tag: "div"
                    },
                    style: this.styles.pcbCover
                }
            }), this.initComponentAndTemplate({
                id: "open_close",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "331px",
                        top: "80px",
                        width: "33px",
                        height: "33px"
                    },
                    skin: "OpenClose",
                    value: 0,
                    interaction: () => this.toggleSwitch("pcb_open")
                }
            }), this.initComponentAndTemplate({
                id: "outl",
                state: {
                    "ua-meter": "outl",
                    misc: {
                        tag: "ua-film-strip"
                    },
                    style: {
                        position: "absolute",
                        left: "73px",
                        top: "93px",
                        width: "97px",
                        height: "17px"
                    },
                    imageName: "UA_Lexicon224_LED-gainmeter",
                    frameSize: 17,
                    frameCount: 11
                }
            }), this.initComponentAndTemplate({
                id: "outr",
                state: {
                    "ua-meter": "outr",
                    misc: {
                        tag: "ua-film-strip"
                    },
                    style: {
                        position: "absolute",
                        left: "73px",
                        top: "111px",
                        width: "97px",
                        height: "17px"
                    },
                    imageName: "UA_Lexicon224_LED-gainmeter",
                    frameSize: 17,
                    frameCount: 11
                }
            }), this.initComponentAndTemplate({
                id: "overflow",
                state: {
                    "ua-meter": "overflow",
                    misc: {
                        tag: "ua-film-strip"
                    },
                    style: {
                        position: "absolute",
                        left: "177px",
                        top: "102px",
                        width: "17px",
                        height: "17px"
                    },
                    imageName: "UA_Lexicon224_LED",
                    frameSize: 17,
                    frameCount: 2,
                    direction: a.AnimationDirection.reverse
                }
            });
            for (let e = 0; e < 8; e++) this.programButtons[e] = this.initComponentAndTemplate({
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: 51 + 35 * e + "px",
                        top: "178px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitch" + (e < 1 ? "L" : e < 7 ? "C" : "R"),
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.setButtons("program", e)
                }
            });
            this.initComponentAndTemplate({
                id: "program-chorus",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: Object.assign(Object.assign({}, this.styles.hiddenButton), {
                        left: "242px",
                        top: "137px"
                    }),
                    interaction: () => this.setButtons("program", 8)
                }
            }), this.initComponentAndTemplate({
                id: "immediate",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "51px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchL",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.toggleButtons("immediate")
                }
            }), this.initComponentAndTemplate({
                id: "sys_noise",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "86px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.toggleButtons("sys_noise")
                }
            }), this.initComponentAndTemplate({
                id: "rear_outs",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "121px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.toggleButtons("rear_outs")
                }
            }), this.initComponentAndTemplate({
                id: "mode_enh",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "156px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.toggleButtons("mode_enh")
                }
            }), this.initComponentAndTemplate({
                id: "decay_opt",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "191px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.toggleButtons("decay_opt")
                }
            }), this.initComponentAndTemplate({
                id: "mix-down",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "226px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("mix", -1)
                }
            }), this.initComponentAndTemplate({
                id: "mix-up",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "261px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("mix", 1)
                }
            }), this.initComponentAndTemplate({
                id: "wet_solo",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "296px",
                        top: "244px",
                        width: "35px",
                        height: "60px"
                    },
                    skin: "SmallSwitchR",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.toggleButtons("wet_solo")
                }
            });
            ["bass", "mid", "crossover", "treble_decay", "depth", "predelay"].forEach((e, t) => {
                this.initComponentAndTemplate({
                    state: {
                        "ua-param": e,
                        misc: {
                            tag: "ua-slider"
                        },
                        style: {
                            position: "absolute",
                            left: 49 + 48 * t + "px",
                            top: "337px",
                            width: "48px",
                            height: "159px",
                            "--ua-slider-track-height": "100%",
                            "--ua-slider-track-border": "none",
                            "--ua-slider-track-radius": "0",
                            "--ua-slider-track-background": "transparent",
                            "--ua-slider-track-low-background": "transparent",
                            "--ua-slider-track-high-background": "transparent",
                            "--ua-slider-indicator-height": "45px",
                            "--ua-slider-indicator-width": "48px",
                            "--ua-slider-indicator-background": ["url(./images/UA_Lexicon224_slider.png)", "-webkit-image-set(\n                url(./images/UA_Lexicon224_slider.png) 1x,\n                url(./images/@2x/UA_Lexicon224_slider@2x.png) 2x\n              )"],
                            "--ua-slider-indicator-shadow": "none"
                        },
                        orientation: a.Orientation.vertical,
                        interaction: () => this.updateLEDDisplay(e),
                        indicatorJumpToPosition: !1
                    }
                }), this.initComponentAndTemplate({
                    state: {
                        misc: {
                            tag: "ua-button"
                        },
                        style: {
                            position: "absolute",
                            left: 49 + 48 * t + "px",
                            top: "481px",
                            width: "48px",
                            height: "20px"
                        },
                        interaction: () => this.defaultButtons([e])
                    }
                })
            }), this.initComponentAndTemplate({
                id: "diffusion-down",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "50px",
                        top: "508px",
                        width: "47px",
                        height: "60px"
                    },
                    skin: "BigSwitchL",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("diffusion", -1)
                }
            }), this.initComponentAndTemplate({
                id: "diffusion-up",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "97px",
                        top: "508px",
                        width: "47px",
                        height: "60px"
                    },
                    skin: "BigSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("diffusion", 1)
                }
            }), this.initComponentAndTemplate({
                id: "diffusion-default",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "50px",
                        top: "568px",
                        width: "94px",
                        height: "20px"
                    },
                    interaction: () => this.defaultButtons(["diffusion"])
                }
            }), this.initComponentAndTemplate({
                id: "mode_enh-down",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "144px",
                        top: "508px",
                        width: "47px",
                        height: "60px"
                    },
                    skin: "BigSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("enh_-_+", -1)
                }
            }), this.initComponentAndTemplate({
                id: "mode_enh-up",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "191px",
                        top: "508px",
                        width: "47px",
                        height: "60px"
                    },
                    skin: "BigSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("enh_-_+", 1)
                }
            }), this.initComponentAndTemplate({
                id: "mode_enh-default",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "144px",
                        top: "568px",
                        width: "94px",
                        height: "20px"
                    },
                    interaction: () => this.defaultButtons(["enh_-_+"])
                }
            }), this.initComponentAndTemplate({
                id: "decay_opt-down",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "238px",
                        top: "508px",
                        width: "47px",
                        height: "60px"
                    },
                    skin: "BigSwitchC",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("opt_-_+", -1)
                }
            }), this.initComponentAndTemplate({
                id: "decay_opt-up",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "285px",
                        top: "508px",
                        width: "47px",
                        height: "60px"
                    },
                    skin: "BigSwitchR",
                    skinOptions: {},
                    mode: "momentary",
                    interaction: () => this.incDecButtons("opt_-_+", 1)
                }
            }), this.initComponentAndTemplate({
                id: "decay_opt-default",
                state: {
                    misc: {
                        tag: "ua-button"
                    },
                    style: {
                        position: "absolute",
                        left: "238px",
                        top: "568px",
                        width: "94px",
                        height: "20px"
                    },
                    interaction: () => this.defaultButtons(["opt_-_+"])
                }
            })
        }
        incDecButtons(e, t) {
            const n = () => {
                    this.buttonDown && (this.timeoutID = setTimeout(n, 95), i())
                },
                i = () => {
                    const n = this.plug.getStoreValue({
                            selector: "controls",
                            id: e,
                            property: "normalized_value"
                        }),
                        i = this.plug.getStoreValue({
                            selector: "controls",
                            id: e,
                            property: "real_value"
                        });
                    let r = 0;
                    if (this.ledDisplay.getActiveControlID() == e) switch (e) {
                        case "diffusion": {
                            const i = 1,
                                s = 64,
                                o = Math.max(i, Math.min(s - 1, Math.round(n * s)));
                            r = Math.max(i, Math.min(o + t, s)), this.plug.setWithReceipt({
                                selector: "controls",
                                id: e,
                                property: "normalized_value",
                                payload: r / s
                            });
                            break
                        }
                        case "mix": {
                            const i = this.shiftKeyPressed ? 1e3 : 100;
                            r = Math.round(n * i) + t, this.plug.setWithReceipt({
                                selector: "controls",
                                id: e,
                                property: "normalized_value",
                                payload: r / i
                            });
                            break
                        }
                        case "enh_-_+":
                        case "pitch_-_+":
                        case "opt_-_+": {
                            const n = 0,
                                s = 15;
                            r = Math.max(n, Math.min(i + t, s)), this.plug.setWithReceipt({
                                selector: "controls",
                                id: e,
                                property: "real_value",
                                payload: r
                            });
                            break
                        }
                    } else this.ledDisplay.setLEDDisplayID(e)
                };
            return (t, {
                state: r
            }) => {
                const s = this.plug.getStoreValue({
                    selector: "controls",
                    id: "program",
                    property: "real_value"
                });
                let o = 0;
                if (this.plug.getStoreValue({
                        selector: "controls",
                        id: "power",
                        property: "real_value"
                    })) {
                    if ("down" == r.type) {
                        switch (e) {
                            case "diffusion":
                                if (3 == s) return;
                                break;
                            case "mix":
                                if (o = this.plug.getStoreValue({
                                        selector: "controls",
                                        id: "wet_solo",
                                        property: "real_value"
                                    }), o) return void this.ledDisplay.setLEDDisplayID(e);
                                break;
                            case "enh_-_+":
                            case "pitch_-_+":
                                if (o = this.plug.getStoreValue({
                                        selector: "controls",
                                        id: "mode_enh",
                                        property: "real_value"
                                    }), !o) return void this.ledDisplay.setLEDDisplayID(e);
                                break;
                            case "opt_-_+":
                                if (7 == s || 8 == s) return;
                                if (o = this.plug.getStoreValue({
                                        selector: "controls",
                                        id: "decay_opt",
                                        property: "real_value"
                                    }), !o) return void this.ledDisplay.setLEDDisplayID(e)
                        }
                        this.shiftKeyPressed = r.event.shiftKey, this.buttonDown = !0, this.plug.setTouch(e, !0), this.timeoutID = setTimeout(n, 200), i()
                    }
                    "up" == r.type && (this.buttonDown && (this.buttonDown = !1, this.plug.setTouch(e, !1)), clearTimeout(this.timeoutID))
                }
            }
        }
        setButtons(e, t) {
            return (n, {
                state: i
            }) => {
                this.plug.getStoreValue({
                    selector: "controls",
                    id: "power",
                    property: "real_value"
                }) && ("down" == i.type && (this.plug.setTouch(e, !0), this.plug.setWithReceipt({
                    selector: "controls",
                    id: e,
                    property: "real_value",
                    payload: i.event.shiftKey ? 8 : t
                })), "up" == i.type && this.plug.setTouch(e, !1))
            }
        }
        toggleButtons(e) {
            return (t, {
                state: n
            }) => {
                const i = this.plug.getStoreValue({
                        selector: "controls",
                        id: "program",
                        property: "real_value"
                    }),
                    r = this.plug.getStoreValue({
                        selector: "controls",
                        id: "power",
                        property: "real_value"
                    }),
                    s = this.plug.getStoreValue({
                        selector: "controls",
                        id: e,
                        property: "real_value"
                    });
                r && ("decay_opt" != e || 7 != i && 8 != i) && ("down" == n.type && (this.plug.setTouch(e, !0), this.plug.setWithReceipt({
                    selector: "controls",
                    id: e,
                    property: "real_value",
                    payload: s ? 0 : 1
                })), "up" == n.type && this.plug.setTouch(e, !1))
            }
        }
        updateLEDDisplay(e) {
            return (t, {
                state: n
            }) => {
                "down" == n.type && this.ledDisplay.setLEDDisplayID(e)
            }
        }
        defaultButtons(e) {
            return (t, {
                state: n
            }) => {
                const i = this.plug.getStoreValue({
                    selector: "controls",
                    id: "program",
                    property: "real_value"
                });
                let r = 0;
                if ("down" == n.type)
                    for (let t of e) {
                        switch (t) {
                            case "bass":
                            case "mid":
                            case "crossover":
                            case "treble_decay":
                            case "predelay":
                                this.ledDisplay.setLEDDisplayID(t);
                                break;
                            case "depth":
                                if (r = this.plug.getStoreValue({
                                        selector: "controls",
                                        id: "rear_outs",
                                        property: "real_value"
                                    }), 5 == i && r || 8 == i) return;
                                this.ledDisplay.setLEDDisplayID(t);
                                break;
                            case "diffusion":
                                if (3 == i) return;
                                this.ledDisplay.setLEDDisplayID(t);
                                break;
                            case "enh_-_+":
                            case "pitch_-_+":
                                if (r = this.plug.getStoreValue({
                                        selector: "controls",
                                        id: "mode_enh",
                                        property: "real_value"
                                    }), !r) return;
                                this.ledDisplay.setLEDDisplayID(t);
                                break;
                            case "opt_-_+":
                                if (r = this.plug.getStoreValue({
                                        selector: "controls",
                                        id: "decay_opt",
                                        property: "real_value"
                                    }), !r) return;
                                this.ledDisplay.setLEDDisplayID(t)
                        }
                        this.plug.postWithReceipt({
                            selector: "controls",
                            id: t,
                            command: "set_control_default_value"
                        })
                    }
            }
        }
        toggleSwitch(e) {
            return (t, {
                state: n
            }) => {
                this.plug.setWithReceipt({
                    selector: "private_data",
                    id: e,
                    property: "data",
                    payload: n.value
                })
            }
        }
    };
    l = (0, i.__decorate)([(0, s.customElement)(r), (0, i.__metadata)("design:paramtypes", [o.AudioPlugin])], l), t.ApplicationRoot = l
});
