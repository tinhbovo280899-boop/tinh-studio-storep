// Extracted webpack module 94. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-listbox",
        o = '\x3c!-- BG: HBGF-1335: This component is deprecated: does not use display and click-region pattern --\x3e\n\n<div class="container ${disabled ? \'disabled\' : \'\'}" ref="$container">\n  <select ref="$select" disabled.bind="disabled">\n    <template repeat.for="option of options">\n      <template if.bind="option.options && option.options.length">\n        <optgroup>\n          <option repeat.for="option of option.options" value.bind="option.value"></option>\n        </optgroup>\n      </template>\n      <template else>\n        <option value.bind="option.value"></option>\n      </template>\n    </template>\n  </select>\n\n  <div class="item-container" style.bind="listContainerStyle">\n    <slot></slot>\n  </div>\n</div>\n';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  display: inline-block;\n}\n\n.container {\n  width: 100%;\n  height: 100%;\n  -webkit-touch-callout: none; /* iOS Safari */\n    -webkit-user-select: none; /* Safari */\n      -khtml-user-select: none; /* Konqueror HTML */\n        -moz-user-select: none; /* Firefox */\n        -ms-user-select: none; /* Internet Explorer/Edge */\n            user-select: none; /* Non-prefixed version, currently\n                                  supported by Chrome and Opera */\n  --ua-listbox-border-default: 1px solid #ddd;\n  --ua-listbox-background-default: #f9f9f9;\n  --ua-listbox-radius-default: 3px;\n  --ua-listbox-color-default: #333;\n}\n\nselect {\n  display: none;\n  width: 100%;\n  height: 100%;\n}\n\n.item-container {\n  border: var(--ua-listbox-border, var(--ua-listbox-border-default));\n  background: var(--ua-listbox-background, var(--ua-listbox-background-default));\n  width: 100%;\n  height: 100%;\n  border-radius: var(--ua-listbox-radius, var(--ua-listbox-radius-default));\n}\n\n.disabled {\n  opacity: var(--ua-disabled-opacity, 1.0);\n}\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
