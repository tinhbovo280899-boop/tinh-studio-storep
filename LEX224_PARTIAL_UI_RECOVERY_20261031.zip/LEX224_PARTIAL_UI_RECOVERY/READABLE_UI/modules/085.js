// Extracted webpack module 85. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t), n.d(t, "name", (function() {
        return r
    })), n.d(t, "template", (function() {
        return s
    })), n.d(t, "dependencies", (function() {
        return o
    })), n.d(t, "shadowOptions", (function() {
        return a
    })), n.d(t, "register", (function() {
        return l
    }));
    var i = n(1);
    const r = "ua-midi-note",
        s = "<style>\n  :host {\n    position: absolute;\n    top: 0px;\n    left: 0px;\n    height: 100%;\n    width: 100%;\n    cursor: default;\n  } \n  \n</style>";
    t.default = s;
    const o = [],
        a = {
            mode: "open"
        };
    let c;

    function l(e) {
        c || (c = i.CustomElement.define({
            name: r,
            template: s,
            dependencies: o,
            shadowOptions: a
        })), e.register(c)
    }
});
