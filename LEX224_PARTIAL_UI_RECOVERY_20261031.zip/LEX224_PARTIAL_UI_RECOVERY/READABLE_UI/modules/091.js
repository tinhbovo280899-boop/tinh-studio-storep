// Extracted webpack module 91. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-option",
        o = '<template class="${selected ? \'active\' : \'\'}">\n  \n  <slot name="heading"></slot>\n\n  \x3c!-- Container --\x3e\n  <div class="container" ref="containerRef">\n\n    \x3c!-- BG: HBGF-1335: Prevent implicit compositing by placing "static" click region underneath composited display --\x3e\n    \x3c!-- Click Region --\x3e\n    <div class="click-region"></div>\n\n    \x3c!-- Display --\x3e\n    <slot class="display"></slot>\n\n  </div>\n\n</template>\n';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  display: inline-block;\n  position: static;\n  text-align: center;\n  width: 100%;\n}\n\n.container {\n  position: relative;\n  width: 100%;\n  padding: var(--ua-option-padding, 6px);\n  color: var(--ua-option-color, inherit);\n  cursor: default;\n  border: var(--ua-option-border, 0px none transparent);\n  border-top: var(--ua-option-border-top, 0px none transparent);\n  border-left: var(--ua-option-border-left, 0px none transparent);\n  border-bottom: var(--ua-option-border-bottom, 0px none transparent);\n  border-right: var(--ua-option-border-right, 0px none transparent);\n  box-shadow: var(--ua-option-box-shadow, none);\n}\n\n:host(:hover) .container {\n  background: var(--ua-option-background-hover, rgba(0, 0, 0, .1));\n  border: var(--ua-option-border-hover, var(--ua-option-border, 0px none transparent));\n  border-top: var(--ua-option-border-top-hover, var(--ua-option-border-top, 0px none transparent));\n  border-left: var(--ua-option-border-left-hover, var(--ua-option-border-left, 0px none transparent));\n  border-bottom: var(--ua-option-border-bottom-hover, var(--ua-option-border-bottom, 0px none transparent));\n  border-right: var(--ua-option-border-right-hover, var(--ua-option-border-right, 0px none transparent));\n  box-shadow: var(--ua-option-box-shadow-hover, var(--ua-option-box-shadow, none));\n}\n\n:host(.active) .container {\n  background: var(--ua-option-background-active, #2196F3); \n  color: var(--ua-option-color-active, var(--ua-option-color, inherit));\n  border: var(--ua-option-border-active, var(--ua-option-border, 0px none transparent));\n  border-top: var(--ua-option-border-top-active, var(--ua-option-border-top, 0px none transparent));\n  border-left: var(--ua-option-border-left-active, var(--ua-option-border-left, 0px none transparent));\n  border-bottom: var(--ua-option-border-bottom-active, var(--ua-option-border-bottom, 0px none transparent));\n  border-right: var(--ua-option-border-right-active, var(--ua-option-border-right, 0px none transparent));\n  box-shadow: var(--ua-option-box-shadow-active, var(--ua-option-box-shadow, none));\n}\n\n.display {\n  position: absolute;\n  top: 0px;\n  left: 0px;\n}\n\n.click-region {\n  position: absolute;\n  pointer-events: none;\n  top: 0px;\n  left: 0px;\n  width: 100%;\n  height: 100%;\n  border: var(--ua-click-region-border, none); /* Used for displaying the click region */\n  background: var(--ua-click-region-background, none); /* Used for displaying the click region */\n}")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
