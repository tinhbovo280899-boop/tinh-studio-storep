// Extracted webpack module 93. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-input-text",
        o = '<template class="${disabled ? \'disabled\' : \'\'}">\n\n  \x3c!-- Container --\x3e\n  <div class="container">\n\n    \x3c!-- Click Region--\x3e\n    <div class="click-region"></div>\n\n    \x3c!-- Display --\x3e\n    <input type="text"\n      class="display ${disabled ? \'disabled\' : \'\'}"\n      ref="input"\n      disabled.bind="disabled"\n    >\n\n  </div>\n  \n</template>';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  display: inline-block;\n  position: relative;\n}\n\n:host(:focus) {\n  outline: none;\n}\n\n:host(.disabled) {\n  opacity: var(--ua-disabled-opacity, 1.0);\n}\n\n.container {\n  position: relative;\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n\n.disabled {\n  /* SL: WebKit adjusts the color of disabled input elements */\n  /* BG: HBGF-1335: Prefixed properties set on parent disabled class will not \n  cascade down to children. Set prefixed property on child disabled class instead */\n  -webkit-text-fill-color: var(--ua-input-text-color, #333);\n}\n\n.click-region {\n  position: absolute;\n  top: calc(-1 * var(--ua-input-text-click-region-top, 0px));\n  left: calc(-1 * var(--ua-input-text-click-region-left, 0px));\n  height: calc(100% + var(--ua-input-text-click-region-top, 0px) + var(--ua-input-text-click-region-bottom, 0px));\n  width: calc(100% + var(--ua-input-text-click-region-left, 0px) + var(--ua-input-text-click-region-right, 0px));\n  border: var(--ua-click-region-border, none);\n}\n\n.display {\n  /* BG: HBGF-1335: According to ChatGPT 12/20/2023, input type text does not benefit from hardware acceleration\n  as the browser applies its own rendering techniques to it. */\n  /* BG: HBGF-1335: When viewing the component in MS Edge 3D View, the display (Input type text) \n  is embedded in the webpage background, not on its own layer, even when using translatez(0) */\n  /* transform: translateZ(0); */\n\n  position: absolute;\n  top: var(--ua-input-text-click-region-top, 0px);\n  left: var(--ua-input-text-click-region-left, 0px);\n  height: calc(100% - var(--ua-input-text-click-region-top, 0px) - var(--ua-input-text-click-region-bottom, 0px));\n  width: calc(100% - var(--ua-input-text-click-region-left, 0px) - var(--ua-input-text-click-region-right, 0px));\n  background: var(--ua-input-text-background, #f9f9f9);\n  border-radius: var(--ua-input-text-radius, 3px);\n  border: var(--ua-input-text-border, 1px solid #ddd);\n  color: var(--ua-input-text-color, #333);\n  padding: var(--ua-input-text-padding, 4px);\n  text-align: var(--ua-input-text-text-align, left);\n  text-transform: var(--ua-input-text-text-transform, none);\n  box-shadow: var(--ua-input-text-shadow, none);\n  caret-color: var(--ua-input-text-caret-color, var(--ua-input-text-color, #333));\n  outline: none;\n\n  /* Default the input to not selectable. This fixes a quirk with Safari/Luna. */\n  -webkit-touch-callout: none; /* iOS Safari */\n      -webkit-user-select: none; /* Safari */\n        -khtml-user-select: none; /* Konqueror HTML */\n          -moz-user-select: none; /* Firefox */\n          -ms-user-select: none; /* Internet Explorer/Edge */\n              user-select: none; /* Non-prefixed version, currently\n                                    supported by Chrome and Opera */\n}\n\n.display:focus {\n  background: var(--ua-input-text-active-background, var(--ua-input-text-background, #f9f9f9));\n  border: var(--ua-input-text-active-border, 1px solid #2196F3);\n  color: var(--ua-input-text-active-color, var(--ua-input-text-color, #333));\n}\n\n\n.display::selection { \n  background: var(--ua-input-text-active-selection-background, #2196F3);\n  color: var(--ua-input-text-active-selection-color, var(--ua-input-text-color, #333));\n}\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
