// Extracted webpack module 74. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return v
        }));
        var i = n(0),
            r = n(1),
            s = n(27),
            o = n(5),
            a = n(12),
            c = n(92),
            l = n(3),
            u = n(4),
            h = n.n(u),
            d = n(8),
            p = n(16),
            f = n(9);
        let g = c;
        l.i && (g = h.a.readFileSync(h.a.resolve(e, "./ua-dropdown.html"), "utf-8"));
        const m = Object.assign({}, d.a);
        let v = class extends d.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = m, this.selectedOption = null, this.valueType = o.c.real, this.options = [], this.listContainerStyle = null, this.selectedItemContainerStyle = null, this.listVisible = !1, this.validateClickEvent = (e, {
                    state: t
                }) => (t.id = "validateClickEvent", this.listVisible ? this.isDropdownHit(e) && (t.exitChain = !0) : (this.removeClickOutsideMiddleware(e), t.exitChain = !0), t), this.validateVisibilityChange = (e, {
                    state: t
                }) => (t.id = "validateVisibilityChange", "hidden" !== document.visibilityState && (t.exitChain = !0), t), this.addUpEventListener = (e, {
                    state: t
                }) => {
                    t.id = "addUpEventListener";
                    const n = [this.validateEvent, this.tryInteractionCallback, this.updateMiddlewareEvent, this.tryInteractionCallback, this.removeMoveAndUpListener];
                    return this.generateUpEventListener({
                        event: e,
                        middleware: n,
                        target: window
                    }), t
                }, this.onDownEvent = (e, t) => {
                    const {
                        state: n
                    } = t;
                    if (n.id = "onDownEvent", this.shouldMiddlewareChainContinue(n)) {
                        const i = this.listVisible;
                        i ? this.hideList(e, t) : this.showList(e, t), this.listVisible === i && n.action.push("EXIT")
                    }
                    return n
                }, this.showList = (e, {
                    state: t
                }) => (t.id = "showList", this.listVisible = !0, this.scrollOptionIntoView(), this.addClickOutsideMiddleware(e), t), this.hideList = (e, {
                    state: t
                }) => (t.id = "hideList", this.listVisible = !1, this.removeClickOutsideMiddleware(e), t), this.createOpenOrCloseEvent = (e, {
                    state: t
                }) => (t.id = "createOpenOrCloseEvent", this.shouldMiddlewareChainContinue(t) || (t.exitChain = !0), this.listVisible ? (t.event = new Event("open"), t.type = "open") : (t.event = new Event("close"), t.type = "close"), t), this.onKeyDown = e => {
                    e.preventDefault()
                }
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.$container
            }
            binding() {
                this.optionsChanged()
            }
            attached() {
                const e = [this.validateEvent, this.addUpEventListener, this.onDownEvent, this.tryInteractionCallback, this.updateMiddlewareEvent, this.tryInteractionCallback, this.createOpenOrCloseEvent, this.tryInteractionCallback],
                    t = [this.tryInteractionCallback];
                this.eventListeners.mouseover = this.createEventListenerMiddleware({
                    middleware: t
                }), this.eventListeners.mouseout = this.createEventListenerMiddleware({
                    middleware: t
                }), this.eventListeners.visibilitychange = this.createEventListenerMiddleware({
                    middleware: [this.validateVisibilityChange, this.hideList, this.createOpenOrCloseEvent, this.tryInteractionCallback]
                }), this.generateDownEventListener({
                    middleware: e,
                    target: this.$button
                }), this.$button.addEventListener("mouseover", this.eventListeners.mouseover), this.$button.addEventListener("mouseout", this.eventListeners.mouseout), document.addEventListener("visibilitychange", this.eventListeners.visibilitychange), this.$list.addEventListener("keydown", this.onKeyDown)
            }
            detached() {
                this.removeDownEventListener({
                    target: this.$button
                }), this.$button.removeEventListener("mouseover", this.eventListeners.mouseover), this.$button.removeEventListener("mouseout", this.eventListeners.mouseout), document.removeEventListener("visibilitychange", this.eventListeners.visibilitychange), this.$list.removeEventListener("keydown", this.onKeyDown)
            }
            configureFromUANet(e, t, n) {
                n.valueType = this.valueType
            }
            setUANetValue(e, t) {
                this.value = t
            }
            getUANetValue(e) {
                return this.value
            }
            subscribe(e, t) {
                return this.ea.subscribe(e, t)
            }
            getInteraction() {
                return this
            }
            scrollOptionIntoView() {
                const e = this.element.getElementsByClassName("active")[0];
                e && (this.$list.scrollTop = e.offsetTop - this.$list.offsetTop)
            }
            executeSelectedMiddlewareChain() {
                return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    const e = this.generateMiddlewareConfig({
                            action: ["RESET"],
                            event: new Event("selected"),
                            type: "selected"
                        }),
                        t = yield this.runMiddleware({
                            config: e,
                            middleware: [this.tryInteractionCallback, this.hideList, this.createOpenOrCloseEvent, this.tryInteractionCallback]
                        });
                    this.handleMiddleware(t)
                }))
            }
            executeCloseMiddlewareChain() {
                return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    const e = this.generateMiddlewareConfig({
                            action: ["RESET"],
                            event: new Event("close"),
                            type: "close"
                        }),
                        t = yield this.runMiddleware({
                            config: e,
                            middleware: [this.hideList, this.createOpenOrCloseEvent, this.tryInteractionCallback]
                        });
                    this.handleMiddleware(t)
                }))
            }
            addClickOutsideMiddleware(e) {
                const t = [this.validateClickEvent, this.tryInteractionCallback, this.hideList, this.createOpenOrCloseEvent, this.tryInteractionCallback];
                l.h(e) ? (this.eventListeners.click = this.createEventListenerMiddleware({
                    middleware: t
                }), window.addEventListener("click", this.eventListeners.click, !0)) : l.j(e) && (this.outsideUpEventListener = this.createEventListenerMiddleware({
                    middleware: t
                }), window.addEventListener("touchend", this.outsideUpEventListener, {
                    passive: !1,
                    capture: !0
                }))
            }
            removeClickOutsideMiddleware(e) {
                l.h(e) ? window.removeEventListener("click", this.eventListeners.click, !0) : l.j(e) && window.removeEventListener("touchend", this.outsideUpEventListener, !0)
            }
            findOptionWithValue(e, t) {
                for (let n of e) {
                    if (n.value === t) return n;
                    if (n.options && n.options.length) {
                        const e = this.findOptionWithValue(n.options, t);
                        if (e) return e
                    }
                }
                return null
            }
            valueChanged() {
                const e = this.findOptionWithValue(this.options, this.value);
                this.selectedOption && (this.selectedOption.selected = !1), this.selectedOption = e, this.selectedOption ? (this.$select && (this.$select.value = this.selectedOption.value), this.selectedOption.selected = !0) : this.$select && (this.$select.value = ""), Object(a.d)(this.element)
            }
            optionsChanged() {
                this.options.forEach(e => e.setOwner(this)), this.valueChanged()
            }
            select(e) {
                return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    return e.selected ? (yield this.executeCloseMiddlewareChain(), !1) : (this.publishUANetInteraction({
                        action: "START"
                    }), this.value = e.value, this.publishUANetInteraction({
                        action: "CHANGE"
                    }), this.publishUANetInteraction({
                        action: "END"
                    }), yield this.executeSelectedMiddlewareChain(), !0)
                }))
            }
            setValue(e) {
                this.value = e
            }
            isDropdownHit(e) {
                return e.composedPath().includes(this.element)
            }
        };
        Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], v.prototype, "selectedOption", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", String)], v.prototype, "valueType", void 0), Object(i.__decorate)([Object(r.children)({
            filter: (e, t, n) => n instanceof s.a
        }), Object(i.__metadata)("design:type", Array)], v.prototype, "options", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], v.prototype, "listContainerStyle", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], v.prototype, "selectedItemContainerStyle", void 0), v = Object(i.__decorate)([l.i ? Object(r.customElement)({
            name: "ua-dropdown",
            template: g
        }) : Object(r.customElement)(g), Object(i.__metadata)("design:paramtypes", [HTMLElement, p.a, f.a])], v)
    }).call(this, "/")
});
