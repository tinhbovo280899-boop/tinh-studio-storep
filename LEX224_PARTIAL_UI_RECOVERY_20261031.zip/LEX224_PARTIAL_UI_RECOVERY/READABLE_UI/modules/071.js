// Extracted webpack module 71. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return m
        }));
        var i = n(0),
            r = n(17),
            s = n(1),
            o = n(12),
            a = n(13),
            c = n(87),
            l = n(3),
            u = n(4),
            h = n.n(u),
            d = n(8),
            p = n(9);
        let f = c;
        l.i && (f = h.a.readFileSync(h.a.resolve(e, "./ua-checkbox.html"), "utf-8"));
        const g = Object.assign(Object.assign({}, d.a), {
            value: !1
        });
        let m = class extends d.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = g, this.onMouseDown = e => {
                    if (!this.disabled) {
                        if (this.profile.isRevertEvent(e)) return this.publishUANetInteraction({
                            action: "REVERT"
                        }), void e.preventDefault();
                        if (this.profile.isDefaultEvent(e)) return this.publishUANetInteraction({
                            action: "DEFAULT"
                        }), void e.preventDefault();
                        e.cancelable && e.preventDefault(), this.publishUANetInteraction({
                            action: "START"
                        }), this.value = !this.value, this.element.addEventListener("click", this.preventUnselect), this.element.dispatchEvent(new Event("change")), this.publishUANetInteraction({
                            action: "END"
                        })
                    }
                }, this.preventUnselect = e => {
                    e.preventDefault(), this.element.removeEventListener("click", this.preventUnselect)
                }, this.initClassState()
            }
            hardwareAcceleratedChanged() {
                this.skin || super.hardwareAcceleratedChanged()
            }
            getHardwareAcceleratedDisplay() {
                return this.$display
            }
            valueChanged() {
                this.publishUANetInteraction({
                    action: "CHANGE"
                }), Object(o.d)(this.element)
            }
            setUANetValue(e, t) {
                this.value = t > 0
            }
            getUANetValue(e) {
                return this.value ? 1 : 0
            }
        };
        m = Object(i.__decorate)([l.i ? Object(s.customElement)({
            name: "ua-checkbox",
            template: f
        }) : Object(s.customElement)(f), r.a, Object(i.__metadata)("design:paramtypes", [HTMLElement, a.a, p.a])], m)
    }).call(this, "/")
});
