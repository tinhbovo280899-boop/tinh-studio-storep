// Extracted webpack module 75. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return g
        }));
        var i = n(0),
            r = n(1),
            s = n(21),
            o = n(93),
            a = n(3),
            c = n(4),
            l = n.n(c),
            u = n(8),
            h = n(13),
            d = n(9);
        let p = o;
        a.i && (p = l.a.readFileSync(l.a.resolve(e, "./ua-input-text.html"), "utf-8"));
        const f = Object.assign(Object.assign({}, u.a), {
            value: ""
        });
        let g = class extends u.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.value = "", this.focused = !1, this.selected = !1, this.DEFAULT_TRACKER_STATE = f, this.windowFocus = !0, this.prevValue = this.value, this.addWindowDownEventListener = (e, {
                    state: t
                }) => {
                    if (t.id = "addWindowDownEventListener", !this.eventListeners.mousedown) {
                        const e = [this.onWindowDownEvent];
                        this.generateDownEventListener({
                            middleware: e,
                            target: window
                        })
                    }
                    return t
                }, this.removeWindowDownEventListener = (e, {
                    state: t
                }) => (t.id = "removeWindowDownEventListener", this.removeDownEventListener({
                    target: window
                }), this.eventListeners.mousedown = void 0, t), this.addKeyDownEventListener = (e, {
                    state: t
                }) => (t.id = "addKeyDownEventListener", this.eventListeners.keydown || (this.eventListeners.keydown = this.createEventListenerMiddleware({
                    middleware: [this.onKeyDown, this.tryInteractionCallback]
                }), document.addEventListener("keydown", this.eventListeners.keydown, !0)), t), this.removeKeyDownEventListener = (e, {
                    state: t
                }) => (t.id = "removeKeyDownEventListener", document.removeEventListener("keydown", this.eventListeners.keydown, !0), this.eventListeners.keydown = void 0, t), this.onWindowDownEvent = (e, {
                    state: t
                }) => (t.id = "onWindowDownEvent", e.composedPath().includes(this.input) || (this.focused = !1), t), this.onWindowBlur = e => {
                    this.setWindowFocus(!1)
                }, this.onWindowFocus = e => {
                    this.setWindowFocus(!0)
                }, this.onFocus = (e, {
                    state: t
                }) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    return t.id = "onFocus", this.focused = !0, yield Object(a.m)(1), this.selected = !0, t
                })), this.onInput = (e, {
                    state: t
                }) => (t.id = "onInput", t), this.onKeyDown = (e, {
                    state: t
                }) => {
                    switch (t.id = "onKeyDown", e.stopPropagation(), e.key) {
                        case "Enter":
                        case "Escape":
                            e.preventDefault(), t.exitChain = !0, this.focused = !1
                    }
                    return t
                }, this.onChange = (e, {
                    state: t
                }) => (t.id = "onChange", e.preventDefault(), t), this.onBlur = (e, {
                    state: t
                }) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    return t.id = "onBlur", yield Object(a.m)(1), this.getWindowFocus() ? t.value = this.getInputValue() : t.action.push("EXIT"), this.focused = !1, t
                })), this.onSelect = (e, {
                    state: t
                }) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    return t.id = "onSelect", this.isInputSelected() ? this.selected = !0 : this.selected = !1, t
                })), this.initClassState()
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.input
            }
            attaching() {
                this.setValue(this.value), this.eventListeners.change = this.createEventListenerMiddleware({
                    middleware: [this.onChange, this.tryInteractionCallback]
                }), this.eventListeners.input = this.createEventListenerMiddleware({
                    middleware: [this.onInput, this.tryInteractionCallback]
                }), this.eventListeners.focus = this.createEventListenerMiddleware({
                    middleware: [this.onFocus, this.addKeyDownEventListener, this.addWindowDownEventListener, this.tryInteractionCallback]
                }), this.eventListeners.blur = this.createEventListenerMiddleware({
                    middleware: [this.removeKeyDownEventListener, this.removeWindowDownEventListener, this.startUANetInteraction, this.changeUANetInteraction, this.endUANetInteraction, this.onBlur, this.tryInteractionCallback]
                }), this.eventListeners.select = this.createEventListenerMiddleware({
                    middleware: [this.onSelect, this.tryInteractionCallback]
                }), this.eventListeners.mouseover = this.createEventListenerMiddleware({
                    middleware: [this.tryInteractionCallback]
                }), this.eventListeners.mouseout = this.createEventListenerMiddleware({
                    middleware: [this.tryInteractionCallback]
                }), this.input.addEventListener("change", this.eventListeners.change), this.input.addEventListener("input", this.eventListeners.input), this.input.addEventListener("focus", this.eventListeners.focus), this.input.addEventListener("blur", this.eventListeners.blur), this.input.addEventListener("select", this.eventListeners.select), this.input.addEventListener("mouseover", this.eventListeners.mouseover), this.input.addEventListener("mouseout", this.eventListeners.mouseout), window.addEventListener("blur", this.onWindowBlur), window.addEventListener("focus", this.onWindowFocus)
            }
            detaching() {
                this.input.removeEventListener("change", this.eventListeners.change), this.input.removeEventListener("input", this.eventListeners.input), this.input.removeEventListener("focus", this.eventListeners.focus), this.input.removeEventListener("blur", this.eventListeners.blur), this.input.removeEventListener("select", this.eventListeners.select), this.input.removeEventListener("mouseover", this.eventListeners.mouseover), this.input.removeEventListener("mouseout", this.eventListeners.mouseout), window.removeEventListener("blur", this.onWindowBlur), window.removeEventListener("focus", this.onWindowFocus)
            }
            configureFromUANet(e, t, n) {
                n.valueType = s.f.string
            }
            setUANetValue(e, t) {
                null == t ? this.setValue(this.prevValue) : this.setValue(t)
            }
            getUANetValue(e) {
                return this.value
            }
            subscribe(e, t) {
                return this.ea.subscribe(e, t)
            }
            getInteraction() {
                return this
            }
            setValue(e) {
                e !== this.value ? (this.prevValue = this.value, this.value = e) : this.setInputValue(e)
            }
            set isSelectedOperable(e) {
                e ? (this.input.style.userSelect = "auto", this.input.style.webkitUserSelect = "auto") : (this.input.style.userSelect = "none", this.input.style.webkitUserSelect = "none")
            }
            getWindowFocus() {
                return this.windowFocus
            }
            setWindowFocus(e) {
                this.windowFocus = e
            }
            getInputValue() {
                var e;
                return null === (e = this.input) || void 0 === e ? void 0 : e.value
            }
            setInputValue(e) {
                return !(!this.input || this.focused) && (this.input.value = e, !0)
            }
            valueChanged(e, t) {
                this.setInputValue(e)
            }
            focusedChanged(e, t) {
                return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    e !== t && (e ? (this.isSelectedOperable = !0, this.input.focus()) : (this.isSelectedOperable = !1, this.selected = !1, this.input.blur(), yield Object(a.m)(5), this.setValue(this.value)))
                }))
            }
            isInputSelected() {
                var e;
                return (null === (e = window.getSelection()) || void 0 === e ? void 0 : e.toString()) === this.getInputValue()
            }
            selectedChanged(e, t) {
                if (e !== t)
                    if (e) {
                        if (!this.isInputSelected()) {
                            this.input.select();
                            "mac" === a.e() && this.input.dispatchEvent(new Event("select"))
                        }
                    } else this.isInputSelected() && ("forward" === this.input.selectionDirection || "none" === this.input.selectionDirection ? (this.input.selectionStart = 0, this.input.selectionEnd = 0) : (this.input.selectionStart = this.input.value.length, this.input.selectionEnd = this.input.value.length))
            }
        };
        Object(i.__decorate)([Object(r.bindable)({
            mode: r.BindingMode.twoWay
        }), Object(i.__metadata)("design:type", String)], g.prototype, "value", void 0), Object(i.__decorate)([Object(r.bindable)({
            mode: r.BindingMode.twoWay
        }), Object(i.__metadata)("design:type", Boolean)], g.prototype, "focused", void 0), Object(i.__decorate)([Object(r.bindable)({
            mode: r.BindingMode.twoWay
        }), Object(i.__metadata)("design:type", Boolean)], g.prototype, "selected", void 0), g = Object(i.__decorate)([a.i ? Object(r.customElement)({
            name: "ua-input-text",
            template: p
        }) : Object(r.customElement)(p), Object(i.__metadata)("design:paramtypes", [HTMLElement, h.a, d.a])], g)
    }).call(this, "/")
});
