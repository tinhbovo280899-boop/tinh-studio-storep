// Extracted webpack module 54. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return s
    }));
    var i = n(8),
        r = n(19);
    class s extends i.b {
        constructor(e, t, n) {
            super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.validateWheelEvent = (e, t) => (t.state.id = "validateWheelEvent", e.preventDefault(), (this.disabled || this.dragging || "wheel" !== e.type) && t.state.action.push("EXIT"), t.state), this.onMouseOver = (e, {
                state: t
            }) => (t.id = "onMouseOver", t), this.onMouseOut = (e, {
                state: t
            }) => (t.id = "onMouseOut", t), this.onDownOrMoveEvent = (e, {
                state: t
            }) => {
                if (t.id = "onDownOrMoveEvent", this.shouldMiddlewareChainContinue(t)) {
                    this.dragging = !0;
                    const {
                        hasMoved: n,
                        trackerState: i
                    } = this.createInteraction({
                        event: e
                    });
                    n && (t.value = this.computeValueFromInteraction({
                        trackerState: i
                    }))
                }
                return t
            }, this.onUpEvent = (e, {
                state: t
            }) => (t.id = "onUpEvent", this.shouldMiddlewareChainContinue(t) && (this.createInteraction({
                event: e
            }), this.dragging = !1), t), this.addMoveEventListener = (e, {
                state: t
            }) => {
                t.id = "addMoveEventListener";
                const n = [this.validateEvent],
                    i = this.shouldMiddlewareChainContinue(t);
                return i && n.push(this.onDownOrMoveEvent, this.changeUANetInteraction), n.push(this.tryInteractionCallback), i && n.push(this.updateMiddlewareEvent, this.tryInteractionCallback), this.generateMoveEventListener({
                    event: e,
                    middleware: n,
                    target: window
                }), t
            }, this.addUpEventListener = (e, {
                state: t
            }) => {
                t.id = "addUpEventListener";
                const n = [this.validateEvent],
                    i = this.shouldMiddlewareChainContinue(t);
                return i && n.push(this.onUpEvent, this.changeUANetInteraction, this.endUANetInteraction), n.push(this.tryInteractionCallback), i && n.push(this.updateMiddlewareEvent, this.tryInteractionCallback), n.push(this.removeMoveAndUpListener), this.generateUpEventListener({
                    event: e,
                    middleware: n,
                    target: window
                }), t
            }, this.onMouseWheelStart = (e, {
                state: t
            }) => (t.type = "wheelstart", t.id = "onMouseWheelStart", this.shouldMiddlewareChainContinue(t) && (this.scrolling ? t.action.push("NO_OP") : (this.scrolling = !0, t.action.push("START", "CHANGE"))), t), this.tryWheelStartInteractionCallback = (e, t) => (t.state.type = "wheelstart", t.state.id = "tryWheelStartInteractionCallback", this.includesAction({
                action: "START",
                state: t.state
            }) ? this.tryInteractionCallback(e, t) : t.state), this.onMouseWheel = (e, {
                state: t
            }) => {
                if (t.type = "wheel", t.id = "onMouseWheel", this.shouldMiddlewareChainContinue(t))
                    if (this.scrolling) {
                        const n = this.createInteraction({
                            event: e
                        });
                        n.hasMoved && (t.value = this.computeValueFromInteraction({
                            trackerState: n.trackerState
                        })), t.action.push("CHANGE")
                    } else t.action.push("NO_OP");
                return t
            }, this.fireWheelEndChain = (e, t) => (t.state.id = "fireWheelEndChain", this.wheelDebouncer.fn().then(() => this.eventListeners.wheelend(e)).catch(() => {}), t.state), this.onMouseWheelEnd = (e, {
                state: t
            }) => (t.type = "wheelend", t.id = "onMouseWheelEnd", this.shouldMiddlewareChainContinue(t) && (this.scrolling ? t.action.push("CHANGE", "END") : t.action.push("EXIT"), this.scrolling = !1), t), this.wheelDebouncer = Object(r.a)(() => {}, 200)
        }
        attaching() {
            const e = [this.validateEvent, this.revertUANetInteraction, this.defaultUANetInteraction, this.addMoveEventListener, this.addUpEventListener, this.calculateDOMDependentProperties, this.onDownOrMoveEvent, this.startUANetInteraction, this.changeUANetInteraction, this.tryInteractionCallback, this.updateMiddlewareEvent, this.tryInteractionCallback];
            this.eventListeners.mouseover = this.createEventListenerMiddleware({
                middleware: [this.onMouseOver, this.tryInteractionCallback]
            }), this.eventListeners.mouseout = this.createEventListenerMiddleware({
                middleware: [this.onMouseOut, this.tryInteractionCallback]
            }), this.eventListeners.wheel = this.createEventListenerMiddleware({
                middleware: [this.validateWheelEvent, this.onMouseWheelStart, this.tryWheelStartInteractionCallback, this.onMouseWheel, this.tryInteractionCallback, this.fireWheelEndChain]
            }), this.eventListeners.wheelend = this.createEventListenerMiddleware({
                middleware: [this.onMouseWheelEnd, this.tryInteractionCallback]
            }), this.eventListeners.dblclick = this.createEventListenerMiddleware({
                middleware: [this.tryInteractionCallback]
            }), this.generateDownEventListener({
                middleware: e,
                target: this.element
            }), this.element.addEventListener("mouseover", this.eventListeners.mouseover), this.element.addEventListener("mouseout", this.eventListeners.mouseout), this.element.addEventListener("wheel", this.eventListeners.wheel), this.element.addEventListener("dblclick", this.eventListeners.dblclick)
        }
        detaching() {
            this.removeDownEventListener({
                target: this.element
            }), this.element.removeEventListener("mouseover", this.eventListeners.mouseover), this.element.removeEventListener("mouseout", this.eventListeners.mouseout), this.element.removeEventListener("wheel", this.eventListeners.wheel), this.element.removeEventListener("dblclick", this.eventListeners.dblclick)
        }
    }
});
