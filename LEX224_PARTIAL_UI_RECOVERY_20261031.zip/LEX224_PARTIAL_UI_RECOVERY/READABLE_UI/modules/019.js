// Extracted webpack module 19. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";

    function i(e, t, n = !1) {
        const i = {
            fn: function(r = t, ...s) {
                var o;
                return null === (o = i.reject) || void 0 === o || o.call(i, "Debounced"), new Promise((t, o) => {
                    var a;
                    const c = this,
                        l = n && !i.timeout;
                    if (i.reject = e => (i.timeout && clearTimeout(i.timeout), o(e)), i.resolve = n => {
                            i.timeout && clearTimeout(i.timeout);
                            const r = e.apply(c, s);
                            return t(null != n ? n : r)
                        }, l) return null === (a = i.resolve) || void 0 === a ? void 0 : a.call(i);
                    clearTimeout(i.timeout), i.timeout = setTimeout(() => {
                        var e;
                        if (i.timeout = null, !n) return null === (e = i.resolve) || void 0 === e ? void 0 : e.call(i)
                    }, r)
                })
            }
        };
        return i
    }
    n.d(t, "a", (function() {
        return i
    }))
});
