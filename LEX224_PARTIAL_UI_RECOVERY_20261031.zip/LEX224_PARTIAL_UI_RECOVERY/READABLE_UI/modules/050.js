// Extracted webpack module 50. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(0),
        r = n(1),
        s = function(e, t) {
            return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN
        },
        o = function(e) {
            var t;
            return 1 === e.length && (t = e, e = function(e, n) {
                return s(t(e), n)
            }), {
                left: function(t, n, i, r) {
                    for (null == i && (i = 0), null == r && (r = t.length); i < r;) {
                        var s = i + r >>> 1;
                        e(t[s], n) < 0 ? i = s + 1 : r = s
                    }
                    return i
                },
                right: function(t, n, i, r) {
                    for (null == i && (i = 0), null == r && (r = t.length); i < r;) {
                        var s = i + r >>> 1;
                        e(t[s], n) > 0 ? r = s : i = s + 1
                    }
                    return i
                }
            }
        };
    var a = o(s);
    a.right, a.left;
    var c = Array.prototype,
        l = (c.slice, c.map, function(e, t, n) {
            e = +e, t = +t, n = (r = arguments.length) < 2 ? (t = e, e = 0, 1) : r < 3 ? 1 : +n;
            for (var i = -1, r = 0 | Math.max(0, Math.ceil((t - e) / n)), s = new Array(r); ++i < r;) s[i] = e + i * n;
            return s
        });
    Math.sqrt(50), Math.sqrt(10), Math.sqrt(2);
    Array.prototype.slice;
    var u = {
        value: function() {}
    };

    function h() {
        for (var e, t = 0, n = arguments.length, i = {}; t < n; ++t) {
            if (!(e = arguments[t] + "") || e in i || /[\s.]/.test(e)) throw new Error("illegal type: " + e);
            i[e] = []
        }
        return new d(i)
    }

    function d(e) {
        this._ = e
    }

    function p(e, t) {
        return e.trim().split(/^|\s+/).map((function(e) {
            var n = "",
                i = e.indexOf(".");
            if (i >= 0 && (n = e.slice(i + 1), e = e.slice(0, i)), e && !t.hasOwnProperty(e)) throw new Error("unknown type: " + e);
            return {
                type: e,
                name: n
            }
        }))
    }

    function f(e, t) {
        for (var n, i = 0, r = e.length; i < r; ++i)
            if ((n = e[i]).name === t) return n.value
    }

    function g(e, t, n) {
        for (var i = 0, r = e.length; i < r; ++i)
            if (e[i].name === t) {
                e[i] = u, e = e.slice(0, i).concat(e.slice(i + 1));
                break
            } return null != n && e.push({
            name: t,
            value: n
        }), e
    }
    d.prototype = h.prototype = {
        constructor: d,
        on: function(e, t) {
            var n, i = this._,
                r = p(e + "", i),
                s = -1,
                o = r.length;
            if (!(arguments.length < 2)) {
                if (null != t && "function" != typeof t) throw new Error("invalid callback: " + t);
                for (; ++s < o;)
                    if (n = (e = r[s]).type) i[n] = g(i[n], e.name, t);
                    else if (null == t)
                    for (n in i) i[n] = g(i[n], e.name, null);
                return this
            }
            for (; ++s < o;)
                if ((n = (e = r[s]).type) && (n = f(i[n], e.name))) return n
        },
        copy: function() {
            var e = {},
                t = this._;
            for (var n in t) e[n] = t[n].slice();
            return new d(e)
        },
        call: function(e, t) {
            if ((n = arguments.length - 2) > 0)
                for (var n, i, r = new Array(n), s = 0; s < n; ++s) r[s] = arguments[s + 2];
            if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
            for (s = 0, n = (i = this._[e]).length; s < n; ++s) i[s].value.apply(t, r)
        },
        apply: function(e, t, n) {
            if (!this._.hasOwnProperty(e)) throw new Error("unknown type: " + e);
            for (var i = this._[e], r = 0, s = i.length; r < s; ++r) i[r].value.apply(t, n)
        }
    };
    var m = h;

    function v() {}
    var b = function(e) {
        return null == e ? v : function() {
            return this.querySelector(e)
        }
    };

    function y() {
        return []
    }
    var w = function(e) {
            return null == e ? y : function() {
                return this.querySelectorAll(e)
            }
        },
        k = function(e) {
            return function() {
                return this.matches(e)
            }
        },
        x = function(e) {
            return new Array(e.length)
        };

    function _(e, t) {
        this.ownerDocument = e.ownerDocument, this.namespaceURI = e.namespaceURI, this._next = null, this._parent = e, this.__data__ = t
    }
    _.prototype = {
        constructor: _,
        appendChild: function(e) {
            return this._parent.insertBefore(e, this._next)
        },
        insertBefore: function(e, t) {
            return this._parent.insertBefore(e, t)
        },
        querySelector: function(e) {
            return this._parent.querySelector(e)
        },
        querySelectorAll: function(e) {
            return this._parent.querySelectorAll(e)
        }
    };

    function S(e, t, n, i, r, s) {
        for (var o, a = 0, c = t.length, l = s.length; a < l; ++a)(o = t[a]) ? (o.__data__ = s[a], i[a] = o) : n[a] = new _(e, s[a]);
        for (; a < c; ++a)(o = t[a]) && (r[a] = o)
    }

    function O(e, t, n, i, r, s, o) {
        var a, c, l, u = {},
            h = t.length,
            d = s.length,
            p = new Array(h);
        for (a = 0; a < h; ++a)(c = t[a]) && (p[a] = l = "$" + o.call(c, c.__data__, a, t), l in u ? r[a] = c : u[l] = c);
        for (a = 0; a < d; ++a)(c = u[l = "$" + o.call(e, s[a], a, s)]) ? (i[a] = c, c.__data__ = s[a], u[l] = null) : n[a] = new _(e, s[a]);
        for (a = 0; a < h; ++a)(c = t[a]) && u[p[a]] === c && (r[a] = c)
    }

    function C(e, t) {
        return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN
    }
    var A = "http://www.w3.org/1999/xhtml",
        T = {
            svg: "http://www.w3.org/2000/svg",
            xhtml: A,
            xlink: "http://www.w3.org/1999/xlink",
            xml: "http://www.w3.org/XML/1998/namespace",
            xmlns: "http://www.w3.org/2000/xmlns/"
        },
        E = function(e) {
            var t = e += "",
                n = t.indexOf(":");
            return n >= 0 && "xmlns" !== (t = e.slice(0, n)) && (e = e.slice(n + 1)), T.hasOwnProperty(t) ? {
                space: T[t],
                local: e
            } : e
        };

    function j(e) {
        return function() {
            this.removeAttribute(e)
        }
    }

    function M(e) {
        return function() {
            this.removeAttributeNS(e.space, e.local)
        }
    }

    function L(e, t) {
        return function() {
            this.setAttribute(e, t)
        }
    }

    function P(e, t) {
        return function() {
            this.setAttributeNS(e.space, e.local, t)
        }
    }

    function R(e, t) {
        return function() {
            var n = t.apply(this, arguments);
            null == n ? this.removeAttribute(e) : this.setAttribute(e, n)
        }
    }

    function I(e, t) {
        return function() {
            var n = t.apply(this, arguments);
            null == n ? this.removeAttributeNS(e.space, e.local) : this.setAttributeNS(e.space, e.local, n)
        }
    }
    var D = function(e) {
        return e.ownerDocument && e.ownerDocument.defaultView || e.document && e || e.defaultView
    };

    function N(e) {
        return function() {
            this.style.removeProperty(e)
        }
    }

    function V(e, t, n) {
        return function() {
            this.style.setProperty(e, t, n)
        }
    }

    function $(e, t, n) {
        return function() {
            var i = t.apply(this, arguments);
            null == i ? this.style.removeProperty(e) : this.style.setProperty(e, i, n)
        }
    }

    function F(e, t) {
        return e.style.getPropertyValue(t) || D(e).getComputedStyle(e, null).getPropertyValue(t)
    }

    function U(e) {
        return function() {
            delete this[e]
        }
    }

    function B(e, t) {
        return function() {
            this[e] = t
        }
    }

    function z(e, t) {
        return function() {
            var n = t.apply(this, arguments);
            null == n ? delete this[e] : this[e] = n
        }
    }

    function H(e) {
        return e.trim().split(/^|\s+/)
    }

    function W(e) {
        return e.classList || new q(e)
    }

    function q(e) {
        this._node = e, this._names = H(e.getAttribute("class") || "")
    }

    function G(e, t) {
        for (var n = W(e), i = -1, r = t.length; ++i < r;) n.add(t[i])
    }

    function K(e, t) {
        for (var n = W(e), i = -1, r = t.length; ++i < r;) n.remove(t[i])
    }

    function Y(e) {
        return function() {
            G(this, e)
        }
    }

    function X(e) {
        return function() {
            K(this, e)
        }
    }

    function J(e, t) {
        return function() {
            (t.apply(this, arguments) ? G : K)(this, e)
        }
    }
    q.prototype = {
        add: function(e) {
            this._names.indexOf(e) < 0 && (this._names.push(e), this._node.setAttribute("class", this._names.join(" ")))
        },
        remove: function(e) {
            var t = this._names.indexOf(e);
            t >= 0 && (this._names.splice(t, 1), this._node.setAttribute("class", this._names.join(" ")))
        },
        contains: function(e) {
            return this._names.indexOf(e) >= 0
        }
    };

    function Q() {
        this.textContent = ""
    }

    function Z(e) {
        return function() {
            this.textContent = e
        }
    }

    function ee(e) {
        return function() {
            var t = e.apply(this, arguments);
            this.textContent = null == t ? "" : t
        }
    }

    function te() {
        this.innerHTML = ""
    }

    function ne(e) {
        return function() {
            this.innerHTML = e
        }
    }

    function ie(e) {
        return function() {
            var t = e.apply(this, arguments);
            this.innerHTML = null == t ? "" : t
        }
    }

    function re() {
        this.nextSibling && this.parentNode.appendChild(this)
    }

    function se() {
        this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild)
    }

    function oe(e) {
        return function() {
            var t = this.ownerDocument,
                n = this.namespaceURI;
            return n === A && t.documentElement.namespaceURI === A ? t.createElement(e) : t.createElementNS(n, e)
        }
    }

    function ae(e) {
        return function() {
            return this.ownerDocument.createElementNS(e.space, e.local)
        }
    }
    var ce = function(e) {
        var t = E(e);
        return (t.local ? ae : oe)(t)
    };

    function le() {
        return null
    }

    function ue() {
        var e = this.parentNode;
        e && e.removeChild(this)
    }

    function he() {
        var e = this.cloneNode(!1),
            t = this.parentNode;
        return t ? t.insertBefore(e, this.nextSibling) : e
    }

    function de() {
        var e = this.cloneNode(!0),
            t = this.parentNode;
        return t ? t.insertBefore(e, this.nextSibling) : e
    }
    var pe = {},
        fe = null;
    "undefined" != typeof document && ("onmouseenter" in document.documentElement || (pe = {
        mouseenter: "mouseover",
        mouseleave: "mouseout"
    }));

    function ge(e, t, n) {
        return e = me(e, t, n),
            function(t) {
                var n = t.relatedTarget;
                n && (n === this || 8 & n.compareDocumentPosition(this)) || e.call(this, t)
            }
    }

    function me(e, t, n) {
        return function(i) {
            var r = fe;
            fe = i;
            try {
                e.call(this, this.__data__, t, n)
            } finally {
                fe = r
            }
        }
    }

    function ve(e) {
        return e.trim().split(/^|\s+/).map((function(e) {
            var t = "",
                n = e.indexOf(".");
            return n >= 0 && (t = e.slice(n + 1), e = e.slice(0, n)), {
                type: e,
                name: t
            }
        }))
    }

    function be(e) {
        return function() {
            var t = this.__on;
            if (t) {
                for (var n, i = 0, r = -1, s = t.length; i < s; ++i) n = t[i], e.type && n.type !== e.type || n.name !== e.name ? t[++r] = n : this.removeEventListener(n.type, n.listener, n.capture);
                ++r ? t.length = r : delete this.__on
            }
        }
    }

    function ye(e, t, n) {
        var i = pe.hasOwnProperty(e.type) ? ge : me;
        return function(r, s, o) {
            var a, c = this.__on,
                l = i(t, s, o);
            if (c)
                for (var u = 0, h = c.length; u < h; ++u)
                    if ((a = c[u]).type === e.type && a.name === e.name) return this.removeEventListener(a.type, a.listener, a.capture), this.addEventListener(a.type, a.listener = l, a.capture = n), void(a.value = t);
            this.addEventListener(e.type, l, n), a = {
                type: e.type,
                name: e.name,
                value: t,
                listener: l,
                capture: n
            }, c ? c.push(a) : this.__on = [a]
        }
    }

    function we(e, t, n) {
        var i = D(e),
            r = i.CustomEvent;
        "function" == typeof r ? r = new r(t, n) : (r = i.document.createEvent("Event"), n ? (r.initEvent(t, n.bubbles, n.cancelable), r.detail = n.detail) : r.initEvent(t, !1, !1)), e.dispatchEvent(r)
    }

    function ke(e, t) {
        return function() {
            return we(this, e, t)
        }
    }

    function xe(e, t) {
        return function() {
            return we(this, e, t.apply(this, arguments))
        }
    }
    var _e = [null];

    function Se(e, t) {
        this._groups = e, this._parents = t
    }

    function Oe() {
        return new Se([
            [document.documentElement]
        ], _e)
    }
    Se.prototype = Oe.prototype = {
        constructor: Se,
        select: function(e) {
            "function" != typeof e && (e = b(e));
            for (var t = this._groups, n = t.length, i = new Array(n), r = 0; r < n; ++r)
                for (var s, o, a = t[r], c = a.length, l = i[r] = new Array(c), u = 0; u < c; ++u)(s = a[u]) && (o = e.call(s, s.__data__, u, a)) && ("__data__" in s && (o.__data__ = s.__data__), l[u] = o);
            return new Se(i, this._parents)
        },
        selectAll: function(e) {
            "function" != typeof e && (e = w(e));
            for (var t = this._groups, n = t.length, i = [], r = [], s = 0; s < n; ++s)
                for (var o, a = t[s], c = a.length, l = 0; l < c; ++l)(o = a[l]) && (i.push(e.call(o, o.__data__, l, a)), r.push(o));
            return new Se(i, r)
        },
        filter: function(e) {
            "function" != typeof e && (e = k(e));
            for (var t = this._groups, n = t.length, i = new Array(n), r = 0; r < n; ++r)
                for (var s, o = t[r], a = o.length, c = i[r] = [], l = 0; l < a; ++l)(s = o[l]) && e.call(s, s.__data__, l, o) && c.push(s);
            return new Se(i, this._parents)
        },
        data: function(e, t) {
            if (!e) return f = new Array(this.size()), u = -1, this.each((function(e) {
                f[++u] = e
            })), f;
            var n, i = t ? O : S,
                r = this._parents,
                s = this._groups;
            "function" != typeof e && (n = e, e = function() {
                return n
            });
            for (var o = s.length, a = new Array(o), c = new Array(o), l = new Array(o), u = 0; u < o; ++u) {
                var h = r[u],
                    d = s[u],
                    p = d.length,
                    f = e.call(h, h && h.__data__, u, r),
                    g = f.length,
                    m = c[u] = new Array(g),
                    v = a[u] = new Array(g);
                i(h, d, m, v, l[u] = new Array(p), f, t);
                for (var b, y, w = 0, k = 0; w < g; ++w)
                    if (b = m[w]) {
                        for (w >= k && (k = w + 1); !(y = v[k]) && ++k < g;);
                        b._next = y || null
                    }
            }
            return (a = new Se(a, r))._enter = c, a._exit = l, a
        },
        enter: function() {
            return new Se(this._enter || this._groups.map(x), this._parents)
        },
        exit: function() {
            return new Se(this._exit || this._groups.map(x), this._parents)
        },
        join: function(e, t, n) {
            var i = this.enter(),
                r = this,
                s = this.exit();
            return i = "function" == typeof e ? e(i) : i.append(e + ""), null != t && (r = t(r)), null == n ? s.remove() : n(s), i && r ? i.merge(r).order() : r
        },
        merge: function(e) {
            for (var t = this._groups, n = e._groups, i = t.length, r = n.length, s = Math.min(i, r), o = new Array(i), a = 0; a < s; ++a)
                for (var c, l = t[a], u = n[a], h = l.length, d = o[a] = new Array(h), p = 0; p < h; ++p)(c = l[p] || u[p]) && (d[p] = c);
            for (; a < i; ++a) o[a] = t[a];
            return new Se(o, this._parents)
        },
        order: function() {
            for (var e = this._groups, t = -1, n = e.length; ++t < n;)
                for (var i, r = e[t], s = r.length - 1, o = r[s]; --s >= 0;)(i = r[s]) && (o && 4 ^ i.compareDocumentPosition(o) && o.parentNode.insertBefore(i, o), o = i);
            return this
        },
        sort: function(e) {
            function t(t, n) {
                return t && n ? e(t.__data__, n.__data__) : !t - !n
            }
            e || (e = C);
            for (var n = this._groups, i = n.length, r = new Array(i), s = 0; s < i; ++s) {
                for (var o, a = n[s], c = a.length, l = r[s] = new Array(c), u = 0; u < c; ++u)(o = a[u]) && (l[u] = o);
                l.sort(t)
            }
            return new Se(r, this._parents).order()
        },
        call: function() {
            var e = arguments[0];
            return arguments[0] = this, e.apply(null, arguments), this
        },
        nodes: function() {
            var e = new Array(this.size()),
                t = -1;
            return this.each((function() {
                e[++t] = this
            })), e
        },
        node: function() {
            for (var e = this._groups, t = 0, n = e.length; t < n; ++t)
                for (var i = e[t], r = 0, s = i.length; r < s; ++r) {
                    var o = i[r];
                    if (o) return o
                }
            return null
        },
        size: function() {
            var e = 0;
            return this.each((function() {
                ++e
            })), e
        },
        empty: function() {
            return !this.node()
        },
        each: function(e) {
            for (var t = this._groups, n = 0, i = t.length; n < i; ++n)
                for (var r, s = t[n], o = 0, a = s.length; o < a; ++o)(r = s[o]) && e.call(r, r.__data__, o, s);
            return this
        },
        attr: function(e, t) {
            var n = E(e);
            if (arguments.length < 2) {
                var i = this.node();
                return n.local ? i.getAttributeNS(n.space, n.local) : i.getAttribute(n)
            }
            return this.each((null == t ? n.local ? M : j : "function" == typeof t ? n.local ? I : R : n.local ? P : L)(n, t))
        },
        style: function(e, t, n) {
            return arguments.length > 1 ? this.each((null == t ? N : "function" == typeof t ? $ : V)(e, t, null == n ? "" : n)) : F(this.node(), e)
        },
        property: function(e, t) {
            return arguments.length > 1 ? this.each((null == t ? U : "function" == typeof t ? z : B)(e, t)) : this.node()[e]
        },
        classed: function(e, t) {
            var n = H(e + "");
            if (arguments.length < 2) {
                for (var i = W(this.node()), r = -1, s = n.length; ++r < s;)
                    if (!i.contains(n[r])) return !1;
                return !0
            }
            return this.each(("function" == typeof t ? J : t ? Y : X)(n, t))
        },
        text: function(e) {
            return arguments.length ? this.each(null == e ? Q : ("function" == typeof e ? ee : Z)(e)) : this.node().textContent
        },
        html: function(e) {
            return arguments.length ? this.each(null == e ? te : ("function" == typeof e ? ie : ne)(e)) : this.node().innerHTML
        },
        raise: function() {
            return this.each(re)
        },
        lower: function() {
            return this.each(se)
        },
        append: function(e) {
            var t = "function" == typeof e ? e : ce(e);
            return this.select((function() {
                return this.appendChild(t.apply(this, arguments))
            }))
        },
        insert: function(e, t) {
            var n = "function" == typeof e ? e : ce(e),
                i = null == t ? le : "function" == typeof t ? t : b(t);
            return this.select((function() {
                return this.insertBefore(n.apply(this, arguments), i.apply(this, arguments) || null)
            }))
        },
        remove: function() {
            return this.each(ue)
        },
        clone: function(e) {
            return this.select(e ? de : he)
        },
        datum: function(e) {
            return arguments.length ? this.property("__data__", e) : this.node().__data__
        },
        on: function(e, t, n) {
            var i, r, s = ve(e + ""),
                o = s.length;
            if (!(arguments.length < 2)) {
                for (a = t ? ye : be, null == n && (n = !1), i = 0; i < o; ++i) this.each(a(s[i], t, n));
                return this
            }
            var a = this.node().__on;
            if (a)
                for (var c, l = 0, u = a.length; l < u; ++l)
                    for (i = 0, c = a[l]; i < o; ++i)
                        if ((r = s[i]).type === c.type && r.name === c.name) return c.value
        },
        dispatch: function(e, t) {
            return this.each(("function" == typeof t ? xe : ke)(e, t))
        }
    };
    var Ce = Oe,
        Ae = function(e) {
            return "string" == typeof e ? new Se([
                [document.querySelector(e)]
            ], [document.documentElement]) : new Se([
                [e]
            ], _e)
        };
    var Te = function(e, t, n) {
        e.prototype = t.prototype = n, n.constructor = e
    };

    function Ee(e, t) {
        var n = Object.create(e.prototype);
        for (var i in t) n[i] = t[i];
        return n
    }

    function je() {}
    var Me = "\\s*([+-]?\\d+)\\s*",
        Le = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)\\s*",
        Pe = "\\s*([+-]?\\d*\\.?\\d+(?:[eE][+-]?\\d+)?)%\\s*",
        Re = /^#([0-9a-f]{3,8})$/,
        Ie = new RegExp("^rgb\\(" + [Me, Me, Me] + "\\)$"),
        De = new RegExp("^rgb\\(" + [Pe, Pe, Pe] + "\\)$"),
        Ne = new RegExp("^rgba\\(" + [Me, Me, Me, Le] + "\\)$"),
        Ve = new RegExp("^rgba\\(" + [Pe, Pe, Pe, Le] + "\\)$"),
        $e = new RegExp("^hsl\\(" + [Le, Pe, Pe] + "\\)$"),
        Fe = new RegExp("^hsla\\(" + [Le, Pe, Pe, Le] + "\\)$"),
        Ue = {
            aliceblue: 15792383,
            antiquewhite: 16444375,
            aqua: 65535,
            aquamarine: 8388564,
            azure: 15794175,
            beige: 16119260,
            bisque: 16770244,
            black: 0,
            blanchedalmond: 16772045,
            blue: 255,
            blueviolet: 9055202,
            brown: 10824234,
            burlywood: 14596231,
            cadetblue: 6266528,
            chartreuse: 8388352,
            chocolate: 13789470,
            coral: 16744272,
            cornflowerblue: 6591981,
            cornsilk: 16775388,
            crimson: 14423100,
            cyan: 65535,
            darkblue: 139,
            darkcyan: 35723,
            darkgoldenrod: 12092939,
            darkgray: 11119017,
            darkgreen: 25600,
            darkgrey: 11119017,
            darkkhaki: 12433259,
            darkmagenta: 9109643,
            darkolivegreen: 5597999,
            darkorange: 16747520,
            darkorchid: 10040012,
            darkred: 9109504,
            darksalmon: 15308410,
            darkseagreen: 9419919,
            darkslateblue: 4734347,
            darkslategray: 3100495,
            darkslategrey: 3100495,
            darkturquoise: 52945,
            darkviolet: 9699539,
            deeppink: 16716947,
            deepskyblue: 49151,
            dimgray: 6908265,
            dimgrey: 6908265,
            dodgerblue: 2003199,
            firebrick: 11674146,
            floralwhite: 16775920,
            forestgreen: 2263842,
            fuchsia: 16711935,
            gainsboro: 14474460,
            ghostwhite: 16316671,
            gold: 16766720,
            goldenrod: 14329120,
            gray: 8421504,
            green: 32768,
            greenyellow: 11403055,
            grey: 8421504,
            honeydew: 15794160,
            hotpink: 16738740,
            indianred: 13458524,
            indigo: 4915330,
            ivory: 16777200,
            khaki: 15787660,
            lavender: 15132410,
            lavenderblush: 16773365,
            lawngreen: 8190976,
            lemonchiffon: 16775885,
            lightblue: 11393254,
            lightcoral: 15761536,
            lightcyan: 14745599,
            lightgoldenrodyellow: 16448210,
            lightgray: 13882323,
            lightgreen: 9498256,
            lightgrey: 13882323,
            lightpink: 16758465,
            lightsalmon: 16752762,
            lightseagreen: 2142890,
            lightskyblue: 8900346,
            lightslategray: 7833753,
            lightslategrey: 7833753,
            lightsteelblue: 11584734,
            lightyellow: 16777184,
            lime: 65280,
            limegreen: 3329330,
            linen: 16445670,
            magenta: 16711935,
            maroon: 8388608,
            mediumaquamarine: 6737322,
            mediumblue: 205,
            mediumorchid: 12211667,
            mediumpurple: 9662683,
            mediumseagreen: 3978097,
            mediumslateblue: 8087790,
            mediumspringgreen: 64154,
            mediumturquoise: 4772300,
            mediumvioletred: 13047173,
            midnightblue: 1644912,
            mintcream: 16121850,
            mistyrose: 16770273,
            moccasin: 16770229,
            navajowhite: 16768685,
            navy: 128,
            oldlace: 16643558,
            olive: 8421376,
            olivedrab: 7048739,
            orange: 16753920,
            orangered: 16729344,
            orchid: 14315734,
            palegoldenrod: 15657130,
            palegreen: 10025880,
            paleturquoise: 11529966,
            palevioletred: 14381203,
            papayawhip: 16773077,
            peachpuff: 16767673,
            peru: 13468991,
            pink: 16761035,
            plum: 14524637,
            powderblue: 11591910,
            purple: 8388736,
            rebeccapurple: 6697881,
            red: 16711680,
            rosybrown: 12357519,
            royalblue: 4286945,
            saddlebrown: 9127187,
            salmon: 16416882,
            sandybrown: 16032864,
            seagreen: 3050327,
            seashell: 16774638,
            sienna: 10506797,
            silver: 12632256,
            skyblue: 8900331,
            slateblue: 6970061,
            slategray: 7372944,
            slategrey: 7372944,
            snow: 16775930,
            springgreen: 65407,
            steelblue: 4620980,
            tan: 13808780,
            teal: 32896,
            thistle: 14204888,
            tomato: 16737095,
            turquoise: 4251856,
            violet: 15631086,
            wheat: 16113331,
            white: 16777215,
            whitesmoke: 16119285,
            yellow: 16776960,
            yellowgreen: 10145074
        };

    function Be() {
        return this.rgb().formatHex()
    }

    function ze() {
        return this.rgb().formatRgb()
    }

    function He(e) {
        var t, n;
        return e = (e + "").trim().toLowerCase(), (t = Re.exec(e)) ? (n = t[1].length, t = parseInt(t[1], 16), 6 === n ? We(t) : 3 === n ? new Ye(t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | 240 & t, (15 & t) << 4 | 15 & t, 1) : 8 === n ? qe(t >> 24 & 255, t >> 16 & 255, t >> 8 & 255, (255 & t) / 255) : 4 === n ? qe(t >> 12 & 15 | t >> 8 & 240, t >> 8 & 15 | t >> 4 & 240, t >> 4 & 15 | 240 & t, ((15 & t) << 4 | 15 & t) / 255) : null) : (t = Ie.exec(e)) ? new Ye(t[1], t[2], t[3], 1) : (t = De.exec(e)) ? new Ye(255 * t[1] / 100, 255 * t[2] / 100, 255 * t[3] / 100, 1) : (t = Ne.exec(e)) ? qe(t[1], t[2], t[3], t[4]) : (t = Ve.exec(e)) ? qe(255 * t[1] / 100, 255 * t[2] / 100, 255 * t[3] / 100, t[4]) : (t = $e.exec(e)) ? Ze(t[1], t[2] / 100, t[3] / 100, 1) : (t = Fe.exec(e)) ? Ze(t[1], t[2] / 100, t[3] / 100, t[4]) : Ue.hasOwnProperty(e) ? We(Ue[e]) : "transparent" === e ? new Ye(NaN, NaN, NaN, 0) : null
    }

    function We(e) {
        return new Ye(e >> 16 & 255, e >> 8 & 255, 255 & e, 1)
    }

    function qe(e, t, n, i) {
        return i <= 0 && (e = t = n = NaN), new Ye(e, t, n, i)
    }

    function Ge(e) {
        return e instanceof je || (e = He(e)), e ? new Ye((e = e.rgb()).r, e.g, e.b, e.opacity) : new Ye
    }

    function Ke(e, t, n, i) {
        return 1 === arguments.length ? Ge(e) : new Ye(e, t, n, null == i ? 1 : i)
    }

    function Ye(e, t, n, i) {
        this.r = +e, this.g = +t, this.b = +n, this.opacity = +i
    }

    function Xe() {
        return "#" + Qe(this.r) + Qe(this.g) + Qe(this.b)
    }

    function Je() {
        var e = this.opacity;
        return (1 === (e = isNaN(e) ? 1 : Math.max(0, Math.min(1, e))) ? "rgb(" : "rgba(") + Math.max(0, Math.min(255, Math.round(this.r) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.g) || 0)) + ", " + Math.max(0, Math.min(255, Math.round(this.b) || 0)) + (1 === e ? ")" : ", " + e + ")")
    }

    function Qe(e) {
        return ((e = Math.max(0, Math.min(255, Math.round(e) || 0))) < 16 ? "0" : "") + e.toString(16)
    }

    function Ze(e, t, n, i) {
        return i <= 0 ? e = t = n = NaN : n <= 0 || n >= 1 ? e = t = NaN : t <= 0 && (e = NaN), new tt(e, t, n, i)
    }

    function et(e) {
        if (e instanceof tt) return new tt(e.h, e.s, e.l, e.opacity);
        if (e instanceof je || (e = He(e)), !e) return new tt;
        if (e instanceof tt) return e;
        var t = (e = e.rgb()).r / 255,
            n = e.g / 255,
            i = e.b / 255,
            r = Math.min(t, n, i),
            s = Math.max(t, n, i),
            o = NaN,
            a = s - r,
            c = (s + r) / 2;
        return a ? (o = t === s ? (n - i) / a + 6 * (n < i) : n === s ? (i - t) / a + 2 : (t - n) / a + 4, a /= c < .5 ? s + r : 2 - s - r, o *= 60) : a = c > 0 && c < 1 ? 0 : o, new tt(o, a, c, e.opacity)
    }

    function tt(e, t, n, i) {
        this.h = +e, this.s = +t, this.l = +n, this.opacity = +i
    }

    function nt(e, t, n) {
        return 255 * (e < 60 ? t + (n - t) * e / 60 : e < 180 ? n : e < 240 ? t + (n - t) * (240 - e) / 60 : t)
    }

    function it(e, t, n, i, r) {
        var s = e * e,
            o = s * e;
        return ((1 - 3 * e + 3 * s - o) * t + (4 - 6 * s + 3 * o) * n + (1 + 3 * e + 3 * s - 3 * o) * i + o * r) / 6
    }
    Te(je, He, {
        copy: function(e) {
            return Object.assign(new this.constructor, this, e)
        },
        displayable: function() {
            return this.rgb().displayable()
        },
        hex: Be,
        formatHex: Be,
        formatHsl: function() {
            return et(this).formatHsl()
        },
        formatRgb: ze,
        toString: ze
    }), Te(Ye, Ke, Ee(je, {
        brighter: function(e) {
            return e = null == e ? 1 / .7 : Math.pow(1 / .7, e), new Ye(this.r * e, this.g * e, this.b * e, this.opacity)
        },
        darker: function(e) {
            return e = null == e ? .7 : Math.pow(.7, e), new Ye(this.r * e, this.g * e, this.b * e, this.opacity)
        },
        rgb: function() {
            return this
        },
        displayable: function() {
            return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1
        },
        hex: Xe,
        formatHex: Xe,
        formatRgb: Je,
        toString: Je
    })), Te(tt, (function(e, t, n, i) {
        return 1 === arguments.length ? et(e) : new tt(e, t, n, null == i ? 1 : i)
    }), Ee(je, {
        brighter: function(e) {
            return e = null == e ? 1 / .7 : Math.pow(1 / .7, e), new tt(this.h, this.s, this.l * e, this.opacity)
        },
        darker: function(e) {
            return e = null == e ? .7 : Math.pow(.7, e), new tt(this.h, this.s, this.l * e, this.opacity)
        },
        rgb: function() {
            var e = this.h % 360 + 360 * (this.h < 0),
                t = isNaN(e) || isNaN(this.s) ? 0 : this.s,
                n = this.l,
                i = n + (n < .5 ? n : 1 - n) * t,
                r = 2 * n - i;
            return new Ye(nt(e >= 240 ? e - 240 : e + 120, r, i), nt(e, r, i), nt(e < 120 ? e + 240 : e - 120, r, i), this.opacity)
        },
        displayable: function() {
            return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1
        },
        formatHsl: function() {
            var e = this.opacity;
            return (1 === (e = isNaN(e) ? 1 : Math.max(0, Math.min(1, e))) ? "hsl(" : "hsla(") + (this.h || 0) + ", " + 100 * (this.s || 0) + "%, " + 100 * (this.l || 0) + "%" + (1 === e ? ")" : ", " + e + ")")
        }
    }));
    var rt = function(e) {
        return function() {
            return e
        }
    };

    function st(e, t) {
        return function(n) {
            return e + n * t
        }
    }

    function ot(e) {
        return 1 == (e = +e) ? at : function(t, n) {
            return n - t ? function(e, t, n) {
                return e = Math.pow(e, n), t = Math.pow(t, n) - e, n = 1 / n,
                    function(i) {
                        return Math.pow(e + i * t, n)
                    }
            }(t, n, e) : rt(isNaN(t) ? n : t)
        }
    }

    function at(e, t) {
        var n = t - e;
        return n ? st(e, n) : rt(isNaN(e) ? t : e)
    }
    var ct = function e(t) {
        var n = ot(t);

        function i(e, t) {
            var i = n((e = Ke(e)).r, (t = Ke(t)).r),
                r = n(e.g, t.g),
                s = n(e.b, t.b),
                o = at(e.opacity, t.opacity);
            return function(t) {
                return e.r = i(t), e.g = r(t), e.b = s(t), e.opacity = o(t), e + ""
            }
        }
        return i.gamma = e, i
    }(1);

    function lt(e) {
        return function(t) {
            var n, i, r = t.length,
                s = new Array(r),
                o = new Array(r),
                a = new Array(r);
            for (n = 0; n < r; ++n) i = Ke(t[n]), s[n] = i.r || 0, o[n] = i.g || 0, a[n] = i.b || 0;
            return s = e(s), o = e(o), a = e(a), i.opacity = 1,
                function(e) {
                    return i.r = s(e), i.g = o(e), i.b = a(e), i + ""
                }
        }
    }
    lt((function(e) {
        var t = e.length - 1;
        return function(n) {
            var i = n <= 0 ? n = 0 : n >= 1 ? (n = 1, t - 1) : Math.floor(n * t),
                r = e[i],
                s = e[i + 1],
                o = i > 0 ? e[i - 1] : 2 * r - s,
                a = i < t - 1 ? e[i + 2] : 2 * s - r;
            return it((n - i / t) * t, o, r, s, a)
        }
    })), lt((function(e) {
        var t = e.length;
        return function(n) {
            var i = Math.floor(((n %= 1) < 0 ? ++n : n) * t),
                r = e[(i + t - 1) % t],
                s = e[i % t],
                o = e[(i + 1) % t],
                a = e[(i + 2) % t];
            return it((n - i / t) * t, r, s, o, a)
        }
    }));
    var ut = function(e, t) {
        t || (t = []);
        var n, i = e ? Math.min(t.length, e.length) : 0,
            r = t.slice();
        return function(s) {
            for (n = 0; n < i; ++n) r[n] = e[n] * (1 - s) + t[n] * s;
            return r
        }
    };

    function ht(e) {
        return ArrayBuffer.isView(e) && !(e instanceof DataView)
    }

    function dt(e, t) {
        var n, i = t ? t.length : 0,
            r = e ? Math.min(i, e.length) : 0,
            s = new Array(r),
            o = new Array(i);
        for (n = 0; n < r; ++n) s[n] = kt(e[n], t[n]);
        for (; n < i; ++n) o[n] = t[n];
        return function(e) {
            for (n = 0; n < r; ++n) o[n] = s[n](e);
            return o
        }
    }
    var pt = function(e, t) {
            var n = new Date;
            return e = +e, t = +t,
                function(i) {
                    return n.setTime(e * (1 - i) + t * i), n
                }
        },
        ft = function(e, t) {
            return e = +e, t = +t,
                function(n) {
                    return e * (1 - n) + t * n
                }
        },
        gt = function(e, t) {
            var n, i = {},
                r = {};
            for (n in null !== e && "object" == typeof e || (e = {}), null !== t && "object" == typeof t || (t = {}), t) n in e ? i[n] = kt(e[n], t[n]) : r[n] = t[n];
            return function(e) {
                for (n in i) r[n] = i[n](e);
                return r
            }
        },
        mt = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g,
        vt = new RegExp(mt.source, "g");
    var bt, yt, wt = function(e, t) {
            var n, i, r, s = mt.lastIndex = vt.lastIndex = 0,
                o = -1,
                a = [],
                c = [];
            for (e += "", t += "";
                (n = mt.exec(e)) && (i = vt.exec(t));)(r = i.index) > s && (r = t.slice(s, r), a[o] ? a[o] += r : a[++o] = r), (n = n[0]) === (i = i[0]) ? a[o] ? a[o] += i : a[++o] = i : (a[++o] = null, c.push({
                i: o,
                x: ft(n, i)
            })), s = vt.lastIndex;
            return s < t.length && (r = t.slice(s), a[o] ? a[o] += r : a[++o] = r), a.length < 2 ? c[0] ? function(e) {
                return function(t) {
                    return e(t) + ""
                }
            }(c[0].x) : function(e) {
                return function() {
                    return e
                }
            }(t) : (t = c.length, function(e) {
                for (var n, i = 0; i < t; ++i) a[(n = c[i]).i] = n.x(e);
                return a.join("")
            })
        },
        kt = function(e, t) {
            var n, i = typeof t;
            return null == t || "boolean" === i ? rt(t) : ("number" === i ? ft : "string" === i ? (n = He(t)) ? (t = n, ct) : wt : t instanceof He ? ct : t instanceof Date ? pt : ht(t) ? ut : Array.isArray(t) ? dt : "function" != typeof t.valueOf && "function" != typeof t.toString || isNaN(t) ? gt : ft)(e, t)
        },
        xt = function() {
            for (var e, t = fe; e = t.sourceEvent;) t = e;
            return t
        },
        _t = function(e, t) {
            var n = e.ownerSVGElement || e;
            if (n.createSVGPoint) {
                var i = n.createSVGPoint();
                return i.x = t.clientX, i.y = t.clientY, [(i = i.matrixTransform(e.getScreenCTM().inverse())).x, i.y]
            }
            var r = e.getBoundingClientRect();
            return [t.clientX - r.left - e.clientLeft, t.clientY - r.top - e.clientTop]
        },
        St = function(e) {
            var t = xt();
            return t.changedTouches && (t = t.changedTouches[0]), _t(e, t)
        },
        Ot = 0,
        Ct = 0,
        At = 0,
        Tt = 0,
        Et = 0,
        jt = 0,
        Mt = "object" == typeof performance && performance.now ? performance : Date,
        Lt = "object" == typeof window && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function(e) {
            setTimeout(e, 17)
        };

    function Pt() {
        return Et || (Lt(Rt), Et = Mt.now() + jt)
    }

    function Rt() {
        Et = 0
    }

    function It() {
        this._call = this._time = this._next = null
    }

    function Dt(e, t, n) {
        var i = new It;
        return i.restart(e, t, n), i
    }

    function Nt() {
        Et = (Tt = Mt.now()) + jt, Ot = Ct = 0;
        try {
            ! function() {
                Pt(), ++Ot;
                for (var e, t = bt; t;)(e = Et - t._time) >= 0 && t._call.call(null, e), t = t._next;
                --Ot
            }()
        } finally {
            Ot = 0,
                function() {
                    var e, t, n = bt,
                        i = 1 / 0;
                    for (; n;) n._call ? (i > n._time && (i = n._time), e = n, n = n._next) : (t = n._next, n._next = null, n = e ? e._next = t : bt = t);
                    yt = e, $t(i)
                }(), Et = 0
        }
    }

    function Vt() {
        var e = Mt.now(),
            t = e - Tt;
        t > 1e3 && (jt -= t, Tt = e)
    }

    function $t(e) {
        Ot || (Ct && (Ct = clearTimeout(Ct)), e - Et > 24 ? (e < 1 / 0 && (Ct = setTimeout(Nt, e - Mt.now() - jt)), At && (At = clearInterval(At))) : (At || (Tt = Mt.now(), At = setInterval(Vt, 1e3)), Ot = 1, Lt(Nt)))
    }
    It.prototype = Dt.prototype = {
        constructor: It,
        restart: function(e, t, n) {
            if ("function" != typeof e) throw new TypeError("callback is not a function");
            n = (null == n ? Pt() : +n) + (null == t ? 0 : +t), this._next || yt === this || (yt ? yt._next = this : bt = this, yt = this), this._call = e, this._time = n, $t()
        },
        stop: function() {
            this._call && (this._call = null, this._time = 1 / 0, $t())
        }
    };
    var Ft = function(e, t, n) {
            var i = new It;
            return t = null == t ? 0 : +t, i.restart((function(n) {
                i.stop(), e(n + t)
            }), t, n), i
        },
        Ut = m("start", "end", "cancel", "interrupt"),
        Bt = [],
        zt = function(e, t, n, i, r, s) {
            var o = e.__transition;
            if (o) {
                if (n in o) return
            } else e.__transition = {};
            ! function(e, t, n) {
                var i, r = e.__transition;

                function s(c) {
                    var l, u, h, d;
                    if (1 !== n.state) return a();
                    for (l in r)
                        if ((d = r[l]).name === n.name) {
                            if (3 === d.state) return Ft(s);
                            4 === d.state ? (d.state = 6, d.timer.stop(), d.on.call("interrupt", e, e.__data__, d.index, d.group), delete r[l]) : +l < t && (d.state = 6, d.timer.stop(), d.on.call("cancel", e, e.__data__, d.index, d.group), delete r[l])
                        } if (Ft((function() {
                            3 === n.state && (n.state = 4, n.timer.restart(o, n.delay, n.time), o(c))
                        })), n.state = 2, n.on.call("start", e, e.__data__, n.index, n.group), 2 === n.state) {
                        for (n.state = 3, i = new Array(h = n.tween.length), l = 0, u = -1; l < h; ++l)(d = n.tween[l].value.call(e, e.__data__, n.index, n.group)) && (i[++u] = d);
                        i.length = u + 1
                    }
                }

                function o(t) {
                    for (var r = t < n.duration ? n.ease.call(null, t / n.duration) : (n.timer.restart(a), n.state = 5, 1), s = -1, o = i.length; ++s < o;) i[s].call(e, r);
                    5 === n.state && (n.on.call("end", e, e.__data__, n.index, n.group), a())
                }

                function a() {
                    for (var i in n.state = 6, n.timer.stop(), delete r[t], r) return;
                    delete e.__transition
                }
                r[t] = n, n.timer = Dt((function(e) {
                    n.state = 1, n.timer.restart(s, n.delay, n.time), n.delay <= e && s(e - n.delay)
                }), 0, n.time)
            }(e, n, {
                name: t,
                index: i,
                group: r,
                on: Ut,
                tween: Bt,
                time: s.time,
                delay: s.delay,
                duration: s.duration,
                ease: s.ease,
                timer: null,
                state: 0
            })
        };

    function Ht(e, t) {
        var n = qt(e, t);
        if (n.state > 0) throw new Error("too late; already scheduled");
        return n
    }

    function Wt(e, t) {
        var n = qt(e, t);
        if (n.state > 3) throw new Error("too late; already running");
        return n
    }

    function qt(e, t) {
        var n = e.__transition;
        if (!n || !(n = n[t])) throw new Error("transition not found");
        return n
    }
    var Gt, Kt, Yt, Xt, Jt = function(e, t) {
            var n, i, r, s = e.__transition,
                o = !0;
            if (s) {
                for (r in t = null == t ? null : t + "", s)(n = s[r]).name === t ? (i = n.state > 2 && n.state < 5, n.state = 6, n.timer.stop(), n.on.call(i ? "interrupt" : "cancel", e, e.__data__, n.index, n.group), delete s[r]) : o = !1;
                o && delete e.__transition
            }
        },
        Qt = 180 / Math.PI,
        Zt = {
            translateX: 0,
            translateY: 0,
            rotate: 0,
            skewX: 0,
            scaleX: 1,
            scaleY: 1
        },
        en = function(e, t, n, i, r, s) {
            var o, a, c;
            return (o = Math.sqrt(e * e + t * t)) && (e /= o, t /= o), (c = e * n + t * i) && (n -= e * c, i -= t * c), (a = Math.sqrt(n * n + i * i)) && (n /= a, i /= a, c /= a), e * i < t * n && (e = -e, t = -t, c = -c, o = -o), {
                translateX: r,
                translateY: s,
                rotate: Math.atan2(t, e) * Qt,
                skewX: Math.atan(c) * Qt,
                scaleX: o,
                scaleY: a
            }
        };

    function tn(e, t, n, i) {
        function r(e) {
            return e.length ? e.pop() + " " : ""
        }
        return function(s, o) {
            var a = [],
                c = [];
            return s = e(s), o = e(o),
                function(e, i, r, s, o, a) {
                    if (e !== r || i !== s) {
                        var c = o.push("translate(", null, t, null, n);
                        a.push({
                            i: c - 4,
                            x: ft(e, r)
                        }, {
                            i: c - 2,
                            x: ft(i, s)
                        })
                    } else(r || s) && o.push("translate(" + r + t + s + n)
                }(s.translateX, s.translateY, o.translateX, o.translateY, a, c),
                function(e, t, n, s) {
                    e !== t ? (e - t > 180 ? t += 360 : t - e > 180 && (e += 360), s.push({
                        i: n.push(r(n) + "rotate(", null, i) - 2,
                        x: ft(e, t)
                    })) : t && n.push(r(n) + "rotate(" + t + i)
                }(s.rotate, o.rotate, a, c),
                function(e, t, n, s) {
                    e !== t ? s.push({
                        i: n.push(r(n) + "skewX(", null, i) - 2,
                        x: ft(e, t)
                    }) : t && n.push(r(n) + "skewX(" + t + i)
                }(s.skewX, o.skewX, a, c),
                function(e, t, n, i, s, o) {
                    if (e !== n || t !== i) {
                        var a = s.push(r(s) + "scale(", null, ",", null, ")");
                        o.push({
                            i: a - 4,
                            x: ft(e, n)
                        }, {
                            i: a - 2,
                            x: ft(t, i)
                        })
                    } else 1 === n && 1 === i || s.push(r(s) + "scale(" + n + "," + i + ")")
                }(s.scaleX, s.scaleY, o.scaleX, o.scaleY, a, c), s = o = null,
                function(e) {
                    for (var t, n = -1, i = c.length; ++n < i;) a[(t = c[n]).i] = t.x(e);
                    return a.join("")
                }
        }
    }
    var nn = tn((function(e) {
            return "none" === e ? Zt : (Gt || (Gt = document.createElement("DIV"), Kt = document.documentElement, Yt = document.defaultView), Gt.style.transform = e, e = Yt.getComputedStyle(Kt.appendChild(Gt), null).getPropertyValue("transform"), Kt.removeChild(Gt), e = e.slice(7, -1).split(","), en(+e[0], +e[1], +e[2], +e[3], +e[4], +e[5]))
        }), "px, ", "px)", "deg)"),
        rn = tn((function(e) {
            return null == e ? Zt : (Xt || (Xt = document.createElementNS("http://www.w3.org/2000/svg", "g")), Xt.setAttribute("transform", e), (e = Xt.transform.baseVal.consolidate()) ? (e = e.matrix, en(e.a, e.b, e.c, e.d, e.e, e.f)) : Zt)
        }), ", ", ")", ")");

    function sn(e, t) {
        var n, i;
        return function() {
            var r = Wt(this, e),
                s = r.tween;
            if (s !== n)
                for (var o = 0, a = (i = n = s).length; o < a; ++o)
                    if (i[o].name === t) {
                        (i = i.slice()).splice(o, 1);
                        break
                    } r.tween = i
        }
    }

    function on(e, t, n) {
        var i, r;
        if ("function" != typeof n) throw new Error;
        return function() {
            var s = Wt(this, e),
                o = s.tween;
            if (o !== i) {
                r = (i = o).slice();
                for (var a = {
                        name: t,
                        value: n
                    }, c = 0, l = r.length; c < l; ++c)
                    if (r[c].name === t) {
                        r[c] = a;
                        break
                    } c === l && r.push(a)
            }
            s.tween = r
        }
    }

    function an(e, t, n) {
        var i = e._id;
        return e.each((function() {
                var e = Wt(this, i);
                (e.value || (e.value = {}))[t] = n.apply(this, arguments)
            })),
            function(e) {
                return qt(e, i).value[t]
            }
    }
    var cn = function(e, t) {
        var n;
        return ("number" == typeof t ? ft : t instanceof He ? ct : (n = He(t)) ? (t = n, ct) : wt)(e, t)
    };

    function ln(e) {
        return function() {
            this.removeAttribute(e)
        }
    }

    function un(e) {
        return function() {
            this.removeAttributeNS(e.space, e.local)
        }
    }

    function hn(e, t, n) {
        var i, r, s = n + "";
        return function() {
            var o = this.getAttribute(e);
            return o === s ? null : o === i ? r : r = t(i = o, n)
        }
    }

    function dn(e, t, n) {
        var i, r, s = n + "";
        return function() {
            var o = this.getAttributeNS(e.space, e.local);
            return o === s ? null : o === i ? r : r = t(i = o, n)
        }
    }

    function pn(e, t, n) {
        var i, r, s;
        return function() {
            var o, a, c = n(this);
            if (null != c) return (o = this.getAttribute(e)) === (a = c + "") ? null : o === i && a === r ? s : (r = a, s = t(i = o, c));
            this.removeAttribute(e)
        }
    }

    function fn(e, t, n) {
        var i, r, s;
        return function() {
            var o, a, c = n(this);
            if (null != c) return (o = this.getAttributeNS(e.space, e.local)) === (a = c + "") ? null : o === i && a === r ? s : (r = a, s = t(i = o, c));
            this.removeAttributeNS(e.space, e.local)
        }
    }

    function gn(e, t) {
        return function(n) {
            this.setAttribute(e, t.call(this, n))
        }
    }

    function mn(e, t) {
        return function(n) {
            this.setAttributeNS(e.space, e.local, t.call(this, n))
        }
    }

    function vn(e, t) {
        var n, i;

        function r() {
            var r = t.apply(this, arguments);
            return r !== i && (n = (i = r) && mn(e, r)), n
        }
        return r._value = t, r
    }

    function bn(e, t) {
        var n, i;

        function r() {
            var r = t.apply(this, arguments);
            return r !== i && (n = (i = r) && gn(e, r)), n
        }
        return r._value = t, r
    }

    function yn(e, t) {
        return function() {
            Ht(this, e).delay = +t.apply(this, arguments)
        }
    }

    function wn(e, t) {
        return t = +t,
            function() {
                Ht(this, e).delay = t
            }
    }

    function kn(e, t) {
        return function() {
            Wt(this, e).duration = +t.apply(this, arguments)
        }
    }

    function xn(e, t) {
        return t = +t,
            function() {
                Wt(this, e).duration = t
            }
    }

    function _n(e, t) {
        if ("function" != typeof t) throw new Error;
        return function() {
            Wt(this, e).ease = t
        }
    }

    function Sn(e, t, n) {
        var i, r, s = function(e) {
            return (e + "").trim().split(/^|\s+/).every((function(e) {
                var t = e.indexOf(".");
                return t >= 0 && (e = e.slice(0, t)), !e || "start" === e
            }))
        }(t) ? Ht : Wt;
        return function() {
            var o = s(this, e),
                a = o.on;
            a !== i && (r = (i = a).copy()).on(t, n), o.on = r
        }
    }
    var On = Ce.prototype.constructor;

    function Cn(e) {
        return function() {
            this.style.removeProperty(e)
        }
    }

    function An(e, t, n) {
        return function(i) {
            this.style.setProperty(e, t.call(this, i), n)
        }
    }

    function Tn(e, t, n) {
        var i, r;

        function s() {
            var s = t.apply(this, arguments);
            return s !== r && (i = (r = s) && An(e, s, n)), i
        }
        return s._value = t, s
    }

    function En(e) {
        return function(t) {
            this.textContent = e.call(this, t)
        }
    }

    function jn(e) {
        var t, n;

        function i() {
            var i = e.apply(this, arguments);
            return i !== n && (t = (n = i) && En(i)), t
        }
        return i._value = e, i
    }
    var Mn = 0;

    function Ln(e, t, n, i) {
        this._groups = e, this._parents = t, this._name = n, this._id = i
    }

    function Pn(e) {
        return Ce().transition(e)
    }

    function Rn() {
        return ++Mn
    }
    var In = Ce.prototype;
    Ln.prototype = Pn.prototype = {
        constructor: Ln,
        select: function(e) {
            var t = this._name,
                n = this._id;
            "function" != typeof e && (e = b(e));
            for (var i = this._groups, r = i.length, s = new Array(r), o = 0; o < r; ++o)
                for (var a, c, l = i[o], u = l.length, h = s[o] = new Array(u), d = 0; d < u; ++d)(a = l[d]) && (c = e.call(a, a.__data__, d, l)) && ("__data__" in a && (c.__data__ = a.__data__), h[d] = c, zt(h[d], t, n, d, h, qt(a, n)));
            return new Ln(s, this._parents, t, n)
        },
        selectAll: function(e) {
            var t = this._name,
                n = this._id;
            "function" != typeof e && (e = w(e));
            for (var i = this._groups, r = i.length, s = [], o = [], a = 0; a < r; ++a)
                for (var c, l = i[a], u = l.length, h = 0; h < u; ++h)
                    if (c = l[h]) {
                        for (var d, p = e.call(c, c.__data__, h, l), f = qt(c, n), g = 0, m = p.length; g < m; ++g)(d = p[g]) && zt(d, t, n, g, p, f);
                        s.push(p), o.push(c)
                    } return new Ln(s, o, t, n)
        },
        filter: function(e) {
            "function" != typeof e && (e = k(e));
            for (var t = this._groups, n = t.length, i = new Array(n), r = 0; r < n; ++r)
                for (var s, o = t[r], a = o.length, c = i[r] = [], l = 0; l < a; ++l)(s = o[l]) && e.call(s, s.__data__, l, o) && c.push(s);
            return new Ln(i, this._parents, this._name, this._id)
        },
        merge: function(e) {
            if (e._id !== this._id) throw new Error;
            for (var t = this._groups, n = e._groups, i = t.length, r = n.length, s = Math.min(i, r), o = new Array(i), a = 0; a < s; ++a)
                for (var c, l = t[a], u = n[a], h = l.length, d = o[a] = new Array(h), p = 0; p < h; ++p)(c = l[p] || u[p]) && (d[p] = c);
            for (; a < i; ++a) o[a] = t[a];
            return new Ln(o, this._parents, this._name, this._id)
        },
        selection: function() {
            return new On(this._groups, this._parents)
        },
        transition: function() {
            for (var e = this._name, t = this._id, n = Rn(), i = this._groups, r = i.length, s = 0; s < r; ++s)
                for (var o, a = i[s], c = a.length, l = 0; l < c; ++l)
                    if (o = a[l]) {
                        var u = qt(o, t);
                        zt(o, e, n, l, a, {
                            time: u.time + u.delay + u.duration,
                            delay: 0,
                            duration: u.duration,
                            ease: u.ease
                        })
                    } return new Ln(i, this._parents, e, n)
        },
        call: In.call,
        nodes: In.nodes,
        node: In.node,
        size: In.size,
        empty: In.empty,
        each: In.each,
        on: function(e, t) {
            var n = this._id;
            return arguments.length < 2 ? qt(this.node(), n).on.on(e) : this.each(Sn(n, e, t))
        },
        attr: function(e, t) {
            var n = E(e),
                i = "transform" === n ? rn : cn;
            return this.attrTween(e, "function" == typeof t ? (n.local ? fn : pn)(n, i, an(this, "attr." + e, t)) : null == t ? (n.local ? un : ln)(n) : (n.local ? dn : hn)(n, i, t))
        },
        attrTween: function(e, t) {
            var n = "attr." + e;
            if (arguments.length < 2) return (n = this.tween(n)) && n._value;
            if (null == t) return this.tween(n, null);
            if ("function" != typeof t) throw new Error;
            var i = E(e);
            return this.tween(n, (i.local ? vn : bn)(i, t))
        },
        style: function(e, t, n) {
            var i = "transform" == (e += "") ? nn : cn;
            return null == t ? this.styleTween(e, function(e, t) {
                var n, i, r;
                return function() {
                    var s = F(this, e),
                        o = (this.style.removeProperty(e), F(this, e));
                    return s === o ? null : s === n && o === i ? r : r = t(n = s, i = o)
                }
            }(e, i)).on("end.style." + e, Cn(e)) : "function" == typeof t ? this.styleTween(e, function(e, t, n) {
                var i, r, s;
                return function() {
                    var o = F(this, e),
                        a = n(this),
                        c = a + "";
                    return null == a && (this.style.removeProperty(e), c = a = F(this, e)), o === c ? null : o === i && c === r ? s : (r = c, s = t(i = o, a))
                }
            }(e, i, an(this, "style." + e, t))).each(function(e, t) {
                var n, i, r, s, o = "style." + t,
                    a = "end." + o;
                return function() {
                    var c = Wt(this, e),
                        l = c.on,
                        u = null == c.value[o] ? s || (s = Cn(t)) : void 0;
                    l === n && r === u || (i = (n = l).copy()).on(a, r = u), c.on = i
                }
            }(this._id, e)) : this.styleTween(e, function(e, t, n) {
                var i, r, s = n + "";
                return function() {
                    var o = F(this, e);
                    return o === s ? null : o === i ? r : r = t(i = o, n)
                }
            }(e, i, t), n).on("end.style." + e, null)
        },
        styleTween: function(e, t, n) {
            var i = "style." + (e += "");
            if (arguments.length < 2) return (i = this.tween(i)) && i._value;
            if (null == t) return this.tween(i, null);
            if ("function" != typeof t) throw new Error;
            return this.tween(i, Tn(e, t, null == n ? "" : n))
        },
        text: function(e) {
            return this.tween("text", "function" == typeof e ? function(e) {
                return function() {
                    var t = e(this);
                    this.textContent = null == t ? "" : t
                }
            }(an(this, "text", e)) : function(e) {
                return function() {
                    this.textContent = e
                }
            }(null == e ? "" : e + ""))
        },
        textTween: function(e) {
            var t = "text";
            if (arguments.length < 1) return (t = this.tween(t)) && t._value;
            if (null == e) return this.tween(t, null);
            if ("function" != typeof e) throw new Error;
            return this.tween(t, jn(e))
        },
        remove: function() {
            return this.on("end.remove", (e = this._id, function() {
                var t = this.parentNode;
                for (var n in this.__transition)
                    if (+n !== e) return;
                t && t.removeChild(this)
            }));
            var e
        },
        tween: function(e, t) {
            var n = this._id;
            if (e += "", arguments.length < 2) {
                for (var i, r = qt(this.node(), n).tween, s = 0, o = r.length; s < o; ++s)
                    if ((i = r[s]).name === e) return i.value;
                return null
            }
            return this.each((null == t ? sn : on)(n, e, t))
        },
        delay: function(e) {
            var t = this._id;
            return arguments.length ? this.each(("function" == typeof e ? yn : wn)(t, e)) : qt(this.node(), t).delay
        },
        duration: function(e) {
            var t = this._id;
            return arguments.length ? this.each(("function" == typeof e ? kn : xn)(t, e)) : qt(this.node(), t).duration
        },
        ease: function(e) {
            var t = this._id;
            return arguments.length ? this.each(_n(t, e)) : qt(this.node(), t).ease
        },
        end: function() {
            var e, t, n = this,
                i = n._id,
                r = n.size();
            return new Promise((function(s, o) {
                var a = {
                        value: o
                    },
                    c = {
                        value: function() {
                            0 == --r && s()
                        }
                    };
                n.each((function() {
                    var n = Wt(this, i),
                        r = n.on;
                    r !== e && ((t = (e = r).copy())._.cancel.push(a), t._.interrupt.push(a), t._.end.push(c)), n.on = t
                }))
            }))
        }
    };
    var Dn = {
        time: null,
        delay: 0,
        duration: 250,
        ease: function(e) {
            return ((e *= 2) <= 1 ? e * e * e : (e -= 2) * e * e + 2) / 2
        }
    };

    function Nn(e, t) {
        for (var n; !(n = e.__transition) || !(n = n[t]);)
            if (!(e = e.parentNode)) return Dn.time = Pt(), Dn;
        return n
    }
    Ce.prototype.interrupt = function(e) {
        return this.each((function() {
            Jt(this, e)
        }))
    }, Ce.prototype.transition = function(e) {
        var t, n;
        e instanceof Ln ? (t = e._id, e = e._name) : (t = Rn(), (n = Dn).time = Pt(), e = null == e ? null : e + "");
        for (var i = this._groups, r = i.length, s = 0; s < r; ++s)
            for (var o, a = i[s], c = a.length, l = 0; l < c; ++l)(o = a[l]) && zt(o, e, t, l, a, n || Nn(o, t));
        return new Ln(i, this._parents, e, t)
    };

    function Vn(e) {
        return [+e[0], +e[1]]
    }

    function $n(e) {
        return [Vn(e[0]), Vn(e[1])]
    } ["w", "e"].map(Fn), ["n", "s"].map(Fn), ["n", "w", "e", "s", "nw", "ne", "sw", "se"].map(Fn);

    function Fn(e) {
        return {
            type: e
        }
    }
    Math.cos, Math.sin, Math.PI, Math.max;
    Array.prototype.slice;
    var Un = Math.PI,
        Bn = 2 * Un,
        zn = Bn - 1e-6;

    function Hn() {
        this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = ""
    }

    function Wn() {
        return new Hn
    }
    Hn.prototype = Wn.prototype = {
        constructor: Hn,
        moveTo: function(e, t) {
            this._ += "M" + (this._x0 = this._x1 = +e) + "," + (this._y0 = this._y1 = +t)
        },
        closePath: function() {
            null !== this._x1 && (this._x1 = this._x0, this._y1 = this._y0, this._ += "Z")
        },
        lineTo: function(e, t) {
            this._ += "L" + (this._x1 = +e) + "," + (this._y1 = +t)
        },
        quadraticCurveTo: function(e, t, n, i) {
            this._ += "Q" + +e + "," + +t + "," + (this._x1 = +n) + "," + (this._y1 = +i)
        },
        bezierCurveTo: function(e, t, n, i, r, s) {
            this._ += "C" + +e + "," + +t + "," + +n + "," + +i + "," + (this._x1 = +r) + "," + (this._y1 = +s)
        },
        arcTo: function(e, t, n, i, r) {
            e = +e, t = +t, n = +n, i = +i, r = +r;
            var s = this._x1,
                o = this._y1,
                a = n - e,
                c = i - t,
                l = s - e,
                u = o - t,
                h = l * l + u * u;
            if (r < 0) throw new Error("negative radius: " + r);
            if (null === this._x1) this._ += "M" + (this._x1 = e) + "," + (this._y1 = t);
            else if (h > 1e-6)
                if (Math.abs(u * a - c * l) > 1e-6 && r) {
                    var d = n - s,
                        p = i - o,
                        f = a * a + c * c,
                        g = d * d + p * p,
                        m = Math.sqrt(f),
                        v = Math.sqrt(h),
                        b = r * Math.tan((Un - Math.acos((f + h - g) / (2 * m * v))) / 2),
                        y = b / v,
                        w = b / m;
                    Math.abs(y - 1) > 1e-6 && (this._ += "L" + (e + y * l) + "," + (t + y * u)), this._ += "A" + r + "," + r + ",0,0," + +(u * d > l * p) + "," + (this._x1 = e + w * a) + "," + (this._y1 = t + w * c)
                } else this._ += "L" + (this._x1 = e) + "," + (this._y1 = t);
            else;
        },
        arc: function(e, t, n, i, r, s) {
            e = +e, t = +t, s = !!s;
            var o = (n = +n) * Math.cos(i),
                a = n * Math.sin(i),
                c = e + o,
                l = t + a,
                u = 1 ^ s,
                h = s ? i - r : r - i;
            if (n < 0) throw new Error("negative radius: " + n);
            null === this._x1 ? this._ += "M" + c + "," + l : (Math.abs(this._x1 - c) > 1e-6 || Math.abs(this._y1 - l) > 1e-6) && (this._ += "L" + c + "," + l), n && (h < 0 && (h = h % Bn + Bn), h > zn ? this._ += "A" + n + "," + n + ",0,1," + u + "," + (e - o) + "," + (t - a) + "A" + n + "," + n + ",0,1," + u + "," + (this._x1 = c) + "," + (this._y1 = l) : h > 1e-6 && (this._ += "A" + n + "," + n + ",0," + +(h >= Un) + "," + u + "," + (this._x1 = e + n * Math.cos(r)) + "," + (this._y1 = t + n * Math.sin(r))))
        },
        rect: function(e, t, n, i) {
            this._ += "M" + (this._x0 = this._x1 = +e) + "," + (this._y0 = this._y1 = +t) + "h" + +n + "v" + +i + "h" + -n + "Z"
        },
        toString: function() {
            return this._
        }
    };
    var qn = Wn;

    function Gn() {}

    function Kn(e, t) {
        var n = new Gn;
        if (e instanceof Gn) e.each((function(e, t) {
            n.set(t, e)
        }));
        else if (Array.isArray(e)) {
            var i, r = -1,
                s = e.length;
            if (null == t)
                for (; ++r < s;) n.set(r, e[r]);
            else
                for (; ++r < s;) n.set(t(i = e[r], r, e), i)
        } else if (e)
            for (var o in e) n.set(o, e[o]);
        return n
    }
    Gn.prototype = Kn.prototype = {
        constructor: Gn,
        has: function(e) {
            return "$" + e in this
        },
        get: function(e) {
            return this["$" + e]
        },
        set: function(e, t) {
            return this["$" + e] = t, this
        },
        remove: function(e) {
            var t = "$" + e;
            return t in this && delete this[t]
        },
        clear: function() {
            for (var e in this) "$" === e[0] && delete this[e]
        },
        keys: function() {
            var e = [];
            for (var t in this) "$" === t[0] && e.push(t.slice(1));
            return e
        },
        values: function() {
            var e = [];
            for (var t in this) "$" === t[0] && e.push(this[t]);
            return e
        },
        entries: function() {
            var e = [];
            for (var t in this) "$" === t[0] && e.push({
                key: t.slice(1),
                value: this[t]
            });
            return e
        },
        size: function() {
            var e = 0;
            for (var t in this) "$" === t[0] && ++e;
            return e
        },
        empty: function() {
            for (var e in this)
                if ("$" === e[0]) return !1;
            return !0
        },
        each: function(e) {
            for (var t in this) "$" === t[0] && e(this[t], t.slice(1), this)
        }
    };
    var Yn = Kn;

    function Xn() {}
    var Jn = Yn.prototype;

    function Qn(e, t) {
        var n = new Xn;
        if (e instanceof Xn) e.each((function(e) {
            n.add(e)
        }));
        else if (e) {
            var i = -1,
                r = e.length;
            if (null == t)
                for (; ++i < r;) n.add(e[i]);
            else
                for (; ++i < r;) n.add(t(e[i], i, e))
        }
        return n
    }
    Xn.prototype = Qn.prototype = {
        constructor: Xn,
        has: Jn.has,
        add: function(e) {
            return this["$" + (e += "")] = e, this
        },
        remove: Jn.remove,
        clear: Jn.clear,
        values: Jn.keys,
        size: Jn.size,
        empty: Jn.empty,
        each: Jn.each
    };
    Array.prototype.slice;
    var Zn = 7.5625;

    function ei(e) {
        return (e = +e) < 4 / 11 ? Zn * e * e : e < 8 / 11 ? Zn * (e -= 6 / 11) * e + 3 / 4 : e < 10 / 11 ? Zn * (e -= 9 / 11) * e + 15 / 16 : Zn * (e -= 21 / 22) * e + 63 / 64
    }

    function ti(e, t, n, i) {
        if (isNaN(t) || isNaN(n)) return e;
        var r, s, o, a, c, l, u, h, d, p = e._root,
            f = {
                data: i
            },
            g = e._x0,
            m = e._y0,
            v = e._x1,
            b = e._y1;
        if (!p) return e._root = f, e;
        for (; p.length;)
            if ((l = t >= (s = (g + v) / 2)) ? g = s : v = s, (u = n >= (o = (m + b) / 2)) ? m = o : b = o, r = p, !(p = p[h = u << 1 | l])) return r[h] = f, e;
        if (a = +e._x.call(null, p.data), c = +e._y.call(null, p.data), t === a && n === c) return f.next = p, r ? r[h] = f : e._root = f, e;
        do {
            r = r ? r[h] = new Array(4) : e._root = new Array(4), (l = t >= (s = (g + v) / 2)) ? g = s : v = s, (u = n >= (o = (m + b) / 2)) ? m = o : b = o
        } while ((h = u << 1 | l) == (d = (c >= o) << 1 | a >= s));
        return r[d] = p, r[h] = f, e
    }
    var ni = function(e, t, n, i, r) {
        this.node = e, this.x0 = t, this.y0 = n, this.x1 = i, this.y1 = r
    };

    function ii(e) {
        return e[0]
    }

    function ri(e) {
        return e[1]
    }

    function si(e, t, n) {
        var i = new oi(null == t ? ii : t, null == n ? ri : n, NaN, NaN, NaN, NaN);
        return null == e ? i : i.addAll(e)
    }

    function oi(e, t, n, i, r, s) {
        this._x = e, this._y = t, this._x0 = n, this._y0 = i, this._x1 = r, this._y1 = s, this._root = void 0
    }

    function ai(e) {
        for (var t = {
                data: e.data
            }, n = t; e = e.next;) n = n.next = {
            data: e.data
        };
        return t
    }
    var ci = si.prototype = oi.prototype;
    ci.copy = function() {
        var e, t, n = new oi(this._x, this._y, this._x0, this._y0, this._x1, this._y1),
            i = this._root;
        if (!i) return n;
        if (!i.length) return n._root = ai(i), n;
        for (e = [{
                source: i,
                target: n._root = new Array(4)
            }]; i = e.pop();)
            for (var r = 0; r < 4; ++r)(t = i.source[r]) && (t.length ? e.push({
                source: t,
                target: i.target[r] = new Array(4)
            }) : i.target[r] = ai(t));
        return n
    }, ci.add = function(e) {
        var t = +this._x.call(null, e),
            n = +this._y.call(null, e);
        return ti(this.cover(t, n), t, n, e)
    }, ci.addAll = function(e) {
        var t, n, i, r, s = e.length,
            o = new Array(s),
            a = new Array(s),
            c = 1 / 0,
            l = 1 / 0,
            u = -1 / 0,
            h = -1 / 0;
        for (n = 0; n < s; ++n) isNaN(i = +this._x.call(null, t = e[n])) || isNaN(r = +this._y.call(null, t)) || (o[n] = i, a[n] = r, i < c && (c = i), i > u && (u = i), r < l && (l = r), r > h && (h = r));
        if (c > u || l > h) return this;
        for (this.cover(c, l).cover(u, h), n = 0; n < s; ++n) ti(this, o[n], a[n], e[n]);
        return this
    }, ci.cover = function(e, t) {
        if (isNaN(e = +e) || isNaN(t = +t)) return this;
        var n = this._x0,
            i = this._y0,
            r = this._x1,
            s = this._y1;
        if (isNaN(n)) r = (n = Math.floor(e)) + 1, s = (i = Math.floor(t)) + 1;
        else {
            for (var o, a, c = r - n, l = this._root; n > e || e >= r || i > t || t >= s;) switch (a = (t < i) << 1 | e < n, (o = new Array(4))[a] = l, l = o, c *= 2, a) {
                case 0:
                    r = n + c, s = i + c;
                    break;
                case 1:
                    n = r - c, s = i + c;
                    break;
                case 2:
                    r = n + c, i = s - c;
                    break;
                case 3:
                    n = r - c, i = s - c
            }
            this._root && this._root.length && (this._root = l)
        }
        return this._x0 = n, this._y0 = i, this._x1 = r, this._y1 = s, this
    }, ci.data = function() {
        var e = [];
        return this.visit((function(t) {
            if (!t.length)
                do {
                    e.push(t.data)
                } while (t = t.next)
        })), e
    }, ci.extent = function(e) {
        return arguments.length ? this.cover(+e[0][0], +e[0][1]).cover(+e[1][0], +e[1][1]) : isNaN(this._x0) ? void 0 : [
            [this._x0, this._y0],
            [this._x1, this._y1]
        ]
    }, ci.find = function(e, t, n) {
        var i, r, s, o, a, c, l, u = this._x0,
            h = this._y0,
            d = this._x1,
            p = this._y1,
            f = [],
            g = this._root;
        for (g && f.push(new ni(g, u, h, d, p)), null == n ? n = 1 / 0 : (u = e - n, h = t - n, d = e + n, p = t + n, n *= n); c = f.pop();)
            if (!(!(g = c.node) || (r = c.x0) > d || (s = c.y0) > p || (o = c.x1) < u || (a = c.y1) < h))
                if (g.length) {
                    var m = (r + o) / 2,
                        v = (s + a) / 2;
                    f.push(new ni(g[3], m, v, o, a), new ni(g[2], r, v, m, a), new ni(g[1], m, s, o, v), new ni(g[0], r, s, m, v)), (l = (t >= v) << 1 | e >= m) && (c = f[f.length - 1], f[f.length - 1] = f[f.length - 1 - l], f[f.length - 1 - l] = c)
                } else {
                    var b = e - +this._x.call(null, g.data),
                        y = t - +this._y.call(null, g.data),
                        w = b * b + y * y;
                    if (w < n) {
                        var k = Math.sqrt(n = w);
                        u = e - k, h = t - k, d = e + k, p = t + k, i = g.data
                    }
                } return i
    }, ci.remove = function(e) {
        if (isNaN(s = +this._x.call(null, e)) || isNaN(o = +this._y.call(null, e))) return this;
        var t, n, i, r, s, o, a, c, l, u, h, d, p = this._root,
            f = this._x0,
            g = this._y0,
            m = this._x1,
            v = this._y1;
        if (!p) return this;
        if (p.length)
            for (;;) {
                if ((l = s >= (a = (f + m) / 2)) ? f = a : m = a, (u = o >= (c = (g + v) / 2)) ? g = c : v = c, t = p, !(p = p[h = u << 1 | l])) return this;
                if (!p.length) break;
                (t[h + 1 & 3] || t[h + 2 & 3] || t[h + 3 & 3]) && (n = t, d = h)
            }
        for (; p.data !== e;)
            if (i = p, !(p = p.next)) return this;
        return (r = p.next) && delete p.next, i ? (r ? i.next = r : delete i.next, this) : t ? (r ? t[h] = r : delete t[h], (p = t[0] || t[1] || t[2] || t[3]) && p === (t[3] || t[2] || t[1] || t[0]) && !p.length && (n ? n[d] = p : this._root = p), this) : (this._root = r, this)
    }, ci.removeAll = function(e) {
        for (var t = 0, n = e.length; t < n; ++t) this.remove(e[t]);
        return this
    }, ci.root = function() {
        return this._root
    }, ci.size = function() {
        var e = 0;
        return this.visit((function(t) {
            if (!t.length)
                do {
                    ++e
                } while (t = t.next)
        })), e
    }, ci.visit = function(e) {
        var t, n, i, r, s, o, a = [],
            c = this._root;
        for (c && a.push(new ni(c, this._x0, this._y0, this._x1, this._y1)); t = a.pop();)
            if (!e(c = t.node, i = t.x0, r = t.y0, s = t.x1, o = t.y1) && c.length) {
                var l = (i + s) / 2,
                    u = (r + o) / 2;
                (n = c[3]) && a.push(new ni(n, l, u, s, o)), (n = c[2]) && a.push(new ni(n, i, u, l, o)), (n = c[1]) && a.push(new ni(n, l, r, s, u)), (n = c[0]) && a.push(new ni(n, i, r, l, u))
            } return this
    }, ci.visitAfter = function(e) {
        var t, n = [],
            i = [];
        for (this._root && n.push(new ni(this._root, this._x0, this._y0, this._x1, this._y1)); t = n.pop();) {
            var r = t.node;
            if (r.length) {
                var s, o = t.x0,
                    a = t.y0,
                    c = t.x1,
                    l = t.y1,
                    u = (o + c) / 2,
                    h = (a + l) / 2;
                (s = r[0]) && n.push(new ni(s, o, a, u, h)), (s = r[1]) && n.push(new ni(s, u, a, c, h)), (s = r[2]) && n.push(new ni(s, o, h, u, l)), (s = r[3]) && n.push(new ni(s, u, h, c, l))
            }
            i.push(t)
        }
        for (; t = i.pop();) e(t.node, t.x0, t.y0, t.x1, t.y1);
        return this
    }, ci.x = function(e) {
        return arguments.length ? (this._x = e, this) : this._x
    }, ci.y = function(e) {
        return arguments.length ? (this._y = e, this) : this._y
    };
    Math.PI, Math.sqrt(5);
    var li = function() {
            return Math.random()
        },
        ui = (function e(t) {
            function n(e, n) {
                return e = null == e ? 0 : +e, n = null == n ? 1 : +n, 1 === arguments.length ? (n = e, e = 0) : n -= e,
                    function() {
                        return t() * n + e
                    }
            }
            return n.source = e, n
        }(li), function e(t) {
            function n(e, n) {
                var i, r;
                return e = null == e ? 0 : +e, n = null == n ? 1 : +n,
                    function() {
                        var s;
                        if (null != i) s = i, i = null;
                        else
                            do {
                                i = 2 * t() - 1, s = 2 * t() - 1, r = i * i + s * s
                            } while (!r || r > 1);
                        return e + n * s * Math.sqrt(-2 * Math.log(r) / r)
                    }
            }
            return n.source = e, n
        }(li)),
        hi = (function e(t) {
            function n() {
                var e = ui.source(t).apply(this, arguments);
                return function() {
                    return Math.exp(e())
                }
            }
            return n.source = e, n
        }(li), function e(t) {
            function n(e) {
                return function() {
                    for (var n = 0, i = 0; i < e; ++i) n += t();
                    return n
                }
            }
            return n.source = e, n
        }(li));
    (function e(t) {
        function n(e) {
            var n = hi.source(t)(e);
            return function() {
                return n() / e
            }
        }
        return n.source = e, n
    })(li),
    function e(t) {
        function n(e) {
            return function() {
                return -Math.log(1 - t()) / e
            }
        }
        return n.source = e, n
    }(li);
    var di = Array.prototype;
    di.map, di.slice;
    var pi = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;

    function fi(e) {
        if (!(t = pi.exec(e))) throw new Error("invalid format: " + e);
        var t;
        return new gi({
            fill: t[1],
            align: t[2],
            sign: t[3],
            symbol: t[4],
            zero: t[5],
            width: t[6],
            comma: t[7],
            precision: t[8] && t[8].slice(1),
            trim: t[9],
            type: t[10]
        })
    }

    function gi(e) {
        this.fill = void 0 === e.fill ? " " : e.fill + "", this.align = void 0 === e.align ? ">" : e.align + "", this.sign = void 0 === e.sign ? "-" : e.sign + "", this.symbol = void 0 === e.symbol ? "" : e.symbol + "", this.zero = !!e.zero, this.width = void 0 === e.width ? void 0 : +e.width, this.comma = !!e.comma, this.precision = void 0 === e.precision ? void 0 : +e.precision, this.trim = !!e.trim, this.type = void 0 === e.type ? "" : e.type + ""
    }
    fi.prototype = gi.prototype, gi.prototype.toString = function() {
        return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (void 0 === this.width ? "" : Math.max(1, 0 | this.width)) + (this.comma ? "," : "") + (void 0 === this.precision ? "" : "." + Math.max(0, 0 | this.precision)) + (this.trim ? "~" : "") + this.type
    };

    function mi(e, t) {
        if ((n = (e = t ? e.toExponential(t - 1) : e.toExponential()).indexOf("e")) < 0) return null;
        var n, i = e.slice(0, n);
        return [i.length > 1 ? i[0] + i.slice(2) : i, +e.slice(n + 1)]
    }
    var vi, bi, yi = function(e) {
            return (e = mi(Math.abs(e))) ? e[1] : NaN
        },
        wi = function(e, t) {
            var n = mi(e, t);
            if (!n) return e + "";
            var i = n[0],
                r = n[1];
            return r < 0 ? "0." + new Array(-r).join("0") + i : i.length > r + 1 ? i.slice(0, r + 1) + "." + i.slice(r + 1) : i + new Array(r - i.length + 2).join("0")
        },
        ki = {
            "%": function(e, t) {
                return (100 * e).toFixed(t)
            },
            b: function(e) {
                return Math.round(e).toString(2)
            },
            c: function(e) {
                return e + ""
            },
            d: function(e) {
                return Math.abs(e = Math.round(e)) >= 1e21 ? e.toLocaleString("en").replace(/,/g, "") : e.toString(10)
            },
            e: function(e, t) {
                return e.toExponential(t)
            },
            f: function(e, t) {
                return e.toFixed(t)
            },
            g: function(e, t) {
                return e.toPrecision(t)
            },
            o: function(e) {
                return Math.round(e).toString(8)
            },
            p: function(e, t) {
                return wi(100 * e, t)
            },
            r: wi,
            s: function(e, t) {
                var n = mi(e, t);
                if (!n) return e + "";
                var i = n[0],
                    r = n[1],
                    s = r - (vi = 3 * Math.max(-8, Math.min(8, Math.floor(r / 3)))) + 1,
                    o = i.length;
                return s === o ? i : s > o ? i + new Array(s - o + 1).join("0") : s > 0 ? i.slice(0, s) + "." + i.slice(s) : "0." + new Array(1 - s).join("0") + mi(e, Math.max(0, t + s - 1))[0]
            },
            X: function(e) {
                return Math.round(e).toString(16).toUpperCase()
            },
            x: function(e) {
                return Math.round(e).toString(16)
            }
        },
        xi = function(e) {
            return e
        },
        _i = Array.prototype.map,
        Si = ["y", "z", "a", "f", "p", "n", "µ", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
    bi = function(e) {
        var t, n, i = void 0 === e.grouping || void 0 === e.thousands ? xi : (t = _i.call(e.grouping, Number), n = e.thousands + "", function(e, i) {
                for (var r = e.length, s = [], o = 0, a = t[0], c = 0; r > 0 && a > 0 && (c + a + 1 > i && (a = Math.max(1, i - c)), s.push(e.substring(r -= a, r + a)), !((c += a + 1) > i));) a = t[o = (o + 1) % t.length];
                return s.reverse().join(n)
            }),
            r = void 0 === e.currency ? "" : e.currency[0] + "",
            s = void 0 === e.currency ? "" : e.currency[1] + "",
            o = void 0 === e.decimal ? "." : e.decimal + "",
            a = void 0 === e.numerals ? xi : function(e) {
                return function(t) {
                    return t.replace(/[0-9]/g, (function(t) {
                        return e[+t]
                    }))
                }
            }(_i.call(e.numerals, String)),
            c = void 0 === e.percent ? "%" : e.percent + "",
            l = void 0 === e.minus ? "-" : e.minus + "",
            u = void 0 === e.nan ? "NaN" : e.nan + "";

        function h(e) {
            var t = (e = fi(e)).fill,
                n = e.align,
                h = e.sign,
                d = e.symbol,
                p = e.zero,
                f = e.width,
                g = e.comma,
                m = e.precision,
                v = e.trim,
                b = e.type;
            "n" === b ? (g = !0, b = "g") : ki[b] || (void 0 === m && (m = 12), v = !0, b = "g"), (p || "0" === t && "=" === n) && (p = !0, t = "0", n = "=");
            var y = "$" === d ? r : "#" === d && /[boxX]/.test(b) ? "0" + b.toLowerCase() : "",
                w = "$" === d ? s : /[%p]/.test(b) ? c : "",
                k = ki[b],
                x = /[defgprs%]/.test(b);

            function _(e) {
                var r, s, c, d = y,
                    _ = w;
                if ("c" === b) _ = k(e) + _, e = "";
                else {
                    var S = (e = +e) < 0 || 1 / e < 0;
                    if (e = isNaN(e) ? u : k(Math.abs(e), m), v && (e = function(e) {
                            e: for (var t, n = e.length, i = 1, r = -1; i < n; ++i) switch (e[i]) {
                                case ".":
                                    r = t = i;
                                    break;
                                case "0":
                                    0 === r && (r = i), t = i;
                                    break;
                                default:
                                    if (!+e[i]) break e;
                                    r > 0 && (r = 0)
                            }
                            return r > 0 ? e.slice(0, r) + e.slice(t + 1) : e
                        }(e)), S && 0 == +e && "+" !== h && (S = !1), d = (S ? "(" === h ? h : l : "-" === h || "(" === h ? "" : h) + d, _ = ("s" === b ? Si[8 + vi / 3] : "") + _ + (S && "(" === h ? ")" : ""), x)
                        for (r = -1, s = e.length; ++r < s;)
                            if (48 > (c = e.charCodeAt(r)) || c > 57) {
                                _ = (46 === c ? o + e.slice(r + 1) : e.slice(r)) + _, e = e.slice(0, r);
                                break
                            }
                }
                g && !p && (e = i(e, 1 / 0));
                var O = d.length + e.length + _.length,
                    C = O < f ? new Array(f - O + 1).join(t) : "";
                switch (g && p && (e = i(C + e, C.length ? f - _.length : 1 / 0), C = ""), n) {
                    case "<":
                        e = d + e + _ + C;
                        break;
                    case "=":
                        e = d + C + e + _;
                        break;
                    case "^":
                        e = C.slice(0, O = C.length >> 1) + d + e + _ + C.slice(O);
                        break;
                    default:
                        e = C + d + e + _
                }
                return a(e)
            }
            return m = void 0 === m ? 6 : /[gprs]/.test(b) ? Math.max(1, Math.min(21, m)) : Math.max(0, Math.min(20, m)), _.toString = function() {
                return e + ""
            }, _
        }
        return {
            format: h,
            formatPrefix: function(e, t) {
                var n = h(((e = fi(e)).type = "f", e)),
                    i = 3 * Math.max(-8, Math.min(8, Math.floor(yi(t) / 3))),
                    r = Math.pow(10, -i),
                    s = Si[8 + i / 3];
                return function(e) {
                    return n(r * e) + s
                }
            }
        }
    }({
        decimal: ".",
        thousands: ",",
        grouping: [3],
        currency: ["$", ""],
        minus: "-"
    }), bi.format, bi.formatPrefix;
    var Oi = new Date,
        Ci = new Date;

    function Ai(e, t, n, i) {
        function r(t) {
            return e(t = 0 === arguments.length ? new Date : new Date(+t)), t
        }
        return r.floor = function(t) {
            return e(t = new Date(+t)), t
        }, r.ceil = function(n) {
            return e(n = new Date(n - 1)), t(n, 1), e(n), n
        }, r.round = function(e) {
            var t = r(e),
                n = r.ceil(e);
            return e - t < n - e ? t : n
        }, r.offset = function(e, n) {
            return t(e = new Date(+e), null == n ? 1 : Math.floor(n)), e
        }, r.range = function(n, i, s) {
            var o, a = [];
            if (n = r.ceil(n), s = null == s ? 1 : Math.floor(s), !(n < i && s > 0)) return a;
            do {
                a.push(o = new Date(+n)), t(n, s), e(n)
            } while (o < n && n < i);
            return a
        }, r.filter = function(n) {
            return Ai((function(t) {
                if (t >= t)
                    for (; e(t), !n(t);) t.setTime(t - 1)
            }), (function(e, i) {
                if (e >= e)
                    if (i < 0)
                        for (; ++i <= 0;)
                            for (; t(e, -1), !n(e););
                    else
                        for (; --i >= 0;)
                            for (; t(e, 1), !n(e););
            }))
        }, n && (r.count = function(t, i) {
            return Oi.setTime(+t), Ci.setTime(+i), e(Oi), e(Ci), Math.floor(n(Oi, Ci))
        }, r.every = function(e) {
            return e = Math.floor(e), isFinite(e) && e > 0 ? e > 1 ? r.filter(i ? function(t) {
                return i(t) % e == 0
            } : function(t) {
                return r.count(0, t) % e == 0
            }) : r : null
        }), r
    }
    var Ti = Ai((function(e) {
        e.setMonth(0, 1), e.setHours(0, 0, 0, 0)
    }), (function(e, t) {
        e.setFullYear(e.getFullYear() + t)
    }), (function(e, t) {
        return t.getFullYear() - e.getFullYear()
    }), (function(e) {
        return e.getFullYear()
    }));
    Ti.every = function(e) {
        return isFinite(e = Math.floor(e)) && e > 0 ? Ai((function(t) {
            t.setFullYear(Math.floor(t.getFullYear() / e) * e), t.setMonth(0, 1), t.setHours(0, 0, 0, 0)
        }), (function(t, n) {
            t.setFullYear(t.getFullYear() + n * e)
        })) : null
    };
    var Ei = Ti,
        ji = (Ti.range, Ai((function(e) {
            e.setDate(1), e.setHours(0, 0, 0, 0)
        }), (function(e, t) {
            e.setMonth(e.getMonth() + t)
        }), (function(e, t) {
            return t.getMonth() - e.getMonth() + 12 * (t.getFullYear() - e.getFullYear())
        }), (function(e) {
            return e.getMonth()
        })));
    ji.range;

    function Mi(e) {
        return Ai((function(t) {
            t.setDate(t.getDate() - (t.getDay() + 7 - e) % 7), t.setHours(0, 0, 0, 0)
        }), (function(e, t) {
            e.setDate(e.getDate() + 7 * t)
        }), (function(e, t) {
            return (t - e - 6e4 * (t.getTimezoneOffset() - e.getTimezoneOffset())) / 6048e5
        }))
    }
    var Li = Mi(0),
        Pi = Mi(1),
        Ri = Mi(2),
        Ii = Mi(3),
        Di = Mi(4),
        Ni = Mi(5),
        Vi = Mi(6),
        $i = (Li.range, Pi.range, Ri.range, Ii.range, Di.range, Ni.range, Vi.range, Ai((function(e) {
            e.setHours(0, 0, 0, 0)
        }), (function(e, t) {
            e.setDate(e.getDate() + t)
        }), (function(e, t) {
            return (t - e - 6e4 * (t.getTimezoneOffset() - e.getTimezoneOffset())) / 864e5
        }), (function(e) {
            return e.getDate() - 1
        }))),
        Fi = $i,
        Ui = ($i.range, Ai((function(e) {
            e.setTime(e - e.getMilliseconds() - 1e3 * e.getSeconds() - 6e4 * e.getMinutes())
        }), (function(e, t) {
            e.setTime(+e + 36e5 * t)
        }), (function(e, t) {
            return (t - e) / 36e5
        }), (function(e) {
            return e.getHours()
        }))),
        Bi = (Ui.range, Ai((function(e) {
            e.setTime(e - e.getMilliseconds() - 1e3 * e.getSeconds())
        }), (function(e, t) {
            e.setTime(+e + 6e4 * t)
        }), (function(e, t) {
            return (t - e) / 6e4
        }), (function(e) {
            return e.getMinutes()
        }))),
        zi = (Bi.range, Ai((function(e) {
            e.setTime(e - e.getMilliseconds())
        }), (function(e, t) {
            e.setTime(+e + 1e3 * t)
        }), (function(e, t) {
            return (t - e) / 1e3
        }), (function(e) {
            return e.getUTCSeconds()
        }))),
        Hi = (zi.range, Ai((function() {}), (function(e, t) {
            e.setTime(+e + t)
        }), (function(e, t) {
            return t - e
        })));
    Hi.every = function(e) {
        return e = Math.floor(e), isFinite(e) && e > 0 ? e > 1 ? Ai((function(t) {
            t.setTime(Math.floor(t / e) * e)
        }), (function(t, n) {
            t.setTime(+t + n * e)
        }), (function(t, n) {
            return (n - t) / e
        })) : Hi : null
    };
    Hi.range;

    function Wi(e) {
        return Ai((function(t) {
            t.setUTCDate(t.getUTCDate() - (t.getUTCDay() + 7 - e) % 7), t.setUTCHours(0, 0, 0, 0)
        }), (function(e, t) {
            e.setUTCDate(e.getUTCDate() + 7 * t)
        }), (function(e, t) {
            return (t - e) / 6048e5
        }))
    }
    var qi = Wi(0),
        Gi = Wi(1),
        Ki = Wi(2),
        Yi = Wi(3),
        Xi = Wi(4),
        Ji = Wi(5),
        Qi = Wi(6),
        Zi = (qi.range, Gi.range, Ki.range, Yi.range, Xi.range, Ji.range, Qi.range, Ai((function(e) {
            e.setUTCHours(0, 0, 0, 0)
        }), (function(e, t) {
            e.setUTCDate(e.getUTCDate() + t)
        }), (function(e, t) {
            return (t - e) / 864e5
        }), (function(e) {
            return e.getUTCDate() - 1
        }))),
        er = Zi,
        tr = (Zi.range, Ai((function(e) {
            e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0)
        }), (function(e, t) {
            e.setUTCFullYear(e.getUTCFullYear() + t)
        }), (function(e, t) {
            return t.getUTCFullYear() - e.getUTCFullYear()
        }), (function(e) {
            return e.getUTCFullYear()
        })));
    tr.every = function(e) {
        return isFinite(e = Math.floor(e)) && e > 0 ? Ai((function(t) {
            t.setUTCFullYear(Math.floor(t.getUTCFullYear() / e) * e), t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0)
        }), (function(t, n) {
            t.setUTCFullYear(t.getUTCFullYear() + n * e)
        })) : null
    };
    var nr = tr;
    tr.range;

    function ir(e) {
        if (0 <= e.y && e.y < 100) {
            var t = new Date(-1, e.m, e.d, e.H, e.M, e.S, e.L);
            return t.setFullYear(e.y), t
        }
        return new Date(e.y, e.m, e.d, e.H, e.M, e.S, e.L)
    }

    function rr(e) {
        if (0 <= e.y && e.y < 100) {
            var t = new Date(Date.UTC(-1, e.m, e.d, e.H, e.M, e.S, e.L));
            return t.setUTCFullYear(e.y), t
        }
        return new Date(Date.UTC(e.y, e.m, e.d, e.H, e.M, e.S, e.L))
    }

    function sr(e, t, n) {
        return {
            y: e,
            m: t,
            d: n,
            H: 0,
            M: 0,
            S: 0,
            L: 0
        }
    }
    var or, ar = {
            "-": "",
            _: " ",
            0: "0"
        },
        cr = /^\s*\d+/,
        lr = /^%/,
        ur = /[\\^$*+?|[\]().{}]/g;

    function hr(e, t, n) {
        var i = e < 0 ? "-" : "",
            r = (i ? -e : e) + "",
            s = r.length;
        return i + (s < n ? new Array(n - s + 1).join(t) + r : r)
    }

    function dr(e) {
        return e.replace(ur, "\\$&")
    }

    function pr(e) {
        return new RegExp("^(?:" + e.map(dr).join("|") + ")", "i")
    }

    function fr(e) {
        for (var t = {}, n = -1, i = e.length; ++n < i;) t[e[n].toLowerCase()] = n;
        return t
    }

    function gr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 1));
        return i ? (e.w = +i[0], n + i[0].length) : -1
    }

    function mr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 1));
        return i ? (e.u = +i[0], n + i[0].length) : -1
    }

    function vr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.U = +i[0], n + i[0].length) : -1
    }

    function br(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.V = +i[0], n + i[0].length) : -1
    }

    function yr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.W = +i[0], n + i[0].length) : -1
    }

    function wr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 4));
        return i ? (e.y = +i[0], n + i[0].length) : -1
    }

    function kr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.y = +i[0] + (+i[0] > 68 ? 1900 : 2e3), n + i[0].length) : -1
    }

    function xr(e, t, n) {
        var i = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(t.slice(n, n + 6));
        return i ? (e.Z = i[1] ? 0 : -(i[2] + (i[3] || "00")), n + i[0].length) : -1
    }

    function _r(e, t, n) {
        var i = cr.exec(t.slice(n, n + 1));
        return i ? (e.q = 3 * i[0] - 3, n + i[0].length) : -1
    }

    function Sr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.m = i[0] - 1, n + i[0].length) : -1
    }

    function Or(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.d = +i[0], n + i[0].length) : -1
    }

    function Cr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 3));
        return i ? (e.m = 0, e.d = +i[0], n + i[0].length) : -1
    }

    function Ar(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.H = +i[0], n + i[0].length) : -1
    }

    function Tr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.M = +i[0], n + i[0].length) : -1
    }

    function Er(e, t, n) {
        var i = cr.exec(t.slice(n, n + 2));
        return i ? (e.S = +i[0], n + i[0].length) : -1
    }

    function jr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 3));
        return i ? (e.L = +i[0], n + i[0].length) : -1
    }

    function Mr(e, t, n) {
        var i = cr.exec(t.slice(n, n + 6));
        return i ? (e.L = Math.floor(i[0] / 1e3), n + i[0].length) : -1
    }

    function Lr(e, t, n) {
        var i = lr.exec(t.slice(n, n + 1));
        return i ? n + i[0].length : -1
    }

    function Pr(e, t, n) {
        var i = cr.exec(t.slice(n));
        return i ? (e.Q = +i[0], n + i[0].length) : -1
    }

    function Rr(e, t, n) {
        var i = cr.exec(t.slice(n));
        return i ? (e.s = +i[0], n + i[0].length) : -1
    }

    function Ir(e, t) {
        return hr(e.getDate(), t, 2)
    }

    function Dr(e, t) {
        return hr(e.getHours(), t, 2)
    }

    function Nr(e, t) {
        return hr(e.getHours() % 12 || 12, t, 2)
    }

    function Vr(e, t) {
        return hr(1 + Fi.count(Ei(e), e), t, 3)
    }

    function $r(e, t) {
        return hr(e.getMilliseconds(), t, 3)
    }

    function Fr(e, t) {
        return $r(e, t) + "000"
    }

    function Ur(e, t) {
        return hr(e.getMonth() + 1, t, 2)
    }

    function Br(e, t) {
        return hr(e.getMinutes(), t, 2)
    }

    function zr(e, t) {
        return hr(e.getSeconds(), t, 2)
    }

    function Hr(e) {
        var t = e.getDay();
        return 0 === t ? 7 : t
    }

    function Wr(e, t) {
        return hr(Li.count(Ei(e) - 1, e), t, 2)
    }

    function qr(e) {
        var t = e.getDay();
        return t >= 4 || 0 === t ? Di(e) : Di.ceil(e)
    }

    function Gr(e, t) {
        return e = qr(e), hr(Di.count(Ei(e), e) + (4 === Ei(e).getDay()), t, 2)
    }

    function Kr(e) {
        return e.getDay()
    }

    function Yr(e, t) {
        return hr(Pi.count(Ei(e) - 1, e), t, 2)
    }

    function Xr(e, t) {
        return hr(e.getFullYear() % 100, t, 2)
    }

    function Jr(e, t) {
        return hr((e = qr(e)).getFullYear() % 100, t, 2)
    }

    function Qr(e, t) {
        return hr(e.getFullYear() % 1e4, t, 4)
    }

    function Zr(e, t) {
        var n = e.getDay();
        return hr((e = n >= 4 || 0 === n ? Di(e) : Di.ceil(e)).getFullYear() % 1e4, t, 4)
    }

    function es(e) {
        var t = e.getTimezoneOffset();
        return (t > 0 ? "-" : (t *= -1, "+")) + hr(t / 60 | 0, "0", 2) + hr(t % 60, "0", 2)
    }

    function ts(e, t) {
        return hr(e.getUTCDate(), t, 2)
    }

    function ns(e, t) {
        return hr(e.getUTCHours(), t, 2)
    }

    function is(e, t) {
        return hr(e.getUTCHours() % 12 || 12, t, 2)
    }

    function rs(e, t) {
        return hr(1 + er.count(nr(e), e), t, 3)
    }

    function ss(e, t) {
        return hr(e.getUTCMilliseconds(), t, 3)
    }

    function os(e, t) {
        return ss(e, t) + "000"
    }

    function as(e, t) {
        return hr(e.getUTCMonth() + 1, t, 2)
    }

    function cs(e, t) {
        return hr(e.getUTCMinutes(), t, 2)
    }

    function ls(e, t) {
        return hr(e.getUTCSeconds(), t, 2)
    }

    function us(e) {
        var t = e.getUTCDay();
        return 0 === t ? 7 : t
    }

    function hs(e, t) {
        return hr(qi.count(nr(e) - 1, e), t, 2)
    }

    function ds(e) {
        var t = e.getUTCDay();
        return t >= 4 || 0 === t ? Xi(e) : Xi.ceil(e)
    }

    function ps(e, t) {
        return e = ds(e), hr(Xi.count(nr(e), e) + (4 === nr(e).getUTCDay()), t, 2)
    }

    function fs(e) {
        return e.getUTCDay()
    }

    function gs(e, t) {
        return hr(Gi.count(nr(e) - 1, e), t, 2)
    }

    function ms(e, t) {
        return hr(e.getUTCFullYear() % 100, t, 2)
    }

    function vs(e, t) {
        return hr((e = ds(e)).getUTCFullYear() % 100, t, 2)
    }

    function bs(e, t) {
        return hr(e.getUTCFullYear() % 1e4, t, 4)
    }

    function ys(e, t) {
        var n = e.getUTCDay();
        return hr((e = n >= 4 || 0 === n ? Xi(e) : Xi.ceil(e)).getUTCFullYear() % 1e4, t, 4)
    }

    function ws() {
        return "+0000"
    }

    function ks() {
        return "%"
    }

    function xs(e) {
        return +e
    }

    function _s(e) {
        return Math.floor(+e / 1e3)
    }! function(e) {
        or = function(e) {
            var t = e.dateTime,
                n = e.date,
                i = e.time,
                r = e.periods,
                s = e.days,
                o = e.shortDays,
                a = e.months,
                c = e.shortMonths,
                l = pr(r),
                u = fr(r),
                h = pr(s),
                d = fr(s),
                p = pr(o),
                f = fr(o),
                g = pr(a),
                m = fr(a),
                v = pr(c),
                b = fr(c),
                y = {
                    a: function(e) {
                        return o[e.getDay()]
                    },
                    A: function(e) {
                        return s[e.getDay()]
                    },
                    b: function(e) {
                        return c[e.getMonth()]
                    },
                    B: function(e) {
                        return a[e.getMonth()]
                    },
                    c: null,
                    d: Ir,
                    e: Ir,
                    f: Fr,
                    g: Jr,
                    G: Zr,
                    H: Dr,
                    I: Nr,
                    j: Vr,
                    L: $r,
                    m: Ur,
                    M: Br,
                    p: function(e) {
                        return r[+(e.getHours() >= 12)]
                    },
                    q: function(e) {
                        return 1 + ~~(e.getMonth() / 3)
                    },
                    Q: xs,
                    s: _s,
                    S: zr,
                    u: Hr,
                    U: Wr,
                    V: Gr,
                    w: Kr,
                    W: Yr,
                    x: null,
                    X: null,
                    y: Xr,
                    Y: Qr,
                    Z: es,
                    "%": ks
                },
                w = {
                    a: function(e) {
                        return o[e.getUTCDay()]
                    },
                    A: function(e) {
                        return s[e.getUTCDay()]
                    },
                    b: function(e) {
                        return c[e.getUTCMonth()]
                    },
                    B: function(e) {
                        return a[e.getUTCMonth()]
                    },
                    c: null,
                    d: ts,
                    e: ts,
                    f: os,
                    g: vs,
                    G: ys,
                    H: ns,
                    I: is,
                    j: rs,
                    L: ss,
                    m: as,
                    M: cs,
                    p: function(e) {
                        return r[+(e.getUTCHours() >= 12)]
                    },
                    q: function(e) {
                        return 1 + ~~(e.getUTCMonth() / 3)
                    },
                    Q: xs,
                    s: _s,
                    S: ls,
                    u: us,
                    U: hs,
                    V: ps,
                    w: fs,
                    W: gs,
                    x: null,
                    X: null,
                    y: ms,
                    Y: bs,
                    Z: ws,
                    "%": ks
                },
                k = {
                    a: function(e, t, n) {
                        var i = p.exec(t.slice(n));
                        return i ? (e.w = f[i[0].toLowerCase()], n + i[0].length) : -1
                    },
                    A: function(e, t, n) {
                        var i = h.exec(t.slice(n));
                        return i ? (e.w = d[i[0].toLowerCase()], n + i[0].length) : -1
                    },
                    b: function(e, t, n) {
                        var i = v.exec(t.slice(n));
                        return i ? (e.m = b[i[0].toLowerCase()], n + i[0].length) : -1
                    },
                    B: function(e, t, n) {
                        var i = g.exec(t.slice(n));
                        return i ? (e.m = m[i[0].toLowerCase()], n + i[0].length) : -1
                    },
                    c: function(e, n, i) {
                        return S(e, t, n, i)
                    },
                    d: Or,
                    e: Or,
                    f: Mr,
                    g: kr,
                    G: wr,
                    H: Ar,
                    I: Ar,
                    j: Cr,
                    L: jr,
                    m: Sr,
                    M: Tr,
                    p: function(e, t, n) {
                        var i = l.exec(t.slice(n));
                        return i ? (e.p = u[i[0].toLowerCase()], n + i[0].length) : -1
                    },
                    q: _r,
                    Q: Pr,
                    s: Rr,
                    S: Er,
                    u: mr,
                    U: vr,
                    V: br,
                    w: gr,
                    W: yr,
                    x: function(e, t, i) {
                        return S(e, n, t, i)
                    },
                    X: function(e, t, n) {
                        return S(e, i, t, n)
                    },
                    y: kr,
                    Y: wr,
                    Z: xr,
                    "%": Lr
                };

            function x(e, t) {
                return function(n) {
                    var i, r, s, o = [],
                        a = -1,
                        c = 0,
                        l = e.length;
                    for (n instanceof Date || (n = new Date(+n)); ++a < l;) 37 === e.charCodeAt(a) && (o.push(e.slice(c, a)), null != (r = ar[i = e.charAt(++a)]) ? i = e.charAt(++a) : r = "e" === i ? " " : "0", (s = t[i]) && (i = s(n, r)), o.push(i), c = a + 1);
                    return o.push(e.slice(c, a)), o.join("")
                }
            }

            function _(e, t) {
                return function(n) {
                    var i, r, s = sr(1900, void 0, 1);
                    if (S(s, e, n += "", 0) != n.length) return null;
                    if ("Q" in s) return new Date(s.Q);
                    if ("s" in s) return new Date(1e3 * s.s + ("L" in s ? s.L : 0));
                    if (t && !("Z" in s) && (s.Z = 0), "p" in s && (s.H = s.H % 12 + 12 * s.p), void 0 === s.m && (s.m = "q" in s ? s.q : 0), "V" in s) {
                        if (s.V < 1 || s.V > 53) return null;
                        "w" in s || (s.w = 1), "Z" in s ? (r = (i = rr(sr(s.y, 0, 1))).getUTCDay(), i = r > 4 || 0 === r ? Gi.ceil(i) : Gi(i), i = er.offset(i, 7 * (s.V - 1)), s.y = i.getUTCFullYear(), s.m = i.getUTCMonth(), s.d = i.getUTCDate() + (s.w + 6) % 7) : (r = (i = ir(sr(s.y, 0, 1))).getDay(), i = r > 4 || 0 === r ? Pi.ceil(i) : Pi(i), i = Fi.offset(i, 7 * (s.V - 1)), s.y = i.getFullYear(), s.m = i.getMonth(), s.d = i.getDate() + (s.w + 6) % 7)
                    } else("W" in s || "U" in s) && ("w" in s || (s.w = "u" in s ? s.u % 7 : "W" in s ? 1 : 0), r = "Z" in s ? rr(sr(s.y, 0, 1)).getUTCDay() : ir(sr(s.y, 0, 1)).getDay(), s.m = 0, s.d = "W" in s ? (s.w + 6) % 7 + 7 * s.W - (r + 5) % 7 : s.w + 7 * s.U - (r + 6) % 7);
                    return "Z" in s ? (s.H += s.Z / 100 | 0, s.M += s.Z % 100, rr(s)) : ir(s)
                }
            }

            function S(e, t, n, i) {
                for (var r, s, o = 0, a = t.length, c = n.length; o < a;) {
                    if (i >= c) return -1;
                    if (37 === (r = t.charCodeAt(o++))) {
                        if (r = t.charAt(o++), !(s = k[r in ar ? t.charAt(o++) : r]) || (i = s(e, n, i)) < 0) return -1
                    } else if (r != n.charCodeAt(i++)) return -1
                }
                return i
            }
            return y.x = x(n, y), y.X = x(i, y), y.c = x(t, y), w.x = x(n, w), w.X = x(i, w), w.c = x(t, w), {
                format: function(e) {
                    var t = x(e += "", y);
                    return t.toString = function() {
                        return e
                    }, t
                },
                parse: function(e) {
                    var t = _(e += "", !1);
                    return t.toString = function() {
                        return e
                    }, t
                },
                utcFormat: function(e) {
                    var t = x(e += "", w);
                    return t.toString = function() {
                        return e
                    }, t
                },
                utcParse: function(e) {
                    var t = _(e += "", !0);
                    return t.toString = function() {
                        return e
                    }, t
                }
            }
        }(e), or.format, or.parse, or.utcFormat, or.utcParse
    }({
        dateTime: "%x, %X",
        date: "%-m/%-d/%Y",
        time: "%-I:%M:%S %p",
        periods: ["AM", "PM"],
        days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
        shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
        months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
        shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
    });
    var Ss = Ai((function(e) {
            e.setUTCDate(1), e.setUTCHours(0, 0, 0, 0)
        }), (function(e, t) {
            e.setUTCMonth(e.getUTCMonth() + t)
        }), (function(e, t) {
            return t.getUTCMonth() - e.getUTCMonth() + 12 * (t.getUTCFullYear() - e.getUTCFullYear())
        }), (function(e) {
            return e.getUTCMonth()
        })),
        Os = (Ss.range, Ai((function(e) {
            e.setUTCMinutes(0, 0, 0)
        }), (function(e, t) {
            e.setTime(+e + 36e5 * t)
        }), (function(e, t) {
            return (t - e) / 36e5
        }), (function(e) {
            return e.getUTCHours()
        }))),
        Cs = (Os.range, Ai((function(e) {
            e.setUTCSeconds(0, 0)
        }), (function(e, t) {
            e.setTime(+e + 6e4 * t)
        }), (function(e, t) {
            return (t - e) / 6e4
        }), (function(e) {
            return e.getUTCMinutes()
        })));
    Cs.range;
    var As = function(e) {
            return function() {
                return e
            }
        },
        Ts = Math.abs,
        Es = Math.atan2,
        js = Math.cos,
        Ms = Math.max,
        Ls = Math.min,
        Ps = Math.sin,
        Rs = Math.sqrt,
        Is = Math.PI,
        Ds = Is / 2,
        Ns = 2 * Is;

    function Vs(e) {
        return e > 1 ? 0 : e < -1 ? Is : Math.acos(e)
    }

    function $s(e) {
        return e >= 1 ? Ds : e <= -1 ? -Ds : Math.asin(e)
    }

    function Fs(e) {
        return e.innerRadius
    }

    function Us(e) {
        return e.outerRadius
    }

    function Bs(e) {
        return e.startAngle
    }

    function zs(e) {
        return e.endAngle
    }

    function Hs(e) {
        return e && e.padAngle
    }

    function Ws(e, t, n, i, r, s, o, a) {
        var c = n - e,
            l = i - t,
            u = o - r,
            h = a - s,
            d = h * c - u * l;
        if (!(d * d < 1e-12)) return [e + (d = (u * (t - s) - h * (e - r)) / d) * c, t + d * l]
    }

    function qs(e, t, n, i, r, s, o) {
        var a = e - n,
            c = t - i,
            l = (o ? s : -s) / Rs(a * a + c * c),
            u = l * c,
            h = -l * a,
            d = e + u,
            p = t + h,
            f = n + u,
            g = i + h,
            m = (d + f) / 2,
            v = (p + g) / 2,
            b = f - d,
            y = g - p,
            w = b * b + y * y,
            k = r - s,
            x = d * g - f * p,
            _ = (y < 0 ? -1 : 1) * Rs(Ms(0, k * k * w - x * x)),
            S = (x * y - b * _) / w,
            O = (-x * b - y * _) / w,
            C = (x * y + b * _) / w,
            A = (-x * b + y * _) / w,
            T = S - m,
            E = O - v,
            j = C - m,
            M = A - v;
        return T * T + E * E > j * j + M * M && (S = C, O = A), {
            cx: S,
            cy: O,
            x01: -u,
            y01: -h,
            x11: S * (r / k - 1),
            y11: O * (r / k - 1)
        }
    }

    function Gs() {
        this._ = null
    }

    function Ks(e) {
        e.U = e.C = e.L = e.R = e.P = e.N = null
    }

    function Ys(e, t) {
        var n = t,
            i = t.R,
            r = n.U;
        r ? r.L === n ? r.L = i : r.R = i : e._ = i, i.U = r, n.U = i, n.R = i.L, n.R && (n.R.U = n), i.L = n
    }

    function Xs(e, t) {
        var n = t,
            i = t.L,
            r = n.U;
        r ? r.L === n ? r.L = i : r.R = i : e._ = i, i.U = r, n.U = i, n.L = i.R, n.L && (n.L.U = n), i.R = n
    }

    function Js(e) {
        for (; e.L;) e = e.L;
        return e
    }
    Gs.prototype = {
        constructor: Gs,
        insert: function(e, t) {
            var n, i, r;
            if (e) {
                if (t.P = e, t.N = e.N, e.N && (e.N.P = t), e.N = t, e.R) {
                    for (e = e.R; e.L;) e = e.L;
                    e.L = t
                } else e.R = t;
                n = e
            } else this._ ? (e = Js(this._), t.P = null, t.N = e, e.P = e.L = t, n = e) : (t.P = t.N = null, this._ = t, n = null);
            for (t.L = t.R = null, t.U = n, t.C = !0, e = t; n && n.C;) n === (i = n.U).L ? (r = i.R) && r.C ? (n.C = r.C = !1, i.C = !0, e = i) : (e === n.R && (Ys(this, n), n = (e = n).U), n.C = !1, i.C = !0, Xs(this, i)) : (r = i.L) && r.C ? (n.C = r.C = !1, i.C = !0, e = i) : (e === n.L && (Xs(this, n), n = (e = n).U), n.C = !1, i.C = !0, Ys(this, i)), n = e.U;
            this._.C = !1
        },
        remove: function(e) {
            e.N && (e.N.P = e.P), e.P && (e.P.N = e.N), e.N = e.P = null;
            var t, n, i, r = e.U,
                s = e.L,
                o = e.R;
            if (n = s ? o ? Js(o) : s : o, r ? r.L === e ? r.L = n : r.R = n : this._ = n, s && o ? (i = n.C, n.C = e.C, n.L = s, s.U = n, n !== o ? (r = n.U, n.U = e.U, e = n.R, r.L = e, n.R = o, o.U = n) : (n.U = r, r = n, e = n.R)) : (i = e.C, e = n), e && (e.U = r), !i)
                if (e && e.C) e.C = !1;
                else {
                    do {
                        if (e === this._) break;
                        if (e === r.L) {
                            if ((t = r.R).C && (t.C = !1, r.C = !0, Ys(this, r), t = r.R), t.L && t.L.C || t.R && t.R.C) {
                                t.R && t.R.C || (t.L.C = !1, t.C = !0, Xs(this, t), t = r.R), t.C = r.C, r.C = t.R.C = !1, Ys(this, r), e = this._;
                                break
                            }
                        } else if ((t = r.L).C && (t.C = !1, r.C = !0, Xs(this, r), t = r.L), t.L && t.L.C || t.R && t.R.C) {
                            t.L && t.L.C || (t.R.C = !1, t.C = !0, Ys(this, t), t = r.L), t.C = r.C, r.C = t.L.C = !1, Xs(this, r), e = this._;
                            break
                        }
                        t.C = !0, e = r, r = r.U
                    } while (!e.C);
                    e && (e.C = !1)
                }
        }
    };
    var Qs = Gs;

    function Zs(e, t, n, i) {
        var r = [null, null],
            s = So.push(r) - 1;
        return r.left = e, r.right = t, n && to(r, e, t, n), i && to(r, t, e, i), xo[e.index].halfedges.push(s), xo[t.index].halfedges.push(s), r
    }

    function eo(e, t, n) {
        var i = [t, n];
        return i.left = e, i
    }

    function to(e, t, n, i) {
        e[0] || e[1] ? e.left === n ? e[1] = i : e[0] = i : (e[0] = i, e.left = t, e.right = n)
    }

    function no(e, t, n, i, r) {
        var s, o = e[0],
            a = e[1],
            c = o[0],
            l = o[1],
            u = 0,
            h = 1,
            d = a[0] - c,
            p = a[1] - l;
        if (s = t - c, d || !(s > 0)) {
            if (s /= d, d < 0) {
                if (s < u) return;
                s < h && (h = s)
            } else if (d > 0) {
                if (s > h) return;
                s > u && (u = s)
            }
            if (s = i - c, d || !(s < 0)) {
                if (s /= d, d < 0) {
                    if (s > h) return;
                    s > u && (u = s)
                } else if (d > 0) {
                    if (s < u) return;
                    s < h && (h = s)
                }
                if (s = n - l, p || !(s > 0)) {
                    if (s /= p, p < 0) {
                        if (s < u) return;
                        s < h && (h = s)
                    } else if (p > 0) {
                        if (s > h) return;
                        s > u && (u = s)
                    }
                    if (s = r - l, p || !(s < 0)) {
                        if (s /= p, p < 0) {
                            if (s > h) return;
                            s > u && (u = s)
                        } else if (p > 0) {
                            if (s < u) return;
                            s < h && (h = s)
                        }
                        return !(u > 0 || h < 1) || (u > 0 && (e[0] = [c + u * d, l + u * p]), h < 1 && (e[1] = [c + h * d, l + h * p]), !0)
                    }
                }
            }
        }
    }

    function io(e, t, n, i, r) {
        var s = e[1];
        if (s) return !0;
        var o, a, c = e[0],
            l = e.left,
            u = e.right,
            h = l[0],
            d = l[1],
            p = u[0],
            f = u[1],
            g = (h + p) / 2,
            m = (d + f) / 2;
        if (f === d) {
            if (g < t || g >= i) return;
            if (h > p) {
                if (c) {
                    if (c[1] >= r) return
                } else c = [g, n];
                s = [g, r]
            } else {
                if (c) {
                    if (c[1] < n) return
                } else c = [g, r];
                s = [g, n]
            }
        } else if (a = m - (o = (h - p) / (f - d)) * g, o < -1 || o > 1)
            if (h > p) {
                if (c) {
                    if (c[1] >= r) return
                } else c = [(n - a) / o, n];
                s = [(r - a) / o, r]
            } else {
                if (c) {
                    if (c[1] < n) return
                } else c = [(r - a) / o, r];
                s = [(n - a) / o, n]
            }
        else if (d < f) {
            if (c) {
                if (c[0] >= i) return
            } else c = [t, o * t + a];
            s = [i, o * i + a]
        } else {
            if (c) {
                if (c[0] < t) return
            } else c = [i, o * i + a];
            s = [t, o * t + a]
        }
        return e[0] = c, e[1] = s, !0
    }

    function ro(e, t) {
        var n = e.site,
            i = t.left,
            r = t.right;
        return n === r && (r = i, i = n), r ? Math.atan2(r[1] - i[1], r[0] - i[0]) : (n === i ? (i = t[1], r = t[0]) : (i = t[0], r = t[1]), Math.atan2(i[0] - r[0], r[1] - i[1]))
    }

    function so(e, t) {
        return t[+(t.left !== e.site)]
    }

    function oo(e, t) {
        return t[+(t.left === e.site)]
    }
    var ao, co = [];

    function lo() {
        Ks(this), this.x = this.y = this.arc = this.site = this.cy = null
    }

    function uo(e) {
        var t = e.P,
            n = e.N;
        if (t && n) {
            var i = t.site,
                r = e.site,
                s = n.site;
            if (i !== s) {
                var o = r[0],
                    a = r[1],
                    c = i[0] - o,
                    l = i[1] - a,
                    u = s[0] - o,
                    h = s[1] - a,
                    d = 2 * (c * h - l * u);
                if (!(d >= -Co)) {
                    var p = c * c + l * l,
                        f = u * u + h * h,
                        g = (h * p - l * f) / d,
                        m = (c * f - u * p) / d,
                        v = co.pop() || new lo;
                    v.arc = e, v.site = r, v.x = g + o, v.y = (v.cy = m + a) + Math.sqrt(g * g + m * m), e.circle = v;
                    for (var b = null, y = _o._; y;)
                        if (v.y < y.y || v.y === y.y && v.x <= y.x) {
                            if (!y.L) {
                                b = y.P;
                                break
                            }
                            y = y.L
                        } else {
                            if (!y.R) {
                                b = y;
                                break
                            }
                            y = y.R
                        } _o.insert(b, v), b || (ao = v)
                }
            }
        }
    }

    function ho(e) {
        var t = e.circle;
        t && (t.P || (ao = t.N), _o.remove(t), co.push(t), Ks(t), e.circle = null)
    }
    var po = [];

    function fo() {
        Ks(this), this.edge = this.site = this.circle = null
    }

    function go(e) {
        var t = po.pop() || new fo;
        return t.site = e, t
    }

    function mo(e) {
        ho(e), ko.remove(e), po.push(e), Ks(e)
    }

    function vo(e) {
        var t = e.circle,
            n = t.x,
            i = t.cy,
            r = [n, i],
            s = e.P,
            o = e.N,
            a = [e];
        mo(e);
        for (var c = s; c.circle && Math.abs(n - c.circle.x) < Oo && Math.abs(i - c.circle.cy) < Oo;) s = c.P, a.unshift(c), mo(c), c = s;
        a.unshift(c), ho(c);
        for (var l = o; l.circle && Math.abs(n - l.circle.x) < Oo && Math.abs(i - l.circle.cy) < Oo;) o = l.N, a.push(l), mo(l), l = o;
        a.push(l), ho(l);
        var u, h = a.length;
        for (u = 1; u < h; ++u) l = a[u], c = a[u - 1], to(l.edge, c.site, l.site, r);
        c = a[0], (l = a[h - 1]).edge = Zs(c.site, l.site, null, r), uo(c), uo(l)
    }

    function bo(e) {
        for (var t, n, i, r, s = e[0], o = e[1], a = ko._; a;)
            if ((i = yo(a, o) - s) > Oo) a = a.L;
            else {
                if (!((r = s - wo(a, o)) > Oo)) {
                    i > -Oo ? (t = a.P, n = a) : r > -Oo ? (t = a, n = a.N) : t = n = a;
                    break
                }
                if (!a.R) {
                    t = a;
                    break
                }
                a = a.R
            }!
        function(e) {
            xo[e.index] = {
                site: e,
                halfedges: []
            }
        }(e);
        var c = go(e);
        if (ko.insert(t, c), t || n) {
            if (t === n) return ho(t), n = go(t.site), ko.insert(c, n), c.edge = n.edge = Zs(t.site, c.site), uo(t), void uo(n);
            if (n) {
                ho(t), ho(n);
                var l = t.site,
                    u = l[0],
                    h = l[1],
                    d = e[0] - u,
                    p = e[1] - h,
                    f = n.site,
                    g = f[0] - u,
                    m = f[1] - h,
                    v = 2 * (d * m - p * g),
                    b = d * d + p * p,
                    y = g * g + m * m,
                    w = [(m * b - p * y) / v + u, (d * y - g * b) / v + h];
                to(n.edge, l, f, w), c.edge = Zs(l, e, null, w), n.edge = Zs(e, f, null, w), uo(t), uo(n)
            } else c.edge = Zs(t.site, c.site)
        }
    }

    function yo(e, t) {
        var n = e.site,
            i = n[0],
            r = n[1],
            s = r - t;
        if (!s) return i;
        var o = e.P;
        if (!o) return -1 / 0;
        var a = (n = o.site)[0],
            c = n[1],
            l = c - t;
        if (!l) return a;
        var u = a - i,
            h = 1 / s - 1 / l,
            d = u / l;
        return h ? (-d + Math.sqrt(d * d - 2 * h * (u * u / (-2 * l) - c + l / 2 + r - s / 2))) / h + i : (i + a) / 2
    }

    function wo(e, t) {
        var n = e.N;
        if (n) return yo(n, t);
        var i = e.site;
        return i[1] === t ? i[0] : 1 / 0
    }
    var ko, xo, _o, So, Oo = 1e-6,
        Co = 1e-12;

    function Ao(e, t) {
        return t[1] - e[1] || t[0] - e[0]
    }

    function To(e, t) {
        var n, i, r, s = e.sort(Ao).pop();
        for (So = [], xo = new Array(e.length), ko = new Qs, _o = new Qs;;)
            if (r = ao, s && (!r || s[1] < r.y || s[1] === r.y && s[0] < r.x)) s[0] === n && s[1] === i || (bo(s), n = s[0], i = s[1]), s = e.pop();
            else {
                if (!r) break;
                vo(r.arc)
            } if (function() {
                for (var e, t, n, i, r = 0, s = xo.length; r < s; ++r)
                    if ((e = xo[r]) && (i = (t = e.halfedges).length)) {
                        var o = new Array(i),
                            a = new Array(i);
                        for (n = 0; n < i; ++n) o[n] = n, a[n] = ro(e, So[t[n]]);
                        for (o.sort((function(e, t) {
                                return a[t] - a[e]
                            })), n = 0; n < i; ++n) a[n] = t[o[n]];
                        for (n = 0; n < i; ++n) t[n] = a[n]
                    }
            }(), t) {
            var o = +t[0][0],
                a = +t[0][1],
                c = +t[1][0],
                l = +t[1][1];
            ! function(e, t, n, i) {
                for (var r, s = So.length; s--;) io(r = So[s], e, t, n, i) && no(r, e, t, n, i) && (Math.abs(r[0][0] - r[1][0]) > Oo || Math.abs(r[0][1] - r[1][1]) > Oo) || delete So[s]
            }(o, a, c, l),
            function(e, t, n, i) {
                var r, s, o, a, c, l, u, h, d, p, f, g, m = xo.length,
                    v = !0;
                for (r = 0; r < m; ++r)
                    if (s = xo[r]) {
                        for (o = s.site, a = (c = s.halfedges).length; a--;) So[c[a]] || c.splice(a, 1);
                        for (a = 0, l = c.length; a < l;) f = (p = oo(s, So[c[a]]))[0], g = p[1], h = (u = so(s, So[c[++a % l]]))[0], d = u[1], (Math.abs(f - h) > Oo || Math.abs(g - d) > Oo) && (c.splice(a, 0, So.push(eo(o, p, Math.abs(f - e) < Oo && i - g > Oo ? [e, Math.abs(h - e) < Oo ? d : i] : Math.abs(g - i) < Oo && n - f > Oo ? [Math.abs(d - i) < Oo ? h : n, i] : Math.abs(f - n) < Oo && g - t > Oo ? [n, Math.abs(h - n) < Oo ? d : t] : Math.abs(g - t) < Oo && f - e > Oo ? [Math.abs(d - t) < Oo ? h : e, t] : null)) - 1), ++l);
                        l && (v = !1)
                    } if (v) {
                    var b, y, w, k = 1 / 0;
                    for (r = 0, v = null; r < m; ++r)(s = xo[r]) && (w = (b = (o = s.site)[0] - e) * b + (y = o[1] - t) * y) < k && (k = w, v = s);
                    if (v) {
                        var x = [e, t],
                            _ = [e, i],
                            S = [n, i],
                            O = [n, t];
                        v.halfedges.push(So.push(eo(o = v.site, x, _)) - 1, So.push(eo(o, _, S)) - 1, So.push(eo(o, S, O)) - 1, So.push(eo(o, O, x)) - 1)
                    }
                }
                for (r = 0; r < m; ++r)(s = xo[r]) && (s.halfedges.length || delete xo[r])
            }(o, a, c, l)
        }
        this.edges = So, this.cells = xo, ko = _o = So = xo = null
    }
    To.prototype = {
        constructor: To,
        polygons: function() {
            var e = this.edges;
            return this.cells.map((function(t) {
                var n = t.halfedges.map((function(n) {
                    return so(t, e[n])
                }));
                return n.data = t.site.data, n
            }))
        },
        triangles: function() {
            var e = [],
                t = this.edges;
            return this.cells.forEach((function(n, i) {
                if (s = (r = n.halfedges).length)
                    for (var r, s, o, a, c, l, u = n.site, h = -1, d = t[r[s - 1]], p = d.left === u ? d.right : d.left; ++h < s;) o = p, p = (d = t[r[h]]).left === u ? d.right : d.left, o && p && i < o.index && i < p.index && (c = o, l = p, ((a = u)[0] - l[0]) * (c[1] - a[1]) - (a[0] - c[0]) * (l[1] - a[1]) < 0) && e.push([u.data, o.data, p.data])
            })), e
        },
        links: function() {
            return this.edges.filter((function(e) {
                return e.right
            })).map((function(e) {
                return {
                    source: e.left.data,
                    target: e.right.data
                }
            }))
        },
        find: function(e, t, n) {
            for (var i, r, s = this, o = s._found || 0, a = s.cells.length; !(r = s.cells[o]);)
                if (++o >= a) return null;
            var c = e - r.site[0],
                l = t - r.site[1],
                u = c * c + l * l;
            do {
                r = s.cells[i = o], o = null, r.halfedges.forEach((function(n) {
                    var i = s.edges[n],
                        a = i.left;
                    if (a !== r.site && a || (a = i.right)) {
                        var c = e - a[0],
                            l = t - a[1],
                            h = c * c + l * l;
                        h < u && (u = h, o = a.index)
                    }
                }))
            } while (null !== o);
            return s._found = i, null == n || u <= n * n ? r.site : null
        }
    };
    Math.SQRT2;

    function Eo(e, t, n) {
        this.k = e, this.x = t, this.y = n
    }
    Eo.prototype = {
        constructor: Eo,
        scale: function(e) {
            return 1 === e ? this : new Eo(this.k * e, this.x, this.y)
        },
        translate: function(e, t) {
            return 0 === e & 0 === t ? this : new Eo(this.k, this.x + this.k * e, this.y + this.k * t)
        },
        apply: function(e) {
            return [e[0] * this.k + this.x, e[1] * this.k + this.y]
        },
        applyX: function(e) {
            return e * this.k + this.x
        },
        applyY: function(e) {
            return e * this.k + this.y
        },
        invert: function(e) {
            return [(e[0] - this.x) / this.k, (e[1] - this.y) / this.k]
        },
        invertX: function(e) {
            return (e - this.x) / this.k
        },
        invertY: function(e) {
            return (e - this.y) / this.k
        },
        rescaleX: function(e) {
            return e.copy().domain(e.range().map(this.invertX, this).map(e.invert, e))
        },
        rescaleY: function(e) {
            return e.copy().domain(e.range().map(this.invertY, this).map(e.invert, e))
        },
        toString: function() {
            return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")"
        }
    };
    new Eo(1, 0, 0);
    Eo.prototype;

    function jo(e, t) {
        return e.each((function() {
            var e = t.apply(this, arguments),
                n = Ae(this);
            for (var i in e) n.attr(i, e[i])
        }))
    }

    function Mo(e, t) {
        for (var n in t) e.attr(n, t[n]);
        return e
    }

    function Lo(e, t, n) {
        return e.each((function() {
            var e = t.apply(this, arguments),
                i = Ae(this);
            for (var r in e) i.style(r, e[r], n)
        }))
    }

    function Po(e, t, n) {
        for (var i in t) e.style(i, t[i], n);
        return e
    }

    function Ro(e, t) {
        return e.each((function() {
            var e = t.apply(this, arguments),
                n = Ae(this);
            for (var i in e) n.property(i, e[i])
        }))
    }

    function Io(e, t) {
        for (var n in t) e.property(n, t[n]);
        return e
    }

    function Do(e, t) {
        return e.each((function() {
            var n = t.apply(this, arguments),
                i = Ae(this).transition(e);
            for (var r in n) i.attr(r, n[r])
        }))
    }

    function No(e, t) {
        for (var n in t) e.attr(n, t[n]);
        return e
    }

    function Vo(e, t, n) {
        return e.each((function() {
            var i = t.apply(this, arguments),
                r = Ae(this).transition(e);
            for (var s in i) r.style(s, i[s], n)
        }))
    }

    function $o(e, t, n) {
        for (var i in t) e.style(i, t[i], n);
        return e
    }
    var Fo;
    Ce.prototype.attrs = function(e) {
        return ("function" == typeof e ? jo : Mo)(this, e)
    }, Ce.prototype.styles = function(e, t) {
        return ("function" == typeof e ? Lo : Po)(this, e, null == t ? "" : t)
    }, Ce.prototype.properties = function(e) {
        return ("function" == typeof e ? Ro : Io)(this, e)
    }, Pn.prototype.attrs = function(e) {
        return ("function" == typeof e ? Do : No)(this, e)
    }, Pn.prototype.styles = function(e, t) {
        return ("function" == typeof e ? Vo : $o)(this, e, null == t ? "" : t)
    };
    const Uo = {
        linear: function(e) {
            return +e
        },
        bounce: ei
    };

    function Bo(e, t, n = 0, i = 0, r = 0) {
        return t = t || 100, r = r || 0, n = n || 360, i = i || 0, Math.PI / 180 * ((e - r) * (n - i) / (t - r) + i)
    }

    function zo(e, t, n = 0, i = 360, r = 0) {
        return function() {
            var e = Fs,
                t = Us,
                n = As(0),
                i = null,
                r = Bs,
                s = zs,
                o = Hs,
                a = null;

            function c() {
                var c, l, u = +e.apply(this, arguments),
                    h = +t.apply(this, arguments),
                    d = r.apply(this, arguments) - Ds,
                    p = s.apply(this, arguments) - Ds,
                    f = Ts(p - d),
                    g = p > d;
                if (a || (a = c = qn()), h < u && (l = h, h = u, u = l), h > 1e-12)
                    if (f > Ns - 1e-12) a.moveTo(h * js(d), h * Ps(d)), a.arc(0, 0, h, d, p, !g), u > 1e-12 && (a.moveTo(u * js(p), u * Ps(p)), a.arc(0, 0, u, p, d, g));
                    else {
                        var m, v, b = d,
                            y = p,
                            w = d,
                            k = p,
                            x = f,
                            _ = f,
                            S = o.apply(this, arguments) / 2,
                            O = S > 1e-12 && (i ? +i.apply(this, arguments) : Rs(u * u + h * h)),
                            C = Ls(Ts(h - u) / 2, +n.apply(this, arguments)),
                            A = C,
                            T = C;
                        if (O > 1e-12) {
                            var E = $s(O / u * Ps(S)),
                                j = $s(O / h * Ps(S));
                            (x -= 2 * E) > 1e-12 ? (w += E *= g ? 1 : -1, k -= E) : (x = 0, w = k = (d + p) / 2), (_ -= 2 * j) > 1e-12 ? (b += j *= g ? 1 : -1, y -= j) : (_ = 0, b = y = (d + p) / 2)
                        }
                        var M = h * js(b),
                            L = h * Ps(b),
                            P = u * js(k),
                            R = u * Ps(k);
                        if (C > 1e-12) {
                            var I, D = h * js(y),
                                N = h * Ps(y),
                                V = u * js(w),
                                $ = u * Ps(w);
                            if (f < Is && (I = Ws(M, L, V, $, D, N, P, R))) {
                                var F = M - I[0],
                                    U = L - I[1],
                                    B = D - I[0],
                                    z = N - I[1],
                                    H = 1 / Ps(Vs((F * B + U * z) / (Rs(F * F + U * U) * Rs(B * B + z * z))) / 2),
                                    W = Rs(I[0] * I[0] + I[1] * I[1]);
                                A = Ls(C, (u - W) / (H - 1)), T = Ls(C, (h - W) / (H + 1))
                            }
                        }
                        _ > 1e-12 ? T > 1e-12 ? (m = qs(V, $, M, L, h, T, g), v = qs(D, N, P, R, h, T, g), a.moveTo(m.cx + m.x01, m.cy + m.y01), T < C ? a.arc(m.cx, m.cy, T, Es(m.y01, m.x01), Es(v.y01, v.x01), !g) : (a.arc(m.cx, m.cy, T, Es(m.y01, m.x01), Es(m.y11, m.x11), !g), a.arc(0, 0, h, Es(m.cy + m.y11, m.cx + m.x11), Es(v.cy + v.y11, v.cx + v.x11), !g), a.arc(v.cx, v.cy, T, Es(v.y11, v.x11), Es(v.y01, v.x01), !g))) : (a.moveTo(M, L), a.arc(0, 0, h, b, y, !g)) : a.moveTo(M, L), u > 1e-12 && x > 1e-12 ? A > 1e-12 ? (m = qs(P, R, D, N, u, -A, g), v = qs(M, L, V, $, u, -A, g), a.lineTo(m.cx + m.x01, m.cy + m.y01), A < C ? a.arc(m.cx, m.cy, A, Es(m.y01, m.x01), Es(v.y01, v.x01), !g) : (a.arc(m.cx, m.cy, A, Es(m.y01, m.x01), Es(m.y11, m.x11), !g), a.arc(0, 0, u, Es(m.cy + m.y11, m.cx + m.x11), Es(v.cy + v.y11, v.cx + v.x11), g), a.arc(v.cx, v.cy, A, Es(v.y11, v.x11), Es(v.y01, v.x01), !g))) : a.arc(0, 0, u, k, w, g) : a.lineTo(P, R)
                    }
                else a.moveTo(0, 0);
                if (a.closePath(), c) return a = null, c + "" || null
            }
            return c.centroid = function() {
                var n = (+e.apply(this, arguments) + +t.apply(this, arguments)) / 2,
                    i = (+r.apply(this, arguments) + +s.apply(this, arguments)) / 2 - Is / 2;
                return [js(i) * n, Ps(i) * n]
            }, c.innerRadius = function(t) {
                return arguments.length ? (e = "function" == typeof t ? t : As(+t), c) : e
            }, c.outerRadius = function(e) {
                return arguments.length ? (t = "function" == typeof e ? e : As(+e), c) : t
            }, c.cornerRadius = function(e) {
                return arguments.length ? (n = "function" == typeof e ? e : As(+e), c) : n
            }, c.padRadius = function(e) {
                return arguments.length ? (i = null == e ? null : "function" == typeof e ? e : As(+e), c) : i
            }, c.startAngle = function(e) {
                return arguments.length ? (r = "function" == typeof e ? e : As(+e), c) : r
            }, c.endAngle = function(e) {
                return arguments.length ? (s = "function" == typeof e ? e : As(+e), c) : s
            }, c.padAngle = function(e) {
                return arguments.length ? (o = "function" == typeof e ? e : As(+e), c) : o
            }, c.context = function(e) {
                return arguments.length ? (a = null == e ? null : e, c) : a
            }, c
        }().innerRadius(e).outerRadius(t).startAngle(n).endAngle(i).cornerRadius(r)
    }
    let Ho = Fo = class {
        constructor(e) {
            this.element = e, this.value = 0, this.options = Fo.defaultOptions, this.step = 1, this.min = 0, this.max = 100, this.readonly = !1, this.label = null, this.inDrag = !1, this.guard = !1
        }
        attached() {
            this.draw()
        }
        draw() {
            const e = window.getComputedStyle(this.element);
            if (this.startAngle = parseInt(e.getPropertyValue("--ua-knob-start-angle")) || -150, this.endAngle = parseInt(e.getPropertyValue("--ua-knob-end-angle")) || 150, this.size = parseInt(e.getPropertyValue("--ua-knob-size")) || 48, this.trackWidth = parseInt(e.getPropertyValue("--ua-knob-track-size")) || 10, this.trackCap = parseInt(e.getPropertyValue("--ua-knob-track-radius")) || 0, this.barWidth = parseInt(e.getPropertyValue("--ua-knob-indicator-size")) || 6, this.barCap = parseInt(e.getPropertyValue("--ua-knob-track-radius")) || 0, this.fontSize = e.getPropertyValue("font-size"), this.fontWeight = e.getPropertyValue("font-weight"), this.fontFamily = e.getPropertyPriority("font-family"), this.backgroundColor = e.getPropertyValue("--ua-knob-background") || "transparent", this.normalizedOptions = Object.assign({}, Fo.defaultOptions, this.options), this.guard) return;
            Ae(this.element).select("svg").remove();
            const t = this;
            t.createArcs();
            t.drawArcs((function() {
                t.inDrag = !1;
                const e = St(this.parentNode),
                    n = e[0] - t.size / 2,
                    i = e[1] - t.size / 2;
                t.interaction(n, i, !0)
            }), (function() {})), t.normalizedOptions.animation && t.normalizedOptions.animation.enabled ? t.valueElem.transition().ease(Uo[t.normalizedOptions.animation.ease]).duration(t.normalizedOptions.animation.duration).tween("", (function() {
                const e = kt(Bo(t.startAngle, 360), Bo(t.value, t.max, t.endAngle, t.startAngle, t.min));
                return function(n) {
                    const i = e(n);
                    t.valueElem.attr("d", t.valueArc.endAngle(i)), t.changeElem.attr("d", t.changeArc.endAngle(i))
                }
            })) : (t.changeArc.endAngle(Bo(this.value, this.max, this.endAngle, this.startAngle, this.min)), t.changeElem.attr("d", t.changeArc), t.valueArc.endAngle(Bo(this.value, this.max, this.endAngle, this.startAngle, this.min)), t.valueElem.attr("d", t.valueArc))
        }
        drawArc(e, t, n, i, r, s) {
            const o = e.append("path").attr("id", n).attr("d", t);
            for (const e in i) o.style(e, i[e]);
            return o.attr("transform", "translate(" + this.size / 2 + ", " + this.size / 2 + ")"), !1 === this.readonly && (r && o.on("click", r), s && o.call(s)), o
        }
        createArcs() {
            let e = parseInt((this.size / 2).toString(), 10);
            const t = Bo(this.startAngle, 360),
                n = Bo(this.endAngle, 360);
            this.normalizedOptions.scale.enabled && (e -= this.normalizedOptions.scale.width + this.normalizedOptions.scale.spaceWidth);
            let i = e - this.trackWidth,
                r = e - this.barWidth,
                s = e - this.barWidth;
            let o, a = e,
                c = e,
                l = e,
                u = e;
            this.barWidth > this.trackWidth ? (o = (this.barWidth - this.trackWidth) / 2, i -= o, a -= o) : this.barWidth < this.trackWidth && (o = (this.trackWidth - this.barWidth) / 2, c -= o, l -= o, r -= o, s -= o), "transparent" !== this.backgroundColor && (this.normalizedOptions.background.full ? this.bgArc = zo(0, e, 0, 2 * Math.PI) : this.bgArc = zo(0, e, t, n)), this.normalizedOptions.skin && "tron" === this.normalizedOptions.skin.type && (a = a - this.normalizedOptions.skin.width - this.normalizedOptions.skin.spaceWidth, c = c - this.normalizedOptions.skin.width - this.normalizedOptions.skin.spaceWidth, l = l - this.normalizedOptions.skin.width - this.normalizedOptions.skin.spaceWidth, u = u - this.normalizedOptions.skin.width - this.normalizedOptions.skin.spaceWidth, this.hoopArc = zo(e - this.normalizedOptions.skin.width, e, t, n)), this.trackArc = zo(i, a, t, n, this.trackCap), this.changeArc = zo(r, c, t, t, this.barCap), this.valueArc = zo(s, l, t, t, this.barCap), this.interactArc = zo(1, u, t, n)
        }
        drawArcs(e, t) {
            let n = "";
            const i = Ae(this.element).append("svg").attr("width", this.size).attr("height", this.size);
            if ("transparent" !== this.backgroundColor && this.drawArc(i, this.bgArc, "bgArc", {
                    fill: this.backgroundColor
                }), this.normalizedOptions.displayInput) {
                let e = .2 * this.size + "px";
                "auto" !== this.fontSize && (e = this.fontSize + "px"), this.step < 1 && (this.value = Number(this.value.toFixed(1)));
                let t = this.label || this.value;
                "function" == typeof this.normalizedOptions.inputFormatter && (t = this.normalizedOptions.inputFormatter(t)), "Arial" !== this.fontFamily && (n = this.fontFamily);
                let r = "";
                if ("400" !== this.fontWeight && (r = this.fontWeight), i.append("text").attr("id", "text").attr("class", "text-value").attr("text-anchor", "middle").attr("font-size", e).attr("font-weight", r).attr("font-family", n).style("fill", "var(--ua-knob-text-color, #222)").text(t + this.normalizedOptions.unit || "").attr("transform", "translate(" + this.size / 2 + ", " + (this.size / 2 + .06 * this.size) + ")"), this.normalizedOptions.subText.enabled) {
                    e = .07 * this.size + "px", "auto" !== this.normalizedOptions.subText.fontSize && (e = this.normalizedOptions.subText.fontSize + "px"), "Arial" !== this.normalizedOptions.subText.fontFamily && (n = this.normalizedOptions.subText.fontFamily);
                    let t = "";
                    "normal" !== this.normalizedOptions.subText.fontWeight && (t = this.normalizedOptions.subText.fontWeight), i.append("text").attr("class", "sub-text").attr("text-anchor", "middle").attr("font-size", e).attr("font-family", n).attr("font-weight", t).style("fill", "var(--ua-knob-subtext-color, gray)").text(this.normalizedOptions.subText.text).attr("transform", "translate(" + this.size / 2 + ", " + (this.size / 2 + .15 * this.size + this.normalizedOptions.subText.offset) + ")")
                }
            }
            if (this.normalizedOptions.scale.enabled) {
                let e, t, n, r = 0,
                    s = 0;
                const o = Bo(this.min, this.max, this.endAngle, this.startAngle, this.min),
                    a = Bo(this.max, this.max, this.endAngle, this.startAngle, this.min);
                let c = 0;
                if (0 === this.startAngle && 360 === this.endAngle || (c = 1), "dots" === this.normalizedOptions.scale.type) {
                    const u = this.normalizedOptions.scale.width;
                    e = this.size / 2 - u, t = this.normalizedOptions.scale.quantity;
                    const h = e + this.normalizedOptions.scale.width;
                    n = l(t).map((function() {
                        return s = r * (a - o) - Math.PI / 2 + o, r += 1 / (t - c), {
                            cx: h + Math.cos(s) * e,
                            cy: h + Math.sin(s) * e,
                            r: u
                        }
                    })), i.selectAll("circle").data(n).enter().append("circle").attrs({
                        r: function(e) {
                            return e.r
                        },
                        cx: function(e) {
                            return e.cx
                        },
                        cy: function(e) {
                            return e.cy
                        },
                        fill: "var(--ua-knob-scale-background, gray)"
                    })
                } else if ("lines" === this.normalizedOptions.scale.type) {
                    const u = this.normalizedOptions.scale.height;
                    e = this.size / 2, t = this.normalizedOptions.scale.quantity, n = l(t).map((function() {
                        return s = r * (a - o) - Math.PI / 2 + o, r += 1 / (t - c), {
                            x1: e + Math.cos(s) * e,
                            y1: e + Math.sin(s) * e,
                            x2: e + Math.cos(s) * (e - u),
                            y2: e + Math.sin(s) * (e - u)
                        }
                    })), i.selectAll("line").data(n).enter().append("line").attrs({
                        x1: function(e) {
                            return e.x1
                        },
                        y1: function(e) {
                            return e.y1
                        },
                        x2: function(e) {
                            return e.x2
                        },
                        y2: function(e) {
                            return e.y2
                        },
                        "stroke-width": this.normalizedOptions.scale.width,
                        stroke: "var(--ua-knob-scale-background, gray)"
                    })
                }
            }
            this.normalizedOptions.skin && "tron" === this.normalizedOptions.skin.type && this.drawArc(i, this.hoopArc, "hoopArc", {
                fill: "var(--ua-knob-skin-color, rgba(255, 0, 0, .5))"
            }), this.drawArc(i, this.trackArc, "trackArc", {
                fill: "var(--ua-knob-track-background, #656D7F)"
            }), this.normalizedOptions.previous.enabled ? this.changeElem = this.drawArc(i, this.changeArc, "changeArc", {
                fill: "var(--ua-knob-prev-bar-background, rgba(0,0,0,0))"
            }) : this.changeElem = this.drawArc(i, this.changeArc, "changeArc", {
                "fill-opacity": 0
            }), this.valueElem = this.drawArc(i, this.valueArc, "valueArc", {
                fill: "var(--ua-knob-indicator-background, #FFAE1A)"
            });
            let r = "pointer";
            this.readonly && (r = "default"), this.drawArc(i, this.interactArc, "interactArc", {
                "fill-opacity": 0,
                cursor: r
            }, e, t)
        }
        interaction(e, t, n) {
            this.guard = !0;
            const i = Math.atan(t / e) / (Math.PI / 180);
            let r;
            e >= 0 && t <= 0 || e >= 0 && t >= 0 ? r = 90 : (r = 270, this.startAngle < 0 && (r = -90));
            const s = (r + i) * (Math.PI / 180);
            if (this.value = function(e, t, n, i, r) {
                    return t = t || 100, n = n || 0, i = i || 360, r = r || 0, (180 / Math.PI * e - r) * (t - n) / (i - r) + n
                }(s, this.max, this.min, this.endAngle, this.startAngle), this.value >= this.min && this.value <= this.max && (this.value = Math.round(~~((this.value < 0 ? -.5 : .5) + this.value / this.step) * this.step * 100) / 100, this.step < 1 && (this.value = Number(this.value.toFixed(1))), this.valueArc.endAngle(Bo(this.value, this.max, this.endAngle, this.startAngle, this.min)), this.valueElem.attr("d", this.valueArc), n && (this.changeArc.endAngle(Bo(this.value, this.max, this.endAngle, this.startAngle, this.min)), this.changeElem.attr("d", this.changeArc)), this.normalizedOptions.displayInput)) {
                let e = this.label || this.value;
                "function" == typeof this.normalizedOptions.inputFormatter && (e = this.normalizedOptions.inputFormatter(e)), Ae(this.element).select("#text").text(e + this.normalizedOptions.unit || "")
            }
            this.guard = !1
        }
        setValue(e) {
            if (!this.inDrag && this.value >= this.min && this.value <= this.max) {
                const t = Bo(e, this.max, this.endAngle, this.startAngle, this.min);
                if (this.value = Math.round(~~((e < 0 ? -.5 : .5) + e / this.step) * this.step * 100) / 100, this.step < 1 && (this.value = Number(this.value.toFixed(1))), this.changeArc.endAngle(t), Ae(this.element).select("#changeArc").attr("d", this.changeArc), this.valueArc.endAngle(t), Ae(this.element).select("#valueArc").attr("d", this.valueArc), this.normalizedOptions.displayInput) {
                    let e = this.label || this.value;
                    "function" == typeof this.normalizedOptions.inputFormatter && (e = this.normalizedOptions.inputFormatter(e)), Ae(this.element).select("#text").text(e + this.normalizedOptions.unit || "")
                }
            }
        }
    };
    Ho.defaultOptions = {
        unit: "",
        displayInput: !1,
        inputFormatter: function(e) {
            return e
        },
        subText: {
            enabled: !1,
            text: "",
            fontFamily: "Arial",
            fontWeight: "normal",
            fontSize: "auto",
            offset: 0
        },
        background: {
            full: !1
        },
        scale: {
            enabled: !1,
            type: "lines",
            width: 4,
            quantity: 20,
            height: 10,
            spaceWidth: 15
        },
        animation: {
            enabled: !1,
            duration: 1e3,
            ease: "bounce"
        },
        previous: {
            enabled: !1
        },
        skin: {
            type: "simple",
            width: 10,
            spaceWidth: 5
        }
    }, Object(i.__decorate)([Object(r.bindable)({
        mode: r.BindingMode.twoWay,
        callback: "draw",
        primary: !0
    }), Object(i.__metadata)("design:type", Number)], Ho.prototype, "value", void 0), Object(i.__decorate)([Object(r.bindable)({
        callback: "draw"
    }), Object(i.__metadata)("design:type", Object)], Ho.prototype, "options", void 0), Object(i.__decorate)([Object(r.bindable)({
        callback: "draw"
    }), Object(i.__metadata)("design:type", Number)], Ho.prototype, "step", void 0), Object(i.__decorate)([Object(r.bindable)({
        callback: "draw"
    }), Object(i.__metadata)("design:type", Number)], Ho.prototype, "min", void 0), Object(i.__decorate)([Object(r.bindable)({
        callback: "draw"
    }), Object(i.__metadata)("design:type", Number)], Ho.prototype, "max", void 0), Object(i.__decorate)([Object(r.bindable)({
        callback: "draw"
    }), Object(i.__metadata)("design:type", Boolean)], Ho.prototype, "readonly", void 0), Ho = Fo = Object(i.__decorate)([Object(r.customAttribute)({
        name: "html-knob",
        hasDynamicOptions: !0
    }), Object(i.__metadata)("design:paramtypes", [HTMLElement])], Ho);
    var Wo, qo = n(71),
        Go = n(62),
        Ko = n(72),
        Yo = n(41),
        Xo = n(73),
        Jo = n(74),
        Qo = n(27),
        Zo = n(42),
        ea = n(75),
        ta = n(76),
        na = n(77),
        ia = n(78),
        ra = n(79),
        sa = n(80),
        oa = n(81),
        aa = n(82),
        ca = n(8),
        la = n(15),
        ua = n(7),
        ha = n(20),
        da = n(23);
    let pa = Wo = class {
        constructor(e, t) {
            this.element = e, this.resourceManager = t, this.value = 0, this.direction = da.a.normal, this.gradient = null, this.height = 0, this.width = 0
        }
        binding() {
            this.imageName ? this.imageNameChanged() : this.gradientChanged()
        }
        attached() {
            "none" !== window.getComputedStyle(this.element).display && (this.element.style.display = "block"), this.height = parseInt(window.getComputedStyle(this.element).height.replace("px", "")), this.width = parseInt(window.getComputedStyle(this.element).width.replace("px", "")), this.valueChanged()
        }
        imageNameChanged() {
            const e = this.resourceManager.imagePathFromName("" + this.imageName),
                t = this.resourceManager.imageSetFromName("" + this.imageName);
            Object(la.d)(this.element, e, t)
        }
        gradientChanged() {
            const e = "linear-gradient(to bottom, " + (this.gradient || Wo.defaultGradient).join(", ") + ")";
            this.element.style.backgroundImage = e
        }
        valueChanged() {
            let e = "boolean" == typeof this.value ? this.value ? 1 : 0 : this.value;
            null == e && (e = 0);
            const t = Math.floor(this.height * e),
                n = this.direction == da.a.normal ? this.height - t : t,
                i = Object(ua.a)(n || 0, 0, this.height);
            this.element.style.clip = `rect(${i}px ${this.width}px ${this.height}px 0px)`
        }
    };
    pa.defaultGradient = ["#FD6100 0%", "#F2DF00 11%", "#4DB500 100%"], Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Number)], pa.prototype, "value", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", String)], pa.prototype, "imageName", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", String)], pa.prototype, "direction", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], pa.prototype, "gradient", void 0), pa = Wo = Object(i.__decorate)([Object(r.customElement)("ua-meter"), Object(i.__metadata)("design:paramtypes", [HTMLElement, ha.a])], pa), n.d(t, "HTMLKnobBehavior", (function() {
        return Ho
    })), n.d(t, "UACheckbox", (function() {
        return qo.a
    })), n.d(t, "UASwitch", (function() {
        return Go.b
    })), n.d(t, "SwitchValueConverter", (function() {
        return Go.a
    })), n.d(t, "UAKnob", (function() {
        return Ko.a
    })), n.d(t, "UAFilmStrip", (function() {
        return Yo.b
    })), n.d(t, "UAInputNumber", (function() {
        return Xo.a
    })), n.d(t, "UADropdown", (function() {
        return Jo.a
    })), n.d(t, "UAOption", (function() {
        return Qo.a
    })), n.d(t, "UAText", (function() {
        return Zo.b
    })), n.d(t, "UAInputText", (function() {
        return ea.a
    })), n.d(t, "UAListbox", (function() {
        return ta.a
    })), n.d(t, "UASlider", (function() {
        return na.a
    })), n.d(t, "UASliderRange", (function() {
        return ia.a
    })), n.d(t, "UAToggleButton", (function() {
        return ra.a
    })), n.d(t, "UAButton", (function() {
        return sa.a
    })), n.d(t, "UAMidiNote", (function() {
        return oa.a
    })), n.d(t, "UAClip", (function() {
        return aa.a
    })), n.d(t, "UAComponent", (function() {
        return ca.b
    })), n.d(t, "UAMeter", (function() {
        return pa
    }))
});
