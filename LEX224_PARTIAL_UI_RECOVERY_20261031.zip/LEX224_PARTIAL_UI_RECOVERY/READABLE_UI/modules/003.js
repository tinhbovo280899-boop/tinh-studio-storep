// Extracted webpack module 3. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "i", (function() {
            return s
        })), n.d(t, "m", (function() {
            return o
        })), n.d(t, "g", (function() {
            return a
        })), n.d(t, "f", (function() {
            return c
        })), n.d(t, "d", (function() {
            return l
        })), n.d(t, "l", (function() {
            return u
        })), n.d(t, "e", (function() {
            return h
        })), n.d(t, "j", (function() {
            return d
        })), n.d(t, "h", (function() {
            return p
        })), n.d(t, "k", (function() {
            return f
        })), n.d(t, "c", (function() {
            return g
        })), n.d(t, "n", (function() {
            return v
        })), n.d(t, "a", (function() {
            return b
        })), n.d(t, "b", (function() {
            return y
        }));
        var i, r = n(0);
        const s = null != (null === (i = null == e ? void 0 : e.versions) || void 0 === i ? void 0 : i.node),
            o = e => new Promise(t => setTimeout(t, e)),
            a = e => !!e.match(/file.*\.(jpg|jpeg|png|gif)/i) || !!e.match(/http.*\.(jpg|jpeg|png|gif)/i) || !!e.match(/https.*\.(jpg|jpeg|png|gif)/i),
            c = e => {
                const t = e.split('"'),
                    n = [];
                return t.forEach(e => {
                    if (a(e)) try {
                        new URL(e), n.push(e)
                    } catch (e) {}
                }), n.length > 0 ? n : void 0
            },
            l = e => e.replace("/@2x/", "/").replace("@2x", ""),
            u = e => new Promise((t, n) => {
                const i = new Image;
                i.src = e, i.onload = () => t(i), i.onerror = e => n(e)
            }),
            h = () => {
                var e, t, n, i;
                const r = null === (n = null === (t = null === (e = window) || void 0 === e ? void 0 : e.navigator) || void 0 === t ? void 0 : t.userAgentData) || void 0 === n ? void 0 : n.platform,
                    s = window.navigator.platform,
                    o = (null !== (i = null != r ? r : s) && void 0 !== i ? i : "").toLowerCase();
                return o ? o.includes("win") ? "win" : (o.includes("mac"), "mac") : "mac"
            },
            d = e => {
                let t = !1;
                try {
                    t = e instanceof TouchEvent
                } catch (e) {}
                return t
            },
            p = e => {
                let t = !1;
                try {
                    t = e instanceof MouseEvent
                } catch (e) {}
                return t
            },
            f = e => {
                let t = !1;
                try {
                    t = e instanceof WheelEvent
                } catch (e) {}
                return t
            },
            g = (e, t) => t.getTime() - e.getTime(),
            m = /_[a-z]/g,
            v = e => e.toLowerCase().replace(m, e => e.slice(-1).toUpperCase()),
            b = e => Object(r.__awaiter)(void 0, void 0, void 0, (function*() {
                try {
                    const t = yield fetch(e, {
                        mode: "no-cors"
                    });
                    return yield t.json()
                } catch (e) {
                    return
                }
            })),
            y = e => new Promise((t, n) => {
                const i = new FileReader;
                i.onloadend = () => t(i.result), i.onerror = n, i.readAsDataURL(e)
            })
    }).call(this, n(43))
});
