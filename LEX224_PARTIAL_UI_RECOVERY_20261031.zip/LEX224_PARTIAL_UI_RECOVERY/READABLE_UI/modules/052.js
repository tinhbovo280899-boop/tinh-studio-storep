// Extracted webpack module 52. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(0),
        r = n(1),
        s = n(24);
    let o = class {
        constructor(e, t, n) {
            this.defaultFactory = e, this.location = t, this.skinManager = n, this.task = r.LifecycleTask.done, this.value = null, this.type = null
        }
        valueChanged(e, t, n) {
            this.task.done ? this.task = this.swap(this.value, n) : this.task = new r.ContinuationTask(this.task, this.swap, this, this.value, n)
        }
        binding(e) {
            return this.task.done ? this.task = this.swap(this.value, e) : this.task = new r.ContinuationTask(this.task, this.swap, this, this.value, e), this.task
        }
        attaching(e) {
            this.task.done ? this.attachView(e) : this.task = new r.ContinuationTask(this.task, this.attachView, this, e)
        }
        detaching(e) {
            return void 0 !== this.view && (this.task.done ? this.view.detach(e) : this.task = new r.ContinuationTask(this.task, this.view.detach, this.view, e)), this.task
        }
        unbinding(e) {
            return void 0 !== this.view && (this.task.done ? this.task = this.view.unbind(e) : this.task = new r.ContinuationTask(this.task, this.view.unbind, this.view, e)), this.task
        }
        swap(e, t) {
            let n = r.LifecycleTask.done,
                i = this.skinManager.resolveSkin(e, this.type) || this.defaultFactory;
            if (i !== this.currentFactory && void 0 !== this.view && (n = this.deactivate(t)), n.done) {
                const e = this.updateView(i, t);
                n = this.activate(e, t)
            } else n = new r.PromiseTask(n.wait().then(() => this.updateView(i, t)), this.activate, this, t);
            return n
        }
        updateView(e, t) {
            this.currentFactory = e;
            let n = this.currentFactory.create(t);
            return n.hold(this.location, 1), n
        }
        attachView(e) {
            void 0 !== this.view && (40 & this.$controller.state) > 0 && this.view.attach(e)
        }
        activate(e, t) {
            if (this.view = e, void 0 === e) return r.LifecycleTask.done;
            let n = this.bindView(t);
            return 0 == (32 & this.$controller.state) || (n.done ? this.attachView(t) : n = new r.ContinuationTask(n, this.attachView, this, t)), n
        }
        deactivate(e) {
            const t = this.view;
            if (void 0 === t) return r.LifecycleTask.done;
            t.detach(e);
            const n = t.unbind(e);
            return t.parent = void 0, n
        }
        bindView(e) {
            return void 0 !== this.view && (5 & this.$controller.state) > 0 ? (this.view.parent = this.$controller, this.view.bind(e, this.$controller.scope, this.$controller.part)) : r.LifecycleTask.done
        }
    };
    o.inject = [r.IViewFactory, r.IRenderLocation, s.a], Object(i.__decorate)([Object(r.bindable)({
        primary: !0
    }), Object(i.__metadata)("design:type", Object)], o.prototype, "value", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], o.prototype, "type", void 0), o = Object(i.__decorate)([Object(r.customAttribute)({
        name: "skin-site",
        isTemplateController: !0,
        hasDynamicOptions: !0
    }), Object(i.__metadata)("design:paramtypes", [Object, Object, s.a])], o), n.d(t, "SkinSiteAttribute", (function() {
        return o
    }))
});
