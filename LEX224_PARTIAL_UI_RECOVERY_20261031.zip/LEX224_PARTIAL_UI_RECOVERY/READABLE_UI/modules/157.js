// Extracted webpack module 157. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "application-root",
        o = '<div style.bind="styles.backPanel | elbertCssObject">\r\n  <template repeat.for="register of state.registry.templates">\r\n    <div creator.bind="state.templates[register[0]].template"></div>\r\n  </template>\r\n  <led-display view-model.ref="ledDisplay"></led-display>\r\n</div>\r\n';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\r\n  display: block;\r\n  width: 100%;\r\n  height: 100%;\r\n  /*--ua-click-region-border: 1px dotted #FF00FF;*/\r\n}\r\n\r\n.message {\r\n  color: red;\r\n}\r\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
