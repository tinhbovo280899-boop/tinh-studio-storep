// Extracted webpack module 25. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    var i = n(5);
    var r = n(11);
    n.d(t, "a", (function() {
        return s
    }));
    class s {
        constructor(e, t, n = i.c.normalized) {
            this.controller = e, this.observerLocator = t, this.valueType = n, this.viewModel = e.viewModel
        }
        configure(e, t, n) {
            Object(i.d)(this.viewModel) && this.viewModel.configureFromUANet(e, t, this, n)
        }
        setValue(e, t) {
            if (this.getValue(e) !== t)
                if (Object(i.f)(this.viewModel)) this.viewModel.setUANetValue(e, t);
                else {
                    if (!(e in this.viewModel)) throw new Error(`Control does not implement a setUANetValue(value) method or a ${e} property as required by the ua-param/ua-meter attributes.`);
                    this.viewModel[e] = t
                }
        }
        getValue(e) {
            if (Object(i.e)(this.viewModel)) return this.viewModel.getUANetValue(e);
            if (e in this.viewModel) return this.viewModel[e];
            throw new Error(`Control does not implement a getUANetValue() method  or a ${e}  property as required by the ua-param/ua-meter attributes.`)
        }
        subscribe(e, t) {
            const n = this.tryFindInteraction();
            if (null === n) {
                if (!(e in this.viewModel)) return {
                    dispose() {}
                };
                const n = this.observerLocator.getObserver(0, this.viewModel, e),
                    i = this;
                let r = i.getValue(e);
                const s = {
                    handleChange() {
                        const n = i.getValue(e);
                        n !== r && (r = n, t.start({}), t.change({
                            value: n
                        }), t.end({}))
                    }
                };
                return n.subscribe(s), {
                    dispose() {
                        n.unsubscribe(s)
                    }
                }
            } {
                const i = n.subscribe(r.g.start, (n, ...i) => {
                        (n = null != n ? n : {}).viewModelPropertyName && n.viewModelPropertyName !== e || t.start(n)
                    }),
                    s = n.subscribe(r.g.change, n => {
                        (n = null != n ? n : {}).viewModelPropertyName && n.viewModelPropertyName !== e || (n.value = this.getValue(e), t.change(n))
                    }),
                    o = n.subscribe(r.g.revert, n => {
                        (n = null != n ? n : {}).viewModelPropertyName && n.viewModelPropertyName !== e || t.revert(n)
                    }),
                    a = n.subscribe(r.g.default, n => {
                        (n = null != n ? n : {}).viewModelPropertyName && n.viewModelPropertyName !== e || t.default(n)
                    }),
                    c = n.subscribe(r.g.end, n => {
                        (n = null != n ? n : {}).viewModelPropertyName && n.viewModelPropertyName !== e || t.end(n)
                    });
                return {
                    dispose() {
                        i.dispose(), s.dispose(), o.dispose(), a.dispose(), c.dispose()
                    }
                }
            }
        }
        tryFindInteraction() {
            if ("getInteraction" in this.viewModel) return this.viewModel.getInteraction();
            const e = this.controller.projector.provideEncapsulationSource();
            for (let t = 0, n = e.childNodes.length; t < n; ++t) {
                const n = e.childNodes[t].$interaction;
                if (n) return n
            }
            return null
        }
    }
});
