// Extracted webpack module 45. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return h
    })), n.d(t, "b", (function() {
        return d
    }));
    var i = n(0),
        r = n(1),
        s = n(7),
        o = n(13),
        a = n(10),
        c = n(8),
        l = n(54),
        u = n(9);
    const h = Object.assign(Object.assign({}, c.a), {
        value: 0,
        index: 0,
        min: 0,
        max: 1,
        discrete: !1,
        orientation: a.a.both,
        endless: !1,
        states: null
    });
    let d = class extends l.a {
        constructor(e, t, n) {
            super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = h, this.initClassState()
        }
        hardwareAcceleratedChanged() {}
        getHardwareAcceleratedDisplay() {
            return this.element
        }
        binding() {
            null === this.interactionHost ? this.element.$interaction = this : this.interactionHost.getInteraction = () => this
        }
        attaching() {
            super.attaching()
        }
        detaching() {
            super.detaching()
        }
        subscribe(e, t) {
            return this.ea.subscribe(e, t)
        }
        setValue(e) {
            if (this.disabled) return;
            if (Number.isNaN(e)) return void console.warn("linear interaction: setValue encountered a NaN");
            let t = e;
            if (this.discrete) {
                if (Array.isArray(this.states) && this.states.length > 0) {
                    if (-1 === this.profile.getIndexFromRealValue({
                            value: t,
                            states: this.states
                        })) return console.warn("setValue: real value not found in array, returning"), console.log(t), void console.log(this.states)
                }
            } else t = Object(s.a)(t, this.min, this.max);
            t !== this.value && (this.value = t)
        }
        computeValueFromInteraction({
            trackerState: e
        }) {
            return e.value
        }
    };
    d = Object(i.__decorate)([Object(r.customAttribute)({
        name: "linear-interaction",
        hasDynamicOptions: !0
    }), Object(i.__metadata)("design:paramtypes", [HTMLElement, o.a, u.a])], d)
});
