// Extracted webpack module 86. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t), n.d(t, "name", (function() {
        return r
    })), n.d(t, "template", (function() {
        return s
    })), n.d(t, "dependencies", (function() {
        return o
    })), n.d(t, "shadowOptions", (function() {
        return a
    })), n.d(t, "register", (function() {
        return l
    }));
    var i = n(1);
    const r = "ua-clip",
        s = "<style>\n  :host {\n    clip: rect(0px,0px,0px,0px); /* hide the meter on initial load */\n  } \n  \n</style>";
    t.default = s;
    const o = [],
        a = {
            mode: "open"
        };
    let c;

    function l(e) {
        c || (c = i.CustomElement.define({
            name: r,
            template: s,
            dependencies: o,
            shadowOptions: a
        })), e.register(c)
    }
});
