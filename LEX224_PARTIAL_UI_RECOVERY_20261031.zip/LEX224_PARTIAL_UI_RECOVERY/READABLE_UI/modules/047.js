// Extracted webpack module 47. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return r
    })), n.d(t, "b", (function() {
        return s
    })), n.d(t, "d", (function() {
        return o
    })), n.d(t, "c", (function() {
        return a
    }));
    var i = n(1);

    function r(e) {
        return Object(i.customElement)({
            name: e.name,
            template: e.template,
            shadowOptions: {
                mode: "open"
            },
            dependencies: e.dependencies
        })
    }
    const s = e => "object" == typeof e && !Array.isArray(e),
        o = e => {
            const {
                wrapperCallback: t,
                callbackArgs: n
            } = e, i = a({
                callback: t
            });
            return a({
                callback: i,
                args: n
            })
        },
        a = e => {
            const {
                callback: t,
                args: n
            } = e;
            return "function" == typeof t ? Array.isArray(n) ? t(...n) : t() : void 0
        }
});
