// Extracted webpack module 63. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = {};
    n.r(i), n.d(i, "BackgroundImageAttribute", (function() {
        return Ji
    }));
    var r = n(2),
        s = n(1);
    const o = [{
        type: s.AccessKeyedExpression,
        name: "AccessKeyedExpression"
    }, {
        type: s.AccessMemberExpression,
        name: "AccessMemberExpression"
    }, {
        type: s.AccessScopeExpression,
        name: "AccessScopeExpression"
    }, {
        type: s.AccessThisExpression,
        name: "AccessThisExpression"
    }, {
        type: s.ArrayBindingPattern,
        name: "ArrayBindingPattern"
    }, {
        type: s.ArrayLiteralExpression,
        name: "ArrayLiteralExpression"
    }, {
        type: s.AssignExpression,
        name: "AssignExpression"
    }, {
        type: s.BinaryExpression,
        name: "BinaryExpression"
    }, {
        type: s.BindingBehaviorExpression,
        name: "BindingBehaviorExpression"
    }, {
        type: s.BindingIdentifier,
        name: "BindingIdentifier"
    }, {
        type: s.CallFunctionExpression,
        name: "CallFunctionExpression"
    }, {
        type: s.CallMemberExpression,
        name: "CallMemberExpression"
    }, {
        type: s.CallScopeExpression,
        name: "CallScopeExpression"
    }, {
        type: s.ConditionalExpression,
        name: "ConditionalExpression"
    }, {
        type: s.ForOfStatement,
        name: "ForOfStatement"
    }, {
        type: s.HtmlLiteralExpression,
        name: "HtmlLiteralExpression"
    }, {
        type: s.Interpolation,
        name: "Interpolation"
    }, {
        type: s.ObjectBindingPattern,
        name: "ObjectBindingPattern"
    }, {
        type: s.ObjectLiteralExpression,
        name: "ObjectLiteralExpression"
    }, {
        type: s.PrimitiveLiteralExpression,
        name: "PrimitiveLiteralExpression"
    }, {
        type: s.TaggedTemplateExpression,
        name: "TaggedTemplateExpression"
    }, {
        type: s.TemplateExpression,
        name: "TemplateExpression"
    }, {
        type: s.UnaryExpression,
        name: "UnaryExpression"
    }, {
        type: s.ValueConverterExpression,
        name: "ValueConverterExpression"
    }];

    function a() {
        o.forEach(e => {
            var t;
            t = e.type, e.name, t.prototype.toString = function() {
                return c.unparse(this)
            }
        })
    }
    class c {
        constructor() {
            this.text = ""
        }
        static unparse(e) {
            const t = new c;
            return e.accept(t), t.text
        }
        visitAccessMember(e) {
            e.object.accept(this), this.text += "." + e.name
        }
        visitAccessKeyed(e) {
            e.object.accept(this), this.text += "[", e.key.accept(this), this.text += "]"
        }
        visitAccessThis(e) {
            if (0 === e.ancestor) return void(this.text += "$this");
            this.text += "$parent";
            let t = e.ancestor - 1;
            for (; t--;) this.text += ".$parent"
        }
        visitAccessScope(e) {
            let t = e.ancestor;
            for (; t--;) this.text += "$parent.";
            this.text += e.name
        }
        visitArrayLiteral(e) {
            const t = e.elements;
            this.text += "[";
            for (let e = 0, n = t.length; e < n; ++e) 0 !== e && (this.text += ","), t[e].accept(this);
            this.text += "]"
        }
        visitObjectLiteral(e) {
            const t = e.keys,
                n = e.values;
            this.text += "{";
            for (let e = 0, i = t.length; e < i; ++e) 0 !== e && (this.text += ","), this.text += `'${t[e]}':`, n[e].accept(this);
            this.text += "}"
        }
        visitPrimitiveLiteral(e) {
            if (this.text += "(", "string" == typeof e.value) {
                const t = e.value.replace(/'/g, "\\'");
                this.text += `'${t}'`
            } else this.text += "" + e.value;
            this.text += ")"
        }
        visitCallFunction(e) {
            this.text += "(", e.func.accept(this), this.writeArgs(e.args), this.text += ")"
        }
        visitCallMember(e) {
            this.text += "(", e.object.accept(this), this.text += "." + e.name, this.writeArgs(e.args), this.text += ")"
        }
        visitCallScope(e) {
            this.text += "(";
            let t = e.ancestor;
            for (; t--;) this.text += "$parent.";
            this.text += e.name, this.writeArgs(e.args), this.text += ")"
        }
        visitTemplate(e) {
            const {
                cooked: t,
                expressions: n
            } = e, i = n.length;
            this.text += "`", this.text += t[0];
            for (let e = 0; e < i; e++) n[e].accept(this), this.text += t[e + 1];
            this.text += "`"
        }
        visitTaggedTemplate(e) {
            const {
                cooked: t,
                expressions: n
            } = e, i = n.length;
            e.func.accept(this), this.text += "`", this.text += t[0];
            for (let e = 0; e < i; e++) n[e].accept(this), this.text += t[e + 1];
            this.text += "`"
        }
        visitUnary(e) {
            this.text += "(" + e.operation, e.operation.charCodeAt(0) >= 97 && (this.text += " "), e.expression.accept(this), this.text += ")"
        }
        visitBinary(e) {
            this.text += "(", e.left.accept(this), 105 === e.operation.charCodeAt(0) ? this.text += ` ${e.operation} ` : this.text += e.operation, e.right.accept(this), this.text += ")"
        }
        visitConditional(e) {
            this.text += "(", e.condition.accept(this), this.text += "?", e.yes.accept(this), this.text += ":", e.no.accept(this), this.text += ")"
        }
        visitAssign(e) {
            this.text += "(", e.target.accept(this), this.text += "=", e.value.accept(this), this.text += ")"
        }
        visitValueConverter(e) {
            const t = e.args;
            e.expression.accept(this), this.text += "|" + e.name;
            for (let e = 0, n = t.length; e < n; ++e) this.text += ":", t[e].accept(this)
        }
        visitBindingBehavior(e) {
            const t = e.args;
            e.expression.accept(this), this.text += "&" + e.name;
            for (let e = 0, n = t.length; e < n; ++e) this.text += ":", t[e].accept(this)
        }
        visitArrayBindingPattern(e) {
            const t = e.elements;
            this.text += "[";
            for (let e = 0, n = t.length; e < n; ++e) 0 !== e && (this.text += ","), t[e].accept(this);
            this.text += "]"
        }
        visitObjectBindingPattern(e) {
            const t = e.keys,
                n = e.values;
            this.text += "{";
            for (let e = 0, i = t.length; e < i; ++e) 0 !== e && (this.text += ","), this.text += `'${t[e]}':`, n[e].accept(this);
            this.text += "}"
        }
        visitBindingIdentifier(e) {
            this.text += e.name
        }
        visitHtmlLiteral(e) {
            throw new Error("visitHtmlLiteral")
        }
        visitForOfStatement(e) {
            e.declaration.accept(this), this.text += " of ", e.iterable.accept(this)
        }
        visitInterpolation(e) {
            const {
                parts: t,
                expressions: n
            } = e, i = n.length;
            this.text += "${", this.text += t[0];
            for (let e = 0; e < i; e++) n[e].accept(this), this.text += t[e + 1];
            this.text += "}"
        }
        writeArgs(e) {
            this.text += "(";
            for (let t = 0, n = e.length; t < n; ++t) 0 !== t && (this.text += ","), e[t].accept(this);
            this.text += ")"
        }
    }
    const l = {
        ...r.k,
        get level() {
            return r.k.level
        },
        write(e, ...t) {
            const n = u(e),
                i = `Code ${e}: ${n.message}`;
            switch (n.level) {
                case 3:
                    this.level >= 3 && console.debug(i, ...t);
                    break;
                case 2:
                    this.level >= 2 && console.info(i, ...t);
                    break;
                case 1:
                    this.level >= 1 && console.warn(i, ...t);
                    break;
                case 0:
                    throw this.error(e, ...t)
            }
        },
        error(e, ...t) {
            const n = u(e),
                i = new Error(`Code ${e}: ${function(e,...t){for(;e.includes("%s");)e=e.replace("%s",String(t.shift()));return e}(n.message,...t)}`);
            return i.data = t, i
        }
    };

    function u(e) {
        const t = h[e];
        return void 0 !== t ? t : function(e) {
            return {
                level: 0,
                message: `Attempted to report with unknown code ${e}.`
            }
        }(e)
    }
    const h = {
            0: {
                level: 1,
                message: "Cannot add observers to object."
            },
            1: {
                level: 1,
                message: "Cannot observe property of object."
            },
            2: {
                level: 2,
                message: "Starting application in debug mode."
            },
            3: {
                level: 0,
                message: "Runtime expression compilation is only available when including JIT support."
            },
            4: {
                level: 0,
                message: "Invalid animation direction."
            },
            5: {
                level: 0,
                message: "key/value cannot be null or undefined. Are you trying to inject/register something that doesn't exist with DI?"
            },
            6: {
                level: 0,
                message: "Invalid resolver strategy specified."
            },
            7: {
                level: 0,
                message: "Constructor Parameter with index cannot be null or undefined. Are you trying to inject/register something that doesn't exist with DI?"
            },
            8: {
                level: 0,
                message: "Self binding behavior only supports events."
            },
            9: {
                level: 0,
                message: "The updateTrigger binding behavior requires at least one event name argument: eg <input value.bind=\"firstName & updateTrigger:'blur'\">"
            },
            10: {
                level: 0,
                message: "The updateTrigger binding behavior can only be applied to two-way/ from-view bindings on input/select elements."
            },
            11: {
                level: 0,
                message: "Only property bindings and string interpolation bindings can be signaled. Trigger, delegate and call bindings cannot be signaled."
            },
            12: {
                level: 0,
                message: "Signal name is required."
            },
            14: {
                level: 0,
                message: "Property cannot be assigned."
            },
            15: {
                level: 0,
                message: "Unexpected call context."
            },
            16: {
                level: 0,
                message: "A dependency registration is missing for the interface %s."
            },
            17: {
                level: 0,
                message: "You can only define one default implementation for an interface."
            },
            18: {
                level: 0,
                message: "You cannot observe a setter only property."
            },
            19: {
                level: 0,
                message: "Value for expression is non-repeatable."
            },
            20: {
                level: 0,
                message: "No template compiler found with the specified name. JIT support or a custom compiler is required."
            },
            21: {
                level: 0,
                message: "You cannot combine the containerless custom element option with Shadow DOM."
            },
            22: {
                level: 0,
                message: "A containerless custom element cannot be the root component of an application."
            },
            30: {
                level: 0,
                message: "There are more targets than there are target instructions."
            },
            31: {
                level: 0,
                message: "There are more target instructions than there are targets."
            },
            100: {
                level: 0,
                message: "Invalid start of expression."
            },
            101: {
                level: 0,
                message: "Unconsumed token."
            },
            102: {
                level: 0,
                message: "Double dot and spread operators are not supported."
            },
            103: {
                level: 0,
                message: "Invalid member expression."
            },
            104: {
                level: 0,
                message: "Unexpected end of expression."
            },
            105: {
                level: 0,
                message: "Expected identifier."
            },
            106: {
                level: 0,
                message: 'Invalid BindingIdentifier at left hand side of "of".'
            },
            107: {
                level: 0,
                message: "Invalid or unsupported property definition in object literal."
            },
            108: {
                level: 0,
                message: "Unterminated quote in string literal."
            },
            109: {
                level: 0,
                message: "Unterminated template string."
            },
            110: {
                level: 0,
                message: "Missing expected token."
            },
            111: {
                level: 0,
                message: "Unexpected character."
            },
            150: {
                level: 0,
                message: "Left hand side of expression is not assignable."
            },
            151: {
                level: 0,
                message: 'Unexpected keyword "of"'
            },
            401: {
                level: 1,
                message: "AttributePattern is missing a handler for '%s'."
            },
            402: {
                level: 1,
                message: "AttributePattern handler for '%s' is not a function."
            },
            800: {
                level: 0,
                message: "Property '%s' is being dirty-checked."
            },
            801: {
                level: 1,
                message: "Property '%s' is being dirty-checked."
            },
            2e3: {
                level: 0,
                message: "Router has not been activated."
            },
            2001: {
                level: 0,
                message: "Router has already been activated."
            },
            2002: {
                level: 0,
                message: "Failed to resolve all viewports."
            },
            2003: {
                level: 0,
                message: "Browser navigation has already been activated."
            },
            2004: {
                level: 0,
                message: "LinkHandler has already been activated."
            },
            1001: {
                level: 2,
                message: "DOM already initialized. Destroying and re-initializing.."
            },
            1e4: {
                level: 3,
                message: "%s"
            }
        },
        d = {
            objName: "marker",
            methodName: "noop",
            params: r.g.emptyArray,
            depth: -1,
            prev: null,
            next: null
        };
    class p {
        constructor(e, t, n) {
            this.objName = e, this.methodName = t, this.depth = p.stack.length, this.params = n, this.next = d, this.prev = p.tail, p.tail.next = this, p.tail = this, p.stack.push(this)
        }
        static reset() {
            let e = p.head,
                t = null;
            for (; null != e;) t = e.next, e.next = null, e.prev = null, e.params = null, e = t;
            p.head = d, p.tail = d, p.stack = []
        }
        static enter(e, t, n) {
            return new p(e, t, n)
        }
        static leave() {
            return p.stack.pop()
        }
    }
    p.head = d, p.tail = d, p.stack = [];
    r.m;
    const f = Object.freeze({
        rendering: !0,
        binding: !0,
        observation: !0,
        attaching: !0,
        mounting: !0,
        di: !0,
        lifecycle: !0,
        jit: !0
    });
    const g = Object.prototype.toString;

    function m(e, t = 0) {
        return null != e.params && e.params.length > t ? function(e) {
            const t = [];
            2097152 & e && t.push("mustEvaluate");
            16777216 & e && t.push("isCollectionMutation");
            16 & e && t.push("updateTargetInstance");
            32 & e && t.push("updateSourceExpression");
            64 & e && t.push("fromAsyncFlush");
            128 & e && t.push("fromSyncFlush");
            256 & e && t.push("fromTick");
            1024 & e && t.push("fromStartTask");
            2048 & e && t.push("fromStopTask");
            4096 & e && t.push("fromBind");
            8192 & e && t.push("fromUnbind");
            16384 & e && t.push("fromAttach");
            32768 & e && t.push("fromDetach");
            65536 & e && t.push("fromCache");
            131072 & e && t.push("fromDOMEvent");
            262144 & e && t.push("fromLifecycleTask");
            4194304 & e && t.push("isTraversingParentScope");
            67108864 & e && t.push("allowParentScopeTraversal");
            1 & e && t.push("getterSetterStrategy");
            2 & e && t.push("proxyStrategy");
            1073741824 & e && t.push("secondaryExpression");
            if (0 === t.length) return "none";
            return t.join("|")
        }(e.params[t]) : "none"
    }

    function v(e) {
        let t;
        return t = void 0 === e ? "undefined" : null === e ? "null" : void 0 !== e.constructor ? e.constructor.description ? `Resource{'${e.constructor.description.name}'}` : e.constructor.name : "string" == typeof e ? `'${e}'` : g.call(e), t
    }

    function b(e, t = 0) {
        return null != e.params && e.params.length > t ? v(e.params[t]) : "undefined"
    }

    function y(e, t = 0) {
        let n;
        if (null != e.params && e.params.length > t) {
            const i = e.params[t];
            return n = null != i && null != i.bindingContext ? v(i.bindingContext) : "undefined", `Scope{${n}}`
        }
        return "undefined"
    }

    function w(e, t = 0) {
        if (null != e.params && e.params.length > t) {
            const n = e.params[t];
            return "string" == typeof n ? `'${n}'` : void 0 !== n && Reflect.has(n, "friendlyName") ? n.friendlyName : v(n)
        }
        return "undefined"
    }

    function k(e, t = 0) {
        if (null != e.params && e.params.length > t) {
            const n = e.params[t];
            return "string" == typeof n ? `'${n}'` : n.toString()
        }
        return "undefined"
    }
    const x = {
            $hydrate: e => m(e),
            render: e => `${m(e)},IDOM,IRenderContext,${b(e,3)}`,
            addBinding: e => `${b(e)},${b(e,1)}`,
            addComponent: e => `${b(e)},${b(e,1)}`
        },
        _ = {
            $bind: e => m(e),
            $unbind: e => m(e),
            connect: e => m(e),
            constructor(e) {
                switch (e.objName) {
                    case "ArrayObserver":
                    case "MapObserver":
                    case "SetObserver":
                        return m(e);
                    case "SetterObserver":
                    case "SelfObserver":
                        return `${m(e)},${b(e,1)},${k(e,2)}`;
                    case "ProxyObserver":
                        return b(e);
                    case "ProxySubscriberCollection":
                    case "DirtyCheckProperty":
                        return `${b(e,1)},${k(e,2)}`;
                    case "PrimitiveObserver":
                    case "PropertyAccessor":
                        return `${b(e)},${k(e,1)}`;
                    default:
                        return ""
                }
            },
            lockedBind: e => m(e),
            lockedUnbind: e => m(e),
            InternalObserversLookup: e => `${m(e)},${b(e,1)},${k(e,2)}`,
            BindingContext(e) {
                switch (e.methodName) {
                    case "get":
                        return `${y(e)},${k(e,1)},${k(e,2)},${m(e,3)}`;
                    case "getObservers":
                        return m(e);
                    default:
                        return "unknown"
                }
            },
            Scope(e) {
                switch (e.methodName) {
                    case "create":
                        return `${m(e)},${b(e,1)},${b(e,2)}`;
                    case "fromOverride":
                        return `${m(e)},${b(e,1)}`;
                    case "fromParent":
                        return `${m(e)},${y(e,1)},${b(e,2)}`;
                    default:
                        return "unknown"
                }
            },
            OverrideContext(e) {
                switch (e.methodName) {
                    case "create":
                        return `${m(e)},${b(e,1)},${b(e,2)}`;
                    case "getObservers":
                        return "";
                    default:
                        return "unknown"
                }
            }
        },
        S = {
            callSource(e) {
                const t = [];
                switch (e.objName) {
                    case "Listener":
                        return e.params[0].type;
                    case "CallBinding":
                        if (null != e.params)
                            for (let n = 0, i = e.params.length; n < i; ++n) t.push(b(e, n));
                        return t.join(",");
                    default:
                        return "unknown"
                }
            },
            setValue(e) {
                let t;
                const n = e.params[0];
                switch (typeof n) {
                    case "undefined":
                        t = "undefined";
                        break;
                    case "object":
                        t = null === n ? "null" : v(n);
                        break;
                    case "string":
                        t = `'${n}'`;
                        break;
                    case "number":
                        t = n.toString();
                        break;
                    default:
                        t = v(n)
                }
                return `${t},${m(e,1)}`
            },
            flush: e => m(e),
            handleChange: e => `${k(e)},${k(e,1)},${m(e,2)}`,
            lockScope: e => y(e)
        },
        O = {
            $attach: e => m(e),
            $detach: e => m(e),
            $cache: e => m(e),
            hold: e => `Node{'${e.params[0].textContent}'}`,
            release: e => m(e)
        },
        C = {
            $mount: e => m(e),
            $unmount: e => m(e),
            project: e => b(e),
            take: e => b(e)
        },
        A = {
            construct: e => b(e),
            Container(e) {
                const t = [];
                switch (e.methodName) {
                    case "get":
                    case "getAll":
                        return w(e);
                    case "register":
                        if (null != e.params)
                            for (let n = 0, i = e.params.length; n < i; ++n) t.push(w(e, n));
                        return t.join(",");
                    case "createChild":
                        return "";
                    default:
                        return "unknown"
                }
            }
        },
        T = {
            Lifecycle(e) {
                switch (e.methodName.slice(0, 3)) {
                    case "beg":
                        return "";
                    case "enq":
                        return b(e);
                    case "end":
                    case "pro":
                        return m(e);
                    default:
                        return "unknown"
                }
            },
            CompositionCoordinator(e) {
                switch (e.methodName) {
                    case "enqueue":
                        return "IController";
                    case "swap":
                        return "IController," + m(e, 1);
                    case "processNext":
                        return "";
                    default:
                        return "unknown"
                }
            },
            AggregateLifecycleTask(e) {
                switch (e.methodName) {
                    case "addTask":
                    case "removeTask":
                        return b(e);
                    case "complete":
                        return "" + k(e, 2);
                    default:
                        return "unknown"
                }
            }
        },
        E = {
            TemplateBinder: e => ""
        };
    const j = {
        register(e) {
            l.write(2), Object.assign(r.k, l), a()
        }
    };
    var M = n(16),
        L = n(14),
        P = n(26),
        R = n(21),
        I = n(0);
    class D {
        constructor(e, t, n, i) {
            this.rawName = e, this.rawValue = t, this.target = n, this.command = i
        }
    }
    class N {
        constructor(e, t, n, i) {
            if (this.chars = e, this.repeat = t, this.isSymbol = n, this.isInverted = i, i) switch (e.length) {
                case 0:
                    this.has = this.hasOfNoneInverse;
                    break;
                case 1:
                    this.has = this.hasOfSingleInverse;
                    break;
                default:
                    this.has = this.hasOfMultipleInverse
            } else switch (e.length) {
                case 0:
                    this.has = this.hasOfNone;
                    break;
                case 1:
                    this.has = this.hasOfSingle;
                    break;
                default:
                    this.has = this.hasOfMultiple
            }
        }
        equals(e) {
            return this.chars === e.chars && this.repeat === e.repeat && this.isSymbol === e.isSymbol && this.isInverted === e.isInverted
        }
        hasOfMultiple(e) {
            return this.chars.includes(e)
        }
        hasOfSingle(e) {
            return this.chars === e
        }
        hasOfNone(e) {
            return !1
        }
        hasOfMultipleInverse(e) {
            return !this.chars.includes(e)
        }
        hasOfSingleInverse(e) {
            return this.chars !== e
        }
        hasOfNoneInverse(e) {
            return !0
        }
    }
    class V {
        constructor() {
            this._pattern = "", this.parts = r.g.emptyArray, this.currentRecord = {}, this.partsRecord = {}
        }
        get pattern() {
            const e = this._pattern;
            return "" === e ? null : e
        }
        set pattern(e) {
            null == e ? (this._pattern = "", this.parts = r.g.emptyArray) : (this._pattern = e, this.parts = this.partsRecord[e])
        }
        append(e, t) {
            const {
                currentRecord: n
            } = this;
            void 0 === n[e] ? n[e] = t : n[e] += t
        }
        next(e) {
            const {
                currentRecord: t
            } = this;
            if (void 0 !== t[e]) {
                const {
                    partsRecord: n
                } = this;
                void 0 === n[e] ? n[e] = [t[e]] : n[e].push(t[e]), t[e] = void 0
            }
        }
    }
    class $ {
        constructor(e, ...t) {
            this.charSpec = e, this.nextStates = [], this.types = null, this.patterns = t, this.isEndpoint = !1
        }
        get pattern() {
            return this.isEndpoint ? this.patterns[0] : null
        }
        findChild(e) {
            const t = this.nextStates,
                n = t.length;
            let i = null;
            for (let r = 0; r < n; ++r)
                if (i = t[r], e.equals(i.charSpec)) return i;
            return null
        }
        append(e, t) {
            const {
                patterns: n
            } = this;
            n.includes(t) || n.push(t);
            let i = this.findChild(e);
            return null == i && (i = new $(e, t), this.nextStates.push(i), e.repeat && i.nextStates.push(i)), i
        }
        findMatches(e, t) {
            const n = [],
                i = this.nextStates,
                r = i.length;
            let s = 0,
                o = null,
                a = 0,
                c = 0;
            for (; a < r; ++a)
                if (o = i[a], o.charSpec.has(e))
                    if (n.push(o), s = o.patterns.length, c = 0, o.charSpec.isSymbol)
                        for (; c < s; ++c) t.next(o.patterns[c]);
                    else
                        for (; c < s; ++c) t.append(o.patterns[c], e);
            return n
        }
    }
    class F {
        constructor(e) {
            this.text = e;
            const t = this.len = e.length,
                n = this.specs = [];
            for (let i = 0; i < t; ++i) n.push(new N(e[i], !1, !1, !1))
        }
        eachChar(e) {
            const {
                len: t,
                specs: n
            } = this;
            for (let i = 0; i < t; ++i) e(n[i])
        }
    }
    class U {
        constructor(e) {
            this.text = "PART", this.spec = new N(e, !0, !1, !0)
        }
        eachChar(e) {
            e(this.spec)
        }
    }
    class B {
        constructor(e) {
            this.text = e, this.spec = new N(e, !1, !0, !1)
        }
        eachChar(e) {
            e(this.spec)
        }
    }
    class z {
        constructor() {
            this.statics = 0, this.dynamics = 0, this.symbols = 0
        }
    }
    const H = r.a.createInterface("ISyntaxInterpreter").withDefault(e => e.singleton(W));
    class W {
        constructor() {
            this.rootState = new $(null), this.initialStates = [this.rootState]
        }
        add(e) {
            let t = 0;
            if (Array.isArray(e)) {
                const n = e.length;
                for (; t < n; ++t) this.add(e[t]);
                return
            }
            let n = this.rootState;
            const i = e,
                r = i.pattern,
                s = new z,
                o = this.parse(i, s),
                a = o.length,
                c = e => {
                    n = n.append(e, r)
                };
            for (t = 0; t < a; ++t) o[t].eachChar(c);
            n.types = s, n.isEndpoint = !0
        }
        interpret(e) {
            const t = new V;
            let n = this.initialStates;
            const i = e.length;
            for (let r = 0; r < i && (n = this.getNextStates(n, e.charAt(r), t), 0 !== n.length); ++r);
            if (n.sort((e, t) => {
                    if (!e.isEndpoint) return t.isEndpoint ? 1 : 0;
                    if (!t.isEndpoint) return -1;
                    const n = e.types,
                        i = t.types;
                    return n.statics !== i.statics ? i.statics - n.statics : n.dynamics !== i.dynamics ? i.dynamics - n.dynamics : n.symbols !== i.symbols ? i.symbols - n.symbols : 0
                }), n.length > 0) {
                const e = n[0];
                e.charSpec.isSymbol || t.next(e.pattern), t.pattern = e.pattern
            }
            return t
        }
        getNextStates(e, t, n) {
            const i = [];
            let r = null;
            const s = e.length;
            for (let o = 0; o < s; ++o) r = e[o], i.push(...r.findMatches(t, n));
            return i
        }
        parse(e, t) {
            const n = [],
                i = e.pattern,
                r = i.length;
            let s = 0,
                o = 0,
                a = "";
            for (; s < r;) a = i.charAt(s), e.symbols.includes(a) ? s !== o ? (n.push(new F(i.slice(o, s))), ++t.statics, o = s) : (n.push(new B(i.slice(o, s + 1))), ++t.symbols, o = ++s) : s === o && "P" === a && "PART" === i.slice(s, s + 4) ? (o = s += 4, n.push(new U(e.symbols)), ++t.dynamics) : ++s;
            return o !== s && (n.push(new F(i.slice(o, s))), ++t.statics), n
        }
    }
    const q = r.a.createInterface("IAttributePattern").noDefault();

    function G(...e) {
        return function(t) {
            const n = t.prototype;
            return function(e, t) {
                for (const n of t) n.pattern in e ? "function" != typeof e[n.pattern] && r.k.write(402, n.pattern) : r.k.write(401, n.pattern)
            }(n, e), n.$patternDefs = e, t.register = function(e) {
                r.j.singleton(q, t).register(e)
            }, t
        }
    }
    const K = r.a.createInterface("IAttributeParser").withDefault(e => e.singleton(J)),
        {
            enter: Y,
            leave: X
        } = r.h.createTimer("AttributeParser");
    class J {
        constructor(e, t) {
            this.interpreter = e, this.cache = {};
            const n = this.patterns = {};
            t.forEach(t => {
                const i = t.$patternDefs;
                e.add(i), i.forEach(e => {
                    n[e.pattern] = t
                })
            })
        }
        parse(e, t) {
            let n = this.cache[e];
            null == n && (n = this.cache[e] = this.interpreter.interpret(e));
            const i = n.pattern;
            return null == i ? new D(e, t, e, null) : this.patterns[i][i](e, t, n.parts)
        }
    }
    J.inject = [H, Object(r.n)(q)];
    let Q = class {
        "PART.PART"(e, t, n) {
            return new D(e, t, n[0], n[1])
        }
        "PART.PART.PART"(e, t, n) {
            return new D(e, t, n[0], n[2])
        }
    };
    Q = Object(I.__decorate)([G({
        pattern: "PART.PART",
        symbols: "."
    }, {
        pattern: "PART.PART.PART",
        symbols: "."
    })], Q);
    let Z = class {
        ref(e, t, n) {
            return new D(e, t, "element", "ref")
        }
        "PART.ref"(e, t, n) {
            return new D(e, t, n[0], "ref")
        }
    };
    Z = Object(I.__decorate)([G({
        pattern: "ref",
        symbols: ""
    }, {
        pattern: "PART.ref",
        symbols: "."
    })], Z);
    let ee = class {
        ":PART"(e, t, n) {
            return new D(e, t, n[0], "bind")
        }
    };
    ee = Object(I.__decorate)([G({
        pattern: ":PART",
        symbols: ":"
    })], ee);
    let te = class {
        "@PART"(e, t, n) {
            return new D(e, t, n[0], "trigger")
        }
    };

    function ne(e) {
        return function(t) {
            return re.define(e, t)
        }
    }
    te = Object(I.__decorate)([G({
        pattern: "@PART",
        symbols: "@"
    })], te);
    class ie {
        constructor(e, t, n, i, r) {
            this.Type = e, this.name = t, this.aliases = n, this.key = i, this.type = r
        }
        static create(e, t) {
            let n, i;
            return "string" == typeof e ? (n = e, i = {
                name: n
            }) : (n = e.name, i = e), new ie(t, Object(r.q)(re.getAnnotation(t, "name"), n), Object(r.z)(re.getAnnotation(t, "aliases"), i.aliases, t.aliases), re.keyFrom(n), Object(r.q)(re.getAnnotation(t, "type"), i.type, t.type, null))
        }
        register(e) {
            const {
                Type: t,
                key: n,
                aliases: i
            } = this;
            r.j.singleton(n, t).register(e), r.j.alias(n, t).register(e), Object(s.registerAliases)(i, re, n, e)
        }
    }
    const re = {
        name: r.i.resource.keyFor("binding-command"),
        keyFrom: e => `${re.name}:${e}`,
        isType: e => "function" == typeof e && r.f.hasOwn(re.name, e),
        define(e, t) {
            const n = ie.create(e, t);
            return r.f.define(re.name, n, n.Type), r.f.define(re.name, n, n), r.i.resource.appendTo(t, re.name), n.Type
        },
        getDefinition(e) {
            const t = r.f.getOwn(re.name, e);
            if (void 0 === t) throw new Error("No definition found for type " + e.name);
            return t
        },
        annotate(e, t, n) {
            r.f.define(r.i.annotation.keyFor(t), n, e)
        },
        getAnnotation: (e, t) => r.f.getOwn(r.i.annotation.keyFor(t), e)
    };

    function se(e, t) {
        return 256 & e.flags ? e.bindable.propName : t ? Object(r.o)(e.syntax.target) : e.syntax.target
    }
    var oe;

    function ae(e) {
        const t = e.createElement("au-m");
        return e.makeTarget(t), t
    }! function(e) {
        e[e.type = 511] = "type", e[e.isTemplateController = 1] = "isTemplateController", e[e.isReplacePart = 2] = "isReplacePart", e[e.isCustomAttribute = 4] = "isCustomAttribute", e[e.isPlainAttribute = 8] = "isPlainAttribute", e[e.isCustomElement = 16] = "isCustomElement", e[e.isLetElement = 32] = "isLetElement", e[e.isPlainElement = 64] = "isPlainElement", e[e.isText = 128] = "isText", e[e.isBinding = 256] = "isBinding", e[e.hasMarker = 512] = "hasMarker", e[e.hasTemplate = 1024] = "hasTemplate", e[e.hasAttributes = 2048] = "hasAttributes", e[e.hasBindings = 4096] = "hasBindings", e[e.hasChildNodes = 8192] = "hasChildNodes", e[e.hasParts = 16384] = "hasParts"
    }(oe || (oe = {}));
    class ce {
        constructor(e, t, n = t.name) {
            this.syntax = e, this.info = t, this.res = n, this.flags = 4, this._bindings = null
        }
        get bindings() {
            return null === this._bindings && (this._bindings = [], this.flags |= 4096), this._bindings
        }
    }
    class le {
        constructor(e, t, n) {
            this.syntax = e, this.command = t, this.expression = n, this.flags = 8
        }
    }
    class ue {
        constructor(e, t, n, i, r) {
            this.command = e, this.bindable = t, this.expression = n, this.rawValue = i, this.target = r, this.flags = 256
        }
    }
    let he = class {
        constructor() {
            this.bindingType = 49
        }
        compile(e) {
            return new s.OneTimeBindingInstruction(e.expression, se(e, !1))
        }
    };
    he = Object(I.__decorate)([ne("one-time")], he);
    let de = class {
        constructor() {
            this.bindingType = 50
        }
        compile(e) {
            return new s.ToViewBindingInstruction(e.expression, se(e, !1))
        }
    };
    de = Object(I.__decorate)([ne("to-view")], de);
    let pe = class {
        constructor() {
            this.bindingType = 51
        }
        compile(e) {
            return new s.FromViewBindingInstruction(e.expression, se(e, !1))
        }
    };
    pe = Object(I.__decorate)([ne("from-view")], pe);
    let fe = class {
        constructor() {
            this.bindingType = 52
        }
        compile(e) {
            return new s.TwoWayBindingInstruction(e.expression, se(e, !1))
        }
    };
    fe = Object(I.__decorate)([ne("two-way")], fe);
    let ge = class {
        constructor() {
            this.bindingType = 53
        }
        compile(e) {
            let t = s.BindingMode.default;
            if (e instanceof ue) t = e.bindable.mode;
            else {
                switch (e.syntax.command) {
                    case "bind":
                    case "to-view":
                        t = s.BindingMode.toView;
                        break;
                    case "one-time":
                        t = s.BindingMode.oneTime;
                        break;
                    case "from-view":
                        t = s.BindingMode.fromView;
                        break;
                    case "two-way":
                        t = s.BindingMode.twoWay
                }
            }
            switch (t) {
                case s.BindingMode.default:
                case s.BindingMode.toView:
                    return de.prototype.compile(e);
                case s.BindingMode.oneTime:
                    return he.prototype.compile(e);
                case s.BindingMode.fromView:
                    return pe.prototype.compile(e);
                case s.BindingMode.twoWay:
                    return fe.prototype.compile(e)
            }
        }
    };
    ge = Object(I.__decorate)([ne("bind")], ge);
    let me = class {
        constructor() {
            this.bindingType = 153
        }
        compile(e) {
            return new s.CallBindingInstruction(e.expression, se(e, !0))
        }
    };
    me = Object(I.__decorate)([ne("call")], me);
    let ve = class {
        constructor() {
            this.bindingType = 539
        }
        compile(e) {
            return new s.IteratorBindingInstruction(e.expression, se(e, !1))
        }
    };

    function be(e) {
        switch (e) {
            case 98:
                return 8;
            case 116:
                return 9;
            case 110:
                return 10;
            case 118:
                return 11;
            case 102:
                return 12;
            case 114:
                return 13;
            case 34:
                return 34;
            case 39:
                return 39;
            case 92:
                return 92;
            default:
                return e
        }
    }
    var ye, we, ke, xe;
    ve = Object(I.__decorate)([ne("for")], ve),
        function(e) {
            e[e.Reset = 0] = "Reset", e[e.Ancestor = 511] = "Ancestor", e[e.This = 512] = "This", e[e.Scope = 1024] = "Scope", e[e.Member = 2048] = "Member", e[e.Keyed = 4096] = "Keyed"
        }(ye || (ye = {})),
        function(e) {
            e[e.Variadic = 61] = "Variadic", e[e.Assign = 62] = "Assign", e[e.Conditional = 63] = "Conditional", e[e.LogicalOR = 64] = "LogicalOR", e[e.LogicalAND = 128] = "LogicalAND", e[e.Equality = 192] = "Equality", e[e.Relational = 256] = "Relational", e[e.Additive = 320] = "Additive", e[e.Multiplicative = 384] = "Multiplicative", e[e.Binary = 448] = "Binary", e[e.LeftHandSide = 449] = "LeftHandSide", e[e.Primary = 450] = "Primary", e[e.Unary = 451] = "Unary"
        }(we || (we = {})),
        function(e) {
            e[e.EOF = 1572864] = "EOF", e[e.ExpressionTerminal = 1048576] = "ExpressionTerminal", e[e.AccessScopeTerminal = 524288] = "AccessScopeTerminal", e[e.ClosingToken = 262144] = "ClosingToken", e[e.OpeningToken = 131072] = "OpeningToken", e[e.BinaryOp = 65536] = "BinaryOp", e[e.UnaryOp = 32768] = "UnaryOp", e[e.LeftHandSide = 16384] = "LeftHandSide", e[e.StringOrNumericLiteral = 12288] = "StringOrNumericLiteral", e[e.NumericLiteral = 8192] = "NumericLiteral", e[e.StringLiteral = 4096] = "StringLiteral", e[e.IdentifierName = 3072] = "IdentifierName", e[e.Keyword = 2048] = "Keyword", e[e.Identifier = 1024] = "Identifier", e[e.Contextual = 512] = "Contextual", e[e.Precedence = 448] = "Precedence", e[e.Type = 63] = "Type", e[e.FalseKeyword = 2048] = "FalseKeyword", e[e.TrueKeyword = 2049] = "TrueKeyword", e[e.NullKeyword = 2050] = "NullKeyword", e[e.UndefinedKeyword = 2051] = "UndefinedKeyword", e[e.ThisScope = 3076] = "ThisScope", e[e.ParentScope = 3077] = "ParentScope", e[e.OpenParen = 671750] = "OpenParen", e[e.OpenBrace = 131079] = "OpenBrace", e[e.Dot = 16392] = "Dot", e[e.CloseBrace = 1835017] = "CloseBrace", e[e.CloseParen = 1835018] = "CloseParen", e[e.Comma = 1572875] = "Comma", e[e.OpenBracket = 671756] = "OpenBracket", e[e.CloseBracket = 1835021] = "CloseBracket", e[e.Colon = 1572878] = "Colon", e[e.Question = 1572879] = "Question", e[e.Ampersand = 1572880] = "Ampersand", e[e.Bar = 1572883] = "Bar", e[e.BarBar = 1638548] = "BarBar", e[e.AmpersandAmpersand = 1638613] = "AmpersandAmpersand", e[e.EqualsEquals = 1638678] = "EqualsEquals", e[e.ExclamationEquals = 1638679] = "ExclamationEquals", e[e.EqualsEqualsEquals = 1638680] = "EqualsEqualsEquals", e[e.ExclamationEqualsEquals = 1638681] = "ExclamationEqualsEquals", e[e.LessThan = 1638746] = "LessThan", e[e.GreaterThan = 1638747] = "GreaterThan", e[e.LessThanEquals = 1638748] = "LessThanEquals", e[e.GreaterThanEquals = 1638749] = "GreaterThanEquals", e[e.InKeyword = 1640798] = "InKeyword", e[e.InstanceOfKeyword = 1640799] = "InstanceOfKeyword", e[e.Plus = 623008] = "Plus", e[e.Minus = 623009] = "Minus", e[e.TypeofKeyword = 34850] = "TypeofKeyword", e[e.VoidKeyword = 34851] = "VoidKeyword", e[e.Asterisk = 1638884] = "Asterisk", e[e.Percent = 1638885] = "Percent", e[e.Slash = 1638886] = "Slash", e[e.Equals = 1048615] = "Equals", e[e.Exclamation = 32808] = "Exclamation", e[e.TemplateTail = 540713] = "TemplateTail", e[e.TemplateContinuation = 540714] = "TemplateContinuation", e[e.OfKeyword = 1051179] = "OfKeyword"
        }(ke || (ke = {})),
        function(e) {
            e[e.Null = 0] = "Null", e[e.Backspace = 8] = "Backspace", e[e.Tab = 9] = "Tab", e[e.LineFeed = 10] = "LineFeed", e[e.VerticalTab = 11] = "VerticalTab", e[e.FormFeed = 12] = "FormFeed", e[e.CarriageReturn = 13] = "CarriageReturn", e[e.Space = 32] = "Space", e[e.Exclamation = 33] = "Exclamation", e[e.DoubleQuote = 34] = "DoubleQuote", e[e.Dollar = 36] = "Dollar", e[e.Percent = 37] = "Percent", e[e.Ampersand = 38] = "Ampersand", e[e.SingleQuote = 39] = "SingleQuote", e[e.OpenParen = 40] = "OpenParen", e[e.CloseParen = 41] = "CloseParen", e[e.Asterisk = 42] = "Asterisk", e[e.Plus = 43] = "Plus", e[e.Comma = 44] = "Comma", e[e.Minus = 45] = "Minus", e[e.Dot = 46] = "Dot", e[e.Slash = 47] = "Slash", e[e.Semicolon = 59] = "Semicolon", e[e.Backtick = 96] = "Backtick", e[e.OpenBracket = 91] = "OpenBracket", e[e.Backslash = 92] = "Backslash", e[e.CloseBracket = 93] = "CloseBracket", e[e.Caret = 94] = "Caret", e[e.Underscore = 95] = "Underscore", e[e.OpenBrace = 123] = "OpenBrace", e[e.Bar = 124] = "Bar", e[e.CloseBrace = 125] = "CloseBrace", e[e.Colon = 58] = "Colon", e[e.LessThan = 60] = "LessThan", e[e.Equals = 61] = "Equals", e[e.GreaterThan = 62] = "GreaterThan", e[e.Question = 63] = "Question", e[e.Zero = 48] = "Zero", e[e.One = 49] = "One", e[e.Two = 50] = "Two", e[e.Three = 51] = "Three", e[e.Four = 52] = "Four", e[e.Five = 53] = "Five", e[e.Six = 54] = "Six", e[e.Seven = 55] = "Seven", e[e.Eight = 56] = "Eight", e[e.Nine = 57] = "Nine", e[e.UpperA = 65] = "UpperA", e[e.UpperB = 66] = "UpperB", e[e.UpperC = 67] = "UpperC", e[e.UpperD = 68] = "UpperD", e[e.UpperE = 69] = "UpperE", e[e.UpperF = 70] = "UpperF", e[e.UpperG = 71] = "UpperG", e[e.UpperH = 72] = "UpperH", e[e.UpperI = 73] = "UpperI", e[e.UpperJ = 74] = "UpperJ", e[e.UpperK = 75] = "UpperK", e[e.UpperL = 76] = "UpperL", e[e.UpperM = 77] = "UpperM", e[e.UpperN = 78] = "UpperN", e[e.UpperO = 79] = "UpperO", e[e.UpperP = 80] = "UpperP", e[e.UpperQ = 81] = "UpperQ", e[e.UpperR = 82] = "UpperR", e[e.UpperS = 83] = "UpperS", e[e.UpperT = 84] = "UpperT", e[e.UpperU = 85] = "UpperU", e[e.UpperV = 86] = "UpperV", e[e.UpperW = 87] = "UpperW", e[e.UpperX = 88] = "UpperX", e[e.UpperY = 89] = "UpperY", e[e.UpperZ = 90] = "UpperZ", e[e.LowerA = 97] = "LowerA", e[e.LowerB = 98] = "LowerB", e[e.LowerC = 99] = "LowerC", e[e.LowerD = 100] = "LowerD", e[e.LowerE = 101] = "LowerE", e[e.LowerF = 102] = "LowerF", e[e.LowerG = 103] = "LowerG", e[e.LowerH = 104] = "LowerH", e[e.LowerI = 105] = "LowerI", e[e.LowerJ = 106] = "LowerJ", e[e.LowerK = 107] = "LowerK", e[e.LowerL = 108] = "LowerL", e[e.LowerM = 109] = "LowerM", e[e.LowerN = 110] = "LowerN", e[e.LowerO = 111] = "LowerO", e[e.LowerP = 112] = "LowerP", e[e.LowerQ = 113] = "LowerQ", e[e.LowerR = 114] = "LowerR", e[e.LowerS = 115] = "LowerS", e[e.LowerT = 116] = "LowerT", e[e.LowerU = 117] = "LowerU", e[e.LowerV = 118] = "LowerV", e[e.LowerW = 119] = "LowerW", e[e.LowerX = 120] = "LowerX", e[e.LowerY = 121] = "LowerY", e[e.LowerZ = 122] = "LowerZ"
        }(xe || (xe = {}));
    const {
        enter: _e,
        leave: Se
    } = r.h.createTimer("ExpressionParser"), Oe = s.PrimitiveLiteralExpression.$false, Ce = s.PrimitiveLiteralExpression.$true, Ae = s.PrimitiveLiteralExpression.$null, Te = s.PrimitiveLiteralExpression.$undefined, Ee = s.AccessThisExpression.$this, je = s.AccessThisExpression.$parent;
    const Me = new class {
        constructor(e) {
            this.index = 0, this.startIndex = 0, this.lastIndex = 0, this.input = e, this.length = e.length, this.currentToken = 1572864, this.tokenValue = "", this.currentChar = e.charCodeAt(0), this.assignable = !0
        }
        get tokenRaw() {
            return this.input.slice(this.startIndex, this.index)
        }
    }("");
    var Le, Pe;

    function Re(e, t) {
        return Me.input = e, Me.length = e.length, Me.index = 0, Me.currentChar = e.charCodeAt(0), Ie(Me, 0, 61, void 0 === t ? 53 : t)
    }

    function Ie(e, t, n, i) {
        if (284 === i) return new s.CustomExpression(e.input);
        if (0 === e.index) {
            if (2048 & i) return function(e) {
                const t = [],
                    n = [],
                    i = e.length;
                let r = "";
                for (; e.index < i;) {
                    switch (e.currentChar) {
                        case 36:
                            if (123 === e.input.charCodeAt(e.index + 1)) {
                                t.push(r), r = "", e.index += 2, e.currentChar = e.input.charCodeAt(e.index), Ne(e);
                                const i = Ie(e, 0, 61, 2048);
                                n.push(i);
                                continue
                            }
                            r += "$";
                            break;
                        case 92:
                            r += String.fromCharCode(be(Ve(e)));
                            break;
                        default:
                            r += String.fromCharCode(e.currentChar)
                    }
                    Ve(e)
                }
                if (n.length) return t.push(r), new s.Interpolation(t, n);
                return null
            }(e);
            if (Ne(e), 1048576 & e.currentToken) throw r.k.error(100, {
                state: e
            })
        }
        e.assignable = 448 > n;
        let o = void 0;
        if (32768 & e.currentToken) {
            const n = He[63 & e.currentToken];
            Ne(e), o = new s.UnaryExpression(n, Ie(e, t, 449, i)), e.assignable = !1
        } else {
            e: switch (e.currentToken) {
                case 3077:
                    e.assignable = !1;
                    do {
                        if (Ne(e), t++, !Be(e, 16392)) {
                            if (524288 & e.currentToken) {
                                const e = 511 & t;
                                o = 0 === e ? Ee : 1 === e ? je : new s.AccessThisExpression(e), t = 512;
                                break e
                            }
                            throw r.k.error(103, {
                                state: e
                            })
                        }
                        if (16392 === e.currentToken) throw r.k.error(102, {
                            state: e
                        });
                        if (1572864 === e.currentToken) throw r.k.error(105, {
                            state: e
                        })
                    } while (3077 === e.currentToken);
                case 1024:
                    512 & i ? o = new s.BindingIdentifier(e.tokenValue) : (o = new s.AccessScopeExpression(e.tokenValue, 511 & t), t = 1024), e.assignable = !0, Ne(e);
                    break;
                case 3076:
                    e.assignable = !1, Ne(e), o = Ee, t = 512;
                    break;
                case 671750:
                    Ne(e), o = Ie(e, 0, 62, i), ze(e, 1835018), t = 0;
                    break;
                case 671756:
                    o = function(e, t, n) {
                        Ne(e);
                        const i = new Array;
                        for (; 1835021 !== e.currentToken;)
                            if (Be(e, 1572875)) {
                                if (i.push(Te), 1835021 === e.currentToken) break
                            } else {
                                if (i.push(Ie(e, t, 62, -513 & n)), !Be(e, 1572875)) break;
                                if (1835021 === e.currentToken) break
                            } return ze(e, 1835021), 512 & n ? new s.ArrayBindingPattern(i) : (e.assignable = !1, new s.ArrayLiteralExpression(i))
                    }(e, t, i), t = 0;
                    break;
                case 131079:
                    o = function(e, t) {
                        const n = new Array,
                            i = new Array;
                        Ne(e);
                        for (; 1835017 !== e.currentToken;) {
                            if (n.push(e.tokenValue), 12288 & e.currentToken) Ne(e), ze(e, 1572878), i.push(Ie(e, 0, 62, -513 & t));
                            else {
                                if (!(3072 & e.currentToken)) throw r.k.error(107, {
                                    state: e
                                });
                                {
                                    const {
                                        currentChar: n,
                                        currentToken: r,
                                        index: s
                                    } = e;
                                    Ne(e), Be(e, 1572878) ? i.push(Ie(e, 0, 62, -513 & t)) : (e.currentChar = n, e.currentToken = r, e.index = s, i.push(Ie(e, 0, 450, -513 & t)))
                                }
                            }
                            1835017 !== e.currentToken && ze(e, 1572875)
                        }
                        return ze(e, 1835017), 512 & t ? new s.ObjectBindingPattern(n, i) : (e.assignable = !1, new s.ObjectLiteralExpression(n, i))
                    }(e, i), t = 0;
                    break;
                case 540713:
                    o = new s.TemplateExpression([e.tokenValue]), e.assignable = !1, Ne(e), t = 0;
                    break;
                case 540714:
                    o = De(e, t, i, o, !1), t = 0;
                    break;
                case 4096:
                case 8192:
                    o = new s.PrimitiveLiteralExpression(e.tokenValue), e.assignable = !1, Ne(e), t = 0;
                    break;
                case 2050:
                case 2051:
                case 2049:
                case 2048:
                    o = He[63 & e.currentToken], e.assignable = !1, Ne(e), t = 0;
                    break;
                default:
                    throw e.index >= e.length ? r.k.error(104, {
                        state: e
                    }) : r.k.error(101, {
                        state: e
                    })
            }
            if (512 & i) return function(e, t) {
                if (0 == (65536 & t.$kind)) throw r.k.error(106, {
                    state: e
                });
                if (1051179 !== e.currentToken) throw r.k.error(106, {
                    state: e
                });
                Ne(e);
                const n = t,
                    i = Ie(e, 0, 61, 0);
                return new s.ForOfStatement(n, i)
            }(e, o);
            if (449 < n) return o;
            let a = e.tokenValue;
            for (;
                (16384 & e.currentToken) > 0;) {
                const n = [];
                let c;
                switch (e.currentToken) {
                    case 16392:
                        if (e.assignable = !0, Ne(e), 0 == (3072 & e.currentToken)) throw r.k.error(105, {
                            state: e
                        });
                        if (a = e.tokenValue, Ne(e), t = (1536 & t) << 1 | 2048 & t | (4096 & t) >> 1, 671750 === e.currentToken) {
                            0 === t && (t = 2048);
                            continue
                        }
                        o = 1024 & t ? new s.AccessScopeExpression(a, o.ancestor) : new s.AccessMemberExpression(o, a);
                        continue;
                    case 671756:
                        e.assignable = !0, Ne(e), t = 4096, o = new s.AccessKeyedExpression(o, Ie(e, 0, 62, i)), ze(e, 1835021);
                        break;
                    case 671750:
                        for (e.assignable = !1, Ne(e); 1835018 !== e.currentToken && (n.push(Ie(e, 0, 62, i)), Be(e, 1572875)););
                        ze(e, 1835018), o = 1024 & t ? new s.CallScopeExpression(a, n, o.ancestor) : 2048 & t ? new s.CallMemberExpression(o, a, n) : new s.CallFunctionExpression(o, n), t = 0;
                        break;
                    case 540713:
                        e.assignable = !1, c = [e.tokenValue], o = new s.TaggedTemplateExpression(c, c, o), Ne(e);
                        break;
                    case 540714:
                        o = De(e, t, i, o, !0)
                }
            }
        }
        if (448 < n) return o;
        for (;
            (65536 & e.currentToken) > 0;) {
            const r = e.currentToken;
            if ((448 & r) <= n) break;
            Ne(e), o = new s.BinaryExpression(He[63 & r], o, Ie(e, t, 448 & r, i)), e.assignable = !1
        }
        if (63 < n) return o;
        if (Be(e, 1572879)) {
            const n = Ie(e, t, 62, i);
            ze(e, 1572878), o = new s.ConditionalExpression(o, n, Ie(e, t, 62, i)), e.assignable = !1
        }
        if (62 < n) return o;
        if (Be(e, 1048615)) {
            if (!e.assignable) throw r.k.error(150, {
                state: e
            });
            o = new s.AssignExpression(o, Ie(e, t, 62, i))
        }
        if (61 < n) return o;
        for (; Be(e, 1572883);) {
            if (1572864 === e.currentToken) throw r.k.error(112);
            const n = e.tokenValue;
            Ne(e);
            const a = new Array;
            for (; Be(e, 1572878);) a.push(Ie(e, t, 62, i));
            o = new s.ValueConverterExpression(o, n, a)
        }
        for (; Be(e, 1572880);) {
            if (1572864 === e.currentToken) throw r.k.error(113);
            const n = e.tokenValue;
            Ne(e);
            const a = new Array;
            for (; Be(e, 1572878);) a.push(Ie(e, t, 62, i));
            o = new s.BindingBehaviorExpression(o, n, a)
        }
        if (1572864 !== e.currentToken) {
            if (2048 & i) return o;
            if ("of" === e.tokenRaw) throw r.k.error(151, {
                state: e
            });
            throw r.k.error(101, {
                state: e
            })
        }
        return o
    }

    function De(e, t, n, i, r) {
        const o = [e.tokenValue];
        ze(e, 540714);
        const a = [Ie(e, t, 62, n)];
        for (; 540713 !== (e.currentToken = Ue(e));) o.push(e.tokenValue), ze(e, 540714), a.push(Ie(e, t, 62, n));
        return o.push(e.tokenValue), e.assignable = !1, r ? (Ne(e), new s.TaggedTemplateExpression(o, o, i, a)) : (Ne(e), new s.TemplateExpression(o, a))
    }

    function Ne(e) {
        for (; e.index < e.length;)
            if (e.startIndex = e.index, null != (e.currentToken = et[e.currentChar](e))) return;
        e.currentToken = 1572864
    }

    function Ve(e) {
        return e.currentChar = e.input.charCodeAt(++e.index)
    }

    function $e(e, t) {
        let n = e.currentChar;
        if (!1 === t) {
            do {
                n = Ve(e)
            } while (n <= 57 && n >= 48);
            if (46 !== n) return e.tokenValue = parseInt(e.tokenRaw, 10), 8192;
            if (n = Ve(e), e.index >= e.length) return e.tokenValue = parseInt(e.tokenRaw.slice(0, -1), 10), 8192
        }
        if (n <= 57 && n >= 48)
            do {
                n = Ve(e)
            } while (n <= 57 && n >= 48);
        else e.currentChar = e.input.charCodeAt(--e.index);
        return e.tokenValue = parseFloat(e.tokenRaw), 8192
    }

    function Fe(e) {
        let t = !0,
            n = "";
        for (; 96 !== Ve(e);)
            if (36 === e.currentChar) {
                if (e.index + 1 < e.length && 123 === e.input.charCodeAt(e.index + 1)) {
                    e.index++, t = !1;
                    break
                }
                n += "$"
            } else if (92 === e.currentChar) n += String.fromCharCode(be(Ve(e)));
        else {
            if (e.index >= e.length) throw r.k.error(109, {
                state: e
            });
            n += String.fromCharCode(e.currentChar)
        }
        return Ve(e), e.tokenValue = n, t ? 540713 : 540714
    }

    function Ue(e) {
        if (e.index >= e.length) throw r.k.error(109, {
            state: e
        });
        return e.index--, Fe(e)
    }

    function Be(e, t) {
        return e.currentToken === t && (Ne(e), !0)
    }

    function ze(e, t) {
        if (e.currentToken !== t) throw r.k.error(110, {
            state: e,
            expected: t
        });
        Ne(e)
    }! function(e) {
        e[e.InvalidExpressionStart = 100] = "InvalidExpressionStart", e[e.UnconsumedToken = 101] = "UnconsumedToken", e[e.DoubleDot = 102] = "DoubleDot", e[e.InvalidMemberExpression = 103] = "InvalidMemberExpression", e[e.UnexpectedEndOfExpression = 104] = "UnexpectedEndOfExpression", e[e.ExpectedIdentifier = 105] = "ExpectedIdentifier", e[e.InvalidForDeclaration = 106] = "InvalidForDeclaration", e[e.InvalidObjectLiteralPropertyDefinition = 107] = "InvalidObjectLiteralPropertyDefinition", e[e.UnterminatedQuote = 108] = "UnterminatedQuote", e[e.UnterminatedTemplate = 109] = "UnterminatedTemplate", e[e.MissingExpectedToken = 110] = "MissingExpectedToken", e[e.UnexpectedCharacter = 111] = "UnexpectedCharacter", e[e.MissingValueConverter = 112] = "MissingValueConverter", e[e.MissingBindingBehavior = 113] = "MissingBindingBehavior"
    }(Le || (Le = {})),
    function(e) {
        e[e.NotAssignable = 150] = "NotAssignable", e[e.UnexpectedForOf = 151] = "UnexpectedForOf"
    }(Pe || (Pe = {}));
    const He = [Oe, Ce, Ae, Te, "$this", "$parent", "(", "{", ".", "}", ")", ",", "[", "]", ":", "?", "'", '"', "&", "|", "||", "&&", "==", "!=", "===", "!==", "<", ">", "<=", ">=", "in", "instanceof", "+", "-", "typeof", "void", "*", "%", "/", "=", "!", 540713, 540714, "of"],
        We = Object.create(null);
    We.true = 2049, We.null = 2050, We.false = 2048, We.undefined = 2051, We.$this = 3076, We.$parent = 3077, We.in = 1640798, We.instanceof = 1640799, We.typeof = 34850, We.void = 34851, We.of = 1051179;
    const qe = [36, 0, 48, 58, 65, 91, 95, 0, 97, 123],
        Ge = [36, 0, 65, 91, 95, 0, 97, 123, 170, 0, 186, 0, 192, 215, 216, 247, 248, 697, 736, 741, 7424, 7462, 7468, 7517, 7522, 7526, 7531, 7544, 7545, 7615, 7680, 7936, 8305, 0, 8319, 0, 8336, 8349, 8490, 8492, 8498, 0, 8526, 0, 8544, 8585, 11360, 11392, 42786, 42888, 42891, 42927, 42928, 42936, 42999, 43008, 43824, 43867, 43868, 43877, 64256, 64263, 65313, 65339, 65345, 65371],
        Ke = [48, 58],
        Ye = [0, 33, 127, 161];

    function Xe(e, t, n, i) {
        const r = n.length;
        for (let s = 0; s < r; s += 2) {
            const r = n[s];
            let o = n[s + 1];
            if (o = o > 0 ? o : r + 1, e && e.fill(i, r, o), t)
                for (let e = r; e < o; e++) t.add(e)
        }
    }

    function Je(e) {
        return t => (Ve(t), e)
    }
    const Qe = e => {
        throw r.k.error(111, {
            state: e
        })
    };
    Qe.notMapped = !0;
    Xe(null, new Set, qe, !0);
    const Ze = new Uint8Array(65535);
    Xe(Ze, null, Ge, 1), Xe(Ze, null, Ke, 1);
    const et = new Array(65535);
    et.fill(Qe, 0, 65535), Xe(et, null, Ye, e => (Ve(e), null)), Xe(et, null, Ge, (function(e) {
        for (; Ze[Ve(e)];);
        const t = We[e.tokenValue = e.tokenRaw];
        return void 0 === t ? 1024 : t
    })), Xe(et, null, Ke, e => $e(e, !1)), et[34] = et[39] = e => function(e) {
        const t = e.currentChar;
        Ve(e);
        let n = 0;
        const i = new Array;
        let s = e.index;
        for (; e.currentChar !== t;)
            if (92 === e.currentChar) i.push(e.input.slice(s, e.index)), Ve(e), n = be(e.currentChar), Ve(e), i.push(String.fromCharCode(n)), s = e.index;
            else {
                if (e.index >= e.length) throw r.k.error(108, {
                    state: e
                });
                Ve(e)
            } const o = e.input.slice(s, e.index);
        Ve(e), i.push(o);
        const a = i.join("");
        return e.tokenValue = a, 4096
    }(e), et[96] = e => Fe(e), et[33] = e => 61 !== Ve(e) ? 32808 : 61 !== Ve(e) ? 1638679 : (Ve(e), 1638681), et[61] = e => 61 !== Ve(e) ? 1048615 : 61 !== Ve(e) ? 1638678 : (Ve(e), 1638680), et[38] = e => 38 !== Ve(e) ? 1572880 : (Ve(e), 1638613), et[124] = e => 124 !== Ve(e) ? 1572883 : (Ve(e), 1638548), et[46] = e => Ve(e) <= 57 && e.currentChar >= 48 ? $e(e, !0) : 16392, et[60] = e => 61 !== Ve(e) ? 1638746 : (Ve(e), 1638748), et[62] = e => 61 !== Ve(e) ? 1638747 : (Ve(e), 1638749), et[37] = Je(1638885), et[40] = Je(671750), et[41] = Je(1835018), et[42] = Je(1638884), et[43] = Je(623008), et[44] = Je(1572875), et[45] = Je(623009), et[47] = Je(1638886), et[58] = Je(1572878), et[63] = Je(1572879), et[91] = Je(671756), et[93] = Je(1835021), et[123] = Je(131079), et[125] = Je(1835017);
    const tt = [{
            register(e) {
                e.registerTransformer(s.IExpressionParser, e => (Reflect.set(e, "parseCore", Re), e))
            }
        }],
        nt = [Z, Q],
        it = [ge, he, pe, de, fe, me, ve];
    class rt {
        constructor(e, t) {
            this.propName = e, this.mode = t
        }
    }
    class st {
        constructor(e, t) {
            this.name = e, this.containerless = t, this.bindables = Object.create(null)
        }
        static from(e) {
            const t = new st(e.name, e.containerless),
                n = e.bindables,
                i = s.BindingMode.toView;
            let o, a, c, l;
            for (a in n) o = n[a], void 0 !== o.property && (a = o.property), c = void 0 !== o.attribute ? o.attribute : Object(r.y)(a), l = void 0 !== o.mode && o.mode !== s.BindingMode.default ? o.mode : i, t.bindables[c] = new rt(a, l);
            return t
        }
    }
    class ot {
        constructor(e, t) {
            this.name = e, this.isTemplateController = t, this.bindables = Object.create(null), this.bindable = null
        }
        static from(e) {
            const t = new ot(e.name, e.isTemplateController),
                n = e.bindables,
                i = void 0 !== e.defaultBindingMode && e.defaultBindingMode !== s.BindingMode.default ? e.defaultBindingMode : s.BindingMode.toView;
            let r, o, a, c, l = !1,
                u = !1;
            for (o in n) {
                if (r = n[o], void 0 !== r.property && (o = r.property), a = void 0 !== r.mode && r.mode !== s.BindingMode.default ? r.mode : i, u = !0 === r.primary, c = t.bindables[o] = new rt(o, a), u) {
                    if (l) throw new Error("primary already exists");
                    l = !0, t.bindable = c
                }
                null === t.bindable && (t.bindable = c)
            }
            return null === t.bindable && (t.bindable = new rt("value", i)), t
        }
    }
    class at {
        constructor(e) {
            this.resources = e, this.elementLookup = Object.create(null), this.attributeLookup = Object.create(null), this.commandLookup = Object.create(null)
        }
        getElementInfo(e) {
            let t = this.elementLookup[e];
            if (void 0 === t) {
                const n = this.resources.find(s.CustomElement, e);
                this.elementLookup[e] = t = null === n ? null : st.from(n)
            }
            return t
        }
        getAttributeInfo(e) {
            let t = this.attributeLookup[e.target];
            if (void 0 === t) {
                const n = this.resources.find(s.CustomAttribute, e.target);
                this.attributeLookup[e.target] = t = null === n ? null : ot.from(n)
            }
            return t
        }
        getBindingCommand(e, t) {
            const n = e.command;
            if (null === n) return null;
            let i = this.commandLookup[n];
            if (void 0 === i) {
                if (i = this.resources.create(re, n), null === i) {
                    if (t) return null;
                    throw new Error("Unknown binding command: " + n)
                }
                this.commandLookup[n] = i
            }
            return i
        }
    }
    const ct = r.a.createInterface("IAttrSyntaxTransformer").noDefault();
    Array.prototype.slice;
    class lt {
        constructor(e, t, n, i, r, s, o, a) {
            this.dom = e, this.$state = 0, this.delegationStrategy = n, this.locator = a, this.preventDefault = s, this.sourceExpression = i, this.target = r, this.targetEvent = t, this.eventManager = o
        }
        callSource(e) {
            const t = this.$scope.overrideContext;
            t.$event = e;
            const n = this.sourceExpression.evaluate(2097152, this.$scope, this.locator, this.part);
            return Reflect.deleteProperty(t, "$event"), !0 !== n && this.preventDefault && e.preventDefault(), n
        }
        handleEvent(e) {
            this.callSource(e)
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(4096 | e)
            }
            this.$state |= 1, this.$scope = t, this.part = n;
            const i = this.sourceExpression;
            Object(s.hasBind)(i) && i.bind(e, t, this), this.handler = this.eventManager.addEventListener(this.dom, this.target, this.targetEvent, this, this.delegationStrategy), this.$state |= 4, this.$state &= -2
        }
        $unbind(e) {
            if (!(4 & this.$state)) return;
            this.$state |= 2;
            const t = this.sourceExpression;
            Object(s.hasUnbind)(t) && t.unbind(e, this.$scope, this), this.$scope = null, this.handler.dispose(), this.handler = null, this.$state &= -7
        }
        observeProperty(e, t, n) {}
        handleChange(e, t, n) {}
    }
    let ut = class {
        constructor(e, t, n, i, r, s) {
            this.observerLocator = n, this.lifecycle = e, this.obj = i, this.propertyKey = r, this.targetAttribute = s, this.currentValue = null, this.oldValue = null, this.hasChanges = !1, this.priority = 12288, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: e
                } = this;
                switch (this.oldValue = e, this.targetAttribute) {
                    case "class":
                        e ? this.obj.classList.add(this.propertyKey) : this.obj.classList.remove(this.propertyKey);
                        break;
                    case "style": {
                        let t = "",
                            n = e;
                        "string" == typeof n && n.includes("!important") && (t = "important", n = n.replace("!important", "")), this.obj.style.setProperty(this.propertyKey, n, t)
                    }
                }
            }
        }
        handleMutation(e) {
            let t = !1;
            for (let n = 0, i = e.length; i > n; ++n) {
                const i = e[n];
                if ("attributes" === i.type && i.attributeName === this.propertyKey) {
                    t = !0;
                    break
                }
            }
            if (t) {
                let e;
                switch (this.targetAttribute) {
                    case "class":
                        e = this.obj.classList.contains(this.propertyKey);
                        break;
                    case "style":
                        e = this.obj.style.getPropertyValue(this.propertyKey);
                        break;
                    default:
                        throw new Error("Unsupported targetAttribute: " + this.targetAttribute)
                }
                if (e !== this.currentValue) {
                    const {
                        currentValue: t
                    } = this;
                    this.currentValue = this.oldValue = e, this.hasChanges = !1, this.callSubscribers(e, t, 131072)
                }
            }
        }
        subscribe(e) {
            this.hasSubscribers() || (this.currentValue = this.oldValue = this.obj.getAttribute(this.propertyKey), ht(this.obj, this)), this.addSubscriber(e)
        }
        unsubscribe(e) {
            this.removeSubscriber(e), this.hasSubscribers() || dt(this.obj, this)
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority)
        }
        unbind(e) {
            536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
    };
    ut = Object(I.__decorate)([Object(s.subscriberCollection)()], ut);
    const ht = (e, t) => {
            void 0 === e.$eMObservers && (e.$eMObservers = new Set), void 0 === e.$mObserver && (e.$mObserver = s.DOM.createNodeObserver(e, pt, {
                attributes: !0
            })), e.$eMObservers.add(t)
        },
        dt = (e, t) => {
            const n = e.$eMObservers;
            return !!n.delete(t) && (0 === n.size && (e.$mObserver.disconnect(), e.$mObserver = void 0), !0)
        },
        pt = e => {
            e[0].target.$eMObservers.forEach(ft, e)
        };

    function ft(e) {
        e.handleMutation(this)
    }
    Array.prototype.slice;
    const {
        oneTime: gt,
        toView: mt,
        fromView: vt
    } = s.BindingMode, bt = mt | gt;
    let yt = class {
        constructor(e, t, n, i, r, o, a) {
            s.connectable.assignIdTo(this), this.$state = 0, this.$lifecycle = a.get(s.ILifecycle), this.$scope = null, this.locator = a, this.mode = r, this.observerLocator = o, this.sourceExpression = e, this.target = t, this.targetAttribute = n, this.targetProperty = i, this.persistentFlags = 0
        }
        updateTarget(e, t) {
            t |= this.persistentFlags, this.targetObserver.setValue(e, 16 | t)
        }
        updateSource(e, t) {
            t |= this.persistentFlags, this.sourceExpression.assign(32 | t, this.$scope, this.locator, e)
        }
        handleChange(e, t, n) {
            if (4 & this.$state) {
                if (n |= this.persistentFlags, this.mode === s.BindingMode.fromView && (n &= -17, n |= 32), 16 & n) {
                    const t = this.targetObserver.getValue();
                    return (10082 !== this.sourceExpression.$kind || this.observerSlots > 1) && (e = this.sourceExpression.evaluate(n, this.$scope, this.locator, this.part)), e !== t && this.updateTarget(e, n), void(0 == (this.mode & gt) && (this.version++, this.sourceExpression.connect(n, this.$scope, this, this.part), this.unobserve(!1)))
                }
                if (!(32 & n)) throw r.k.error(15, n);
                e !== this.sourceExpression.evaluate(n, this.$scope, this.locator, this.part) && this.updateSource(e, n)
            }
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(4096 | e)
            }
            this.$state |= 1, this.persistentFlags = 2080374799 & e, this.$scope = t, this.part = n;
            let i = this.sourceExpression;
            Object(s.hasBind)(i) && i.bind(e, t, this);
            let r = this.targetObserver;
            r || (r = this.targetObserver = new ut(this.$lifecycle, e, this.observerLocator, this.target, this.targetProperty, this.targetAttribute)), r.bind && r.bind(e), i = this.sourceExpression, this.mode & bt && this.updateTarget(i.evaluate(e, t, this.locator, n), e), this.mode & mt && i.connect(e, t, this, n), this.mode & vt && (r[this.id] |= 32, r.subscribe(this)), this.$state |= 4, this.$state &= -2
        }
        $unbind(e) {
            4 & this.$state && (this.$state |= 2, this.persistentFlags = 0, Object(s.hasUnbind)(this.sourceExpression) && this.sourceExpression.unbind(e, this.$scope, this), this.$scope = null, this.targetObserver.unbind && this.targetObserver.unbind(e), this.targetObserver.unsubscribe && (this.targetObserver.unsubscribe(this), this.targetObserver[this.id] &= -33), this.unobserve(!0), this.$state &= -7)
        }
        connect(e) {
            4 & this.$state && (e |= this.persistentFlags, this.sourceExpression.connect(2097152 | e, this.$scope, this, this.part))
        }
    };
    yt = Object(I.__decorate)([Object(s.connectable)()], yt);
    class wt {
        constructor(e, t, n, i, r) {
            this.lifecycle = e, this.obj = n, this.propertyKey = i, this.currentValue = null, this.oldValue = null, this.namespace = r, this.hasChanges = !1, this.priority = 12288, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: e
                } = this;
                this.oldValue = e, null == e ? this.obj.removeAttributeNS(this.namespace, this.propertyKey) : this.obj.setAttributeNS(this.namespace, this.propertyKey, e)
            }
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority), this.currentValue = this.oldValue = this.obj.getAttributeNS(this.namespace, this.propertyKey)
        }
        unbind(e) {
            536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
    }

    function kt(e, t) {
        return e === t
    }
    let xt = class {
        constructor(e, t, n, i, r) {
            this.lifecycle = e, this.observerLocator = n, this.handler = i, this.obj = r, this.currentValue = void 0, this.oldValue = void 0, this.hasChanges = !1, this.priority = 12288, this.arrayObserver = void 0, this.valueObserver = void 0, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: t
                } = this;
                this.oldValue = t, void 0 === this.valueObserver && (void 0 !== this.obj.$observers && (void 0 !== this.obj.$observers.model ? this.valueObserver = this.obj.$observers.model : void 0 !== this.obj.$observers.value && (this.valueObserver = this.obj.$observers.value)), void 0 !== this.valueObserver && this.valueObserver.subscribe(this)), void 0 !== this.arrayObserver && (this.arrayObserver.unsubscribeFromCollection(this), this.arrayObserver = void 0), "checkbox" === this.obj.type && Array.isArray(t) && (this.arrayObserver = this.observerLocator.getArrayObserver(e, t), this.arrayObserver.subscribeToCollection(this)), this.synchronizeElement()
            }
        }
        handleCollectionChange(e, t) {
            const {
                currentValue: n,
                oldValue: i
            } = this;
            (4096 & t) > 0 || 268435456 === this.persistentFlags ? (this.oldValue = n, this.synchronizeElement()) : this.hasChanges = !0, 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0), this.callSubscribers(n, i, t)
        }
        handleChange(e, t, n) {
            (4096 & n) > 0 || 268435456 === this.persistentFlags ? this.synchronizeElement() : this.hasChanges = !0, 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0), this.callSubscribers(e, t, n)
        }
        synchronizeElement() {
            const {
                currentValue: e,
                obj: t
            } = this, n = Object.prototype.hasOwnProperty.call(t, "model") ? t.model : t.value, i = "radio" === t.type, r = void 0 !== t.matcher ? t.matcher : kt;
            i ? t.checked = !!r(e, n) : !0 === e ? t.checked = !0 : Array.isArray(e) ? t.checked = -1 !== e.findIndex(e => !!r(e, n)) : t.checked = !1
        }
        handleEvent() {
            this.oldValue = this.currentValue;
            let {
                currentValue: e
            } = this;
            const {
                obj: t
            } = this, n = Object.prototype.hasOwnProperty.call(t, "model") ? t.model : t.value;
            let i;
            const r = void 0 !== t.matcher ? t.matcher : kt;
            if ("checkbox" === t.type) {
                if (Array.isArray(e)) return i = e.findIndex(e => !!r(e, n)), void(t.checked && -1 === i ? e.push(n) : t.checked || -1 === i || e.splice(i, 1));
                e = t.checked
            } else {
                if (!t.checked) return;
                e = n
            }
            this.currentValue = e, this.callSubscribers(this.currentValue, this.oldValue, 655360)
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority), this.currentValue = this.obj.checked
        }
        unbind(e) {
            void 0 !== this.arrayObserver && (this.arrayObserver.unsubscribeFromCollection(this), this.arrayObserver = void 0), void 0 !== this.valueObserver && this.valueObserver.unsubscribe(this), 536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
        subscribe(e) {
            this.hasSubscribers() || this.handler.subscribe(this.obj, this), this.addSubscriber(e)
        }
        unsubscribe(e) {
            this.removeSubscriber(e), this.hasSubscribers() || this.handler.dispose()
        }
    };
    xt = Object(I.__decorate)([Object(s.subscriberCollection)()], xt);
    class _t {
        constructor(e, t, n) {
            this.lifecycle = e, this.obj = n, this.currentValue = "", this.oldValue = "", this.doNotCache = !0, this.nameIndex = {}, this.version = 0, this.isActive = !1, this.hasChanges = !1, this.priority = 12288, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: e,
                    nameIndex: t
                } = this;
                let {
                    version: n
                } = this;
                this.oldValue = e;
                const i = this.getClassesToAdd(e);
                if (i.length > 0 && this.addClassesAndUpdateIndex(i), this.version += 1, 0 === n) return;
                n -= 1;
                for (const e in t) Object.prototype.hasOwnProperty.call(t, e) && t[e] === n && this.obj.classList.remove(e)
            }
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority)
        }
        unbind(e) {
            536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
        splitClassString(e) {
            const t = e.match(/\S+/g);
            return null === t ? r.g.emptyArray : t
        }
        getClassesToAdd(e) {
            if ("string" == typeof e) return this.splitClassString(e);
            if (e instanceof Array) {
                const t = e.length;
                if (t > 0) {
                    const n = [];
                    for (let i = 0; i < t; ++i) n.push(...this.getClassesToAdd(e[i]));
                    return n
                }
                return r.g.emptyArray
            }
            if (e instanceof Object) {
                const t = [];
                for (const n in e) e[n] && (n.includes(" ") ? t.push(...this.splitClassString(n)) : t.push(n));
                return t
            }
            return r.g.emptyArray
        }
        addClassesAndUpdateIndex(e) {
            const t = this.obj;
            for (let n = 0, i = e.length; n < i; n++) {
                const i = e[n];
                i.length && (this.nameIndex[i] = this.version, t.classList.add(i))
            }
        }
    }
    class St {
        constructor(e, t, n, i) {
            this.lifecycle = e, this.obj = n, this.propertyKey = i, this.currentValue = null, this.oldValue = null, this.hasChanges = !1, this.priority = 12288, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: e
                } = this;
                this.oldValue = e, null == e ? this.obj.removeAttribute(this.propertyKey) : this.obj.setAttribute(this.propertyKey, e)
            }
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority), this.currentValue = this.oldValue = this.obj.getAttribute(this.propertyKey)
        }
        unbind(e) {
            536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
    }
    class Ot {
        constructor(e, t, n, i) {
            this.lifecycle = e, this.obj = n, this.propertyKey = i, this.currentValue = void 0, this.oldValue = void 0, this.hasChanges = !1, this.priority = 12288, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: e
                } = this;
                this.oldValue = e, this.obj[this.propertyKey] = e
            }
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority), this.currentValue = this.oldValue = this.obj[this.propertyKey]
        }
        unbind(e) {
            536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
    }

    function Ct(e) {
        return e.composedPath && e.composedPath()[0] || e.deepPath && e.deepPath()[0] || e.path && e.path[0] || e.target
    }

    function At() {
        this.standardStopPropagation(), this.propagationStopped = !0
    }

    function Tt(e) {
        e.propagationStopped = !1;
        let t = Ct(e);
        const n = [];
        for (; t;) {
            if (t.capturedCallbacks) {
                const i = t.capturedCallbacks[e.type];
                i && (e.stopPropagation !== At && (e.standardStopPropagation = e.stopPropagation, e.stopPropagation = At), n.push(i))
            }
            t = t.parentNode
        }
        for (let t = n.length - 1; t >= 0 && !e.propagationStopped; t--) {
            const i = n[t];
            "handleEvent" in i ? i.handleEvent(e) : i(e)
        }
    }

    function Et(e) {
        e.propagationStopped = !1;
        let t = Ct(e);
        for (; t && !e.propagationStopped;) {
            if (t.delegatedCallbacks) {
                const n = t.delegatedCallbacks[e.type];
                n && (e.stopPropagation !== At && (e.standardStopPropagation = e.stopPropagation, e.stopPropagation = At), "handleEvent" in n ? n.handleEvent(e) : n(e))
            }
            t = t.parentNode
        }
    }
    class jt {
        constructor(e, t, n, i) {
            this.dom = e, this.capture = i, this.count = 0, this.eventName = t, this.listener = n
        }
        increment() {
            this.count++, 1 === this.count && this.dom.addEventListener(this.eventName, this.listener, null, this.capture)
        }
        decrement() {
            this.count--, 0 === this.count && this.dom.removeEventListener(this.eventName, this.listener, null, this.capture)
        }
        dispose() {
            this.count > 0 && (this.count = 0, this.dom.removeEventListener(this.eventName, this.listener, null, this.capture))
        }
    }
    class Mt {
        constructor(e, t, n, i) {
            this.entry = e, this.lookup = t, this.targetEvent = n, t[n] = i
        }
        dispose() {
            this.entry.decrement(), this.lookup[this.targetEvent] = null
        }
    }
    class Lt {
        constructor(e, t, n, i) {
            this.dom = e, this.target = t, this.targetEvent = n, this.callback = i, e.addEventListener(n, i, t)
        }
        dispose() {
            this.dom.removeEventListener(this.targetEvent, this.callback, this.target)
        }
    }
    class Pt {
        constructor(e, t) {
            this.dom = e, this.events = t, this.target = null, this.handler = null
        }
        subscribe(e, t) {
            this.target = e, this.handler = t;
            const n = this.dom.addEventListener,
                i = this.events;
            for (let r = 0, s = i.length; s > r; ++r) n(i[r], t, e)
        }
        dispose() {
            const e = this.target,
                t = this.handler,
                n = this.events,
                i = this.dom;
            for (let r = 0, s = n.length; s > r; ++r) i.removeEventListener(n[r], t, e);
            this.target = this.handler = null
        }
    }
    const Rt = r.a.createInterface("IEventManager").withDefault(e => e.singleton(It));
    class It {
        constructor() {
            this.delegatedHandlers = {}, this.capturedHandlers = {}, this.delegatedHandlers = {}, this.capturedHandlers = {}
        }
        addEventListener(e, t, n, i, r) {
            let o, a, c;
            if (r === s.DelegationStrategy.bubbling) {
                o = this.delegatedHandlers, c = o[n] || (o[n] = new jt(e, n, Et, !1)), c.increment();
                const r = t.delegatedCallbacks || (t.delegatedCallbacks = {});
                return new Mt(c, r, n, i)
            }
            if (r === s.DelegationStrategy.capturing) {
                a = this.capturedHandlers, c = a[n] || (a[n] = new jt(e, n, Tt, !0)), c.increment();
                const r = t.capturedCallbacks || (t.capturedCallbacks = {});
                return new Mt(c, r, n, i)
            }
            return new Lt(e, t, n, i)
        }
        dispose() {
            let e;
            const {
                delegatedHandlers: t,
                capturedHandlers: n
            } = this;
            for (e in t) t[e].dispose();
            for (e in n) n[e].dispose()
        }
    }
    const Dt = {
        childList: !0,
        subtree: !0,
        characterData: !0
    };

    function Nt(e, t) {
        return e === t
    }
    let Vt = class {
        constructor(e, t, n, i, r, s) {
            this.lifecycle = e, this.observerLocator = n, this.dom = i, this.obj = s, this.handler = r, this.currentValue = void 0, this.oldValue = void 0, this.hasChanges = !1, this.priority = 12288, this.arrayObserver = void 0, this.nodeObserver = void 0, this.handleNodeChange = this.handleNodeChange.bind(this), this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: t
                } = this;
                this.oldValue = t;
                const n = Array.isArray(t);
                if (!n && null != t && this.obj.multiple) throw new Error("Only null or Array instances can be bound to a multi-select.");
                this.arrayObserver && (this.arrayObserver.unsubscribeFromCollection(this), this.arrayObserver = void 0), n && (this.arrayObserver = this.observerLocator.getArrayObserver(e, t), this.arrayObserver.subscribeToCollection(this)), this.synchronizeOptions(), this.notify(e)
            }
        }
        handleCollectionChange(e, t) {
            (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.synchronizeOptions() : this.hasChanges = !0, 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0), this.callSubscribers(this.currentValue, this.oldValue, t)
        }
        handleChange(e, t, n) {
            (4096 & n) > 0 || 268435456 === this.persistentFlags ? this.synchronizeOptions() : this.hasChanges = !0, 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0), this.callSubscribers(e, t, n)
        }
        notify(e) {
            if ((4096 & e) > 0 || 268435456 === this.persistentFlags) return;
            const t = this.oldValue,
                n = this.currentValue;
            n !== t && this.callSubscribers(n, t, e)
        }
        handleEvent() {
            this.synchronizeValue() && this.callSubscribers(this.currentValue, this.oldValue, 655360)
        }
        synchronizeOptions(e) {
            const {
                currentValue: t,
                obj: n
            } = this, i = Array.isArray(t), r = void 0 !== n.matcher ? n.matcher : Nt, s = n.options;
            let o = s.length;
            for (; o-- > 0;) {
                const e = s[o],
                    n = Object.prototype.hasOwnProperty.call(e, "model") ? e.model : e.value;
                i ? e.selected = -1 !== t.findIndex(e => !!r(n, e)) : e.selected = !!r(n, t)
            }
        }
        synchronizeValue() {
            const e = this.obj,
                t = e.options,
                n = t.length,
                i = this.currentValue;
            let r = 0;
            if (e.multiple) {
                if (!Array.isArray(i)) return !0;
                let s;
                const o = e.matcher || Nt,
                    a = [];
                for (; r < n;) s = t[r], s.selected && a.push(Object.prototype.hasOwnProperty.call(s, "model") ? s.model : s.value), ++r;
                for (r = 0; r < i.length;) {
                    const e = i[r]; - 1 === a.findIndex(t => !!o(e, t)) ? i.splice(r, 1) : ++r
                }
                for (r = 0; r < a.length;) {
                    const e = a[r]; - 1 === i.findIndex(t => !!o(e, t)) && i.push(e), ++r
                }
                return !1
            }
            let s = null;
            for (; r < n;) {
                const e = t[r];
                if (e.selected) {
                    s = Object.prototype.hasOwnProperty.call(e, "model") ? e.model : e.value;
                    break
                }++r
            }
            return this.oldValue = this.currentValue, this.currentValue = s, !0
        }
        bind(e) {
            this.nodeObserver = this.dom.createNodeObserver(this.obj, this.handleNodeChange, Dt), 536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority)
        }
        unbind(e) {
            this.nodeObserver.disconnect(), this.nodeObserver = null, 536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this), this.arrayObserver && (this.arrayObserver.unsubscribeFromCollection(this), this.arrayObserver = null)
        }
        handleNodeChange() {
            this.synchronizeOptions();
            this.synchronizeValue() && this.notify(131072)
        }
        subscribe(e) {
            this.hasSubscribers() || this.handler.subscribe(this.obj, this), this.addSubscriber(e)
        }
        unsubscribe(e) {
            this.removeSubscriber(e), this.hasSubscribers() || this.handler.dispose()
        }
    };
    Vt = Object(I.__decorate)([Object(s.subscriberCollection)()], Vt);
    class $t {
        constructor(e, t, n) {
            this.lifecycle = e, this.obj = n, this.currentValue = "", this.oldValue = "", this.styles = {}, this.version = 0, this.hasChanges = !1, this.priority = 12288, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.obj.style.cssText
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        getStyleTuplesFromString(e) {
            const t = [],
                n = /\s*([\w-]+)\s*:\s*((?:(?:[\w-]+\(\s*(?:"(?:\\"|[^"])*"|'(?:\\'|[^'])*'|[\w-]+\(\s*(?:[^"](?:\\"|[^"])*"|'(?:\\'|[^'])*'|[^)]*)\),?|[^)]*)\),?|"(?:\\"|[^"])*"|'(?:\\'|[^'])*'|[^;]*),?\s*)+);?/g;
            let i, r;
            for (; null !== (i = n.exec(e));) r = i[1], 0 !== r.length && t.push([r, i[2]]);
            return t
        }
        getStyleTuplesFromObject(e) {
            let t;
            const n = [];
            for (const i in e) t = e[i], null != t && ("string" != typeof t ? n.push(...this.getStyleTuples(t)) : n.push([Object(r.y)(i), t]));
            return n
        }
        getStyleTuplesFromArray(e) {
            const t = e.length;
            if (t > 0) {
                const n = [];
                for (let i = 0; i < t; ++i) n.push(...this.getStyleTuples(e[i]));
                return n
            }
            return r.g.emptyArray
        }
        getStyleTuples(e) {
            return "string" == typeof e ? this.getStyleTuplesFromString(e) : e instanceof Array ? this.getStyleTuplesFromArray(e) : e instanceof Object ? this.getStyleTuplesFromObject(e) : r.g.emptyArray
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: e
                } = this;
                this.oldValue = e;
                const t = this.styles;
                let n, i = this.version;
                const r = this.getStyleTuples(e);
                let s, o, a;
                const c = r.length;
                for (let e = 0; e < c; ++e) s = r[e], o = s[0], a = s[1], this.setProperty(o, a);
                if (this.styles = t, this.version += 1, 0 === i) return;
                for (n in i -= 1, t) Object.prototype.hasOwnProperty.call(t, n) && t[n] === i && this.obj.style.removeProperty(n)
            }
        }
        setProperty(e, t) {
            let n = "";
            null != t && "function" == typeof t.indexOf && t.includes("!important") && (n = "important", t = t.replace("!important", "")), this.obj.style.setProperty(e, t, n)
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority), this.oldValue = this.currentValue = this.obj.style.cssText
        }
        unbind(e) {
            536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
    }
    const Ft = r.a.createInterface("ISVGAnalyzer").withDefault(e => e.singleton(class {
        isStandardSvgAttribute(e, t) {
            return !1
        }
    }));
    let Ut = class {
        constructor(e, t, n, i, r) {
            this.lifecycle = e, this.handler = n, this.obj = i, this.propertyKey = r, this.currentValue = "", this.oldValue = "", this.hasChanges = !1, this.priority = 12288, this.persistentFlags = 805306383 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 || 268435456 === this.persistentFlags ? this.flushRAF(t) : 536870912 !== this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority, !0)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: t,
                    oldValue: n
                } = this;
                this.oldValue = t, this.obj[this.propertyKey] = null == t ? "" : t, 0 == (4096 & e) && this.callSubscribers(t, n, e)
            }
        }
        handleEvent() {
            const e = this.oldValue = this.currentValue,
                t = this.currentValue = this.obj[this.propertyKey];
            e !== t && (this.oldValue = t, this.callSubscribers(t, e, 655360))
        }
        subscribe(e) {
            this.hasSubscribers() || (this.handler.subscribe(this.obj, this), this.currentValue = this.oldValue = this.obj[this.propertyKey]), this.addSubscriber(e)
        }
        unsubscribe(e) {
            this.removeSubscriber(e), this.hasSubscribers() || this.handler.dispose()
        }
        bind(e) {
            536870912 === this.persistentFlags && this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority)
        }
        unbind(e) {
            536870912 === this.persistentFlags && this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
    };
    Ut = Object(I.__decorate)([Object(s.subscriberCollection)()], Ut);
    const Bt = "http://www.w3.org/1999/xlink",
        zt = "http://www.w3.org/XML/1998/namespace",
        Ht = "http://www.w3.org/2000/xmlns/",
        Wt = Object.assign(Object.create(null), {
            "xlink:actuate": ["actuate", Bt],
            "xlink:arcrole": ["arcrole", Bt],
            "xlink:href": ["href", Bt],
            "xlink:role": ["role", Bt],
            "xlink:show": ["show", Bt],
            "xlink:title": ["title", Bt],
            "xlink:type": ["type", Bt],
            "xml:lang": ["lang", zt],
            "xml:space": ["space", zt],
            xmlns: ["xmlns", Ht],
            "xmlns:xlink": ["xlink", Ht]
        }),
        qt = ["change", "input"],
        Gt = ["change"],
        Kt = ["change", "input", "blur", "keyup", "paste"],
        Yt = ["scroll"],
        Xt = Object.assign(Object.create(null), {
            class: !0,
            style: !0,
            css: !0,
            checked: !0,
            value: !0,
            model: !0,
            "xlink:actuate": !0,
            "xlink:arcrole": !0,
            "xlink:href": !0,
            "xlink:role": !0,
            "xlink:show": !0,
            "xlink:title": !0,
            "xlink:type": !0,
            "xml:lang": !0,
            "xml:space": !0,
            xmlns: !0,
            "xmlns:xlink": !0
        });
    class Jt {
        constructor(e, t) {
            this.dom = e, this.svgAnalyzer = t
        }
        static register(e) {
            return r.j.singleton(s.ITargetObserverLocator, this).register(e)
        }
        getObserver(e, t, n, i, r) {
            switch (r) {
                case "checked":
                    return new xt(t, e, n, new Pt(this.dom, qt), i);
                case "value":
                    return "SELECT" === i.tagName ? new Vt(t, e, n, this.dom, new Pt(this.dom, Gt), i) : new Ut(t, e, new Pt(this.dom, qt), i, r);
                case "files":
                    return new Ut(t, e, new Pt(this.dom, qt), i, r);
                case "textContent":
                case "innerHTML":
                    return new Ut(t, e, new Pt(this.dom, Kt), i, r);
                case "scrollTop":
                case "scrollLeft":
                    return new Ut(t, e, new Pt(this.dom, Yt), i, r);
                case "class":
                    return new _t(t, e, i);
                case "style":
                case "css":
                    return new $t(t, e, i);
                case "model":
                    return new s.SetterObserver(t, e, i, r);
                case "role":
                    return new St(t, e, i, r);
                default:
                    if (void 0 !== Wt[r]) {
                        const n = Wt[r];
                        return new wt(t, e, i, n[0], n[1])
                    }
                    if (en(i, r, this.svgAnalyzer)) return new St(t, e, i, r)
            }
            return null
        }
        overridesAccessor(e, t, n) {
            return !0 === Xt[n]
        }
        handles(e, t) {
            return this.dom.isNodeInstance(t)
        }
    }
    Jt.inject = [s.IDOM, Ft];
    class Qt {
        constructor(e, t) {
            this.dom = e, this.svgAnalyzer = t
        }
        static register(e) {
            return r.j.singleton(s.ITargetAccessorLocator, this).register(e)
        }
        getAccessor(e, t, n, i) {
            switch (i) {
                case "textContent":
                    return new Ot(t, e, n, i);
                case "class":
                    return new _t(t, e, n);
                case "style":
                case "css":
                    return new $t(t, e, n);
                case "src":
                case "href":
                case "role":
                    return new St(t, e, n, i);
                default:
                    if (void 0 !== Wt[i]) {
                        const r = Wt[i];
                        return new wt(t, e, n, r[0], r[1])
                    }
                    return en(n, i, this.svgAnalyzer) ? new St(t, e, n, i) : new Ot(t, e, n, i)
            }
        }
        handles(e, t) {
            return this.dom.isNodeInstance(t)
        }
    }
    Qt.inject = [s.IDOM, Ft];
    const Zt = {};

    function en(e, t, n) {
        if (!0 === Zt[t]) return !0;
        const i = t.slice(0, 5);
        return Zt[t] = "aria-" === i || "data-" === i || n.isStandardSvgAttribute(e, t)
    }
    let tn = class {
        bind(e, t, n) {
            n.targetObserver = new St(n.locator.get(s.ILifecycle), e, n.target, n.targetProperty)
        }
        unbind(e, t, n) {}
    };

    function nn(e) {
        const t = Ct(e);
        if (this.target === t) return this.selfEventCallSource(e)
    }
    tn = Object(I.__decorate)([Object(s.bindingBehavior)("attr")], tn);
    let rn = class {
        bind(e, t, n) {
            if (!n.callSource || !n.targetEvent) throw r.k.error(8);
            n.selfEventCallSource = n.callSource, n.callSource = nn
        }
        unbind(e, t, n) {
            n.callSource = n.selfEventCallSource, n.selfEventCallSource = null
        }
    };
    rn = Object(I.__decorate)([Object(s.bindingBehavior)("self")], rn);
    let sn = class {
        constructor(e) {
            this.observerLocator = e
        }
        bind(e, t, n, ...i) {
            if (0 === i.length) throw r.k.error(9);
            if (n.mode !== s.BindingMode.twoWay && n.mode !== s.BindingMode.fromView) throw r.k.error(10);
            this.persistentFlags = 2080374799 & e;
            const o = this.observerLocator.getObserver(this.persistentFlags | e, n.target, n.targetProperty);
            if (!o.handler) throw r.k.error(10);
            n.targetObserver = o, o.originalHandler = n.targetObserver.handler, o.handler = new Pt(n.locator.get(s.IDOM), i)
        }
        unbind(e, t, n) {
            n.targetObserver.handler.dispose(), n.targetObserver.handler = n.targetObserver.originalHandler, n.targetObserver.originalHandler = null
        }
    };
    sn = Object(I.__decorate)([Object(s.bindingBehavior)("updateTrigger"), Object(I.__param)(0, s.IObserverLocator)], sn);
    const on = Symbol(),
        an = {
            passive: !0,
            capture: !0
        },
        cn = {
            passive: !0
        },
        ln = new WeakMap;
    class un {
        constructor(e, t) {
            this.dom = e, this.lifecycle = t, ln.set(e.document, this), this.dom = e, this.blurs = [], this.handler = pn(this, this.blurs)
        }
        static createFor(e, t) {
            return ln.get(e.document) || new un(e, t)
        }
        register(e) {
            const t = this.blurs;
            t.includes(e) || 1 !== t.push(e) || this.addListeners()
        }
        unregister(e) {
            const t = this.blurs,
                n = t.indexOf(e);
            n > -1 && t.splice(n, 1), 0 === t.length && this.removeListeners()
        }
        addListeners() {
            const e = this.dom,
                t = e.document,
                n = e.window,
                i = this.handler;
            n.navigator.pointerEnabled && t.addEventListener("pointerdown", i, an), t.addEventListener("touchstart", i, an), t.addEventListener("mousedown", i, an), t.addEventListener("focus", i, an), n.addEventListener("blur", i, cn)
        }
        removeListeners() {
            const e = this.dom,
                t = e.document,
                n = e.window,
                i = this.handler;
            n.navigator.pointerEnabled && t.removeEventListener("pointerdown", i, an), t.removeEventListener("touchstart", i, an), t.removeEventListener("mousedown", i, an), t.removeEventListener("focus", i, an), n.removeEventListener("blur", i, cn)
        }
    }
    let hn = class {
        constructor(e, t, n) {
            this.element = e, this.dom = t, this.linkedMultiple = !0, this.searchSubTree = !0, this.linkingContext = null, this.value = on, this.manager = un.createFor(t, n)
        }
        attached() {
            this.manager.register(this)
        }
        detaching() {
            this.manager.unregister(this)
        }
        handleEventTarget(e) {
            if (!1 === this.value) return;
            const t = this.dom;
            e !== t.window && e !== t.document && this.contains(e) || this.triggerBlur()
        }
        contains(e) {
            if (!this.value) return !1;
            let t, n, i, s, o;
            const a = this.element;
            if (dn(a, e)) return !0;
            if (!this.linkedWith) return !1;
            const c = this.dom.document,
                l = this.linkedWith,
                u = this.linkingContext,
                h = this.searchSubTree,
                d = this.linkedMultiple,
                p = Array.isArray(l) ? l : [l],
                f = ("string" == typeof u ? c.querySelector(u) : u) || c.body,
                g = p.length;
            for (n = 0; g > n; ++n)
                if (o = p[n], "string" == typeof o) {
                    if (h) {
                        if (d) t = f.querySelectorAll(o);
                        else {
                            const e = f.querySelector(o);
                            t = null !== e ? [e] : r.g.emptyArray
                        }
                        for (s = t.length, i = 0; s > i; ++i)
                            if (t[i].contains(e)) return !0
                    } else
                        for (t = f.children, s = t.length, i = 0; s > i; ++i)
                            if (t[i].matches(o)) return !0
                } else if (o && o.contains(e)) return !0;
            return !1
        }
        triggerBlur() {
            this.value = !1, "function" == typeof this.onBlur && this.onBlur.call(null)
        }
    };
    Object(I.__decorate)([Object(s.bindable)()], hn.prototype, "value", void 0), Object(I.__decorate)([Object(s.bindable)()], hn.prototype, "onBlur", void 0), Object(I.__decorate)([Object(s.bindable)()], hn.prototype, "linkedWith", void 0), Object(I.__decorate)([Object(s.bindable)()], hn.prototype, "linkedMultiple", void 0), Object(I.__decorate)([Object(s.bindable)()], hn.prototype, "searchSubTree", void 0), Object(I.__decorate)([Object(s.bindable)()], hn.prototype, "linkingContext", void 0), hn = Object(I.__decorate)([Object(s.customAttribute)("blur"), Object(I.__param)(0, s.INode), Object(I.__param)(1, s.IDOM), Object(I.__param)(2, s.ILifecycle)], hn);
    const dn = (e, t) => {
            if (e.contains(t)) return !0;
            let n = null;
            for (; null != t;) {
                if (t === e) return !0;
                n = t.parentNode, null !== n || 11 !== t.nodeType ? t = n : t = t.host
            }
            return !1
        },
        pn = (e, t) => {
            let n = !1;
            const i = () => {
                    n = !1
                },
                r = () => {
                    n = !0, e.lifecycle.enqueueRAF(i, void 0, 32768, !0)
                },
                s = e => {
                    n || (o(e), r())
                },
                o = e => {
                    const n = e.composed ? e.composedPath()[0] : e.target;
                    if (null !== n)
                        for (let e = 0, i = t.length; e < i; ++e) t[e].handleEventTarget(n)
                };
            return {
                onpointerdown: s,
                ontouchstart: s,
                onmousedown: s,
                onfocus: i => {
                    if (n) return;
                    if (i.target === e.dom.window)
                        for (let e = 0, n = t.length; n > e; ++e) t[e].triggerBlur();
                    else o(i);
                    r()
                },
                onblur: () => {
                    n = !1;
                    for (let e = 0, n = t.length; e < n; ++e) t[e].triggerBlur()
                },
                handleEvent(e) {
                    this["on" + e.type](e)
                }
            }
        };
    let fn = class {
        constructor(e, t) {
            this.element = e, this.dom = t, this.element = e, this.dom = t, this.needsApply = !1
        }
        binding() {
            this.valueChanged()
        }
        valueChanged() {
            32 & this.$controller.state ? this.apply() : this.needsApply = !0
        }
        attached() {
            this.needsApply && (this.needsApply = !1, this.apply());
            const e = this.element;
            e.addEventListener("focus", this), e.addEventListener("blur", this)
        }
        detached() {
            const e = this.element;
            e.removeEventListener("focus", this), e.removeEventListener("blur", this)
        }
        handleEvent(e) {
            "focus" === e.type ? this.value = !0 : this.dom.document.activeElement !== this.element && (this.value = !1)
        }
        apply() {
            const e = this.element;
            this.value ? e.focus() : e.blur()
        }
    };

    function gn(e) {
        return null == e ? s.LifecycleTask.done : "function" == typeof e.then ? new s.TerminalTask(e) : e
    }
    Object(I.__decorate)([Object(s.bindable)({
        mode: s.BindingMode.twoWay
    })], fn.prototype, "value", void 0), fn = Object(I.__decorate)([Object(s.customAttribute)("focus"), Object(I.__param)(0, s.INode), Object(I.__param)(1, s.IDOM)], fn);
    let mn = class {
        constructor(e, t, n) {
            this.factory = e, this.originalLoc = t, this.dom = n, this.id = Object(r.B)("au$component"), this.currentTarget = n.createElement("div"), this.task = s.LifecycleTask.done, this.view = this.factory.create(), this.view.hold(t, 1), this.strict = !1
        }
        binding(e) {
            return null == this.callbackContext && (this.callbackContext = this.$controller.scope.bindingContext), this.view.bind(e, this.$controller.scope)
        }
        attached(e) {
            this.targetChanged()
        }
        detaching(e) {
            this.task = this.deactivate(e)
        }
        unbinding(e) {
            return this.callbackContext = null, this.view.unbind(e)
        }
        targetChanged() {
            const e = this.$controller;
            0 != (4 & e.state) && this.project(e.flags)
        }
        project(e) {
            const t = this.currentTarget,
                n = this.currentTarget = this.resolveTarget();
            t !== n && (this.task = this.deactivate(e), this.task = this.activate(n, e))
        }
        activate(e, t) {
            const {
                activating: n,
                activated: i,
                callbackContext: r,
                view: o
            } = this;
            let a = this.task;
            return o.hold(e, 2), 0 == (40 & this.$controller.state) || ("function" == typeof n && (a = a.done ? gn(n.call(r, e, o)) : new s.ContinuationTask(a, n, r, e, o)), a.done ? o.attach(t) : a = new s.ContinuationTask(a, o.attach, o, t), "function" == typeof i && (a = a.done ? gn(i.call(r, e, o)) : new s.ContinuationTask(a, i, r, e, o))), a
        }
        deactivate(e) {
            const {
                deactivating: t,
                deactivated: n,
                callbackContext: i,
                view: r,
                target: o
            } = this;
            let a = this.task;
            return "function" == typeof t && (a = a.done ? gn(t.call(i, o, r)) : new s.ContinuationTask(a, t, i, o, r)), a.done ? r.detach(e) : a = new s.ContinuationTask(a, r.detach, r, e), "function" == typeof n && (a = a.done ? gn(n.call(i, o, r)) : new s.ContinuationTask(a, n, i, o, r)), a
        }
        resolveTarget() {
            const e = this.dom,
                t = e.document;
            let n = this.target,
                i = this.renderContext;
            if ("string" == typeof n) {
                let r = t;
                "string" == typeof i && (i = t.querySelector(i)), e.isNodeInstance(i) && (r = i), n = r.querySelector(n)
            }
            if (e.isNodeInstance(n)) return n;
            if (null == n) {
                if (this.strict) throw new Error("Render target not found");
                n = t.body
            }
            return n
        }
    };
    var vn;

    function bn(e) {
        const t = e.type;
        return "string" == typeof t && 2 === t.length
    }
    Object(I.__decorate)([Object(s.bindable)({
            primary: !0
        })], mn.prototype, "target", void 0), Object(I.__decorate)([Object(s.bindable)({
            callback: "targetChanged"
        })], mn.prototype, "renderContext", void 0), Object(I.__decorate)([Object(s.bindable)()], mn.prototype, "strict", void 0), Object(I.__decorate)([Object(s.bindable)()], mn.prototype, "deactivating", void 0), Object(I.__decorate)([Object(s.bindable)()], mn.prototype, "activating", void 0), Object(I.__decorate)([Object(s.bindable)()], mn.prototype, "deactivated", void 0), Object(I.__decorate)([Object(s.bindable)()], mn.prototype, "activated", void 0), Object(I.__decorate)([Object(s.bindable)()], mn.prototype, "callbackContext", void 0), mn = Object(I.__decorate)([Object(s.templateController)("portal"), Object(I.__param)(0, s.IViewFactory), Object(I.__param)(1, s.IRenderLocation), Object(I.__param)(2, s.IDOM)], mn),
        function(e) {
            e.textBinding = "ha", e.listenerBinding = "hb", e.attributeBinding = "hc", e.stylePropertyBinding = "hd", e.setAttribute = "he", e.setClassAttribute = "hf", e.setStyleAttribute = "hg"
        }(vn || (vn = {}));
    class yn {
        constructor(e) {
            this.type = "ha", this.from = e
        }
    }
    class wn {
        constructor(e, t) {
            this.type = "hb", this.from = e, this.preventDefault = !0, this.strategy = s.DelegationStrategy.none, this.to = t
        }
    }
    class kn {
        constructor(e, t) {
            this.type = "hb", this.from = e, this.preventDefault = !1, this.strategy = s.DelegationStrategy.bubbling, this.to = t
        }
    }
    class xn {
        constructor(e, t) {
            this.type = "hb", this.from = e, this.preventDefault = !1, this.strategy = s.DelegationStrategy.capturing, this.to = t
        }
    }
    class _n {
        constructor(e, t) {
            this.type = "he", this.to = t, this.value = e
        }
    }
    class Sn {
        constructor(e) {
            this.type = "hf", this.value = e
        }
    }
    class On {
        constructor(e) {
            this.type = "hg", this.value = e
        }
    }
    class Cn {
        constructor(e, t, n) {
            this.type = "hc", this.from = t, this.attr = e, this.to = n
        }
    }

    function An(e, t, n, i) {
        if ("string" == typeof t) return function(e, t, n, i) {
            const r = [],
                s = [],
                o = [],
                a = e.createElement(t);
            let c = !1;
            n && Object.keys(n).forEach(t => {
                const i = n[t];
                bn(i) ? (c = !0, r.push(i)) : e.setAttribute(a, t, i)
            });
            c && (e.makeTarget(a), s.push(r));
            i && En(e, a, i, s, o);
            return new Tn(e, a, s, o)
        }(e, t, n, i);
        if (s.CustomElement.isType(t)) return function(e, t, n, i) {
            const r = s.CustomElement.getDefinition(t),
                o = r.name,
                a = [],
                c = [a],
                l = [],
                u = [],
                h = r.bindables,
                d = e.createElement(o);
            e.makeTarget(d), l.includes(t) || l.push(t);
            a.push(new s.HydrateElementInstruction(o, u)), n && Object.keys(n).forEach(e => {
                const t = n[e];
                if (bn(t)) u.push(t);
                else {
                    void 0 !== h[e] ? u.push({
                        type: "re",
                        to: e,
                        value: t
                    }) : u.push(new _n(t, e))
                }
            });
            i && En(e, d, i, c, l);
            return new Tn(e, d, c, l)
        }(e, t, n, i);
        throw new Error("Invalid tagOrType.")
    }
    class Tn {
        constructor(e, t, n, i) {
            this.dom = e, this.node = t, this.instructions = n, this.dependencies = i, this.lazyDefinition = void 0
        }
        get definition() {
            return void 0 === this.lazyDefinition && (this.lazyDefinition = s.CustomElementDefinition.create({
                name: s.CustomElement.generateName(),
                template: this.node,
                needsCompile: "string" == typeof this.node,
                instructions: this.instructions,
                dependencies: this.dependencies
            })), this.lazyDefinition
        }
        getElementTemplate(e, t) {
            return e.getElementTemplate(this.dom, this.definition, void 0, t)
        }
        createView(e, t, n) {
            return this.getViewFactory(t, n).create()
        }
        getViewFactory(e, t) {
            return e.getViewFactory(this.dom, this.definition, t)
        }
        mergeInto(e, t, n) {
            this.dom.appendChild(e, this.node), t.push(...this.instructions), n.push(...this.dependencies)
        }
    }

    function En(e, t, n, i, r) {
        for (let s = 0, o = n.length; s < o; ++s) {
            const o = n[s];
            switch (typeof o) {
                case "string":
                    e.appendChild(t, e.createTextNode(o));
                    break;
                case "object":
                    e.isNodeInstance(o) ? e.appendChild(t, o) : "mergeInto" in o && o.mergeInto(t, i, r)
            }
        }
    }
    const jn = ["subject", "composing"];
    let Mn = class {
        constructor(e, t, n, i) {
            this.dom = e, this.renderable = t, this.instruction = n, this.renderingEngine = i, this.id = Object(r.B)("au$component"), this.subject = void 0, this.composing = !1, this.view = void 0, this.task = s.LifecycleTask.done, this.lastSubject = void 0, this.properties = n.instructions.filter(e => !jn.includes(e.to)).reduce((e, t) => (t.to && (e[t.to] = t), e), {})
        }
        binding(e) {
            return this.task.done ? this.task = this.compose(this.subject, e) : this.task = new s.ContinuationTask(this.task, this.compose, this, this.subject, e), this.task.done ? this.task = this.bindView(e) : this.task = new s.ContinuationTask(this.task, this.bindView, this, e), this.task
        }
        attaching(e) {
            this.task.done ? this.attachView(e) : this.task = new s.ContinuationTask(this.task, this.attachView, this, e)
        }
        detaching(e) {
            null != this.view && (this.task.done ? this.view.detach(e) : this.task = new s.ContinuationTask(this.task, this.view.detach, this.view, e))
        }
        unbinding(e) {
            return this.lastSubject = void 0, null != this.view && (this.task.done ? this.task = this.view.unbind(e) : this.task = new s.ContinuationTask(this.task, this.view.unbind, this.view, e)), this.task
        }
        caching(e) {
            this.view = void 0
        }
        subjectChanged(e, t, n) {
            n |= this.$controller.flags, this.task.done ? this.task = this.compose(e, n) : this.task = new s.ContinuationTask(this.task, this.compose, this, e, n)
        }
        compose(e, t) {
            if (this.lastSubject === e) return s.LifecycleTask.done;
            this.lastSubject = e, this.composing = !0;
            let n = this.deactivate(t);
            if (e instanceof Promise) {
                let i;
                i = n.done ? e.then(e => this.resolveView(e, t)) : n.wait().then(() => e.then(e => this.resolveView(e, t))), n = new s.PromiseTask(i, this.activate, this, t)
            } else {
                const i = this.resolveView(e, t);
                n = n.done ? this.activate(i, t) : new s.ContinuationTask(n, this.activate, this, i, t)
            }
            return n.done ? this.onComposed() : n = new s.ContinuationTask(n, this.onComposed, this), n
        }
        deactivate(e) {
            const t = this.view;
            return null == t ? s.LifecycleTask.done : (t.detach(e), t.unbind(e))
        }
        activate(e, t) {
            if (this.view = e, null == e) return s.LifecycleTask.done;
            let n = this.bindView(t);
            return n.done ? this.attachView(t) : n = new s.ContinuationTask(n, this.attachView, this, t), n
        }
        bindView(e) {
            return null != this.view && (5 & this.$controller.state) > 0 ? this.view.bind(e, this.renderable.scope, this.$controller.part) : s.LifecycleTask.done
        }
        attachView(e) {
            null != this.view && (40 & this.$controller.state) > 0 && this.view.attach(e)
        }
        onComposed() {
            this.composing = !1
        }
        resolveView(e, t) {
            const n = this.provideViewFor(e, t);
            if (n) return n.hold(this.$controller.projector.host, 1), n.lockScope(this.renderable.scope), n
        }
        provideViewFor(e, t) {
            if (e) return "lockScope" in e ? e : "createView" in e ? e.createView(t, this.renderingEngine, this.renderable.context) : "create" in e ? e.create() : "template" in e ? this.renderingEngine.getViewFactory(this.dom, e, this.renderable.context).create() : An(this.dom, e, this.properties, void 0 === this.$controller.projector ? r.g.emptyArray : this.$controller.projector.children).createView(t, this.renderingEngine, this.renderable.context)
        }
    };
    var Ln;
    Object(I.__decorate)([s.bindable], Mn.prototype, "subject", void 0), Object(I.__decorate)([Object(s.bindable)({
            mode: s.BindingMode.fromView
        })], Mn.prototype, "composing", void 0), Mn = Object(I.__decorate)([Object(s.customElement)({
            name: "au-compose",
            template: null,
            containerless: !0
        }), Object(I.__param)(0, s.IDOM), Object(I.__param)(1, s.IController), Object(I.__param)(2, s.ITargetedInstruction), Object(I.__param)(3, s.IRenderingEngine)], Mn),
        function(e) {
            e[e.Element = 1] = "Element", e[e.Attr = 2] = "Attr", e[e.Text = 3] = "Text", e[e.CDATASection = 4] = "CDATASection", e[e.EntityReference = 5] = "EntityReference", e[e.Entity = 6] = "Entity", e[e.ProcessingInstruction = 7] = "ProcessingInstruction", e[e.Comment = 8] = "Comment", e[e.Document = 9] = "Document", e[e.DocumentType = 10] = "DocumentType", e[e.DocumentFragment = 11] = "DocumentFragment", e[e.Notation = 12] = "Notation"
        }(Ln || (Ln = {}));
    class Pn {
        constructor(e, t, n, i, o, a, c, l) {
            this.window = e, this.document = t, this.Node = n, this.Element = i, this.HTMLElement = o, this.CustomEvent = a, this.CSSStyleSheet = c, this.ShadowRoot = l, s.DOM.isInitialized && (r.k.write(1001), s.DOM.destroy()), s.DOM.initialize(this)
        }
        static register(e) {
            return r.j.alias(s.IDOM, this).register(e)
        }
        addEventListener(e, t, n, i) {
            (n || this.document).addEventListener(e, t, i)
        }
        appendChild(e, t) {
            e.appendChild(t)
        }
        cloneNode(e, t) {
            return e.cloneNode(!1 !== t)
        }
        convertToRenderLocation(e) {
            if (this.isRenderLocation(e)) return e;
            if (null == e.parentNode) throw r.k.error(52);
            const t = this.document.createComment("au-end"),
                n = this.document.createComment("au-start");
            return e.parentNode.replaceChild(t, e), t.parentNode.insertBefore(n, t), t.$start = n, n.$nodes = null, t
        }
        createDocumentFragment(e) {
            if (null == e) return this.document.createDocumentFragment();
            if (this.isNodeInstance(e)) {
                if (void 0 !== e.content) return e.content;
                const t = this.document.createDocumentFragment();
                return t.appendChild(e), t
            }
            return this.createTemplate(e).content
        }
        createElement(e) {
            return this.document.createElement(e)
        }
        fetch(e, t) {
            return this.window.fetch(e, t)
        }
        createCustomEvent(e, t) {
            return new this.CustomEvent(e, t)
        }
        dispatchEvent(e) {
            this.document.dispatchEvent(e)
        }
        createNodeObserver(e, t, n) {
            if ("undefined" == typeof MutationObserver) return {
                disconnect() {},
                observe() {},
                takeRecords: () => r.g.emptyArray
            };
            const i = new MutationObserver(t);
            return i.observe(e, n), i
        }
        createTemplate(e) {
            if (null == e) return this.document.createElement("template");
            const t = this.document.createElement("template");
            return t.innerHTML = e.toString(), t
        }
        createTextNode(e) {
            return this.document.createTextNode(e)
        }
        insertBefore(e, t) {
            t.parentNode.insertBefore(e, t)
        }
        isMarker(e) {
            return "AU-M" === e.nodeName
        }
        isNodeInstance(e) {
            return null != e && e.nodeType > 0
        }
        isRenderLocation(e) {
            return "au-end" === e.textContent
        }
        makeTarget(e) {
            e.className = "au"
        }
        registerElementResolver(e, t) {
            e.registerResolver(s.INode, t), e.registerResolver(this.Node, t), e.registerResolver(this.Element, t), e.registerResolver(this.HTMLElement, t)
        }
        remove(e) {
            e.remove ? e.remove() : e.parentNode.removeChild(e)
        }
        removeEventListener(e, t, n, i) {
            (n || this.document).removeEventListener(e, t, i)
        }
        setAttribute(e, t, n) {
            e.setAttribute(t, n)
        }
    }
    s.DOM;
    class Rn {
        constructor(e, t) {
            this.dom = e, this.fragment = t, this.isMounted = !1, this.isLinked = !1, this.fragment = t;
            const n = t.querySelectorAll(".au");
            let i = 0,
                r = n.length;
            const s = this.targets = Array(r);
            for (; i < r;) {
                const e = n[i];
                "AU-M" === e.nodeName ? s[i] = this.dom.convertToRenderLocation(e) : s[i] = e, ++i
            }
            const o = t.childNodes;
            i = 0, r = o.length;
            const a = this.childNodes = Array(r);
            for (; i < r;) a[i] = o[i], ++i;
            this.firstChild = t.firstChild, this.lastChild = t.lastChild, this.next = void 0, this.refNode = void 0
        }
        findTargets() {
            return this.targets
        }
        insertBefore(e) {
            if (this.isLinked && this.refNode) this.addToLinked();
            else {
                const t = e.parentNode;
                if (this.isMounted) {
                    let n = this.firstChild;
                    const i = this.lastChild;
                    let r;
                    for (; null != n && (r = n.nextSibling, t.insertBefore(n, e), n !== i);) n = r
                } else this.isMounted = !0, e.parentNode.insertBefore(this.fragment, e)
            }
        }
        appendTo(e) {
            if (this.isMounted) {
                let t = this.firstChild;
                const n = this.lastChild;
                let i;
                for (; null != t && (i = t.nextSibling, e.appendChild(t), t !== n);) t = i
            } else this.isMounted = !0, e.appendChild(this.fragment)
        }
        remove() {
            if (this.isMounted) {
                this.isMounted = !1;
                const e = this.fragment,
                    t = this.lastChild;
                let n, i = this.firstChild;
                for (; null !== i && (n = i.nextSibling, e.appendChild(i), i !== t);) i = n
            }
        }
        addToLinked() {
            const e = this.refNode,
                t = e.parentNode;
            if (this.isMounted) {
                let n = this.firstChild;
                const i = this.lastChild;
                let r;
                for (; null != n && (r = n.nextSibling, t.insertBefore(n, e), n !== i);) n = r
            } else this.isMounted = !0, t.insertBefore(this.fragment, e)
        }
        unlink() {
            this.isLinked = !1, this.next = void 0, this.refNode = void 0
        }
        link(e) {
            this.isLinked = !0, this.dom.isRenderLocation(e) ? this.refNode = e : (this.next = e, this.obtainRefNode())
        }
        obtainRefNode() {
            void 0 !== this.next ? this.refNode = this.next.firstChild : this.refNode = void 0
        }
    }
    class In {
        constructor(e, t) {
            this.dom = e, this.node = null === t ? null : e.createDocumentFragment(t)
        }
        createNodeSequence() {
            return null === this.node ? s.NodeSequence.empty : new Rn(this.dom, this.node.cloneNode(!0))
        }
    }
    var Dn;
    (Dn = class {
        constructor(e) {
            this.nextSibling = e, this.textContent = ""
        }
        get parentNode() {
            return this.nextSibling.parentNode
        }
        remove() {}
    }.prototype).previousSibling = null, Dn.childNodes = r.g.emptyArray, Dn.nodeName = "AU-M", Dn.nodeType = 1;
    class Nn {
        constructor(e) {
            this.dom = e
        }
        static register(e) {
            return r.j.singleton(s.ITemplateFactory, this).register(e)
        }
        create(e, t) {
            return new s.CompiledTemplate(this.dom, t, new In(this.dom, t.template), e)
        }
    }
    Nn.inject = [s.IDOM];
    let Vn = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, o) {
            const a = r.nextSibling;
            let c;
            t.isMarker(r) && t.remove(r);
            const l = Object(s.ensureExpression)(this.parser, o.from, 2048);
            c = l.isMulti ? new s.MultiInterpolationBinding(this.observerLocator, l, a, "textContent", s.BindingMode.toView, n) : new s.InterpolationBinding(l.firstExpression, l, a, "textContent", s.BindingMode.toView, this.observerLocator, n, !0), Object(s.addBinding)(i, c)
        }
    };
    Vn.inject = [s.IExpressionParser, s.IObserverLocator], Vn = Object(I.__decorate)([Object(s.instructionRenderer)("ha")], Vn);
    let $n = class {
        constructor(e, t) {
            this.parser = e, this.eventManager = t
        }
        render(e, t, n, i, r, o) {
            const a = Object(s.ensureExpression)(this.parser, o.from, 80 | o.strategy + 6),
                c = new lt(t, o.to, o.strategy, a, r, o.preventDefault, this.eventManager, n);
            Object(s.addBinding)(i, c)
        }
    };
    $n.inject = [s.IExpressionParser, Rt], $n = Object(I.__decorate)([Object(s.instructionRenderer)("hb")], $n);
    let Fn = class {
        render(e, t, n, i, r, s) {
            r.setAttribute(s.to, s.value)
        }
    };
    Fn = Object(I.__decorate)([Object(s.instructionRenderer)("he")], Fn);
    let Un = class {
        render(e, t, n, i, r, s) {
            ! function(e, t) {
                const n = t.length;
                let i = 0;
                for (let r = 0; r < n; ++r) 32 === t.charCodeAt(r) ? (r !== i && e.add(t.slice(i, r)), i = r + 1) : r + 1 === n && e.add(t.slice(i))
            }(r.classList, s.value)
        }
    };
    Un = Object(I.__decorate)([Object(s.instructionRenderer)("hf")], Un);
    let Bn = class {
        render(e, t, n, i, r, s) {
            r.style.cssText += s.value
        }
    };
    Bn = Object(I.__decorate)([Object(s.instructionRenderer)("hg")], Bn);
    let zn = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, o) {
            const a = Object(s.ensureExpression)(this.parser, o.from, 48 | s.BindingMode.toView),
                c = new s.PropertyBinding(a, r.style, o.to, s.BindingMode.toView, this.observerLocator, n);
            Object(s.addBinding)(i, c)
        }
    };
    zn.inject = [s.IExpressionParser, s.IObserverLocator], zn = Object(I.__decorate)([Object(s.instructionRenderer)("hd")], zn);
    let Hn = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, o) {
            const a = Object(s.ensureExpression)(this.parser, o.from, 48 | s.BindingMode.toView),
                c = new yt(a, r, o.attr, o.to, s.BindingMode.toView, this.observerLocator, n);
            Object(s.addBinding)(i, c)
        }
    };
    Hn.inject = [s.IExpressionParser, s.IObserverLocator], Hn = Object(I.__decorate)([Object(s.instructionRenderer)("hc")], Hn);
    const Wn = Object.freeze({
            applyTo: r.g.noop
        }),
        qn = r.a.createInterface("IShadowDOMStyles").noDefault(),
        Gn = r.a.createInterface("IShadowDOMGlobalStyles").withDefault(e => e.instance(Wn));
    class Kn {
        constructor(e, t, n, i = null) {
            this.sharedStyles = i, this.styleSheets = t.map(t => {
                let i;
                return t instanceof e.CSSStyleSheet ? i = t : (i = n.get(t), i || (i = new e.CSSStyleSheet, i.replaceSync(t), n.set(t, i))), i
            })
        }
        static supported(e) {
            return "adoptedStyleSheets" in e.ShadowRoot.prototype
        }
        applyTo(e) {
            null !== this.sharedStyles && this.sharedStyles.applyTo(e), e.adoptedStyleSheets = [...e.adoptedStyleSheets, ...this.styleSheets]
        }
    }
    class Yn {
        constructor(e, t, n = null) {
            this.dom = e, this.localStyles = t, this.sharedStyles = n
        }
        applyTo(e) {
            const t = this.localStyles,
                n = this.dom;
            for (let i = t.length - 1; i > -1; --i) {
                const r = n.createElement("style");
                r.innerHTML = t[i], e.prepend(r)
            }
            null !== this.sharedStyles && this.sharedStyles.applyTo(e)
        }
    }
    Array.prototype.slice;
    const Xn = {
        mode: "open"
    };
    const Jn = {
        childList: !0
    };
    class Qn {
        constructor(e, t, n, i) {
            let r;
            this.dom = e, this.host = n, this.$controller = t, r = i.shadowOptions instanceof Object && "mode" in i.shadowOptions ? i.shadowOptions : Xn, this.shadowRoot = n.attachShadow(r), this.host.$controller = t, this.shadowRoot.$controller = t
        }
        get children() {
            return this.host.childNodes
        }
        subscribeToChildrenChange(e, t = Jn) {
            this.dom.createNodeObserver(this.host, e, t)
        }
        provideEncapsulationSource() {
            return this.shadowRoot
        }
        project(e) {
            const t = this.$controller.context;
            (t.has(qn, !1) ? t.get(qn) : t.get(Gn)).applyTo(this.shadowRoot), e.appendTo(this.shadowRoot)
        }
        take(e) {
            e.remove(), e.unlink()
        }
    }
    class Zn {
        constructor(e, t, n) {
            n.childNodes.length ? this.childNodes = Object(r.D)(n.childNodes) : this.childNodes = r.g.emptyArray, this.host = e.convertToRenderLocation(n), this.host.$controller = t
        }
        get children() {
            return this.childNodes
        }
        subscribeToChildrenChange(e) {}
        provideEncapsulationSource() {
            return this.host.getRootNode()
        }
        project(e) {
            e.insertBefore(this.host)
        }
        take(e) {
            e.remove(), e.unlink()
        }
    }
    class ei {
        constructor(e, t) {
            this.host = t, this.host.$controller = e
        }
        get children() {
            return this.host.childNodes
        }
        subscribeToChildrenChange(e) {}
        provideEncapsulationSource() {
            return this.host.getRootNode()
        }
        project(e) {
            e.appendTo(this.host)
        }
        take(e) {
            e.remove(), e.unlink()
        }
    }
    const ti = [class {
            static register(e) {
                return r.j.singleton(s.IProjectorLocator, this).register(e)
            }
            getElementProjector(e, t, n, i) {
                if (i.shadowOptions || i.hasSlots) {
                    if (i.containerless) throw r.k.error(21);
                    return new Qn(e, t, n, i)
                }
                return i.containerless ? new Zn(e, t, n) : new ei(t, n)
            }
        }, Qt, Jt, Nn],
        ni = [tn, rn, sn, Mn, mn, fn, hn],
        ii = [$n, Hn, Fn, Un, Bn, zn, Vn],
        ri = {
            register: e => s.RuntimeConfiguration.register(e).register(...ti, ...ni, ...ii),
            createContainer() {
                return this.register(r.a.createContainer())
            }
        };
    class si {
        register(e, ...t) {
            const n = Object.assign({}, ...t);
            let i = class {
                constructor(e) {
                    this.element = e
                }
                binding() {
                    this.valueChanged()
                }
                valueChanged() {
                    this.value ? this.element.className = this.value.split(" ").map(e => n[e] || e).join(" ") : this.element.className = ""
                }
            };
            Object(I.__decorate)([s.bindable], i.prototype, "value", void 0), i = Object(I.__decorate)([Object(s.customAttribute)("class"), Object(I.__param)(0, s.INode)], i), e.register(i)
        }
    }
    class oi {
        constructor(e, t) {
            this.sharedStyles = e, this.createStyles = t
        }
        register(e, ...t) {
            e.register(r.j.instance(qn, this.createStyles(t, this.sharedStyles)))
        }
    }
    const ai = {
        cssModulesProcessor: () => ({
            register(e) {
                e.register(r.j.singleton(".css", si))
            }
        }),
        shadowDOM: e => s.StartTask.with(r.c).beforeCreate().call(t => {
            const n = t.get(Pn);
            let i, s;
            if (Kn.supported(n)) {
                const e = new Map;
                i = (t, i) => new Kn(n, t, e, i)
            } else i = (e, t) => {
                if (e.find(e => "string" != typeof e)) throw new Error("Shadow DOM CSS must be a string.");
                return new Yn(n, e, t)
            };
            s = e && e.sharedStyles ? i(e.sharedStyles, null) : Wn, t.register(r.j.instance(Gn, s)), t.register(r.j.instance(".css", new oi(s, i)))
        })
    };
    let ci = class {
        constructor() {
            this.bindingType = 4182
        }
        compile(e) {
            return new wn(e.expression, se(e, !1))
        }
    };
    ci = Object(I.__decorate)([ne("trigger")], ci);
    let li = class {
        constructor() {
            this.bindingType = 4184
        }
        compile(e) {
            return new kn(e.expression, se(e, !1))
        }
    };
    li = Object(I.__decorate)([ne("delegate")], li);
    let ui = class {
        constructor() {
            this.bindingType = 4183
        }
        compile(e) {
            return new xn(e.expression, se(e, !1))
        }
    };
    ui = Object(I.__decorate)([ne("capture")], ui);
    let hi = class {
        constructor() {
            this.bindingType = 32
        }
        compile(e) {
            const t = se(e, !1);
            return new Cn(t, e.expression, t)
        }
    };
    hi = Object(I.__decorate)([ne("attr")], hi);
    let di = class {
        constructor() {
            this.bindingType = 32
        }
        compile(e) {
            return new Cn("style", e.expression, se(e, !1))
        }
    };
    di = Object(I.__decorate)([ne("style")], di);
    let pi = class {
        constructor() {
            this.bindingType = 32
        }
        compile(e) {
            return new Cn("class", e.expression, se(e, !1))
        }
    };
    pi = Object(I.__decorate)([ne("class")], pi);
    let fi = class {
        constructor() {
            this.bindingType = 4128
        }
        compile(e) {
            return new s.RefBindingInstruction(e.expression, se(e, !1))
        }
    };
    fi = Object(I.__decorate)([ne("ref")], fi);
    let gi = class {
        "attr.PART"(e, t, n) {
            return new D(e, t, n[1], "attr")
        }
        "PART.attr"(e, t, n) {
            return new D(e, t, n[0], "attr")
        }
    };
    gi = Object(I.__decorate)([G({
        pattern: "attr.PART",
        symbols: "."
    }, {
        pattern: "PART.attr",
        symbols: "."
    })], gi);
    let mi = class {
        "style.PART"(e, t, n) {
            return new D(e, t, n[1], "style")
        }
        "PART.style"(e, t, n) {
            return new D(e, t, n[0], "style")
        }
    };
    mi = Object(I.__decorate)([G({
        pattern: "style.PART",
        symbols: "."
    }, {
        pattern: "PART.style",
        symbols: "."
    })], mi);
    let vi = class {
        "class.PART"(e, t, n) {
            return new D(e, t, n[1], "class")
        }
        "PART.class"(e, t, n) {
            return new D(e, t, n[0], "class")
        }
    };
    vi = Object(I.__decorate)([G({
        pattern: "class.PART",
        symbols: "."
    }, {
        pattern: "PART.class",
        symbols: "."
    })], vi);
    const bi = class {
            constructor(e, t, n, i = n.name, r = n.bindables) {
                this.physicalNode = t, this.info = n, this.res = i, this.bindables = r, this.flags = 16, this.isTarget = !0, this.templateController = null, this._customAttributes = null, this._plainAttributes = null, this._bindings = null, this._childNodes = null, this._parts = null, n.containerless ? (this.isContainerless = !0, this.marker = ae(e), this.flags |= 512) : (this.isContainerless = !1, this.marker = null)
            }
            get customAttributes() {
                return null === this._customAttributes && (this._customAttributes = [], this.flags |= 2048), this._customAttributes
            }
            get plainAttributes() {
                return null === this._plainAttributes && (this._plainAttributes = [], this.flags |= 2048), this._plainAttributes
            }
            get bindings() {
                return null === this._bindings && (this._bindings = [], this.flags |= 4096), this._bindings
            }
            get childNodes() {
                return null === this._childNodes && (this._childNodes = [], this.flags |= 8192), this._childNodes
            }
            get parts() {
                return null === this._parts && (this._parts = [], this.flags |= 16384), this._parts
            }
        },
        yi = class {
            constructor(e, t, n = ae(e)) {
                this.physicalNode = t, this.marker = n, this.flags = 544, this.toBindingContext = !1, this._bindings = null
            }
            get bindings() {
                return null === this._bindings && (this._bindings = [], this.flags |= 4096), this._bindings
            }
        },
        wi = class {
            constructor(e, t) {
                this.physicalNode = t, this.flags = 64, this.isTarget = !1, this.templateController = null, this.hasSlots = !1, this._customAttributes = null, this._plainAttributes = null, this._childNodes = null
            }
            get customAttributes() {
                return null === this._customAttributes && (this._customAttributes = [], this.flags |= 2048), this._customAttributes
            }
            get plainAttributes() {
                return null === this._plainAttributes && (this._plainAttributes = [], this.flags |= 2048), this._plainAttributes
            }
            get childNodes() {
                return null === this._childNodes && (this._childNodes = [], this.flags |= 8192), this._childNodes
            }
        },
        ki = class {
            constructor(e, t = null, n = null, i = null) {
                this.name = e, this.physicalNode = t, this.parent = n, this.template = i, this.flags = 2
            }
        },
        xi = class {
            constructor(e, t, n, i, r = n.name) {
                this.syntax = t, this.info = n, this.res = r, this.flags = 513, this.physicalNode = null, this.template = null, this.templateController = null, this._bindings = null, this._parts = null, this.partName = "replaceable" === n.name ? i : null, this.marker = ae(e)
            }
            get bindings() {
                return null === this._bindings && (this._bindings = [], this.flags |= 4096), this._bindings
            }
            get parts() {
                return null === this._parts && (this._parts = [], this.flags |= 16384), this._parts
            }
        },
        _i = class {
            constructor(e, t, n, i = ae(e)) {
                this.physicalNode = t, this.interpolation = n, this.marker = i, this.flags = 640
            }
        },
        Si = Object.assign(Object.create(null), {
            id: !0,
            replace: !0
        }),
        Oi = Object.assign(Object.create(null), {
            "as-element": !0,
            replace: !0
        });

    function Ci(e) {
        const t = e.length;
        let n = 0;
        for (let i = 0; i < t; ++i)
            if (n = e.charCodeAt(i), 92 === n) ++i;
            else {
                if (58 === n) return !0;
                if (36 === n && 123 === e.charCodeAt(i + 1)) return !1
            } return !1
    }

    function Ai(e, t) {
        return e !== t
    }
    class Ti {
        constructor(e, t, n, i, r) {
            this.dom = e, this.resources = t, this.attrParser = n, this.exprParser = i, this.attrSyntaxTransformer = r
        }
        bind(e) {
            const t = new wi(this.dom, e),
                n = this.resources,
                i = this.attrSyntaxTransformer,
                r = e.attributes;
            let s = 0;
            for (; s < r.length;) {
                const o = r[s],
                    a = this.attrParser.parse(o.name, o.value);
                if (!0 === Si[a.target]) throw new Error("Invalid surrogate attribute: " + a.target);
                const c = n.getBindingCommand(a, !0);
                if (null === c || 0 == (4096 & c.bindingType)) {
                    const r = n.getAttributeInfo(a);
                    if (null === r) i.transform(e, a), this.bindPlainAttribute(a, o, t, t);
                    else {
                        if (r.isTemplateController) throw new Error("Cannot have template controller on surrogate element.");
                        this.bindCustomAttribute(a, r, c, t)
                    }
                } else i.transform(e, a), this.bindPlainAttribute(a, o, t, t);
                ++s
            }
            return this.bindChildNodes(e, t, t, null, null, null), t
        }
        bindManifest(e, t, n, i, r, s, o) {
            switch (t.nodeName) {
                case "LET":
                    return void this.bindLetElement(e, t);
                case "SLOT":
                    n.hasSlots = !0
            }
            "" === (o = t.getAttribute("replaceable")) && (o = "default");
            let a = t.getAttribute("as-element");
            null === a && (a = t.nodeName.toLowerCase());
            const c = this.resources.getElementInfo(a);
            null === c ? i = new wi(this.dom, t) : (s = r, r = i = new bi(this.dom, t, c)), this.bindChildNodes(t, n, i, r, s, o), this.bindAttributes(t, e, n, i, r, s, o), r === i && i.isContainerless ? t.parentNode.replaceChild(i.marker, t) : i.isTarget && t.classList.add("au")
        }
        bindLetElement(e, t) {
            const n = new yi(this.dom, t);
            e.childNodes.push(n);
            const i = t.attributes;
            let o = 0;
            for (; o < i.length;) {
                const e = i[o];
                if ("to-binding-context" === e.name) {
                    t.removeAttribute("to-binding-context"), n.toBindingContext = !0;
                    continue
                }
                const a = this.attrParser.parse(e.name, e.value),
                    c = this.resources.getBindingCommand(a, !1),
                    l = null === c ? 2048 : c.bindingType,
                    u = this.exprParser.parse(a.rawValue, l),
                    h = Object(r.o)(a.target),
                    d = new rt(h, s.BindingMode.toView);
                n.bindings.push(new ue(c, d, u, a.rawValue, h)), ++o
            }
            t.parentNode.replaceChild(n.marker, t)
        }
        bindAttributes(e, t, n, i, r, s, o) {
            let a = i,
                c = void 0,
                l = void 0;
            const u = e.attributes;
            let h = 0;
            for (; h < u.length;) {
                const t = u[h];
                if (++h, !0 === Oi[t.name]) continue;
                const r = this.attrParser.parse(t.name, t.value),
                    s = this.resources.getBindingCommand(r, !0);
                if (null === s || 0 == (4096 & s.bindingType)) {
                    const u = this.resources.getAttributeInfo(r);
                    null === u ? (this.attrSyntaxTransformer.transform(e, r), this.bindPlainAttribute(r, t, n, i)) : u.isTemplateController ? (l = i.templateController = this.declareTemplateController(r, u, o), a === i ? (l.template = i, a = l) : (l.templateController = c, l.template = c.template, c.template = l), c = l) : this.bindCustomAttribute(r, u, s, i)
                } else this.attrSyntaxTransformer.transform(e, r), this.bindPlainAttribute(r, t, n, i)
            }! function(e, t, n) {
                const i = n.physicalNode;
                let r, s = t;
                for (; Ai(s, n);) s.template === n ? (i.parentNode.replaceChild(s.marker, i), "TEMPLATE" === i.nodeName ? (s.physicalNode = i, i.remove()) : (r = s.physicalNode = e.createTemplate(), r.content.appendChild(i))) : (r = s.physicalNode = e.createTemplate(), r.content.appendChild(s.marker)), i.removeAttribute(s.syntax.rawName), s = s.template
            }(this.dom, a, i);
            let d = e.getAttribute("replace");
            ("" === d || null === d && null !== r && r.isContainerless) && (d = "default");
            const p = i === r ? s : r;
            if (null === d || null === p) t.childNodes.push(a);
            else {
                const e = new ki(d);
                e.parent = t, e.template = a, p.parts.push(e), null != t.templateController && t.templateController.parts.push(e),
                    function(e, t, n) {
                        let i, r;
                        i = (512 & n.flags) > 0 ? n.marker : n.physicalNode, "TEMPLATE" === i.nodeName ? t.physicalNode = i : (r = t.physicalNode = e.createTemplate(), r.content.appendChild(i))
                    }(this.dom, e, a)
            }
        }
        bindChildNodes(e, t, n, i, r, s) {
            let o, a;
            for (o = "TEMPLATE" === e.nodeName ? e.content.firstChild : e.firstChild; null !== o;) switch (o.nodeType) {
                case 1:
                    a = o.nextSibling, this.bindManifest(n, o, t, n, i, r, s), o = a;
                    break;
                case 3:
                    o = this.bindText(o, n).nextSibling;
                    break;
                case 4:
                case 7:
                case 8:
                case 10:
                    o = o.nextSibling;
                    break;
                case 9:
                case 11:
                    o = o.firstChild
            }
        }
        bindText(e, t) {
            const n = this.exprParser.parse(e.wholeText, 2048);
            if (null !== n) {
                const i = new _i(this.dom, e, n);
                t.childNodes.push(i),
                    function(e) {
                        const t = e.physicalNode,
                            n = t.parentNode;
                        for (; null !== t.nextSibling && 3 === t.nextSibling.nodeType;) n.removeChild(t.nextSibling);
                        t.textContent = "", n.insertBefore(e.marker, t)
                    }(i)
            }
            let i = e;
            for (; null !== i.nextSibling && 3 === i.nextSibling.nodeType;) i = i.nextSibling;
            return i
        }
        declareTemplateController(e, t, n) {
            let i;
            const r = e.rawValue,
                s = this.resources.getBindingCommand(e, !1);
            if (null === s && Ci(r)) i = new xi(this.dom, e, t, n), this.bindMultiAttribute(i, t, r);
            else {
                i = new xi(this.dom, e, t, n);
                const o = null === s ? 2048 : s.bindingType,
                    a = this.exprParser.parse(r, o);
                i.bindings.push(new ue(s, t.bindable, a, r, e.target))
            }
            return i
        }
        bindCustomAttribute(e, t, n, i) {
            let r;
            const s = e.rawValue;
            if (null === n && Ci(s)) r = new ce(e, t), this.bindMultiAttribute(r, t, s);
            else {
                r = new ce(e, t);
                const i = null === n ? 2048 : n.bindingType,
                    o = this.exprParser.parse(s, i);
                r.bindings.push(new ue(n, t.bindable, o, s, e.target))
            }
            i.customAttributes.push(r), i.isTarget = !0
        }
        bindMultiAttribute(e, t, n) {
            const i = t.bindables,
                o = n.length;
            let a = void 0,
                c = void 0,
                l = 0,
                u = 0;
            for (let t = 0; t < o; ++t)
                if (u = n.charCodeAt(t), 92 === u) ++t;
                else if (58 === u) {
                for (a = n.slice(l, t); n.charCodeAt(++t) <= 32;);
                for (l = t; t < o; ++t)
                    if (u = n.charCodeAt(t), 92 === u) ++t;
                    else if (59 === u) {
                    c = n.slice(l, t);
                    break
                }
                void 0 === c && (c = n.slice(l));
                const h = this.attrParser.parse(a, c),
                    d = Object(r.o)(h.target),
                    p = this.resources.getBindingCommand(h, !1),
                    f = null === p ? 2048 : p.bindingType,
                    g = this.exprParser.parse(c, f);
                let m = i[d];
                for (void 0 === m && (m = i[d] = new rt(d, s.BindingMode.toView)), e.bindings.push(new ue(p, m, g, c, d)); t < o && n.charCodeAt(++t) <= 32;);
                l = t, a = void 0, c = void 0
            }
        }
        bindPlainAttribute(e, t, n, i) {
            const s = this.resources.getBindingCommand(e, !1),
                o = null === s ? 2048 : s.bindingType,
                a = e.target,
                c = e.rawValue;
            let l;
            if (0 === c.length && (55 | 53 & o) > 0) {
                if (!((55 | 53 & o) > 0)) return;
                l = this.exprParser.parse(Object(r.o)(a), o)
            } else l = this.exprParser.parse(c, o);
            if ((16 & i.flags) > 0) {
                const t = i.bindables[a];
                null != t ? (i.bindings.push(new ue(s, t, l, c, a)), i.isTarget = !0) : null != l && (i.plainAttributes.push(new le(e, s, l)), i.isTarget = !0)
            } else null != l ? (i.plainAttributes.push(new le(e, s, l)), i.isTarget = !0) : i === n && i.plainAttributes.push(new le(e, s, l));
            null == s && null != l && (t.value = "")
        }
    }
    const Ei = r.a.createInterface("ITemplateElementFactory").noDefault(),
        {
            enter: ji,
            leave: Mi
        } = r.h.createTimer("TemplateElementFactory"),
        Li = {};
    class Pi {
        constructor(e) {
            this.dom = e, this.template = e.createTemplate()
        }
        static register(e) {
            return r.j.singleton(Ei, this).register(e)
        }
        createTemplate(e) {
            if ("string" == typeof e) {
                let t = Li[e];
                if (void 0 === t) {
                    const n = this.template;
                    n.innerHTML = e;
                    const i = n.content.firstElementChild;
                    null == i || "TEMPLATE" !== i.nodeName || null != i.nextElementSibling ? (this.template = this.dom.createTemplate(), t = n) : (n.content.removeChild(i), t = i), Li[e] = t
                }
                return t.cloneNode(!0)
            }
            if ("TEMPLATE" !== e.nodeName) {
                const t = this.dom.createTemplate();
                return t.content.appendChild(e), t
            }
            return null != e.parentNode && e.parentNode.removeChild(e), e
        }
    }
    Pi.inject = [s.IDOM];
    class Ri {
        constructor(e, t, n) {
            this.partialDefinition = e, this.surrogate = t, this.template = n, this.instructions = [], this.surrogates = [], this.scopeParts = [], this.parts = {}
        }
        toDefinition() {
            const e = this.partialDefinition;
            return s.CustomElementDefinition.create({
                ...e,
                instructions: Object(r.z)(e.instructions, this.instructions),
                surrogates: Object(r.z)(e.surrogates, this.surrogates),
                scopeParts: Object(r.z)(e.scopeParts, this.scopeParts),
                template: this.template,
                needsCompile: !1,
                hasSlots: this.surrogate.hasSlots
            })
        }
    }
    let Ii = class {
        constructor(e, t, n, i) {
            this.factory = e, this.attrParser = t, this.exprParser = n, this.attrSyntaxModifier = i
        }
        get name() {
            return "default"
        }
        static register(e) {
            return r.j.singleton(s.ITemplateCompiler, this).register(e)
        }
        compile(e, t, n) {
            const i = new at(n),
                {
                    attrParser: r,
                    exprParser: s,
                    attrSyntaxModifier: o,
                    factory: a
                } = this,
                c = new Ti(e, i, r, s, o),
                l = a.createTemplate(t.template),
                u = c.bind(l),
                h = this.compilation = new Ri(t, u, l),
                d = u.customAttributes,
                p = u.plainAttributes,
                f = d.length,
                g = p.length;
            if (f + g > 0) {
                let e = 0;
                for (let t = 0; f > t; ++t) h.surrogates[e] = this.compileCustomAttribute(d[t]), e++;
                for (let t = 0; t < g; ++t) h.surrogates[e] = this.compilePlainAttribute(p[t], !0), e++
            }
            this.compileChildNodes(u, h.instructions, h.scopeParts);
            const m = h.toDefinition();
            return this.compilation = null, m
        }
        compileChildNodes(e, t, n) {
            if ((8192 & e.flags) > 0) {
                const {
                    childNodes: i
                } = e;
                let r;
                const o = i.length;
                for (let e = 0; e < o; ++e)
                    if (r = i[e], (128 & r.flags) > 0) t.push([new yn(r.interpolation)]);
                    else if ((32 & r.flags) > 0) {
                    const e = r.bindings,
                        n = [];
                    let i;
                    const o = e.length;
                    for (let t = 0; t < o; ++t) i = e[t], n[t] = new s.LetBindingInstruction(i.expression, i.target);
                    t.push([new s.LetElementInstruction(n, r.toBindingContext)])
                } else this.compileParentNode(r, t, n)
            }
        }
        compileCustomElement(e, t, n) {
            const i = this.compileAttributes(e, 1);
            i[0] = new s.HydrateElementInstruction(e.res, this.compileBindings(e), this.compileParts(e, n)), t.push(i), this.compileChildNodes(e, t, n)
        }
        compilePlainElement(e, t, n) {
            const i = this.compileAttributes(e, 0);
            i.length > 0 && t.push(i), this.compileChildNodes(e, t, n)
        }
        compileParentNode(e, t, n) {
            switch (511 & e.flags) {
                case 16:
                    this.compileCustomElement(e, t, n);
                    break;
                case 64:
                    this.compilePlainElement(e, t, n);
                    break;
                case 1:
                    this.compileTemplateController(e, t, n)
            }
        }
        compileTemplateController(e, t, n) {
            const i = this.compileBindings(e),
                o = [],
                a = [];
            this.compileParentNode(e.template, o, a), Object(r.A)(n, a, !1);
            const c = s.CustomElementDefinition.create({
                name: null === e.partName ? e.res : e.partName,
                scopeParts: a,
                template: e.physicalNode,
                instructions: o,
                needsCompile: !1
            });
            let l = void 0;
            if ((16384 & e.flags) > 0) {
                l = {};
                for (const t of e.parts) l[t.name] = this.compilation.parts[t.name]
            }
            t.push([new s.HydrateTemplateController(c, e.res, i, "else" === e.res, l)])
        }
        compileBindings(e) {
            let t;
            if ((4096 & e.flags) > 0) {
                const {
                    bindings: n
                } = e, i = n.length;
                t = Array(i);
                let r = 0;
                for (; r < i; ++r) t[r] = this.compileBinding(n[r])
            } else t = r.g.emptyArray;
            return t
        }
        compileBinding(e) {
            return null === e.command ? null === e.expression ? new s.SetPropertyInstruction(e.rawValue, e.bindable.propName) : new s.InterpolationInstruction(e.expression, e.bindable.propName) : e.command.compile(e)
        }
        compileAttributes(e, t) {
            let n;
            if ((2048 & e.flags) > 0) {
                const i = e.customAttributes,
                    r = e.plainAttributes,
                    s = i.length,
                    o = r.length;
                n = Array(t + s + o);
                for (let e = 0; s > e; ++e) n[t] = this.compileCustomAttribute(i[e]), t++;
                for (let e = 0; o > e; ++e) n[t] = this.compilePlainAttribute(r[e], !1), t++
            } else n = t > 0 ? Array(t) : r.g.emptyArray;
            return n
        }
        compileCustomAttribute(e) {
            const t = this.compileBindings(e);
            return new s.HydrateAttributeInstruction(e.res, t)
        }
        compilePlainAttribute(e, t) {
            if (null === e.command) {
                const n = e.syntax;
                if (null === e.expression) {
                    const e = n.rawValue;
                    if (t) switch (n.target) {
                        case "class":
                            return new Sn(e);
                        case "style":
                            return new On(e)
                    }
                    return new _n(e, n.target)
                }
                return new s.InterpolationInstruction(e.expression, n.target)
            }
            return e.command.compile(e)
        }
        compileParts(e, t) {
            const n = {};
            if ((16384 & e.flags) > 0) {
                const i = e.parts,
                    r = i.length;
                let o = t.length;
                for (let e = 0; e < r; ++e) {
                    const r = i[e];
                    t.includes(r.name) || (t[o++] = r.name);
                    const a = [],
                        c = [];
                    this.compileParentNode(r.template, c, a), this.compilation.parts[r.name] = n[r.name] = s.CustomElementDefinition.create({
                        name: r.name,
                        scopeParts: a,
                        template: r.physicalNode,
                        instructions: c,
                        needsCompile: !1
                    })
                }
            }
            return n
        }
    };
    Ii = Object(I.__decorate)([Object(I.__param)(0, Ei), Object(I.__param)(1, K), Object(I.__param)(2, s.IExpressionParser), Object(I.__param)(3, ct)], Ii);
    const Di = [Ii, Pi, class {
            static register(e) {
                return r.j.singleton(ct, this).register(e)
            }
            transform(e, t) {
                "bind" === t.command && function(e, t) {
                    switch (e.tagName) {
                        case "INPUT":
                            switch (e.type) {
                                case "checkbox":
                                case "radio":
                                    return "checked" === t.target;
                                default:
                                    return "value" === t.target || "files" === t.target
                            }
                        case "TEXTAREA":
                        case "SELECT":
                            return "value" === t.target;
                        default:
                            switch (t.target) {
                                case "textcontent":
                                case "innerhtml":
                                    return e.hasAttribute("contenteditable");
                                case "scrolltop":
                                case "scrollleft":
                                    return !0;
                                default:
                                    return !1
                            }
                    }
                }(e, t) && (t.command = "two-way"), t.target = this.map(e.tagName, t.target)
            }
            map(e, t) {
                switch (e) {
                    case "LABEL":
                        switch (t) {
                            case "for":
                                return "htmlFor";
                            default:
                                return t
                        }
                    case "IMG":
                        switch (t) {
                            case "usemap":
                                return "useMap";
                            default:
                                return t
                        }
                    case "INPUT":
                        switch (t) {
                            case "maxlength":
                                return "maxLength";
                            case "minlength":
                                return "minLength";
                            case "formaction":
                                return "formAction";
                            case "formenctype":
                                return "formEncType";
                            case "formmethod":
                                return "formMethod";
                            case "formnovalidate":
                                return "formNoValidate";
                            case "formtarget":
                                return "formTarget";
                            case "inputmode":
                                return "inputMode";
                            default:
                                return t
                        }
                    case "TEXTAREA":
                        switch (t) {
                            case "maxlength":
                                return "maxLength";
                            default:
                                return t
                        }
                    case "TD":
                    case "TH":
                        switch (t) {
                            case "rowspan":
                                return "rowSpan";
                            case "colspan":
                                return "colSpan";
                            default:
                                return t
                        }
                    default:
                        switch (t) {
                            case "accesskey":
                                return "accessKey";
                            case "contenteditable":
                                return "contentEditable";
                            case "tabindex":
                                return "tabIndex";
                            case "textcontent":
                                return "textContent";
                            case "innerhtml":
                                return "innerHTML";
                            case "scrolltop":
                                return "scrollTop";
                            case "scrollleft":
                                return "scrollLeft";
                            case "readonly":
                                return "readOnly";
                            default:
                                return t
                        }
                }
            }
        }],
        Ni = [fi, ci, li, ui, pi, di, hi];
    class Vi {
        constructor(e) {
            this.container = e
        }
        static register(e) {
            return r.j.singleton(s.IDOMInitializer, this).register(e)
        }
        initialize(e) {
            if (this.container.has(s.IDOM, !1)) return this.container.get(s.IDOM);
            let t;
            return t = void 0 !== e ? void 0 !== e.dom ? e.dom : null !== e.host.ownerDocument ? new Pn(window, e.host.ownerDocument, Node, Element, HTMLElement, CustomEvent, CSSStyleSheet, ShadowRoot) : new Pn(window, document, Node, Element, HTMLElement, CustomEvent, CSSStyleSheet, ShadowRoot) : new Pn(window, document, Node, Element, HTMLElement, CustomEvent, CSSStyleSheet, ShadowRoot), r.j.instance(s.IDOM, t).register(this.container), t
        }
    }
    Vi.inject = [r.c];
    const $i = [Vi],
        Fi = {
            register: e => ri.register(e).register(...$i),
            createContainer() {
                return this.register(r.a.createContainer())
            }
        },
        {
            enter: Ui,
            leave: Bi
        } = r.h.createTimer("JitHtmlBrowserConfiguration"),
        zi = {
            register: e => (Fi.register(e).register(...it, ...nt, ...tt, ...Ni, ...Di), e),
            createContainer() {
                return this.register(r.a.createContainer())
            }
        };
    class Hi {
        constructor(e, t, n) {
            this.lifecycle = e, this.obj = t, this.propertyKey = n, this.currentValue = null, this.oldValue = null, this.hasChanges = !1, this.priority = 12288
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            this.currentValue = e, this.hasChanges = e !== this.oldValue, (4096 & t) > 0 && this.flushRAF(t)
        }
        flushRAF(e) {
            if (this.hasChanges) {
                this.hasChanges = !1;
                const {
                    currentValue: e
                } = this;
                this.oldValue = e, !0 === e ? this.obj.setAttribute(this.propertyKey, this.propertyKey) : this.obj.removeAttribute(this.propertyKey)
            }
        }
        bind(e) {
            this.lifecycle.enqueueRAF(this.flushRAF, this, this.priority), this.currentValue = this.oldValue = this.obj.getAttribute(this.propertyKey) === this.propertyKey
        }
        unbind(e) {
            this.lifecycle.dequeueRAF(this.flushRAF, this)
        }
    }
    var Wi = n(50),
        qi = n(44),
        Gi = n(52),
        Ki = n(53),
        Yi = n(20),
        Xi = n(15);
    let Ji = class {
        constructor(e, t) {
            this.element = e, this.resourceManager = t, this.value = null
        }
        binding() {
            this.valueChanged()
        }
        valueChanged() {
            const e = this.resourceManager.imagePathFromName(this.value),
                t = this.resourceManager.imageSetFromName(this.value);
            Object(Xi.d)(this.element, e, t)
        }
    };
    Object(I.__decorate)([s.bindable, Object(I.__metadata)("design:type", Object)], Ji.prototype, "value", void 0), Ji = Object(I.__decorate)([Object(s.customAttribute)("background-image"), Object(I.__metadata)("design:paramtypes", [HTMLElement, Yi.a])], Ji);
    var Qi = n(51),
        Zi = n(12),
        er = n(6);

    function tr(e) {
        try {
            const t = "string" == typeof e ? JSON.parse(e) : e;
            if (null == t.address || null == t.port || null == t.client) return;
            return t
        } catch (e) {
            return void console.error(e)
        }
    }
    const nr = console.log;
    class ir {
        constructor(e) {
            this.transport = e, this.isConnected = !1, this.listeners = new er.ConnectionListeners, this.clientIdentifier = "temp", this.port = 0
        }
        static getHostName(e) {
            return e.split(":")[0]
        }
        connect(e) {
            return this.isConnected = !1, new Promise((t, n) => {
                this.connectSuccess = t, this.connectError = n, this.clientIdentifier = this.createClientIdentifier(e.client), this.port = e.port, "undefined" != typeof window && window.addEventListener("message", this.handleMessageFromParentWindow.bind(this)), this.sendMessageToParentWindow("connect", e)
            })
        }
        addListeners(e) {
            this.listeners.add(e)
        }
        removeListeners(e) {
            this.listeners.remove(e)
        }
        unregister() {}
        sendMessage(e, t) {
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                this.sendMessageToParentWindow("message", Object.assign(Object.assign({}, t), {
                    payload: e
                }))
            }))
        }
        close(e, t, n) {
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                this.sendMessageToParentWindow("close", Object.assign(Object.assign({}, n), {
                    port: this.port,
                    reason: e,
                    code: t
                })), this.isConnected = !1
            }))
        }
        sendMessageToParentWindow(e, t) {
            if ("undefined" == typeof window || !window.parent) return void console.error(`[${this.clientIdentifier}] parent window not found`);
            const n = Object.assign(Object.assign({}, t), {
                command: e,
                client: this.clientIdentifier
            });
            window.parent.postMessage(n, window.origin)
        }
        clientName() {
            return window.frameElement.getAttribute("name") || "unknown"
        }
        createClientIdentifier(e) {
            return `${this.clientName()}:${e}`
        }
        handleMessageFromParentWindow(e) {
            var t, n;
            const i = tr(e.data);
            if (null == i) return void console.warn(`[${this.clientIdentifier}] not a UANet message ${JSON.stringify(i)}`);
            if (!this.messageIsForMe(i)) return;
            const r = i.reason || "",
                s = i.code || er.TransportError.closedByUser;
            switch (i.command) {
                case "pong":
                    return void nr(`[${this.clientIdentifier}] pong`);
                case "open":
                    nr(`[${this.clientIdentifier}] open`);
                    for (const e of this.listeners.open) e(new Event("open"));
                    return void(this.connectSuccess && (this.isConnected = !0, this.connectSuccess(), this.connectSuccess = void 0));
                case "message":
                    if (null == i.payload) return void console.warn(`[${this.clientIdentifier}] no message payload`);
                    nr(`[${this.clientIdentifier}] message for ${null===(n=null===(t=i.payload)||void 0===t?void 0:t.parameters)||void 0===n?void 0:n.message_id} ${i.payload.path} ${JSON.stringify(i.payload.data)}`);
                    for (const e of this.listeners.message) e(new Event("message"), i.payload);
                    return;
                case "error":
                    nr(`[${this.clientIdentifier}] error`);
                    for (const e of this.listeners.error) e({
                        type: "error",
                        reason: r,
                        code: s
                    });
                    this.connectError && this.connectError(new Error(r));
                case "close":
                    nr(`[${this.clientIdentifier}] error`);
                    for (const e of this.listeners.close) e({
                        type: "close",
                        reason: r,
                        code: s
                    });
                    return;
                default:
                    console.warn(`[${this.clientIdentifier}] unhandled ${i.command} message from parent window`), nr(i)
            }
        }
        messageIsForMe({
            client: e
        }) {
            return this.clientIdentifier === e
        }
    }
    console.log;
    var rr = n(3),
        sr = n(11),
        or = n(29);
    class ar {
        constructor(e, t) {
            this.store = {
                app: e,
                environment: t
            }, this.setupGlobalStore()
        }
        setupGlobalStore() {
            const e = Object(sr.k)();
            this.removeGlobalStore(), e.hbgf_store = this
        }
        removeGlobalStore() {
            const e = Object(sr.k)();
            e.hbgf_store && delete e.hbgf_store
        }
        set(e, t) {
            this.store[e] = t
        }
        get(e) {
            return this.store[e]
        }
    }
    var cr = n(9);
    var lr;
    ! function(e) {
        e[e.ERROR = -1] = "ERROR", e[e.RESET = 0] = "RESET", e[e.TRY_LOADING_DEV_FEATURES = 1] = "TRY_LOADING_DEV_FEATURES", e[e.TRY_LOADED_DEV_FEATURES = 2] = "TRY_LOADED_DEV_FEATURES", e[e.LOADING_LOAD_SCREEN = 3] = "LOADING_LOAD_SCREEN", e[e.LOADED_LOAD_SCREEN = 4] = "LOADED_LOAD_SCREEN", e[e.LOADING_CLIENT_LAYER = 5] = "LOADING_CLIENT_LAYER", e[e.LOADED_CLIENT_LAYER = 6] = "LOADED_CLIENT_LAYER", e[e.LOADING_GUI_APP = 7] = "LOADING_GUI_APP", e[e.LOADED_GUI_APP = 8] = "LOADED_GUI_APP", e[e.NOTIFYING_GUI_LOADED = 9] = "NOTIFYING_GUI_LOADED", e[e.NOTIFIED_GUI_LOADED = 10] = "NOTIFIED_GUI_LOADED", e[e.LOADING_PROG_BAR = 11] = "LOADING_PROG_BAR", e[e.LOADED_PROG_BAR = 12] = "LOADED_PROG_BAR", e[e.LOADING_GUI_REQS = 13] = "LOADING_GUI_REQS", e[e.LOADED_GUI_REQS = 14] = "LOADED_GUI_REQS", e[e.REMOVING_LOAD_SCREEN = 15] = "REMOVING_LOAD_SCREEN", e[e.REMOVED_LOAD_SCREEN = 16] = "REMOVED_LOAD_SCREEN", e[e.RESOLVED = 17] = "RESOLVED"
    }(lr || (lr = {})), er.Connection.register("ble", () => new ir("ble"));
    class ur {
        constructor(e) {
            var t;
            this.options = e, this.guiState = lr.RESET, this.guiStateStartDate = new Date, this.guiStateTempDate = new Date, this.guiResolutionCloudLogTimeout = 6e4, this.au = new s.Aurelia, this.uaLog = new er.UALog(e.manifest.name), this.environment = null !== (t = this.options.environment) && void 0 !== t ? t : sr.d, this.uaStore = new ar(this, this.environment), this.uaScheduler = new cr.a
        }
        start(e = window.location.href) {
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                try {
                    this.updateAndLogGUIState(lr.RESET);
                    const t = this.getURLParams(e),
                        n = !t.path,
                        i = this.getProgressBar();
                    this.updateDocumentMetadata(), this.handleGUILoadResolutionTimeout(), this.updateAndLogGUIState(lr.TRY_LOADING_DEV_FEATURES), yield this.loadDevFeatures(), this.updateAndLogGUIState(lr.TRY_LOADED_DEV_FEATURES), this.updateAndLogGUIState(lr.LOADING_LOAD_SCREEN);
                    const r = yield this.createAndLoadLoadingScreen();
                    this.updateAndLogGUIState(lr.LOADED_LOAD_SCREEN), this.updateAndLogGUIState(lr.LOADING_CLIENT_LAYER), n || (yield this.loadUANet(t)), this.updateAndLogGUIState(lr.LOADED_CLIENT_LAYER), this.updateAndLogGUIState(lr.LOADING_GUI_APP), yield this.loadGUIApp(), this.updateAndLogGUIState(lr.LOADED_GUI_APP), this.updateAndLogGUIState(lr.NOTIFYING_GUI_LOADED), n || (yield this.notifyGUILoaded()), this.updateAndLogGUIState(lr.NOTIFIED_GUI_LOADED), this.updateAndLogGUIState(lr.LOADING_PROG_BAR), !n && i && (yield this.loadProgressBar(i)), this.updateAndLogGUIState(lr.LOADED_PROG_BAR), this.updateAndLogGUIState(lr.LOADING_GUI_REQS), yield Promise.all(this.loadGUIPromises()), this.updateAndLogGUIState(lr.LOADED_GUI_REQS), this.updateAndLogGUIState(lr.REMOVING_LOAD_SCREEN), yield this.removeLoadingScreen(r), this.updateAndLogGUIState(lr.REMOVED_LOAD_SCREEN), this.updateAndLogGUIState(lr.RESOLVED)
                } catch (e) {
                    this.uaLog.log("debug", JSON.stringify(e)), console.error(e), this.updateAndLogGUIState(lr.ERROR)
                }
            }))
        }
        updateAndLogGUIState(e) {
            const t = this.guiStateTempDate,
                n = this.guiState;
            this.guiStateTempDate = new Date, this.guiState = e;
            try {
                let e = Object(rr.c)(t, new Date) / 1e3;
                e = Number(e.toFixed(2));
                const i = lr[n],
                    r = lr[this.guiState],
                    s = this.guiState < 0 ? "error" : "info",
                    o = `GUI State: ${"error"===s?i:r}. GUI State Delta time: ${e} (s)`;
                if (this.uaLog.log(s, o), this.guiState === lr.RESET) this.guiStateStartDate = new Date;
                else if (this.guiState === lr.RESOLVED) {
                    const e = new Date;
                    let t = Object(rr.c)(this.guiStateStartDate, e) / 1e3,
                        n = t - .5;
                    t = Number(t.toFixed(2)), n = Number(n.toFixed(2));
                    const i = n >= this.guiResolutionCloudLogTimeout / 1e3 ? "error" : "info",
                        r = `GUI Resolution time: ${t} (s). Without blur animation: ${n} (s)`;
                    this.uaLog.log(i, r)
                }
            } catch (e) {}
        }
        handleGUILoadResolutionTimeout() {
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                if (yield Object(rr.m)(this.guiResolutionCloudLogTimeout), this.guiState !== lr.RESOLVED) {
                    const e = `GUI has not resolved yet. Elapsed time: ${this.guiResolutionCloudLogTimeout/1e3} (s). Current GUI state: ` + lr[this.guiState];
                    this.uaLog.log("error", e)
                }
            }))
        }
        loadDevFeatures() {
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                if (this.environment.UA_FINAL_CANDIDATE_BUILD) return !1;
                this.uaLog.destinations.console = !0, this.uaDevFeatureHandler = new or.a(this.au, this.uaLog, this.options.manifest), this.uaStore.set("uaDevFeatureHandler", this.uaDevFeatureHandler), this.uaLog.log("debug", "Detected non RC build"), this.uaLog.log("debug", "HBGF Environment: " + JSON.stringify(this.environment));
                let e = !1;
                try {
                    e = yield this.uaDevFeatureHandler.init()
                } catch (e) {}
                return this.uaLog.log("debug", "Dev features " + (e ? "enabled" : "disabled")), e
            }))
        }
        loadUANet(e) {
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                Object(er.logSessionStorage)("Application.loadUANet"), this.createAndRegisterAudioPlugin(e);
                const {
                    deviceId: t,
                    port: n,
                    path: i
                } = e;
                return new Promise((e, r) => {
                    if (!this.plugin) return Object(er.logSessionStorage)("Application.loadUANet plugin is undefined"), console.warn("Cannot load UANet. Plugin is undefined"), r();
                    this.plugin.connect(e, t, n, i)
                })
            }))
        }
        loadGUIApp() {
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                Object(er.logSessionStorage)("Application.loadGUIApp");
                const e = this.loadAttachedSpy(),
                    t = this.loadAurelia(),
                    n = this.loadResources();
                yield Promise.all([e, t, n])
            }))
        }
        notifyGUILoaded() {
            if (!this.plugin) return console.warn("Cannot notify host GUI loaded. Plugin is undefined"), Promise.reject();
            let e, t = !1,
                n = 0;
            return new Promise((i, r) => Object(I.__awaiter)(this, void 0, void 0, (function*() {
                const r = () => (Object(er.logSessionStorage)("Application.notifyGUILoaded: Response heard"), t = !0, s(), i(!0)),
                    s = () => {
                        Object(er.logSessionStorage)("Application.notifyGUILoaded: Clearing timeout"), clearTimeout(e), e = void 0
                    },
                    o = () => Object(I.__awaiter)(this, void 0, void 0, (function*() {
                        var e, t;
                        if (Object(er.logSessionStorage)(`Application.notifyGUILoaded: Sending post. Client connected: ${null===(e=this.plugin)||void 0===e?void 0:e.connected}. Tries: ${n}`), n++, n >= Number.MAX_SAFE_INTEGER && (n = 1), null === (t = this.plugin) || void 0 === t ? void 0 : t.connected) try {
                            return yield this.plugin.postWithReceipt({
                                selector: "effect",
                                id: "effect",
                                command: "notify_gui_loaded"
                            }), r()
                        } catch (e) {
                            let t = e;
                            if ("INVALID_UANET_PATH" === t.error || "UANET_MESSAGE_ERROR" === t.error) return r()
                        }
                    })),
                    a = () => {
                        t ? r() : (o(), c())
                    },
                    c = () => {
                        var t;
                        Object(er.logSessionStorage)(`Application.notifyGUILoaded: Creating timeout. Client connected: ${null===(t=this.plugin)||void 0===t?void 0:t.connected}. Tries: ${n}`), clearTimeout(e), e = setTimeout(a, 1e3 + 1e3 * n)
                    };
                if ("notify_gui_loaded" in window && "function" == typeof notify_gui_loaded) return notify_gui_loaded(), r();
                a()
            })))
        }
        loadAurelia() {
            const e = this.au.container;
            e.register(zi, Wi, i, qi, Gi, Ki, ai.shadowDOM({
                sharedStyles: [Xi.c]
            })), e.registerTransformer(s.ITargetObserverLocator, e => {
                const t = e.getObserver;
                return e.getObserver = (n, i, r, s, o) => {
                    switch (o) {
                        case "disabled":
                        case "readonly":
                            return new Hi(i, s, o);
                        default:
                            return t.call(e, n, i, r, s, o)
                    }
                }, e
            }), this.options.includes && this.au.register(...this.options.includes);
            const t = this.createApplicationHost();
            return Object(Zi.b)(t), Object(Xi.b)(t), Object(Xi.a)(t), Object(Zi.a)(), this.au.app({
                host: t,
                component: this.options.root
            }), this.au.start().wait()
        }
        loadResources() {
            Object(er.logSessionStorage)("Application.loadResources");
            const e = this.au.container.get(Qi.a);
            return this.uaStore.set("skins", e), Object(er.logSessionStorage)("Application.loadResources. Instantiated skins class"), e.configureAndLoadResources()
        }
        loadAttachedSpy() {
            if (!s.CustomElement.isType(this.options.root)) return Promise.resolve();
            let e;
            const t = s.CustomElement.getDefinition(this.options.root),
                n = this.options.root.prototype,
                i = new Promise(t => e = t),
                r = n.attached;
            return Object(er.logSessionStorage)("Application.loadAttachedSpy: attached was present: " + !!r), t.hooks.hasAttached = !0, n.attached = function(...t) {
                let i;
                return Object(er.logSessionStorage)("Application.loadAttachedSpy: calling attached"), r ? (i = r.apply(this, t), n.attached = r) : delete n.attached, e(), i
            }, i
        }
        loadProgressBar(e) {
            return this.plugin ? (Object(er.logSessionStorage)("Application.loadProgressBar"), this.updateProgressBar(e, this.plugin)) : (console.warn("Cannot load progress bar. Plugin is undefined"), Promise.reject())
        }
        loadGUIPromises() {
            var e, t;
            return Object(er.logSessionStorage)("Application.loadGUIPromises"), null !== (t = null === (e = this.options.loadingScreen) || void 0 === e ? void 0 : e.promisesToAwait) && void 0 !== t ? t : [Promise.resolve()]
        }
        getURLParams(e) {
            var t, n, i, r, s, o;
            const a = new URLSearchParams(e);
            return {
                deviceId: null !== (i = null !== (n = null !== (t = a.get("deviceId")) && void 0 !== t ? t : a.get("host")) && void 0 !== n ? n : a.get("ip")) && void 0 !== i ? i : void 0,
                port: null !== (r = a.get("port")) && void 0 !== r ? r : void 0,
                path: null !== (s = a.get("path")) && void 0 !== s ? s : void 0,
                transport: null !== (o = a.get("transport")) && void 0 !== o ? o : "ws"
            }
        }
        updateDocumentMetadata() {
            var e;
            document.title = null !== (e = this.options.manifest.name) && void 0 !== e ? e : "Title"
        }
        createApplicationHost() {
            let e = this.options.host;
            if (!e) {
                const t = this.options.root;
                if (s.CustomElement.isType(t)) {
                    const n = s.CustomElement.getDefinition(t).name;
                    e = document.querySelector(n), e || (e = document.createElement(n), e.style.position = "relative", e.style.zIndex = "0", document.body.appendChild(e))
                } else e = document.body
            }
            return e
        }
        getProgressBar() {
            const e = document.querySelector(".loading-progress");
            if (e) return e
        }
        updateProgressBar(e, t) {
            return new Promise(n => {
                const i = () => {
                    null == sessionStorage.getItem("ua-loading-meter") && sessionStorage.setItem("ua-loading-meter", "true"), (null == e ? void 0 : e.parentNode) && (null == e || e.remove()), n()
                };
                Object(er.logSessionStorage)("Application.updateProgressBar");
                if (sessionStorage.getItem("ua-loading-meter")) return i();
                const r = "ua_standard_loading_progress";
                if (null == t.getStoreValue({
                        selector: "meters",
                        id: r,
                        property: "level"
                    })) return i();
                let s = !1;
                setTimeout(() => {
                    s || i()
                }, 1e3);
                const o = t.registerCallbackListener({
                    selector: "meters",
                    id: r,
                    properties: {
                        level: {}
                    },
                    callback: n => {
                        const r = n.events[n.events.length - 1].value[0];
                        s = !0, null == e || e.setAttribute("value", r), r >= 1 && (null == e || e.classList.add("done"), this.seed && t.unregisterCallbackListener({
                            seed: this.seed
                        }), i())
                    }
                });
                o.seed ? this.seed = o.seed : (this.seed = void 0, i())
            })
        }
        createAndLoadLoadingScreen() {
            var e;
            return Object(I.__awaiter)(this, void 0, void 0, (function*() {
                Object(er.logSessionStorage)("Application.createAndLoadLoadingScreen");
                const t = null !== (e = this.getLoadingScreen()) && void 0 !== e ? e : this.createLoadingScreen(this.options.manifest);
                try {
                    yield this.loadLoadingScreen(t)
                } catch (e) {
                    console.warn("Could not preload loading screen images", e)
                }
                return t
            }))
        }
        createLoadingScreen(e) {
            var t, n, i;
            const r = e.loading_image,
                s = Object(rr.d)(r),
                o = document.createElement("div"),
                a = this.millisecToTransitionDuration(null !== (i = null === (n = null === (t = this.options) || void 0 === t ? void 0 : t.loadingScreen) || void 0 === n ? void 0 : n.transitionDurationMillisec) && void 0 !== i ? i : 500);
            return o.id = "ua-loading-screen", o.style.position = "absolute", o.style.zIndex = "1", o.style.top = "0px", o.style.left = "0px", o.style.width = e.window.width + "px", o.style.height = e.window.height + "px", o.style.backgroundSize = "contain", o.style.backgroundRepeat = "no-repeat", o.style.backgroundImage = `url(${s})`, o.style.backgroundImage = `-webkit-image-set(url(${s}) 1x, url(${r}) 2x)`, o.style.backgroundImage = `image-set(url(${s}) 1x, url(${r}) 2x)`, o.style.transitionDuration = a, o.style.transitionProperty = "opacity", o.style.transitionTimingFunction = "ease-in-out", o.style.opacity = "1", document.body.appendChild(o), {
                element: o,
                imageURLs: [r, s],
                transitionDuration: a,
                isLegacy: !1
            }
        }
        transitionLoadingScreen({
            element: e,
            isLegacy: t
        }) {
            t ? e.classList.add("done") : e.style.opacity = "0"
        }
        getLoadingScreen() {
            var e, t;
            const n = document.querySelector(".loading-screen");
            if (!n) return;
            const i = window.getComputedStyle(n),
                r = i.backgroundImage;
            return {
                element: n,
                imageURLs: Object(rr.f)(r),
                transitionDuration: i.transitionDuration ? i.transitionDuration : this.millisecToTransitionDuration(null !== (t = null === (e = this.options.loadingScreen) || void 0 === e ? void 0 : e.transitionDurationMillisec) && void 0 !== t ? t : 500),
                isLegacy: !0
            }
        }
        loadLoadingScreen({
            imageURLs: e
        }) {
            return new Promise((t, n) => Object(I.__awaiter)(this, void 0, void 0, (function*() {
                if (!e) return n(new Error("Image URLs are undefined"));
                const i = [];
                e.forEach(e => {
                    e && i.push(Object(rr.l)(e))
                });
                try {
                    yield Promise.all(i)
                } catch (e) {
                    return n(e)
                }
                return t()
            })))
        }
        transitionDurationToMillisec(e) {
            const t = e.toLowerCase(),
                n = t.includes("ms"),
                i = t.includes("s");
            let r = 500;
            return n ? r = Number(t.replace("ms", "")) : i && (r = 1e3 * Number(t.replace("s", ""))), Number.isNaN(r) && (r = 500), r
        }
        millisecToTransitionDuration(e) {
            return e + "ms"
        }
        removeLoadingScreen(e) {
            return new Promise(t => {
                const {
                    element: n,
                    transitionDuration: i
                } = e, r = this.transitionDurationToMillisec(i), s = () => {
                    Object(er.logSessionStorage)("Application.removeLoadingScreen. Removed"), n.parentNode || t(), n.removeEventListener("transitionend", s), n.removeEventListener("webkitTransitionEnd", s), n.removeEventListener("animationend", s), n.removeEventListener("webkitAnimationEnd", s), n.remove(), t()
                };
                Object(er.logSessionStorage)("Application.removeLoadingScreen. Started"), this.transitionLoadingScreen(e), n.addEventListener("transitionend", s), n.addEventListener("webkitTransitionEnd", s), n.addEventListener("animationend", s), n.addEventListener("webkitAnimationEnd", s), setTimeout(s, r + 20)
            })
        }
        createAudioPlugin({
            transport: e
        }) {
            let t;
            switch (e) {
                case "ble":
                case "ws":
                    t = er.Connection.get(e)
            }
            if (void 0 === t) throw new Error("no transport registered for " + e);
            return new er.AudioPlugin(t())
        }
        createAndRegisterAudioPlugin(e) {
            this.plugin = this.createAudioPlugin(e), this.uaLog.plugin = this.plugin, this.au.container.register(r.j.instance(er.AudioPlugin, this.plugin)), this.au.container.register(r.j.instance(er.UALog, this.uaLog)), this.au.container.register(r.j.instance(cr.a, this.uaScheduler)), this.uaStore.set("plugin", this.plugin), this.uaStore.set("uaLog", this.uaLog), this.uaStore.set("uaScheduler", this.uaScheduler)
        }
    }
    var hr, dr = n(5);

    function pr(e, t) {
        let n;
        const i = function(e, t) {
            arguments.length > 1 && (n.name = t), fr.define(e, n, !0)
        };
        return arguments.length > 1 ? (n = {}, void i(e, t)) : "string" == typeof e ? (n = {
            name: e
        }, i) : (n = e || {}, i)
    }
    let fr = hr = class {
        constructor(e, t) {
            switch (this.obj = e, this.config = t, this.guard = function() {
                    let e = !1;
                    return function(t) {
                        e || (e = !0, t(), e = !1)
                    }
                }(), this.initialValueRetrieved = !1, this.useTouch = !0, this.plugin = this.getAudioPlugin(), this.selector = t.selector || "controls", this.id = t.id || t.param || t.name, this.property = t.property || "normalized_value", this.valueType = t.type, this.useTouch = "useTouch" in t ? t.useTouch : "controls" === this.selector, this.valueType) {
                case dr.c.normalized:
                    this.property = "normalized_value";
                    break;
                case dr.c.string:
                    this.property = "string_value";
                    break;
                case dr.c.real:
                    this.property = "real_value";
                    break;
                case dr.c.name:
                    this.property = "name"
            }
            this.setupSubscription()
        }
        detaching() {
            this.seed && this.plugin.unregisterCallbackListener({
                seed: this.seed
            })
        }
        handleChange(e, t, n) {
            this.setValue(e, n)
        }
        getValue() {
            return !this.initialValueRetrieved && this.plugin.client && (this.initialValueRetrieved = !0, this.currentValue = this.getValueFromPlugin()), this.currentValue
        }
        setValue(e, t) {
            e !== this.currentValue && (this.setGuiValue(e, t), this.sendValueToPlugin())
        }
        getCallback() {
            var e, t;
            return null !== (t = this.obj[null !== (e = this.config.callback) && void 0 !== e ? e : this.config.name + "Changed"]) && void 0 !== t ? t : null
        }
        setGuiValue(e, t) {
            if (e !== this.currentValue) {
                const n = this.currentValue;
                t |= this.persistentFlags, this.currentValue = e, this.callSubscribers(e, n, 524288 | t);
                const i = this.getCallback();
                "function" == typeof i && i.call(this.obj, e, n, t)
            }
        }
        sendValueToPlugin() {
            this.guard(() => {
                this.useTouch && this.plugin.setTouch(this.id, !0), this.plugin.setWithReceipt({
                    selector: this.selector,
                    id: this.id,
                    property: this.property,
                    payload: this.currentValue
                }), this.useTouch && this.plugin.setTouch(this.id, !1)
            })
        }
        getValueFromPlugin() {
            var e;
            switch (this.valueType) {
                case dr.c.values:
                    const t = this.plugin.getStoreValue({
                            selector: this.selector,
                            id: this.id,
                            property: "real_values"
                        }),
                        n = this.plugin.getStoreValue({
                            selector: this.selector,
                            id: this.id,
                            property: "string_values"
                        });
                    if (null !== t && Array.isArray(t) && t.length > 0 && null !== n && Array.isArray(n) && n.length > 0) {
                        const i = t.map((e, t) => ({
                            value: e,
                            name: n[t]
                        }));
                        return this.setGuiValue(i, 0), null !== (e = this.currentValue) && void 0 !== e ? e : []
                    }
                    return [];
                default:
                    return this.plugin.getStoreValue({
                        selector: this.selector,
                        id: this.id,
                        property: this.property
                    })
            }
        }
        getAudioPlugin() {
            const e = this.obj.$controller;
            if (e) return e.context.get(er.AudioPlugin);
            for (const e of this.obj) {
                const t = this.obj[e];
                if (t instanceof er.AudioPlugin) return t
            }
            throw new Error("AudioPlugin not found. You must use the @uanet decorator on a component or an object with an AudioPlugin property.")
        }
        static define(e, t, n = !1) {
            function i() {
                return this.$observers[t.name].getValue()
            }
            if (i.getObserver = function(e) {
                    return e.$observers[t.name]
                }, Reflect.defineProperty(e, t.name, {
                    enumerable: !0,
                    get: i,
                    set: function(e) {
                        this.$observers[t.name].setValue(e, 0)
                    }
                }), n) {
                let n = e.uaNetProperties;
                if (!n) {
                    e.uaNetProperties = n = [];
                    const t = e.created || r.g.noop;
                    e.created = function() {
                        let e = this.$observers;
                        e || (e = {}, this.$observers = e), n.forEach(t => e[t.name] = new hr(this, t)), t.call(this)
                    }
                }
                n.push(t)
            } else {
                let n = e.$observers;
                n || (n = {}, e.$observers = n), n[t.name] = new hr(e, t)
            }
        }
        setupSubscription() {
            let e = {};
            e = this.valueType === dr.c.values ? {
                real_values: {},
                string_values: {}
            } : {
                [this.property]: {}
            };
            const t = this.plugin.registerCallbackListener({
                selector: this.selector,
                id: this.id,
                properties: e,
                callback: () => {},
                updater: () => {
                    this.guard(() => {
                        const e = this.getValueFromPlugin();
                        this.setValue(e, 0)
                    })
                }
            });
            this.seed = t.seed
        }
    };
    fr = hr = Object(I.__decorate)([Object(s.subscriberCollection)(), Object(I.__metadata)("design:paramtypes", [Object, Object])], fr);

    function gr(e) {
        return e ? e.startsWith("https://") ? e.replace("https://", "host://") : e.startsWith("http://") ? e.replace("http://", "host://") : e.startsWith("//") ? e.replace("//", "host://") : e.startsWith("host://") ? e : "host://" + e : ""
    }
    var mr = n(7);
    const vr = ["C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B"];

    function br(e, t = 0) {
        "string" == typeof e && (e = parseInt(e)), e = Math.round(e);
        const n = Math.floor(e / 12) + t;
        return `${vr[e%12]}${n}`
    }
    var yr = n(49),
        wr = n(46);
    n.d(t, "DebugConfiguration", (function() {
        return j
    })), n.d(t, "bindable", (function() {
        return s.bindable
    })), n.d(t, "children", (function() {
        return s.children
    })), n.d(t, "customElement", (function() {
        return s.customElement
    })), n.d(t, "LinearInteractionAttribute", (function() {
        return M.b
    })), n.d(t, "debounce", (function() {
        return M.c
    })), n.d(t, "InteractionProfile", (function() {
        return M.a
    })), n.d(t, "TextLevel", (function() {
        return L.h
    })), n.d(t, "ImagePacking", (function() {
        return L.d
    })), n.d(t, "DEFAULT_UACOMPONENT_TRACKER_STATE", (function() {
        return L.b
    })), n.d(t, "component", (function() {
        return L.A
    })), n.d(t, "isObject", (function() {
        return L.B
    })), n.d(t, "runGUICallback", (function() {
        return L.D
    })), n.d(t, "runCallbackSafely", (function() {
        return L.C
    })), n.d(t, "HTMLKnobBehavior", (function() {
        return L.c
    })), n.d(t, "UACheckbox", (function() {
        return L.j
    })), n.d(t, "UASwitch", (function() {
        return L.x
    })), n.d(t, "SwitchValueConverter", (function() {
        return L.g
    })), n.d(t, "UAKnob", (function() {
        return L.q
    })), n.d(t, "UAFilmStrip", (function() {
        return L.n
    })), n.d(t, "UAInputNumber", (function() {
        return L.o
    })), n.d(t, "UADropdown", (function() {
        return L.m
    })), n.d(t, "UAOption", (function() {
        return L.u
    })), n.d(t, "UAText", (function() {
        return L.y
    })), n.d(t, "UAInputText", (function() {
        return L.p
    })), n.d(t, "UAListbox", (function() {
        return L.r
    })), n.d(t, "UASlider", (function() {
        return L.v
    })), n.d(t, "UASliderRange", (function() {
        return L.w
    })), n.d(t, "UAToggleButton", (function() {
        return L.z
    })), n.d(t, "UAButton", (function() {
        return L.i
    })), n.d(t, "UAMidiNote", (function() {
        return L.t
    })), n.d(t, "UAClip", (function() {
        return L.k
    })), n.d(t, "UAComponent", (function() {
        return L.l
    })), n.d(t, "UAMeter", (function() {
        return L.s
    })), n.d(t, "Orientation", (function() {
        return L.f
    })), n.d(t, "InteractionMode", (function() {
        return L.e
    })), n.d(t, "AnimationDirection", (function() {
        return L.a
    })), n.d(t, "SkinSiteAttribute", (function() {
        return P.c
    })), n.d(t, "SkinManager", (function() {
        return P.b
    })), n.d(t, "deriveImageNamesFromSkin", (function() {
        return P.d
    })), n.d(t, "skinnable", (function() {
        return P.e
    })), n.d(t, "SkinConfiguration", (function() {
        return P.a
    })), n.d(t, "ComponentAutomator", (function() {
        return R.a
    })), n.d(t, "UAParamAttribute", (function() {
        return R.e
    })), n.d(t, "ValueType", (function() {
        return R.f
    })), n.d(t, "DefaultPropertyName", (function() {
        return R.b
    })), n.d(t, "isUANetValueProvider", (function() {
        return R.h
    })), n.d(t, "isUANetValueReceiver", (function() {
        return R.i
    })), n.d(t, "isUANetConfigurable", (function() {
        return R.g
    })), n.d(t, "UANetAutomationLocator", (function() {
        return R.d
    })), n.d(t, "UAMeterAttribute", (function() {
        return R.c
    })), n.d(t, "EGUIState", (function() {
        return lr
    })), n.d(t, "Application", (function() {
        return ur
    })), n.d(t, "uanet", (function() {
        return pr
    })), n.d(t, "UANetProperty", (function() {
        return fr
    })), n.d(t, "disableUserSelect", (function() {
        return Xi.b
    })), n.d(t, "setClipPath", (function() {
        return Xi.e
    })), n.d(t, "setBackgroundImage", (function() {
        return Xi.d
    })), n.d(t, "enableContextMenus", (function() {
        return Zi.e
    })), n.d(t, "disableContextMenus", (function() {
        return Zi.b
    })), n.d(t, "disableBackspaceNavigation", (function() {
        return Zi.a
    })), n.d(t, "disableSpacebarScrolling", (function() {
        return Zi.c
    })), n.d(t, "dispatchDOMEvent", (function() {
        return Zi.d
    })), n.d(t, "applyHostLinkProtocol", (function() {
        return gr
    })), n.d(t, "clamp", (function() {
        return mr.a
    })), n.d(t, "round", (function() {
        return mr.c
    })), n.d(t, "ensureFloat", (function() {
        return mr.b
    })), n.d(t, "convertNumberToNote", (function() {
        return br
    })), n.d(t, "getInteractingInputDevice", (function() {
        return sr.l
    })), n.d(t, "generateSyntheticMiddlewareEvent", (function() {
        return sr.h
    })), n.d(t, "isTSyntheticPointerMiddlewareEvent", (function() {
        return sr.m
    })), n.d(t, "InteractionEvent", (function() {
        return sr.g
    })), n.d(t, "DEFAULT_UANET_CONFIG", (function() {
        return sr.c
    })), n.d(t, "DEFAULT_GUI_MANIFEST", (function() {
        return sr.a
    })), n.d(t, "HBGF_ENV", (function() {
        return sr.d
    })), n.d(t, "DEFAULT_HBGF_DEV_FEATURES", (function() {
        return sr.b
    })), n.d(t, "HBGF_RUNTIME_FILE_DEPS", (function() {
        return sr.e
    })), n.d(t, "IS_AMBER_TEST", (function() {
        return sr.f
    })), n.d(t, "getHBGFWindow", (function() {
        return sr.k
    })), n.d(t, "getHBGFEnv", (function() {
        return sr.i
    })), n.d(t, "getHBGFEnvVar", (function() {
        return sr.j
    })), n.d(t, "setHBGFEnvVar", (function() {
        return sr.n
    })), n.d(t, "Font", (function() {
        return yr.a
    })), n.d(t, "ResourceManager", (function() {
        return Yi.a
    })), n.d(t, "isNode", (function() {
        return rr.i
    })), n.d(t, "sleep", (function() {
        return rr.m
    })), n.d(t, "isFileImg", (function() {
        return rr.g
    })), n.d(t, "getResourceURLsFromBackgroundImageCSS", (function() {
        return rr.f
    })), n.d(t, "getImage1xPath", (function() {
        return rr.d
    })), n.d(t, "loadImage", (function() {
        return rr.l
    })), n.d(t, "getPlatform", (function() {
        return rr.e
    })), n.d(t, "isTouchEvent", (function() {
        return rr.j
    })), n.d(t, "isMouseEvent", (function() {
        return rr.h
    })), n.d(t, "isWheelEvent", (function() {
        return rr.k
    })), n.d(t, "getElapsedTimeMillisec", (function() {
        return rr.c
    })), n.d(t, "snakeToCamelCase", (function() {
        return rr.n
    })), n.d(t, "fetchJSON", (function() {
        return rr.a
    })), n.d(t, "getBase64", (function() {
        return rr.b
    })), n.d(t, "HBGFDevFeaturesJson", (function() {
        return wr
    })), n.d(t, "UAScheduler", (function() {
        return cr.a
    })), n.d(t, "UADevFeatureHandler", (function() {
        return or.a
    }))
});
