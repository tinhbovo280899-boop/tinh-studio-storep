// Extracted webpack module 88. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-switch",
        o = '\x3c!-- BG: HBGF-1335: This component is deprecated: may not have display and click-region pattern --\x3e\n\n<div skin-site="value.bind: skin; type.bind: skinType"\n      class="container ${disabled ? \'disabled\' : \'\'} ${orientation}"\n      ref="$display">\n  <div class="track ${isActive ? \'active\' : \'\'}"></div>\n  <div class="indicator ${isActive ? \'active\' : \'\'}"></div>\n</div>\n<label class="click-region">\n  <input if.bind="mode === \'toggle\' && states.length < 3"\n        type="checkbox"\n        class="inner-input ${skin ? \'\' : orientation}"\n        disabled.bind="disabled"\n        checked.two-way="value | switchValueConverter:$this"\n        ref="$inputCheckbox">\n  <input else type="range"\n            class="inner-input ${orientation}"\n            disabled.bind="disabled"\n            value.two-way="value | switchValueConverter:$this"\n            min="0"\n            step="1"\n            max="${states.length - 1}"\n            ref="$inputRange">\n</label>';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  display: inline-block;\n  position: relative;\n}\n\n:host(:focus) {\n  outline: none;\n}\n\n.click-region {\n  position: absolute;\n  top: calc(-1 * var(--ua-switch-click-region-top, 0px));\n  left: calc(-1 * var(--ua-switch-click-region-left, 0px));\n  height: calc(100% + var(--ua-switch-click-region-top, 0px) + var(--ua-switch-click-region-bottom, 0px));\n  width: calc(100% + var(--ua-switch-click-region-left, 0px) + var(--ua-switch-click-region-right, 0px));\n  border: var(--ua-click-region-border, none);\n}\n\n.inner-input {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  opacity: 0;\n}\n\n.inner-input:disabled {\n  /*cursor: default;*/\n}\n\n:host {\n  --ua-switch-indicator-size-default: 20px;\n  --ua-switch-track-reduction: calc(1 - var(--ua-switch-track-ratio, -.1));\n  --ua-switch-indicator-offset-right: calc(var(--ua-switch-indicator-offset-ratio, -.1) * var(--ua-switch-indicator-size, var(--ua-switch-indicator-size-default)));\n  --ua-switch-indicator-offset-left: calc(-1 * var(--ua-switch-indicator-offset-right));\n\n  width: 40px;\n  height: var(--ua-switch-indicator-size, var(--ua-switch-indicator-size-default));\n}\n\n.container {\n  display: var(--ua-switch-container-display, block);\n  position: absolute;\n  width: 100%;\n  height: 100%;\n}\n\n.track {\n  position: absolute;\n  height: calc(100% - var(--ua-switch-indicator-size, var(--ua-switch-indicator-size-default)) * var(--ua-switch-track-ratio, -.1));\n  width: 100%;\n  top: calc(var(--ua-switch-indicator-size, var(--ua-switch-indicator-size-default)) * var(--ua-switch-track-ratio, -.1) / 2);\n  border: var(--ua-switch-track-border, 1px solid #dfdfdf);\n  border-radius: var(--ua-switch-track-radius, 20px);\n  background: var(--ua-switch-track-background, #FFF);\n  transition: background-color 150ms ease-in-out;\n}\n\n.track.active {\n  background: var(--ua-switch-track-background-active, rgb(100, 189, 99));\n  border: var(--ua-switch-track-border-active, 1px solid rgb(100, 189, 99));\n}\n\n.indicator {\n  position: absolute;\n  left: var(--ua-switch-indicator-offset-left);\n  height: var(--ua-switch-indicator-size, var(--ua-switch-indicator-size-default));\n  width: var(--ua-switch-indicator-size, var(--ua-switch-indicator-size-default));\n  background: var(--ua-switch-indicator-background, #FFF);\n  border-radius: var(--ua-switch-indicator-radius, 100%);\n  box-shadow: var(--ua-switch-indicator-shadow, 0 1px 3px rgba(0,0,0,0.4));\n  transition: left .1s ease-in-out, background-color .1s ease-in-out;\n}\n\n.indicator.active {\n  left: calc(100% - var(--ua-switch-indicator-size, var(--ua-switch-indicator-size-default)) + var(--ua-switch-indicator-offset-right));\n  background: var(--ua-switch-indicator-background-active, #fff);\n  box-shadow: var(--ua-switch-indicator-shadow-active, 0px 2px 5px 0px rgba(0, 0, 0, 0.4));\n}\n\n.disabled {\n  opacity: var(--ua-disabled-opacity, 1.0);\n}\n\n.vertical {\n  transform: rotate(-90deg);\n}\n\n.vertical-reverse {\n  transform: rotate(90deg);\n}\n\n.horizontal-reverse {\n  transform: rotate(180deg);\n}\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
