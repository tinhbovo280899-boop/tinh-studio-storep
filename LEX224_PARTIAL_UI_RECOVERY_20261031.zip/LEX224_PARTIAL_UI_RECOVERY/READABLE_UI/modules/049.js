// Extracted webpack module 49. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return r
    }));
    var i = n(0);
    class r {
        constructor() {
            this.url = "", this.loaded = !1, this.fontFamily = "", this.onload = function() {}, this.onerror = function(e) {}
        }
        getFontUrl() {
            let e;
            return e = this.isSystemFont() ? `local(${this.url})` : `url(${this.url})`, e
        }
        isSystemFont() {
            return -1 === this.url.indexOf(".")
        }
        loadFont() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                if (this.loaded) return !1;
                const e = this.getFontUrl(),
                    t = new FontFace(this.fontFamily, e);
                document.fonts.add(t);
                try {
                    yield t.load(), this.loaded = !0, this.onload()
                } catch (t) {
                    this.loaded = !1, console.error(t), this.onerror("Error downloading font resource: " + JSON.stringify({
                        fontUrl: e,
                        fontFamily: this.fontFamily,
                        resourceUrl: this.url
                    }))
                }
                return this.loaded
            }))
        }
        set src(e) {
            this.url = e, this.loadFont()
        }
        get src() {
            return this.url
        }
    }
});
