// Extracted webpack module 154. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.LEDDisplay = void 0;
    const i = n(0),
        r = (0, i.__importStar)(n(158)),
        s = n(1),
        o = n(6);

    function a(e, t) {
        return Math.max(1, Math.min(t - 1, Math.round(e * t)))
    }
    let c = class {
        constructor(e) {
            this.plug = e, this.activeControlID = "program", this.timeoutID = void 0
        }
        attached() {
            this.plug.registerMultiCallbackListener({
                listeners: [{
                    selector: "controls",
                    id: "program",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "bass",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "mid",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "crossover",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "treble_decay",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "depth",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "predelay",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "diffusion",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "mix",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "enh_-_+",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "pitch_-_+",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "opt_-_+",
                    properties: {
                        string_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "rear_outs",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "controls",
                    id: "power",
                    properties: {
                        real_value: {}
                    }
                }, {
                    selector: "private_data",
                    id: "led_hold",
                    properties: {
                        data: {}
                    }
                }],
                callback: e => this.updateHandler(e.values)
            }), this.setLEDDisplayID("program")
        }
        updateHandler(e) {
            const t = this.plug.getStoreValue({
                selector: "private_data",
                id: "led_hold",
                property: "data"
            });
            if (e.private_data.led_hold && (t ? clearTimeout(this.timeoutID) : this.setLEDDisplayID("program")), Object.keys(e.controls).length > 1) this.setLEDDisplayID("program");
            else if (e.controls.program) t ? this.updateDisplay() : this.setLEDDisplayID("program");
            else if (e.controls.rear_outs || e.controls.power) this.updateDisplay();
            else if (1 == Object.keys(e.controls).length) {
                const [t] = Object.keys(e.controls);
                this.setLEDDisplayID(t)
            }
        }
        getActiveControlID() {
            return this.activeControlID
        }
        setLEDDisplayID(e) {
            this.activeControlID = e;
            this.plug.getStoreValue({
                selector: "private_data",
                id: "led_hold",
                property: "data"
            }) || "program" != this.activeControlID && (clearTimeout(this.timeoutID), this.timeoutID = setTimeout(() => {
                this.setLEDDisplayID("program")
            }, 3e3)), this.updateDisplay()
        }
        updateDisplay() {
            return (0, i.__awaiter)(this, void 0, void 0, (function*() {
                let e = "    ",
                    t = [],
                    n = -1;
                if (this.plug.getStoreValue({
                        selector: "controls",
                        id: "power",
                        property: "real_value"
                    })) {
                    if ("depth" == this.activeControlID) {
                        const e = this.plug.getStoreValue({
                                selector: "controls",
                                id: "program",
                                property: "real_value"
                            }),
                            t = this.plug.getStoreValue({
                                selector: "controls",
                                id: "rear_outs",
                                property: "real_value"
                            });
                        (5 == e && t || 8 == e) && (this.activeControlID = "program")
                    }
                    if ("program" == this.activeControlID) {
                        const t = this.plug.getStoreValue({
                                selector: "controls",
                                id: "bass",
                                property: "normalized_value"
                            }),
                            n = this.plug.getStoreValue({
                                selector: "controls",
                                id: "mid",
                                property: "normalized_value"
                            }),
                            i = a(t, 32) + a(n, 32) >> 1;
                        e = yield this.plug.postWithReceipt({
                            selector: "controls",
                            id: "bass",
                            command: "get_string_for_normalized_value",
                            payload: i / 32
                        }).catch(e => (console.error(e), " ---"))
                    } else e = this.plug.getStoreValue({
                        selector: "controls",
                        id: this.activeControlID,
                        property: "string_value"
                    }), "100%" == e && (e = " 100")
                }
                for (const n of e.slice(0, 4)) t.push(" 0123456789-".indexOf(n));
                const i = e.slice(5);
                n = ["s", "ms", "Hz", "kHz"].indexOf(i);
                const r = this.numericDisp.children,
                    s = this.unitsDisp.children;
                let o = !1;
                for (let e = 2, n = 3; e >= 0; e--, n--)(o = -1 == t[n]) && n--, r[e].classList.toggle("decimal", o), r[e].style.backgroundPositionY = -30 * t[n] + "px";
                for (let e = 0; e < 4; e++) s[e].style.backgroundPositionY = (n == e ? 0 : -17) + "px"
            }))
        }
    };
    c = (0, i.__decorate)([(0, s.customElement)(r), (0, i.__metadata)("design:paramtypes", [o.AudioPlugin])], c), t.LEDDisplay = c
});
