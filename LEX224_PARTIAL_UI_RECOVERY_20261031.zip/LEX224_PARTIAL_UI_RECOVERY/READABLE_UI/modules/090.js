// Extracted webpack module 90. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-input-number",
        o = '\x3c!-- BG: HBGF-1335: This component is unmaintained: does not use display and click-region pattern --\x3e\n\n<input type="text"\n      class="${disabled ? \'disabled\' : \'\'} \n      ${hideoutline ? \'no-outline\' : \'\'}"\n      ref="$input"\n      disabled.bind="disabled"\n      focus.bind="hasFocus"\n      keydown.trigger="onKeyDown($event)"\n      keyup.trigger="onKeyUp($event)"\n      blur.trigger="onBlur($event)">  \n\n\n<div class="click-region"\n     disabled.bind="disabled"\n     wheel.trigger="onMouseWheel($event)"\n     mousedown.trigger="onMouseDown($event)"></div>';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  display: inline-block;\n  position: relative;\n}\n\n:host(:focus) {\n  outline: none;\n}\n\n.click-region {\n  position: absolute;\n  top: calc(-1 * var(--ua-input-number-click-region-top, 0px));\n  left: calc(-1 * var(--ua-input-number-click-region-left, 0px));\n  height: calc(100% + var(--ua-input-number-click-region-top, 0px) + var(--ua-input-number-click-region-bottom, 0px));\n  width: calc(100% + var(--ua-input-number-click-region-left, 0px) + var(--ua-input-number-click-region-right, 0px));\n  border: var(--ua-click-region-border, none);\n}\n\ninput {\n  position: relative;\n  width: 100%;\n  height: 100%;\n  background: var(--ua-input-number-background, #f9f9f9);\n  border-radius: var(--ua-input-number-radius, 3px);\n  border: var(--ua-input-number-border, 1px solid #ddd);\n  color: var(--ua-input-number-color, #333);\n  padding: var(--ua-input-number-padding, 4px);\n  text-align: var(--ua-input-number-text-align, left);\n  box-shadow: var(--ua-input-number-shadow, none);\n  caret-color: var(--ua-input-number-caret-color, var(--ua-input-number-color, #333));\n  outline: var(--ua-input-number-outline, none);\n  text-shadow: var(--ua-input-number-text-shadow, none);\n  cursor: var(--ua-input-number-cursor, default);\n}\n\ninput:focus {\n  background: var(--ua-input-number-active-background, var(--ua-input-number-background, #f9f9f9));\n  border: var(--ua-input-number-active-border, 1px solid #2196F3);\n  color: var(--ua-input-number-active-color, var(--ua-input-number-color, #333));\n}\n\ninput:focus.no-outline {\n  caret-color: transparent;\n  border: 0 solid;\n  outline: none;\n}\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
