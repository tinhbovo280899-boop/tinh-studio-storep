// Extracted webpack module 155. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    }), t.Skins = void 0;
    const i = n(63);
    class r extends i.SkinConfiguration {
        configure() {
            this.images.load("UA_Lexicon224_panel"), this.configureKnobs(), this.configureSliders(), this.configureButtons()
        }
        configureKnobs() {
            this.knob.imageSkin({
                name: "PotKnob",
                imageName: "UA_Lexicon224_pot",
                frameSize: 35,
                frameCount: 31
            })
        }
        configureSliders() {
            this.slider.imageSkin({
                name: "DispSwitch",
                imageName: "UA_Lexicon224_displayswitch",
                frameSize: 40,
                frameCount: 2
            })
        }
        configureButtons() {
            this.button.imageSkin({
                name: "OpenClose",
                imageName: "UA_Lexicon224_open_close_label",
                frameSize: 33,
                frameCount: 2
            }), this.button.imageSkin({
                name: "PitchShift",
                imageName: "UA_Lexicon224_button_PitchShift",
                frameSize: 38,
                frameCount: 2
            }), this.button.imageSkin({
                name: "LinkLED",
                imageName: "UA_Lexicon224_LED-link",
                frameSize: 17,
                frameCount: 2,
                direction: i.AnimationDirection.reverse
            }), this.button.imageSkin({
                name: "UALogo",
                imageName: "UA_Lexicon224_UAlogo",
                frameSize: 17,
                frameCount: 2
            }), this.button.imageSkin({
                name: "PowerSwitch",
                imageName: "UA_Lexicon224_button_POWER",
                frameSize: 33,
                frameCount: 2
            }), this.button.imageSkin({
                name: "SmallSwitchL",
                imageName: "UA_Lexicon224_switch_small_L",
                frameSize: 60,
                frameCount: 4
            }), this.button.imageSkin({
                name: "SmallSwitchC",
                imageName: "UA_Lexicon224_switch_small_C",
                frameSize: 60,
                frameCount: 4
            }), this.button.imageSkin({
                name: "SmallSwitchR",
                imageName: "UA_Lexicon224_switch_small_R",
                frameSize: 60,
                frameCount: 4
            }), this.button.imageSkin({
                name: "BigSwitchL",
                imageName: "UA_Lexicon224_switch_large_L",
                frameSize: 60,
                frameCount: 4
            }), this.button.imageSkin({
                name: "BigSwitchC",
                imageName: "UA_Lexicon224_switch_large_C",
                frameSize: 60,
                frameCount: 4
            }), this.button.imageSkin({
                name: "BigSwitchR",
                imageName: "UA_Lexicon224_switch_large_R",
                frameSize: 60,
                frameCount: 4
            })
        }
    }
    t.Skins = r
});
