// Extracted webpack module 8. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return h
    })), n.d(t, "b", (function() {
        return d
    }));
    var i = n(0),
        r = n(2),
        s = n(1),
        o = n(11),
        a = n(10),
        c = n(6),
        l = n(47),
        u = n(3);
    const h = {
        event: new Event("mousedown"),
        movementPx: 0,
        totalMovementPx: 0,
        moveRemainderPx: 0,
        dragging: void 0,
        lastScreenX: void 0,
        lastScreenY: void 0,
        posX: void 0,
        posY: void 0,
        changeX: 0,
        changeY: 0,
        startPx: void 0,
        index: 0,
        interactionType: "movement",
        value: 0,
        initialNormalizedValue: 0,
        min: 0,
        max: 1,
        discrete: !1,
        orientation: a.a.vertical,
        endless: !1,
        states: null,
        offsetPx: 0,
        fineTune: !1,
        rangePx: 200,
        mousewheelRangePx: 2e3,
        trackpadRangePx: 2e3,
        get step() {
            return 1 / this.rangePx
        },
        get curStep() {
            return this.fineTune ? this.fineStep : this.step
        },
        get fineStep() {
            return 1 / (4 * this.rangePx)
        },
        get fineTuneScaling() {
            return this.step / this.fineStep
        },
        isTrackPad: !1,
        isOffScreen: !1,
        indicatorJumpToPosition: !1
    };
    class d {
        constructor(e, t, n) {
            this.element = e, this.profile = t, this.uaScheduler = n, this.interactionHost = null, this.disabled = !1, this.interaction = () => () => {}, this.uaNet = o.c, this.hardwareAccelerated = !0, this.dragging = !1, this.scrolling = !1, this.DEFAULT_TRACKER_STATE = h, this.ea = new r.b, this.eventListeners = {}, this.value = h.value, this.index = h.index, this.step = h.step, this.fineStep = h.fineStep, this.min = h.min, this.max = h.max, this.discrete = h.discrete, this.orientation = h.orientation, this.endless = h.endless, this.states = h.states, this.startPx = h.startPx, this.rangePx = h.rangePx, this.mousewheelRangePx = h.mousewheelRangePx, this.isTouching = !1, this.validateTouchEvent = (e, {
                state: t
            }) => (t.id = "validateTouchEvent", t), this.validateMouseEvent = (e, {
                state: t
            }) => (t.id = "validateMouseEvent", t), this.validateWheelEvent = (e, {
                state: t
            }) => (t.id = "validateWheelEvent", t), this.calculateDOMDependentProperties = (e, {
                state: t
            }) => (t.id = "calculateDOMDependentProperties", t), this.startUANetInteraction = (e, {
                state: t
            }) => (t.id = "startUANetInteraction", this.includesAction({
                action: "EXIT",
                state: t
            }) || this.includesAction({
                action: "DEFAULT",
                state: t
            }) || this.includesAction({
                action: "REVERT",
                state: t
            }) || t.action.push("START"), t), this.changeUANetInteraction = (e, {
                state: t
            }) => (t.id = "changeUANetInteraction", this.includesAction({
                action: "EXIT",
                state: t
            }) || this.includesAction({
                action: "DEFAULT",
                state: t
            }) || this.includesAction({
                action: "REVERT",
                state: t
            }) || t.action.push("CHANGE"), t), this.endUANetInteraction = (e, {
                state: t
            }) => (t.id = "endUANetInteraction", this.includesAction({
                action: "EXIT",
                state: t
            }) || this.includesAction({
                action: "DEFAULT",
                state: t
            }) || this.includesAction({
                action: "REVERT",
                state: t
            }) || t.action.push("END"), t), this.revertUANetInteraction = (e, {
                state: t
            }) => {
                t.id = "revertUANetInteraction";
                let n = !1;
                return u.h(e) ? n = this.profile.isRevertEvent(e) : u.j(e) && (n = this.profile.isRevertTouchEvent(e)), n && !this.includesAction({
                    action: "EXIT",
                    state: t
                }) && t.action.push("REVERT"), t
            }, this.defaultUANetInteraction = (e, {
                state: t
            }) => (t.id = "defaultUANetInteraction", this.profile.isDefaultEvent(e) && !this.includesAction({
                action: "EXIT",
                state: t
            }) && t.action.push("DEFAULT"), t), this.tryInteractionCallback = (e, t) => {
                t.state.id = "tryInteractionCallback";
                let n = void 0;
                return (!Object(o.m)(t.state.type) || this.shouldMiddlewareChainContinue(t.state)) && (n = Object(l.d)({
                    wrapperCallback: this.interaction,
                    callbackArgs: [e, t]
                })), null == n ? t.state : n
            }, this.validateEvent = (e, t) => {
                const n = t.state;
                n.id = "validateEvent", e.preventDefault();
                const i = Object(o.h)(n.type),
                    r = Object(o.l)(e);
                return this.interactingInputDevice ? this.interactingInputDevice !== r || "down" === i ? (n.exitChain = !0, this.removeMoveAndUpListener(new Event("change"), t), this.isTouching && this.createUANetInteraction({
                    action: "END",
                    state: n
                }), this.interactingInputDevice = void 0) : "up" === i && (this.interactingInputDevice = void 0) : "down" === i && (this.interactingInputDevice = r), (!this.isMouseEventValid(e) && !this.isTouchEventValid(e) || this.disabled || this.scrolling) && n.action.push("EXIT"), n
            }, this.removeMoveAndUpListener = (e, {
                state: t
            }) => (t.id = "removeMoveAndUpListener", this.removeMoveEventListener({
                target: window
            }), this.removeUpEventListener({
                target: window
            }), t), this.updateMiddlewareEvent = (e, {
                state: t
            }) => (t.id = "updateMiddlewareEvent", t.type = Object(o.h)(t.type), t), this.createEventListenerMiddleware = e => {
                const {
                    middleware: t
                } = e;
                return e => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    const n = this.generateMiddlewareConfig({
                        event: e,
                        action: ["RESET"],
                        type: e.type
                    });
                    try {
                        const e = yield this.runMiddleware({
                            config: n,
                            middleware: t
                        });
                        this.handleMiddleware(e)
                    } catch (e) {
                        console.error("UAComponent.createEventListenerMiddleware: runMiddleware rejected")
                    }
                }))
            }
        }
        getHWAStyle(e) {
            let t;
            switch (e) {
                case "will-change":
                    t = ["will-change", "transform"];
                    break;
                case "transform":
                default:
                    t = ["transform", "translateZ(0px)"]
            }
            return t
        }
        hardwareAcceleratedChanged() {
            (() => {
                const e = this.getHardwareAcceleratedDisplay();
                e && this.updateHardwareAccelerated(this.hardwareAccelerated, e)
            })()
        }
        updateHardwareAccelerated(e, t) {
            const [n, i] = this.getHWAStyle("will-change");
            let r;
            r = e ? i : "", r = r.trim(), r ? t.style.setProperty(n, r) : t.style.removeProperty(n)
        }
        getHardwareAcceleratedDisplay() {
            return this.element
        }
        bound() {
            this.hardwareAcceleratedChanged()
        }
        initClassState() {
            this.value = this.DEFAULT_TRACKER_STATE.value, this.index = this.DEFAULT_TRACKER_STATE.index, this.step = this.DEFAULT_TRACKER_STATE.step, this.fineStep = this.DEFAULT_TRACKER_STATE.fineStep, this.min = this.DEFAULT_TRACKER_STATE.min, this.max = this.DEFAULT_TRACKER_STATE.max, this.discrete = this.DEFAULT_TRACKER_STATE.discrete, this.orientation = this.DEFAULT_TRACKER_STATE.orientation, this.endless = this.DEFAULT_TRACKER_STATE.endless, this.states = this.DEFAULT_TRACKER_STATE.states, this.startPx = this.DEFAULT_TRACKER_STATE.startPx, this.rangePx = this.DEFAULT_TRACKER_STATE.rangePx, this.mousewheelRangePx = this.DEFAULT_TRACKER_STATE.mousewheelRangePx
        }
        createTrackerState({
            trackerState: e
        }) {
            return this.profile.configureTrackerState({
                trackerState: Object.assign(Object.assign({}, h), e)
            })
        }
        overrideGenTrackerState(e) {
            return {}
        }
        genTrackerState({
            trackerState: e
        }) {
            var t, n, i, r, s, o, a, c, l, u, h, d, p, f, g, m;
            const v = null === (t = this.overrideGenTrackerState) || void 0 === t ? void 0 : t.call(this, {
                    trackerState: e
                }),
                b = this;
            return Object.assign({
                value: null !== (n = this.value) && void 0 !== n ? n : this.DEFAULT_TRACKER_STATE.value,
                index: null !== (i = this.index) && void 0 !== i ? i : this.DEFAULT_TRACKER_STATE.index,
                min: null !== (r = this.min) && void 0 !== r ? r : this.DEFAULT_TRACKER_STATE.min,
                max: null !== (s = this.max) && void 0 !== s ? s : this.DEFAULT_TRACKER_STATE.max,
                discrete: null !== (o = this.discrete) && void 0 !== o ? o : this.DEFAULT_TRACKER_STATE.discrete,
                orientation: null !== (a = this.orientation) && void 0 !== a ? a : this.DEFAULT_TRACKER_STATE.orientation,
                endless: null !== (c = this.endless) && void 0 !== c ? c : this.DEFAULT_TRACKER_STATE.endless,
                states: null !== (l = this.states) && void 0 !== l ? l : this.DEFAULT_TRACKER_STATE.states,
                startPx: null !== (u = this.startPx) && void 0 !== u ? u : this.DEFAULT_TRACKER_STATE.startPx,
                rangePx: null !== (h = this.rangePx) && void 0 !== h ? h : this.DEFAULT_TRACKER_STATE.rangePx,
                mousewheelRangePx: null !== (d = this.mousewheelRangePx) && void 0 !== d ? d : this.DEFAULT_TRACKER_STATE.mousewheelRangePx,
                trackpadRangePx: null !== (p = this.trackpadRangePx) && void 0 !== p ? p : this.DEFAULT_TRACKER_STATE.trackpadRangePx,
                offsetPx: null !== (f = this.offsetPx) && void 0 !== f ? f : this.DEFAULT_TRACKER_STATE.offsetPx,
                indicatorJumpToPosition: null !== (g = this.indicatorJumpToPosition) && void 0 !== g ? g : this.DEFAULT_TRACKER_STATE.indicatorJumpToPosition,
                fineTune: null !== (m = this.fineTune) && void 0 !== m ? m : this.profile.isFineTuneEvent(e.event),
                get step() {
                    var e;
                    return null !== (e = b.step) && void 0 !== e ? e : 1 / this.rangePx
                },
                get fineStep() {
                    var e;
                    return null !== (e = b.fineStep) && void 0 !== e ? e : 1 / (4 * this.rangePx)
                },
                get fineTuneScaling() {
                    var e;
                    return null !== (e = b.fineTuneScaling) && void 0 !== e ? e : this.step / this.fineStep
                }
            }, v)
        }
        updateTrackerState({
            trackerState: e
        }) {
            const t = Object.assign(Object.assign({}, this.trackerState), e),
                n = this.genTrackerState({
                    trackerState: t
                });
            this.trackerState = Object.assign(Object.assign({}, t), n)
        }
        createInteraction({
            event: e
        }) {
            var t;
            this.trackerState || (this.trackerState = this.createTrackerState({
                trackerState: {
                    event: e
                }
            }), null === (t = this.handleLifecycle) || void 0 === t || t.call(this, {
                type: "TRACKER_STATE_INIT",
                payload: {
                    event: e
                }
            })), this.handleLifecycle({
                type: "INTERACTION_BEGIN",
                payload: {
                    event: e
                }
            }), this.updateTrackerState({
                trackerState: {
                    event: e
                }
            });
            const n = this.profile.trackInteraction({
                trackerState: this.trackerState
            });
            return this.updateTrackerState({
                trackerState: n.trackerState
            }), n
        }
        handleLifecycle(e) {}
        includesAction({
            action: e,
            state: t
        }) {
            return t.action.includes(e)
        }
        isMouseEventValid(e) {
            return u.h(e) && 0 === e.button
        }
        isTouchEventValid(e) {
            return u.j(e) && e.touches.length < 2
        }
        shouldMiddlewareChainContinue(e) {
            return !this.includesAction({
                action: "DEFAULT",
                state: e
            }) && !this.includesAction({
                action: "EXIT",
                state: e
            })
        }
        publishUANetInteraction(e) {
            const {
                action: t,
                publishState: n
            } = e;
            let i;
            switch (t) {
                case "START":
                    this.isTouching = !0, i = o.g.start;
                    break;
                case "CHANGE":
                    i = o.g.change;
                    break;
                case "END":
                    this.isTouching = !1, i = o.g.end;
                    break;
                case "DEFAULT":
                    i = o.g.default;
                    break;
                case "REVERT":
                    i = o.g.revert;
                    break;
                default:
                    return this.isTouching = !1, void console.warn("UAComponent.publishUANetInteraction: Unsupported config", e)
            }
            const r = [i, n];
            this.ea.publish(...r)
        }
        createUANetInteraction(e) {
            const {
                action: t,
                state: n
            } = e;
            let i = !0;
            const r = Object.assign({}, n);
            switch (t) {
                case "START":
                    this.publishUANetInteraction({
                        action: "START",
                        publishState: r
                    });
                    break;
                case "CHANGE":
                    this.trySetValue(n.value) && this.publishUANetInteraction({
                        action: "CHANGE",
                        publishState: r
                    });
                    break;
                case "REVERT":
                    this.publishUANetInteraction({
                        action: "REVERT",
                        publishState: r
                    });
                    break;
                case "DEFAULT":
                    this.publishUANetInteraction({
                        action: "DEFAULT",
                        publishState: r
                    });
                    break;
                case "END":
                    this.publishUANetInteraction({
                        action: "END",
                        publishState: r
                    });
                    break;
                case "RESET":
                case "NO_OP":
                    break;
                case "EXIT":
                    i = !1;
                    break;
                default:
                    console.warn("UAComponent.createUANetInteraction: Unsupported action", e)
            }
            return r.value !== n.value && (n.value = r.value), i
        }
        generateDownEventListener({
            middleware: e,
            target: t
        }) {
            this.eventListeners.mousedown = this.createEventListenerMiddleware({
                middleware: e
            }), this.eventListeners.touchstart = this.createEventListenerMiddleware({
                middleware: e
            }), t.addEventListener("mousedown", this.eventListeners.mousedown), t.addEventListener("touchstart", this.eventListeners.touchstart, {
                passive: !1
            })
        }
        removeDownEventListener({
            target: e
        }) {
            this.removeEventListenerSafely(e, "mousedown"), this.removeEventListenerSafely(e, "touchstart")
        }
        generateMoveEventListener({
            event: e,
            middleware: t,
            target: n
        }) {
            u.h(e) ? (this.eventListeners.mousemove = this.createEventListenerMiddleware({
                middleware: t
            }), n.addEventListener("mousemove", this.eventListeners.mousemove)) : u.j(e) && (this.eventListeners.touchmove = this.createEventListenerMiddleware({
                middleware: t
            }), n.addEventListener("touchmove", this.eventListeners.touchmove, {
                passive: !1
            }))
        }
        removeMoveEventListener({
            target: e
        }) {
            this.removeEventListenerSafely(e, "mousemove"), this.removeEventListenerSafely(e, "touchmove")
        }
        generateUpEventListener({
            event: e,
            middleware: t,
            target: n
        }) {
            u.h(e) ? (this.eventListeners.mouseup = this.createEventListenerMiddleware({
                middleware: t
            }), n.addEventListener("mouseup", this.eventListeners.mouseup)) : u.j(e) && (this.eventListeners.touchend = this.createEventListenerMiddleware({
                middleware: t
            }), this.eventListeners.touchcancel = this.createEventListenerMiddleware({
                middleware: t
            }), n.addEventListener("touchend", this.eventListeners.touchend), n.addEventListener("touchcancel", this.eventListeners.touchcancel))
        }
        removeUpEventListener({
            target: e
        }) {
            this.removeEventListenerSafely(e, "mouseup"), this.removeEventListenerSafely(e, "touchend"), this.removeEventListenerSafely(e, "touchcancel")
        }
        removeEventListenerSafely(e, t) {
            const n = this.eventListeners[t];
            let i = !1;
            return null != n && (e.removeEventListener(t, n), i = !0), i
        }
        generateMiddlewareState(e) {
            const {
                event: t,
                type: n,
                action: i,
                id: r,
                value: s
            } = e;
            return {
                event: t,
                type: n,
                action: i,
                id: null != r ? r : "GENESIS_STATE",
                value: null != s ? s : this.value
            }
        }
        generateMiddlewareConfig(e) {
            const t = this.generateMiddlewareState(e);
            return {
                state: t,
                snapshots: [t]
            }
        }
        runMiddleware({
            config: e,
            middleware: t
        }) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const n = e => Object.assign(Object.assign({}, e), Array.isArray(e.action) ? {
                    action: e.action.slice(0)
                } : void 0);
                for (const i of t) {
                    const t = n(e.state);
                    let r;
                    delete t.id;
                    try {
                        r = yield i.call(this, e.state.event, {
                            snapshots: e.snapshots,
                            state: t
                        }), Object(c.logSessionStorage)("UAComponent.runMiddleware: " + JSON.stringify({
                            newState: r
                        }))
                    } catch (e) {
                        console.error(e), Object(c.logSessionStorage)("UAComponent.runMiddleware: Middleware rejected a promise"), r = !1
                    }
                    if ("boolean" == typeof r && !1 === r) break;
                    if (e.state = r ? n(Object.assign(Object.assign({}, e.state), r)) : e.state, null == e.state.id && null != i.name && (e.state.id = i.name), e.snapshots.push(e.state), e.state.exitChain) break
                }
                return e
            }))
        }
        handleMiddleware(e) {
            const {
                state: t
            } = e;
            Object(c.logSessionStorage)("UAComponent.handleMiddleware: " + JSON.stringify({
                type: t.type,
                state: t
            })), t.action.every(e => this.createUANetInteraction({
                state: t,
                action: e
            }))
        }
        trySetValue(e) {
            return e !== this.value && (this.setValue(e), !0)
        }
        setValue(e) {
            this.value = e
        }
        static getUANetConfig({
            element: e
        }) {
            const t = s.CustomElement.behaviorFor(e),
                n = null == t ? void 0 : t.viewModel;
            let i;
            return n ? (null == n.uaNet && (n.uaNet = o.c), i = n.uaNet) : i = o.c, i
        }
    }
    Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "interactionHost", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Boolean)], d.prototype, "disabled", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Function)], d.prototype, "interaction", void 0), Object(i.__decorate)([Object(s.bindable)({
        mode: s.BindingMode.twoWay
    }), Object(i.__metadata)("design:type", Object)], d.prototype, "uaNet", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "skinOptions", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Boolean)], d.prototype, "hardwareAccelerated", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "trackerState", void 0), Object(i.__decorate)([Object(s.bindable)({
        mode: s.BindingMode.twoWay
    }), Object(i.__metadata)("design:type", Object)], d.prototype, "value", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "index", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "step", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "fineStep", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "min", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "max", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "discrete", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "orientation", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "endless", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "states", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "startPx", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "rangePx", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "mousewheelRangePx", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "trackpadRangePx", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "indicatorJumpToPosition", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "offsetPx", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "fineTune", void 0), Object(i.__decorate)([Object(s.bindable)(), Object(i.__metadata)("design:type", Object)], d.prototype, "fineTuneScaling", void 0)
});
