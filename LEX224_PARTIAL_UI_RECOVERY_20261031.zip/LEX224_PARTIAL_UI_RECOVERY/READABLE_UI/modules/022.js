// Extracted webpack module 22. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    var i;
    n.d(t, "a", (function() {
            return i
        })),
        function(e) {
            e.default = "default", e.toggle = "toggle", e.drag = "drag"
        }(i || (i = {}))
});
