// Extracted webpack module 24. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return r
    }));
    var i = n(1);
    class r {
        constructor(e, t) {
            this.renderingEngine = e, this.dom = t, this.defaultSkins = new Map, this.namedSkins = new Map
        }
        resolveSkin(e, t = null) {
            return null == e ? this.getDefaultSkin(t) : s(e) ? e : "string" == typeof e ? this.getNamedSkin(e, t) : null
        }
        setDefaultSkin(e, t) {
            if (!s(e)) {
                if (!i.CustomElement.isType(t)) throw new Error("The type must be a custom element.");
                {
                    const n = {
                        name: i.CustomElement.getDefinition(t).name + ":default-skin",
                        needsCompile: !0,
                        template: e
                    };
                    e = this.renderingEngine.getViewFactory(this.dom, n)
                }
            }
            this.defaultSkins.set(t, e)
        }
        addSkin(e, t, n = null) {
            if (null !== n && i.CustomElement.isType(n) && (t = `${i.CustomElement.getDefinition(n).name}:${t}`), !s(e)) {
                const n = {
                    name: t,
                    needsCompile: !0,
                    template: e
                };
                e = this.renderingEngine.getViewFactory(this.dom, n)
            }
            this.namedSkins.set(t, e)
        }
        getNamedSkin(e, t = null) {
            let n;
            return null !== t && i.CustomElement.isType(t) && (n = this.namedSkins.get(`${i.CustomElement.getDefinition(t).name}:${e}`)), n || this.namedSkins.get(e) || null
        }
        getDefaultSkin(e) {
            return null === e ? null : this.defaultSkins.get(e) || null
        }
    }

    function s(e) {
        return "string" != typeof e && "create" in e
    }
    r.inject = [i.IRenderingEngine, i.IDOM]
});
