// Extracted webpack module 82. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return p
        }));
        var i = n(0),
            r = n(1),
            s = n(86),
            o = n(3),
            a = n(4),
            c = n.n(a),
            l = n(8),
            u = n(16),
            h = n(9);
        let d = s;
        o.i && (d = c.a.readFileSync(c.a.resolve(e, "./ua-clip.html"), "utf-8"));
        let p = class extends l.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.value = 0, this.clip = "right", this.meterWidth = 0, this.meterHeight = 0, this.lastMeterPixelValue = -1, this.horizontal = !0
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.element
            }
            binding() {
                "top" != this.clip && "bottom" != this.clip || (this.horizontal = !1), this.update()
            }
            valueChanged(e, t) {
                e != t && this.update()
            }
            update() {
                if (!this.element) return;
                if (this.meterWidth || (this.meterWidth = this.element.offsetWidth, this.meterHeight = this.element.offsetHeight), !this.meterWidth) return;
                let e, t, n, i, r;
                if (e = this.horizontal ? Math.round(this.meterWidth * this.value) : Math.round(this.meterHeight * this.value), e != this.lastMeterPixelValue) {
                    switch (this.lastMeterPixelValue = e, this.clip) {
                        case "top":
                            t = this.meterHeight - e, n = this.meterWidth, i = this.meterHeight, r = 0;
                            break;
                        case "bottom":
                            t = 0, n = this.meterWidth, i = e, r = 0;
                            break;
                        case "left":
                            t = 0, n = this.meterWidth, i = this.meterHeight, r = this.meterWidth - e;
                            break;
                        case "right":
                        default:
                            t = 0, n = e, i = this.meterHeight, r = 0
                    }
                    this.element.style.clip = "rect(" + t + "px " + n + "px " + i + "px " + r + "px)"
                }
            }
        };
        Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Number)], p.prototype, "value", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", String)], p.prototype, "clip", void 0), p = Object(i.__decorate)([o.i ? Object(r.customElement)({
            name: "ua-clip",
            template: d
        }) : Object(r.customElement)(d), Object(i.__metadata)("design:paramtypes", [HTMLElement, u.a, h.a])], p)
    }).call(this, "/")
});
