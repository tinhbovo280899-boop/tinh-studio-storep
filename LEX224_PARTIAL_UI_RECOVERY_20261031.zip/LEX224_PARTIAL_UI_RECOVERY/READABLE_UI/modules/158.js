// Extracted webpack module 158. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "led-display",
        o = '<div ref="numericDisp">\r\n  <div class="numeric"></div>\r\n  <div class="numeric"></div>\r\n  <div class="numeric"></div>\r\n</div>\r\n\r\n<div ref="unitsDisp">\r\n  <div class="led"></div>\r\n  <div class="led"></div>\r\n  <div class="led"></div>\r\n  <div class="led"></div>\r\n</div>\r\n';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\r\n  display: block;\r\n}\r\n\r\n.numeric {\r\n  position: absolute;\r\n  top: 95px;\r\n  width: 25px;\r\n  height: 30px;\r\n  background-image: url('images/UA_Lexicon224_LED-numeric.png');\r\n  background-image: -webkit-image-set(\r\n    url('images/UA_Lexicon224_LED-numeric.png') 1x,\r\n    url('images/@2x/UA_Lexicon224_LED-numeric@2x.png') 2x\r\n  );\r\n  background-image: image-set(\r\n    url('images/UA_Lexicon224_LED-numeric.png') 1x,\r\n    url('images/@2x/UA_Lexicon224_LED-numeric@2x.png') 2x\r\n  );\r\n  display: block;\r\n  background-repeat: no-repeat;\r\n}\r\n\r\n.numeric.decimal {\r\n  background-image: url('images/UA_Lexicon224_LED-numeric-decimal.png');\r\n  background-image: -webkit-image-set(\r\n    url('images/UA_Lexicon224_LED-numeric-decimal.png') 1x,\r\n    url('images/@2x/UA_Lexicon224_LED-numeric-decimal@2x.png') 2x\r\n  );\r\n  background-image: image-set(\r\n    url('images/UA_Lexicon224_LED-numeric-decimal.png') 1x,\r\n    url('images/@2x/UA_Lexicon224_LED-numeric-decimal@2x.png') 2x\r\n  );\r\n}\r\n\r\n.numeric:nth-child(1) { left: 207px; }\r\n.numeric:nth-child(2) { left: 232px; }\r\n.numeric:nth-child(3) { left: 257px; }\r\n\r\n.led {\r\n  position: absolute;\r\n  left: 310px;\r\n  width: 17px;\r\n  height: 17px;\r\n  background-image: url('images/UA_Lexicon224_LED.png');\r\n  background-image: -webkit-image-set(url('images/UA_Lexicon224_LED.png') 1x, url('images/@2x/UA_Lexicon224_LED@2x.png') 2x);\r\n  background-image: image-set(url('images/UA_Lexicon224_LED.png') 1x, url('images/@2x/UA_Lexicon224_LED@2x.png') 2x);\r\n  background-repeat: no-repeat;\r\n}\r\n\r\n.led:nth-child(1) { top: 87px; }\r\n.led:nth-child(2) { top: 97px; }\r\n.led:nth-child(3) { top: 107px; }\r\n.led:nth-child(4) { top: 117px; }\r\n\r\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
