// Extracted webpack module 97. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-toggle-button",
        o = '\x3c!-- BG: HBGF-1335: This component is deprecated: does not use display and click-region pattern --\x3e\n\n<template mousedown.trigger="onMouseDown($event)">\n  <input type="checkbox" checked.bind="value">\n  <div skin-site="value.bind: skin; type.bind: skinType" class="container ${disabled ? \'disabled\' : \'\'}" ref="$display">\n    <div class="background state-${state}"></div>\n    <div class="button state-${state}"></div>\n    <div class="indicator state-${state}"></div>\n  </div>\n</template>\n';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  width: 100%;\n  height: 100%;\n  display: inline-block;\n  /*cursor: pointer;*/\n}\n\n.background::before,\n.toggle::before {\n  \n  position: absolute;\n  display: block;\n  content: ' ';\n  top: calc(-1 * var(--ua-toggle-button-click-region-top, 0px));\n  left: calc(-1 * var(--ua-toggle-button-click-region-left, 0px));\n  bottom: calc(-1 * var(--ua-toggle-button-click-region-bottom, 0px));\n  right: calc(-1 * var(--ua-toggle-button-click-region-right, 0px));\n  border: var(--ua-click-region-border, none);\n  \n}\n\n\ninput {\n  display: none;\n}\n\n.container {\n  display: var(--ua-toggle-button-container-display, block);\n  width: 100%;\n  height: 100%;\n  position: relative;\n  border-radius: var(--ua-toggle-button-radius, 50%);\n  box-shadow: 1px 1px 2px rgba(0, 0, 0, .5);\n}\n\n.disabled {\n  opacity: var(--ua-disabled-opacity, 1.0);\n}\n\n.background {\n  background: var(--ua-toggle-button-background-background, black);\n  border-radius: var(--ua-toggle-button-radius, 50%);\n  width: 100%;\n  height: 100%;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.button {\n  background: var(--ua-toggle-button-button-background, radial-gradient(circle, rgba(33,33,33,1) 0%, rgba(65,57,57,1) 92%));\n  border-radius: var(--ua-toggle-button-radius, 50%);\n  width: 82%;\n  height: 82%;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n  box-shadow: inset 0px 1px 2px rgba(255,255,255,0.25);\n}\n\n.indicator {\n  background: var(--ua-toggle-button-indicator-background, rgb(90, 39, 39));\n  border-radius: var(--ua-toggle-button-radius, 50%);\n  width: 37%;\n  height: 37%;\n  position: absolute;\n  left: 50%;\n  top: 50%;\n  transform: translate(-50%, -50%);\n}\n\n.button.state-1, .button.state-3 {\n  width: 75%;\n  height: 75%;\n}\n\n.indicator.state-1, .indicator.state-3 {\n  width: 34%;\n  height: 34%;\n}\n\n.indicator.state-2, .indicator.state-3 {\n  background: var(--ua-toggle-button-indicator-background-active, rgb(252, 56, 45));\n  box-shadow: 0px 0px 5px var(--ua-toggle-button-indicator-background-active, rgb(252, 56, 45));\n}\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
