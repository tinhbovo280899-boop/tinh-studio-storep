// Extracted webpack module 10. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    var i;
    n.d(t, "a", (function() {
            return i
        })),
        function(e) {
            e.vertical = "vertical", e.horizontal = "horizontal", e.verticalReverse = "vertical-reverse", e.horizontalReverse = "horizontal-reverse", e.both = "both", e.bothReverse = "both-reverse"
        }(i || (i = {}))
});
