// Extracted webpack module 79. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return v
        }));
        var i = n(0),
            r = n(1),
            s = n(17),
            o = n(13),
            a = n(12),
            c = n(97),
            l = n(3),
            u = n(4),
            h = n.n(u),
            d = n(8),
            p = n(9);
        let f = c;
        var g;
        l.i && (f = h.a.readFileSync(h.a.resolve(e, "./ua-toggle-button.html"), "utf-8")),
            function(e) {
                e[e.off = 0] = "off", e[e.offPressed = 1] = "offPressed", e[e.on = 2] = "on", e[e.onPressed = 3] = "onPressed"
            }(g || (g = {}));
        const m = Object.assign(Object.assign({}, d.a), {
            value: !1
        });
        let v = class extends d.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = m, this.state = g.off, this.onMouseUp = e => {
                    this.profile.isRevertEvent(e) || (this.value = this.state === g.offPressed), window.removeEventListener("mouseup", this.onMouseUp), this.publishUANetInteraction({
                        action: "END"
                    })
                }, this.initClassState(), this.disabled = !1
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.$display
            }
            binding() {
                this.updateElement(this.value)
            }
            valueChanged(e, t) {
                e !== t && (this.updateElement(this.value), this.publishUANetInteraction({
                    action: "CHANGE"
                }))
            }
            updateElement(e) {
                this.value ? this.state = g.on : this.state = g.off, Object(a.d)(this.element)
            }
            setUANetValue(e, t) {
                this.value = t > 0
            }
            getUANetValue(e) {
                return this.value ? 1 : 0
            }
            getInteraction() {
                return this
            }
            subscribe(e, t) {
                return this.ea.subscribe(e, t)
            }
            onMouseDown(e) {
                if (!this.disabled) {
                    if (this.profile.isRevertEvent(e)) return this.publishUANetInteraction({
                        action: "REVERT"
                    }), !1;
                    if (this.profile.isDefaultEvent(e)) return this.publishUANetInteraction({
                        action: "DEFAULT"
                    }), !1;
                    window.addEventListener("mouseup", this.onMouseUp), this.publishUANetInteraction({
                        action: "START"
                    }), this.state === g.off ? this.state = g.offPressed : this.state = g.onPressed
                }
            }
        };
        v = Object(i.__decorate)([l.i ? Object(r.customElement)({
            name: "ua-toggle-button",
            template: f
        }) : Object(r.customElement)(f), s.a, Object(i.__metadata)("design:paramtypes", [HTMLElement, o.a, p.a])], v)
    }).call(this, "/")
});
