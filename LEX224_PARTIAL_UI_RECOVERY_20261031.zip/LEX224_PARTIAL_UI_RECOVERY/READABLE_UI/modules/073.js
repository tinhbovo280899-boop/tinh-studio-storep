// Extracted webpack module 73. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return b
        }));
        var i = n(0),
            r = n(1),
            s = n(21),
            o = n(7),
            a = n(13),
            c = n(12),
            l = n(10),
            u = n(90),
            h = n(3),
            d = n(4),
            p = n.n(d),
            f = n(8),
            g = n(9);
        let m = u;
        h.i && (m = p.a.readFileSync(p.a.resolve(e, "./ua-input-number.html"), "utf-8"));
        const v = Object.assign(Object.assign({}, f.a), {
            value: 0,
            step: .05,
            fineStep: 0,
            min: 0,
            max: 1,
            discrete: !0,
            orientation: l.a.vertical,
            states: null
        });
        let b = class extends f.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = v, this.scale = 0, this.signed = !1, this.valueType = s.f.real, this.hasFocus = !1, this.shouldUpdateInput = !0, this.lastDigitSelection = null, this.hideoutline = !1, this.onTouchStart = e => {
                    if (!this.disabled) return this.element.addEventListener("touchmove", this.onTouchMove), this.element.addEventListener("touchend", this.onTouchEnd), this.createInteraction({
                        event: e
                    }), !0
                }, this.onTouchMove = e => {
                    if (e.touches.length > 1) return;
                    const t = this.createInteraction({
                        event: e
                    });
                    if (!t.hasMoved) return;
                    const n = this.getDigitSelection();
                    if (null === n) return;
                    let i = this.getDigitDescription(n.length),
                        r = t.trackerState.value;
                    r < i.min && 0 !== n.startIndex && (r = i.min), r > i.max && 0 !== n.startIndex && (r = i.max);
                    const s = this.$input.value.slice(0, n.startIndex) + r.toString() + this.$input.value.slice(n.endIndex),
                        o = parseFloat(s);
                    n.value = r, n.length = n.value.toString().length, n.endIndex = n.startIndex + n.length, this.updateValue(!0, o), this.$input.setSelectionRange(n.startIndex, n.endIndex)
                }, this.onTouchEnd = e => {
                    window.removeEventListener("touchmove", this.onTouchMove), window.removeEventListener("touchend", this.onTouchEnd)
                }, this.onMouseMove = e => {
                    const t = this.createInteraction({
                        event: e
                    });
                    if (!t.hasMoved) return;
                    const n = this.getDigitSelection();
                    if (null === n) return;
                    let i = this.getDigitDescription(n.length),
                        r = t.trackerState.value;
                    r < i.min && 0 !== n.startIndex && (r = i.min), r > i.max && 0 !== n.startIndex && (r = i.max);
                    const s = this.$input.value.slice(0, n.startIndex) + r.toString() + this.$input.value.slice(n.endIndex),
                        o = parseFloat(s);
                    n.value = r, n.length = n.value.toString().length, n.endIndex = n.startIndex + n.length, this.updateValue(!0, o), this.$input.setSelectionRange(n.startIndex, n.endIndex)
                }, this.onMouseUp = () => {
                    window.removeEventListener("mousemove", this.onMouseMove), window.removeEventListener("mouseup", this.onMouseUp), this.lastDigitSelection = null
                }, this.initClassState(), this.disabled = !1, this.dragging = !1, this.scrolling = !1
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.$input
            }
            computeScrollStepSize(e, t, n, i) {
                let r;
                return r = !this.discrete && this.profile.isFineTuneEvent(e) ? i || t / 500 : n || t / 40, r
            }
            configureFromUANet(e, t, n, i) {
                this.states = i.getRealValues({
                    paramName: t
                }), n.valueType = this.valueType, i.isDiscreteParam(t) ? this.discrete = !0 : this.discrete = !1
            }
            setUANetValue(e, t) {
                this.value = t
            }
            getUANetValue(e) {
                return this.getValidNumber()
            }
            binding() {
                this.valueChanged(this.value), this.stepChanged(this.step)
            }
            valueChanged(e) {
                this.tryUpdateInputControl(e), Object(c.d)(this.element)
            }
            stepChanged(e) {
                0 == this.fineStep && (this.fineStep = e / 20)
            }
            minChanged() {
                this.onConfigChange()
            }
            maxChanged() {
                this.onConfigChange()
            }
            onConfigChange() {
                this.updateValue(!0)
            }
            onKeyDown(e) {
                switch (e.stopPropagation(), e.key) {
                    case "Down":
                    case "ArrowDown":
                        return this.currentStep = this.step, this.stepDown(), !1;
                    case "Up":
                    case "ArrowUp":
                        return this.currentStep = this.step, this.stepUp(), !1;
                    case "Left":
                    case "ArrowLeft":
                        return !0;
                    case "Right":
                    case "ArrowRight":
                        return !0;
                    case ".":
                    case "Decimal": {
                        if (this.scale < 1) return !1;
                        if (this.$input.value.indexOf(".") > -1) return !1;
                        const t = this.getPotentialValue(e.key);
                        return !(t.stringValue.indexOf(".") > -1) || t.stringValue.split(".")[1].length <= this.scale
                    }
                    case "+":
                    case "Add":
                        return !!this.signed && (!(this.$input.value.indexOf("+") > -1) && 0 === this.$input.selectionStart);
                    case "-":
                    case "Subtract":
                        return !!this.signed && (!(this.$input.value.indexOf("-") > -1) && 0 === this.$input.selectionStart);
                    case "Backspace":
                    case "Delete":
                    case "Tab":
                        return !0;
                    case "Enter":
                        return this.hideoutline = !0, !0
                }
                const t = e.keyCode;
                if (t >= 48 && t <= 57 || t >= 96 && t <= 105) {
                    if (e.shiftKey) return !1;
                    const t = this.getPotentialValue(e.key);
                    if (t.numberValue > this.max) return !1;
                    return !(t.stringValue.indexOf(".") > -1) || t.stringValue.split(".")[1].length <= this.scale
                }
                return !1
            }
            onKeyUp(e) {
                switch (e.key) {
                    case ".":
                    case "Decimal":
                    case "+":
                    case "Add":
                    case "-":
                    case "Subtract":
                    case "Backspace":
                    case "Delete":
                        return this.updateValue(!1), !0;
                    case "Enter":
                        return this.updateValue(!0), this.element.blur(), this.hideoutline = !1, !0;
                    case "Tab":
                        return !0
                }
                const t = e.keyCode;
                return (t >= 48 && t <= 57 || t >= 96 && t <= 105) && this.updateValue(!1), !0
            }
            onMouseWheel(e) {
                this.hasFocus = !0;
                const {
                    deltaX: t,
                    deltaY: n
                } = this.profile.getWheelEventDeltas({
                    event: e,
                    isTrackPad: this.profile.isTrackPad(e)
                });
                this.updateTrackerState({
                    trackerState: {
                        event: e,
                        changeX: t,
                        changeY: n
                    }
                });
                const i = this.profile.getMovementFromChange({
                        interactionType: "wheel",
                        orientation: this.orientation,
                        changeX: t,
                        changeY: n
                    }),
                    r = Math.sign(i);
                this.updateTrackerState({
                    trackerState: {
                        event: e,
                        movementPx: 0,
                        totalMovementPx: 0,
                        moveRemainderPx: 0
                    }
                }), 0 != r && (this.currentStep = this.computeScrollStepSize(e, this.max - this.min, this.step, this.fineStep), r < 0 ? this.stepDown() : this.stepUp())
            }
            onBlur() {
                this.updateValue(!0)
            }
            onMouseDownClickRegion(e) {
                this.disabled || (this.hasFocus = !0)
            }
            onMouseDown(e) {
                return this.disabled || (window.addEventListener("mousemove", this.onMouseMove), window.addEventListener("mouseup", this.onMouseUp), this.hasFocus = !0), !1
            }
            getDigitDescription(e) {
                return {
                    min: 0,
                    max: Math.pow(10, e) - 1,
                    step: this.currentStep
                }
            }
            getDigitSelection() {
                if (this.lastDigitSelection) return this.lastDigitSelection;
                const e = this.$input.selectionStart || 0,
                    t = this.$input.selectionEnd || 0;
                if (0 === e && 0 === t) return this.lastDigitSelection;
                const n = this.$input.value.substring(e, t),
                    i = parseFloat(n);
                return Number.isNaN(i) ? null : this.lastDigitSelection = {
                    startIndex: e,
                    endIndex: t,
                    length: t - e,
                    value: i
                }
            }
            stepUp() {
                let e = this.value;
                e += this.currentStep, e > this.max && (e = this.max), this.updateValue(!0, e)
            }
            stepDown() {
                let e = this.value;
                e -= this.currentStep, e < this.min && (e = this.min), this.updateValue(!0, e)
            }
            getPotentialValue(e) {
                const t = this.$input.selectionStart || 0,
                    n = this.$input.selectionEnd || 0,
                    i = this.$input.value.substring(0, t) + e + this.$input.value.substring(n);
                return {
                    stringValue: i,
                    numberValue: parseFloat(i)
                }
            }
            updateValue(e = !1, t) {
                let n = null != t ? t : this.getRawNumber();
                !e && n < this.min || n > this.max || (this.shouldUpdateInput = e, e && (n = null != t ? t : this.getValidNumber()), this.tryUpdateInputControl(n), this.value = n, this.shouldUpdateInput = !0)
            }
            tryUpdateInputControl(e) {
                this.shouldUpdateInput && (this.$input.value = this.getValidNumber(e).toFixed(this.scale))
            }
            getRawNumber() {
                const e = parseFloat(this.$input.value);
                return Number.isNaN(e) ? this.min : e
            }
            getValidNumber(e) {
                const t = null != e ? e.toString() : this.$input.value,
                    n = parseFloat(t);
                return Number.isNaN(n) ? this.min : n > this.max ? this.max : n < this.min ? this.min : Object(o.c)(n, this.scale)
            }
        };
        Object(i.__decorate)([Object(r.bindable)({
            callback: "onConfigChange"
        }), Object(i.__metadata)("design:type", Number)], b.prototype, "scale", void 0), Object(i.__decorate)([Object(r.bindable)({
            callback: "onConfigChange"
        }), Object(i.__metadata)("design:type", Boolean)], b.prototype, "signed", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", String)], b.prototype, "valueType", void 0), b = Object(i.__decorate)([h.i ? Object(r.customElement)({
            name: "ua-input-number",
            template: m
        }) : Object(r.customElement)(m), Object(i.__metadata)("design:paramtypes", [HTMLElement, a.a, g.a])], b)
    }).call(this, "/")
});
