// Extracted webpack module 53. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(0),
        r = n(1),
        s = n(5),
        o = n(6),
        a = n(14),
        c = n(11);
    let l = class {
        constructor(e, t, n) {
            this.element = e, this.audioPlugin = t, this.localValue = null, this.seedStore = {}, this.isBound = !1, this.value = null, this.transform = null, this.automator = n.locateAutomatorFor(e, this)
        }
        bound() {
            this.isBound = !0, this.valueChanged(this.value, null)
        }
        detached() {
            this.isBound = !1, this.cleanupSeedStore()
        }
        injectIDAttribute() {
            void 0 !== this.value && null !== this.value && this.element.setAttribute("ua-test-meter-name", this.value)
        }
        valueChanged(e, t) {
            this.localValue !== e && null != e && this.isBound ? (this.localValue = e, this.cleanupSeedStore(), this.setupSubscriptions(), this.injectIDAttribute()) : null == e && (this.localValue = e, this.cleanupSeedStore())
        }
        setupSubscriptions() {
            const e = this.value,
                t = {
                    selector: "meters",
                    id: e,
                    properties: {
                        level: {}
                    }
                },
                n = this.audioPlugin.registerCallbackListener(Object.assign(Object.assign({}, t), {
                    callback: e => {
                        var t, n, i, r, s, o;
                        const a = null === (n = null === (t = e.values.level) || void 0 === t ? void 0 : t.value) || void 0 === n ? void 0 : n[0],
                            c = null === (i = e.values.level) || void 0 === i ? void 0 : i.wasRequested,
                            l = null === (o = null === (s = null === (r = e.values.level) || void 0 === r ? void 0 : r.message) || void 0 === s ? void 0 : s.parameters) || void 0 === o ? void 0 : o.cmd_tag;
                        !c && this.uaNetRequestMutex && (this.uaNetRequestMutex = void 0), l || "number" != typeof a || this.handleMeterValue(a)
                    }
                }));
            if (n.seed) {
                this.seedStore.value = n, this.seedStore.valueConfig = t;
                const i = {
                        selector: "effect",
                        id: "effect",
                        properties: {
                            plugin_power: {}
                        }
                    },
                    r = this.audioPlugin.registerCallbackListener(Object.assign(Object.assign({}, i), {
                        callback: e => {
                            var t, n;
                            return this.handlePluginPower(null === (n = null === (t = e.values) || void 0 === t ? void 0 : t.plugin_power) || void 0 === n ? void 0 : n.value)
                        }
                    }));
                r.seed ? (this.seedStore.pluginPower = r, this.seedStore.pluginPowerConfig = i) : (console.warn(`ua-meter: encountered an error registering a listener for plugin power for meter id: ${e}.error object: ` + JSON.stringify(r.error)), console.warn(`ua-meter: meter id: '${e}' will continue to function but will not respond to the plugin power dependency.`));
                const s = this.getPluginPowerValue();
                this.handlePluginPower(s, !0)
            } else console.warn(`ua-meter: encountered an error registering a listener for meter id: ${e}.error object: ` + JSON.stringify(n.error)), this.cleanupSeedStore()
        }
        updateValueInComponent(e, t) {
            let n = e;
            if (t) {
                const e = Object(a.D)({
                    wrapperCallback: this.transform,
                    callbackArgs: [{
                        meterValue: n
                    }]
                });
                Object(a.B)(e) && "number" == typeof e.value && (n = e.value)
            }
            this.automator.setValue(s.a, n)
        }
        handlePluginPower(e, t) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const n = this.getShouldCallTransform(e),
                    i = this.getDefaultMeterValue(),
                    r = this.getMeterValue(),
                    s = () => !t && this.getPluginPowerValue(),
                    o = () => s() && this.uaNetRequestMutex;
                let a = !1,
                    c = r;
                if (n)
                    if (s()) {
                        const e = yield this.tryGetUANetMeterValue();
                        o() && "number" == typeof e && (c = e, a = !0, this.uaNetRequestMutex = void 0)
                    } else c = r, a = !0;
                else c = i, a = !0;
                a && this.updateValueInComponent(c, n)
            }))
        }
        handleMeterValue(e) {
            this.getShouldCallTransform() && this.updateValueInComponent(e, !0)
        }
        getDefaultMeterValue() {
            var e, t, n, i, r;
            const s = a.l.getUANetConfig({
                element: this.element
            });
            return null !== (t = null === (e = null == s ? void 0 : s.meter) || void 0 === e ? void 0 : e.defaultMeterValue) && void 0 !== t ? t : null !== (r = null === (i = null === (n = c.c) || void 0 === n ? void 0 : n.meter) || void 0 === i ? void 0 : i.defaultMeterValue) && void 0 !== r ? r : 0
        }
        getPluginPowerValue() {
            return !!this.audioPlugin.getStoreValue({
                selector: "effect",
                id: "effect",
                property: "plugin_power"
            })
        }
        getMeterValue() {
            const e = this.getMeterId();
            if (!e) return console.warn("ua-meter: Seed store registration invalid for id: " + this.value), -1;
            return this.audioPlugin.getStoreValue({
                selector: "meters",
                id: e,
                property: "level"
            })[0]
        }
        tryGetUANetMeterValue() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const e = "ua-meter_" + Math.round(1e8 * Math.random());
                var t;
                if (this.uaNetRequestMutex = e, yield(t = 60, Object(i.__awaiter)(void 0, void 0, void 0, (function*() {
                        return new Promise(e => setTimeout(e, t))
                    }))), this.uaNetRequestMutex) try {
                    const t = yield this.getUANetMeterValue(e);
                    return e === this.uaNetRequestMutex ? t : void 0
                } catch (e) {
                    return
                }
            }))
        }
        getUANetMeterValue(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return new Promise((t, n) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    const i = this.getMeterId();
                    if (!i) return console.warn("ua-meter: Seed store registration invalid for id: " + this.value), n();
                    try {
                        const n = yield this.audioPlugin.getWithReceipt({
                            selector: "meters",
                            id: i,
                            property: "level",
                            params: {
                                cmd_tag: e
                            }
                        });
                        return t(n[0])
                    } catch (e) {
                        return Object(o.isTClientError)(e) ? console.warn(`ua-meter: Encountered an error fetching the value of ${i} from UANet:`, JSON.stringify(e)) : console.warn(`ua-meter: Encountered an error fetching the value of ${i} from UANet`), n()
                    }
                })))
            }))
        }
        getShouldCallTransform(e) {
            var t, n, i;
            const r = a.l.getUANetConfig({
                    element: this.element
                }),
                s = null != e ? e : this.getPluginPowerValue(),
                o = null == (null === (n = null === (t = this.seedStore) || void 0 === t ? void 0 : t.pluginPower) || void 0 === n ? void 0 : n.seed);
            return (null === (i = null == r ? void 0 : r.meter) || void 0 === i ? void 0 : i.ignorePluginPower) || s || o
        }
        getMeterId() {
            const e = this.seedStore.valueConfig;
            if (!e) return;
            const {
                id: t
            } = this.getDescriptorsFromConfig(e);
            return t
        }
        cleanupSeedStore() {
            var e, t, n, i;
            const r = null === (t = null === (e = this.seedStore) || void 0 === e ? void 0 : e.value) || void 0 === t ? void 0 : t.seed,
                s = null === (i = null === (n = this.seedStore) || void 0 === n ? void 0 : n.pluginPower) || void 0 === i ? void 0 : i.seed;
            return !!r && (this.audioPlugin.unregisterCallbackListener({
                seed: r
            }), delete this.seedStore.value, delete this.seedStore.valueConfig, s && (this.audioPlugin.unregisterCallbackListener({
                seed: s
            }), delete this.seedStore.pluginPower, delete this.seedStore.pluginPowerConfig), !0)
        }
        getDescriptorsFromConfig(e) {
            const t = Object.keys(e.properties);
            return {
                selector: e.selector,
                id: e.id,
                property: t[0]
            }
        }
    };
    Object(i.__decorate)([Object(r.bindable)({
        primary: !0
    }), Object(i.__metadata)("design:type", Object)], l.prototype, "value", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], l.prototype, "transform", void 0), l = Object(i.__decorate)([Object(r.customAttribute)("ua-meter"), Object(i.__metadata)("design:paramtypes", [HTMLElement, o.AudioPlugin, s.b])], l);
    var u = n(25),
        h = n(40);
    n.d(t, "UAMeterAttribute", (function() {
        return l
    })), n.d(t, "ComponentAutomator", (function() {
        return u.a
    })), n.d(t, "UAParamAttribute", (function() {
        return h.a
    }))
});
