// Extracted webpack module 81. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return f
        }));
        var i = n(0),
            r = n(1),
            s = n(6),
            o = n(85),
            a = n(3),
            c = n(4),
            l = n.n(c),
            u = n(8),
            h = n(13),
            d = n(9);
        let p = o;
        a.i && (p = l.a.readFileSync(l.a.resolve(e, "./ua-midi-note.html"), "utf-8"));
        let f = class extends u.b {
            constructor(e, t, n, i) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.audioPlugin = i, this.note = 0, this.channel = 0, this.noteOn = !1, this.onMouseDown = e => {
                    const t = this.getMidiElement(e);
                    t && (this.matches(t) && this.sendNoteOn(), window.addEventListener("mousemove", this.onMouseMove), window.addEventListener("mouseup", this.onMouseUp))
                }, this.onMouseMove = e => {
                    const t = this.getMidiElement(e);
                    t && (this.matches(t) ? this.sendNoteOn() : this.noteOn && this.sendNoteOff())
                }, this.onMouseUp = e => {
                    this.sendNoteOff(), window.removeEventListener("mousemove", this.onMouseMove), window.removeEventListener("mouseup", this.onMouseUp)
                }
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.element
            }
            binding() {
                this.updateDOMMidiChannel(this.channel)
            }
            attached() {
                window.addEventListener("mousedown", this.onMouseDown)
            }
            channelChanged(e, t) {
                this.updateDOMMidiChannel(e)
            }
            updateDOMMidiChannel(e) {
                try {
                    this.element.setAttribute("midichannel", e.toString())
                } catch (e) {
                    console.log(e)
                }
            }
            getMidiElement(e) {
                let t = 0;
                const n = e.path || e.composedPath && e.composedPath(),
                    i = n[0];
                return "UA-MIDI-NOTE" === n[0].nodeName && (t = i), t
            }
            matches(e) {
                let t = !1;
                return e.getAttribute("note") == this.note && e.getAttribute("midichannel") == this.channel && (t = !0), t
            }
            sendNoteOn() {
                this.noteOn || (this.audioPlugin.sendMidiMessage(s.MidiMessageType.kNoteOn, this.channel, this.note, 127), this.noteOn = !0)
            }
            sendNoteOff() {
                this.noteOn && (this.audioPlugin.sendMidiMessage(s.MidiMessageType.kNoteOff, this.channel, this.note, 127), this.noteOn = !1)
            }
        };
        Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Number)], f.prototype, "note", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Number)], f.prototype, "channel", void 0), f = Object(i.__decorate)([a.i ? Object(r.customElement)({
            name: "ua-midi-note",
            template: p
        }) : Object(r.customElement)(p), Object(i.__metadata)("design:paramtypes", [HTMLElement, h.a, d.a, s.AudioPlugin])], f)
    }).call(this, "/")
});
