// Extracted webpack module 62. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "b", (function() {
            return w
        })), n.d(t, "a", (function() {
            return k
        }));
        var i, r = n(0),
            s = n(1),
            o = n(26),
            a = n(10),
            c = n(22),
            l = n(19),
            u = n(13),
            h = n(12),
            d = n(88),
            p = n(3),
            f = n(4),
            g = n.n(f),
            m = n(8),
            v = n(9);
        let b = d;
        p.i && (b = g.a.readFileSync(g.a.resolve(e, "./ua-switch.html"), "utf-8"));
        const y = Object.assign(Object.assign({}, m.a), {
            value: !1,
            orientation: a.a.horizontal,
            step: 1,
            fineStep: 1,
            discrete: !0,
            states: [0, 1]
        });
        let w = i = class extends m.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = y, this.mode = c.a.default, this.isActive = !1, this.$inputRange = null, this.$inputCheckbox = null, this.converter = null, this.inTouchGesture = !1, this.onClick = e => {
                    e.preventDefault()
                }, this.onMouseDown = e => {
                    if (!this.disabled) {
                        if (this.profile.isRevertEvent(e)) return this.publishUANetInteraction({
                            action: "REVERT"
                        }), void e.preventDefault();
                        if (this.profile.isDefaultEvent(e)) return this.publishUANetInteraction({
                            action: "DEFAULT"
                        }), void e.preventDefault();
                        e.cancelable && e.preventDefault(), this.publishUANetInteraction({
                            action: "START"
                        }), this.$inputCheckbox && (this.$inputCheckbox.checked = !this.$inputCheckbox.checked, this.$inputCheckbox.dispatchEvent(new Event("change"))), window.addEventListener("mouseup", this.onMouseUp)
                    }
                }, this.onMouseUp = e => {
                    window.removeEventListener("mouseup", this.onMouseUp), this.publishUANetInteraction({
                        action: "END"
                    })
                }, this.tryEndScroll = Object(l.a)(() => {
                    this.scrolling = !1, this.publishUANetInteraction({
                        action: "END"
                    })
                }, 200).fn, this.onMouseWheel = e => {
                    if (this.disabled) return;
                    if (this.mode !== c.a.drag) return;
                    this.converter || (this.converter = new k), e.preventDefault(), this.tryStartScroll();
                    const t = this.createInteraction({
                        event: e
                    });
                    t.hasMoved && (t.trackerState.value - this.value < 0 ? this.$inputRange.stepDown() : this.$inputRange.stepUp()), this.value = this.converter.fromView(this.$inputRange.value, this), this.tryEndScroll()
                }, this.initClassState(), this.disabled = !1, this.dragging = !1, this.scrolling = !1
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.$display
            }
            binding() {
                this.modeChanged(), this.updateElement(this.value), this.fineTuneScaling = this.step / this.fineStep
            }
            valueChanged(e, t) {
                e !== t && (this.updateElement(e), this.publishUANetInteraction({
                    action: "CHANGE"
                }))
            }
            updateElement(e) {
                this.profile.isStatesValid(this.states) || console.warn("ua-switch: invalid states"), this.isActive = !0 === this.value || 1 === this.states.indexOf(this.value), Object(h.d)(this.element)
            }
            modeChanged() {
                this.mode === c.a.default && (this.mode = i.defaultMode)
            }
            attaching() {
                this.$inputRange ? this.$inputRange.addEventListener("wheel", this.onMouseWheel) : this.$inputCheckbox && this.$inputCheckbox.addEventListener("click", this.onClick);
                (this.$inputCheckbox || this.$inputRange).addEventListener("mousedown", this.onMouseDown)
            }
            attached() {
                if (this.$inputRange && -1 !== this.orientation.indexOf("vertical")) {
                    const e = window.getComputedStyle(this.element),
                        t = e.width,
                        n = e.height;
                    this.$inputRange.style.width = n, this.$inputRange.style.height = t, this.$inputRange.style.left = `calc( ((${n} / 2) - (${t} / 2)) * -1 )`, this.$inputRange.style.top = `calc( ((${t} / 2) - (${n} / 2)) * -1)`
                }
            }
            detaching() {
                this.$inputRange ? this.$inputRange.removeEventListener("wheel", this.onMouseWheel) : this.$inputCheckbox && this.$inputCheckbox.removeEventListener("click", this.onClick);
                (this.$inputCheckbox || this.$inputRange).removeEventListener("mousedown", this.onMouseDown)
            }
            overrideGenTrackerState(e) {
                return {
                    orientation: -1 !== this.orientation.indexOf("reverse") ? a.a.bothReverse : a.a.both
                }
            }
            getInteraction() {
                return this
            }
            subscribe(e, t) {
                return this.ea.subscribe(e, t)
            }
            tryStartScroll() {
                this.scrolling || (this.scrolling = !0, this.publishUANetInteraction({
                    action: "START"
                }))
            }
        };
        w.defaultMode = c.a.toggle, Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], w.prototype, "mode", void 0), w = i = Object(r.__decorate)([p.i ? Object(s.customElement)({
            name: "ua-switch",
            template: b
        }) : Object(s.customElement)(b), o.e, Object(r.__metadata)("design:paramtypes", [HTMLElement, u.a, v.a])], w);
        let k = class {
            toView(e, t) {
                if (t.mode === c.a.toggle && t.states.length < 3) {
                    if ("boolean" == typeof e) return e;
                    if ("string" == typeof e) {
                        if ("true" === e) return !0;
                        if ("false" === e) return !1;
                        let n = t.states.indexOf(e);
                        if (0 === n) return !1;
                        if (1 === n) return !0;
                        const i = parseFloat(e);
                        return n = t.states.indexOf(i), 0 !== n && (1 === n || i > 0)
                    }
                    return e > 0
                } {
                    if ("boolean" == typeof e) return e ? 1 : 0;
                    if ("string" == typeof e) {
                        if ("true" === e) return 1;
                        if ("false" === e) return 0;
                        let n = t.states.indexOf(e);
                        if (-1 !== n) return n;
                        const i = parseFloat(e);
                        return n = t.states.indexOf(i), -1 === n ? i : n
                    }
                    let n = t.states.indexOf(e);
                    return -1 === n ? e : n
                }
            }
            fromView(e, t) {
                return t.mode === c.a.toggle && t.states.length < 3 ? e ? t.states[1] : t.states[0] : e < 0 || e > t.states.length - 1 ? e : t.states[e]
            }
        };
        k = Object(r.__decorate)([Object(s.valueConverter)("switchValueConverter")], k)
    }).call(this, "/")
});
