// Extracted webpack module 27. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return f
        }));
        var i, r = n(0),
            s = n(1),
            o = n(91),
            a = n(3),
            c = n(4),
            l = n.n(c),
            u = n(8),
            h = n(16),
            d = n(9);
        let p = o;
        a.i && (p = l.a.readFileSync(l.a.resolve(e, "./ua-option.html"), "utf-8"));
        let f = i = class extends u.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.options = [], this.selectable = !0, this.selected = !1, this.addUpEventListener = (e, {
                    state: t
                }) => {
                    t.id = "addUpEventListener";
                    const n = [this.validateEvent, this.onUpEvent, this.removeMoveAndUpListener];
                    return this.generateUpEventListener({
                        event: e,
                        middleware: n,
                        target: window
                    }), t
                }
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.containerRef
            }
            attached() {
                const e = [this.validateEvent, this.addUpEventListener];
                this.generateDownEventListener({
                    middleware: e,
                    target: this.containerRef
                })
            }
            detached() {
                this.removeDownEventListener({
                    target: this.containerRef
                })
            }
            setOwner(e) {
                this.owner = e, this.optionsChanged()
            }
            select() {
                return Object(r.__awaiter)(this, void 0, void 0, (function*() {
                    this.selectable && (yield this.owner.select(this))
                }))
            }
            optionsChanged() {
                this.options.forEach(e => e.setOwner(this.owner)), this.selectable = this.options.length < 1
            }
            onUpEvent(e, {
                state: t
            }) {
                return Object(r.__awaiter)(this, void 0, void 0, (function*() {
                    return t.id = "onUpEvent", this.shouldMiddlewareChainContinue(t) && this.isOptionHit(e) && (yield this.select()), t
                }))
            }
            isOptionHit(e) {
                return e.composedPath().includes(this.element)
            }
        };
        Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Object)], f.prototype, "value", void 0), Object(r.__decorate)([Object(s.children)({
            filter: (e, t, n) => n instanceof i
        }), Object(r.__metadata)("design:type", Array)], f.prototype, "options", void 0), f = i = Object(r.__decorate)([a.i ? Object(s.customElement)({
            name: "ua-option",
            template: p
        }) : Object(s.customElement)(p), Object(r.__metadata)("design:paramtypes", [HTMLElement, h.a, d.a])], f)
    }).call(this, "/")
});
