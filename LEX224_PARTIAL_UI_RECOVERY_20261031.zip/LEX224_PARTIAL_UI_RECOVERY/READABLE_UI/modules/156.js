// Extracted webpack module 156. Requires the original bundle runtime.
module.exports = (function(e) {
    e.exports = JSON.parse('{"name":"Lexicon 224 Digital Reverb","icon":"images/icon.png","loading_image":"images/@2x/lexicon224_blurred@2x.png","window":{"width":381,"height":621},"appearance":{"colors":{"window-background":"66,63,55","scrollbar-thumbnail":"66,63,55","list-selection":"66,63,55","text-link":"242,231,203","text-selection":"242,231,203","button-primary":"97,93,80","button-secondary":"64,61,53"}}}')
});
