// Extracted webpack module 29. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return a
    }));
    var i = n(0),
        r = n(3),
        s = n(12),
        o = n(11);
    class a {
        constructor(e, t, n) {
            this.au = e, this.uaLog = t, this.guiManifest = n, this.foundElements = [], this.curMousePositionStr = "Position:", this.enabled = !1
        }
        init() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                if (this.enabled) return !0;
                const e = yield this.fetchDevFeatures();
                return e ? (this.uaLog.log("debug", "Detected dev feature configuration. Loading dev features"), this.devFeatures = e, this.devFeaturesState = this.parseDevFeatureState(this.devFeatures), this.enabled = !0, this.setupGlobalHandler(), this.handleDevFeatures(), !0) : (this.enabled = !1, this.uaLog.log("debug", "Did not detect dev feature configuration. Dev features are disabled"), !1)
            }))
        }
        fetchDevFeatures() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                let e, t = this.guiManifest.hbgf_dev_features;
                if (e = "GUI manifest sync", !t) {
                    const n = yield Object(r.a)(o.e.guiManifestJson);
                    if (t = null == n ? void 0 : n.hbgf_dev_features, e = "GUI manifest async", !t) {
                        const n = yield Object(r.a)(o.e.hbgfDevFeaturesJson);
                        t = null == n ? void 0 : n.hbgf_dev_features, e = "HBGF dev features file"
                    }
                }
                return t ? this.uaLog.log("debug", "Fetched Dev features from source: " + e) : this.uaLog.log("debug", "Could not fetch dev features"), t
            }))
        }
        setupGlobalHandler() {
            const e = window;
            this.removeGlobalHandler(), e.hbgf_dev_features = this.handleDevFeatures.bind(this)
        }
        removeGlobalHandler() {
            const e = window;
            return "hbgf_dev_features" in e && "function" == typeof e.hbgf_dev_features && (delete e.hbgf_dev_features, !0)
        }
        getRootNode() {
            try {
                return this.au.root.host
            } catch (e) {
                return
            }
        }
        getRootViewModel() {
            try {
                return this.au.root.viewModel
            } catch (e) {
                return
            }
        }
        getDevFeatureArray() {
            return Object.entries(this.devFeaturesState).map(([e, t]) => e)
        }
        parseDevFeatureState(e) {
            let t = {};
            return Object.entries(e).forEach(([e, n]) => {
                t[e] = n.initial_value
            }), t
        }
        handleDevFeature(e) {
            var t;
            const n = this.devFeaturesState[e];
            if (this[e]) try {
                if (null === (t = null == this ? void 0 : this[e]) || void 0 === t ? void 0 : t.call(this, n)) return this.uaLog.log("debug", `HBGF Dev Feature: "${e}" set to value: ${n}`), !0
            } catch (e) {} else this.uaLog.log("debug", `HBGF Dev Feature: "${e}" is invalid`);
            return !1
        }
        handleDevFeatures(...e) {
            const t = 0 === e.length,
                n = this.getDevFeatureArray();
            (t ? n : e).forEach(e => {
                t || (this.devFeaturesState[e] = !this.devFeaturesState[e]), this.handleDevFeature(e)
            })
        }
        findElements(e, t) {
            var n;
            const i = null !== (n = e.shadowRoot) && void 0 !== n ? n : e;
            if (!(i instanceof Text || i instanceof Comment || 0 === i.children.length)) {
                const e = i.querySelectorAll(t);
                this.foundElements.push(...Array.from(e)), i.childNodes.forEach(e => this.findElements(e, t))
            }
        }
        component_click_regions(e) {
            const t = {
                    border: "1px solid rgba(47,139,87,1)",
                    "background-color": "rgba(47,139,87,0.25)"
                },
                n = Object.entries({
                    "--ua-click-region-border": "1px solid rgba(255,255,255,1)",
                    "--ua-click-region-background": "rgba(255,255,255,0.25)",
                    "--ua-click-region-alternate-background": "rgba(255,255,255,0.5)"
                }),
                i = this.getRootNode();
            return !!i && (e ? (this.foundElements = [], this.findElements(i, ".ua-click-region-tag"), n.forEach(([e, t]) => i.style.setProperty(e, t)), this.foundElements.forEach(e => {
                var n;
                if ((null !== (n = e.shadowRoot) && void 0 !== n ? n : e).querySelector("#ua-click-region-overlay")) return;
                const i = e.getBoundingClientRect(),
                    {
                        width: r,
                        height: s
                    } = i,
                    o = e instanceof SVGElement,
                    a = document.createElement("div");
                if (o) this.uaLog.log("debug", "Dev feature: enable_click_regions: SVG is unsupported");
                else {
                    Object.entries(t).forEach(([e, t]) => a.style[e] = t), a.style.top = "0px", a.style.left = "0px", a.style.width = r + "px", a.style.height = s + "px"
                }
                if (a.id = "ua-click-region-overlay", a.style.pointerEvents = "none", a.style.position = "absolute", !o) {
                    const t = getComputedStyle(e);
                    "" !== t.position && "static" !== t.position || (a.setAttribute("ua-parent-position", t.position), e.style.position = "relative")
                }
                e.appendChild(a)
            })) : (n.forEach(([e]) => i.style.removeProperty(e)), this.foundElements.forEach(e => {
                var t, n;
                const i = null !== (n = null === (t = e.shadowRoot) || void 0 === t ? void 0 : t.querySelector("#ua-click-region-overlay")) && void 0 !== n ? n : e.querySelector("#ua-click-region-overlay");
                if (!i) return;
                const r = i.getAttribute("ua-parent-position");
                r && (e.style.position = r), i.remove()
            })), !0)
        }
        graphics_info_overlay(e) {
            const t = e => {
                    let t = this.curMousePositionStr;
                    return e && (t = "Position: ", t += e.clientX + ", " + e.clientY, this.curMousePositionStr = t), t
                },
                n = e => `GUI Scale: ${100*(e=>{e.style.backgroundPositionY="100px";const t=getComputedStyle(e);return parseFloat(t.backgroundPositionY)/100})(e)}%`,
                i = e => {
                    if (this.overlayChild && this.overlayChild.remove(), this.overlay) {
                        this.overlayChild = document.createElement("p"), this.overlayChild.style.margin = "0px", this.overlayChild.style.color = "black", this.overlayChild.appendChild(document.createTextNode("Device pixel ratio: " + window.devicePixelRatio)), this.overlayChild.appendChild(document.createElement("br")), this.overlayChild.appendChild(document.createTextNode("Image scale: " + (window.devicePixelRatio <= 1 ? "1x" : "2x"))), this.overlayChild.appendChild(document.createElement("br")), this.overlayChild.appendChild(document.createTextNode(`Screen: ${window.screen.width} x ${window.screen.height}`)), this.overlayChild.appendChild(document.createElement("br")), this.overlayChild.appendChild(document.createTextNode(n(this.overlay))), this.overlayChild.appendChild(document.createElement("br")), this.overlayChild.appendChild(document.createTextNode(t(e))), this.overlay.appendChild(this.overlayChild);
                        const i = this.overlayChild.getBoundingClientRect();
                        this.overlay.style.width = i.width + "px", this.overlay.style.height = i.height + "px"
                    }
                };
            if (e) this.overlay = document.createElement("div"), this.overlay.id = "ua-display-image-scale-info", this.overlay.style.position = "absolute", this.overlay.style.top = "0px", this.overlay.style.left = "0px", this.overlay.style.width = "200px", this.overlay.style.height = "100px", this.overlay.style.opacity = "0.80", this.overlay.style.backgroundColor = "white", this.overlay.style.pointerEvents = "none", this.overlayChild = document.createElement("p"), document.body.appendChild(this.overlay), document.addEventListener("mouseover", i), document.addEventListener("mousedown", i), document.addEventListener("mousemove", i), i(), this.displayImageScaleInterval = setInterval(i, 1e3);
            else {
                document.removeEventListener("mouseover", i), document.removeEventListener("mousedown", i), document.removeEventListener("mousemove", i), clearInterval(this.displayImageScaleInterval);
                const e = "#ua-display-image-scale-info",
                    t = document.body.querySelector(e);
                if (!t) return !1;
                t.remove()
            }
            return !0
        }
        browser_context_menu(e) {
            const t = this.getRootNode();
            return !!t && (e ? Object(s.e)(t) : Object(s.b)(t), !0)
        }
    }
});
