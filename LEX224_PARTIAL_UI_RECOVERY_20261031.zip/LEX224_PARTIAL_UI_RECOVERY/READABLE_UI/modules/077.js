// Extracted webpack module 77. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return k
        }));
        var i = n(0),
            r = n(1),
            s = n(5),
            o = n(17),
            a = n(10),
            c = n(13),
            l = n(7),
            u = n(12),
            h = n(95),
            d = n(3),
            p = n(4),
            f = n.n(p),
            g = n(8),
            m = n(54),
            v = n(11),
            b = n(9);
        let y = h;
        d.i && (y = f.a.readFileSync(f.a.resolve(e, "./ua-slider.html"), "utf-8"));
        const w = Object.assign(Object.assign({}, g.a), {
            value: 0,
            min: 0,
            max: 1,
            orientation: a.a.horizontal,
            discrete: !1,
            states: null,
            mousewheelRangePx: 3e3,
            trackpadRangePx: 3e3,
            indicatorJumpToPosition: !1
        });
        let k = class extends m.a {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = w, this.origin = 0, this.$inputRange = null, this.indicatorJumpToPositionDefault = !1, this.calculateDOMDependentProperties = (e, t) => {
                    var n;
                    if (t.state.id = "calculateDOMDependentProperties", "wheel" == e.type) return t.state.action.push("EXIT"), t.state;
                    let i, r = 0,
                        s = 0;
                    if (this.$inputRange) {
                        const t = this.$inputRange.getBoundingClientRect();
                        if (t.width > 0 && t.height > 0) {
                            r = this.profile.isHorizontal(this.orientation) ? t.width : t.height, s = this.profile.isHorizontal(this.orientation) ? t.left : t.top;
                            const o = null !== (n = this.$inputRange.getElementsByClassName("click-region-indicator")[0]) && void 0 !== n ? n : null;
                            let a, c = 0,
                                l = 0;
                            if (o) {
                                const e = o.getBoundingClientRect();
                                c = Math.floor(this.profile.isHorizontal(this.orientation) ? e.left : e.top), l = Math.floor(this.profile.isHorizontal(this.orientation) ? e.width : e.height)
                            }
                            if (1 != this.indicatorJumpToPosition && ("mousedown" == e.type ? a = this.profile.isHorizontal(this.orientation) ? e.clientX : e.clientY : "touchstart" == e.type && (a = this.profile.isHorizontal(this.orientation) ? e.targetTouches[0].clientX : e.targetTouches[0].clientY), null != a && a >= c && a <= c + l)) {
                                const e = a - (c + Math.floor(l / 2));
                                i = null != this.measuredOffsetPx ? Math.abs(e - this.measuredOffsetPx) > 1 ? e : this.measuredOffsetPx : e
                            }
                        }
                    }
                    return this.measuredOffsetPx = i, t.state
                }, this.initClassState(), this.disabled = !1, this.dragging = !1, this.scrolling = !1
            }
            hardwareAcceleratedChanged() {
                this.skin || super.hardwareAcceleratedChanged()
            }
            getHardwareAcceleratedDisplay() {
                return this.$display
            }
            binding() {
                this.updateIndex()
            }
            attaching() {
                super.attaching()
            }
            detaching() {
                super.detaching()
            }
            overrideGenTrackerState(e) {
                var t, n;
                if ("boolean" != typeof this.indicatorJumpToPosition && (this.indicatorJumpToPosition = !!this.discrete), "number" != typeof this.trackpadRangePx) {
                    const e = 120;
                    this.trackpadRangePx = this.discrete ? this.max * e : w.trackpadRangePx
                }
                "number" != typeof this.mousewheelRangePx && (this.mousewheelRangePx = w.mousewheelRangePx);
                const i = null !== (t = this.measuredOffsetPx) && void 0 !== t ? t : 0;
                return {
                    offsetPx: null !== (n = this.offsetPx) && void 0 !== n ? n : this.indicatorJumpToPosition ? 0 : i,
                    indicatorJumpToPosition: this.indicatorJumpToPosition,
                    trackpadRangePx: this.trackpadRangePx,
                    mousewheelRangePx: this.mousewheelRangePx
                }
            }
            calculateLayoutProperties() {
                var e;
                if (this.$inputRange) {
                    const t = this.$inputRange.getBoundingClientRect();
                    if (t.width > 0 && t.height > 0) {
                        let n = 0,
                            i = 0,
                            r = 0;
                        const s = null !== (e = this.$inputRange.getElementsByClassName("click-region-indicator")[0]) && void 0 !== e ? e : null;
                        n = this.profile.isHorizontal(this.orientation) ? t.width : t.height, i = this.profile.isHorizontal(this.orientation) ? t.left : t.top, r = this.profile.isHorizontal(this.orientation) ? s ? s.clientWidth : 0 : s ? s.clientHeight : 0;
                        return {
                            startPx: i + Math.floor(r / 2),
                            rangePx: n - r
                        }
                    }
                    console.warn("ua-slider: rect bounds are 0. cannot calculate startPx and rangePx")
                } else console.warn("ua-slider: refs are undefined. cannot calculate startPx and rangePx")
            }
            setLayoutProperties() {
                const e = this.calculateLayoutProperties();
                e && (this.startPx = e.startPx, this.rangePx = e.rangePx)
            }
            handleLifecycle({
                type: e,
                payload: t
            }) {
                const n = Object(v.h)(t.event.type);
                switch (e) {
                    case "TRACKER_STATE_INIT":
                        "down" !== n && this.setLayoutProperties();
                        break;
                    case "INTERACTION_BEGIN":
                        "down" === n && this.setLayoutProperties()
                }
            }
            getInteraction() {
                return this
            }
            subscribe(e, t) {
                return this.ea.subscribe(e, t)
            }
            configureFromUANet(e, t, n, i) {
                this.states = i.getRealValues({
                    paramName: t
                }), i.isDiscreteParam(t) ? (this.min = 0, this.max = i.numStepsParam(t) - 1, n.valueType = s.c.real, this.discrete = !0) : (this.min = 0, this.max = 1, n.valueType = s.c.normalized, this.discrete = !1), this.updateIndex()
            }
            setUANetValue(e, t) {
                this.setValue(t)
            }
            getUANetValue(e) {
                return this.value
            }
            setValue(e) {
                Number.isNaN(e) ? console.warn("ua-slider setValue encountered a NaN") : e !== this.value && (this.value = e)
            }
            computeValueFromInteraction({
                trackerState: e
            }) {
                let t;
                return t = "mousedown" != e.event.type && "touchstart" != e.event.type || this.indicatorJumpToPosition || null == this.measuredOffsetPx ? this.discrete ? e.value : Object(l.a)(e.value, this.min, this.max) : this.value, t
            }
            updateIndex() {
                let e = this.index;
                e = Array.isArray(this.states) && this.states.length > 0 ? this.profile.getIndexFromRealValue({
                    value: this.value,
                    states: this.states,
                    curIndex: this.index
                }) : this.value, -1 === e ? console.warn("index cannot be determined from real value ") : this.index = e, this.updateElement()
            }
            valueChanged(e, t) {
                this.updateIndex()
            }
            updateElement() {
                const e = this.index / (this.max - this.min);
                this.indicatorLeft = 100 * e, 0 === this.origin ? (this.lowLeft = 0, this.lowRight = 100 - this.indicatorLeft, this.highLeft = this.indicatorLeft, this.highRight = 0) : 1 === this.origin ? (this.lowLeft = this.indicatorLeft, this.lowRight = 0, this.highLeft = 0, this.highRight = 100 - this.indicatorLeft) : e < this.origin ? (this.lowLeft = this.indicatorLeft, this.lowRight = 100 - 100 * this.origin, this.highLeft = 0, this.highRight = 100) : (this.lowLeft = 0, this.lowRight = 100, this.highLeft = 100 * this.origin, this.highRight = 100 - this.indicatorLeft), Object(u.d)(this.element)
            }
        };
        Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Number)], k.prototype, "origin", void 0), k = Object(i.__decorate)([d.i ? Object(r.customElement)({
            name: "ua-slider",
            template: y
        }) : Object(r.customElement)(y), o.a, Object(i.__metadata)("design:paramtypes", [HTMLElement, c.a, b.a])], k)
    }).call(this, "/")
});
