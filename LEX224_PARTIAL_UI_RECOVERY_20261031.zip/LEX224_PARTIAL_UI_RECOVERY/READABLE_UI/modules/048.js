// Extracted webpack module 48. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";

    function i(e) {
        const t = [e.imageName];
        return e.shadow && t.push(`${e.imageName}${e.shadow.imageNameSuffix||"_S"}`), e.hoverImageName && t.push(e.hoverImageName), t
    }
    n.d(t, "a", (function() {
        return i
    }))
});
