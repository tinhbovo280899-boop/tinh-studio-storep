// Extracted webpack module 89. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-knob",
        o = '<template class="${disabled ? \'disabled\' : \'\'}">\n\n  \x3c!-- Container --\x3e\n  <div class="container">\n\n    \x3c!-- BG: HBGF-1335: Prevent implicit compositing by placing "static" click region underneath composited display --\x3e\n    \x3c!-- Click Region --\x3e\n    <div\n      class="click-region"\n      linear-interaction="\n        interactionHost.bind: $this;\n        value.two-way: value;\n        min.bind: min;\n        max.bind: max;\n        step.bind: step;\n        fine-step.bind: fineStep;\n        fine-tune.bind: fineTune;\n        fine-tune-scaling.bind: fineTuneScaling;\n        disabled.bind: disabled;\n        discrete.bind: discrete;\n        range-px.bind: rangePx;\n        mousewheel-range-px.bind: mousewheelRangePx;\n        trackpad-range-px.bind: trackpadRangePx;\n        orientation.bind: orientation;\n        endless.bind: endless;\n        states.bind: states;\n        ua-net.two-way: uaNet;\n        interaction.call: interaction()"\n    >\n    </div>\n\n    \x3c!-- Display (CSS or Skin) --\x3e\n    <div \n      class="display"\n      skin-site="value.bind: skin; type.bind: skinType"\n      html-knob="value.bind: index; min.bind: min; max.bind: max; step.bind: step; fineStep.bind: fineStep; options.bind: options; readonly.bind: disabled"\n      ref="$display"\n    >\n    </div>\n\n  </div>\n</template>\n';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  /* Any CSS Properties set in the :host can be overriden by the consumer. */\n  /* The internal component operation should not depend on these in any way */\n  /* These are simply \"nice defaults\" to make it easier for the consumer */\n\n  display: inline-block; /* Best all around default. Allows the element to be displayed between text and other components without introducing a line-break */\n  height: var(--ua-knob-size, 48px); /* Default to match size defined in html-knob-behavior.ts (Knobs with filmstrips override this by setting the component height). */\n  width: var(--ua-knob-size, 48px); /* Default to match size defined in html-knob-behavior.ts (Knobs with filmstrips override this by setting the component width). */\n  pointer-events: none; /* Disable pointer-events on the host (and all child elements because pointer-events is inherited). */\n}\n\n:host(:focus) {\n  outline: none;\n}\n\n:host(.disabled) {\n  opacity: var(--ua-disabled-opacity, 1.0);\n}\n\n/* This container 'protects' the component from the outside world by setting postion: relative */\n.container {\n  position: relative; /* Limit the scope of absolutely positioned child elements, so a child of the relatively positioned element can be absolutely positioned within that block. */\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n\n\n/* Display */\n.display {\n  position: absolute;\n  display: var(--ua-knob-display, block);\n  height: 100%;\n  width: 100%;\n}\n\n\n/* Click Region */\n.click-region {\n  position: absolute;\n  top: var(--ua-knob-click-region-top, 0px);\n  left: var(--ua-knob-click-region-left, 0px);\n  height: var(--ua-knob-click-region-height, 100%);\n  width: var(--ua-knob-click-region-width, 100%);\n  border: var(--ua-click-region-border, none); /* Used for displaying the click region */\n  outline: var(--ua-click-region-outline, none); /* Used for displaying the click region */\n  box-shadow: var(--ua-click-region-box-shadow, none); /* Used for displaying the click region */\n  background: var(--ua-click-region-background, none); /* Used for displaying the click region */\n  border-radius: var(--ua-knob-click-region-border-radius, 0);\n  pointer-events: var(--ua-knob-click-region-pointer-events, auto); /* Turn on pointer events for the click region, but allow the consumer to override if they want a knob without interactions. */\n}")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
