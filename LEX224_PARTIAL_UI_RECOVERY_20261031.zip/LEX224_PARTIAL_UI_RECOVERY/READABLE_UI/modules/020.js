// Extracted webpack module 20. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return a
    }));
    var i = n(0),
        r = n(6),
        s = n(49),
        o = n(3);
    class a {
        constructor(e) {
            this.uaLog = e, this.resourceStore = {
                image: new Map,
                font: new Map
            }, this.resourceQueue = [], this.exhaustResourceQueuePromise = void 0, this.resourceQueueBatchSize = 5, this.resourceLoadMaxRetries = -1, this.resourceLoadRetryDelayMillisec = 10, this.resourceQueueStartDelayMillisec = 0, this.imagePath = "images", this.imageExtension = ".png", this.imageResolutions = [{
                resolution: "1x",
                subdir: "",
                suffix: ""
            }, {
                resolution: "2x",
                subdir: "@2x",
                suffix: "@2x"
            }], this.fontPath = "fonts", this.fontExtension = ".ttf"
        }
        imagePathFromName(e) {
            return `${this.imagePath}/${e}${this.imageExtension}`
        }
        imageSetFromName(e) {
            return this.imageResolutions.map(({
                resolution: t,
                subdir: n,
                suffix: i
            }) => ({
                url: this.imagePath.concat("/", n, n && "/", e, i, this.imageExtension),
                resolution: t
            }))
        }
        loadImageFromName(e) {
            return this.imageSetFromName(e).map(e => this.loadImageFromUrl(e.url, e.resolution))
        }
        fontPathFromName(e) {
            return `${this.fontPath}/${e}${this.fontExtension}`
        }
        loadFontFromName(e) {
            return this.loadFontFromUrl(this.fontPathFromName(e), e)
        }
        loadFontFromUrl(e, t) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return this.loadResource({
                    url: e,
                    type: "font",
                    fontFamily: t
                })
            }))
        }
        loadImageFromUrl(e, t) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return this.loadResource({
                    url: e,
                    type: "image",
                    resolution: t
                })
            }))
        }
        waitForAllReady() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return this.exhaustResourceQueue()
            }))
        }
        loadResource(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const t = e.type,
                    n = e.url;
                if (this.resourceStore[t].has(n)) {
                    return this.resourceStore[t].get(n).promise
                }
                const i = this.createResource(e);
                this.resourceQueue.push(i), this.exhaustResourceQueue();
                return i.promise
            }))
        }
        createResource(e) {
            let t;
            return t = (e => {
                if ("object" != typeof e) return !1;
                const t = e.url;
                return "string" == typeof e.fontFamily && "string" == typeof t
            })(e) ? this.createFontResourceEntry(e) : this.createImageResourceEntry(e), this.initResourceEntry(t), t
        }
        createFontResourceEntry({
            url: e,
            fontFamily: t
        }) {
            const n = {
                type: "font",
                url: e,
                ready: !1,
                resource: new s.a,
                fontFamily: t,
                retries: 0
            };
            return n.resource.fontFamily = n.fontFamily, this.resourceStore.font.set(n.url, n), n
        }
        createImageResourceEntry({
            url: e,
            resolution: t
        }) {
            const n = {
                type: "image",
                url: e,
                ready: !1,
                resource: new Image,
                resolution: t,
                retries: 0
            };
            return this.resourceStore.image.set(n.url, n), n
        }
        initResourceEntry(e) {
            e.promise = new Promise((t, n) => {
                e.load = () => (this.uaLog.log("debug", "Started loading resource url: " + e.url), e.resource.src = e.url, e.resource.onerror = (...t) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    e.error = 1 === t.length ? new Error(t[0]) : 5 === t.length ? t[4] : new Error("Unknown error");
                    const i = yield this.retryResourceLoad(e);
                    if (this.uaLog.log("debug", `Failed to load resource url: ${e.url}. Retried: ${i}. Retries: ${e.retries}.`), !i) return this.uaLog.log("error", `Failed to load resource url: ${e.url}. Retried: ${i}. Retries: ${e.retries}.`), n(e.error)
                })), e.resource.onload = () => (this.uaLog.log("debug", `Successfully loaded resource url: ${e.url}. Retries: ${e.retries}`), e.ready = !0, t(e.resource)), e.load = void 0, e.promise)
            })
        }
        retryResourceLoad(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return (this.resourceLoadMaxRetries < 0 || e.retries < this.resourceLoadMaxRetries) && (e.retries++, yield Object(o.m)(this.resourceLoadRetryDelayMillisec), e.resource.src = e.url, !0)
            }))
        }
        handleResourceQueue(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const t = e > this.resourceQueue.length ? this.resourceQueue.length : e,
                    n = this.resourceQueue.slice(0, t),
                    i = [];
                n.forEach(e => {
                    var t;
                    const n = null === (t = e.load) || void 0 === t ? void 0 : t.call(e);
                    n && i.push(n)
                });
                const r = yield Promise.allSettled(i);
                return this.resourceQueue.splice(0, t), r
            }))
        }
        exhaustResourceQueue() {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return this.exhaustResourceQueuePromise || (this.exhaustResourceQueuePromise = new Promise((e, t) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    for (yield Object(o.m)(this.resourceQueueStartDelayMillisec); 0 !== this.resourceQueue.length;) yield this.handleResourceQueue(this.resourceQueueBatchSize);
                    return this.exhaustResourceQueuePromise = void 0, e()
                })))), this.exhaustResourceQueuePromise
            }))
        }
    }
    a.inject = [r.UALog]
});
