// Extracted webpack module 151. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    const i = n(0),
        r = n(63),
        s = n(153),
        o = n(154),
        a = n(155),
        c = n(83),
        l = (0, i.__importDefault)(n(156));
    new r.Application({
        root: s.ApplicationRoot,
        includes: [r.DebugConfiguration, a.Skins, o.LEDDisplay, c.ElbertCSSObjectValueConverter, c.CreatorAttribute],
        manifest: l.default
    }).start()
});
