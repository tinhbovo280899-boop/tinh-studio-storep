// Extracted webpack module 80. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return b
        }));
        var i, r = n(0),
            s = n(1),
            o = n(5),
            a = n(17),
            c = n(13),
            l = n(12),
            u = n(98),
            h = n(3),
            d = n(19),
            p = n(4),
            f = n.n(p),
            g = n(8),
            m = n(9);
        ! function(e) {
            e[e.off = 0] = "off", e[e.on = 1] = "on", e[e.offPressed = 2] = "offPressed", e[e.onPressed = 3] = "onPressed"
        }(i || (i = {}));
        let v = u;
        h.i && (v = f.a.readFileSync(f.a.resolve(e, "./ua-button.html"), "utf-8"));
        Object.assign(Object.assign({}, g.a), {
            value: !1
        });
        let b = class extends g.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.mode = "default", this.gesture = "mousedown", this.onValue = 1, this.offValue = 0, this.interaction = () => () => {}, this.cssSkin = "", this.ignoreModifiers = !1, this.state = i.off, this.defaultUANetInteraction = (e, {
                    state: t
                }) => {
                    t.id = "defaultUANetInteraction";
                    let n = this.profile.isDefaultEvent(e);
                    return this.ignoreModifiers || !n || this.includesAction({
                        action: "EXIT",
                        state: t
                    }) || t.action.push("DEFAULT"), t
                }, this.onDownEvent = (e, {
                    state: t
                }) => {
                    if (t.id = "onDownEvent", this.shouldMiddlewareChainContinue(t)) switch (this.mode) {
                        case "momentary":
                            t.value = this.onValue, t.action.push("START", "CHANGE");
                            break;
                        case "toggle":
                            this.state = this.state === i.off ? i.offPressed : i.onPressed, t.action.push("START");
                            break;
                        case "set":
                            "mousedown" == this.gesture ? (t.value = this.onValue, t.action.push("START", "CHANGE")) : t.action.push("START");
                            break;
                        case "set-to-default":
                            "mousedown" == this.gesture ? t.action.push("DEFAULT") : t.action = ["RESET"];
                            break;
                        default:
                            if ("mousedown" == this.gesture) {
                                const e = this.value != this.onValue ? this.onValue : this.offValue;
                                t.value = e, t.action.push("START", "CHANGE")
                            } else this.state = this.state === i.off ? i.on : i.off, t.action.push("START")
                    }
                    return t
                }, this.addMoveEventListener = (e, {
                    state: t
                }) => {
                    t.id = "addMoveEventListener";
                    const n = [this.validateEvent, this.tryInteractionCallback];
                    return this.shouldMiddlewareChainContinue(t) && n.push(this.updateMiddlewareEvent, this.tryInteractionCallback), this.generateMoveEventListener({
                        event: e,
                        middleware: n,
                        target: window
                    }), t
                }, this.addUpEventListener = (e, {
                    state: t
                }) => {
                    t.id = "addUpEventListener";
                    const n = [this.validateEvent],
                        i = this.shouldMiddlewareChainContinue(t);
                    return i && n.push(this.onUpEvent), n.push(this.tryInteractionCallback), i && n.push(this.updateMiddlewareEvent, this.tryInteractionCallback), n.push(this.removeMoveAndUpListener), this.generateUpEventListener({
                        event: e,
                        middleware: n,
                        target: window
                    }), t
                }, this.onUpEvent = (e, {
                    state: t
                }) => {
                    switch (t.id = "onUpEvent", this.mode) {
                        case "momentary":
                            t.value = this.offValue, t.action.push("CHANGE", "END");
                            break;
                        case "toggle":
                            const e = this.value != this.onValue ? this.onValue : this.offValue;
                            t.value = e, t.action.push("CHANGE", "END");
                            break;
                        case "set":
                            "mouseup" == this.gesture ? (t.value = this.onValue, t.action.push("CHANGE", "END")) : t.action.push("END");
                            break;
                        case "set-to-default":
                            "mouseup" == this.gesture ? t.action.push("DEFAULT") : t.action = ["RESET"];
                            break;
                        default:
                            if ("mouseup" == this.gesture) {
                                const e = this.value != this.onValue ? this.onValue : this.offValue;
                                t.value = e, t.action.push("CHANGE", "END")
                            } else t.action.push("END")
                    }
                    return t
                }, this.onMouseOver = (e, {
                    state: t
                }) => (t.id = "onMouseOver", t), this.onMouseOut = (e, {
                    state: t
                }) => (t.id = "onMouseOut", t), this.onMouseWheelStart = (e, {
                    state: t
                }) => (t.type = "wheelstart", t.id = "onMouseWheelStart", t), this.tryWheelStartInteractionCallback = (e, t) => (t.state.type = "wheelstart", t.state.id = "tryWheelStartInteractionCallback", this.scrolling ? t.state : (this.scrolling = !0, this.tryInteractionCallback(e, t))), this.onMouseWheel = (e, {
                    state: t
                }) => (t.type = "wheel", t.id = "onMouseWheel", t), this.fireWheelEndChain = (e, t) => (t.state.id = "fireWheelEndChain", this.wheelDebouncer.fn().then(() => this.eventListeners.wheelend(e)).catch(() => {}), t.state), this.onMouseWheelEnd = (e, {
                    state: t
                }) => (t.type = "wheelend", t.id = "onMouseWheelEnd", this.includesAction({
                    action: "EXIT",
                    state: t
                }) || (this.scrolling = !1), t), this.wheelDebouncer = Object(d.a)(() => {}, 200), this.initClassState(), this.disabled = !1
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.$display
            }
            binding() {
                this.updateElement(this.value)
            }
            attaching() {
                "set-to-default" == this.mode && (this.ignoreModifiers = !0), this.eventListeners.mouseover = this.createEventListenerMiddleware({
                    middleware: [this.onMouseOver, this.tryInteractionCallback]
                }), this.eventListeners.mouseout = this.createEventListenerMiddleware({
                    middleware: [this.onMouseOut, this.tryInteractionCallback]
                }), this.eventListeners.wheel = this.createEventListenerMiddleware({
                    middleware: [this.validateWheelEvent, this.onMouseWheelStart, this.tryWheelStartInteractionCallback, this.onMouseWheel, this.tryInteractionCallback, this.fireWheelEndChain]
                }), this.eventListeners.wheelend = this.createEventListenerMiddleware({
                    middleware: [this.onMouseWheelEnd, this.tryInteractionCallback]
                });
                const e = [this.validateEvent, this.revertUANetInteraction, this.defaultUANetInteraction, this.addMoveEventListener, this.addUpEventListener, this.onDownEvent, this.tryInteractionCallback, this.updateMiddlewareEvent, this.tryInteractionCallback];
                this.generateDownEventListener({
                    middleware: e,
                    target: this.element
                }), this.element.addEventListener("mouseover", this.eventListeners.mouseover), this.element.addEventListener("mouseout", this.eventListeners.mouseout), this.element.addEventListener("wheel", this.eventListeners.wheel)
            }
            detaching() {
                this.removeDownEventListener({
                    target: this.element
                }), this.element.removeEventListener("mouseover", this.eventListeners.mouseover), this.element.removeEventListener("mouseout", this.eventListeners.mouseout), this.element.removeEventListener("wheel", this.eventListeners.wheel)
            }
            configureFromUANet(e, t, n, i) {
                void 0 === this.valueType && (i.isDiscreteParam(t) ? this.valueType = o.c.real : this.valueType = o.c.normalized), n.valueType = this.valueType
            }
            setUANetValue(e, t) {
                this.value = t
            }
            getUANetValue(e) {
                return this.value
            }
            getInteraction() {
                return this
            }
            subscribe(e, t) {
                return this.ea.subscribe(e, t)
            }
            setValue(e) {
                this.value != e && (this.value = e)
            }
            valueChanged(e, t) {
                e !== t && this.updateElement(e)
            }
            updateElement(e) {
                e == this.onValue ? this.state = i.on : this.state = i.off, Object(l.d)(this.element)
            }
        };
        Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], b.prototype, "valueType", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], b.prototype, "mode", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], b.prototype, "gesture", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Number)], b.prototype, "onValue", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Number)], b.prototype, "offValue", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Function)], b.prototype, "interaction", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], b.prototype, "cssSkin", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Object)], b.prototype, "text", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", Boolean)], b.prototype, "ignoreModifiers", void 0), b = Object(r.__decorate)([h.i ? Object(s.customElement)({
            name: "ua-button",
            template: v
        }) : Object(s.customElement)(v), a.a, Object(r.__metadata)("design:paramtypes", [HTMLElement, c.a, m.a])], b)
    }).call(this, "/")
});
