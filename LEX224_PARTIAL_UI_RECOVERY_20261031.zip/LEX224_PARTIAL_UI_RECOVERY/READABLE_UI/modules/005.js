// Extracted webpack module 5. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    var i, r = n(0),
        s = n(1),
        o = n(25);
    class a {
        constructor(e, t) {
            this.element = e, this.observerLocator = t, this.valueType = i.normalized
        }
        configure() {}
        setValue(e, t) {
            this.element[this.getValueProperty(e)] = t
        }
        getValue(e) {
            const t = this.element[this.getValueProperty(e)];
            try {
                return parseFloat(t)
            } catch (e) {
                return console.warn(e), 0
            }
        }
        subscribe(e, t) {
            const n = this.observerLocator.getObserver(0, this.element, this.getValueProperty(e));
            let i = this.getValue(e);
            const r = this,
                s = {
                    handleChange() {
                        const n = r.getValue(e);
                        n !== i && (i = n, t.start({}), t.change({
                            value: n
                        }), t.end({}))
                    }
                };
            return n.subscribe(s), {
                dispose() {
                    n.unsubscribe(s)
                }
            }
        }
        getValueProperty(e) {
            return e
        }
    }
    n.d(t, "c", (function() {
            return i
        })), n.d(t, "a", (function() {
            return c
        })), n.d(t, "e", (function() {
            return l
        })), n.d(t, "f", (function() {
            return u
        })), n.d(t, "d", (function() {
            return h
        })), n.d(t, "b", (function() {
            return d
        })),
        function(e) {
            e.normalized = "normalized", e.string = "string", e.real = "real", e.values = "values", e.name = "name"
        }(i || (i = {}));
    const c = "value";

    function l(e) {
        return "getUANetValue" in e
    }

    function u(e) {
        return "setUANetValue" in e
    }

    function h(e) {
        return "configureFromUANet" in e
    }
    let d = class {
        constructor(e) {
            this.observerLocator = e
        }
        locateAutomatorFor(e, t) {
            const n = s.CustomElement.behaviorFor(e);
            if (n && n.viewModel) {
                const e = n.viewModel;
                return e.$uanet = t,
                    function(e) {
                        return "getUANetAutomator" in e
                    }(e) ? e.getUANetAutomator() : new o.a(n, this.observerLocator)
            }
            return new a(e, this.observerLocator)
        }
    };
    d = Object(r.__decorate)([Object(r.__param)(0, s.IObserverLocator), Object(r.__metadata)("design:paramtypes", [Object])], d)
});
