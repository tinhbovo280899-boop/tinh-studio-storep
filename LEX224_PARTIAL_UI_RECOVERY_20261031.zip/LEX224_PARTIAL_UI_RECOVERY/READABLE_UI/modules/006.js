// Extracted webpack module 6. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(0),
        r = n(43);
    const s = "effects",
        o = "set_control_default_value",
        a = "controls",
        c = parseInt("10010000", 2),
        l = parseInt("10000000", 2);
    var u, h;
    ! function(e) {
        e[e.kNoteOn = 0] = "kNoteOn", e[e.kNoteOff = 1] = "kNoteOff", e[e.kPanic = 2] = "kPanic"
    }(u || (u = {})),
    function(e) {
        e[e.kStatus = 0] = "kStatus", e[e.kData = 1] = "kData"
    }(h || (h = {}));
    const d = ["normalized_value", "string_value", "real_value", "real_values", "string_values", "name", "num_steps", "discrete", "level", "data", "touch_count", "output_stem_format", "preset_name", "preset_uid_dirty", "preset_uid", "plugin_power", "stem_format"],
        p = d.concat(["type", "value"]),
        f = ["value", "read_only", "url_parameters"],
        g = ["heartbeat", "get_base_path_subtree", "get", "set", "post", "subscribe", "unsubscribe"],
        m = e => "meters" === e || "controls" === e || "private_data" === e || "effect" === e,
        v = e => {
            let t = !1;
            if ("object" == typeof e && null !== e) {
                const n = Object.keys(e);
                2 === n.length ? t = "error" in e && "payload" in e : 1 === n.length && (t = "error" in e)
            }
            return t
        };
    let b = 0,
        y = document.title;
    const w = (e, t) => {
            var n;
            if ("1" != r.env.UA_DEBUG && "1" != (null === (n = window) || void 0 === n ? void 0 : n.UA_DEBUG)) return;
            const i = `${e}~Time: ${(new Date).toUTCString()}`;
            console.log(i, String(b)), sessionStorage.setItem(`${i}~Hash: ${Math.random()}`, String(b)), t && (document.title = `${y} - ${t}`), b++
        },
        k = e => {
            if ("/" === e) return e;
            const t = e.split("/");
            return "" === t[t.length - 1] && t.pop(), t.join("/")
        },
        x = (e, t) => {
            const n = new Set(e);
            for (let i of e) t.has(i) && n.delete(i);
            return n
        };

    function _() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
            let t = 16 * Math.random() | 0;
            return ("x" == e ? t : 3 & t | 8).toString(16)
        }))
    }

    function S() {
        return "" + Math.trunc(1e12 * Math.random())
    }

    function O(e) {
        "string" != typeof e && console.warn("not a string:", e)
    }

    function C() {
        return A(Array.from(arguments))
    }

    function A(e) {
        return e.forEach(e => O(e)), e.join("")
    }

    function T(e, t = null) {
        const n = [];
        for (var i in e)
            if (e.hasOwnProperty(i)) {
                const r = t ? t + "[" + i + "]" : i,
                    s = e[i];
                n.push("object" == typeof s ? T(s, r) : encodeURIComponent(r) + "=" + encodeURIComponent(s))
            } return n.join("&")
    }

    function E(e) {
        return "1" === e || "true" === e || ("0" === e || "false" === e || console.warn("defaulting to false in presence of unrecognized bool string " + e), !1)
    }

    function j(e, t, n) {
        const i = function(e) {
            return "object" == typeof e ? e : {
                urlHasPrecedence: !0,
                val: e
            }
        }(n);
        if (i.urlHasPrecedence) {
            const n = function(e) {
                return "string" == typeof e ? [e] : e
            }(t);
            for (const t of n)
                if (e.hasOwnProperty(t)) {
                    const n = decodeURIComponent(e[t]);
                    return "boolean" == typeof i.val ? E(n) : n
                }
        }
        return i.val
    }

    function M(e) {
        const t = e.substr(1).split("&"),
            n = {};
        for (let e in t) {
            const i = t[e].split("=");
            2 === i.length && (n[i[0]] = i[1])
        }
        return n
    }

    function L(e, t = "channel_area_channel") {
        let n = !1;
        if ("channel_area_channel" === t) {
            let t = [!1, !1, !0];
            e < t.length && (n = t[e])
        } else "channel_area_master" === t && (n = !0);
        return n
    }
    var P;
    ! function(e) {
        e[e.closedByUser = 4e3] = "closedByUser", e[e.lostConnection = 4001] = "lostConnection", e[e.closedByConnectionManager = 4002] = "closedByConnectionManager", e[e.reconnectAfterFailure = 4003] = "reconnectAfterFailure", e[e.unknown = 4100] = "unknown"
    }(P || (P = {}));
    const R = g;
    class I {
        constructor(e, t, n, i = []) {
            this.conn = e, this.id = t, this.port = n, this.listeners = [], this.uuid = _(), this.clientErrorListeners = [], this.msgCounter = 0, this.activityShowing = !1;
            const r = {
                open: this.transportOnOpen.bind(this),
                message: this.transportOnMessage.bind(this),
                error: this.transportOnError.bind(this),
                close: this.transportOnClose.bind(this)
            };
            this.dispose = () => {
                this.listeners = [], this.conn.removeListeners(r), this.conn.close("", P.unknown, {
                    client: this.uuid,
                    address: this.id,
                    port: +this.port
                })
            }, this.conn.addListeners(r, {
                client: this.uuid,
                address: t,
                port: +n
            }), this.allowedSelfMessageCommands = [...R, ...i]
        }
        connect() {
            return this.conn.connect({
                client: this.uuid,
                address: this.id,
                port: +this.port
            })
        }
        close(e, t = P.closedByUser) {
            return this.conn.close(e, t, {
                client: this.uuid,
                address: this.id,
                port: +this.port
            })
        }
        addListener(e) {
            this.listeners.push(e)
        }
        removeListener(e) {
            this.listeners = this.listeners.filter(t => t !== e)
        }
        addClientErrorListener(e) {
            this.clientErrorListeners.push(e)
        }
        sendSet(e) {
            const {
                value: t,
                path: n
            } = e;
            let {
                params: i
            } = e;
            i = Object.assign(Object.assign({}, i), {
                cmd_id: "set"
            }), this.sendSocketMsgSet(n, i, t)
        }
        sendHeartbeat() {
            this.sendSocketMsgGet("/status", {
                cmd_id: "heartbeat",
                properties: 0,
                children: 0
            })
        }
        startHeartbeat() {
            this.sendSocketMsgGet("/status", {
                cmd_id: "start_heartbeat",
                properties: 0,
                children: 0
            })
        }
        stopHeartbeat() {
            this.sendSocketMsgGet("/status", {
                cmd_id: "stop_heartbeat",
                properties: 0,
                children: 0
            })
        }
        sendGet(e, t, n, i) {
            let r = {
                flatvalue: 1,
                commands: 0,
                cmd_id: t
            };
            if (r = Object.assign(r, i), n.length > 0) {
                const e = n.join(",");
                r.propfilter = e
            }
            this.sendSocketMsgGet(e, r)
        }
        sendGetRecursive(e, t, n) {
            this.sendGet(e, t, n, {
                recursive: 1
            })
        }
        sendSubscribeWithoutTrailingSeparator(e) {
            this.sendSocketMsgSubscribe(e, {
                cmd_id: "subscribe"
            })
        }
        sendSubscribe(e) {
            this.sendSocketMsgSubscribe(e, {
                cmd_id: "subscribe"
            })
        }
        sendSubscribeRecursive(e, t) {
            const n = {
                recursive: 1,
                cmd_id: t
            };
            this.sendSocketMsgSubscribe(e, n)
        }
        sendSocketMsgGet(e, t) {
            this.sendSocketMsgAction("get", e, t)
        }
        sendSocketMsgSet(e, t, n) {
            this.sendSocketMsgActionWithData("set", e, t, n)
        }
        sendSocketMsgPost(e, t, n) {
            void 0 !== n ? this.sendSocketMsgActionWithData("post", e, t, n) : this.sendSocketMsgAction("post", e, t)
        }
        sendSocketMsgSubscribe(e, t) {
            this.sendSocketMsgAction("subscribe", e, t)
        }
        sendSocketMsgUnsubscribe(e, t) {
            this.sendSocketMsgAction("unsubscribe", e, t)
        }
        sendPost(e, t, n) {
            this.sendSocketMsgPost(e, t, n)
        }
        sendPostWithUid(e, t) {
            const n = {
                client_uid: this.uuid
            };
            Object.assign(n, t), this.sendPost(e, {}, n)
        }
        sendSocketMsgActionWithData(e, t, n, i) {
            this.sendSocketMsgAction(e, t, n, i)
        }
        sendSocketMsgAction(e, t, n, i) {
            const r = Object.assign({}, n, {
                message_id: `${this.uuid}:${this.msgCounter}`
            });
            let s = k(t);
            s ? t = s : console.warn("Client.sendSocketMsgAction: Path is invalid: " + t);
            const o = {
                action: e,
                path: t,
                data: i,
                parameters: r
            };
            this.sendMsg(o)
        }
        sendSocketMessagesAtInterval(e, t, n = 0) {
            n < e.length && (this.sendMsg(e[n]), setTimeout(() => {
                this.sendSocketMessagesAtInterval(e, t, n + 1)
            }, t))
        }
        transportOnOpen(e) {
            this.stopActivity(), this.notifyListeners(e, "client_connected")
        }
        transportOnMessage(e, t) {
            let n = t,
                i = n.parameters;
            i && i.message_id && i.message_id.startsWith && i.message_id.startsWith(this.uuid) && i.cmd_id && !this.isAllowedSelfMessageCommand(i.cmd_id) || this.notifyListeners(e, "client_message", n)
        }
        transportOnError(e) {
            this.notifyListeners(e, "client_error"), console.error("socket error", e)
        }
        transportOnClose(e) {
            this.startActivity(), this.notifyListeners(e, "client_disconnected"), console.warn("socket closing!", e.code)
        }
        transportOnReconnectFailure(e) {}
        startActivity() {
            this.activityShowing || (this.activityShowing = !0)
        }
        stopActivity() {
            this.activityShowing && (this.activityShowing = !1)
        }
        notifyListeners(e, t, n) {
            try {
                for (let i of this.listeners) i(e, t, n)
            } catch (e) {
                console.error(e)
            }
        }
        sendMsg(e) {
            this.conn.sendMessage(e, {
                client: this.uuid,
                address: this.id,
                port: +this.port
            }), this.msgCounter++
        }
        isAllowedSelfMessageCommand(e) {
            return this.allowedSelfMessageCommands.includes(e)
        }
    }
    var D;
    ! function(e) {
        e[e.none = 0] = "none", e[e.received = 1] = "received", e[e.notReceived = 2] = "notReceived"
    }(D || (D = {}));
    class N {
        constructor(e, t = !1, n = "") {
            this.client = e, this.shouldVerify = t, this.status = D.none, this.timeout = null, this.errorMessage = "Heartbeat reply was not received. " + n, this.send()
        }
        received() {
            this.status = D.received
        }
        stop() {
            null != this.timeout && clearTimeout(this.timeout)
        }
        verify() {
            this.status === D.notReceived && (console.warn(this.errorMessage), this.client.close(this.errorMessage))
        }
        send() {
            this.shouldVerify && this.verify(), this.status = D.notReceived, this.client.sendHeartbeat(), this.timeout = setTimeout(() => {
                this.send()
            }, 5e3)
        }
    }
    class V {
        constructor(e, t, n = null, i = null) {
            this.selector = e, this.callback = t, this.id = n, this.type = i
        }
    }
    class $ {
        constructor() {
            this.listeners = {
                open: [],
                message: [],
                close: [],
                error: []
            }
        }
        get open() {
            return this.listeners.open
        }
        get message() {
            return this.listeners.message
        }
        get close() {
            return this.listeners.close
        }
        get error() {
            return this.listeners.error
        }
        add(e) {
            e.open && this.listeners.open.push(e.open), e.message && this.listeners.message.push(e.message), e.close && this.listeners.close.push(e.close), e.error && this.listeners.error.push(e.error)
        }
        remove(e) {
            e.open && this.listeners.open.includes(e.open) && (this.listeners.open = this.listeners.open.filter(t => t !== e.open)), e.message && this.listeners.message.includes(e.message) && (this.listeners.message = this.listeners.message.filter(t => t !== e.message)), e.close && this.listeners.close.includes(e.close) && (this.listeners.close = this.listeners.close.filter(t => t !== e.close)), e.error && this.listeners.error.includes(e.error) && (this.listeners.error = this.listeners.error.filter(t => t !== e.error))
        }
        toString() {
            return JSON.stringify(Object.entries(this.listeners).map(([e, t]) => `${e}: ${t.length}`))
        }
    }

    function F(e) {
        if ("multi" !== e.path) return;
        const t = e.data;
        if (! function(e) {
                if (null == e) return !1;
                if (Array.isArray(e)) return !1;
                const t = e;
                return Array.isArray(t.data) && Array.isArray(t.name) && Array.isArray(t.parent) && Array.isArray(t.path) && Array.isArray(t.string)
            }(t)) return;
        const n = [];
        for (let e = 0; e < t.data.length; e++) {
            const i = B(t, t.path[e]),
                r = t.data[e];
            n.push({
                path: i,
                data: r,
                parameters: {}
            })
        }
        return z("added", t, n), z("removed", t, n), n
    }

    function U(e) {
        const t = F(e);
        return null == t ? Object.assign({}, e) : Object.assign(Object.assign({}, e), {
            multi: t
        })
    }

    function B(e, t) {
        const n = function(e, t) {
                const n = e.name[t];
                return "/" + e.string[n]
            }(e, t),
            i = e.parent[t];
        return i === t ? n : B(e, i) + n
    }

    function z(e, t, n) {
        const i = t[e];
        if (null != i)
            for (const t of i) n[t].operation = e
    }
    const H = new Map([
        ["object", e => JSON.stringify(e)],
        ["string", e => '"' + e + '"'],
        ["number", e => e.toString()],
        ["boolean", e => e.toString()]
    ]);

    function W(e) {
        return function(e, t) {
            const n = e.get(t);
            if (void 0 === n) {
                const n = `key ${t} undefined in map: ${e}`;
                throw console.warn(n), new Error(n)
            }
            return n
        }(H, typeof e)(e)
    }
    const q = {
        encode(e) {
            const t = T(e.parameters),
                n = "" === t ? [] : ["?", t];
            let i = [];
            if (void 0 !== e.data) {
                i = [" ", W(e.data)]
            }
            return A([e.action, " ", e.path].concat(n).concat(i))
        },
        decode(e) {
            try {
                const t = JSON.parse(e),
                    n = function(e) {
                        return function(e) {
                            return null != e && ["get", "set", "post", "subscribe"].includes(e)
                        }(e) ? e : void 0
                    }(t.action);
                if (!t.path) throw `Invalid message, missing "path": "${e}"`;
                return Object.assign(Object.assign({}, t), n && {
                    action: n
                })
            } catch (e) {
                console.error(e)
            }
        }
    };
    class G {
        constructor(e, t = q) {
            this._transport = e, this.format = t, this.transport = "ws", this.isConnected = !1, this.listeners = new $, this.transportOnOpen = e => {
                this.notifyListeners(this.listeners.open, e)
            }, this.transportOnData = (e, t) => {
                let n = this.decode(t);
                if (!n) return void console.warn("Failed to decode message " + t);
                const i = U(n);
                i.multi && (n = i), this.notifyMessageListeners(this.listeners.message, e, n)
            }, this.transportOnError = e => {
                this.notifyListeners(this.listeners.error, e)
            }, this.transportOnClose = e => {
                this.notifyListeners(this.listeners.close, e)
            }, this._transport.addListeners({
                open: this.transportOnOpen,
                close: this.transportOnClose,
                message: this.transportOnData,
                error: this.transportOnError
            })
        }
        addListeners(e) {
            this.listeners.add(e)
        }
        removeListeners(e) {
            this.listeners.remove(e)
        }
        connect(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                try {
                    return yield this._transport.connect(e), this.isConnected = !0, Promise.resolve()
                } catch (e) {
                    return Promise.reject(e)
                }
            }))
        }
        close(e = "", t, n) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                try {
                    return yield this._transport.close(e, t, n), this.isConnected = !1, Promise.resolve()
                } catch (e) {
                    return Promise.reject(e)
                }
            }))
        }
        sendMessage(e, t) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const n = this.format.encode(e);
                this._transport.send(n, t)
            }))
        }
        decode(e) {
            const t = this.format.decode(e);
            if (null != t) return Object.assign(Object.assign({}, t), {
                path: t && t.path || "",
                parameters: t && t.parameters || {}
            })
        }
        notifyListener(e) {
            try {
                e()
            } catch (e) {
                console.error(e)
            }
        }
        notifyMessageListeners(e, t, n) {
            for (let i of e) this.notifyListener(() => {
                i(t, n)
            })
        }
        notifyListeners(e, t) {
            for (let n of e) n(t)
        }
    }
    const K = e => Object(i.__awaiter)(void 0, void 0, void 0, (function*() {
        return new Promise(t => setTimeout(t, e))
    }));
    class Y {
        constructor(e = q) {
            this.format = e, this.name = "ws", this.listeners = new $, this.ip = null, this.port = null, this.socket = null, this.socketResponse = !1, this.numReconnectAttempts = 0, this.closedByUser = !1, this.pendingConnection = !1
        }
        addListeners(e) {
            this.listeners.add(e)
        }
        removeListeners(e) {
            this.listeners.remove(e)
        }
        unregister() {}
        getTimeoutMillisec() {
            let e = 1e3 + 1e3 * this.numReconnectAttempts;
            return e > 1e5 && (e = 1e5), e
        }
        connect({
            address: e,
            port: t,
            skipReconnect: n,
            isReconnect: r
        }) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                return this.ip = e, this.port = t, new Promise((s, o) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                    if (this.pendingConnection) return o(new Error("Cannot reconnect with a pending connection"));
                    if (this.isSocketConnected()) return s();
                    this.pendingConnection = !0, w("WT.connect before: " + JSON.stringify({
                        address: e,
                        port: t,
                        skipReconnect: n,
                        isReconnect: r
                    }));
                    const i = yield this.tryWSConn({
                        isReconnect: r,
                        address: e,
                        port: t
                    });
                    if (w("WT.connect after: " + JSON.stringify({
                            address: e,
                            port: t,
                            skipReconnect: n,
                            isReconnect: r,
                            connected: i
                        })), i) return this.pendingConnection = !1, s();
                    if (n) {
                        const e = new Error("Could not connect to websocket");
                        throw this.pendingConnection = !1, o(e), e
                    }
                    return yield this.reconnectWSConn({
                        address: e,
                        port: t,
                        timeoutMillisec: 500
                    }), this.pendingConnection = !1, s()
                })))
            }))
        }
        close(e = "", t) {
            var n;
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                w("WT.close: " + JSON.stringify({
                    reason: e,
                    code: t
                })), t === P.closedByUser && (this.closedByUser = !0), null === (n = this.socket) || void 0 === n || n.close(t, e)
            }))
        }
        send(e) {
            try {
                this.socket.send(e)
            } catch (t) {
                console.warn("Unable to send socket message: " + e, t)
            }
        }
        socketOnOpen(e) {
            w("WT.socketOnOpen before"), this.numReconnectAttempts = 0, this.socketResponse = !0;
            for (const t of this.listeners.open) t(e)
        }
        socketOnMessage(e) {
            if (this.socketResponse = !0, e.data)
                for (const t of this.listeners.message) t(e, e.data);
            else console.warn("Received message without data " + e)
        }
        socketOnError(e) {
            var t, n, i;
            w("WT.socketOnError before"), this.socketResponse = !0;
            const r = {
                type: "error",
                reason: "",
                code: P.unknown
            };
            for (const e of this.listeners.error) e(r);
            w("WT.socketOnError after. readyState: " + (null === (t = this.socket) || void 0 === t ? void 0 : t.readyState)), "number" == typeof(null === (n = this.socket) || void 0 === n ? void 0 : n.readyState) && 3 !== (null === (i = this.socket) || void 0 === i ? void 0 : i.readyState) || this.socketOnClose(new CloseEvent("close", {
                reason: "Networking process crash suspected.",
                code: P.unknown
            }))
        }
        socketOnClose(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                w(`WT.socketOnClose before: ${JSON.stringify(e)} `), this.socketResponse = !0, this.socket = null;
                for (const t of this.listeners.close) t(e);
                w(`WT.socketOnClose after: ${JSON.stringify(e)} `), this.tryReconnect(e)
            }))
        }
        reconnectWSConn({
            address: e,
            port: t,
            timeoutMillisec: n
        }) {
            return new Promise(r => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                let i = this.isSocketConnected();
                if (i) return r();
                for (w(`WT.reconnectWSConn after: ${JSON.stringify({address:e,port:t,timeoutMillisec:n})} `); !i;) {
                    yield K(n);
                    if (yield this.tryWSConn({
                            isReconnect: !0,
                            address: e,
                            port: t
                        })) {
                        i = !0;
                        break
                    }
                }
                return r()
            })))
        }
        tryWSConn({
            isReconnect: e,
            address: t,
            port: n
        }) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                e && (this.numReconnectAttempts >= Number.MAX_SAFE_INTEGER ? this.numReconnectAttempts = 0 : this.numReconnectAttempts++);
                try {
                    const i = this.getTimeoutMillisec();
                    return w("WT.tryWSConn before: " + JSON.stringify({
                        address: t,
                        port: n,
                        isReconnect: e,
                        timeoutMillisec: i
                    })), yield this.createWSConn({
                        address: t,
                        port: n,
                        timeoutMillisec: i
                    }), w("WT.tryWSConn success: " + JSON.stringify({
                        address: t,
                        port: n,
                        isReconnect: e,
                        timeoutMillisec: i
                    })), Promise.resolve(!0)
                } catch (i) {
                    return w("WT.tryWSConn failure: " + JSON.stringify({
                        address: t,
                        port: n,
                        isReconnect: e,
                        err: i
                    })), Promise.resolve(!1)
                }
            }))
        }
        createWSConn({
            address: e,
            port: t,
            timeoutMillisec: n
        }) {
            return new Promise((i, r) => {
                if (this.isSocketConnected()) return r(new Error("A request to open a websocket connection was made during a valid connection."));
                let s;
                this.socketResponse = !1, this.closedByUser = !1;
                let o = !1,
                    a = !1;
                const c = () => !o && !a && (o = !0, clearTimeout(s), i(), !0),
                    l = e => !o && !a && (a = !0, clearTimeout(s), r(e), !0),
                    u = e => {
                        e.onopen = this.socketOnOpen.bind(this), e.onclose = this.socketOnClose.bind(this), e.onerror = this.socketOnError.bind(this)
                    };
                s = setTimeout(() => {
                    this.isSocketConnected() ? c() : this.close(`Did not receive a response in ${n}. Not reconnecting.`, P.lostConnection)
                }, n), w("WT.createWSConn: " + JSON.stringify({
                    address: e,
                    port: t,
                    timeoutMillisec: n
                }));
                try {
                    this.socket = new WebSocket(`ws://${e}:${t}`), this.socket.onopen = (...e) => {
                        this.socketOnOpen(...e), c() && this.socket && u(this.socket)
                    }, this.socket.onmessage = this.socketOnMessage.bind(this), this.socket.onerror = (...e) => {
                        this.socketOnError(...e), l(new Error("Failed connection. An unknown error ocurred.")) && this.socket && u(this.socket)
                    }, this.socket.onclose = (...e) => {
                        this.socketOnClose(...e), l(new Error("Failed connection. Socket was closed.")) && this.socket && u(this.socket)
                    }
                } catch (e) {
                    l(e)
                }
            })
        }
        tryReconnect(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                if (this.shouldReconnect(e)) try {
                    yield K(500), yield this.connect({
                        address: this.ip,
                        port: this.port,
                        skipReconnect: !1,
                        isReconnect: !0
                    })
                } catch (e) {
                    console.error("Could not reconnect", e)
                }
            }))
        }
        shouldReconnect(e) {
            let t = !0;
            if (this.closedByUser) t = !1;
            else switch (e.code) {
                case P.closedByUser:
                    t = !1;
                    break;
                default:
                    t = !0
            }
            return t && !this.isSocketConnected() && !this.pendingConnection && !0
        }
        isSocketConnected() {
            return !!this.socket && 1 === this.socket.readyState
        }
    }
    class X {
        constructor(e = function() {
            const e = new Y;
            return new G(e)
        }()) {
            this.conn = e, this.getRequestHandlers = [], this.onMixerComplete = null, this.mixerCompleteCalled = !1, this.pendingPaths = new Set, this.requestedPaths = new Set, this.validValueTypes = d, this.uacValues = {}, this.pathStore = {}, this.effectStore = {}, this.commandStore = {
                controls: {},
                effect: {},
                meters: {},
                private_data: {}
            }, this.allowedSelfMessageCommands = [], this.connected = !1, this.setPlugins = !1, this.subscribeToMeters = !1, this.ip = null, this.port = null, this.basePath = null, this.commandValues = {}, this.listeners = {}, this.mVerifyHeartbeat = !1, this.client = null, this.heartbeat = null, this.receiptListeners = {}, this.callbackListeners = {
                controls: {},
                meters: {},
                private_data: {},
                effect: {}
            }, this.callbackListenerSeeds = {}, this.multiCallbackListenerSeeds = {}, this.multiCallbackListenerMutexes = {}
        }
        verifyHeartbeat(e = !0) {
            this.mVerifyHeartbeat = e
        }
        doConnect(e = null, t, n, r, {
            inHardwareOnlyDaemon: s = ""
        } = {}) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                if (this.connected) throw new Error("already connected");
                const i = window.location.search,
                    o = ("undefined" == typeof window || window.location.search, M(i));
                if (this.ip = j(o, ["ip", "host"], t), this.port = j(o, "port", n || "4718"), this.basePath = r || j(o, "path", r), this.setPlugins = j(o, "setplugins", !0), this.subscribeToMeters = j(o, "meters", !0), "" !== s) {
                    const e = "Skipping the rest of _doConnect because daemon is hardware only";
                    if ("localhost" === this.ip) return void console.warn(e);
                    if (!j(o, s, !0)) return void console.warn(e)
                }
                return this.onMixerComplete = e, this.client = new I(this.conn, this.ip, this.port, this.allowedSelfMessageCommands), this.client.addListener(this.clientCallback.bind(this)), this.client.connect()
            }))
        }
        doDisconnect(e, t = P.closedByUser) {
            const {
                client: n,
                heartbeat: i
            } = this;
            null != i && (i.stop(), this.heartbeat = null), null != n && this.connected && n.close(e, t), this.connected = !1
        }
        refreshAllPaths(e = [], t = this.basePath, n = "get_base_path_subtree", i = "subscribe", r = {
            recursive: 1,
            commands: 1
        }) {
            this.client.sendGet(t, n, e, r), this.client.sendSubscribeRecursive(t, i)
        }
        createRequest(e) {
            return new Promise((t, n) => {
                const {
                    request: i,
                    path: r,
                    payload: s
                } = e, o = Object.assign({}, e.params);
                if ("set" === i && void 0 === s) return n({
                    error: "INVALID_UANET_PAYLOAD"
                });
                switch (o.cmd_id && o.cmd_id !== i && console.warn(`MixerBase.createRequest: overriding cmd_id: ${o.cmd_id} in params with ${i}`), o.cmd_id = i, this.createRequestListener({
                        path: r,
                        params: o,
                        resolve: t,
                        reject: n
                    }), i) {
                    case "get":
                        this.client.sendSocketMsgGet(r, o);
                        break;
                    case "set":
                        this.client.sendSocketMsgSet(r, o, s);
                        break;
                    case "post":
                        this.client.sendSocketMsgPost(r, o, s);
                        break;
                    case "subscribe":
                        this.client.sendSocketMsgSubscribe(r, o);
                        break;
                    case "unsubscribe":
                        this.client.sendSocketMsgUnsubscribe(r, o)
                }
            })
        }
        handleRequest(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const {
                    request: t
                } = e;
                try {
                    const e = yield t;
                    return e.error ? {
                        error: "UANET_MESSAGE_ERROR",
                        payload: JSON.parse(JSON.stringify(e))
                    } : void 0 !== e.data ? e.data : {
                        error: "INVALID_UANET_MESSAGE",
                        payload: JSON.parse(JSON.stringify(e))
                    }
                } catch (e) {
                    return v(e) ? e : {
                        error: "UNKNOWN_UANET_REQUEST_ERROR",
                        payload: e
                    }
                }
            }))
        }
        createRequestListener(e) {
            const {
                path: t,
                resolve: n,
                reject: i,
                params: r
            } = e;
            let s = `$PATH:${t}$SEED:${S()}`;
            s in this.receiptListeners && (s = `$PATH:${t}$SEED:${S()}`), r.cmd_listener = s;
            const o = {
                path: t,
                params: r,
                resolve: e => n(e),
                reject: e => i(e)
            };
            return this.receiptListeners[s] = o, s
        }
        removeRequestListener(e) {
            const {
                seed: t
            } = e;
            return !(!t || !(t in this.receiptListeners)) && (delete this.receiptListeners[t], !0)
        }
        handleRequestListener(e) {
            var t;
            const {
                message: n
            } = e, i = null === (t = n.parameters) || void 0 === t ? void 0 : t.cmd_listener;
            if (null == i) return !1;
            const r = this.receiptListeners[i];
            return !!r && (r.path === n.path && r.params.cmd_listener === i ? r.resolve(n) : r.reject({
                error: "MISMATCHED_UANET_REQUEST",
                payload: JSON.parse(JSON.stringify(n))
            }), this.removeRequestListener({
                seed: i
            }), !0)
        }
        postTouch(e, t) {
            if (e in this.uacValues) {
                this.uacValues[e].postTouch(t)
            }
        }
        postSetDefaultValue(e) {
            if (e in this.uacValues) {
                this.uacValues[e].postSetDefaultValue()
            }
        }
        clientConnected() {
            this.connected || (this.connected = !0, null == this.heartbeat && (this.heartbeat = new N(this.client, this.mVerifyHeartbeat, `${this.ip}:${this.port}`)), this.refreshAllPaths())
        }
        notifyClientListeners(e) {
            if (!("client" in this.listeners)) return;
            const t = this.listeners.client;
            for (let n of t) n.callback(e)
        }
        heartbeatReceived() {
            null != this.heartbeat && this.heartbeat.received()
        }
        startRouterdHeartbeat() {
            var e;
            null === (e = this.client) || void 0 === e || e.startHeartbeat()
        }
        stopRouterdHeartbeat() {
            var e;
            null === (e = this.client) || void 0 === e || e.stopHeartbeat()
        }
        signOfLifeReceived() {
            this.heartbeatReceived()
        }
        clientCallback(e, t, n) {
            let i = !1;
            switch (t) {
                case "client_connected":
                    this.clientConnected(), i = !0;
                    break;
                case "client_error":
                    i = !0;
                    break;
                case "client_disconnected":
                    const t = e.reason || "",
                        r = e.code || P.unknown;
                    this.doDisconnect(t, r), i = !0;
                    break;
                case "client_message":
                    let s;
                    if (n && n.multi) s = n.multi;
                    else {
                        if (!n) break;
                        s = [n]
                    }
                    for (const t of s) this.clientMessage(e, t);
                    const o = this.parseMultiMessage({
                        multi: s
                    });
                    for (const e of s) this.updateListeners({
                        message: e,
                        multiMessageData: o
                    });
                    this.handleMultiCallbackListeners()
            }
            i && this.notifyClientListeners(e)
        }
        clientMessage(e, t) {
            var n, i, r;
            this.signOfLifeReceived();
            let s = !0;
            if (t.error && console.warn(t.error, t), void 0 !== (null === (n = null == t ? void 0 : t.parameters) || void 0 === n ? void 0 : n.cmd_id) && null !== (null === (i = null == t ? void 0 : t.parameters) || void 0 === i ? void 0 : i.cmd_id)) switch (null === (r = null == t ? void 0 : t.parameters) || void 0 === r ? void 0 : r.cmd_id) {
                case "get_base_path_subtree":
                    s = !1, this.parseBasePathSubtree(t);
                    break;
                case "heartbeat":
                    s = !1, this.heartbeatReceived();
                    break;
                case "subscribe":
                case "unsubscribe":
                    s = !1, this.handleRequestListener({
                        message: t
                    });
                    break;
                case "set":
                case "get":
                    s = !0, this.handleRequestListener({
                        message: t
                    });
                    break;
                case "post":
                    s = !1, this.handleRequestListener({
                        message: t
                    })
            }
            return !!(s && "data" in t && "path" in t) && this.updateStore({
                message: {
                    path: t.path,
                    data: t.data
                }
            })
        }
        parsingComplete() {
            null === this.onMixerComplete || this.mixerCompleteCalled || (this.onMixerComplete(), this.mixerCompleteCalled = !0)
        }
        unRegisterCallback(e, t = null) {
            const n = this.listeners[e];
            for (let i of n)
                if (i.id === t) {
                    this.listeners[e] = this.listeners[e].filter(e => e !== i);
                    break
                }
        }
        registerCallback(e, t, n = null, i = null) {
            if (i && -1 === this.validValueTypes.indexOf(i)) throw "invalid type: " + i + ". valid types are: " + this.validValueTypes;
            const r = new V(e, t, n, i);
            e in this.listeners || (this.listeners[e] = []), this.listeners[e].push(r)
        }
        getValue(e) {
            let t = null;
            return e in this.uacValues && (t = this.uacValues[e].getValue()), t
        }
        setValue(e) {
            const {
                message: t
            } = e, {
                path: n,
                data: i
            } = t;
            if (n in this.uacValues) {
                const e = this.uacValues[n];
                i !== e.getValue() && e.setValue(i), this.updateStoreAndListeners({
                    message: t,
                    isShortCircuit: !0
                })
            }
        }
        updateCurrentTouchingProperty(e) {
            const t = this.uacValues[e];
            if (!t) return !1;
            const n = t.getType(),
                i = this.getDescriptorsFromPath({
                    path: e
                });
            if (!n || !i || "controls" !== i.selector) return !1;
            const r = this.getCommandPathFromDescriptors({
                selector: "controls",
                id: i.id,
                command: "set_touch"
            });
            if (!r) return !1;
            const s = this.uacValues[r];
            return !!s && (s.setCurrentTouchingProperty(n), !0)
        }
        updateStore(e) {
            const {
                message: {
                    path: t,
                    data: n
                }
            } = e;
            let i = !1;
            if (t in this.uacValues) {
                i = this.uacValues[t].update(n)
            }
            return i
        }
        updateListeners(e) {
            const {
                message: t,
                isShortCircuit: n,
                multiMessageData: i
            } = e;
            n && this.updateCurrentTouchingProperty(e.message.path), this.runCallbackListeners({
                message: t,
                isShortCircuit: n,
                multiMessageData: i
            })
        }
        updateStoreAndListeners(e) {
            this.updateStore({
                message: e.message
            }) && this.updateListeners(e)
        }
        getPathFromDescriptors(e) {
            var t, n, i;
            const {
                id: r,
                property: s,
                selector: o
            } = e;
            if (-1 !== this.validValueTypes.indexOf(s) && this.validateSelector({
                    selector: o,
                    id: r
                })) return "effect" === o && "effect" === r ? null === (t = this.effectStore) || void 0 === t ? void 0 : t[s] : null === (i = null === (n = this.pathStore) || void 0 === n ? void 0 : n[s]) || void 0 === i ? void 0 : i[r]
        }
        getCommandPathFromDescriptors(e) {
            var t, n, i;
            const {
                selector: r,
                id: s,
                command: o
            } = e;
            if (this.validateSelector({
                    selector: r,
                    id: s
                })) return null === (i = null === (n = null === (t = this.commandStore) || void 0 === t ? void 0 : t[r]) || void 0 === n ? void 0 : n[s]) || void 0 === i ? void 0 : i[o]
        }
        validateSelector(e) {
            const {
                selector: t,
                id: n
            } = e;
            return "effect" !== t || "effect" === n
        }
        getDescriptorsFromPath(e) {
            const {
                path: t
            } = e;
            if (!(t in this.uacValues)) return;
            const n = this.uacValues[t],
                i = n.getPath(),
                r = n.getSelector(),
                s = n.getID(),
                o = n.getType();
            if (!(i === t && r && s && o)) return;
            let a;
            if (m(r)) a = r;
            else switch (r) {
                case "param":
                    a = "controls";
                    break;
                case "meters":
                    a = "meters";
                    break;
                case "private_data":
                    a = "private_data";
                    break;
                case "effect":
                    a = "effect";
                    break;
                default:
                    return void console.warn("not a valid selector: " + r, n)
            }
            return {
                selector: a,
                id: s,
                property: o
            }
        }
        parseMultiMessage(e) {
            const {
                multi: t
            } = e, n = [], i = {
                controls: {},
                effect: {},
                meters: {},
                private_data: {}
            }, r = S(), s = (new Date).toISOString();
            return t.forEach(e => {
                const t = this.getDescriptorsFromPath({
                    path: e.path
                });
                if (t) {
                    const {
                        selector: n,
                        property: r,
                        id: o
                    } = t;
                    i[n][o] || (i[n][o] = {}), i[n][o][r] = Object.assign(Object.assign({}, t), {
                        path: e.path,
                        value: e.data,
                        timestamp: s,
                        message: Object.assign({}, e)
                    })
                }
                n.push(Object.assign({}, e))
            }), {
                multi: n,
                tree: i,
                hash: r
            }
        }
        handleRequestedPaths() {
            const e = x(this.requestedPaths, this.pendingPaths);
            this.requestedPaths = new Set;
            for (let t of e) this.createRequest({
                request: "get",
                path: t,
                params: {
                    flatvalue: 1
                }
            }).catch(e => {
                console.warn({
                    error: e,
                    message: "could not request " + t
                }), this.pendingPaths.delete(t)
            }), this.pendingPaths.add(t)
        }
        updateRequestedPaths(e) {
            const {
                multiMessageData: t,
                descriptors: {
                    selector: n,
                    id: i
                },
                callbackListenerSeed: r
            } = e;
            Object.keys(r.properties).forEach(e => {
                var s, o;
                if ((!t || !t.tree[n][i][e]) && ((null === (s = r.properties[e]) || void 0 === s ? void 0 : s.allowLogging) && console.warn({
                        message: `property: ${e} is not in multi message. listener seed in data property`,
                        data: r
                    }), r.counters[e] && (null === (o = r.properties[e]) || void 0 === o ? void 0 : o.allowFetch))) {
                    const t = this.getPathFromDescriptors({
                        selector: n,
                        id: i,
                        property: e
                    });
                    if (!t) return void console.warn({
                        error: "path not found for requesting properties from runCallbackListeners",
                        data: {
                            selector: n,
                            id: i,
                            property: e
                        }
                    });
                    if (!(t in this.uacValues)) return void console.warn({
                        error: "path not found in UANET store",
                        data: t
                    });
                    this.requestedPaths.add(t)
                }
            })
        }
        runMultiCallbackListener(e) {
            var t;
            const {
                seed: n
            } = e, i = this.multiCallbackListenerSeeds[n];
            i && (null === (t = i.callback) || void 0 === t || t.call(i, {
                seed: i.seed,
                events: i.events.slice(0),
                values: JSON.parse(JSON.stringify(i.values))
            }), i.events = [], i.values = {
                controls: {},
                meters: {},
                private_data: {},
                effect: {}
            })
        }
        handleMultiCallbackListeners() {
            Object.keys(this.multiCallbackListenerMutexes).forEach(e => this.runMultiCallbackListener({
                seed: e
            })), this.multiCallbackListenerMutexes = {}
        }
        runCallbackListeners(e) {
            var t, n;
            const {
                message: i,
                isShortCircuit: r,
                multiMessageData: s
            } = e, {
                path: o,
                data: a,
                parameters: c
            } = i, l = this.getDescriptorsFromPath({
                path: o
            });
            if (!l) return;
            const {
                selector: u,
                id: h,
                property: d
            } = l, p = null === (n = null === (t = this.callbackListeners[u]) || void 0 === t ? void 0 : t[h]) || void 0 === n ? void 0 : n[d];
            if (p) {
                const e = (new Date).toISOString(),
                    t = {
                        path: o,
                        selector: u,
                        id: h,
                        property: d,
                        value: a,
                        timestamp: e,
                        isShortCircuit: r,
                        wasRequested: "get" === (null == c ? void 0 : c.cmd_id),
                        message: Object.assign({}, i)
                    },
                    n = this.pendingPaths.has(o);
                n && t.wasRequested && this.pendingPaths.delete(o), Object.keys(p).forEach(e => {
                    var i, o, a, l, u, h;
                    const {
                        allowTaggedUANET: p,
                        ignoreUntaggedUANET: f,
                        ignoreShortCircuit: g
                    } = this.callbackListenerSeeds[e].properties[d];
                    if ((null == c ? void 0 : c.cmd_id) && (Array.isArray(p) && p.includes(c.cmd_id) || "get" === c.cmd_id) || !(null == c ? void 0 : c.cmd_id) && (r && !g || !r && !f)) {
                        const r = null !== (i = this.callbackListenerSeeds[e].maxEventLength) && void 0 !== i ? i : 50,
                            c = this.callbackListenerSeeds[e].includeMultiMessageData;
                        (n && t.wasRequested || !n) && (delete this.callbackListenerSeeds[e].counters[d], this.callbackListenerSeeds[e].values[d] = t, this.callbackListenerSeeds[e].events.push(t));
                        const p = {
                            events: this.callbackListenerSeeds[e].events.slice(0),
                            values: Object.assign({}, this.callbackListenerSeeds[e].values),
                            properties: Object.assign({}, this.callbackListenerSeeds[e].properties),
                            id: this.callbackListenerSeeds[e].id,
                            seed: this.callbackListenerSeeds[e].seed,
                            selector: this.callbackListenerSeeds[e].selector,
                            multiMessageData: c && s ? Object.assign({}, s) : void 0,
                            includeMultiMessageData: c,
                            multiCallbackSeed: this.callbackListenerSeeds[e].multiCallbackSeed
                        };
                        if (0 === Object.keys(this.callbackListenerSeeds[e].counters).length)
                            if (this.callbackListenerSeeds[e].counters = Object.assign({}, this.callbackListenerSeeds[e].properties), this.callbackListenerSeeds[e].values = {}, this.callbackListenerSeeds[e].events = [], "function" == typeof this.callbackListenerSeeds[e].callback) try {
                                null === (a = (o = this.callbackListenerSeeds[e]).callback) || void 0 === a || a.call(o, p)
                            } catch (t) {
                                const n = this.callbackListenerSeeds[e];
                                console.error("Failed to invoke callback function for listener registration: " + JSON.stringify({
                                    seed: n.seed,
                                    selector: n.selector,
                                    id: n.id,
                                    properties: n.properties
                                }), t)
                            } else console.warn({
                                message: "listener does not contain a valid callback function",
                                data: p
                            });
                            else this.callbackListenerSeeds[e].events.length >= r && (console.warn({
                                message: `listener events is at ${r} entries. resetting listener events.\n              override this limit through the maxEventLength property in the listener registration.`,
                                data: p
                            }), this.callbackListenerSeeds[e].events = []);
                        if ("function" == typeof(null === (l = this.callbackListenerSeeds[e]) || void 0 === l ? void 0 : l.updater)) try {
                            null === (h = (u = this.callbackListenerSeeds[e]).updater) || void 0 === h || h.call(u, p)
                        } catch (t) {
                            const n = this.callbackListenerSeeds[e];
                            console.error("Failed to invoke updater function for listener registration: " + JSON.stringify({
                                seed: n.seed,
                                selector: n.selector,
                                id: n.id,
                                properties: n.properties
                            }), t)
                        }
                    }
                })
            }
        }
        isConnectedToMixerd() {
            return "4740" === this.port
        }
    }
    class J {
        static parseBasePaths(e, t, n, i, r) {
            for (let e of n) i[e.propertyValue] = [];
            this.parse(e, t, n, !1, i, r)
        }
        static parse(e, t, n, i, r, s) {
            var o, a;
            if (e && e.properties) {
                let c, l = n[0];
                if ("object" != typeof e) {
                    for (let i of n) "custom" === i.propertyValue && (r.custom.push(t), s[t + "/value"] = e);
                    return
                }
                for (let s of n)
                    if (l = s, s.propertyKey in e.properties && (c = e.properties[s.propertyKey], c === s.propertyValue)) {
                        J.shouldParseProceed(s, r) && ("full_path" === s.storageType ? r[s.propertyValue].push(t) : "value_only" === s.storageType ? e.path ? r[s.propertyValue].push(e.path) : console.warn("PathParser.parse: missing path from data", e) : "all_properties" === s.storageType && (e.properties.full_path = t, r[s.propertyValue].push(e.properties))), s.totalNumFound++, i = !0;
                        break
                    } if (i && e.properties) {
                    for (let n in e.properties) {
                        s[`${t}/${n}/value`] = e.properties[n]
                    }
                    null === (o = e.commands) || void 0 === o || o.forEach(e => {
                        const n = "string" == typeof e ? e : null == e ? void 0 : e.path;
                        s[`${t}/${n}`] = e;
                        const i = t + "/set_touch";
                        "effect_control" !== l.propertyValue || i in s || (s[i] = i)
                    })
                }
                null === (a = e.children) || void 0 === a || a.forEach(e => {
                    let o = t;
                    "root" !== c && (o += "/");
                    let a = o + e.path;
                    this.parse(e, a, n, i, r, s)
                })
            }
        }
        static shouldParseProceed(e, t) {
            if (null !== e.keepRange && null !== e.keepInterval) {
                if (e.totalNumFound % e.keepInterval >= e.keepRange) return !1
            }
            return !(null !== e.keepTotal && t[e.propertyValue].length >= e.keepTotal)
        }
        static subsetOfPaths(e, t) {
            let n = [];
            for (let i in t) {
                n.push([]);
                for (let r in e) - 1 !== e[r].indexOf(t[i]) && n[i].push(e[r])
            }
            return n
        }
        static getPluginParamNameToBasePathObj(e) {
            let t = {};
            for (let n of e) {
                let e = n.split("/").slice(-1)[0];
                e && (t[e] = n)
            }
            return t
        }
    }
    class Q {
        constructor(e, t = "full_path", n = null, i = null, r = null) {
            this.storageType = t, this.keepTotal = n, this.keepRange = i, this.keepInterval = r, this.propertyKey = "type", this.totalNumFound = 0, this.propertyValue = e, null === r && (this.keepInterval = i)
        }
    }

    function Z(e, t, n, i) {
        let r = {};
        if (t < 0 || t > 16) return console.warn("createMidiMessage: channel out of range: " + t), null;
        if (n < 0 || n > 127) return console.warn("createMidiMessage: pitch out of range: " + n), null;
        if (i < 0 || i > 127) return console.warn("createMidiMessage: velocity out of range: " + i), null;
        let s = 0,
            o = 0,
            a = 0;
        switch (e) {
            case u.kNoteOn:
                s = Number(c) + Number(t);
                break;
            case u.kNoteOff:
                s = Number(l) + Number(t);
                break;
            default:
                return console.warn("createMidiMessage: unexpected mesage type: " + e), null
        }
        return o = n, a = i, r = {
            byte_0: s,
            byte_1: o,
            byte_2: a
        }, r
    }

    function ee(e) {
        let t = [];
        e = e.split("").join("");
        for (let n = 0; n < e.length; n++) {
            let i = parseInt(e[n], 16);
            if (i > 0)
                for (let r = 0; r < 4; r++) {
                    t[4 * (e.length - 1 - n) + r] = i >> r & 1
                }
        }
        return t
    }

    function te(e) {
        let t = [];
        for (let n = 0; n < e.length; n += 2) {
            let i = e[n] + e[n + 1],
                r = parseInt(i, 16);
            if (r > 0)
                for (let e = 0; e < 8; e++) {
                    t[n / 2 * 8 + e] = r >> e & 1
                }
        }
        return t
    }
    let ne = -1;
    class ie {
        constructor(e, t) {
            this.client = t, this.uniqueId = ++ne, this.value = null, this.path = null, this.id = null, this.type = null, this.channelArea = null, this.info = {}, this.initialValue = null, this.selector = e, this.info.selector = this.selector
        }
        init(e) {
            return this.initialValue = e, this.update(e)
        }
        update(e) {
            let t = !1;
            return e !== this.value && (this.value = e, this.info.value = this.value, t = !0), t
        }
        subscribe() {
            this.path && this.client.sendSubscribeWithoutTrailingSeparator(this.path)
        }
        getInitialValue() {
            return this.initialValue
        }
        getValue() {
            return this.value
        }
        setValue(e) {
            this.client.sendSet({
                path: this.path,
                value: e
            })
        }
        getIsTouching() {
            return this.isTouching
        }
        setIsTouching(e) {
            this.isTouching = e, !1 === e && this.setCurrentTouchingProperty(void 0)
        }
        setCurrentTouchingProperty(e) {
            this.currentTouchingProperty = e
        }
        getCurrentTouchingProperty() {
            return this.currentTouchingProperty
        }
        postTouch(e) {
            const t = {
                touch: e
            };
            this.client.sendPostWithUid(this.path, t), "set_touch" === this.getType() && this.setIsTouching(e)
        }
        postSetDefaultValue() {
            this.client.sendPostWithUid(this.path, {})
        }
        postCommandValue(e) {
            e && this.client.sendPostWithUid(this.path, e)
        }
        getPath() {
            return this.path
        }
        setPath(e) {
            this.path = e
        }
        getSelector() {
            return this.selector
        }
        setType(e) {
            this.type = e, this.info.value_type = this.type
        }
        getType() {
            return this.type
        }
        setID(e) {
            this.id = e, this.info.id = this.id
        }
        getID() {
            return this.id
        }
        setChannelArea(e) {
            this.channelArea = e, this.info.channel_area = this.channelArea
        }
        getChannelArea() {
            return this.channelArea
        }
        getInfo() {
            return this.info
        }
    }
    class re {
        constructor(e, t) {
            this.client = e, this.masterValues = t
        }
        createChannelValues(e, t, n, i, r, s) {
            for (let c in e) {
                let l = null;
                l = "meters" === t ? e[c] + "/" + t + "/" + n : e[c] + "/" + a + "/" + t + "/" + n, "set_touch" !== n && n !== o && (l += "/value");
                let u = new ie(t, this.client);
                u.setPath(l), u.setID(parseInt(c)), u.setType(n), u.setChannelArea(i), l in this.masterValues && u.init(this.masterValues[l]), s.push(l), r[l] = u
            }
        }
        createStereoChannelValues(e, t, n, i, r, s, c) {
            for (let l in e) {
                const u = parseInt(l);
                let h = [],
                    d = 0;
                h = L(u, r) ? n : t;
                for (let t of h) {
                    if (null === t) {
                        c.push(null);
                        continue
                    }
                    let n = e[l] + "/" + a + "/" + t + "/" + i;
                    "set_touch" !== i && i !== o && (n += "/value");
                    let h = new ie(t, this.client);
                    h.setPath(n);
                    let p = 2 * u + d;
                    h.setID(p), h.setType(i), h.setChannelArea(r), n in this.masterValues && h.init(this.masterValues[n]), c.push(n), s[n] = h, d++
                }
            }
        }
        createPresetValues(e, t, n, i, r) {
            for (let s in e) {
                let o = e[s] + "/" + t + "/value",
                    a = new ie(t, this.client);
                a.setPath(o), a.setID(s), a.setType(n), o in this.masterValues && a.init(this.masterValues[o]), r[s] = o, i[o] = a
            }
        }
        createPresetCMRValues(e, t, n, i, r) {
            for (let s of e) {
                const e = s.name;
                if (n.has(e)) {
                    let n = [s.full_path, "val", "value"].join("/"),
                        o = new ie("preset_cmr_param", this.client);
                    o.setPath(n), o.setID({
                        uid: t,
                        param: e
                    }), n in this.masterValues && o.init(this.masterValues[n]), r.push(n), i[n] = o
                }
            }
        }
        createPropertyValues(e, t, n, i, r, s = "value") {
            for (let o in e) {
                let a = e[o];
                t && (a = a + "/" + t), a = a + "/" + s;
                let c = new ie(t, this.client);
                c.setPath(a), c.setID(parseInt(o)), n && c.setChannelArea(n), a in this.masterValues && c.init(this.masterValues[a]), r.push(a), i[a] = c
            }
        }
        createMeterValues(e) {
            const {
                addParamsToPathForHegel: t,
                basePaths: n,
                valueType: i,
                channelArea: r,
                outPaths: s,
                outValuesByPath: o,
                subscribe: a
            } = e;
            for (let e of n) {
                let t = e + "/level/value",
                    n = new ie("meters", this.client),
                    c = e.lastIndexOf("/"),
                    l = e.substr(c + 1);
                n.setPath(t), n.setID(l), n.setChannelArea(r), n.setType(i), t in this.masterValues && n.init(this.masterValues[t]), a && n.subscribe(), s[l] = t, o[t] = n
            }
        }
        createPropertyValuesWithType(e, t, n, i, r, s, o = "value") {
            for (let a in e) {
                let c = e[a];
                if (!c) continue;
                t && (c = c + "/" + t), c = c + "/" + o;
                let l = new ie(s, this.client);
                l.setPath(c), l.setType(n), l.setID(a), c in this.masterValues && l.update(this.masterValues[c]), r[a] = c, i[c] = l
            }
        }
        createCommandValues({
            basePaths: e,
            outValuesByPath: t,
            outPaths: n
        }) {
            for (let i of e) {
                let e = i,
                    r = new ie("commands", this.client),
                    s = i.lastIndexOf("/"),
                    o = i.substr(s + 1);
                r.setPath(e), r.setID(o), e in this.masterValues ? r.init(this.masterValues[e]) : console.warn("not in masterValues"), n[o] || (n[o] = e), t[e] = r
            }
        }
        createPropertyValuesForBasePath(e, t, n, i, r, s = "param", o = "value", a = !0) {
            e = "/" === e ? "" : e;
            for (const a of t) {
                const t = e + "/" + a + "/" + o;
                if (t in this.masterValues) {
                    let e = new ie(s, this.client);
                    e.setPath(t), e.setType(n), e.setID(a), e.update(this.masterValues[t]), r[a] = t, i[t] = e
                }
            }
        }
        createPluginBypassValues(e, t, n, i, r, c, l) {
            e.length !== t.length && console.warn("base paths and param lengths don't match");
            for (let u in e) {
                let h = "0";
                "channel_area_master" === r && (h = u);
                const d = parseInt(u);
                let p = [e[d], s, h, a, t[d], i].join("/");
                "set_touch" !== i && i !== o && (p += "/value");
                let f = new ie(n, this.client);
                f.setPath(p), f.setID(d), r && f.setChannelArea(r), p in this.masterValues && f.init(this.masterValues[p]), l.push(p), c[p] = f
            }
        }
        createPluginParamValues(e, t, n, i, r = "param") {
            for (let s in e) {
                let a = e[s] + "/" + t;
                "set_touch" !== t && t !== o && (a += "/value");
                let c = new ie(r, this.client);
                c.setPath(a), c.setType(t), c.setID(s), a in this.masterValues && c.init(this.masterValues[a]), i[s] = a, n[a] = c
            }
        }
        generatePathMap(e) {
            const {
                path: t,
                selector: n,
                searchables: i,
                pathGenerator: r
            } = e, s = this.getSelectorID({
                path: t,
                selector: n
            });
            if (!s) return;
            const o = {};
            let a = !1;
            return i.forEach(t => {
                const i = r(t);
                if (i in this.masterValues && !(i in e.UANETStore)) {
                    const r = new ie(n, this.client);
                    "effect" === n ? r.setID("effect") : r.setID(s), r.setPath(i), r.setType(t), r.init(this.masterValues[i]), o[t] = i, e.UANETStore[i] = r, a = !0
                }
            }), a ? o : void 0
        }
        getSelectorID(e) {
            const {
                path: t,
                selector: n
            } = e;
            if (!t.includes("/")) return;
            const i = t.split("/"),
                r = i[i.length - 1];
            if (!/^\s+$/.test(r) && r) {
                if ("effect" !== n) {
                    if (i.length < 2) return;
                    if (i[i.length - 2] !== n) return
                }
                return r
            }
        }
    }
    class se extends X {
        constructor(e = new G(new Y)) {
            super(e), this.normalizedPaths = {}, this.realPaths = {}, this.realValuesPaths = {}, this.stringPaths = {}, this.stringValuesPaths = {}, this.namePaths = {}, this.numStepsPaths = {}, this.discretePaths = {}, this.touchCountPaths = {}, this.booleanPaths = {}, this.privateDataPaths = {}, this.meterPaths = {}, this.paramNames = [], this.privateParamNames = [], this.commandNames = [], this.propfilter = p, this.isStoreValid = !1, this.sharedMultiCallbackListener = e => {
                const {
                    multiMessageData: t,
                    multiCallbackSeed: n
                } = e;
                if ("string" != typeof n) return void console.warn("multi callback seed is invalid: ", n);
                const i = Object.assign({}, e.events[e.events.length - 1]),
                    r = this.multiCallbackListenerSeeds[n];
                if (r.values[i.selector][i.id] || (r.values[i.selector][i.id] = {}), r.events.push(i), r.values[i.selector][i.id][i.property] = i, t) {
                    const {
                        hash: e
                    } = t;
                    "string" != typeof this.multiCallbackListenerMutexes[n] ? this.multiCallbackListenerMutexes[n] = e : this.multiCallbackListenerMutexes[n] !== e && console.warn("mismatching hashes")
                } else this.runMultiCallbackListener({
                    seed: n
                })
            }
        }
        connect(e = null, t, n, i) {
            return this.doConnect(e, t, n, i)
        }
        disconnect(e, t = P.closedByUser) {
            this.doDisconnect(e, t)
        }
        testMidiSystem() {
            let e = !1;
            return e = this.testMidiNoteOnOff(), this.testMidiPanic(), e
        }
        testMidiNoteOnOff() {
            let e = !1;
            return e = this.sendMidiMessage(u.kNoteOn, 0, 64, 64), e ? (setTimeout(() => {
                e = this.sendMidiMessage(u.kNoteOff, 0, 64, 64)
            }, 2e3), e ? (e = !0, e) : (this.sendMidiPanic(), e)) : (this.sendMidiPanic(), e)
        }
        testMidiPanic() {
            let e = !1;
            return e = this.sendMidiMessage(u.kNoteOn, 0, 64, 64), e ? (setTimeout(() => {
                this.sendMidiPanic()
            }, 2e3), e) : (this.sendMidiPanic(), e)
        }
        sendMidiPanic() {
            for (let e = 0; e < 16; e++)
                for (let t = 0; t < 127; t++) this.sendMidiMessage(u.kNoteOff, e, t, 0)
        }
        sendMidiMessage(e, t, n, i) {
            let r = !1,
                s = Z(e, t, n, i);
            return s && (this.postMidiMessage(s), r = !0), r
        }
        tryRevertNormalizedValue(e) {
            return this.tryRevertValue(e, this.normalizedPaths)
        }
        tryDefaultNormalizedValue(e) {
            return this.tryDefaultValue(e, this.normalizedPaths)
        }
        setNormalizedValue(e, t) {
            if (e in this.normalizedPaths) {
                let n = this.normalizedPaths[e];
                "string" == typeof t && (t = parseFloat(t)), this.setValue({
                    message: {
                        path: n,
                        data: t
                    }
                })
            }
        }
        getNormalizedValue(e) {
            let t = null;
            if (e in this.normalizedPaths) {
                let n = this.normalizedPaths[e];
                t = this.getValue(n)
            }
            return t
        }
        setRealValue(e, t) {
            if (e in this.realPaths) {
                let n = this.realPaths[e];
                "string" == typeof t && (t = parseInt(t)), this.setValue({
                    message: {
                        path: n,
                        data: t
                    }
                })
            }
        }
        getWithReceipt(e) {
            var t;
            const {
                selector: n,
                id: i,
                property: r,
                params: s
            } = e, o = null !== (t = this.getPathFromDescriptors({
                selector: n,
                id: i,
                property: r
            })) && void 0 !== t ? t : "";
            return this.getPathWithReceipt({
                path: o,
                params: s
            })
        }
        getPathWithReceipt(e) {
            return new Promise((t, n) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const {
                    path: i
                } = e;
                if (!i) return n({
                    error: "INVALID_UANET_PATH"
                });
                const r = Object.assign({
                        flatvalue: 1
                    }, e.params),
                    s = this.createRequest({
                        request: "get",
                        path: i,
                        params: r
                    }),
                    o = yield this.handleRequest({
                        request: s
                    });
                return v(o) ? n(o) : t(o)
            })))
        }
        setWithReceipt(e) {
            var t;
            const {
                selector: n,
                id: i,
                property: r,
                payload: s,
                params: o,
                skipShortCircuit: a
            } = e, c = null !== (t = this.getPathFromDescriptors({
                selector: n,
                id: i,
                property: r
            })) && void 0 !== t ? t : "";
            return this.setPathWithReceipt({
                path: c,
                payload: s,
                params: o,
                skipShortCircuit: a
            })
        }
        setPathWithReceipt(e) {
            return new Promise((t, n) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const {
                    path: i,
                    payload: r,
                    skipShortCircuit: s
                } = e;
                if (void 0 === r) return n({
                    error: "INVALID_UANET_PAYLOAD"
                });
                if (!i) return n({
                    error: "INVALID_UANET_PATH"
                });
                const o = Object.assign({}, e.params),
                    a = this.createRequest({
                        request: "set",
                        path: i,
                        payload: r,
                        params: o
                    });
                if (!s) {
                    const e = {
                        path: i,
                        data: r
                    };
                    this.updateStoreAndListeners({
                        message: e,
                        isShortCircuit: !0
                    })
                }
                const c = yield this.handleRequest({
                    request: a
                });
                return v(c) ? n(c) : t(c)
            })))
        }
        postWithReceipt(e) {
            var t;
            const {
                selector: n,
                id: i,
                command: r,
                payload: s,
                params: o
            } = e, a = null !== (t = this.getCommandPathFromDescriptors({
                selector: n,
                id: i,
                command: r
            })) && void 0 !== t ? t : "";
            return this.postPathWithReceipt({
                path: a,
                payload: s,
                params: o
            })
        }
        postPathWithReceipt(e) {
            return new Promise((t, n) => Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const {
                    path: i,
                    payload: r
                } = e;
                if (!i) return n({
                    error: "INVALID_UANET_PATH"
                });
                i.includes("set_touch") && null != r && this.setStorePathTouching({
                    path: i,
                    payload: r
                });
                const s = Object.assign({
                        preupdates: 1
                    }, e.params),
                    o = this.createRequest({
                        request: "post",
                        path: i,
                        payload: r,
                        params: s
                    }),
                    a = yield this.handleRequest({
                        request: o
                    });
                return v(a) ? n(a) : t(a)
            })))
        }
        sendExtendedUANetRequest(e) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const {
                    path: t,
                    operation: n,
                    payload: i,
                    parameters: r
                } = e;
                let s;
                if (this.uacValues[t]) {
                    const e = {
                        error: "INVALID_EXTENDED_UANET_PATH",
                        payload: "The requested path is in the UANet store. This API only supports Extended UANet path requests"
                    };
                    return Promise.reject(e)
                }
                switch (n) {
                    case "get":
                        return this.getPathWithReceipt({
                            path: t,
                            params: r
                        });
                    case "set":
                        return this.setPathWithReceipt({
                            path: t,
                            params: r,
                            payload: i
                        });
                    case "post":
                        return this.postPathWithReceipt({
                            path: t,
                            params: r,
                            payload: i
                        });
                    case "subscribe":
                    case "unsubscribe": {
                        const e = Object.assign({}, r),
                            i = this.createRequest({
                                request: n,
                                path: t,
                                params: e
                            });
                        s = yield this.handleRequest({
                            request: i
                        });
                        break
                    }
                }
                return v(s) ? Promise.reject(s) : s
            }))
        }
        tryRevertRealValue(e) {
            return this.tryRevertValue(e, this.realPaths)
        }
        tryRevertValue(e, t) {
            if (e in t) {
                const n = t[e];
                if (!n) return !1;
                const i = this.uacValues[n];
                if (!i) return !1;
                const r = i.getInitialValue();
                if (void 0 !== r) return this.setValue({
                    message: {
                        path: n,
                        data: r
                    }
                }), !0
            }
            return !1
        }
        tryDefaultRealValue(e) {
            return this.tryDefaultValue(e, this.realPaths)
        }
        tryDefaultValue(e, t) {
            if (e in t) {
                return !!t[e] && (this.setDefaultValue(e), !0)
            }
            return !1
        }
        getRealValue(e) {
            let t = null;
            if (e in this.realPaths) {
                let n = this.realPaths[e];
                t = this.getValue(n)
            }
            return t
        }
        getRealValues(e) {
            const {
                paramName: t
            } = e;
            if (t in this.realValuesPaths) {
                const e = this.realValuesPaths[t];
                return this.getValue(e)
            }
            return null
        }
        getStringValues(e) {
            const {
                paramName: t
            } = e;
            if (t in this.stringValuesPaths) {
                const e = this.stringValuesPaths[t];
                return this.getValue(e)
            }
            return null
        }
        getNameValue(e) {
            let t = null;
            if (e in this.namePaths) {
                let n = this.namePaths[e];
                t = this.getValue(n)
            }
            return t
        }
        getNumStepsValue(e) {
            let t = null;
            if (e in this.numStepsPaths) {
                let n = this.numStepsPaths[e];
                t = this.getValue(n)
            }
            return t
        }
        numStepsParam(e) {
            const t = this.getRealValues({
                paramName: e
            });
            return Array.isArray(t) ? t.length : 0
        }
        getDiscreteValue(e) {
            let t = null;
            if (e in this.discretePaths) {
                let n = this.discretePaths[e];
                t = this.getValue(n)
            }
            return t
        }
        isDiscreteParam(e) {
            const t = this.getRealValues({
                paramName: e
            });
            return !!Array.isArray(t) && t.length > 0
        }
        tryRevertStringValue(e) {
            return this.tryRevertValue(e, this.stringPaths)
        }
        tryDefaultStringValue(e) {
            return this.tryDefaultValue(e, this.stringPaths)
        }
        setStringValue(e, t) {
            if (e in this.stringPaths) {
                let n = this.stringPaths[e];
                null != t && "string" != typeof t && (t = t.toString()), this.setValue({
                    message: {
                        path: n,
                        data: t
                    }
                })
            }
        }
        getStringValue(e) {
            let t = null;
            if (e in this.stringPaths) {
                let n = this.stringPaths[e];
                t = this.getValue(n)
            }
            return t
        }
        getBooleanValue(e) {
            let t = null;
            if (e in this.booleanPaths) {
                const n = this.booleanPaths[e];
                t = this.getValue(n)
            }
            return t
        }
        setBooleanValue(e, t) {
            if (e in this.booleanPaths) {
                const n = this.booleanPaths[e];
                this.setValue({
                    message: {
                        path: n,
                        data: t
                    }
                })
            }
        }
        setInitialValue(e) {
            [this.realPaths[e], this.normalizedPaths[e], this.stringPaths[e]].forEach(e => {
                if (e) {
                    const t = this.uacValues[e];
                    if (t) {
                        const e = t.getValue();
                        void 0 !== e && t.init(e)
                    }
                }
            })
        }
        setTouch(e, t) {
            const n = this.getCommandPathFromDescriptors({
                selector: "controls",
                id: e,
                command: "set_touch"
            });
            n && this.postTouch(n, t)
        }
        setDefaultValue(e) {
            const t = this.getCommandPathFromDescriptors({
                selector: "controls",
                id: e,
                command: "set_control_default_value"
            });
            t && this.postSetDefaultValue(t)
        }
        postMidiMessage(e) {
            let t = !1;
            if (e) {
                if (3 != Object.keys(e).length) return console.warn("postMidiMessage unexpected length " + e.length), t;
                this.postCommandValue("send_midi", e), t = !0
            }
            return t
        }
        postCommandValue(e, t) {
            let n = !1;
            const i = this.getCommandPathFromDescriptors({
                selector: "effect",
                id: "effect",
                command: e
            });
            return i && (this.client.sendPostWithUid(i, t), n = !0), n
        }
        getDataValue(e) {
            let t = null;
            if (e in this.privateDataPaths) {
                let n = this.privateDataPaths[e];
                t = this.getValue(n)
            }
            return t
        }
        getParamNames() {
            return this.paramNames
        }
        getMeterNames() {
            return Object.keys(this.meterPaths)
        }
        getNumParams() {
            return this.paramNames.length
        }
        getDataParamNames() {
            return this.privateParamNames
        }
        getMeterValue(e) {
            let t = null;
            if (e in this.meterPaths) {
                let n = this.meterPaths[e];
                t = this.uacValues[n]
            }
            return t
        }
        getManifest() {
            var e;
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const t = yield this.createRequest({
                    request: "get",
                    path: this.basePath + "/plugin_id",
                    params: {
                        flatvalue: 0
                    }
                }), n = null === (e = t.data) || void 0 === e ? void 0 : e.value;
                return (yield this.createRequest({
                    request: "get",
                    path: `/plugins/${n}/manifest`,
                    params: {
                        flatvalue: 0
                    }
                })).data
            }))
        }
        getStoreValue(e) {
            const t = this.getPathFromDescriptors(e);
            if (!t) return;
            return this.getValue(t)
        }
        setStorePathTouching(e) {
            const {
                path: t,
                payload: n
            } = e;
            if (null != n && t) {
                const e = this.uacValues[t];
                if (e && "set_touch" === e.getType()) {
                    const t = n;
                    return e.setIsTouching(t.touch), !0
                }
            }
            return !1
        }
        getStoreTouching({
            id: e
        }) {
            const t = this.getCommandPathFromDescriptors({
                selector: "controls",
                id: e,
                command: "set_touch"
            });
            if (!t) return;
            const n = this.uacValues[t];
            return n ? n.getIsTouching() : void 0
        }
        getStoreCurrentTouchingProperty({
            id: e
        }) {
            const t = this.getCommandPathFromDescriptors({
                selector: "controls",
                id: e,
                command: "set_touch"
            });
            if (!t) return;
            const n = this.uacValues[t];
            return n ? n.getCurrentTouchingProperty() : void 0
        }
        setStoreCurrentTouchingProperty(e) {
            const t = this.getPathFromDescriptors(e);
            return !!t && this.updateCurrentTouchingProperty(t)
        }
        checkInvalidProperty(e) {
            const {
                selector: t,
                id: n,
                property: i
            } = e;
            if (!this.isStoreValid) return {
                error: {
                    message: "UANET store is invalid"
                }
            };
            if (!m(t)) return {
                error: {
                    message: t + " is invalid"
                }
            };
            let r = void 0;
            return this.getPathFromDescriptors({
                selector: t,
                id: n,
                property: i
            }) || (r = {
                message: `invalid selector/id/property combination: ${t}/${n}/${i}. Could not find valid path in UANET store`
            }), r
        }
        registerMultiCallbackListener(e) {
            const {
                listeners: t,
                callback: n
            } = e;
            if (0 === t.length) return {
                error: {
                    message: "listeners array is empty"
                }
            };
            const i = "" + Math.trunc(1e12 * Math.random());
            if (this.multiCallbackListenerSeeds[i]) return {
                error: {
                    message: "there is a multi listener registered for the generated seed already.\n          please try to register the multi listener again.",
                    data: Object.assign({}, this.multiCallbackListenerSeeds[i])
                }
            };
            this.multiCallbackListenerSeeds[i] = {
                seed: i,
                singleSeeds: [],
                callback: n,
                listeners: t,
                events: [],
                values: {
                    controls: {},
                    meters: {},
                    private_data: {},
                    effect: {}
                }
            };
            for (const e of t) {
                const t = this.registerCallbackListener(Object.assign(Object.assign({}, e), {
                    callback: this.sharedMultiCallbackListener,
                    includeMultiMessageData: !0
                }));
                if (t.error || "string" != typeof t.seed) return {
                    error: {
                        message: "registration error",
                        data: {
                            listener: e,
                            error: t.error
                        }
                    }
                };
                this.callbackListenerSeeds[t.seed].multiCallbackSeed = i, this.multiCallbackListenerSeeds[i].singleSeeds.push(t.seed)
            }
            return {
                seed: i
            }
        }
        unregisterMultiCallbackListener(e) {
            const {
                seed: t
            } = e, n = this.multiCallbackListenerSeeds[t];
            if (!n) return !1;
            const {
                singleSeeds: i
            } = n;
            if (!Array.isArray(i)) return !1;
            let r = !0;
            return i.forEach(e => {
                this.unregisterCallbackListener({
                    seed: e
                }) || (r = !1)
            }), delete this.multiCallbackListenerSeeds[t], r
        }
        registerCallbackListener(e) {
            const {
                selector: t,
                callback: n,
                updater: i,
                includeMultiMessageData: r,
                maxEventLength: s = 20
            } = e;
            let {
                properties: o
            } = e;
            const a = "effect" === t ? "effect" : e.id;
            if ("function" != typeof n) return console.warn("registerCallbackListener: callback is not a function"), {
                error: {
                    message: "callback is not a function"
                }
            };
            const c = Object.keys(o);
            if (0 === c.length) return console.warn("registerCallbackListener: properties object must not be empty"), {
                error: {
                    message: "properties object must not be empty"
                }
            };
            let l = void 0;
            if (c.every(e => (l = this.checkInvalidProperty({
                    selector: t,
                    id: a,
                    property: e
                }), !l)), l) return {
                error: l
            };
            const u = "" + Math.trunc(1e12 * Math.random()),
                h = e => {
                    this.callbackListeners[t][a] || (this.callbackListeners[t][a] = {}), this.callbackListeners[t][a][e] || (this.callbackListeners[t][a][e] = {}), this.callbackListeners[t][a][e][u] = u
                };
            let d = {};
            c.forEach(e => {
                h(e), d[e] = !0
            });
            const p = {
                selector: t,
                id: a,
                properties: o,
                seed: u,
                counters: d,
                values: {},
                events: [],
                callback: n,
                updater: i,
                includeMultiMessageData: r,
                maxEventLength: s
            };
            return this.callbackListenerSeeds[u] = p, {
                seed: u
            }
        }
        unregisterCallbackListener(e) {
            var t, n, i;
            const {
                seed: r
            } = e;
            if (!(r in this.callbackListenerSeeds)) return !1;
            const {
                id: s,
                properties: o,
                selector: a
            } = this.callbackListenerSeeds[r];
            delete this.callbackListenerSeeds[r];
            Object.keys(o).forEach(e => {
                var t, n, i, o, c, l, u, h, d;
                null === (i = null === (n = null === (t = this.callbackListeners[a]) || void 0 === t ? void 0 : t[s]) || void 0 === n ? void 0 : n[e]) || void 0 === i || delete i[r];
                const p = "object" == typeof(null === (c = null === (o = this.callbackListeners[a]) || void 0 === o ? void 0 : o[s]) || void 0 === c ? void 0 : c[e]) ? Object.keys(null === (u = null === (l = this.callbackListeners[a]) || void 0 === l ? void 0 : l[s]) || void 0 === u ? void 0 : u[e]) : void 0;
                Array.isArray(p) && 0 === p.length && (null === (d = null === (h = this.callbackListeners[a]) || void 0 === h ? void 0 : h[s]) || void 0 === d || delete d[e])
            });
            const c = "object" == typeof(null === (t = this.callbackListeners[a]) || void 0 === t ? void 0 : t[s]) ? Object.keys(null === (n = this.callbackListeners[a]) || void 0 === n ? void 0 : n[s]) : void 0;
            return Array.isArray(c) && 0 === c.length && (null === (i = this.callbackListeners[a]) || void 0 === i || delete i[s]), !0
        }
        refreshAllPaths(e = this.propfilter, t) {
            t ? super.refreshAllPaths(e, t) : super.refreshAllPaths(e)
        }
        parseBasePathSubtree(e) {
            if (null == e.data || null == e.path) return console.warn("Could not create plugin store."), void(this.isStoreValid = !1);
            this.isStoreValid && console.warn("Plugin store is already valid. Creating a new store"), this.uacValues = {};
            let t = "effect_control";
            this.isConnectedToMixerd() && (t = "control");
            const n = [new Q(t), new Q("meter"), new Q("private_data"), new Q("effect"), new Q("folder")];
            let i = {},
                r = {};
            J.parseBasePaths(e.data, e.path, n, i, r);
            let s = J.getPluginParamNameToBasePathObj(i[t]);
            this.paramNames = Object.keys(s);
            let o = new re(this.client, r);
            o.createPluginParamValues(s, "normalized_value", this.uacValues, this.normalizedPaths), o.createPluginParamValues(s, "real_value", this.uacValues, this.realPaths), o.createPluginParamValues(s, "string_value", this.uacValues, this.stringPaths), o.createPluginParamValues(s, "name", this.uacValues, this.namePaths), o.createPluginParamValues(s, "num_steps", this.uacValues, this.numStepsPaths), o.createPluginParamValues(s, "discrete", this.uacValues, this.discretePaths), o.createPluginParamValues(s, "real_values", this.uacValues, this.realValuesPaths), o.createPluginParamValues(s, "string_values", this.uacValues, this.stringValuesPaths), o.createPluginParamValues(s, "touch_count", this.uacValues, this.touchCountPaths), o.createMeterValues({
                basePaths: i.meter,
                valueType: "level",
                channelArea: null,
                outValuesByPath: this.uacValues,
                outPaths: this.meterPaths,
                addParamsToPathForHegel: !1,
                subscribe: this.subscribeToMeters
            });
            let a = J.getPluginParamNameToBasePathObj(i.private_data);
            if (this.privateParamNames = Object.keys(a), o.createPluginParamValues(a, "data", this.uacValues, this.privateDataPaths, "private_data"), this.commandStore.controls = {}, i.effect_control) {
                let e = !1;
                i.effect_control.forEach(t => {
                    const n = o.getSelectorID({
                            path: t,
                            selector: "controls"
                        }),
                        i = o.generatePathMap({
                            path: t,
                            selector: "controls",
                            searchables: ["get_real_for_normalized_value", "get_string_for_normalized_value", "set_control_default_value", "set_touch"],
                            UANETStore: this.uacValues,
                            pathGenerator: e => `${t}/${e}`
                        });
                    i && n ? this.commandStore.controls[n] = i : e = !0
                }), e && (e = !1)
            } else;
            if (this.commandStore.effect = {}, i.effect) {
                const e = i.effect[0] + "/commands",
                    t = o.generatePathMap({
                        path: e,
                        selector: "effect",
                        searchables: ["send_midi", "set_effect_controls", "untouch_controls", "notify_gui_loaded", "open_link", "open_link_info", "open_link_buy", "open_link_doc", "open_link_video"],
                        UANETStore: this.uacValues,
                        pathGenerator: t => `${e}/${t}`
                    });
                t && (this.commandStore.effect.effect = t);
                const n = o.generatePathMap({
                    path: i.effect[0],
                    selector: "effect",
                    UANETStore: this.uacValues,
                    searchables: ["output_stem_format", "preset_name", "preset_uid_dirty", "preset_uid", "stem_format", "plugin_power"],
                    pathGenerator: e => `${i.effect[0]}/${e}/value`
                });
                n && (this.effectStore = n)
            } else;
            this.pathStore = {
                normalized_value: this.normalizedPaths,
                data: this.privateDataPaths,
                discrete: this.discretePaths,
                level: this.meterPaths,
                name: this.namePaths,
                num_steps: this.numStepsPaths,
                real_value: this.realPaths,
                string_value: this.stringPaths,
                real_values: this.realValuesPaths,
                string_values: this.stringValuesPaths,
                touch_count: this.touchCountPaths
            }, e.error ? (console.warn("AudioPlugin.parseBasePathSubtree: store is invalid. Encountered an error in message: ", e), this.isStoreValid = !1) : this.isStoreValid = !0, this.parsingComplete()
        }
        getChannelConfiguration() {
            const e = this.getStoreValue({
                    selector: "effect",
                    id: "effect",
                    property: "stem_format"
                }),
                t = this.getStoreValue({
                    selector: "effect",
                    id: "effect",
                    property: "output_stem_format"
                });
            return "mono" === e && "mono" === t ? "MIMO" : "mono" === e && "stereo" === t ? "MISO" : "stereo" === e && "mono" === t ? "SIMO" : "stereo" === e && "stereo" === t ? "SISO" : void console.warn("getChannelConfiguration: Error: unsupported config")
        }
        openExternalBrowserLink(e) {
            var t;
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                let n = `AudioPlugin.openExternalBrowserLink: Could not launch url: ${e} in external browser. `;
                try {
                    return yield this.postWithReceipt({
                        selector: "effect",
                        id: "effect",
                        command: "open_link",
                        payload: e
                    }), Promise.resolve()
                } catch (e) {
                    n += "Error: Failed to invoke network callback: " + JSON.stringify(e)
                }
                if (!("lunaOpenInExternalBrowser" in window && "function" == typeof window.lunaOpenInExternalBrowser)) return Promise.reject(n);
                try {
                    return null === (t = null === window || void 0 === window ? void 0 : window.lunaOpenInExternalBrowser) || void 0 === t || t.call(window, e), Promise.resolve()
                } catch (e) {
                    return n += "Error: Failed to invoke JS callback: " + JSON.stringify(e), Promise.reject(n)
                }
            }))
        }
    }
    const oe = (() => {
        const e = {
            ws: () => new G(new Y)
        };
        return {
            register: (t, n) => {
                e[t] = n
            },
            get: t => e[t]
        }
    })();
    class ae {
        constructor(e, t) {
            this.pluginName = e, this.plugin = t, this.destinations = {
                console: !1,
                uaNet: !0
            }
        }
        log(e, t, n) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                const i = this.pluginName ? this.pluginName + ": " : "",
                    r = Object.assign(Object.assign({}, this.destinations), n),
                    s = "string" == typeof t ? `${i}${t}` : t;
                let o = !0;
                return r.console && this.logConsole(e, s), r.uaNet && (o = yield this.logUANet(e, s)), o
            }))
        }
        logUANet(e, t) {
            return Object(i.__awaiter)(this, void 0, void 0, (function*() {
                if (!this.plugin) return !1;
                try {
                    return yield this.plugin.sendExtendedUANetRequest({
                        path: "/logs/send_log",
                        operation: "post",
                        payload: {
                            category: "HBGF",
                            severity: e,
                            message: t
                        }
                    }), !0
                } catch (e) {
                    return !1
                }
            }))
        }
        logConsole(e, t) {
            switch (e) {
                case "error":
                    console.error(t);
                    break;
                case "warn":
                    console.warn(t);
                    break;
                default:
                    console.log(t)
            }
        }
    }
    n.d(t, "AudioPlugin", (function() {
        return se
    })), n.d(t, "reconnectMilliseconds", (function() {
        return 100
    })), n.d(t, "responseTimeoutMilliseconds", (function() {
        return 1e3
    })), n.d(t, "maxReconnectAttempts", (function() {
        return 1
    })), n.d(t, "websocketErrorCodeClosedByUser", (function() {
        return 4e3
    })), n.d(t, "kData", (function() {
        return "data"
    })), n.d(t, "kName", (function() {
        return "name"
    })), n.d(t, "kSeparator", (function() {
        return "/"
    })), n.d(t, "kRoot", (function() {
        return "root"
    })), n.d(t, "kPath", (function() {
        return "path"
    })), n.d(t, "kEffects", (function() {
        return s
    })), n.d(t, "kDiscrete", (function() {
        return "discrete"
    })), n.d(t, "kNumStepsVal", (function() {
        return "num_steps"
    })), n.d(t, "kChildren", (function() {
        return "children"
    })), n.d(t, "kProperties", (function() {
        return "properties"
    })), n.d(t, "kNormalizedValue", (function() {
        return "normalized_value"
    })), n.d(t, "kStringValues", (function() {
        return "string_values"
    })), n.d(t, "kRealValues", (function() {
        return "real_values"
    })), n.d(t, "kStringValue", (function() {
        return "string_value"
    })), n.d(t, "kRealValue", (function() {
        return "real_value"
    })), n.d(t, "kTouchCount", (function() {
        return "touch_count"
    })), n.d(t, "kBooleanValue", (function() {
        return "boolean_value"
    })), n.d(t, "kValue", (function() {
        return "value"
    })), n.d(t, "kReadOnly", (function() {
        return "read_only"
    })), n.d(t, "kURLParameters", (function() {
        return "url_parameters"
    })), n.d(t, "kAdded", (function() {
        return "added"
    })), n.d(t, "kRemoved", (function() {
        return "removed"
    })), n.d(t, "kClient", (function() {
        return "client"
    })), n.d(t, "kClientConnected", (function() {
        return "client_connected"
    })), n.d(t, "kClientDisconnected", (function() {
        return "client_disconnected"
    })), n.d(t, "kClientError", (function() {
        return "client_error"
    })), n.d(t, "kClientMessage", (function() {
        return "client_message"
    })), n.d(t, "kSelector", (function() {
        return "selector"
    })), n.d(t, "kID", (function() {
        return "id"
    })), n.d(t, "kVal", (function() {
        return "val"
    })), n.d(t, "kType", (function() {
        return "type"
    })), n.d(t, "kValueType", (function() {
        return "value_type"
    })), n.d(t, "kDirty", (function() {
        return "dirty"
    })), n.d(t, "kParam", (function() {
        return "param"
    })), n.d(t, "kParameters", (function() {
        return "parameters"
    })), n.d(t, "kPresetCMRParam", (function() {
        return "preset_cmr_param"
    })), n.d(t, "kChannelArea", (function() {
        return "channel_area"
    })), n.d(t, "kChannelArea_Master", (function() {
        return "channel_area_master"
    })), n.d(t, "kChannelArea_Channel", (function() {
        return "channel_area_channel"
    })), n.d(t, "kCommandAction", (function() {
        return "cmd_action"
    })), n.d(t, "kAction_HandleCallbacks", (function() {
        return "handle_callbacks"
    })), n.d(t, "kAction_IgnoreCallbacks", (function() {
        return "ignore_callbacks"
    })), n.d(t, "kCommandListener", (function() {
        return "cmd_listener"
    })), n.d(t, "kMessageID", (function() {
        return "message_id"
    })), n.d(t, "kSetTouch", (function() {
        return "set_touch"
    })), n.d(t, "kSetDefault", (function() {
        return o
    })), n.d(t, "kControl", (function() {
        return "control"
    })), n.d(t, "kControls", (function() {
        return a
    })), n.d(t, "kPrivateData", (function() {
        return "private_data"
    })), n.d(t, "kMeter", (function() {
        return "meter"
    })), n.d(t, "kMeters", (function() {
        return "meters"
    })), n.d(t, "kMeterValues", (function() {
        return "meter_values"
    })), n.d(t, "kLevel", (function() {
        return "level"
    })), n.d(t, "kCommands", (function() {
        return "commands"
    })), n.d(t, "kSendMidi", (function() {
        return "send_midi"
    })), n.d(t, "kFullPath", (function() {
        return "full_path"
    })), n.d(t, "kValueOnly", (function() {
        return "value_only"
    })), n.d(t, "kAllProperties", (function() {
        return "all_properties"
    })), n.d(t, "kEffectControl", (function() {
        return "effect_control"
    })), n.d(t, "kEffectControls", (function() {
        return "effect_controls"
    })), n.d(t, "kInstrument", (function() {
        return "instrument"
    })), n.d(t, "kEffect", (function() {
        return "effect"
    })), n.d(t, "kFolder", (function() {
        return "folder"
    })), n.d(t, "kAutomation", (function() {
        return "automation"
    })), n.d(t, "kCustom", (function() {
        return "custom"
    })), n.d(t, "kUID", (function() {
        return "uid"
    })), n.d(t, "kNumMidiChannels", (function() {
        return 16
    })), n.d(t, "kNumMidiPitchValues", (function() {
        return 127
    })), n.d(t, "kNumMidiVelocityValues", (function() {
        return 127
    })), n.d(t, "kNumMidiMessgeBytes", (function() {
        return 3
    })), n.d(t, "kMidiStatusOn", (function() {
        return c
    })), n.d(t, "kMidiStatusOff", (function() {
        return l
    })), n.d(t, "kChunkData", (function() {
        return "chunk_data"
    })), n.d(t, "kEnabled", (function() {
        return "enabled"
    })), n.d(t, "kExternalSDKInstanceID", (function() {
        return "external_sdk_instance_id"
    })), n.d(t, "kFrozen", (function() {
        return "frozen"
    })), n.d(t, "kInsertType", (function() {
        return "insert_type"
    })), n.d(t, "kLLMEnabled", (function() {
        return "llm_enabled"
    })), n.d(t, "kPluginContentError", (function() {
        return "plugin_content_error"
    })), n.d(t, "kPluginError", (function() {
        return "plugin_error"
    })), n.d(t, "kPluginID", (function() {
        return "plugin_id"
    })), n.d(t, "kPluginLicenseError", (function() {
        return "plugin_license_error"
    })), n.d(t, "kPluginName", (function() {
        return "plugin_name"
    })), n.d(t, "kPluginPower", (function() {
        return "plugin_power"
    })), n.d(t, "kPresetUIDDirty", (function() {
        return "preset_uid_dirty"
    })), n.d(t, "kPresetName", (function() {
        return "preset_name"
    })), n.d(t, "kPresetUID", (function() {
        return "preset_uid"
    })), n.d(t, "kStemFormat", (function() {
        return "stem_format"
    })), n.d(t, "kOutputStemFormat", (function() {
        return "output_stem_format"
    })), n.d(t, "kRowID", (function() {
        return "rowid"
    })), n.d(t, "kSidechainAllowed", (function() {
        return "sidechain_allowed"
    })), n.d(t, "kSidechainInUse", (function() {
        return "sidechain_in_use"
    })), n.d(t, "kState", (function() {
        return "state"
    })), n.d(t, "kTrackUID", (function() {
        return "track_uid"
    })), n.d(t, "MidiMessageType", (function() {
        return u
    })), n.d(t, "MidiByteType", (function() {
        return h
    })), n.d(t, "validPropertyKeys", (function() {
        return d
    })), n.d(t, "kPropfilter", (function() {
        return p
    })), n.d(t, "validPropinfoKeys", (function() {
        return f
    })), n.d(t, "allowedSelfMessageCommands", (function() {
        return g
    })), n.d(t, "isTSelector", (function() {
        return m
    })), n.d(t, "isTClientError", (function() {
        return v
    })), n.d(t, "logSessionStorage", (function() {
        return w
    })), n.d(t, "validateUANetPath", (function() {
        return k
    })), n.d(t, "subtractIntersectionFromSetA", (function() {
        return x
    })), n.d(t, "generateUUID", (function() {
        return _
    })), n.d(t, "generateSeed", (function() {
        return S
    })), n.d(t, "warnIfNotAString", (function() {
        return O
    })), n.d(t, "stringJoin", (function() {
        return C
    })), n.d(t, "stringArrayJoin", (function() {
        return A
    })), n.d(t, "objectToQueryString", (function() {
        return T
    })), n.d(t, "lookupUrlObj", (function() {
        return j
    })), n.d(t, "getURLArgs", (function() {
        return M
    })), n.d(t, "isChannelStereo", (function() {
        return L
    })), n.d(t, "createMidiMessage", (function() {
        return Z
    })), n.d(t, "getMidiKeys", (function() {
        return ee
    })), n.d(t, "getMidiKeysFromSampleEngine", (function() {
        return te
    })), n.d(t, "reconnectMilliseconds", (function() {
        return 100
    })), n.d(t, "responseTimeoutMilliseconds", (function() {
        return 1e3
    })), n.d(t, "maxReconnectAttempts", (function() {
        return 1
    })), n.d(t, "websocketErrorCodeClosedByUser", (function() {
        return 4e3
    })), n.d(t, "kData", (function() {
        return "data"
    })), n.d(t, "kName", (function() {
        return "name"
    })), n.d(t, "kSeparator", (function() {
        return "/"
    })), n.d(t, "kRoot", (function() {
        return "root"
    })), n.d(t, "kPath", (function() {
        return "path"
    })), n.d(t, "kEffects", (function() {
        return s
    })), n.d(t, "kDiscrete", (function() {
        return "discrete"
    })), n.d(t, "kNumStepsVal", (function() {
        return "num_steps"
    })), n.d(t, "kChildren", (function() {
        return "children"
    })), n.d(t, "kProperties", (function() {
        return "properties"
    })), n.d(t, "kNormalizedValue", (function() {
        return "normalized_value"
    })), n.d(t, "kStringValues", (function() {
        return "string_values"
    })), n.d(t, "kRealValues", (function() {
        return "real_values"
    })), n.d(t, "kStringValue", (function() {
        return "string_value"
    })), n.d(t, "kRealValue", (function() {
        return "real_value"
    })), n.d(t, "kTouchCount", (function() {
        return "touch_count"
    })), n.d(t, "kBooleanValue", (function() {
        return "boolean_value"
    })), n.d(t, "kValue", (function() {
        return "value"
    })), n.d(t, "kReadOnly", (function() {
        return "read_only"
    })), n.d(t, "kURLParameters", (function() {
        return "url_parameters"
    })), n.d(t, "kAdded", (function() {
        return "added"
    })), n.d(t, "kRemoved", (function() {
        return "removed"
    })), n.d(t, "kClient", (function() {
        return "client"
    })), n.d(t, "kClientConnected", (function() {
        return "client_connected"
    })), n.d(t, "kClientDisconnected", (function() {
        return "client_disconnected"
    })), n.d(t, "kClientError", (function() {
        return "client_error"
    })), n.d(t, "kClientMessage", (function() {
        return "client_message"
    })), n.d(t, "kSelector", (function() {
        return "selector"
    })), n.d(t, "kID", (function() {
        return "id"
    })), n.d(t, "kVal", (function() {
        return "val"
    })), n.d(t, "kType", (function() {
        return "type"
    })), n.d(t, "kValueType", (function() {
        return "value_type"
    })), n.d(t, "kDirty", (function() {
        return "dirty"
    })), n.d(t, "kParam", (function() {
        return "param"
    })), n.d(t, "kParameters", (function() {
        return "parameters"
    })), n.d(t, "kPresetCMRParam", (function() {
        return "preset_cmr_param"
    })), n.d(t, "kChannelArea", (function() {
        return "channel_area"
    })), n.d(t, "kChannelArea_Master", (function() {
        return "channel_area_master"
    })), n.d(t, "kChannelArea_Channel", (function() {
        return "channel_area_channel"
    })), n.d(t, "kCommandAction", (function() {
        return "cmd_action"
    })), n.d(t, "kAction_HandleCallbacks", (function() {
        return "handle_callbacks"
    })), n.d(t, "kAction_IgnoreCallbacks", (function() {
        return "ignore_callbacks"
    })), n.d(t, "kCommandListener", (function() {
        return "cmd_listener"
    })), n.d(t, "kMessageID", (function() {
        return "message_id"
    })), n.d(t, "kSetTouch", (function() {
        return "set_touch"
    })), n.d(t, "kSetDefault", (function() {
        return o
    })), n.d(t, "kControl", (function() {
        return "control"
    })), n.d(t, "kControls", (function() {
        return a
    })), n.d(t, "kPrivateData", (function() {
        return "private_data"
    })), n.d(t, "kMeter", (function() {
        return "meter"
    })), n.d(t, "kMeters", (function() {
        return "meters"
    })), n.d(t, "kMeterValues", (function() {
        return "meter_values"
    })), n.d(t, "kLevel", (function() {
        return "level"
    })), n.d(t, "kCommands", (function() {
        return "commands"
    })), n.d(t, "kSendMidi", (function() {
        return "send_midi"
    })), n.d(t, "kFullPath", (function() {
        return "full_path"
    })), n.d(t, "kValueOnly", (function() {
        return "value_only"
    })), n.d(t, "kAllProperties", (function() {
        return "all_properties"
    })), n.d(t, "kEffectControl", (function() {
        return "effect_control"
    })), n.d(t, "kEffectControls", (function() {
        return "effect_controls"
    })), n.d(t, "kInstrument", (function() {
        return "instrument"
    })), n.d(t, "kEffect", (function() {
        return "effect"
    })), n.d(t, "kFolder", (function() {
        return "folder"
    })), n.d(t, "kAutomation", (function() {
        return "automation"
    })), n.d(t, "kCustom", (function() {
        return "custom"
    })), n.d(t, "kUID", (function() {
        return "uid"
    })), n.d(t, "kNumMidiChannels", (function() {
        return 16
    })), n.d(t, "kNumMidiPitchValues", (function() {
        return 127
    })), n.d(t, "kNumMidiVelocityValues", (function() {
        return 127
    })), n.d(t, "kNumMidiMessgeBytes", (function() {
        return 3
    })), n.d(t, "kMidiStatusOn", (function() {
        return c
    })), n.d(t, "kMidiStatusOff", (function() {
        return l
    })), n.d(t, "kChunkData", (function() {
        return "chunk_data"
    })), n.d(t, "kEnabled", (function() {
        return "enabled"
    })), n.d(t, "kExternalSDKInstanceID", (function() {
        return "external_sdk_instance_id"
    })), n.d(t, "kFrozen", (function() {
        return "frozen"
    })), n.d(t, "kInsertType", (function() {
        return "insert_type"
    })), n.d(t, "kLLMEnabled", (function() {
        return "llm_enabled"
    })), n.d(t, "kPluginContentError", (function() {
        return "plugin_content_error"
    })), n.d(t, "kPluginError", (function() {
        return "plugin_error"
    })), n.d(t, "kPluginID", (function() {
        return "plugin_id"
    })), n.d(t, "kPluginLicenseError", (function() {
        return "plugin_license_error"
    })), n.d(t, "kPluginName", (function() {
        return "plugin_name"
    })), n.d(t, "kPluginPower", (function() {
        return "plugin_power"
    })), n.d(t, "kPresetUIDDirty", (function() {
        return "preset_uid_dirty"
    })), n.d(t, "kPresetName", (function() {
        return "preset_name"
    })), n.d(t, "kPresetUID", (function() {
        return "preset_uid"
    })), n.d(t, "kStemFormat", (function() {
        return "stem_format"
    })), n.d(t, "kOutputStemFormat", (function() {
        return "output_stem_format"
    })), n.d(t, "kRowID", (function() {
        return "rowid"
    })), n.d(t, "kSidechainAllowed", (function() {
        return "sidechain_allowed"
    })), n.d(t, "kSidechainInUse", (function() {
        return "sidechain_in_use"
    })), n.d(t, "kState", (function() {
        return "state"
    })), n.d(t, "kTrackUID", (function() {
        return "track_uid"
    })), n.d(t, "MidiMessageType", (function() {
        return u
    })), n.d(t, "MidiByteType", (function() {
        return h
    })), n.d(t, "validPropertyKeys", (function() {
        return d
    })), n.d(t, "kPropfilter", (function() {
        return p
    })), n.d(t, "validPropinfoKeys", (function() {
        return f
    })), n.d(t, "allowedSelfMessageCommands", (function() {
        return g
    })), n.d(t, "isTSelector", (function() {
        return m
    })), n.d(t, "isTClientError", (function() {
        return v
    })), n.d(t, "logSessionStorage", (function() {
        return w
    })), n.d(t, "Client", (function() {
        return I
    })), n.d(t, "MixerBase", (function() {
        return X
    })), n.d(t, "ValueCreator", (function() {
        return re
    })), n.d(t, "PathSearchType", (function() {
        return Q
    })), n.d(t, "PathParser", (function() {
        return J
    })), n.d(t, "Value", (function() {
        return ie
    })), n.d(t, "Connection", (function() {
        return oe
    })), n.d(t, "ConnectionListeners", (function() {
        return $
    })), n.d(t, "extractMultiMessage", (function() {
        return F
    })), n.d(t, "expandMultiMessage", (function() {
        return U
    })), n.d(t, "stringifyForNetProto", (function() {
        return W
    })), n.d(t, "TextMessageFormat", (function() {
        return q
    })), n.d(t, "UALog", (function() {
        return ae
    })), n.d(t, "TextConnection", (function() {
        return G
    })), n.d(t, "TransportError", (function() {
        return P
    })), n.d(t, "WebsocketTransport", (function() {
        return Y
    }))
});
