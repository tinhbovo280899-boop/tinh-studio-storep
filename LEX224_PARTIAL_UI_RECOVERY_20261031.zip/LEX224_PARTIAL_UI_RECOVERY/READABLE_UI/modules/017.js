// Extracted webpack module 17. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return r
    }));
    var i = n(1);

    function r(e) {
        e.prototype.skinType = e, Object(i.bindable)({
            attribute: "skin"
        })(e.prototype, "skin")
    }
});
