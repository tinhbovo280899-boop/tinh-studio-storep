// Extracted webpack module 42. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return i
        })), n.d(t, "b", (function() {
            return m
        }));
        var i, r = n(0),
            s = n(1),
            o = n(5),
            a = n(84),
            c = n(3),
            l = n(4),
            u = n.n(l),
            h = n(16),
            d = n(8),
            p = n(9);
        ! function(e) {
            e.label = "label", e.h1 = "h1", e.h2 = "h2", e.h3 = "h3", e.h4 = "h4", e.h5 = "h5", e.h6 = "h6"
        }(i || (i = {}));
        let f = a;
        c.i && (f = u.a.readFileSync(u.a.resolve(e, "./ua-text.html"), "utf-8"));
        const g = Object.assign({}, d.a);
        let m = class extends d.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = g, this.level = i.label, this.valueType = o.c.string, this.emptyValue = "---", this.$textWrapper = null, this.initClassState()
            }
            hardwareAcceleratedChanged() {}
            getHardwareAcceleratedDisplay() {
                return this.element
            }
            binding() {
                this.levelChanged()
            }
            configureFromUANet(e, t, n) {
                n.valueType = this.valueType
            }
            setUANetValue(e, t) {
                this.element.innerText = null == t || "" === t ? this.emptyValue : t
            }
            getUANetValue() {
                return this.element.innerText
            }
            levelChanged() {
                const e = this.$controller.projector.provideEncapsulationSource();
                null !== this.$textWrapper && this.$textWrapper.remove(), this.$textWrapper = document.createElement(this.level), this.$textWrapper.className = "no-select", this.$textWrapper.appendChild(document.createElement("slot")), this.$textWrapper.style.fontSize = "inherit", this.$textWrapper.style.fontWeight = "inherit", e.appendChild(this.$textWrapper)
            }
        };
        Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], m.prototype, "level", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], m.prototype, "valueType", void 0), Object(r.__decorate)([s.bindable, Object(r.__metadata)("design:type", String)], m.prototype, "emptyValue", void 0), m = Object(r.__decorate)([c.i ? Object(s.customElement)({
            name: "ua-text",
            template: f
        }) : Object(s.customElement)(f), Object(r.__metadata)("design:paramtypes", [HTMLElement, h.a, p.a])], m)
    }).call(this, "/")
});
