// Extracted webpack module 1. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i, r = n(2),
        s = n(0);

    function o() {
        return function(e) {
            const t = e.prototype;
            t._subscriberFlags = 0, t.addSubscriber = l, t.removeSubscriber = d, t.hasSubscriber = b, t.hasSubscribers = g, t.callSubscribers = k, void 0 === t.subscribe && (t.subscribe = l), void 0 === t.unsubscribe && (t.unsubscribe = d)
        }
    }

    function a() {
        return function(e) {
            const t = e.prototype;
            t._proxySubscriberFlags = 0, t.addProxySubscriber = u, t.removeProxySubscriber = p, t.hasProxySubscriber = y, t.hasProxySubscribers = m, t.callProxySubscribers = _, void 0 === t.subscribeToProxy && (t.subscribeToProxy = u), void 0 === t.unsubscribeFromProxy && (t.unsubscribeFromProxy = p)
        }
    }

    function c() {
        return function(e) {
            const t = e.prototype;
            t._collectionSubscriberFlags = 0, t.addCollectionSubscriber = h, t.removeCollectionSubscriber = f, t.hasCollectionSubscriber = w, t.hasCollectionSubscribers = v, t.callCollectionSubscribers = S, void 0 === t.subscribeToCollection && (t.subscribeToCollection = h), void 0 === t.unsubscribeFromCollection && (t.unsubscribeFromCollection = f)
        }
    }

    function l(e) {
        if (this.hasSubscriber(e)) return !1;
        const t = this._subscriberFlags;
        return 0 == (1 & t) ? (this._subscriber0 = e, this._subscriberFlags |= 1) : 0 == (2 & t) ? (this._subscriber1 = e, this._subscriberFlags |= 2) : 0 == (4 & t) ? (this._subscriber2 = e, this._subscriberFlags |= 4) : 0 == (8 & t) ? (this._subscribersRest = [e], this._subscriberFlags |= 8) : this._subscribersRest.push(e), !0
    }

    function u(e) {
        if (this.hasProxySubscriber(e)) return !1;
        const t = this._proxySubscriberFlags;
        return 0 == (1 & t) ? (this._proxySubscriber0 = e, this._proxySubscriberFlags |= 1) : 0 == (2 & t) ? (this._proxySubscriber1 = e, this._proxySubscriberFlags |= 2) : 0 == (4 & t) ? (this._proxySubscriber2 = e, this._proxySubscriberFlags |= 4) : 0 == (8 & t) ? (this._proxySubscribersRest = [e], this._proxySubscriberFlags |= 8) : this._proxySubscribersRest.push(e), !0
    }

    function h(e) {
        if (this.hasCollectionSubscriber(e)) return !1;
        const t = this._collectionSubscriberFlags;
        return 0 == (1 & t) ? (this._collectionSubscriber0 = e, this._collectionSubscriberFlags |= 1) : 0 == (2 & t) ? (this._collectionSubscriber1 = e, this._collectionSubscriberFlags |= 2) : 0 == (4 & t) ? (this._collectionSubscriber2 = e, this._collectionSubscriberFlags |= 4) : 0 == (8 & t) ? (this._collectionSubscribersRest = [e], this._collectionSubscriberFlags |= 8) : this._collectionSubscribersRest.push(e), !0
    }

    function d(e) {
        const t = this._subscriberFlags;
        if ((1 & t) > 0 && this._subscriber0 === e) return this._subscriber0 = void 0, this._subscriberFlags = 1 ^ (1 | this._subscriberFlags), !0;
        if ((2 & t) > 0 && this._subscriber1 === e) return this._subscriber1 = void 0, this._subscriberFlags = 2 ^ (2 | this._subscriberFlags), !0;
        if ((4 & t) > 0 && this._subscriber2 === e) return this._subscriber2 = void 0, this._subscriberFlags = 4 ^ (4 | this._subscriberFlags), !0;
        if ((8 & t) > 0) {
            const t = this._subscribersRest;
            for (let n = 0, i = t.length; n < i; ++n)
                if (t[n] === e) return t.splice(n, 1), 1 === i && (this._subscriberFlags = 8 ^ (8 | this._subscriberFlags)), !0
        }
        return !1
    }

    function p(e) {
        const t = this._proxySubscriberFlags;
        if ((1 & t) > 0 && this._proxySubscriber0 === e) return this._proxySubscriber0 = void 0, this._proxySubscriberFlags = 1 ^ (1 | this._proxySubscriberFlags), !0;
        if ((2 & t) > 0 && this._proxySubscriber1 === e) return this._proxySubscriber1 = void 0, this._proxySubscriberFlags = 2 ^ (2 | this._proxySubscriberFlags), !0;
        if ((4 & t) > 0 && this._proxySubscriber2 === e) return this._proxySubscriber2 = void 0, this._proxySubscriberFlags = 4 ^ (4 | this._proxySubscriberFlags), !0;
        if ((8 & t) > 0) {
            const t = this._proxySubscribersRest;
            for (let n = 0, i = t.length; n < i; ++n)
                if (t[n] === e) return t.splice(n, 1), 1 === i && (this._proxySubscriberFlags = 8 ^ (8 | this._proxySubscriberFlags)), !0
        }
        return !1
    }

    function f(e) {
        const t = this._collectionSubscriberFlags;
        if ((1 & t) > 0 && this._collectionSubscriber0 === e) return this._collectionSubscriber0 = void 0, this._collectionSubscriberFlags = 1 ^ (1 | this._collectionSubscriberFlags), !0;
        if ((2 & t) > 0 && this._collectionSubscriber1 === e) return this._collectionSubscriber1 = void 0, this._collectionSubscriberFlags = 2 ^ (2 | this._collectionSubscriberFlags), !0;
        if ((4 & t) > 0 && this._collectionSubscriber2 === e) return this._collectionSubscriber2 = void 0, this._collectionSubscriberFlags = 4 ^ (4 | this._collectionSubscriberFlags), !0;
        if ((8 & t) > 0) {
            const t = this._collectionSubscribersRest;
            for (let n = 0, i = t.length; n < i; ++n)
                if (t[n] === e) return t.splice(n, 1), 1 === i && (this._collectionSubscriberFlags = 8 ^ (8 | this._collectionSubscriberFlags)), !0
        }
        return !1
    }

    function g() {
        return 0 !== this._subscriberFlags
    }

    function m() {
        return 0 !== this._proxySubscriberFlags
    }

    function v() {
        return 0 !== this._collectionSubscriberFlags
    }

    function b(e) {
        const t = this._subscriberFlags;
        if ((1 & t) > 0 && this._subscriber0 === e) return !0;
        if ((2 & t) > 0 && this._subscriber1 === e) return !0;
        if ((4 & t) > 0 && this._subscriber2 === e) return !0;
        if ((8 & t) > 0) {
            const t = this._subscribersRest;
            for (let n = 0, i = t.length; n < i; ++n)
                if (t[n] === e) return !0
        }
        return !1
    }

    function y(e) {
        const t = this._proxySubscriberFlags;
        if ((1 & t) > 0 && this._proxySubscriber0 === e) return !0;
        if ((2 & t) > 0 && this._proxySubscriber1 === e) return !0;
        if ((4 & t) > 0 && this._proxySubscriber2 === e) return !0;
        if ((8 & t) > 0) {
            const t = this._proxySubscribersRest;
            for (let n = 0, i = t.length; n < i; ++n)
                if (t[n] === e) return !0
        }
        return !1
    }

    function w(e) {
        const t = this._collectionSubscriberFlags;
        if ((1 & t) > 0 && this._collectionSubscriber0 === e) return !0;
        if ((2 & t) > 0 && this._collectionSubscriber1 === e) return !0;
        if ((4 & t) > 0 && this._collectionSubscriber2 === e) return !0;
        if ((8 & t) > 0) {
            const t = this._collectionSubscribersRest;
            for (let n = 0, i = t.length; n < i; ++n)
                if (t[n] === e) return !0
        }
        return !1
    }

    function k(e, t, n) {
        const i = this._subscriber0,
            r = this._subscriber1,
            s = this._subscriber2;
        let o = this._subscribersRest;
        if (void 0 !== o && (o = o.slice()), void 0 !== i && x(i, e, t, n, void 0 === i.id ? 0 : this[i.id]), void 0 !== r && x(r, e, t, n, void 0 === r.id ? 0 : this[r.id]), void 0 !== s && x(s, e, t, n, void 0 === s.id ? 0 : this[s.id]), void 0 !== o) {
            const {
                length: i
            } = o;
            let r;
            for (let s = 0; s < i; ++s) r = o[s], void 0 !== r && x(r, e, t, n, void 0 === r.id ? 0 : this[r.id])
        }
    }

    function x(e, t, n, i, r) {
        e.handleChange(t, n, 48 ^ (48 | i) | r)
    }

    function _(e, t, n, i) {
        const r = this._proxySubscriber0,
            s = this._proxySubscriber1,
            o = this._proxySubscriber2;
        let a = this._proxySubscribersRest;
        if (void 0 !== a && (a = a.slice()), void 0 !== r && r.handleProxyChange(e, t, n, i), void 0 !== s && s.handleProxyChange(e, t, n, i), void 0 !== o && o.handleProxyChange(e, t, n, i), void 0 !== a) {
            const {
                length: r
            } = a;
            let s;
            for (let o = 0; o < r; ++o) s = a[o], void 0 !== s && s.handleProxyChange(e, t, n, i)
        }
    }

    function S(e, t) {
        const n = this._collectionSubscriber0,
            i = this._collectionSubscriber1,
            r = this._collectionSubscriber2;
        let s = this._collectionSubscribersRest;
        if (void 0 !== s && (s = s.slice()), void 0 !== n && n.handleCollectionChange(e, t), void 0 !== i && i.handleCollectionChange(e, t), void 0 !== r && r.handleCollectionChange(e, t), void 0 !== s) {
            const {
                length: n
            } = s;
            let i;
            for (let r = 0; r < n; ++r) i = s[r], void 0 !== i && i.handleCollectionChange(e, t)
        }
    }
    Array.prototype.slice;
    const O = new WeakMap;
    let C = class {
        constructor(e, t, n) {
            this.inBatch = !1, this.raw = t, this.key = n, this.proxy = e, this.subscribe = this.addSubscriber, this.unsubscribe = this.removeSubscriber, t[n] instanceof Object && (t[n] = A.getOrCreate(t[n]).proxy)
        }
        setValue(e, t) {
            const n = this.raw[this.key];
            n !== e && (this.raw[this.key] = e, this.callSubscribers(e, n, 18 | t))
        }
        getValue() {
            return this.raw[this.key]
        }
        flushBatch(e) {}
    };
    C = Object(s.__decorate)([o()], C);
    let A = i = class {
        constructor(e) {
            this.raw = e, this.proxy = new Proxy(e, this), O.set(e, this.proxy), this.subscribers = {}
        }
        static getProxyOrSelf(e) {
            if (void 0 === e.$raw) {
                const t = O.get(e);
                return void 0 === t ? e : t
            }
            return e
        }
        static getRawIfProxy(e) {
            const t = e.$raw;
            return void 0 === t ? e : t
        }
        static getOrCreate(e, t) {
            let n;
            if (void 0 === e.$raw) {
                const t = O.get(e);
                n = void 0 === t ? new i(e) : t.$observer
            } else n = e.$observer;
            if (void 0 === t) return n;
            let r = n.subscribers[t];
            if (void 0 === r) {
                const i = this.getRawIfProxy(e),
                    s = n.proxy;
                r = n.subscribers[t] = new C(s, i, t)
            }
            return r
        }
        static isProxy(e) {
            return void 0 !== e.$raw
        }
        get(e, t, n) {
            return "$observer" === t ? this : "$raw" === t ? e : e[t]
        }
        set(e, t, n, i) {
            const r = e[t];
            return r !== n && (e[t] = n, this.callPropertySubscribers(n, r, t), this.callProxySubscribers(t, n, r, 18)), !0
        }
        deleteProperty(e, t) {
            const n = e[t];
            return !!Reflect.deleteProperty(e, t) && (void 0 !== n && (this.callPropertySubscribers(void 0, n, t), this.callProxySubscribers(t, void 0, n, 18)), !0)
        }
        defineProperty(e, t, n) {
            const i = e[t];
            return !!Reflect.defineProperty(e, t, n) && (n.value !== i && (this.callPropertySubscribers(n.value, i, t), this.callProxySubscribers(t, n.value, i, 18)), !0)
        }
        apply(e, t, n = r.g.emptyArray) {
            return Reflect.apply(e, e, n)
        }
        subscribe(e, t) {
            if (void 0 === t) this.addProxySubscriber(e);
            else {
                let n = this.subscribers[t];
                void 0 === n && (n = this.subscribers[t] = new C(this.proxy, this.raw, t)), n.addSubscriber(e)
            }
        }
        unsubscribe(e, t) {
            if (void 0 === t) this.removeProxySubscriber(e);
            else {
                const n = this.subscribers[t];
                void 0 !== n && n.removeSubscriber(e)
            }
        }
        callPropertySubscribers(e, t, n) {
            const i = this.subscribers[n];
            void 0 !== i && i.callSubscribers(e, t, 18)
        }
    };
    A = i = Object(s.__decorate)([a()], A);
    let T = class {
        constructor(e, t, n, i) {
            this.lifecycle = e, this.obj = n, this.propertyKey = i, this.currentValue = void 0, this.oldValue = void 0, this.inBatch = !1, this.observing = !1, this.persistentFlags = 2080374799 & t
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            if (this.observing) {
                const n = this.currentValue;
                this.currentValue = e, 0 === this.lifecycle.batch.depth ? this.callSubscribers(e, n, this.persistentFlags | t) : this.inBatch || (this.inBatch = !0, this.oldValue = n, this.lifecycle.batch.add(this))
            } else this.obj[this.propertyKey] = e
        }
        flushBatch(e) {
            this.inBatch = !1;
            const t = this.currentValue,
                n = this.oldValue;
            this.oldValue = t, this.callSubscribers(t, n, this.persistentFlags | e)
        }
        subscribe(e) {
            !1 === this.observing && (this.observing = !0, this.currentValue = this.obj[this.propertyKey], Reflect.defineProperty(this.obj, this.propertyKey, {
                enumerable: !0,
                configurable: !0,
                get: () => this.getValue(),
                set: e => {
                    this.setValue(e, 0)
                }
            }) || r.k.write(1, this.propertyKey, this.obj)), this.addSubscriber(e)
        }
    };
    T = Object(s.__decorate)([o()], T);
    Array.prototype.slice;
    var E;
    ! function(e) {
        e[e.NilScope = 250] = "NilScope", e[e.NilOverrideContext = 252] = "NilOverrideContext", e[e.NilParentScope = 253] = "NilParentScope"
    }(E || (E = {}));
    const j = Object.freeze({});
    class M {
        getOrCreate(e, t, n, i) {
            return void 0 === this[i] && (this[i] = new T(e, t, n, i)), this[i]
        }
    }
    class L {
        constructor(e, t) {
            if (this.$synthetic = !0, void 0 !== e)
                if (void 0 !== t) this[e] = t;
                else
                    for (const t in e) Object.prototype.hasOwnProperty.call(e, t) && (this[t] = e[t])
        }
        static create(e, t, n) {
            const i = new L(t, n);
            return 2 & e ? A.getOrCreate(i).proxy : i
        }
        static get(e, t, n, i, s) {
            if (null == e) throw r.k.error(250);
            let o = e.overrideContext;
            if (n > 0) {
                for (; n > 0;) {
                    if (null == o.parentOverrideContext) return;
                    n--, o = o.parentOverrideContext
                }
                return t in o ? o : o.bindingContext
            }
            for (; o && !(t in o) && (!o.bindingContext || !(t in o.bindingContext));) o = o.parentOverrideContext;
            if (o) return t in o ? o : o.bindingContext;
            if ((67108864 & i) > 0) {
                let r = e.parentScope;
                for (; null !== r;) {
                    if (r.scopeParts.includes(s)) {
                        const s = this.get(r, t, n, -67108865 & i | 4194304);
                        return s === j ? e.bindingContext || e.overrideContext : s
                    }
                    r = r.parentScope
                }
                if (null === r) throw new Error(`No target scope could be found for part "${s}"`)
            }
            return 4194304 & i ? j : e.bindingContext || e.overrideContext
        }
        getObservers(e) {
            return null == this.$observers && (this.$observers = new M), this.$observers
        }
    }
    class P {
        constructor(e, t, n) {
            this.parentScope = e, this.scopeParts = r.g.emptyArray, this.bindingContext = t, this.overrideContext = n
        }
        static create(e, t, n) {
            return new P(null, t, null == n ? R.create(e, t, n) : n)
        }
        static fromOverride(e, t) {
            if (null == t) throw r.k.error(252);
            return new P(null, t.bindingContext, t)
        }
        static fromParent(e, t, n) {
            if (null == t) throw r.k.error(253);
            return new P(t, n, R.create(e, n, t.overrideContext))
        }
    }
    class R {
        constructor(e, t) {
            this.$synthetic = !0, this.bindingContext = e, this.parentOverrideContext = t
        }
        static create(e, t, n) {
            return new R(t, void 0 === n ? null : n)
        }
        getObservers() {
            return void 0 === this.$observers && (this.$observers = new M), this.$observers
        }
    }
    const I = r.a.createInterface("ISignaler").withDefault(e => e.singleton(D));
    class D {
        constructor() {
            this.signals = Object.create(null)
        }
        dispatchSignal(e, t) {
            const n = this.signals[e];
            if (void 0 !== n)
                for (const e of n.keys()) e.handleChange(void 0, void 0, 16 | t)
        }
        addSignalListener(e, t) {
            const n = this.signals,
                i = n[e];
            void 0 === i ? n[e] = new Set([t]) : i.add(t)
        }
        removeSignalListener(e, t) {
            const n = this.signals[e];
            n && n.delete(t)
        }
    }
    var N;
    ! function(e) {
        e.hydrateElement = "ra", e.hydrateAttribute = "rb", e.hydrateTemplateController = "rc", e.hydrateLetElement = "rd", e.setProperty = "re", e.interpolation = "rf", e.propertyBinding = "rg", e.callBinding = "rh", e.letBinding = "ri", e.refBinding = "rj", e.iteratorBinding = "rk"
    }(N || (N = {}));
    const V = r.a.createInterface("ITargetedInstruction").noDefault();

    function $(e) {
        const t = e.type;
        return "string" == typeof t && 2 === t.length
    }
    class F {
        constructor(e) {
            this.hasRender = "render" in e, this.hasCreated = "created" in e, this.hasBinding = "binding" in e, this.hasBound = "bound" in e, this.hasUnbinding = "unbinding" in e, this.hasUnbound = "unbound" in e, this.hasAttaching = "attaching" in e, this.hasAttached = "attached" in e, this.hasDetaching = "detaching" in e, this.hasDetached = "detached" in e, this.hasCaching = "caching" in e
        }
    }

    function U(...e) {
        return function(t) {
            const n = r.i.annotation.keyFor("aliases"),
                i = r.f.getOwn(n, t);
            void 0 === i ? r.f.define(n, e, t) : i.push(...e)
        }
    }

    function B(e, t, n, i) {
        for (let s = 0, o = e.length; s < o; ++s) r.j.alias(n, t.keyFrom(e[s])).register(i)
    }

    function z(e) {
        return function(t) {
            return W.define(e, t)
        }
    }
    F.none = Object.freeze(new F({}));
    class H {
        constructor(e, t, n, i) {
            this.Type = e, this.name = t, this.aliases = n, this.key = i
        }
        static create(e, t) {
            let n, i;
            return "string" == typeof e ? (n = e, i = {
                name: n
            }) : (n = e.name, i = e), new H(t, Object(r.q)(W.getAnnotation(t, "name"), n), Object(r.z)(W.getAnnotation(t, "aliases"), i.aliases, t.aliases), W.keyFrom(n))
        }
        register(e) {
            const {
                Type: t,
                key: n,
                aliases: i
            } = this;
            r.j.singleton(n, t).register(e), r.j.alias(n, t).register(e), B(i, W, n, e)
        }
    }
    const W = {
        name: r.i.resource.keyFor("binding-behavior"),
        keyFrom: e => `${W.name}:${e}`,
        isType: e => "function" == typeof e && r.f.hasOwn(W.name, e),
        define(e, t) {
            const n = H.create(e, t);
            return r.f.define(W.name, n, n.Type), r.f.define(W.name, n, n), r.i.resource.appendTo(t, W.name), n.Type
        },
        getDefinition(e) {
            const t = r.f.getOwn(W.name, e);
            if (void 0 === t) throw new Error("No definition found for type " + e.name);
            return t
        },
        annotate(e, t, n) {
            r.f.define(r.i.annotation.keyFor(t), n, e)
        },
        getAnnotation: (e, t) => r.f.getOwn(r.i.annotation.keyFor(t), e)
    };

    function q(e) {
        return function(t) {
            return K.define(e, t)
        }
    }
    class G {
        constructor(e, t, n, i) {
            this.Type = e, this.name = t, this.aliases = n, this.key = i
        }
        static create(e, t) {
            let n, i;
            return "string" == typeof e ? (n = e, i = {
                name: n
            }) : (n = e.name, i = e), new G(t, Object(r.q)(K.getAnnotation(t, "name"), n), Object(r.z)(K.getAnnotation(t, "aliases"), i.aliases, t.aliases), K.keyFrom(n))
        }
        register(e) {
            const {
                Type: t,
                key: n,
                aliases: i
            } = this;
            r.j.singleton(n, t).register(e), r.j.alias(n, t).register(e), B(i, K, n, e)
        }
    }
    const K = {
        name: r.i.resource.keyFor("value-converter"),
        keyFrom: e => `${K.name}:${e}`,
        isType: e => "function" == typeof e && r.f.hasOwn(K.name, e),
        define(e, t) {
            const n = G.create(e, t);
            return r.f.define(K.name, n, n.Type), r.f.define(K.name, n, n), r.i.resource.appendTo(t, K.name), n.Type
        },
        getDefinition(e) {
            const t = r.f.getOwn(K.name, e);
            if (void 0 === t) throw new Error("No definition found for type " + e.name);
            return t
        },
        annotate(e, t, n) {
            r.f.define(r.i.annotation.keyFor(t), n, e)
        },
        getAnnotation: (e, t) => r.f.getOwn(r.i.annotation.keyFor(t), e)
    };

    function Y(e) {
        return 32 == (32 & e.$kind)
    }

    function X(e) {
        return 64 == (64 & e.$kind)
    }

    function J(e) {
        return 128 == (128 & e.$kind)
    }

    function Q(e) {
        return 256 == (256 & e.$kind)
    }

    function Z(e) {
        return 8192 == (8192 & e.$kind)
    }

    function ee(e) {
        return 1024 == (1024 & e.$kind)
    }

    function te(e) {
        return 512 == (512 & e.$kind)
    }

    function ne(e) {
        return 32768 == (32768 & e.$kind)
    }

    function ie(e) {
        return 2048 == (2048 & e.$kind)
    }

    function re(e) {
        return 4096 == (4096 & e.$kind)
    }

    function se(e) {
        return 16384 == (16384 & e.$kind)
    }

    function oe(e) {
        if (void 0 === e || 0 === e.length) return !0;
        for (let t = 0; t < e.length; ++t)
            if (!ae(e[t])) return !1;
        return !0
    }

    function ae(e) {
        if (se(e)) switch (e.$kind) {
            case 17955:
                return oe(e.elements);
            case 17956:
                return oe(e.values);
            case 17958:
                return oe(e.expressions);
            case 17925:
                return !0
        }
        return !1
    }
    var ce;
    ! function(e) {
        e[e.NoLocator = 202] = "NoLocator", e[e.NoBehaviorFound = 203] = "NoBehaviorFound", e[e.BehaviorAlreadyApplied = 204] = "BehaviorAlreadyApplied", e[e.NoConverterFound = 205] = "NoConverterFound", e[e.NoBinding = 206] = "NoBinding", e[e.NotAFunction = 207] = "NotAFunction", e[e.UnknownOperator = 208] = "UnknownOperator", e[e.NilScope = 250] = "NilScope"
    }(ce || (ce = {}));
    class le {
        constructor(e) {
            this.value = e
        }
        evaluate(e, t, n, i) {
            return this.value
        }
    }
    class ue {
        constructor(e, t, n) {
            this.$kind = 38962, this.expression = e, this.name = t, this.args = n, this.behaviorKey = W.keyFrom(this.name)
        }
        evaluate(e, t, n, i) {
            return this.expression.evaluate(e, t, n, i)
        }
        assign(e, t, n, i, r) {
            return this.expression.assign(e, t, n, i, r)
        }
        connect(e, t, n, i) {
            this.expression.connect(e, t, n, i)
        }
        bind(e, t, n) {
            if (null == t) throw r.k.error(250, this);
            if (!n) throw r.k.error(206, this);
            const i = n.locator;
            if (!i) throw r.k.error(202, this);
            ie(this.expression) && this.expression.bind(e, t, n);
            const s = this.behaviorKey,
                o = i.get(s);
            if (!o) throw r.k.error(203, this);
            void 0 === n[s] ? (n[s] = o, o.bind.call(o, e, t, n, ...Ie(e, t, i, this.args))) : r.k.write(204, this)
        }
        unbind(e, t, n) {
            const i = this.behaviorKey;
            void 0 !== n[i] ? (n[i].unbind(e, t, n), n[i] = void 0) : r.k.write(204, this), re(this.expression) && this.expression.unbind(e, t, n)
        }
        accept(e) {
            return e.visitBindingBehavior(this)
        }
    }
    class he {
        constructor(e, t, n) {
            this.$kind = 36913, this.expression = e, this.name = t, this.args = n, this.converterKey = K.keyFrom(this.name)
        }
        evaluate(e, t, n, i) {
            if (!n) throw r.k.error(202, this);
            const s = n.get(this.converterKey);
            if (!s) throw r.k.error(205, this);
            if ("toView" in s) {
                const r = this.args,
                    o = r.length,
                    a = Array(o + 1);
                a[0] = this.expression.evaluate(e, t, n, i);
                for (let s = 0; s < o; ++s) a[s + 1] = r[s].evaluate(e, t, n, i);
                return s.toView.call(s, ...a)
            }
            return this.expression.evaluate(e, t, n, i)
        }
        assign(e, t, n, i, s) {
            if (!n) throw r.k.error(202, this);
            const o = n.get(this.converterKey);
            if (!o) throw r.k.error(205, this);
            return "fromView" in o && (i = o.fromView.call(o, i, ...Ie(e, t, n, this.args))), this.expression.assign(e, t, n, i, s)
        }
        connect(e, t, n, i) {
            if (null == t) throw r.k.error(250, this);
            if (!n) throw r.k.error(206, this);
            const s = n.locator;
            if (!s) throw r.k.error(202, this);
            this.expression.connect(e, t, n, i);
            const o = this.args;
            for (let r = 0, s = o.length; r < s; ++r) o[r].connect(e, t, n, i);
            const a = s.get(this.converterKey);
            if (!a) throw r.k.error(205, this);
            const c = a.signals;
            if (void 0 === c) return;
            const l = s.get(I);
            for (let e = 0, t = c.length; e < t; ++e) l.addSignalListener(c[e], n)
        }
        unbind(e, t, n) {
            const i = n.locator,
                r = i.get(this.converterKey).signals;
            if (void 0 === r) return;
            const s = i.get(I);
            for (let e = 0, t = r.length; e < t; ++e) s.removeSignalListener(r[e], n)
        }
        accept(e) {
            return e.visitValueConverter(this)
        }
    }
    class de {
        constructor(e, t) {
            this.$kind = 8208, this.target = e, this.value = t
        }
        evaluate(e, t, n, i) {
            return this.target.assign(e, t, n, this.value.evaluate(e, t, n), i)
        }
        connect(e, t, n, i) {}
        assign(e, t, n, i, r) {
            return this.value.assign(e, t, n, i, r), this.target.assign(e, t, n, i, r)
        }
        accept(e) {
            return e.visitAssign(this)
        }
    }
    class pe {
        constructor(e, t, n) {
            this.$kind = 63, this.assign = r.g.noop, this.condition = e, this.yes = t, this.no = n
        }
        evaluate(e, t, n, i) {
            return this.condition.evaluate(e, t, n, i) ? this.yes.evaluate(e, t, n, i) : this.no.evaluate(e, t, n, i)
        }
        connect(e, t, n, i) {
            this.condition.evaluate(e, t, null, i) ? (this.condition.connect(e, t, n, i), this.yes.connect(e, t, n, i)) : (this.condition.connect(e, t, n, i), this.no.connect(e, t, n, i))
        }
        accept(e) {
            return e.visitConditional(this)
        }
    }
    class fe {
        constructor(e = 0) {
            this.$kind = 1793, this.assign = r.g.noop, this.connect = r.g.noop, this.ancestor = e
        }
        evaluate(e, t, n, i) {
            if (null == t) throw r.k.error(250, this);
            if ((67108864 & e) > 0) {
                let e = t.parentScope;
                for (; null !== e;) e.scopeParts.includes(i) || (e = e.parentScope);
                if (null === e) throw new Error(`No target scope cold be found for part "${i}"`)
            }
            let s = t.overrideContext,
                o = this.ancestor;
            for (; o-- && s;) s = s.parentOverrideContext;
            return o < 1 && s ? s.bindingContext : void 0
        }
        accept(e) {
            return e.visitAccessThis(this)
        }
    }
    fe.$this = new fe(0), fe.$parent = new fe(1);
    class ge {
        constructor(e, t = 0) {
            this.$kind = 10082, this.name = e, this.ancestor = t
        }
        evaluate(e, t, n, i) {
            const r = L.get(t, this.name, this.ancestor, e, i)[this.name];
            return 4 & e ? r : null == r ? "" : r
        }
        assign(e, t, n, i, r) {
            const s = L.get(t, this.name, this.ancestor, e, r);
            if (s instanceof Object) return void 0 !== s.$observers && void 0 !== s.$observers[this.name] ? (s.$observers[this.name].setValue(i, e), i) : s[this.name] = i
        }
        connect(e, t, n, i) {
            const r = L.get(t, this.name, this.ancestor, e, i);
            n.observeProperty(e, r, this.name)
        }
        accept(e) {
            return e.visitAccessScope(this)
        }
    }
    class me {
        constructor(e, t) {
            this.$kind = 9323, this.object = e, this.name = t
        }
        evaluate(e, t, n, i) {
            const r = this.object.evaluate(e, t, n, i);
            return 4 & e ? null == r ? r : r[this.name] : r ? r[this.name] : ""
        }
        assign(e, t, n, i, r) {
            const s = this.object.evaluate(e, t, n, r);
            return s instanceof Object ? void 0 !== s.$observers && void 0 !== s.$observers[this.name] ? s.$observers[this.name].setValue(i, e) : s[this.name] = i : this.object.assign(e, t, n, {
                [this.name]: i
            }), i
        }
        connect(e, t, n, i) {
            const r = this.object.evaluate(e, t, null, i);
            0 == (134217728 & e) && this.object.connect(e, t, n, i), r instanceof Object && n.observeProperty(e, r, this.name)
        }
        accept(e) {
            return e.visitAccessMember(this)
        }
    }
    class ve {
        constructor(e, t) {
            this.$kind = 9324, this.object = e, this.key = t
        }
        evaluate(e, t, n, i) {
            const r = this.object.evaluate(e, t, n, i);
            if (r instanceof Object) {
                return r[this.key.evaluate(e, t, n, i)]
            }
        }
        assign(e, t, n, i, r) {
            return this.object.evaluate(e, t, n, r)[this.key.evaluate(e, t, n, r)] = i
        }
        connect(e, t, n, i) {
            const s = this.object.evaluate(e, t, null, i);
            if (0 == (134217728 & e) && this.object.connect(e, t, n, i), s instanceof Object) {
                this.key.connect(e, t, n, i);
                const o = this.key.evaluate(e, t, null, i);
                Array.isArray(s) && Object(r.w)(o) ? 2 & e && n.observeProperty(e, s, o) : n.observeProperty(e, s, o)
            }
        }
        accept(e) {
            return e.visitAccessKeyed(this)
        }
    }
    class be {
        constructor(e, t, n = 0) {
            this.$kind = 1448, this.assign = r.g.noop, this.name = e, this.args = t, this.ancestor = n
        }
        evaluate(e, t, n, i) {
            const r = Ie(e, t, n, this.args, i),
                s = L.get(t, this.name, this.ancestor, e, i),
                o = De(e, s, this.name);
            if (o) return o.apply(s, r)
        }
        connect(e, t, n, i) {
            const r = this.args;
            for (let s = 0, o = r.length; s < o; ++s) r[s].connect(e, t, n, i)
        }
        accept(e) {
            return e.visitCallScope(this)
        }
    }
    class ye {
        constructor(e, t, n) {
            this.$kind = 1161, this.assign = r.g.noop, this.object = e, this.name = t, this.args = n
        }
        evaluate(e, t, n, i) {
            const r = this.object.evaluate(e, t, n, i),
                s = Ie(e, t, n, this.args, i),
                o = De(e, r, this.name);
            if (o) return o.apply(r, s)
        }
        connect(e, t, n, i) {
            const r = this.object.evaluate(e, t, null, i);
            if (0 == (134217728 & e) && this.object.connect(e, t, n, i), De(-2097153 & e, r, this.name)) {
                const r = this.args;
                for (let s = 0, o = r.length; s < o; ++s) r[s].connect(e, t, n, i)
            }
        }
        accept(e) {
            return e.visitCallMember(this)
        }
    }
    class we {
        constructor(e, t) {
            this.$kind = 1162, this.assign = r.g.noop, this.func = e, this.args = t
        }
        evaluate(e, t, n, i) {
            const s = this.func.evaluate(e, t, n, i);
            if ("function" == typeof s) return s(...Ie(e, t, n, this.args, i));
            if (2097152 & e || null != s) throw r.k.error(207, this)
        }
        connect(e, t, n, i) {
            const r = this.func.evaluate(e, t, null, i);
            if (this.func.connect(e, t, n, i), "function" == typeof r) {
                const r = this.args;
                for (let s = 0, o = r.length; s < o; ++s) r[s].connect(e, t, n, i)
            }
        }
        accept(e) {
            return e.visitCallFunction(this)
        }
    }
    class ke {
        constructor(e, t, n) {
            this.$kind = 46, this.assign = r.g.noop, this.operation = e, this.left = t, this.right = n, this.evaluate = this[e]
        }
        evaluate(e, t, n, i) {
            throw r.k.error(208, this)
        }
        connect(e, t, n, i) {
            const r = this.left.evaluate(e, t, null, i);
            this.left.connect(e, t, n, i), "&&" === this.operation && !r || "||" === this.operation && r || this.right.connect(e, t, n, i)
        }
        "&&"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) && this.right.evaluate(e, t, n, i)
        }
        "||"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) || this.right.evaluate(e, t, n, i)
        }
        "=="(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) == this.right.evaluate(e, t, n, i)
        }
        "==="(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) === this.right.evaluate(e, t, n, i)
        }
        "!="(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) != this.right.evaluate(e, t, n, i)
        }
        "!=="(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) !== this.right.evaluate(e, t, n, i)
        }
        instanceof(e, t, n, i) {
            const r = this.right.evaluate(e, t, n, i);
            return "function" == typeof r && this.left.evaluate(e, t, n, i) instanceof r
        }
        in(e, t, n, i) {
            const r = this.right.evaluate(e, t, n, i);
            return r instanceof Object && this.left.evaluate(e, t, n, i) in r
        }
        "+"(e, t, n, i) {
            const s = this.left.evaluate(e, t, n, i),
                o = this.right.evaluate(e, t, n, i);
            if ((4 & e) > 0) return s + o;
            if (!s || !o) {
                if (Object(r.v)(s) || Object(r.v)(o)) return (s || 0) + (o || 0);
                if (Object(r.x)(s) || Object(r.x)(o)) return (s || "") + (o || "")
            }
            return s + o
        }
        "-"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) - this.right.evaluate(e, t, n, i)
        }
        "*"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) * this.right.evaluate(e, t, n, i)
        }
        "/"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) / this.right.evaluate(e, t, n, i)
        }
        "%"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) % this.right.evaluate(e, t, n, i)
        }
        "<"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) < this.right.evaluate(e, t, n, i)
        }
        ">"(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) > this.right.evaluate(e, t, n, i)
        }
        "<="(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) <= this.right.evaluate(e, t, n, i)
        }
        ">="(e, t, n, i) {
            return this.left.evaluate(e, t, n, i) >= this.right.evaluate(e, t, n, i)
        }
        accept(e) {
            return e.visitBinary(this)
        }
    }
    class xe {
        constructor(e, t) {
            this.$kind = 39, this.assign = r.g.noop, this.operation = e, this.expression = t, this.evaluate = this[e]
        }
        evaluate(e, t, n, i) {
            throw r.k.error(208, this)
        }
        connect(e, t, n, i) {
            this.expression.connect(e, t, n, i)
        }
        void(e, t, n, i) {
            this.expression.evaluate(e, t, n, i)
        }
        typeof(e, t, n, i) {
            return typeof this.expression.evaluate(4 | e, t, n, i)
        }
        "!"(e, t, n, i) {
            return !this.expression.evaluate(e, t, n, i)
        }
        "-"(e, t, n, i) {
            return -this.expression.evaluate(e, t, n, i)
        }
        "+"(e, t, n, i) {
            return +this.expression.evaluate(e, t, n, i)
        }
        accept(e) {
            return e.visitUnary(this)
        }
    }
    class _e {
        constructor(e) {
            this.$kind = 17925, this.assign = r.g.noop, this.connect = r.g.noop, this.value = e
        }
        evaluate(e, t, n, i) {
            return this.value
        }
        accept(e) {
            return e.visitPrimitiveLiteral(this)
        }
    }
    _e.$undefined = new _e(void 0), _e.$null = new _e(null), _e.$true = new _e(!0), _e.$false = new _e(!1), _e.$empty = new _e("");
    class Se {
        constructor(e) {
            this.$kind = 51, this.assign = r.g.noop, this.parts = e
        }
        evaluate(e, t, n, i) {
            const r = this.parts;
            let s, o = "";
            for (let a = 0, c = r.length; a < c; ++a) s = r[a].evaluate(e, t, n, i), null != s && (o += s);
            return o
        }
        connect(e, t, n, i) {
            for (let r = 0, s = this.parts.length; r < s; ++r) this.parts[r].connect(e, t, n, i)
        }
        accept(e) {
            return e.visitHtmlLiteral(this)
        }
    }
    class Oe {
        constructor(e) {
            this.$kind = 17955, this.assign = r.g.noop, this.elements = e
        }
        evaluate(e, t, n, i) {
            const r = this.elements,
                s = r.length,
                o = Array(s);
            for (let a = 0; a < s; ++a) o[a] = r[a].evaluate(e, t, n, i);
            return o
        }
        connect(e, t, n, i) {
            const r = this.elements;
            for (let s = 0, o = r.length; s < o; ++s) r[s].connect(e, t, n, i)
        }
        accept(e) {
            return e.visitArrayLiteral(this)
        }
    }
    Oe.$empty = new Oe(r.g.emptyArray);
    class Ce {
        constructor(e, t) {
            this.$kind = 17956, this.assign = r.g.noop, this.keys = e, this.values = t
        }
        evaluate(e, t, n, i) {
            const r = {},
                s = this.keys,
                o = this.values;
            for (let a = 0, c = s.length; a < c; ++a) r[s[a]] = o[a].evaluate(e, t, n, i);
            return r
        }
        connect(e, t, n, i) {
            const r = this.keys,
                s = this.values;
            for (let o = 0, a = r.length; o < a; ++o) s[o].connect(e, t, n, i)
        }
        accept(e) {
            return e.visitObjectLiteral(this)
        }
    }
    Ce.$empty = new Ce(r.g.emptyArray, r.g.emptyArray);
    class Ae {
        constructor(e, t) {
            this.$kind = 17958, this.assign = r.g.noop, this.cooked = e, this.expressions = void 0 === t ? r.g.emptyArray : t
        }
        evaluate(e, t, n, i) {
            const r = this.expressions,
                s = this.cooked;
            let o = s[0];
            for (let a = 0, c = r.length; a < c; ++a) o += r[a].evaluate(e, t, n, i), o += s[a + 1];
            return o
        }
        connect(e, t, n, i) {
            const r = this.expressions;
            for (let s = 0, o = r.length; s < o; ++s) r[s].connect(e, t, n, i), s++
        }
        accept(e) {
            return e.visitTemplate(this)
        }
    }
    Ae.$empty = new Ae([""]);
    class Te {
        constructor(e, t, n, i) {
            this.$kind = 1197, this.assign = r.g.noop, this.cooked = e, this.cooked.raw = t, this.func = n, this.expressions = void 0 === i ? r.g.emptyArray : i
        }
        evaluate(e, t, n, i) {
            const s = this.expressions,
                o = s.length,
                a = Array(o);
            for (let r = 0, c = o; r < c; ++r) a[r] = s[r].evaluate(e, t, n, i);
            const c = this.func.evaluate(e, t, n, i);
            if ("function" != typeof c) throw r.k.error(207, this);
            return c(this.cooked, ...a)
        }
        connect(e, t, n, i) {
            const r = this.expressions;
            for (let i = 0, s = r.length; i < s; ++i) r[i].connect(e, t, n);
            this.func.connect(e, t, n)
        }
        accept(e) {
            return e.visitTaggedTemplate(this)
        }
    }
    class Ee {
        constructor(e) {
            this.$kind = 65556, this.elements = e
        }
        evaluate(e, t, n, i) {}
        assign(e, t, n, i, r) {}
        connect(e, t, n, i) {}
        accept(e) {
            return e.visitArrayBindingPattern(this)
        }
    }
    class je {
        constructor(e, t) {
            this.$kind = 65557, this.keys = e, this.values = t
        }
        evaluate(e, t, n, i) {}
        assign(e, t, n, i, r) {}
        connect(e, t, n, i) {}
        accept(e) {
            return e.visitObjectBindingPattern(this)
        }
    }
    class Me {
        constructor(e) {
            this.$kind = 65558, this.name = e
        }
        evaluate(e, t, n, i) {
            return this.name
        }
        connect(e, t, n, i) {}
        accept(e) {
            return e.visitBindingIdentifier(this)
        }
    }
    const Le = Object.prototype.toString;
    class Pe {
        constructor(e, t) {
            this.$kind = 6199, this.assign = r.g.noop, this.declaration = e, this.iterable = t
        }
        evaluate(e, t, n, i) {
            return this.iterable.evaluate(e, t, n, i)
        }
        count(e, t) {
            switch (Le.call(t)) {
                case "[object Array]":
                    return t.length;
                case "[object Map]":
                case "[object Set]":
                    return t.size;
                case "[object Number]":
                    return t;
                case "[object Null]":
                case "[object Undefined]":
                    return 0;
                default:
                    throw r.k.error(0)
            }
        }
        iterate(e, t, n) {
            switch (Le.call(t)) {
                case "[object Array]":
                    return Ne(8388608 | e, t, n);
                case "[object Map]":
                    return function(e, t, n) {
                        const i = Array(t.size);
                        let r = -1;
                        for (const e of t.entries()) i[++r] = e;
                        Ne(-8388609 & e, i, n)
                    }(8388608 | e, t, n);
                case "[object Set]":
                    return function(e, t, n) {
                        const i = Array(t.size);
                        let r = -1;
                        for (const e of t.keys()) i[++r] = e;
                        Ne(-8388609 & e, i, n)
                    }(8388608 | e, t, n);
                case "[object Number]":
                    return function(e, t, n) {
                        const i = Array(t);
                        for (let e = 0; e < t; ++e) i[e] = e;
                        Ne(-8388609 & e, i, n)
                    }(8388608 | e, t, n);
                case "[object Null]":
                case "[object Undefined]":
                    return;
                default:
                    throw r.k.error(0)
            }
        }
        connect(e, t, n, i) {
            this.declaration.connect(e, t, n, i), this.iterable.connect(e, t, n, i)
        }
        bind(e, t, n) {
            ie(this.iterable) && this.iterable.bind(e, t, n)
        }
        unbind(e, t, n) {
            re(this.iterable) && this.iterable.unbind(e, t, n)
        }
        accept(e) {
            return e.visitForOfStatement(this)
        }
    }
    class Re {
        constructor(e, t) {
            this.$kind = 24, this.assign = r.g.noop, this.parts = e, this.expressions = void 0 === t ? r.g.emptyArray : t, this.isMulti = this.expressions.length > 1, this.firstExpression = this.expressions[0]
        }
        evaluate(e, t, n, i) {
            if (this.isMulti) {
                const r = this.expressions,
                    s = this.parts;
                let o = s[0];
                for (let a = 0, c = r.length; a < c; ++a) o += r[a].evaluate(e, t, n, i), o += s[a + 1];
                return o
            } {
                const r = this.parts;
                return r[0] + this.firstExpression.evaluate(e, t, n, i) + r[1]
            }
        }
        connect(e, t, n, i) {}
        accept(e) {
            return e.visitInterpolation(this)
        }
    }

    function Ie(e, t, n, i, r) {
        const s = i.length,
            o = Array(s);
        for (let a = 0; a < s; ++a) o[a] = i[a].evaluate(e, t, n, r);
        return o
    }

    function De(e, t, n) {
        const i = null == t ? null : t[n];
        if ("function" == typeof i) return i;
        if (!(2097152 & e) && null == i) return null;
        throw r.k.error(207, t, n, i)
    }

    function Ne(e, t, n) {
        if (8388610 == (8388610 & e)) {
            const e = A.getRawIfProxy(t),
                i = e.length;
            let r, s = 0;
            for (; s < i; ++s) r = e[s], r instanceof Object && (r = e[s] = A.getOrCreate(r).proxy), n(e, s, r)
        } else
            for (let e = 0, i = t.length; e < i; ++e) n(t, e, t[e])
    }
    var Ve, $e;
    ! function(e) {
        e[e.oneTime = 1] = "oneTime", e[e.toView = 2] = "toView", e[e.fromView = 4] = "fromView", e[e.twoWay = 6] = "twoWay", e[e.default = 8] = "default"
    }(Ve || (Ve = {})),
    function(e) {
        e[e.getterSetter = 1] = "getterSetter", e[e.proxies = 2] = "proxies"
    }($e || ($e = {}));
    var Fe, Ue, Be, ze, He;
    ! function(e) {
        e[e.none = 0] = "none", e[e.isBinding = 1] = "isBinding", e[e.isUnbinding = 2] = "isUnbinding", e[e.isBound = 4] = "isBound", e[e.isBoundOrBinding = 5] = "isBoundOrBinding", e[e.isBoundOrUnbinding = 6] = "isBoundOrUnbinding", e[e.isAttaching = 8] = "isAttaching", e[e.isDetaching = 16] = "isDetaching", e[e.isAttached = 32] = "isAttached", e[e.isAttachedOrAttaching = 40] = "isAttachedOrAttaching", e[e.isAttachedOrDetaching = 48] = "isAttachedOrDetaching", e[e.isMounted = 64] = "isMounted", e[e.isCached = 128] = "isCached", e[e.needsBind = 256] = "needsBind", e[e.needsUnbind = 512] = "needsUnbind", e[e.needsAttach = 1024] = "needsAttach", e[e.needsDetach = 2048] = "needsDetach", e[e.needsMount = 4096] = "needsMount", e[e.needsUnmount = 8192] = "needsUnmount", e[e.hasLockedScope = 16384] = "hasLockedScope", e[e.canBeCached = 32768] = "canBeCached", e[e.inBoundQueue = 65536] = "inBoundQueue", e[e.inUnboundQueue = 131072] = "inUnboundQueue", e[e.inAttachedQueue = 262144] = "inAttachedQueue", e[e.inDetachedQueue = 524288] = "inDetachedQueue", e[e.inMountQueue = 1048576] = "inMountQueue", e[e.inUnmountQueue = 2097152] = "inUnmountQueue"
    }(Fe || (Fe = {})),
    function(e) {
        e[e.none = 1] = "none", e[e.hasCreated = 2] = "hasCreated", e[e.hasBinding = 4] = "hasBinding", e[e.hasBound = 8] = "hasBound", e[e.hasAttaching = 16] = "hasAttaching", e[e.hasAttached = 32] = "hasAttached", e[e.hasDetaching = 64] = "hasDetaching", e[e.hasDetached = 128] = "hasDetached", e[e.hasUnbinding = 256] = "hasUnbinding", e[e.hasUnbound = 512] = "hasUnbound", e[e.hasRender = 1024] = "hasRender", e[e.hasCaching = 2048] = "hasCaching"
    }(Ue || (Ue = {})),
    function(e) {
        e[e.none = 0] = "none", e[e.persistentBindingFlags = 2080374799] = "persistentBindingFlags", e[e.allowParentScopeTraversal = 67108864] = "allowParentScopeTraversal", e[e.observeLeafPropertiesOnly = 134217728] = "observeLeafPropertiesOnly", e[e.targetObserverFlags = 805306383] = "targetObserverFlags", e[e.noTargetObserverQueue = 268435456] = "noTargetObserverQueue", e[e.persistentTargetObserverQueue = 536870912] = "persistentTargetObserverQueue", e[e.secondaryExpression = 1073741824] = "secondaryExpression", e[e.bindingStrategy = 15] = "bindingStrategy", e[e.getterSetterStrategy = 1] = "getterSetterStrategy", e[e.proxyStrategy = 2] = "proxyStrategy", e[e.isStrictBindingStrategy = 4] = "isStrictBindingStrategy", e[e.update = 48] = "update", e[e.updateTargetInstance = 16] = "updateTargetInstance", e[e.updateSourceExpression = 32] = "updateSourceExpression", e[e.from = 524224] = "from", e[e.fromFlush = 960] = "fromFlush", e[e.fromAsyncFlush = 64] = "fromAsyncFlush", e[e.fromSyncFlush = 128] = "fromSyncFlush", e[e.fromTick = 256] = "fromTick", e[e.fromBatch = 512] = "fromBatch", e[e.fromStartTask = 1024] = "fromStartTask", e[e.fromStopTask = 2048] = "fromStopTask", e[e.fromBind = 4096] = "fromBind", e[e.fromUnbind = 8192] = "fromUnbind", e[e.fromAttach = 16384] = "fromAttach", e[e.fromDetach = 32768] = "fromDetach", e[e.fromCache = 65536] = "fromCache", e[e.fromDOMEvent = 131072] = "fromDOMEvent", e[e.fromLifecycleTask = 262144] = "fromLifecycleTask", e[e.allowPublishRoundtrip = 524288] = "allowPublishRoundtrip", e[e.isPublishing = 1048576] = "isPublishing", e[e.mustEvaluate = 2097152] = "mustEvaluate", e[e.isTraversingParentScope = 4194304] = "isTraversingParentScope", e[e.isOriginalArray = 8388608] = "isOriginalArray", e[e.isCollectionMutation = 16777216] = "isCollectionMutation", e[e.reorderNodes = 33554432] = "reorderNodes"
    }(Be || (Be = {})),
    function(e) {
        e[e.Connects = 32] = "Connects", e[e.Observes = 64] = "Observes", e[e.CallsFunction = 128] = "CallsFunction", e[e.HasAncestor = 256] = "HasAncestor", e[e.IsPrimary = 512] = "IsPrimary", e[e.IsLeftHandSide = 1024] = "IsLeftHandSide", e[e.HasBind = 2048] = "HasBind", e[e.HasUnbind = 4096] = "HasUnbind", e[e.IsAssignable = 8192] = "IsAssignable", e[e.IsLiteral = 16384] = "IsLiteral", e[e.IsResource = 32768] = "IsResource", e[e.IsForDeclaration = 65536] = "IsForDeclaration", e[e.Type = 31] = "Type", e[e.AccessThis = 1793] = "AccessThis", e[e.AccessScope = 10082] = "AccessScope", e[e.ArrayLiteral = 17955] = "ArrayLiteral", e[e.ObjectLiteral = 17956] = "ObjectLiteral", e[e.PrimitiveLiteral = 17925] = "PrimitiveLiteral", e[e.Template = 17958] = "Template", e[e.Unary = 39] = "Unary", e[e.CallScope = 1448] = "CallScope", e[e.CallMember = 1161] = "CallMember", e[e.CallFunction = 1162] = "CallFunction", e[e.AccessMember = 9323] = "AccessMember", e[e.AccessKeyed = 9324] = "AccessKeyed", e[e.TaggedTemplate = 1197] = "TaggedTemplate", e[e.Binary = 46] = "Binary", e[e.Conditional = 63] = "Conditional", e[e.Assign = 8208] = "Assign", e[e.ValueConverter = 36913] = "ValueConverter", e[e.BindingBehavior = 38962] = "BindingBehavior", e[e.HtmlLiteral = 51] = "HtmlLiteral", e[e.ArrayBindingPattern = 65556] = "ArrayBindingPattern", e[e.ObjectBindingPattern = 65557] = "ObjectBindingPattern", e[e.BindingIdentifier = 65558] = "BindingIdentifier", e[e.ForOfStatement = 6199] = "ForOfStatement", e[e.Interpolation = 24] = "Interpolation"
    }(ze || (ze = {})),
    function(e) {
        e[e.customElement = 0] = "customElement", e[e.customAttribute = 1] = "customAttribute", e[e.synthetic = 2] = "synthetic"
    }(He || (He = {}));
    const We = r.a.createInterface("IController").noDefault();
    var qe;
    ! function(e) {
        e[e.insertBefore = 1] = "insertBefore", e[e.append = 2] = "append"
    }(qe || (qe = {}));
    const Ge = r.a.createInterface("IViewFactory").noDefault();
    class Ke {
        constructor(e, t, n = 16384, i = !1) {
            this.cb = e, this.context = t, this.priority = n, this.once = i, this.next = void 0, this.prev = void 0, this.unlinked = !1
        }
        get first() {
            let e = this;
            for (; void 0 !== e.prev && e.prev.priority === this.priority;) e = e.prev;
            return e
        }
        get last() {
            let e = this;
            for (; void 0 !== e.next && e.next.priority === this.priority;) e = e.next;
            return e
        }
        equals(e, t) {
            return this.cb === e && this.context === t
        }
        call(e) {
            if (void 0 !== this.cb && (void 0 !== this.context ? this.cb.call(this.context, e) : this.cb(e)), this.once) return this.unlink(!0);
            if (this.unlinked) {
                const e = this.next;
                return this.next = void 0, e
            }
            return this.next
        }
        rotate() {
            if (void 0 === this.prev || this.prev.priority > this.priority) return;
            const {
                first: e,
                last: t
            } = this, n = e.prev, i = t.next, r = this.prev;
            this.prev = n, void 0 !== n && (n.next = this), t.next = e, e.prev = t, r.next = i, void 0 !== i && (i.prev = r)
        }
        link(e) {
            this.prev = e, void 0 !== e.next && (e.next.prev = this), this.next = e.next, e.next = this
        }
        unlink(e = !1) {
            if (this.unlinked = !0, this.cb = void 0, this.context = void 0, void 0 !== this.prev && (this.prev.next = this.next), void 0 !== this.next && (this.next.prev = this.prev), this.prev = void 0, e) {
                const {
                    next: e
                } = this;
                return this.next = void 0, e
            }
            return this.next
        }
    }
    var Ye;
    ! function(e) {
        e[e.preempt = 32768] = "preempt", e[e.high = 28672] = "high", e[e.bind = 24576] = "bind", e[e.attach = 20480] = "attach", e[e.normal = 16384] = "normal", e[e.propagate = 12288] = "propagate", e[e.connect = 8192] = "connect", e[e.low = 4096] = "low"
    }(Ye || (Ye = {}));
    const Xe = r.a.createInterface("ILifecycle").withDefault(e => e.singleton(ot)),
        {
            min: Je,
            max: Qe
        } = Math;
    class Ze {
        constructor(e) {
            this.lifecycle = e, this.depth = 0, this.head = void 0, this.tail = void 0
        }
        begin() {
            ++this.depth
        }
        end(e) {
            void 0 === e && (e = 0), 0 == --this.depth && this.process(e)
        }
        inline(e, t) {
            this.begin(), e(), this.end(t)
        }
        add(e) {
            void 0 === this.head ? this.head = e : (e.prevBound = this.tail, this.tail.nextBound = e), this.tail = e, e.state |= 65536
        }
        remove(e) {
            void 0 !== e.prevBound && (e.prevBound.nextBound = e.nextBound), void 0 !== e.nextBound && (e.nextBound.prevBound = e.prevBound), e.prevBound = void 0, e.nextBound = void 0, this.tail === e && (this.tail = e.prevBound), this.head === e && (this.head = e.nextBound), e.state = 65536 ^ (65536 | e.state)
        }
        process(e) {
            for (; void 0 !== this.head;) {
                let t, n = this.head;
                this.head = this.tail = void 0;
                do {
                    n.state = 65536 ^ (65536 | n.state), n.bound(e), t = n.nextBound, n.nextBound = void 0, n.prevBound = void 0, n = t
                } while (void 0 !== n)
            }
        }
    }
    class et {
        constructor(e) {
            this.lifecycle = e, this.depth = 0, this.head = void 0, this.tail = void 0
        }
        begin() {
            ++this.depth
        }
        end(e) {
            void 0 === e && (e = 0), 0 == --this.depth && this.process(e)
        }
        inline(e, t) {
            this.begin(), e(), this.end(t)
        }
        add(e) {
            void 0 === this.head ? this.head = e : (e.prevUnbound = this.tail, this.tail.nextUnbound = e), this.tail = e, e.state |= 131072
        }
        remove(e) {
            void 0 !== e.prevUnbound && (e.prevUnbound.nextUnbound = e.nextUnbound), void 0 !== e.nextUnbound && (e.nextUnbound.prevUnbound = e.prevUnbound), e.prevUnbound = void 0, e.nextUnbound = void 0, this.tail === e && (this.tail = e.prevUnbound), this.head === e && (this.head = e.nextUnbound), e.state = 131072 ^ (131072 | e.state)
        }
        process(e) {
            for (; void 0 !== this.head;) {
                let t, n = this.head;
                this.head = this.tail = void 0;
                do {
                    n.state = 131072 ^ (131072 | n.state), n.unbound(e), t = n.nextUnbound, n.nextUnbound = void 0, n.prevUnbound = void 0, n = t
                } while (void 0 !== n)
            }
        }
    }
    class tt {
        constructor(e) {
            this.lifecycle = e, this.depth = 0, this.head = void 0, this.tail = void 0
        }
        begin() {
            ++this.depth
        }
        end(e) {
            void 0 === e && (e = 0), 0 == --this.depth && (this.lifecycle.mount.process(e), this.process(e))
        }
        inline(e, t) {
            this.begin(), e(), this.end(t)
        }
        add(e) {
            void 0 === this.head ? this.head = e : (e.prevAttached = this.tail, this.tail.nextAttached = e), this.tail = e, e.state |= 262144
        }
        remove(e) {
            void 0 !== e.prevAttached && (e.prevAttached.nextAttached = e.nextAttached), void 0 !== e.nextAttached && (e.nextAttached.prevAttached = e.prevAttached), e.prevAttached = void 0, e.nextAttached = void 0, this.tail === e && (this.tail = e.prevAttached), this.head === e && (this.head = e.nextAttached), e.state = 262144 ^ (262144 | e.state)
        }
        process(e) {
            for (; void 0 !== this.head;) {
                let t, n = this.head;
                this.head = this.tail = void 0;
                do {
                    n.state = 262144 ^ (262144 | n.state), n.attached(e), t = n.nextAttached, n.nextAttached = void 0, n.prevAttached = void 0, n = t
                } while (void 0 !== n)
            }
        }
    }
    class nt {
        constructor(e) {
            this.lifecycle = e, this.depth = 0, this.head = void 0, this.tail = void 0
        }
        begin() {
            ++this.depth
        }
        end(e) {
            void 0 === e && (e = 0), 0 == --this.depth && (this.lifecycle.unmount.process(e), this.process(e))
        }
        inline(e, t) {
            this.begin(), e(), this.end(t)
        }
        add(e) {
            void 0 === this.head ? this.head = e : (e.prevDetached = this.tail, this.tail.nextDetached = e), this.tail = e, e.state |= 524288
        }
        remove(e) {
            void 0 !== e.prevDetached && (e.prevDetached.nextDetached = e.nextDetached), void 0 !== e.nextDetached && (e.nextDetached.prevDetached = e.prevDetached), e.prevDetached = void 0, e.nextDetached = void 0, this.tail === e && (this.tail = e.prevDetached), this.head === e && (this.head = e.nextDetached), e.state = 524288 ^ (524288 | e.state)
        }
        process(e) {
            for (; void 0 !== this.head;) {
                let t, n = this.head;
                this.head = this.tail = void 0;
                do {
                    n.state = 524288 ^ (524288 | n.state), n.detached(e), t = n.nextDetached, n.nextDetached = void 0, n.prevDetached = void 0, n = t
                } while (void 0 !== n)
            }
        }
    }
    class it {
        constructor(e) {
            this.lifecycle = e, this.head = void 0, this.tail = void 0
        }
        add(e) {
            if ((2097152 & e.state) > 0) return this.lifecycle.unmount.remove(e), void console.log("in unmount queue during mountQueue.add, so removing", this);
            void 0 === this.head ? this.head = e : (e.prevMount = this.tail, this.tail.nextMount = e), this.tail = e, e.state |= 1048576
        }
        remove(e) {
            void 0 !== e.prevMount && (e.prevMount.nextMount = e.nextMount), void 0 !== e.nextMount && (e.nextMount.prevMount = e.prevMount), e.prevMount = void 0, e.nextMount = void 0, this.tail === e && (this.tail = e.prevMount), this.head === e && (this.head = e.nextMount), e.state = 1048576 ^ (1048576 | e.state)
        }
        process(e) {
            for (; void 0 !== this.head;) {
                let t, n = this.head;
                this.head = this.tail = void 0;
                do {
                    n.state = 1048576 ^ (1048576 | n.state), n.mount(e), t = n.nextMount, n.nextMount = void 0, n.prevMount = void 0, n = t
                } while (void 0 !== n)
            }
        }
    }
    class rt {
        constructor(e) {
            this.lifecycle = e, this.head = void 0, this.tail = void 0
        }
        add(e) {
            (1048576 & e.state) > 0 ? this.lifecycle.mount.remove(e) : (void 0 === this.head ? this.head = e : (e.prevUnmount = this.tail, this.tail.nextUnmount = e), this.tail = e, e.state |= 2097152)
        }
        remove(e) {
            void 0 !== e.prevUnmount && (e.prevUnmount.nextUnmount = e.nextUnmount), void 0 !== e.nextUnmount && (e.nextUnmount.prevUnmount = e.prevUnmount), e.prevUnmount = void 0, e.nextUnmount = void 0, this.tail === e && (this.tail = e.prevUnmount), this.head === e && (this.head = e.nextUnmount), e.state = 2097152 ^ (2097152 | e.state)
        }
        process(e) {
            for (; void 0 !== this.head;) {
                let t, n = this.head;
                this.head = this.tail = void 0;
                do {
                    n.state = 2097152 ^ (2097152 | n.state), n.unmount(e), t = n.nextUnmount, n.nextUnmount = void 0, n.prevUnmount = void 0, n = t
                } while (void 0 !== n)
            }
        }
    }
    class st {
        constructor(e) {
            this.lifecycle = e, this.queue = [], this.depth = 0
        }
        begin() {
            ++this.depth
        }
        end(e) {
            void 0 === e && (e = 0), 0 == --this.depth && this.process(e)
        }
        inline(e, t) {
            this.begin(), e(), this.end(t)
        }
        add(e) {
            this.queue.push(e)
        }
        remove(e) {
            const t = this.queue.indexOf(e);
            t > -1 && this.queue.splice(t, 1)
        }
        process(e) {
            for (e |= 512; this.queue.length > 0;) {
                const t = this.queue.slice();
                this.queue = [];
                const {
                    length: n
                } = t;
                for (let i = 0; i < n; ++i) t[i].flushBatch(e)
            }
        }
    }
    class ot {
        constructor() {
            this.rafHead = new Ke(void 0, void 0, 1 / 0), this.rafTail = void 0, this.currentTick = 0, this.isFlushingRAF = !1, this.rafRequestId = -1, this.rafStartTime = -1, this.isTicking = !1, this.batch = new st(this), this.mount = new it(this), this.unmount = new rt(this), this.bound = new Ze(this), this.unbound = new et(this), this.attached = new tt(this), this.detached = new nt(this), this.minFrameDuration = 0, this.maxFrameDuration = 1e3 / 30, this.prevFrameDuration = 0, this.nextFrame = new Promise(e => {
                this.resolveNextFrame = e
            }), this.tick = e => {
                this.rafRequestId = -1, this.isTicking && (this.processRAFQueue(960, e), this.isTicking && -1 === this.rafRequestId && void 0 !== this.rafHead.next && (this.rafRequestId = r.g.requestAnimationFrame(this.tick)), ++this.currentTick > 1 && (this.resolveNextFrame(e), this.nextFrame = new Promise(e => {
                    this.resolveNextFrame = e
                })))
            }, this.pendingChanges = 0, this.timeslicingEnabled = !1, this.adaptiveTimeslicing = !1, this.frameDurationFactor = 1
        }
        get FPS() {
            return 1e3 / this.prevFrameDuration
        }
        get minFPS() {
            return 1e3 / this.maxFrameDuration
        }
        set minFPS(e) {
            this.maxFrameDuration = 1e3 / Je(Qe(0, Je(this.maxFPS, e)), 60)
        }
        get maxFPS() {
            return this.minFrameDuration > 0 ? 1e3 / this.minFrameDuration : 60
        }
        set maxFPS(e) {
            this.minFrameDuration = e >= 60 ? 0 : 1e3 / Je(Qe(1, Qe(this.minFPS, e)), 60)
        }
        static register(e) {
            return r.j.singleton(Xe, this).register(e)
        }
        startTicking() {
            this.isTicking || (this.isTicking = !0), -1 === this.rafRequestId && void 0 !== this.rafHead.next && (this.rafStartTime = r.g.now(), this.rafRequestId = r.g.requestAnimationFrame(this.tick))
        }
        stopTicking() {
            this.processRAFQueue(0), this.isTicking ? (this.isTicking = !1, -1 !== this.rafRequestId && (r.g.cancelAnimationFrame(this.rafRequestId), this.rafRequestId = -1)) : -1 !== this.rafRequestId && (r.g.cancelAnimationFrame(this.rafRequestId), this.rafRequestId = -1)
        }
        enqueueRAF(e, t, n = 16384, i = !1) {
            const r = new Ke(e, t, n, i);
            let s = this.rafHead,
                o = s.next;
            if (void 0 === o) r.link(s);
            else {
                do {
                    if (n > o.priority || n === o.priority && i && !o.once) {
                        r.link(s);
                        break
                    }
                    s = o, o = o.next
                } while (void 0 !== o);
                void 0 === r.prev && r.link(s)
            }
            void 0 === r.next && (this.rafTail = r), this.startTicking()
        }
        dequeueRAF(e, t) {
            let n = this.rafHead.next;
            for (; void 0 !== n;) n = n.equals(e, t) ? n.unlink() : n.next
        }
        processRAFQueue(e, t = r.g.now()) {
            if (!this.isFlushingRAF) {
                if (this.isFlushingRAF = !0, t >= this.rafStartTime) {
                    const n = this.prevFrameDuration = t - this.rafStartTime;
                    if (n + 1 < this.minFrameDuration) return;
                    let i = 0;
                    this.adaptiveTimeslicing && this.maxFrameDuration > 0 ? this.frameDurationFactor = Je(Qe(this.frameDurationFactor * (this.maxFrameDuration / n), .1), 10) : this.frameDurationFactor = 1;
                    const s = t + Qe(this.maxFrameDuration * this.frameDurationFactor, 1),
                        o = t + Qe(this.maxFrameDuration * this.frameDurationFactor * 5, 5),
                        a = t + Qe(this.maxFrameDuration * this.frameDurationFactor * 15, 15);
                    e |= 256;
                    do {
                        this.pendingChanges = 0;
                        let t = this.rafHead.next;
                        for (; void 0 !== t;) {
                            if (10 == ++i && (i = 0, this.timeslicingEnabled)) {
                                const {
                                    priority: e
                                } = t, n = r.g.now();
                                if (e <= 4096) {
                                    if (n >= s) {
                                        if (t.rotate(), null == t.last || null == t.last.next) break;
                                        t = t.last.next
                                    }
                                } else if (e < 28672) {
                                    if (n >= o) {
                                        if (t.rotate(), null == t.last || null == t.last.next) break;
                                        t = t.last.next
                                    }
                                } else if (n >= a) {
                                    if (t.rotate(), null == t.last || null == t.last.next) break;
                                    t = t.last.next
                                }
                            }
                            t = t.call(e)
                        }
                    } while (this.pendingChanges > 0);
                    void 0 === this.rafHead.next && this.stopTicking()
                }
                this.rafStartTime = t, this.isFlushingRAF = !1
            }
        }
        enableTimeslicing(e = !0) {
            this.timeslicingEnabled = !0, this.adaptiveTimeslicing = !0 === e
        }
        disableTimeslicing() {
            this.timeslicingEnabled = !1
        }
    }
    Array.prototype.slice;
    const at = [],
        ct = [];
    let lt = -1;

    function ut(e) {
        if (e === lt) {
            lt += 5;
            const t = at.length = ct.length = lt + 1;
            for (let n = e + 1; n < t; ++n) at[n] = "_observer" + n, ct[n] = "_observerVersion" + n
        }
    }

    function ht(e) {
        const t = null == this.observerSlots ? 0 : this.observerSlots;
        let n = t;
        for (; n-- && this[at[n]] !== e;);
        if (-1 === n) {
            for (n = 0; this[at[n]];) n++;
            this[at[n]] = e, e.subscribe(this), e[this.id] |= 16, n === t && (this.observerSlots = n + 1)
        }
        null == this.version && (this.version = 0), this[ct[n]] = this.version, ut(n)
    }

    function dt(e, t, n) {
        const i = this.observerLocator.getObserver(e, t, n);
        this.addObserver(i)
    }

    function pt(e) {
        const t = this.observerSlots;
        let n, i;
        if (!0 === e)
            for (let e = 0; e < t; ++e) n = at[e], i = this[n], null != i && (this[n] = void 0, i.unsubscribe(this), i[this.id] &= -17);
        else {
            const e = this.version;
            for (let r = 0; r < t; ++r) this[ct[r]] !== e && (n = at[r], i = this[n], null != i && (this[n] = void 0, i.unsubscribe(this), i[this.id] &= -17))
        }
    }

    function ft(e) {
        const t = e.prototype;
        return Object.prototype.hasOwnProperty.call(t, "observeProperty") || (t.observeProperty = dt), Object.prototype.hasOwnProperty.call(t, "unobserve") || (t.unobserve = pt), Object.prototype.hasOwnProperty.call(t, "addObserver") || (t.addObserver = ht), e
    }

    function gt(e) {
        return null == e ? ft : ft(e)
    }
    ut(-1);
    let mt = 0;
    gt.assignIdTo = e => {
        e.id = ++mt
    };
    Array.prototype.slice;
    const {
        oneTime: vt,
        toView: bt,
        fromView: yt
    } = Ve, wt = bt | vt;
    let kt = class {
        constructor(e, t, n, i, r, s) {
            gt.assignIdTo(this), this.$state = 0, this.$lifecycle = s.get(Xe), this.$scope = void 0, this.locator = s, this.mode = i, this.observerLocator = r, this.sourceExpression = e, this.target = t, this.targetProperty = n, this.targetObserver = void 0, this.persistentFlags = 0
        }
        updateTarget(e, t) {
            t |= this.persistentFlags, this.targetObserver.setValue(e, t)
        }
        updateSource(e, t) {
            t |= this.persistentFlags, this.sourceExpression.assign(t, this.$scope, this.locator, e, this.part)
        }
        handleChange(e, t, n) {
            if (0 != (4 & this.$state)) {
                if ((16 & (n |= this.persistentFlags)) > 0) {
                    const t = this.targetObserver.getValue();
                    return (10082 !== this.sourceExpression.$kind || this.observerSlots > 1) && (e = this.sourceExpression.evaluate(n, this.$scope, this.locator, this.part)), e !== t && this.updateTarget(e, n), void(0 == (this.mode & vt) && (this.version++, this.sourceExpression.connect(n, this.$scope, this, this.part), this.unobserve(!1)))
                }
                if (!((32 & n) > 0)) throw r.k.error(15, n);
                e !== this.sourceExpression.evaluate(n, this.$scope, this.locator, this.part) && this.updateSource(e, n)
            }
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(4096 | e)
            }
            this.$state |= 1, e |= 4, this.persistentFlags = 2080374799 & e, this.$scope = t, this.part = n;
            let i = this.sourceExpression;
            ie(i) && i.bind(e, t, this);
            let r = this.targetObserver;
            r || (r = this.mode & yt ? this.targetObserver = this.observerLocator.getObserver(e, this.target, this.targetProperty) : this.targetObserver = this.observerLocator.getAccessor(e, this.target, this.targetProperty)), this.mode !== Ve.oneTime && r.bind && r.bind(e), i = this.sourceExpression, this.mode & wt && this.updateTarget(i.evaluate(e, t, this.locator, n), e), this.mode & bt && i.connect(e, t, this, n), this.mode & yt && (r.subscribe(this), r[this.id] |= 32), this.$state |= 4, this.$state &= -2
        }
        $unbind(e) {
            4 & this.$state && (this.$state |= 2, this.persistentFlags = 0, re(this.sourceExpression) && this.sourceExpression.unbind(e, this.$scope, this), this.$scope = void 0, this.targetObserver.unbind && this.targetObserver.unbind(e), this.targetObserver.unsubscribe && (this.targetObserver.unsubscribe(this), this.targetObserver[this.id] &= -33), this.unobserve(!0), this.$state &= -7)
        }
    };
    kt = Object(s.__decorate)([gt()], kt);
    Array.prototype.slice;
    class xt {
        constructor(e, t, n, i, r) {
            this.$state = 0, this.locator = r, this.sourceExpression = e, this.targetObserver = i.getObserver(0, t, n)
        }
        callSource(e) {
            const t = this.$scope.overrideContext;
            Object.assign(t, e);
            const n = this.sourceExpression.evaluate(2097152, this.$scope, this.locator, this.part);
            for (const n in e) Reflect.deleteProperty(t, n);
            return n
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(4096 | e)
            }
            this.$state |= 1, this.$scope = t, this.part = n, ie(this.sourceExpression) && this.sourceExpression.bind(e, t, this), this.targetObserver.setValue(e => this.callSource(e), e), this.$state |= 4, this.$state &= -2
        }
        $unbind(e) {
            4 & this.$state && (this.$state |= 2, re(this.sourceExpression) && this.sourceExpression.unbind(e, this.$scope, this), this.$scope = void 0, this.targetObserver.setValue(null, e), this.$state &= -7)
        }
        observeProperty(e, t, n) {}
        handleChange(e, t, n) {}
    }
    const _t = r.a.createInterface("IExpressionParser").withDefault(e => e.singleton(St));
    class St {
        constructor() {
            this.expressionLookup = Object.create(null), this.forOfLookup = Object.create(null), this.interpolationLookup = Object.create(null)
        }
        parse(e, t) {
            switch (t) {
                case 2048: {
                    let n = this.interpolationLookup[e];
                    return void 0 === n && (n = this.interpolationLookup[e] = this.parseCore(e, t)), n
                }
                case 539: {
                    let n = this.forOfLookup[e];
                    return void 0 === n && (n = this.forOfLookup[e] = this.parseCore(e, t)), n
                }
                default: {
                    if (0 === e.length && 55 & t) return _e.$empty;
                    let n = this.expressionLookup[e];
                    return void 0 === n && (n = this.expressionLookup[e] = this.parseCore(e, t)), n
                }
            }
        }
        cache(e) {
            const {
                forOfLookup: t,
                expressionLookup: n,
                interpolationLookup: i
            } = this;
            for (const r in e) {
                const s = e[r];
                switch (s.$kind) {
                    case 24:
                        i[r] = s;
                        break;
                    case 6199:
                        t[r] = s;
                        break;
                    default:
                        n[r] = s
                }
            }
        }
        parseCore(e, t) {
            try {
                const t = e.split("."),
                    n = t[0];
                let i;
                i = n.endsWith("()") ? new be(n.replace("()", ""), r.g.emptyArray) : new ge(t[0]);
                let s = 1;
                for (; s < t.length;) {
                    const e = t[s];
                    i = e.endsWith("()") ? new ye(i, e.replace("()", ""), r.g.emptyArray) : new me(i, t[s]), s++
                }
                return i
            } catch (e) {
                throw r.k.error(3, e)
            }
        }
    }
    var Ot;
    ! function(e) {
        e[e.None = 0] = "None", e[e.IgnoreCustomAttr = 4096] = "IgnoreCustomAttr", e[e.Interpolation = 2048] = "Interpolation", e[e.IsRef = 5376] = "IsRef", e[e.IsIterator = 512] = "IsIterator", e[e.IsCustom = 256] = "IsCustom", e[e.IsFunction = 128] = "IsFunction", e[e.IsEvent = 64] = "IsEvent", e[e.IsProperty = 32] = "IsProperty", e[e.IsCommand = 16] = "IsCommand", e[e.IsPropertyCommand = 48] = "IsPropertyCommand", e[e.IsEventCommand = 80] = "IsEventCommand", e[e.DelegationStrategyDelta = 6] = "DelegationStrategyDelta", e[e.Command = 15] = "Command", e[e.OneTimeCommand = 49] = "OneTimeCommand", e[e.ToViewCommand = 50] = "ToViewCommand", e[e.FromViewCommand = 51] = "FromViewCommand", e[e.TwoWayCommand = 52] = "TwoWayCommand", e[e.BindCommand = 53] = "BindCommand", e[e.TriggerCommand = 4182] = "TriggerCommand", e[e.CaptureCommand = 4183] = "CaptureCommand", e[e.DelegateCommand = 4184] = "DelegateCommand", e[e.CallCommand = 153] = "CallCommand", e[e.OptionsCommand = 26] = "OptionsCommand", e[e.ForCommand = 539] = "ForCommand", e[e.CustomCommand = 284] = "CustomCommand"
    }(Ot || (Ot = {}));
    const {
        toView: Ct,
        oneTime: At
    } = Ve;
    class Tt {
        constructor(e, t, n, i, r, s) {
            this.$state = 0, this.$scope = void 0, this.interpolation = t, this.locator = s, this.mode = r, this.observerLocator = e, this.target = n, this.targetProperty = i;
            const o = t.expressions,
                a = this.parts = Array(o.length);
            for (let c = 0, l = o.length; c < l; ++c) a[c] = new Et(o[c], t, n, i, r, e, s, 0 === c)
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(e)
            }
            this.$state |= 4, this.$scope = t, this.part = n;
            const i = this.parts;
            for (let r = 0, s = i.length; r < s; ++r) i[r].$bind(e, t, n)
        }
        $unbind(e) {
            if (!(4 & this.$state)) return;
            this.$state &= -5, this.$scope = void 0;
            const t = this.parts;
            for (let n = 0, i = t.length; n < i; ++n) t[n].$unbind(e)
        }
    }
    let Et = class {
        constructor(e, t, n, i, r, s, o, a) {
            gt.assignIdTo(this), this.$state = 0, this.interpolation = t, this.isFirst = a, this.mode = r, this.locator = o, this.observerLocator = s, this.sourceExpression = e, this.target = n, this.targetProperty = i, this.targetObserver = s.getAccessor(0, n, i)
        }
        updateTarget(e, t) {
            this.targetObserver.setValue(e, 16 | t)
        }
        handleChange(e, t, n) {
            if (!(4 & this.$state)) return;
            const i = this.targetObserver.getValue(),
                r = this.interpolation.evaluate(n, this.$scope, this.locator, this.part);
            r !== i && this.updateTarget(r, n), 0 == (this.mode & At) && (this.version++, this.sourceExpression.connect(n, this.$scope, this, this.part), this.unobserve(!1))
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(e)
            }
            this.$state |= 4, this.$scope = t, this.part = n;
            const i = this.sourceExpression;
            i.bind && i.bind(e, t, this), this.mode !== Ve.oneTime && this.targetObserver.bind && this.targetObserver.bind(e), this.isFirst && this.updateTarget(this.interpolation.evaluate(e, t, this.locator, n), e), this.mode & Ct && i.connect(e, t, this, n)
        }
        $unbind(e) {
            if (!(4 & this.$state)) return;
            this.$state &= -5;
            const t = this.sourceExpression;
            t.unbind && t.unbind(e, this.$scope, this), this.targetObserver.unbind && this.targetObserver.unbind(e), this.$scope = void 0, this.unobserve(!0)
        }
    };
    Et = Object(s.__decorate)([gt()], Et);
    Array.prototype.slice;
    let jt = class {
        constructor(e, t, n, i, r = !1) {
            gt.assignIdTo(this), this.$state = 0, this.$lifecycle = i.get(Xe), this.$scope = void 0, this.locator = i, this.observerLocator = n, this.sourceExpression = e, this.target = null, this.targetProperty = t, this.toBindingContext = r
        }
        handleChange(e, t, n) {
            if (4 & this.$state) {
                if (!(16 & n)) throw r.k.error(15, n);
                {
                    const {
                        target: e,
                        targetProperty: t
                    } = this, i = e[t], r = this.sourceExpression.evaluate(n, this.$scope, this.locator, this.part);
                    r !== i && (e[t] = r)
                }
            }
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(4096 | e)
            }
            this.$state |= 1, this.$scope = t, this.part = n, this.target = this.toBindingContext ? t.bindingContext : t.overrideContext;
            const i = this.sourceExpression;
            i.bind && i.bind(e, t, this), this.target[this.targetProperty] = this.sourceExpression.evaluate(4096 | e, t, this.locator, n), this.sourceExpression.connect(e, t, this, n), this.$state |= 4, this.$state &= -2
        }
        $unbind(e) {
            if (!(4 & this.$state)) return;
            this.$state |= 2;
            const t = this.sourceExpression;
            t.unbind && t.unbind(e, this.$scope, this), this.$scope = void 0, this.unobserve(!0), this.$state &= -7
        }
    };
    jt = Object(s.__decorate)([gt()], jt);
    Array.prototype.slice;
    class Mt {
        constructor(e, t, n) {
            this.$state = 0, this.$scope = void 0, this.locator = n, this.sourceExpression = e, this.target = t
        }
        $bind(e, t, n) {
            if (4 & this.$state) {
                if (this.$scope === t) return;
                this.$unbind(4096 | e)
            }
            this.$state |= 1, this.$scope = t, this.part = n, ie(this.sourceExpression) && this.sourceExpression.bind(e, t, this), this.sourceExpression.assign(32 | e, this.$scope, this.locator, this.target, n), this.$state |= 4, this.$state &= -2
        }
        $unbind(e) {
            if (!(4 & this.$state)) return;
            this.$state |= 2;
            let t = this.sourceExpression;
            t.evaluate(e, this.$scope, this.locator, this.part) === this.target && t.assign(e, this.$scope, this.locator, null, this.part), t = this.sourceExpression, re(t) && t.unbind(e, this.$scope, this), this.$scope = void 0, this.$state &= -7
        }
        observeProperty(e, t, n) {}
        handleChange(e, t, n) {}
    }
    var Lt, Pt, Rt;

    function It(e, t) {
        const {
            length: n
        } = e, i = Array(n);
        let r = 0;
        for (; r < n;) i[r] = e[r], ++r;
        return void 0 !== t ? i.deletedItems = t.slice(0) : void 0 !== e.deletedItems ? i.deletedItems = e.deletedItems.slice(0) : i.deletedItems = [], i.isIndexMap = !0, i
    }

    function Dt(e = 0) {
        const t = Array(e);
        let n = 0;
        for (; n < e;) t[n] = n++;
        return t.deletedItems = [], t.isIndexMap = !0, t
    }

    function Nt(e) {
        const t = e.slice();
        return t.deletedItems = e.deletedItems.slice(), t.isIndexMap = !0, t
    }

    function Vt(e) {
        return e instanceof Array && !0 === e.isIndexMap
    }! function(e) {
        e[e.None = 0] = "None", e[e.Subscriber0 = 1] = "Subscriber0", e[e.Subscriber1 = 2] = "Subscriber1", e[e.Subscriber2 = 4] = "Subscriber2", e[e.SubscribersRest = 8] = "SubscribersRest", e[e.Any = 15] = "Any"
    }(Lt || (Lt = {})),
    function(e) {
        e[e.none = 0] = "none", e[e.capturing = 1] = "capturing", e[e.bubbling = 2] = "bubbling"
    }(Pt || (Pt = {})),
    function(e) {
        e[e.indexed = 8] = "indexed", e[e.keyed = 4] = "keyed", e[e.array = 9] = "array", e[e.map = 6] = "map", e[e.set = 7] = "set"
    }(Rt || (Rt = {}));
    let $t = class {
        constructor(e) {
            this.obj = e, this.currentValue = e.length
        }
        getValue() {
            return this.obj.length
        }
        setValue(e, t) {
            const {
                currentValue: n
            } = this;
            e !== n && (this.currentValue = e, this.callSubscribers(e, n, 16 | t))
        }
    };

    function Ft(e, t) {
        return e === t ? 0 : (e = null === e ? "null" : e.toString()) < (t = null === t ? "null" : t.toString()) ? -1 : 1
    }

    function Ut(e, t) {
        return void 0 === e ? void 0 === t ? 0 : 1 : void 0 === t ? -1 : 0
    }

    function Bt(e, t, n, i, r) {
        let s, o, a, c, l, u, h;
        for (u = n + 1; u < i; u++) {
            for (s = e[u], o = t[u], h = u - 1; h >= n && (a = e[h], c = t[h], l = r(a, s), l > 0); h--) e[h + 1] = a, t[h + 1] = c;
            e[h + 1] = s, t[h + 1] = o
        }
    }

    function zt(e, t, n, i, r) {
        let s, o, a, c, l, u, h, d, p, f, g, m, v, b, y, w, k, x, _, S = 0,
            O = 0;
        for (;;) {
            if (i - n <= 10) return void Bt(e, t, n, i, r);
            S = n + (i - n >> 1), s = e[n], c = t[n], o = e[i - 1], l = t[i - 1], a = e[S], u = t[S], h = r(s, o), h > 0 && (f = s, g = c, s = o, c = l, o = f, l = g), d = r(s, a), d >= 0 ? (f = s, g = c, s = a, c = u, a = o, u = l, o = f, l = g) : (p = r(o, a), p > 0 && (f = o, g = l, o = a, l = u, a = f, u = g)), e[n] = s, t[n] = c, e[i - 1] = a, t[i - 1] = u, m = o, v = l, b = n + 1, y = i - 1, e[S] = e[b], t[S] = t[b], e[b] = m, t[b] = v;
            e: for (O = b + 1; O < y; O++)
                if (w = e[O], k = t[O], x = r(w, m), x < 0) e[O] = e[b], t[O] = t[b], e[b] = w, t[b] = k, b++;
                else
            if (x > 0) {
                do {
                    if (y--, y == O) break e;
                    _ = e[y], x = r(_, m)
                } while (x > 0);
                e[O] = e[y], t[O] = t[y], e[y] = w, t[y] = k, x < 0 && (w = e[O], k = t[O], e[O] = e[b], t[O] = t[b], e[b] = w, t[b] = k, b++)
            }
            i - y < b - n ? (zt(e, t, y, i, r), i = b) : (zt(e, t, n, b, r), n = y)
        }
    }
    $t = Object(s.__decorate)([o()], $t);
    const Ht = Array.prototype,
        Wt = Ht.push,
        qt = Ht.unshift,
        Gt = Ht.pop,
        Kt = Ht.shift,
        Yt = Ht.splice,
        Xt = Ht.reverse,
        Jt = Ht.sort,
        Qt = {
            push: Wt,
            unshift: qt,
            pop: Gt,
            shift: Kt,
            splice: Yt,
            reverse: Xt,
            sort: Jt
        },
        Zt = ["push", "unshift", "pop", "shift", "splice", "reverse", "sort"],
        en = {
            push: function(...e) {
                let t = this;
                void 0 !== t.$raw && (t = t.$raw);
                const n = t.$observer;
                if (void 0 === n) return Wt.apply(t, e);
                const i = t.length,
                    r = e.length;
                if (0 === r) return i;
                t.length = n.indexMap.length = i + r;
                let s = i;
                for (; s < t.length;) t[s] = e[s - i], n.indexMap[s] = -2, s++;
                return n.notify(), t.length
            },
            unshift: function(...e) {
                let t = this;
                void 0 !== t.$raw && (t = t.$raw);
                const n = t.$observer;
                if (void 0 === n) return qt.apply(t, e);
                const i = e.length,
                    r = new Array(i);
                let s = 0;
                for (; s < i;) r[s++] = -2;
                qt.apply(n.indexMap, r);
                const o = qt.apply(t, e);
                return n.notify(), o
            },
            pop: function() {
                let e = this;
                void 0 !== e.$raw && (e = e.$raw);
                const t = e.$observer;
                if (void 0 === t) return Gt.call(e);
                const n = t.indexMap,
                    i = Gt.call(e),
                    r = n.length - 1;
                return n[r] > -1 && n.deletedItems.push(n[r]), Gt.call(n), t.notify(), i
            },
            shift: function() {
                let e = this;
                void 0 !== e.$raw && (e = e.$raw);
                const t = e.$observer;
                if (void 0 === t) return Kt.call(e);
                const n = t.indexMap,
                    i = Kt.call(e);
                return n[0] > -1 && n.deletedItems.push(n[0]), Kt.call(n), t.notify(), i
            },
            splice: function(...e) {
                const t = e[0],
                    n = e[1];
                let i = this;
                void 0 !== i.$raw && (i = i.$raw);
                const r = i.$observer;
                if (void 0 === r) return Yt.apply(i, e);
                const s = this.length,
                    o = 0 | t,
                    a = o < 0 ? Math.max(s + o, 0) : Math.min(o, s),
                    c = r.indexMap,
                    l = e.length,
                    u = 0 === l ? 0 : 1 === l ? s - a : n;
                if (u > 0) {
                    let e = a;
                    const t = e + u;
                    for (; e < t;) c[e] > -1 && c.deletedItems.push(c[e]), e++
                }
                if (l > 2) {
                    const e = l - 2,
                        i = new Array(e);
                    let r = 0;
                    for (; r < e;) i[r++] = -2;
                    Yt.call(c, t, n, ...i)
                } else Yt.apply(c, e);
                const h = Yt.apply(i, e);
                return r.notify(), h
            },
            reverse: function() {
                let e = this;
                void 0 !== e.$raw && (e = e.$raw);
                const t = e.$observer;
                if (void 0 === t) return Xt.call(e), this;
                const n = e.length,
                    i = n / 2 | 0;
                let r = 0;
                for (; r !== i;) {
                    const i = n - r - 1,
                        s = e[r],
                        o = t.indexMap[r],
                        a = e[i],
                        c = t.indexMap[i];
                    e[r] = a, t.indexMap[r] = c, e[i] = s, t.indexMap[i] = o, r++
                }
                return t.notify(), this
            },
            sort: function(e) {
                let t = this;
                void 0 !== t.$raw && (t = t.$raw);
                const n = t.$observer;
                if (void 0 === n) return Jt.call(t, e), this;
                const i = t.length;
                if (i < 2) return this;
                zt(t, n.indexMap, 0, i, Ut);
                let r = 0;
                for (; r < i && void 0 !== t[r];) r++;
                return void 0 !== e && "function" == typeof e || (e = Ft), zt(t, n.indexMap, 0, r, e), n.notify(), this
            }
        },
        tn = {
            writable: !0,
            enumerable: !1,
            configurable: !0
        },
        nn = Reflect.defineProperty;
    for (const e of Zt) nn(en[e], "observing", {
        value: !0,
        writable: !1,
        configurable: !1,
        enumerable: !1
    });
    let rn = !1;

    function sn() {
        for (const e of Zt) !0 !== Ht[e].observing && nn(Ht, e, {
            ...tn,
            value: en[e]
        })
    }

    function on() {
        for (const e of Zt) !0 === Ht[e].observing && nn(Ht, e, {
            ...tn,
            value: Qt[e]
        })
    }
    Array.prototype.slice;
    let an = class {
        constructor(e, t, n) {
            rn || (rn = !0, sn()), this.inBatch = !1, this.collection = n, this.persistentFlags = 2080374799 & e, this.indexMap = Dt(n.length), this.lifecycle = t, this.lengthObserver = void 0, Reflect.defineProperty(n, "$observer", {
                value: this,
                enumerable: !1,
                writable: !0,
                configurable: !0
            })
        }
        notify() {
            this.lifecycle.batch.depth > 0 ? this.inBatch || (this.inBatch = !0, this.lifecycle.batch.add(this)) : this.flushBatch(0)
        }
        getLengthObserver() {
            return void 0 === this.lengthObserver && (this.lengthObserver = new $t(this.collection)), this.lengthObserver
        }
        flushBatch(e) {
            this.inBatch = !1;
            const t = this.indexMap,
                n = this.collection.length;
            this.indexMap = Dt(n), this.callCollectionSubscribers(t, 16 | this.persistentFlags), void 0 !== this.lengthObserver && this.lengthObserver.setValue(n, 16)
        }
    };

    function cn(e, t, n) {
        return void 0 === n.$observer && (n.$observer = new an(e, t, n)), n.$observer
    }

    function ln(e) {
        let t = 0,
            n = 0;
        const i = e.length;
        for (let r = 0; r < i; ++r) {
            for (; e.deletedItems[n] <= r - t;) ++n, --t; - 2 === e[r] ? ++t : e[r] += t
        }
    }

    function un(e, t) {
        const n = e.slice(),
            i = t.length;
        let r = 0,
            s = 0;
        for (; r < i;) s = t[r], -2 !== s && (e[r] = n[s]), ++r
    }
    an = Object(s.__decorate)([c()], an);
    let hn = class {
        constructor(e) {
            this.obj = e, this.currentValue = e.size
        }
        getValue() {
            return this.obj.size
        }
        setValue(e, t) {
            const {
                currentValue: n
            } = this;
            e !== n && (this.currentValue = e, this.callSubscribers(e, n, 16 | t))
        }
    };
    hn = Object(s.__decorate)([o()], hn);
    const dn = Map.prototype,
        pn = dn.set,
        fn = dn.clear,
        gn = dn.delete,
        mn = {
            set: pn,
            clear: fn,
            delete: gn
        },
        vn = ["set", "clear", "delete"],
        bn = {
            set: function(e, t) {
                let n = this;
                void 0 !== n.$raw && (n = n.$raw);
                const i = n.$observer;
                if (void 0 === i) return pn.call(n, e, t), this;
                const r = n.size;
                pn.call(n, e, t);
                if (n.size === r) {
                    let r = 0;
                    for (const s of n.entries()) {
                        if (s[0] === e) return s[1] !== t && (i.indexMap[r] = -2), this;
                        r++
                    }
                    return this
                }
                return i.indexMap[r] = -2, i.notify(), this
            },
            clear: function() {
                let e = this;
                void 0 !== e.$raw && (e = e.$raw);
                const t = e.$observer;
                if (void 0 === t) return fn.call(e);
                if (e.size > 0) {
                    const n = t.indexMap;
                    let i = 0;
                    for (const t of e.keys()) n[i] > -1 && n.deletedItems.push(n[i]), i++;
                    fn.call(e), n.length = 0, t.notify()
                }
            },
            delete: function(e) {
                let t = this;
                void 0 !== t.$raw && (t = t.$raw);
                const n = t.$observer;
                if (void 0 === n) return gn.call(t, e);
                if (0 === t.size) return !1;
                let i = 0;
                const r = n.indexMap;
                for (const s of t.keys()) {
                    if (s === e) {
                        r[i] > -1 && r.deletedItems.push(r[i]), r.splice(i, 1);
                        const s = gn.call(t, e);
                        return !0 === s && n.notify(), s
                    }++i
                }
                return !1
            }
        },
        yn = {
            writable: !0,
            enumerable: !1,
            configurable: !0
        },
        wn = Reflect.defineProperty;
    for (const e of vn) wn(bn[e], "observing", {
        value: !0,
        writable: !1,
        configurable: !1,
        enumerable: !1
    });
    let kn = !1;

    function xn() {
        for (const e of vn) !0 !== dn[e].observing && wn(dn, e, {
            ...yn,
            value: bn[e]
        })
    }

    function _n() {
        for (const e of vn) !0 === dn[e].observing && wn(dn, e, {
            ...yn,
            value: mn[e]
        })
    }
    Array.prototype.slice;
    let Sn = class {
        constructor(e, t, n) {
            kn || (kn = !0, xn()), this.inBatch = !1, this.collection = n, this.persistentFlags = 2080374799 & e, this.indexMap = Dt(n.size), this.lifecycle = t, this.lengthObserver = void 0, n.$observer = this
        }
        notify() {
            this.lifecycle.batch.depth > 0 ? this.inBatch || (this.inBatch = !0, this.lifecycle.batch.add(this)) : this.flushBatch(0)
        }
        getLengthObserver() {
            return void 0 === this.lengthObserver && (this.lengthObserver = new hn(this.collection)), this.lengthObserver
        }
        flushBatch(e) {
            this.inBatch = !1;
            const {
                indexMap: t,
                collection: n
            } = this, {
                size: i
            } = n;
            this.indexMap = Dt(i), this.callCollectionSubscribers(t, 16 | this.persistentFlags), void 0 !== this.lengthObserver && this.lengthObserver.setValue(i, 16)
        }
    };

    function On(e, t, n) {
        return void 0 === n.$observer && (n.$observer = new Sn(e, t, n)), n.$observer
    }
    Sn = Object(s.__decorate)([c()], Sn);
    const Cn = Set.prototype,
        An = Cn.add,
        Tn = Cn.clear,
        En = Cn.delete,
        jn = {
            add: An,
            clear: Tn,
            delete: En
        },
        Mn = ["add", "clear", "delete"],
        Ln = {
            add: function(e) {
                let t = this;
                void 0 !== t.$raw && (t = t.$raw);
                const n = t.$observer;
                if (void 0 === n) return An.call(t, e), this;
                const i = t.size;
                An.call(t, e);
                return t.size === i || (n.indexMap[i] = -2, n.notify()), this
            },
            clear: function() {
                let e = this;
                void 0 !== e.$raw && (e = e.$raw);
                const t = e.$observer;
                if (void 0 === t) return Tn.call(e);
                if (e.size > 0) {
                    const n = t.indexMap;
                    let i = 0;
                    for (const t of e.keys()) n[i] > -1 && n.deletedItems.push(n[i]), i++;
                    Tn.call(e), n.length = 0, t.notify()
                }
            },
            delete: function(e) {
                let t = this;
                void 0 !== t.$raw && (t = t.$raw);
                const n = t.$observer;
                if (void 0 === n) return En.call(t, e);
                if (0 === t.size) return !1;
                let i = 0;
                const r = n.indexMap;
                for (const s of t.keys()) {
                    if (s === e) {
                        r[i] > -1 && r.deletedItems.push(r[i]), r.splice(i, 1);
                        const s = En.call(t, e);
                        return !0 === s && n.notify(), s
                    }
                    i++
                }
                return !1
            }
        },
        Pn = {
            writable: !0,
            enumerable: !1,
            configurable: !0
        },
        Rn = Reflect.defineProperty;
    for (const e of Mn) Rn(Ln[e], "observing", {
        value: !0,
        writable: !1,
        configurable: !1,
        enumerable: !1
    });
    let In = !1;

    function Dn() {
        for (const e of Mn) !0 !== Cn[e].observing && Rn(Cn, e, {
            ...Pn,
            value: Ln[e]
        })
    }

    function Nn() {
        for (const e of Mn) !0 === Cn[e].observing && Rn(Cn, e, {
            ...Pn,
            value: jn[e]
        })
    }
    Array.prototype.slice;
    let Vn = class {
        constructor(e, t, n) {
            In || (In = !0, Dn()), this.inBatch = !1, this.collection = n, this.persistentFlags = 2080374799 & e, this.indexMap = Dt(n.size), this.lifecycle = t, this.lengthObserver = void 0, n.$observer = this
        }
        notify() {
            this.lifecycle.batch.depth > 0 ? this.inBatch || (this.inBatch = !0, this.lifecycle.batch.add(this)) : this.flushBatch(0)
        }
        getLengthObserver() {
            return void 0 === this.lengthObserver && (this.lengthObserver = new hn(this.collection)), this.lengthObserver
        }
        flushBatch(e) {
            this.inBatch = !1;
            const {
                indexMap: t,
                collection: n
            } = this, {
                size: i
            } = n;
            this.indexMap = Dt(i), this.callCollectionSubscribers(t, 16 | this.persistentFlags), void 0 !== this.lengthObserver && this.lengthObserver.setValue(i, 16)
        }
    };

    function $n(e, t, n) {
        return void 0 === n.$observer && (n.$observer = new Vn(e, t, n)), n.$observer
    }
    Vn = Object(s.__decorate)([c()], Vn);
    Array.prototype.slice;

    function Fn(e) {
        return function(t, n) {
            t.computed || Reflect.defineProperty(t, "computed", {
                writable: !0,
                configurable: !0,
                enumerable: !1,
                value: Object.create(null)
            }), t.computed[n] = e
        }
    }
    const Un = {
        static: !1,
        volatile: !1
    };

    function Bn(e, t, n, i, s, o, a) {
        if (!1 === a.configurable) return n.createProperty(s, o);
        if (a.get) {
            const {
                constructor: {
                    prototype: {
                        computed: n
                    }
                }
            } = s, r = n && n[o] || Un;
            return a.set ? r.volatile ? new Hn(e, r, s, o, a, t, i) : new zn(s, o, a) : new Hn(e, r, s, o, a, t, i)
        }
        throw r.k.error(18, o)
    }
    let zn = class {
        constructor(e, t, n) {
            this.obj = e, this.propertyKey = t, this.currentValue = this.oldValue = void 0, this.descriptor = n, this.observing = !1
        }
        setValue(e) {
            this.descriptor.set.call(this.obj, e), this.currentValue !== e && (this.oldValue = this.currentValue, this.currentValue = e, this.callSubscribers(e, this.oldValue, 16))
        }
        subscribe(e) {
            this.observing || this.convertProperty(), this.addSubscriber(e)
        }
        unsubscribe(e) {
            this.removeSubscriber(e)
        }
        convertProperty() {
            this.observing = !0, this.currentValue = this.obj[this.propertyKey];
            Reflect.defineProperty(this.obj, this.propertyKey, {
                set: e => {
                    this.setValue(e)
                },
                get: this.descriptor.get
            })
        }
    };
    zn = Object(s.__decorate)([o()], zn);
    let Hn = class {
        constructor(e, t, n, i, r, s, o) {
            this.obj = n, this.propertyKey = i, this.isCollecting = !1, this.currentValue = this.oldValue = void 0, this.propertyDeps = [], this.collectionDeps = [], this.overrides = t, this.subscriberCount = 0, this.descriptor = r, this.proxy = new Proxy(n, qn(e, s, this));
            Reflect.defineProperty(n, i, {
                get: () => this.getValue(),
                set: r.set
            })
        }
        addPropertyDep(e) {
            this.propertyDeps.includes(e) || this.propertyDeps.push(e)
        }
        addCollectionDep(e) {
            this.collectionDeps.includes(e) || this.collectionDeps.push(e)
        }
        getValue() {
            return 0 === this.subscriberCount || this.isCollecting ? this.currentValue = Reflect.apply(this.descriptor.get, this.proxy, r.g.emptyArray) : this.currentValue = Reflect.apply(this.descriptor.get, this.obj, r.g.emptyArray), this.currentValue
        }
        subscribe(e) {
            this.addSubscriber(e), 1 == ++this.subscriberCount && this.getValueAndCollectDependencies(!0)
        }
        unsubscribe(e) {
            this.removeSubscriber(e), 0 == --this.subscriberCount && this.unsubscribeAllDependencies()
        }
        handleChange() {
            const e = this.currentValue,
                t = this.getValueAndCollectDependencies(!1);
            e !== t && this.callSubscribers(t, e, 16)
        }
        handleCollectionChange() {
            const e = this.currentValue,
                t = this.getValueAndCollectDependencies(!1);
            e !== t && this.callSubscribers(t, e, 16)
        }
        getValueAndCollectDependencies(e) {
            const t = !this.overrides.static || e;
            return t && (this.unsubscribeAllDependencies(), this.isCollecting = !0), this.currentValue = this.getValue(), t && (this.propertyDeps.forEach(e => {
                e.subscribe(this)
            }), this.collectionDeps.forEach(e => {
                e.subscribeToCollection(this)
            }), this.isCollecting = !1), this.currentValue
        }
        doNotCollect(e) {
            return !this.isCollecting || "$observers" === e
        }
        unsubscribeAllDependencies() {
            this.propertyDeps.forEach(e => {
                e.unsubscribe(this)
            }), this.propertyDeps.length = 0, this.collectionDeps.forEach(e => {
                e.unsubscribeFromCollection(this)
            }), this.collectionDeps.length = 0
        }
    };
    Hn = Object(s.__decorate)([o()], Hn);
    const Wn = Object.prototype.toString;

    function qn(e, t, n) {
        return {
            get: function(i, r, s) {
                if (n.doNotCollect(r)) return Reflect.get(i, r, s);
                switch (Wn.call(i)) {
                    case "[object Array]":
                        if (n.addCollectionDep(t.getArrayObserver(e, i)), "length" === r) return Reflect.get(i, r, i);
                    case "[object Map]":
                        if (n.addCollectionDep(t.getMapObserver(e, i)), "size" === r) return Reflect.get(i, r, i);
                    case "[object Set]":
                        if (n.addCollectionDep(t.getSetObserver(e, i)), "size" === r) return Reflect.get(i, r, i);
                    default:
                        n.addPropertyDep(t.getObserver(e, i, r))
                }
                return function(e, t, n, i, r) {
                    const s = Reflect.get(t, n, t);
                    if ("function" == typeof s) return t[n].bind(t);
                    if ("object" != typeof s || null === s) return s;
                    return new Proxy(s, qn(e, i, r))
                }(e, i, r, t, n)
            }
        }
    }
    const Gn = r.a.createInterface("IDirtyChecker").withDefault(e => e.singleton(Yn)),
        Kn = {
            framesPerCheck: 6,
            disabled: !1,
            warn: !0,
            throw: !1,
            resetToDefault() {
                this.framesPerCheck = 6, this.disabled = !1, this.warn = !0, this.throw = !1
            }
        };
    class Yn {
        constructor(e) {
            this.elapsedFrames = 0, this.tracked = [], this.lifecycle = e
        }
        createProperty(e, t) {
            if (Kn.throw) throw r.k.error(800, t);
            return Kn.warn && r.k.write(801, t), new Xn(this, e, t)
        }
        addProperty(e) {
            this.tracked.push(e), 1 === this.tracked.length && this.lifecycle.enqueueRAF(this.check, this, 4096)
        }
        removeProperty(e) {
            this.tracked.splice(this.tracked.indexOf(e), 1), 0 === this.tracked.length && this.lifecycle.dequeueRAF(this.check, this)
        }
        check(e) {
            if (Kn.disabled) return;
            if (++this.elapsedFrames < Kn.framesPerCheck) return;
            this.elapsedFrames = 0;
            const t = this.tracked,
                n = t.length;
            let i, r = 0;
            for (; r < n; ++r) i = t[r], i.isDirty() && i.flush(256)
        }
    }
    Yn.inject = [Xe];
    Array.prototype.slice;
    let Xn = class {
        constructor(e, t, n) {
            this.obj = t, this.propertyKey = n, this.dirtyChecker = e
        }
        isDirty() {
            return this.oldValue !== this.obj[this.propertyKey]
        }
        flush(e) {
            const t = this.oldValue,
                n = this.obj[this.propertyKey];
            this.callSubscribers(n, t, 16 | e), this.oldValue = n
        }
        subscribe(e) {
            this.hasSubscribers() || (this.oldValue = this.obj[this.propertyKey], this.dirtyChecker.addProperty(this)), this.addSubscriber(e)
        }
        unsubscribe(e) {
            this.removeSubscriber(e) && !this.hasSubscribers() && this.dirtyChecker.removeProperty(this)
        }
    };
    Xn = Object(s.__decorate)([o()], Xn);
    Array.prototype.slice;
    const Jn = r.g.noop;
    class Qn {
        constructor(e, t) {
            this.doNotCache = !0, "length" === t ? (this.obj = e, this.getValue = this.getStringLength) : this.getValue = this.returnUndefined
        }
        getStringLength() {
            return this.obj.length
        }
        returnUndefined() {}
    }
    Qn.prototype.setValue = Jn, Qn.prototype.subscribe = Jn, Qn.prototype.unsubscribe = Jn, Qn.prototype.dispose = Jn;
    Array.prototype.slice;
    class Zn {
        constructor(e, t) {
            this.obj = e, this.propertyKey = t, void 0 !== e.$observers && void 0 !== e.$observers[t] && void 0 !== e.$observers[t].setValue && (this.setValue = this.setValueDirect)
        }
        getValue() {
            return this.obj[this.propertyKey]
        }
        setValue(e, t) {
            this.obj[this.propertyKey] = e
        }
        setValueDirect(e, t) {
            this.obj.$observers[this.propertyKey].setValue(e, t)
        }
    }
    const ei = Object.prototype.toString,
        ti = r.a.createInterface("IObserverLocator").noDefault(),
        ni = r.a.createInterface("ITargetObserverLocator").noDefault(),
        ii = r.a.createInterface("ITargetAccessorLocator").noDefault();
    class ri {
        constructor(e, t, n, i) {
            this.adapters = [], this.dirtyChecker = t, this.lifecycle = e, this.targetObserverLocator = n, this.targetAccessorLocator = i
        }
        static register(e) {
            return r.j.singleton(ti, this).register(e)
        }
        getObserver(e, t, n) {
            if (2 & e && "object" == typeof t) return A.getOrCreate(t, n);
            if (function(e) {
                    return !0 === e.$synthetic
                }(t)) return t.getObservers(e).getOrCreate(this.lifecycle, e, t, n);
            let i = t.$observers;
            if (i && n in i) return i[n];
            const r = this.createPropertyObserver(e, t, n);
            return r.doNotCache || (void 0 === i && (i = this.getOrCreateObserversLookup(t)), i[n] = r), r
        }
        addAdapter(e) {
            this.adapters.push(e)
        }
        getAccessor(e, t, n) {
            return this.targetAccessorLocator.handles(e, t) ? this.targetObserverLocator.overridesAccessor(e, t, n) ? this.getObserver(e, t, n) : this.targetAccessorLocator.getAccessor(e, this.lifecycle, t, n) : 2 & e ? A.getOrCreate(t, n) : new Zn(t, n)
        }
        getArrayObserver(e, t) {
            return cn(e, this.lifecycle, t)
        }
        getMapObserver(e, t) {
            return On(e, this.lifecycle, t)
        }
        getSetObserver(e, t) {
            return $n(e, this.lifecycle, t)
        }
        getOrCreateObserversLookup(e) {
            return e.$observers || this.createObserversLookup(e)
        }
        createObserversLookup(e) {
            const t = {};
            return Reflect.defineProperty(e, "$observers", {
                enumerable: !1,
                configurable: !1,
                writable: !1,
                value: t
            }) || r.k.write(0, e), t
        }
        getAdapterObserver(e, t, n, i) {
            for (let r = 0, s = this.adapters.length; r < s; r++) {
                const s = this.adapters[r].getObserver(e, t, n, i);
                if (null != s) return s
            }
            return null
        }
        createPropertyObserver(e, t, n) {
            if (!(t instanceof Object)) return new Qn(t, n);
            let i = !1;
            if (this.targetObserverLocator.handles(e, t)) {
                const r = this.targetObserverLocator.getObserver(e, this.lifecycle, this, t, n);
                if (null != r) return r;
                i = !0
            }
            switch (ei.call(t)) {
                case "[object Array]":
                    return "length" === n ? this.getArrayObserver(e, t).getLengthObserver() : this.dirtyChecker.createProperty(t, n);
                case "[object Map]":
                    return "size" === n ? this.getMapObserver(e, t).getLengthObserver() : this.dirtyChecker.createProperty(t, n);
                case "[object Set]":
                    return "size" === n ? this.getSetObserver(e, t).getLengthObserver() : this.dirtyChecker.createProperty(t, n)
            }
            const r = function(e, t) {
                let n = Object.getOwnPropertyDescriptor(e, t),
                    i = Object.getPrototypeOf(e);
                for (; null == n && null != i;) n = Object.getOwnPropertyDescriptor(i, t), i = Object.getPrototypeOf(i);
                return n
            }(t, n);
            if (r && (r.get || r.set)) {
                if (r.get && r.get.getObserver) return r.get.getObserver(t);
                const s = this.getAdapterObserver(e, t, n, r);
                return s || (i ? this.dirtyChecker.createProperty(t, n) : Bn(e, this, this.dirtyChecker, this.lifecycle, t, n, r))
            }
            return new T(this.lifecycle, e, t, n)
        }
    }

    function si(e, t, n) {
        const i = n instanceof Object ? A.getRawIfProxy(n) : n;
        switch (ei.call(n)) {
            case "[object Array]":
                return cn(e, t, i);
            case "[object Map]":
                return On(e, t, i);
            case "[object Set]":
                return $n(e, t, i)
        }
    }
    ri.inject = [Xe, Gn, ni, ii];
    let oi = class {
        constructor(e, t, n, i, r) {
            this.lifecycle = e;
            let s = !1;
            A.isProxy(n) ? (s = !0, n.$observer.subscribe(this, i), this.obj = n.$raw) : this.obj = n, this.propertyKey = i, this.currentValue = void 0, this.oldValue = void 0, this.inBatch = !1, this.callback = this.obj[r], void 0 === this.callback ? this.observing = !1 : (this.observing = !0, this.currentValue = this.obj[this.propertyKey], s || this.createGetterSetter()), this.persistentFlags = 2080374799 & t
        }
        handleChange(e, t, n) {
            this.setValue(e, n)
        }
        getValue() {
            return this.currentValue
        }
        setValue(e, t) {
            if (this.observing) {
                const n = this.currentValue;
                if (this.currentValue = e, 0 === this.lifecycle.batch.depth) {
                    if (this.callSubscribers(e, n, this.persistentFlags | t), 0 == (4096 & t) || (32 & t) > 0) {
                        const i = this.callback;
                        void 0 !== i && i.call(this.obj, e, n, this.persistentFlags | t)
                    }
                } else this.inBatch || (this.inBatch = !0, this.oldValue = n, this.lifecycle.batch.add(this))
            } else this.obj[this.propertyKey] = e
        }
        subscribe(e) {
            !1 === this.observing && (this.observing = !0, this.currentValue = this.obj[this.propertyKey], this.createGetterSetter()), this.addSubscriber(e)
        }
        createGetterSetter() {
            Reflect.defineProperty(this.obj, this.propertyKey, {
                enumerable: !0,
                configurable: !0,
                get: () => this.currentValue,
                set: e => {
                    this.setValue(e, 0)
                }
            }) || r.k.write(1, this.propertyKey, this.obj)
        }
    };
    oi = Object(s.__decorate)([o()], oi);
    class ai {
        constructor(e) {
            this.mode = e, this.originalModes = new WeakMap
        }
        bind(e, t, n) {
            this.originalModes.set(n, n.mode), n.mode = this.mode
        }
        unbind(e, t, n) {
            n.mode = this.originalModes.get(n)
        }
    }
    let ci = class extends ai {
        constructor() {
            super(Ve.oneTime)
        }
    };
    ci = Object(s.__decorate)([z("oneTime")], ci);
    let li = class extends ai {
        constructor() {
            super(Ve.toView)
        }
    };
    li = Object(s.__decorate)([z("toView")], li);
    let ui = class extends ai {
        constructor() {
            super(Ve.fromView)
        }
    };
    ui = Object(s.__decorate)([z("fromView")], ui);
    let hi = class extends ai {
        constructor() {
            super(Ve.twoWay)
        }
    };
    hi = Object(s.__decorate)([z("twoWay")], hi);
    const di = {};

    function pi(e, t, n) {
        const i = this.debounceState;
        r.g.global.clearTimeout(i.timeoutId), i.timeoutId = r.g.global.setTimeout(() => {
            this.debouncedMethod(e, t, n)
        }, i.delay)
    }

    function fi(e, t, n) {
        const i = this.debounceState;
        if (r.g.global.clearTimeout(i.timeoutId), !(n & i.callContextToDebounce)) return i.oldValue = di, void this.debouncedMethod(e, t, n);
        i.oldValue === di && (i.oldValue = t);
        const s = r.g.global.setTimeout(() => {
            const t = i.oldValue;
            i.oldValue = di, this.debouncedMethod(e, t, n)
        }, i.delay);
        i.timeoutId = s
    }
    const gi = Ve.fromView;
    let mi = class {
        bind(e, t, n, i = 200) {
            let r, s, o;
            n instanceof kt ? (r = "handleChange", o = fi, s = n.mode & gi ? 32 : 16) : (r = "callSource", o = pi, s = 16), n.debouncedMethod = n[r], n.debouncedMethod.originalName = r, n[r] = o, n.debounceState = {
                callContextToDebounce: s,
                delay: i,
                timeoutId: 0,
                oldValue: di
            }
        }
        unbind(e, t, n) {
            n[n.debouncedMethod.originalName] = n.debouncedMethod, n.debouncedMethod = null, r.g.global.clearTimeout(n.debounceState.timeoutId), n.debounceState = null
        }
    };
    mi = Object(s.__decorate)([z("debounce")], mi);
    let vi = class {
        bind(e, t = 4096) {
            const {
                targetObserver: n
            } = e;
            if (null != n)
                if (this[e.id] = n.priority, "number" == typeof t) n.priority = t;
                else switch (t) {
                    case "preempt":
                        n.priority = 32768;
                        break;
                    case "high":
                        n.priority = 28672;
                        break;
                    case "bind":
                        n.priority = 24576;
                        break;
                    case "attach":
                        n.priority = 20480;
                        break;
                    case "normal":
                        n.priority = 16384;
                        break;
                    case "propagate":
                        n.priority = 12288;
                        break;
                    case "connect":
                        n.priority = 8192;
                        break;
                    case "low":
                        n.priority = 4096
                }
        }
        unbind(e) {
            null != e.targetObserver && (e.targetObserver.priority = this[e.id])
        }
    };
    vi = Object(s.__decorate)([z("priority")], vi);
    let bi = class {
        constructor(e) {
            this.signaler = e
        }
        bind(e, t, n, ...i) {
            if (!n.updateTarget) throw r.k.error(11);
            if (4 === arguments.length) {
                const e = i[0];
                this.signaler.addSignalListener(e, n), n.signal = e
            } else {
                if (!(arguments.length > 4)) throw r.k.error(12);
                {
                    const e = Array.prototype.slice.call(i.length + 3, 3);
                    let t = e.length;
                    for (; t--;) {
                        const i = e[t];
                        this.signaler.addSignalListener(i, n)
                    }
                    n.signal = e
                }
            }
        }
        unbind(e, t, n) {
            const i = n.signal;
            if (n.signal = null, Array.isArray(i)) {
                const e = i;
                let t = e.length;
                for (; t--;) this.signaler.removeSignalListener(e[t], n)
            } else this.signaler.removeSignalListener(i, n)
        }
    };

    function yi(e) {
        const t = this.throttleState,
            n = +new Date - t.last;
        if (n >= t.delay) return r.g.global.clearTimeout(t.timeoutId), t.timeoutId = -1, t.last = +new Date, void this.throttledMethod(e);
        if (t.newValue = e, -1 === t.timeoutId) {
            const e = r.g.global.setTimeout(() => {
                t.timeoutId = -1, t.last = +new Date, this.throttledMethod(t.newValue)
            }, t.delay - n);
            t.timeoutId = e
        }
    }
    bi = Object(s.__decorate)([z("signal"), Object(s.__param)(0, I)], bi);
    let wi = class {
        bind(e, t, n, i = 200) {
            let r;
            r = n instanceof kt ? n.mode === Ve.twoWay ? "updateSource" : "updateTarget" : "callSource", n.throttledMethod = n[r], n.throttledMethod.originalName = r, n[r] = yi, n.throttleState = {
                delay: i,
                last: 0,
                timeoutId: -1
            }
        }
        unbind(e, t, n) {
            n[n.throttledMethod.originalName] = n.throttledMethod, n.throttledMethod = null, r.g.global.clearTimeout(n.throttleState.timeoutId), n.throttleState = null
        }
    };

    function ki(e, t) {
        let n;

        function i(e, t) {
            arguments.length > 1 && (n.property = t), r.f.define(_i.name, Si.create(t, n), e.constructor, t), r.i.annotation.appendTo(e.constructor, _i.keyFrom(t))
        }
        return arguments.length > 1 ? (n = {}, void i(e, t)) : "string" == typeof e ? (n = {}, i) : (n = void 0 === e ? {} : e, i)
    }

    function xi(e) {
        return e.startsWith(_i.name)
    }
    wi = Object(s.__decorate)([z("throttle")], wi);
    const _i = {
        name: r.i.annotation.keyFor("bindable"),
        keyFrom: e => `${_i.name}:${e}`,
        from(...e) {
            const t = {},
                n = Array.isArray;

            function i(e) {
                t[e] = Si.create(e)
            }
            return e.forEach((function(e) {
                n(e) ? e.forEach(i) : e instanceof Si ? t[e.property] = e : void 0 !== e && Object.keys(e).forEach(n => function(e, n) {
                    t[e] = n instanceof Si ? n : Si.create(e, n)
                }(n, e[n]))
            })), t
        },
        for (e) {
            let t;
            const n = {
                add(i) {
                    let s, o;
                    return "string" == typeof i ? (s = i, o = {
                        property: s
                    }) : (s = i.property, o = i), t = Si.create(s, o), r.f.hasOwn(_i.name, e, s) || r.i.annotation.appendTo(e, _i.keyFrom(s)), r.f.define(_i.name, t, e, s), n
                },
                mode: e => (t.mode = e, n),
                callback: e => (t.callback = e, n),
                attribute: e => (t.attribute = e, n),
                primary: () => (t.primary = !0, n)
            };
            return n
        },
        getAll(e) {
            const t = _i.name.length + 1,
                n = [],
                i = Object(r.u)(e);
            let s, o, a, c = i.length,
                l = 0;
            for (; --c >= 0;) {
                a = i[c], s = r.i.annotation.getKeys(a).filter(xi), o = s.length;
                for (let e = 0; e < o; ++e) n[l++] = r.f.getOwn(_i.name, a, s[e].slice(t))
            }
            return n
        }
    };
    class Si {
        constructor(e, t, n, i, r) {
            this.attribute = e, this.callback = t, this.mode = n, this.primary = i, this.property = r
        }
        static create(e, t = {}) {
            return new Si(Object(r.q)(t.attribute, Object(r.y)(e)), Object(r.q)(t.callback, e + "Changed"), Object(r.q)(t.mode, Ve.toView), Object(r.q)(t.primary, !1), Object(r.q)(t.property, e))
        }
    }

    function Oi(e) {
        return function(t) {
            return Ti.define(e, t)
        }
    }

    function Ci(e) {
        return function(t) {
            return Ti.define("string" == typeof e ? {
                isTemplateController: !0,
                name: e
            } : {
                isTemplateController: !0,
                ...e
            }, t)
        }
    }
    class Ai {
        constructor(e, t, n, i, r, s, o, a, c) {
            this.Type = e, this.name = t, this.aliases = n, this.key = i, this.defaultBindingMode = r, this.isTemplateController = s, this.bindables = o, this.strategy = a, this.hooks = c
        }
        static create(e, t) {
            let n, i;
            return "string" == typeof e ? (n = e, i = {
                name: n
            }) : (n = e.name, i = e), new Ai(t, Object(r.q)(Ti.getAnnotation(t, "name"), n), Object(r.z)(Ti.getAnnotation(t, "aliases"), i.aliases, t.aliases), Ti.keyFrom(n), Object(r.q)(Ti.getAnnotation(t, "defaultBindingMode"), i.defaultBindingMode, t.defaultBindingMode, Ve.toView), Object(r.q)(Ti.getAnnotation(t, "isTemplateController"), i.isTemplateController, t.isTemplateController, !1), _i.from(..._i.getAll(t), Ti.getAnnotation(t, "bindables"), t.bindables, i.bindables), Object(r.q)(Ti.getAnnotation(t, "strategy"), i.strategy, t.strategy, 1), Object(r.q)(Ti.getAnnotation(t, "hooks"), i.hooks, t.hooks, new F(t.prototype)))
        }
        register(e) {
            const {
                Type: t,
                key: n,
                aliases: i
            } = this;
            r.j.transient(n, t).register(e), r.j.alias(n, t).register(e), B(i, Ti, n, e)
        }
    }
    const Ti = {
            name: r.i.resource.keyFor("custom-attribute"),
            keyFrom: e => `${Ti.name}:${e}`,
            isType: e => "function" == typeof e && r.f.hasOwn(Ti.name, e),
            define(e, t) {
                const n = Ai.create(e, t);
                return r.f.define(Ti.name, n, n.Type), r.f.define(Ti.name, n, n), r.i.resource.appendTo(t, Ti.name), n.Type
            },
            getDefinition(e) {
                const t = r.f.getOwn(Ti.name, e);
                if (void 0 === t) throw new Error("No definition found for type " + e.name);
                return t
            },
            annotate(e, t, n) {
                r.f.define(r.i.annotation.keyFor(t), n, e)
            },
            getAnnotation: (e, t) => r.f.getOwn(r.i.annotation.keyFor(t), e)
        },
        Ei = r.a.createInterface("INode").noDefault(),
        ji = r.a.createInterface("IRenderLocation").noDefault(),
        Mi = r.a.createInterface("IDOM").noDefault(),
        Li = function(...e) {
            throw r.k.error(1e3)
        },
        Pi = {
            addEventListener: Li,
            appendChild: Li,
            cloneNode: Li,
            convertToRenderLocation: Li,
            createDocumentFragment: Li,
            createElement: Li,
            createCustomEvent: Li,
            dispatchEvent: Li,
            createNodeObserver: Li,
            createTemplate: Li,
            createTextNode: Li,
            insertBefore: Li,
            isMarker: Li,
            isNodeInstance: Li,
            isRenderLocation: Li,
            makeTarget: Li,
            registerElementResolver: Li,
            remove: Li,
            removeEventListener: Li,
            setAttribute: Li
        },
        Ri = {
            ...Pi,
            get isInitialized() {
                return !0 === Reflect.get(this, "$initialized")
            },
            initialize(e) {
                if (this.isInitialized) throw r.k.error(1001);
                const t = {},
                    n = [e];
                let i = Object.getPrototypeOf(e);
                for (; i && i !== Object.prototype;) n.unshift(i), i = Object.getPrototypeOf(i);
                for (i of n) Object.assign(t, Object.getOwnPropertyDescriptors(i));
                const s = [];
                let o, a;
                for (o in t) a = t[o], a.configurable && a.writable && (Reflect.defineProperty(this, o, a), s.push(o));
                Reflect.set(this, "$domKeys", s), Reflect.set(this, "$initialized", !0)
            },
            destroy() {
                if (!this.isInitialized) throw r.k.error(1002);
                Reflect.get(this, "$domKeys").forEach(e => {
                    Reflect.deleteProperty(this, e)
                }), Object.assign(this, Pi), Reflect.set(this, "$domKeys", r.g.emptyArray), Reflect.set(this, "$initialized", !1)
            }
        },
        Ii = {
            empty: {
                isMounted: !1,
                isLinked: !1,
                next: void 0,
                childNodes: r.g.emptyArray,
                firstChild: null,
                lastChild: null,
                findTargets: () => r.g.emptyArray,
                insertBefore(e) {},
                appendTo(e) {},
                remove() {},
                addToLinked() {},
                unlink() {},
                link(e) {}
            }
        };
    class Di {
        constructor(e, t, n) {
            this.factory = e, this.flags = n, this.id = Object(r.B)("au$component"), this.view = this.factory.create(), this.view.hold(t, 1)
        }
        binding(e) {
            return this.view.parent = this.$controller, this.view.bind(e | this.flags, this.$controller.scope)
        }
        attaching(e) {
            this.view.attach(e)
        }
        detaching(e) {
            this.view.detach(e)
        }
        unbinding(e) {
            const t = this.view.unbind(e);
            return this.view.parent = void 0, t
        }
    }
    let Ni = class extends Di {
        constructor(e, t) {
            super(e, t, 268435456)
        }
    };
    Ni = Object(s.__decorate)([Ci("infrequent-mutations"), Object(s.__param)(0, Ge), Object(s.__param)(1, ji)], Ni);
    let Vi = class extends Di {
        constructor(e, t) {
            super(e, t, 536870912)
        }
    };
    Vi = Object(s.__decorate)([Ci("frequent-mutations"), Object(s.__param)(0, Ge), Object(s.__param)(1, ji)], Vi);
    let $i = class extends Di {
        constructor(e, t) {
            super(e, t, 134217728)
        }
    };
    $i = Object(s.__decorate)([Ci("observe-shallow"), Object(s.__param)(0, Ge), Object(s.__param)(1, ji)], $i);
    const Fi = {
        done: {
            done: !0,
            canCancel: () => !1,
            cancel() {},
            wait: () => Promise.resolve()
        }
    };
    var Ui;
    ! function(e) {
        e[e.beforeCreate = 0] = "beforeCreate", e[e.beforeRender = 1] = "beforeRender", e[e.beforeBind = 2] = "beforeBind", e[e.beforeAttach = 3] = "beforeAttach"
    }(Ui || (Ui = {}));
    const Bi = r.a.createInterface("IStartTask").noDefault();
    var zi;
    ! function(e) {
        e[e.with = 0] = "with", e[e.from = 1] = "from"
    }(zi || (zi = {}));
    const Hi = class e {
            constructor(e) {
                this.type = e, this._slot = void 0, this._promiseOrTask = void 0, this._container = void 0, this._key = void 0, this._callback = void 0, this._task = void 0
            }
            get slot() {
                if (void 0 === this._slot) throw new Error("StartTask.slot is not set");
                return this._slot
            }
            get promiseOrTask() {
                if (void 0 === this._promiseOrTask) throw new Error("StartTask.promiseOrTask is not set");
                return this._promiseOrTask
            }
            get container() {
                if (void 0 === this._container) throw new Error("StartTask.container is not set");
                return this._container
            }
            get key() {
                if (void 0 === this._key) throw new Error("StartTask.key is not set");
                return this._key
            }
            get callback() {
                if (void 0 === this._callback) throw new Error("StartTask.callback is not set");
                return this._callback
            }
            get task() {
                if (void 0 === this._task) throw new Error("StartTask.task is not set");
                return this._task
            }
            static with(t) {
                const n = new e(0);
                return n._key = t, n
            }
            static from(t) {
                const n = new e(1);
                return n._promiseOrTask = t, n
            }
            beforeCreate() {
                return this.at(0)
            }
            beforeRender() {
                return this.at(1)
            }
            beforeBind() {
                return this.at(2)
            }
            beforeAttach() {
                return this.at(3)
            }
            at(e) {
                return this._slot = e, this
            }
            call(e) {
                return this._callback = e, this
            }
            register(e) {
                return this._container = e.register(r.j.instance(Bi, this))
            }
            resolveTask() {
                if (void 0 === this._task) switch (this.type) {
                    case 0:
                        this._task = new Ki(this.container, this.key, this.callback);
                        break;
                    case 1:
                        this._task = new Xi(this.promiseOrTask)
                }
                return this.task
            }
        },
        Wi = r.a.createInterface("IStartTaskManager").noDefault();
    class qi {
        constructor(e) {
            this.locator = e
        }
        static register(e) {
            return r.j.singleton(Wi, this).register(e)
        }
        runBeforeCreate(e = this.locator) {
            return this.run(0, e)
        }
        runBeforeRender(e = this.locator) {
            return this.run(1, e)
        }
        runBeforeBind(e = this.locator) {
            return this.run(2, e)
        }
        runBeforeAttach(e = this.locator) {
            return this.run(3, e)
        }
        run(e, t = this.locator) {
            const n = t.getAll(Bi).filter(t => t.slot === e).map(e => e.resolveTask()).filter(e => !e.done);
            return 0 === n.length ? Fi.done : new Qi(n)
        }
    }
    qi.inject = [r.d];
    class Gi {
        constructor(e, t, n, ...i) {
            this.done = !1, this.isCancelled = !1, this.hasStarted = !1, this.promise = e.then(e => {
                if (!0 !== this.isCancelled && (this.hasStarted = !0, null !== t)) {
                    const r = t.call(n, e, ...i);
                    if (void 0 !== r) {
                        return (r.then instanceof Function ? r : r.wait()).then(() => {
                            this.done = !0
                        })
                    }
                    this.done = !0
                }
            })
        }
        canCancel() {
            return !this.hasStarted
        }
        cancel() {
            this.canCancel() && (this.isCancelled = !0)
        }
        wait() {
            return this.promise
        }
    }
    class Ki {
        constructor(e, t, n) {
            this.container = e, this.key = t, this.callback = n, this.done = !1
        }
        canCancel() {
            return !1
        }
        cancel() {}
        wait() {
            if (void 0 === this.promise) {
                const e = this.container.get(this.key),
                    t = this.callback.call(void 0, e);
                this.promise = void 0 === t ? Promise.resolve() : t.then instanceof Function ? t : t.wait(), this.promise = this.promise.then(() => {
                    this.done = !0, this.container = void 0, this.key = void 0, this.callback = void 0
                }).catch(e => {
                    throw e
                })
            }
            return this.promise
        }
    }
    class Yi {
        constructor(e, t, n, ...i) {
            this.done = !1, this.hasStarted = !1, this.isCancelled = !1;
            const r = e.then instanceof Function ? e : e.wait();
            this.promise = r.then(() => {
                if (!0 === this.isCancelled) return;
                this.hasStarted = !0;
                const e = t.call(n, ...i);
                if (void 0 !== e) {
                    return (e.then instanceof Function ? e : e.wait()).then(() => {
                        this.done = !0
                    })
                }
                this.done = !0
            })
        }
        canCancel() {
            return !this.hasStarted
        }
        cancel() {
            this.canCancel() && (this.isCancelled = !0)
        }
        wait() {
            return this.promise
        }
    }
    class Xi {
        constructor(e) {
            this.done = !1, this.promise = e.then instanceof Function ? e : e.wait(), this.promise.then(() => {
                this.done = !0
            }).catch(e => {
                throw e
            })
        }
        canCancel() {
            return !1
        }
        cancel() {}
        wait() {
            return this.promise
        }
    }
    class Ji {
        constructor(e, t, n, ...i) {
            this.done = !1, this.hasStarted = !1, this.isCancelled = !1, this.promise = Promise.all(e.map(e => e.wait())).then(() => {
                if (!0 === this.isCancelled) return;
                this.hasStarted = !0;
                const e = t.call(n, ...i);
                if (void 0 !== e) return e.wait().then(() => {
                    this.done = !0
                });
                this.done = !0
            })
        }
        canCancel() {
            return !this.hasStarted
        }
        cancel() {
            this.canCancel() && (this.isCancelled = !0)
        }
        wait() {
            return this.promise
        }
    }
    class Qi {
        constructor(e) {
            this.done = !1, this.promise = Promise.all(e.map(e => e.wait())).then(() => {
                this.done = !0
            })
        }
        canCancel() {
            return !1
        }
        cancel() {}
        wait() {
            return this.promise
        }
    }

    function Zi(e) {
        return !(void 0 === e || !0 === e.done)
    }
    let er = class {
        constructor(e, t) {
            this.ifFactory = e, this.location = t, this.id = Object(r.B)("au$component"), this.elseFactory = void 0, this.elseView = void 0, this.ifView = void 0, this.view = void 0, this.task = Fi.done, this.value = !1
        }
        binding(e) {
            return this.task.done ? this.task = this.swap(this.value, e) : this.task = new Yi(this.task, this.swap, this, this.value, e), this.task
        }
        attaching(e) {
            this.task.done ? this.attachView(e) : this.task = new Yi(this.task, this.attachView, this, e)
        }
        detaching(e) {
            return void 0 !== this.view && (this.task.done ? this.view.detach(e) : this.task = new Yi(this.task, this.view.detach, this.view, e)), this.task
        }
        unbinding(e) {
            return void 0 !== this.view && (this.task.done ? this.task = this.view.unbind(e) : this.task = new Yi(this.task, this.view.unbind, this.view, e)), this.task
        }
        caching(e) {
            void 0 !== this.ifView && this.ifView.release(e) && (this.ifView = void 0), void 0 !== this.elseView && this.elseView.release(e) && (this.elseView = void 0), this.view = void 0
        }
        valueChanged(e, t, n) {
            0 != (4 & this.$controller.state) && (this.task.done ? this.task = this.swap(this.value, n) : this.task = new Yi(this.task, this.swap, this, this.value, n))
        }
        updateView(e, t) {
            let n;
            return n = e ? this.ifView = this.ensureView(this.ifView, this.ifFactory, t) : null != this.elseFactory ? this.elseView = this.ensureView(this.elseView, this.elseFactory, t) : void 0, n
        }
        ensureView(e, t, n) {
            return void 0 === e && (e = t.create(n)), e.hold(this.location, 1), e
        }
        swap(e, t) {
            let n = Fi.done;
            if ((!0 === e && void 0 !== this.elseView || !0 !== e && void 0 !== this.ifView) && (n = this.deactivate(t)), n.done) {
                const i = this.updateView(e, t);
                n = this.activate(i, t)
            } else n = new Gi(n.wait().then(() => this.updateView(e, t)), this.activate, this, t);
            return n
        }
        deactivate(e) {
            const t = this.view;
            if (void 0 === t) return Fi.done;
            t.detach(e);
            const n = t.unbind(e);
            return t.parent = void 0, n
        }
        activate(e, t) {
            if (this.view = e, void 0 === e) return Fi.done;
            let n = this.bindView(t);
            return 0 == (32 & this.$controller.state) || (n.done ? this.attachView(t) : n = new Yi(n, this.attachView, this, t)), n
        }
        bindView(e) {
            return void 0 !== this.view && (5 & this.$controller.state) > 0 ? (this.view.parent = this.$controller, this.view.bind(e, this.$controller.scope, this.$controller.part)) : Fi.done
        }
        attachView(e) {
            void 0 !== this.view && (40 & this.$controller.state) > 0 && this.view.attach(e)
        }
    };
    Object(s.__decorate)([ki], er.prototype, "value", void 0), er = Object(s.__decorate)([Ci("if"), Object(s.__param)(0, Ge), Object(s.__param)(1, ji)], er);
    let tr = class {
        constructor(e) {
            this.factory = e, this.id = Object(r.B)("au$component")
        }
        link(e) {
            if (e instanceof er) e.elseFactory = this.factory;
            else {
                if (!(e.viewModel instanceof er)) throw new Error("Unsupported IfBehavior");
                e.viewModel.elseFactory = this.factory
            }
        }
    };
    tr = Object(s.__decorate)([Ci("else"), Object(s.__param)(0, Ge)], tr);
    let nr, ir, rr = class {
        constructor(e, t, n) {
            this.location = e, this.renderable = t, this.factory = n, this.id = Object(r.B)("au$component"), this.hasPendingInstanceMutation = !1, this.observer = void 0, this.views = [], this.key = void 0, this.task = Fi.done, this.normalizedItems = void 0
        }
        binding(e) {
            this.checkCollectionObserver(e);
            const t = this.renderable.bindings,
                {
                    length: n
                } = t;
            let i;
            for (let e = 0; e < n; ++e)
                if (i = t[e], i.target === this && "items" === i.targetProperty) {
                    this.forOf = i.sourceExpression;
                    break
                } return this.local = this.forOf.declaration.evaluate(e, this.$controller.scope, null), this.normalizeToArray(e), this.processViewsKeyed(void 0, e), this.task
        }
        attaching(e) {
            this.task.done ? this.attachViews(void 0, e) : this.task = new Yi(this.task, this.attachViews, this, void 0, e)
        }
        detaching(e) {
            this.task.done ? this.detachViewsByRange(0, this.views.length, e) : this.task = new Yi(this.task, this.detachViewsByRange, this, 0, this.views.length, e)
        }
        unbinding(e) {
            return this.checkCollectionObserver(e), this.task.done ? this.task = this.unbindAndRemoveViewsByRange(0, this.views.length, e, !1) : this.task = new Yi(this.task, this.unbindAndRemoveViewsByRange, this, 0, this.views.length, e, !1), this.task
        }
        itemsChanged(e) {
            e |= this.$controller.flags, this.checkCollectionObserver(e), e |= 16, this.normalizeToArray(e), this.processViewsKeyed(void 0, e)
        }
        handleCollectionChange(e, t) {
            t |= this.$controller.flags, t |= 976, this.normalizeToArray(t), this.processViewsKeyed(e, t)
        }
        processViewsKeyed(e, t) {
            const n = this.views.length;
            void 0 === e ? ((5 & this.$controller.state) > 0 && (this.detachViewsByRange(0, n, t), this.task.done ? this.task = this.unbindAndRemoveViewsByRange(0, n, t, !1) : this.task = new Yi(this.task, this.unbindAndRemoveViewsByRange, this, 0, n, t, !1), this.task.done ? this.task = this.createAndBindAllViews(t) : this.task = new Yi(this.task, this.createAndBindAllViews, this, t)), (40 & this.$controller.state) > 0 && (this.task.done ? this.attachViewsKeyed(t) : this.task = new Yi(this.task, this.attachViewsKeyed, this, t))) : (ln(e), (5 & this.$controller.state) > 0 && (e.deletedItems.length > 0 && (e.deletedItems.sort(r.p), this.task.done ? this.detachViewsByKey(e, t) : this.task = new Yi(this.task, this.detachViewsByKey, this, e, t), this.task.done ? this.task = this.unbindAndRemoveViewsByKey(e, t) : this.task = new Yi(this.task, this.unbindAndRemoveViewsByKey, this, e, t)), this.task.done ? this.task = this.createAndBindNewViewsByKey(e, t) : this.task = new Yi(this.task, this.createAndBindNewViewsByKey, this, e, t)), (40 & this.$controller.state) > 0 && (this.task.done ? this.sortViewsByKey(n, e, t) : this.task = new Yi(this.task, this.sortViewsByKey, this, n, e, t)))
        }
        checkCollectionObserver(e) {
            const t = this.observer;
            if ((5 & this.$controller.state) > 0) {
                const n = this.observer = si(e, this.$controller.lifecycle, this.items);
                t !== n && t && t.unsubscribeFromCollection(this), n && n.subscribeToCollection(this)
            } else void 0 !== t && t.unsubscribeFromCollection(this)
        }
        normalizeToArray(e) {
            const t = this.items;
            if (t instanceof Array) return void(this.normalizedItems = t);
            if (void 0 === this.forOf) return;
            const n = [];
            this.forOf.iterate(e, t, (e, t, i) => {
                n[t] = i
            }), this.normalizedItems = n
        }
        detachViewsByRange(e, t, n) {
            const i = this.views;
            let r;
            this.$controller.lifecycle.detached.begin();
            for (let s = e; s < t; ++s) r = i[s], r.release(n), r.detach(n);
            this.$controller.lifecycle.detached.end(n)
        }
        unbindAndRemoveViewsByRange(e, t, n, i) {
            const r = this.views;
            let s, o, a = void 0;
            this.$controller.lifecycle.unbound.begin();
            for (let i = e; i < t; ++i) o = r[i], s = o.unbind(n), o.parent = void 0, s.done || (void 0 === a && (a = []), a.push(s));
            return i && (this.views.length = e), void 0 === a ? (this.$controller.lifecycle.unbound.end(n), Fi.done) : new Ji(a, this.$controller.lifecycle.unbound.end, this.$controller.lifecycle.unbound, n)
        }
        detachViewsByKey(e, t) {
            const n = this.views;
            this.$controller.lifecycle.detached.begin();
            const i = e.deletedItems,
                r = i.length;
            let s;
            for (let e = 0; e < r; ++e) s = n[i[e]], s.release(t), s.detach(t);
            this.$controller.lifecycle.detached.end(t)
        }
        unbindAndRemoveViewsByKey(e, t) {
            const n = this.views;
            let i, r = void 0;
            this.$controller.lifecycle.unbound.begin();
            const s = e.deletedItems,
                o = s.length;
            let a, c = 0;
            for (; c < o; ++c) a = n[s[c]], i = a.unbind(t), a.parent = void 0, i.done || (void 0 === r && (r = []), r.push(i));
            c = 0;
            let l = 0;
            for (; c < o; ++c) l = s[c] - c, this.views.splice(l, 1);
            return void 0 === r ? (this.$controller.lifecycle.unbound.end(t), Fi.done) : new Ji(r, this.$controller.lifecycle.unbound.end, this.$controller.lifecycle.unbound, t)
        }
        createAndBindAllViews(e) {
            let t, n, i, r = void 0;
            const s = this.$controller,
                o = s.lifecycle,
                a = s.scope;
            o.bound.begin();
            const c = s.part,
                l = this.factory,
                u = this.local,
                h = this.items,
                d = this.forOf.count(e, h),
                p = this.views = Array(d);
            return this.forOf.iterate(e, h, (o, h, f) => {
                n = p[h] = l.create(e), n.parent = s, i = P.fromParent(e, a, L.create(e, u, f)), or(i.overrideContext, h, d), t = n.bind(e, i, c), t.done || (void 0 === r && (r = []), r.push(t))
            }), void 0 === r ? (o.bound.end(e), Fi.done) : new Ji(r, o.bound.end, o.bound, e)
        }
        createAndBindNewViewsByKey(e, t) {
            let n, i, r, s = void 0;
            const o = this.factory,
                a = this.views,
                c = this.local,
                l = this.normalizedItems,
                u = this.$controller,
                h = u.lifecycle,
                d = u.scope;
            h.bound.begin();
            const p = u.part,
                f = e.length;
            for (let h = 0; h < f; ++h) - 2 === e[h] && (i = o.create(t), i.parent = u, r = P.fromParent(t, d, L.create(t, c, l[h])), or(r.overrideContext, h, f), n = i.bind(t, r, p), a.splice(h, 0, i), n.done || (void 0 === s && (s = []), s.push(n)));
            if (a.length !== f) throw new Error(`viewsLen=${a.length}, mapLen=${f}`);
            return void 0 === s ? (h.bound.end(t), Fi.done) : new Ji(s, h.bound.end, h.bound, t)
        }
        attachViews(e, t) {
            let n;
            const i = this.views,
                r = this.location,
                s = this.$controller.lifecycle;
            if (s.attached.begin(), void 0 === e)
                for (let e = 0, s = i.length; e < s; ++e) n = i[e], n.hold(r, 1), n.nodes.unlink(), n.attach(t);
            else
                for (let s = 0, o = i.length; s < o; ++s) e[s] !== s && (n = i[s], n.hold(r, 1), n.nodes.unlink(), n.attach(t));
            s.attached.end(t)
        }
        attachViewsKeyed(e) {
            let t;
            const {
                views: n,
                location: i
            } = this;
            this.$controller.lifecycle.attached.begin();
            for (let r = 0, s = n.length; r < s; ++r) t = n[r], t.hold(i, 1), t.nodes.unlink(), t.attach(e);
            this.$controller.lifecycle.attached.end(e)
        }
        sortViewsByKey(e, t, n) {
            const i = this.location,
                r = this.views,
                s = t.length;
            un(r, t);
            const o = function(e) {
                    const t = e.length;
                    t > sr && (sr = t, nr = new Int32Array(t), ir = new Int32Array(t));
                    let n = 0,
                        i = 0,
                        r = 0,
                        s = 0,
                        o = 0,
                        a = 0,
                        c = 0,
                        l = 0;
                    for (; s < t; s++)
                        if (i = e[s], -2 !== i) {
                            if (o = nr[n], r = e[o], -2 !== r && r < i) {
                                ir[s] = o, nr[++n] = s;
                                continue
                            }
                            for (a = 0, c = n; a < c;) l = a + c >> 1, r = e[nr[l]], -2 !== r && r < i ? a = l + 1 : c = l;
                            r = e[nr[a]], (i < r || -2 === r) && (a > 0 && (ir[s] = nr[a - 1]), nr[a] = s)
                        } s = ++n;
                    const u = new Int32Array(s);
                    i = nr[n - 1];
                    for (; n-- > 0;) u[n] = i, i = ir[i];
                    for (; s-- > 0;) nr[s] = 0;
                    return u
                }(t),
                a = o.length;
            let c;
            this.$controller.lifecycle.attached.begin(), n |= 33554432;
            let l, u = a - 1,
                h = s - 1;
            for (; h >= 0; --h) l = r[h], -2 === t[h] ? (or(l.scope.overrideContext, h, s), l.hold(i, 1), l.attach(n)) : u < 0 || 1 === a || h !== o[u] ? (or(l.scope.overrideContext, h, s), l.attach(n)) : (e !== s && or(l.scope.overrideContext, h, s), --u), c = r[h + 1], void 0 !== c ? l.nodes.link(c.nodes) : l.nodes.link(i);
            this.$controller.lifecycle.attached.end(n)
        }
    };
    Object(s.__decorate)([ki], rr.prototype, "items", void 0), rr = Object(s.__decorate)([Ci("repeat"), Object(s.__param)(0, ji), Object(s.__param)(1, We), Object(s.__param)(2, Ge)], rr);
    let sr = 0;

    function or(e, t, n) {
        const i = 0 === t,
            r = t === n - 1,
            s = t % 2 == 0;
        e.$index = t, e.$first = i, e.$last = r, e.$middle = !i && !r, e.$even = s, e.$odd = !s, e.$length = n
    }
    let ar = class {
        constructor(e, t) {
            this.factory = e, this.location = t, this.id = Object(r.B)("au$component"), this.view = this.factory.create(), this.view.hold(t, 1)
        }
        binding(e) {
            return this.view.parent = this.$controller, this.view.bind(67108864 | e, this.$controller.scope, this.factory.name)
        }
        attaching(e) {
            this.view.attach(e)
        }
        detaching(e) {
            this.view.detach(e)
        }
        unbinding(e) {
            const t = this.view.unbind(e);
            return this.view.parent = void 0, t
        }
    };
    ar = Object(s.__decorate)([Ci("replaceable"), Object(s.__param)(0, Ge), Object(s.__param)(1, ji)], ar);
    let cr = class {
        constructor(e, t) {
            this.factory = e, this.location = t, this.id = Object(r.B)("au$component"), this.id = Object(r.B)("au$component"), this.factory = e, this.view = this.factory.create(), this.view.hold(t, 1)
        }
        valueChanged(e, t, n) {
            (5 & this.$controller.state) > 0 && this.bindChild(4096)
        }
        binding(e) {
            this.view.parent = this.$controller, this.bindChild(e)
        }
        attaching(e) {
            this.view.attach(e)
        }
        detaching(e) {
            this.view.detach(e)
        }
        unbinding(e) {
            this.view.unbind(e), this.view.parent = void 0
        }
        bindChild(e) {
            const t = P.fromParent(e, this.$controller.scope, void 0 === this.value ? {} : this.value);
            this.view.bind(e, t, this.$controller.part)
        }
    };

    function lr(e, t) {
        let n;

        function i(e, t) {
            arguments.length > 1 && (n.property = t), r.f.define(hr.name, dr.create(t, n), e.constructor, t), r.i.annotation.appendTo(e.constructor, hr.keyFrom(t))
        }
        return arguments.length > 1 ? (n = {}, void i(e, t)) : "string" == typeof e ? (n = {}, i) : (n = void 0 === e ? {} : e, i)
    }

    function ur(e) {
        return e.startsWith(hr.name)
    }
    Object(s.__decorate)([ki], cr.prototype, "value", void 0), cr = Object(s.__decorate)([Ci("with"), Object(s.__param)(0, Ge), Object(s.__param)(1, ji)], cr);
    const hr = {
        name: r.i.annotation.keyFor("children-observer"),
        keyFrom: e => `${hr.name}:${e}`,
        from(...e) {
            const t = {},
                n = Array.isArray;

            function i(e) {
                t[e] = dr.create(e)
            }
            return e.forEach((function(e) {
                n(e) ? e.forEach(i) : e instanceof dr ? t[e.property] = e : void 0 !== e && Object.keys(e).forEach(n => function(e, n) {
                    t[e] = dr.create(e, n)
                }(n, e))
            })), t
        },
        getAll(e) {
            const t = hr.name.length + 1,
                n = [],
                i = Object(r.u)(e);
            let s, o, a, c = i.length,
                l = 0;
            for (; --c >= 0;) {
                a = i[c], s = r.i.annotation.getKeys(a).filter(ur), o = s.length;
                for (let e = 0; e < o; ++e) n[l++] = r.f.getOwn(hr.name, a, s[e].slice(t))
            }
            return n
        }
    };
    class dr {
        constructor(e, t, n, i, r, s) {
            this.callback = e, this.property = t, this.options = n, this.query = i, this.filter = r, this.map = s
        }
        static create(e, t = {}) {
            return new dr(Object(r.q)(t.callback, e + "Changed"), Object(r.q)(t.property, e), t.options, t.query, t.filter, t.map)
        }
    }

    function pr(e) {
        return function(t) {
            return vr.define(e, t)
        }
    }

    function fr(e) {
        return void 0 === e ? function(e) {
            vr.annotate(e, "shadowOptions", {
                mode: "open"
            })
        } : "function" != typeof e ? function(t) {
            vr.annotate(t, "shadowOptions", e)
        } : void vr.annotate(e, "shadowOptions", {
            mode: "open"
        })
    }

    function gr(e) {
        if (void 0 === e) return function(e) {
            vr.annotate(e, "containerless", !0)
        };
        vr.annotate(e, "containerless", !0)
    }
    class mr {
        constructor(e, t, n, i, r, s, o, a, c, l, u, h, d, p, f, g, m, v, b) {
            this.Type = e, this.name = t, this.aliases = n, this.key = i, this.cache = r, this.template = s, this.instructions = o, this.dependencies = a, this.needsCompile = c, this.surrogates = l, this.bindables = u, this.childrenObservers = h, this.containerless = d, this.isStrictBinding = p, this.shadowOptions = f, this.hasSlots = g, this.strategy = m, this.hooks = v, this.scopeParts = b
        }
        static create(e, t = null) {
            if (null === t) {
                const n = e;
                if ("string" == typeof n) throw new Error("Cannot create a custom element definition with only a name and no type: " + e);
                const i = Object(r.t)("name", n, vr.generateName);
                return t = "function" == typeof n.Type ? n.Type : vr.generateType(Object(r.C)(i)), new mr(t, i, Object(r.z)(n.aliases), Object(r.t)("key", n, () => vr.keyFrom(i)), Object(r.t)("cache", n, () => 0), Object(r.t)("template", n, () => null), Object(r.z)(n.instructions), Object(r.z)(n.dependencies), Object(r.t)("needsCompile", n, () => !0), Object(r.z)(n.surrogates), _i.from(n.bindables), hr.from(n.childrenObservers), Object(r.t)("containerless", n, () => !1), Object(r.t)("isStrictBinding", n, () => !1), Object(r.t)("shadowOptions", n, () => null), Object(r.t)("hasSlots", n, () => !1), Object(r.t)("strategy", n, () => 1), Object(r.t)("hooks", n, () => F.none), Object(r.z)(n.scopeParts))
            }
            if ("string" == typeof e) return new mr(t, e, Object(r.z)(vr.getAnnotation(t, "aliases"), t.aliases), vr.keyFrom(e), Object(r.s)("cache", t, () => 0), Object(r.s)("template", t, () => null), Object(r.z)(vr.getAnnotation(t, "instructions"), t.instructions), Object(r.z)(vr.getAnnotation(t, "dependencies"), t.dependencies), Object(r.s)("needsCompile", t, () => !0), Object(r.z)(vr.getAnnotation(t, "surrogates"), t.surrogates), _i.from(..._i.getAll(t), vr.getAnnotation(t, "bindables"), t.bindables), hr.from(...hr.getAll(t), vr.getAnnotation(t, "childrenObservers"), t.childrenObservers), Object(r.s)("containerless", t, () => !1), Object(r.s)("isStrictBinding", t, () => !1), Object(r.s)("shadowOptions", t, () => null), Object(r.s)("hasSlots", t, () => !1), Object(r.s)("strategy", t, () => 1), Object(r.s)("hooks", t, () => new F(t.prototype)), Object(r.z)(vr.getAnnotation(t, "scopeParts"), t.scopeParts));
            const n = Object(r.t)("name", e, vr.generateName);
            return new mr(t, n, Object(r.z)(vr.getAnnotation(t, "aliases"), e.aliases, t.aliases), vr.keyFrom(n), Object(r.r)("cache", e, t, () => 0), Object(r.r)("template", e, t, () => null), Object(r.z)(vr.getAnnotation(t, "instructions"), e.instructions, t.instructions), Object(r.z)(vr.getAnnotation(t, "dependencies"), e.dependencies, t.dependencies), Object(r.r)("needsCompile", e, t, () => !0), Object(r.z)(vr.getAnnotation(t, "surrogates"), e.surrogates, t.surrogates), _i.from(..._i.getAll(t), vr.getAnnotation(t, "bindables"), t.bindables, e.bindables), hr.from(...hr.getAll(t), vr.getAnnotation(t, "childrenObservers"), t.childrenObservers, e.childrenObservers), Object(r.r)("containerless", e, t, () => !1), Object(r.r)("isStrictBinding", e, t, () => !1), Object(r.r)("shadowOptions", e, t, () => null), Object(r.r)("hasSlots", e, t, () => !1), Object(r.r)("strategy", e, t, () => 1), Object(r.s)("hooks", t, () => new F(t.prototype)), Object(r.z)(vr.getAnnotation(t, "scopeParts"), e.scopeParts, t.scopeParts))
        }
        register(e) {
            const {
                Type: t,
                key: n,
                aliases: i
            } = this;
            r.j.transient(n, t).register(e), r.j.alias(n, t).register(e), B(i, vr, n, e)
        }
    }
    const vr = {
            name: r.i.resource.keyFor("custom-element"),
            keyFrom: e => `${vr.name}:${e}`,
            isType: e => "function" == typeof e && r.f.hasOwn(vr.name, e),
            behaviorFor: e => e.$controller,
            define(e, t) {
                const n = mr.create(e, t);
                return r.f.define(vr.name, n, n.Type), r.f.define(vr.name, n, n), r.i.resource.appendTo(n.Type, vr.name), n.Type
            },
            getDefinition(e) {
                const t = r.f.getOwn(vr.name, e);
                if (void 0 === t) throw new Error("No definition found for type " + e.name);
                return t
            },
            annotate(e, t, n) {
                r.f.define(r.i.annotation.keyFor(t), n, e)
            },
            getAnnotation: (e, t) => r.f.getOwn(r.i.annotation.keyFor(t), e),
            generateName: function() {
                let e = 0;
                return function() {
                    return "unnamed-" + ++e
                }
            }(),
            generateType: function() {
                const e = {
                        value: "",
                        writable: !1,
                        enumerable: !1,
                        configurable: !0
                    },
                    t = {};
                return function(n, i = t) {
                    const r = class {};
                    return e.value = n, Reflect.defineProperty(r, "name", e), i !== t && Object.assign(r.prototype, i), r
                }
            }()
        },
        br = r.a.createInterface("IProjectorLocator").noDefault(),
        yr = /<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi,
        wr = r.a.createInterface("ISanitizer").withDefault(e => e.singleton(class {
            sanitize(e) {
                return e.replace(yr, "")
            }
        }));
    let kr = class {
        constructor(e) {
            this.sanitizer = e
        }
        toView(e) {
            return null == e ? null : this.sanitizer.sanitize(e)
        }
    };
    kr = Object(s.__decorate)([q("sanitize"), Object(s.__param)(0, wr)], kr);
    class xr {
        constructor(e, t, n, i) {
            this.dom = e, this.parentContainer = t, this.dependencies = n, this.componentType = i;
            const s = this.container = t.createChild(),
                o = this.renderableProvider = new r.e,
                a = this.elementProvider = new r.e,
                c = this.instructionProvider = new r.e,
                l = this.factoryProvider = new _r,
                u = this.renderLocationProvider = new r.e;
            this.renderer = s.get(Er), e.registerElementResolver(s, a), s.registerResolver(Ge, l), s.registerResolver(We, o), s.registerResolver(V, c), s.registerResolver(ji, u), null != n && s.register(...n), i && vr.getDefinition(i).register(s)
        }
        get id() {
            return this.container.id
        }
        get path() {
            return this.container.path
        }
        get parentId() {
            return this.parentContainer.id
        }
        has(e, t) {
            return this.container.has(e, t)
        }
        get(e) {
            return this.container.get(e)
        }
        getAll(e) {
            return this.container.getAll(e)
        }
        register(...e) {
            return this.container.register(...e)
        }
        registerResolver(e, t) {
            return this.container.registerResolver(e, t)
        }
        registerTransformer(e, t) {
            return this.container.registerTransformer(e, t)
        }
        getResolver(e, t) {
            return this.container.getResolver(e, t)
        }
        getFactory(e) {
            return this.container.getFactory(e)
        }
        createChild() {
            return this.container.createChild()
        }
        render(e, t, n, i, r, s) {
            this.renderer.render(e, this.dom, this, t, n, i, r, s)
        }
        beginComponentOperation(e, t, n, i, r, s) {
            return this.renderableProvider.prepare(e), this.elementProvider.prepare(t), this.instructionProvider.prepare(n), i && this.factoryProvider.prepare(i, r), s && this.renderLocationProvider.prepare(s), this
        }
        dispose() {
            this.factoryProvider.dispose(), this.renderableProvider.dispose(), this.instructionProvider.dispose(), this.elementProvider.dispose(), this.renderLocationProvider.dispose()
        }
        createRuntimeCompilationResources() {
            return new r.l(this.container)
        }
    }
    class _r {
        prepare(e, t) {
            this.factory = e, e.addParts(t)
        }
        resolve(e, t) {
            const n = this.factory;
            if (null == n) throw r.k.error(50);
            if (!n.name || !n.name.length) throw r.k.error(51);
            const i = n.parts[n.name];
            if (i) {
                const n = e.get(jr),
                    r = e.get(Mi);
                return n.getViewFactory(r, i, t)
            }
            return n
        }
        dispose() {
            this.factory = null
        }
    }
    const Sr = r.a.createInterface("ITemplateCompiler").noDefault();
    var Or;
    ! function(e) {
        e[e.none = 1] = "none", e[e.surrogate = 2] = "surrogate", e[e.shadowDOM = 4] = "shadowDOM"
    }(Or || (Or = {}));
    const Cr = r.a.createInterface("ITemplateFactory").noDefault();
    class Ar {
        constructor(e, t, n, i) {
            this.dom = e, this.definition = t, this.factory = n, this.renderContext = i
        }
        render(e, t, n, i = 0) {
            const r = e instanceof Nr ? e : e.$controller;
            if (null == r) throw new Error("Controller is missing from the view model");
            const s = r.nodes = this.factory.createNodeSequence();
            r.context = this.renderContext, r.scopeParts = this.definition.scopeParts, r.isStrictBinding = this.definition.isStrictBinding, i |= this.definition.strategy, this.renderContext.render(i, r, s.findTargets(), this.definition, t, n)
        }
    }
    const Tr = r.a.createInterface("IInstructionRenderer").noDefault(),
        Er = r.a.createInterface("IRenderer").noDefault(),
        jr = r.a.createInterface("IRenderingEngine").withDefault(e => e.singleton(Mr));
    let Mr = class {
        constructor(e, t, n, i) {
            this.container = e, this.templateFactory = t, this.lifecycle = n, this.compiler = i
        }
        getElementTemplate(e, t, n, i) {
            if (null != t) return null == n && (n = this.container), this.templateFromSource(e, t, n, i)
        }
        getViewFactory(e, t, n) {
            if (null == t) throw new Error("No definition provided");
            let i;
            t instanceof mr ? i = t : r.f.hasOwn(vr.name, t) ? i = r.f.getOwn(vr.name, t) : (i = mr.create(t), r.f.define(vr.name, i, t), r.f.define(vr.name, i, i.Type)), null == n && (n = this.container);
            const s = vr.keyFrom(n.path + ":factory");
            let o = r.f.getOwn(s, i);
            if (void 0 === o) {
                const t = this.templateFromSource(e, i, n, void 0);
                o = new Fr(i.name, t, this.lifecycle), o.setCacheSize(i.cache, !0), r.f.define(s, o, i)
            }
            return o
        }
        templateFromSource(e, t, n, i) {
            const s = vr.keyFrom(n.path + ":template");
            let o = r.f.getOwn(s, t);
            return void 0 === o && (o = this.templateFromSourceCore(e, t, n, i), r.f.define(s, o, t)), o
        }
        templateFromSourceCore(e, t, n, i) {
            const s = new xr(e, n, t.dependencies, i);
            if (null != t.template && t.needsCompile) {
                const i = vr.keyFrom(n.path + ":compiled-definition");
                let o = r.f.getOwn(i, t);
                return void 0 === o && (o = this.compiler.compile(e, t, s.createRuntimeCompilationResources(), Or.surrogate), r.f.define(i, o, t)), this.templateFactory.create(s, o)
            }
            return this.templateFactory.create(s, t)
        }
    };
    Mr = Object(s.__decorate)([Object(s.__param)(0, r.c), Object(s.__param)(1, Cr), Object(s.__param)(2, Xe), Object(s.__param)(3, Sr)], Mr);
    let Lr = class {
        constructor(e, t, n, i, r, s = Pr, o = Rr, a = Ir, c) {
            this.propertyKey = i, this.obj = t, this.callback = t[r], this.query = s, this.filter = o, this.map = a, this.options = c, this.children = void 0, this.controller = e, this.observing = !1, this.persistentFlags = 2080374799 & n, this.createGetterSetter()
        }
        getValue() {
            return this.tryStartObserving(), this.children
        }
        setValue(e) {}
        subscribe(e) {
            this.tryStartObserving(), this.addSubscriber(e)
        }
        tryStartObserving() {
            if (!this.observing) {
                this.observing = !0;
                const e = this.controller.projector;
                this.children = Dr(e, this.query, this.filter, this.map), e.subscribeToChildrenChange(() => {
                    this.onChildrenChanged()
                }, this.options)
            }
        }
        onChildrenChanged() {
            this.children = Dr(this.controller.projector, this.query, this.filter, this.map), void 0 !== this.callback && this.callback.call(this.obj), this.callSubscribers(this.children, void 0, 16 | this.persistentFlags)
        }
        createGetterSetter() {
            Reflect.defineProperty(this.obj, this.propertyKey, {
                enumerable: !0,
                configurable: !0,
                get: () => this.getValue(),
                set: () => {}
            }) || r.k.write(1, this.propertyKey, this.obj)
        }
    };

    function Pr(e) {
        return e.children
    }

    function Rr(e, t, n) {
        return !!n
    }

    function Ir(e, t, n) {
        return n
    }

    function Dr(e, t, n, i) {
        const r = t(e),
            s = [];
        for (let e = 0, t = r.length; e < t; ++e) {
            const t = r[e],
                o = vr.behaviorFor(t),
                a = o ? o.viewModel : null;
            n(t, o, a) && s.push(i(t, o, a))
        }
        return s
    }
    Lr = Object(s.__decorate)([o()], Lr);
    class Nr {
        constructor(e, t, n, i, s, o, a, c) {
            switch (this.vmKind = e, this.flags = t, this.viewCache = n, this.lifecycle = i, this.viewModel = s, this.parentContext = o, this.host = a, this.id = Object(r.B)("au$component"), this.nextBound = void 0, this.nextUnbound = void 0, this.prevBound = void 0, this.prevUnbound = void 0, this.nextAttached = void 0, this.nextDetached = void 0, this.prevAttached = void 0, this.prevDetached = void 0, this.nextMount = void 0, this.nextUnmount = void 0, this.prevMount = void 0, this.prevUnmount = void 0, this.parent = void 0, this.bindings = void 0, this.controllers = void 0, this.state = 0, this.mountStrategy = 1, e) {
                case 2:
                    if (null == n) throw new Error("No IViewCache was provided when rendering a synthetic view.");
                    this.hooks = F.none, this.bindingContext = void 0, this.host = void 0, this.vmKind = 2, this.scopeParts = void 0, this.isStrictBinding = !1, this.scope = void 0, this.projector = void 0, this.nodes = void 0, this.context = void 0, this.location = void 0;
                    break;
                case 0: {
                    if (null == o) throw new Error("No parentContext was provided when rendering a custom element.");
                    if (null == s) throw new Error("No viewModel was provided when rendering a custom elemen.");
                    if (null == a) throw new Error("No host element was provided when rendering a custom element.");
                    const e = s.constructor,
                        n = vr.getDefinition(e);
                    Vr(this, n, t |= n.strategy, s), this.hooks = n.hooks, this.bindingContext = $r(t, s);
                    const i = o.get(jr);
                    let l, u, h = void 0;
                    if (this.hooks.hasRender) {
                        const n = this.bindingContext.render(t, a, null == c.parts ? r.g.emptyObject : c.parts, o);
                        null != n && "getElementTemplate" in n && (h = n.getElementTemplate(i, e, o))
                    } else h = i.getElementTemplate(o.get(Mi), n, o, e);
                    void 0 !== h && (null == h.definition || 0 === h.definition.instructions.length || 0 === h.definition.instructions[0].length || null == h.definition.instructions[0][0].parts ? u = null == c.parts ? r.g.emptyObject : c.parts : (l = h.definition.instructions[0][0], u = null == c.parts ? l.parts : {
                        ...c.parts,
                        ...l.parts
                    }), h.render(this, a, u)), this.scope = P.create(t, this.bindingContext, null), this.projector = o.get(br).getElementProjector(o.get(Mi), this, a, void 0 !== h ? h.definition : n), this.location = void 0, s.$controller = this, this.hooks.hasCreated && this.bindingContext.created(t);
                    break
                }
                case 1: {
                    if (null == o) throw new Error("No parentContext was provided when rendering a custom element or attribute.");
                    if (null == s) throw new Error("No viewModel was provided when rendering a custom elemen.");
                    const e = s.constructor,
                        n = Ti.getDefinition(e);
                    Vr(this, n, t |= n.strategy, s), this.hooks = n.hooks, this.bindingContext = $r(t, s), this.scope = void 0, this.projector = void 0, this.nodes = void 0, this.context = void 0, this.location = void 0, s.$controller = this, this.hooks.hasCreated && this.bindingContext.created(t);
                    break
                }
                default:
                    throw new Error("Invalid ViewModelKind: " + e)
            }
        }
        static forCustomElement(e, t, n, i = 0, s = r.g.emptyObject) {
            let o = Nr.lookup.get(e);
            return void 0 === o && (o = new Nr(0, i, void 0, t.get(Xe), e, t, n, s), this.lookup.set(e, o)), o
        }
        static forCustomAttribute(e, t, n = 0) {
            let i = Nr.lookup.get(e);
            return void 0 === i && (i = new Nr(1, 4 | n, void 0, t.get(Xe), e, t, void 0, r.g.emptyObject), this.lookup.set(e, i)), i
        }
        static forSyntheticView(e, t, n = 0) {
            return new Nr(2, n, e, t, void 0, void 0, void 0, r.g.emptyObject)
        }
        lockScope(e) {
            this.scope = e, this.state |= 16384
        }
        hold(e, t) {
            this.state = 32768 ^ (32768 | this.state), this.location = e, this.mountStrategy = t
        }
        release(e) {
            return this.state |= 32768, (32 & this.state) > 0 ? this.viewCache.canReturnToCache(this) : this.unmountSynthetic(e)
        }
        bind(e, t, n) {
            switch (this.part = n, e |= 4096, this.vmKind) {
                case 0:
                    return this.bindCustomElement(e, t);
                case 1:
                    return this.bindCustomAttribute(e, t);
                case 2:
                    return this.bindSynthetic(e, t)
            }
        }
        unbind(e) {
            switch (e |= 8192, this.vmKind) {
                case 0:
                    return this.unbindCustomElement(e);
                case 1:
                    return this.unbindCustomAttribute(e);
                case 2:
                    return this.unbindSynthetic(e)
            }
        }
        bound(e) {
            this.bindingContext.bound(e)
        }
        unbound(e) {
            this.bindingContext.unbound(e)
        }
        attach(e) {
            if (!((40 & this.state) > 0 && 0 == (33554432 & e))) switch (e |= 16384, this.vmKind) {
                case 0:
                    this.attachCustomElement(e);
                    break;
                case 1:
                    this.attachCustomAttribute(e);
                    break;
                case 2:
                    this.attachSynthetic(e)
            }
        }
        detach(e) {
            if (0 != (40 & this.state)) switch (e |= 32768, this.vmKind) {
                case 0:
                    this.detachCustomElement(e);
                    break;
                case 1:
                    this.detachCustomAttribute(e);
                    break;
                case 2:
                    this.detachSynthetic(e)
            }
        }
        attached(e) {
            this.bindingContext.attached(e)
        }
        detached(e) {
            this.bindingContext.detached(e)
        }
        mount(e) {
            switch (this.vmKind) {
                case 0:
                    this.mountCustomElement(e);
                    break;
                case 2:
                    this.mountSynthetic(e)
            }
        }
        unmount(e) {
            switch (this.vmKind) {
                case 0:
                    this.unmountCustomElement(e);
                    break;
                case 2:
                    this.unmountSynthetic(e)
            }
        }
        cache(e) {
            switch (this.vmKind) {
                case 0:
                    this.cacheCustomElement(e);
                    break;
                case 1:
                    this.cacheCustomAttribute(e);
                    break;
                case 2:
                    this.cacheSynthetic(e)
            }
        }
        getTargetAccessor(e) {
            const {
                bindings: t
            } = this;
            if (void 0 !== t) {
                const n = t.find(t => t.targetProperty === e);
                if (void 0 !== n) return n.targetObserver
            }
        }
        bindCustomElement(e, t) {
            const n = this.scope;
            if (n.parentScope = void 0 === t ? null : t, n.scopeParts = this.scopeParts, (4 & this.state) > 0) return Fi.done;
            if (e |= 4096, this.state |= 1, this.lifecycle.bound.begin(), this.bindBindings(e, n), this.hooks.hasBinding) {
                const t = this.bindingContext.binding(e);
                if (Zi(t)) return new Yi(t, this.bindControllers, this, e, n)
            }
            return this.bindControllers(e, n)
        }
        bindCustomAttribute(e, t) {
            if ((4 & this.state) > 0) {
                if (this.scope === t) return Fi.done;
                e |= 4096;
                const n = this.unbind(e);
                if (!n.done) return new Yi(n, this.bind, this, e, t)
            } else e |= 4096;
            if (this.state |= 1, this.scope = t, this.lifecycle.bound.begin(), this.hooks.hasBinding) {
                const t = this.bindingContext.binding(e);
                if (Zi(t)) return new Yi(t, this.endBind, this, e)
            }
            return this.endBind(e), Fi.done
        }
        bindSynthetic(e, t) {
            if (null == t) throw new Error("Scope is null or undefined");
            if (t.scopeParts = Object(r.A)(t.scopeParts, this.scopeParts, !1), (4 & this.state) > 0) {
                if (this.scope === t || (16384 & this.state) > 0) return Fi.done;
                e |= 4096;
                const n = this.unbind(e);
                if (!n.done) return new Yi(n, this.bind, this, e, t)
            } else e |= 4096;
            return 0 == (16384 & this.state) && (this.scope = t), this.state |= 1, this.lifecycle.bound.begin(), this.bindBindings(e, t), this.bindControllers(e, t)
        }
        bindBindings(e, t) {
            const {
                bindings: n
            } = this;
            if (void 0 !== n) {
                const {
                    length: i
                } = n;
                this.isStrictBinding && (e |= 4);
                for (let r = 0; r < i; ++r) n[r].$bind(e, t, this.part)
            }
        }
        bindControllers(e, t) {
            let n, i = void 0;
            const {
                controllers: r
            } = this;
            if (void 0 !== r) {
                const {
                    length: s
                } = r;
                for (let o = 0; o < s; ++o) r[o].parent = this, n = r[o].bind(e, t, this.part), n.done || (void 0 === i && (i = []), i.push(n))
            }
            return void 0 === i ? (this.endBind(e), Fi.done) : new Ji(i, this.endBind, this, e)
        }
        endBind(e) {
            this.hooks.hasBound && this.lifecycle.bound.add(this), this.state = 1 ^ this.state | 4, this.lifecycle.bound.end(e)
        }
        unbindCustomElement(e) {
            if (0 == (4 & this.state)) return Fi.done;
            if (this.scope.parentScope = null, this.state |= 2, e |= 8192, this.lifecycle.unbound.begin(), this.hooks.hasUnbinding) {
                const t = this.bindingContext.unbinding(e);
                if (Zi(t)) return new Yi(t, this.unbindControllers, this, e)
            }
            return this.unbindControllers(e)
        }
        unbindCustomAttribute(e) {
            if (0 == (4 & this.state)) return Fi.done;
            if (this.state |= 2, e |= 8192, this.lifecycle.unbound.begin(), this.hooks.hasUnbinding) {
                const t = this.bindingContext.unbinding(e);
                if (Zi(t)) return new Yi(t, this.endUnbind, this, e)
            }
            return this.endUnbind(e), Fi.done
        }
        unbindSynthetic(e) {
            return 0 == (4 & this.state) ? Fi.done : (this.state |= 2, e |= 8192, this.lifecycle.unbound.begin(), this.unbindControllers(e))
        }
        unbindBindings(e) {
            const {
                bindings: t
            } = this;
            if (void 0 !== t)
                for (let n = t.length - 1; n >= 0; --n) t[n].$unbind(e);
            this.endUnbind(e)
        }
        unbindControllers(e) {
            let t, n = void 0;
            const {
                controllers: i
            } = this;
            if (void 0 !== i)
                for (let r = i.length - 1; r >= 0; --r) t = i[r].unbind(e), i[r].parent = void 0, t.done || (void 0 === n && (n = []), n.push(t));
            return void 0 === n ? (this.unbindBindings(e), Fi.done) : new Ji(n, this.unbindBindings, this, e)
        }
        endUnbind(e) {
            switch (this.vmKind) {
                case 1:
                    this.scope = void 0;
                    break;
                case 2:
                    0 == (16384 & this.state) && (this.scope = void 0)
            }
            this.hooks.hasUnbound && this.lifecycle.unbound.add(this), this.state = 6 ^ (6 | this.state), this.lifecycle.unbound.end(e)
        }
        attachCustomElement(e) {
            e |= 16384, this.state |= 8, this.lifecycle.mount.add(this), this.lifecycle.attached.begin(), this.hooks.hasAttaching && this.bindingContext.attaching(e), this.attachControllers(e), this.hooks.hasAttached && this.lifecycle.attached.add(this), this.state = 8 ^ this.state | 32, this.lifecycle.attached.end(e)
        }
        attachCustomAttribute(e) {
            e |= 16384, this.state |= 8, this.lifecycle.attached.begin(), this.hooks.hasAttaching && this.bindingContext.attaching(e), this.hooks.hasAttached && this.lifecycle.attached.add(this), this.state = 8 ^ this.state | 32, this.lifecycle.attached.end(e)
        }
        attachSynthetic(e) {
            ((32 & this.state) > 0 && 33554432 & e) > 0 ? this.lifecycle.mount.add(this) : (e |= 16384, this.state |= 8, this.lifecycle.mount.add(this), this.lifecycle.attached.begin(), this.attachControllers(e), this.state = 8 ^ this.state | 32, this.lifecycle.attached.end(e))
        }
        detachCustomElement(e) {
            e |= 32768, this.state |= 16, this.lifecycle.detached.begin(), this.lifecycle.unmount.add(this), this.hooks.hasDetaching && this.bindingContext.detaching(e), this.detachControllers(e), this.hooks.hasDetached && this.lifecycle.detached.add(this), this.state = 48 ^ (48 | this.state), this.lifecycle.detached.end(e)
        }
        detachCustomAttribute(e) {
            e |= 32768, this.state |= 16, this.lifecycle.detached.begin(), this.hooks.hasDetaching && this.bindingContext.detaching(e), this.hooks.hasDetached && this.lifecycle.detached.add(this), this.state = 48 ^ (48 | this.state), this.lifecycle.detached.end(e)
        }
        detachSynthetic(e) {
            e |= 32768, this.state |= 16, this.lifecycle.detached.begin(), this.lifecycle.unmount.add(this), this.detachControllers(e), this.state = 48 ^ (48 | this.state), this.lifecycle.detached.end(e)
        }
        attachControllers(e) {
            const {
                controllers: t
            } = this;
            if (void 0 !== t) {
                const {
                    length: n
                } = t;
                for (let i = 0; i < n; ++i) t[i].attach(e)
            }
        }
        detachControllers(e) {
            const {
                controllers: t
            } = this;
            if (void 0 !== t)
                for (let n = t.length - 1; n >= 0; --n) t[n].detach(e)
        }
        mountCustomElement(e) {
            (64 & this.state) > 0 || (this.state |= 64, this.projector.project(this.nodes))
        }
        mountSynthetic(e) {
            const t = this.nodes,
                n = this.location;
            switch (this.state |= 64, this.mountStrategy) {
                case 2:
                    t.appendTo(n);
                    break;
                default:
                    t.insertBefore(n)
            }
        }
        unmountCustomElement(e) {
            0 != (64 & this.state) && (this.state = 64 ^ (64 | this.state), this.projector.take(this.nodes))
        }
        unmountSynthetic(e) {
            return 0 != (64 & this.state) && (this.state = 64 ^ (64 | this.state), this.nodes.remove(), this.nodes.unlink(), !!((32768 & this.state) > 0 && (this.state = 32768 ^ (32768 | this.state), this.viewCache.tryReturnToCache(this))) && (this.state |= 128, !0))
        }
        cacheCustomElement(e) {
            e |= 65536, this.hooks.hasCaching && this.bindingContext.caching(e)
        }
        cacheCustomAttribute(e) {
            e |= 65536, this.hooks.hasCaching && this.bindingContext.caching(e);
            const {
                controllers: t
            } = this;
            if (void 0 !== t) {
                const {
                    length: n
                } = t;
                for (let i = n - 1; i >= 0; --i) t[i].cache(e)
            }
        }
        cacheSynthetic(e) {
            const {
                controllers: t
            } = this;
            if (void 0 !== t) {
                const {
                    length: n
                } = t;
                for (let i = n - 1; i >= 0; --i) t[i].cache(e)
            }
        }
    }

    function Vr(e, t, n, i) {
        const r = null != i.$observers ? i.$observers : {},
            s = t.bindables,
            o = Object.getOwnPropertyNames(s),
            a = (2 & n) > 0,
            c = e.lifecycle,
            l = "childrenObservers" in t,
            u = o.length;
        let h;
        for (let e = 0; e < u; ++e) h = o[e], null == r[h] && (r[h] = new oi(c, n, a ? A.getOrCreate(i).proxy : i, h, s[h].callback));
        if (l) {
            const s = t.childrenObservers;
            if (s) {
                const t = Object.getOwnPropertyNames(s),
                    {
                        length: o
                    } = t;
                let a;
                for (let c = 0; c < o; ++c)
                    if (a = t[c], null == r[a]) {
                        const t = s[a];
                        r[a] = new Lr(e, i, n, a, t.callback, t.query, t.filter, t.map, t.options)
                    }
            }
        }
        a && !l || Reflect.defineProperty(i, "$observers", {
            enumerable: !1,
            value: r
        })
    }

    function $r(e, t) {
        return !0 === t.noProxy || 0 == (2 & e) ? t : A.getOrCreate(t).proxy
    }
    Nr.lookup = new WeakMap;
    class Fr {
        constructor(e, t, n) {
            this.isCaching = !1, this.cacheSize = -1, this.cache = null, this.lifecycle = n, this.name = e, this.template = t, this.parts = r.g.emptyObject
        }
        get parentContextId() {
            return this.template.renderContext.parentId
        }
        setCacheSize(e, t) {
            e && ("*" === e ? e = Fr.maxCacheSize : "string" == typeof e && (e = parseInt(e, 10)), -1 !== this.cacheSize && t || (this.cacheSize = e)), this.cacheSize > 0 ? this.cache = [] : this.cache = null, this.isCaching = this.cacheSize > 0
        }
        canReturnToCache(e) {
            return null != this.cache && this.cache.length < this.cacheSize
        }
        tryReturnToCache(e) {
            return !!this.canReturnToCache(e) && (e.cache(0), this.cache.push(e), !0)
        }
        create(e) {
            const t = this.cache;
            let n;
            if (null != t && t.length > 0) return n = t.pop(), n.state = 128 ^ (128 | n.state), n;
            if (n = Nr.forSyntheticView(this, this.lifecycle, e), this.template.render(n, null, this.parts, e), !n.nodes) throw r.k.error(90);
            return n
        }
        addParts(e) {
            Object.keys(e).length > 0 && (this.parts = {
                ...this.parts,
                ...e
            })
        }
    }
    Fr.maxCacheSize = 65535;
    const Ur = new WeakSet;

    function Br(e) {
        return !Ur.has(e)
    }

    function zr(e) {
        return Ur.add(e), mr.create(e)
    }
    const Hr = {
        name: r.i.resource.keyFor("views"),
        has: e => "function" == typeof e && (r.f.hasOwn(Hr.name, e) || "$views" in e),
        get(e) {
            if ("function" == typeof e && "$views" in e) {
                const t = e.$views.filter(Br).map(zr);
                for (const n of t) Hr.add(e, n)
            }
            let t = r.f.getOwn(Hr.name, e);
            return void 0 === t && r.f.define(Hr.name, t = [], e), t
        },
        add(e, t) {
            const n = mr.create(t);
            let i = r.f.getOwn(Hr.name, e);
            return void 0 === i ? r.f.define(Hr.name, i = [n], e) : i.push(n), i
        }
    };

    function Wr(e) {
        return function(t) {
            Hr.add(t, e)
        }
    }
    const qr = r.a.createInterface("IViewLocator").noDefault(),
        Gr = ["binding", "bound", "attaching", "attached", "detaching", "caching", "detached", "unbinding", "unbound"];
    class Kr {
        constructor() {
            this.modelInstanceToBoundComponent = new WeakMap, this.modelTypeToUnboundComponent = new Map
        }
        static register(e) {
            return r.j.singleton(qr, this).register(e)
        }
        getViewComponentForObject(e, t) {
            if (e) {
                const n = Hr.has(e.constructor) ? Hr.get(e.constructor) : [],
                    i = "function" == typeof t ? t(e, n) : this.getViewName(n, t);
                return this.getOrCreateBoundComponent(e, n, i)
            }
            return null
        }
        getOrCreateBoundComponent(e, t, n) {
            let i, r = this.modelInstanceToBoundComponent.get(e);
            if (void 0 === r ? (r = {}, this.modelInstanceToBoundComponent.set(e, r)) : i = r[n], void 0 === i) {
                const s = this.getOrCreateUnboundComponent(e, t, n);
                i = vr.define(vr.getDefinition(s), class extends s {
                    constructor() {
                        super(e)
                    }
                }), r[n] = i
            }
            return i
        }
        getOrCreateUnboundComponent(e, t, n) {
            let i, r = this.modelTypeToUnboundComponent.get(e.constructor);
            if (void 0 === r ? (r = {}, this.modelTypeToUnboundComponent.set(e.constructor, r)) : i = r[n], void 0 === i) {
                i = vr.define(this.getView(t, n), class {
                    constructor(e) {
                        this.viewModel = e
                    }
                    created(e) {
                        this.$controller.scope = P.fromParent(e, this.$controller.scope, this.viewModel), this.viewModel.created && this.viewModel.created(e)
                    }
                });
                const s = i.prototype;
                Gr.forEach(t => {
                    if (t in e) {
                        const e = function(e) {
                            return this.viewModel[t](e)
                        };
                        Reflect.defineProperty(e, "name", {
                            configurable: !0,
                            value: t
                        }), s[t] = e
                    }
                }), r[n] = i
            }
            return i
        }
        getViewName(e, t) {
            return t || (1 === e.length ? e[0].name : "default-view")
        }
        getView(e, t) {
            const n = e.find(e => e.name === t);
            if (void 0 === n) throw new Error("Could not find view: " + t);
            return n
        }
    }
    let Yr = class {
        constructor(e) {
            this.viewLocator = e
        }
        toView(e, t) {
            return this.viewLocator.getViewComponentForObject(e, t)
        }
    };
    Yr = Object(s.__decorate)([q("view"), Object(s.__param)(0, qr)], Yr);
    const Xr = r.a.createInterface("IActivator").withDefault(e => e.singleton(Jr));
    class Jr {
        constructor(e) {
            this.taskManager = e
        }
        static register(e) {
            return r.j.singleton(Xr, this).register(e)
        }
        activate(e, t, n, i = 1024, r) {
            i = void 0 === i ? 0 : i;
            const s = this.taskManager;
            let o = s.runBeforeRender();
            return o.done ? this.render(e, t, n, i) : o = new Yi(o, this.render, this, e, t, n, i), o = o.done ? s.runBeforeBind() : new Yi(o, s.runBeforeBind, s), o = o.done ? this.bind(t, i, r) : new Yi(o, this.bind, this, t, i, r), o = o.done ? s.runBeforeAttach() : new Yi(o, s.runBeforeAttach, s), o.done ? this.attach(t, i) : o = new Yi(o, this.attach, this, t, i), o
        }
        deactivate(e, t = 2048) {
            const n = this.getController(e);
            return n.detach(32768 | t), n.unbind(8192 | t)
        }
        render(e, t, n, i) {
            Nr.forCustomElement(t, n, e, i)
        }
        bind(e, t, n) {
            return this.getController(e).bind(4096 | t, n)
        }
        attach(e, t) {
            this.getController(e).attach(16384 | t)
        }
        getController(e) {
            return Nr.forCustomElement(e, void 0, void 0)
        }
    }
    Jr.inject = [Wi];
    class Qr {
        constructor(e, t) {
            if (this.config = e, null != e.host) t.has(Ei, !1) ? this.container = t.createChild() : this.container = t, r.j.instance(Ei, e.host).register(this.container), this.host = e.host;
            else {
                if (!t.has(Ei, !0)) throw new Error("No host element found.");
                this.container = t, this.host = t.get(Ei)
            }
            this.strategy = null != e.strategy ? e.strategy : 1;
            const n = this.container.get(es);
            this.dom = n.initialize(e), this.lifecycle = this.container.get(Xe), this.activator = this.container.get(Xr);
            const i = this.container.get(Wi).runBeforeCreate();
            i.done ? (this.task = Fi.done, this.create()) : this.task = new Yi(i, this.create, this)
        }
        activate(e) {
            const {
                task: t,
                host: n,
                viewModel: i,
                container: r,
                activator: s,
                strategy: o
            } = this, a = 1024 | o;
            if (void 0 === i) return void 0 === this.createTask && (this.createTask = new Yi(t, this.activate, this, e)), this.createTask;
            if (t.done) null == e || e.done ? this.task = s.activate(n, i, r, a, void 0) : this.task = new Yi(e, s.activate, s, n, i, r, a, void 0);
            else if (null == e || e.done) this.task = new Yi(t, s.activate, s, n, i, r, a, void 0);
            else {
                const o = new Yi(t, e.wait, e);
                this.task = new Yi(o, s.activate, s, n, i, r, a, void 0)
            }
            return this.task
        }
        deactivate(e) {
            const {
                task: t,
                viewModel: n,
                activator: i,
                strategy: r
            } = this, s = 2048 | r;
            if (void 0 === n) return void 0 === this.createTask && (this.createTask = new Yi(t, this.deactivate, this, e)), this.createTask;
            if (t.done) null == e || e.done ? this.task = i.deactivate(n, s) : this.task = new Yi(e, i.deactivate, i, n, s);
            else if (null == e || e.done) this.task = new Yi(t, i.deactivate, i, n, s);
            else {
                const r = new Yi(t, e.wait, e);
                this.task = new Yi(r, i.deactivate, i, n, s)
            }
            return this.task
        }
        create() {
            const e = this.config;
            this.viewModel = vr.isType(e.component) ? this.container.get(e.component) : e.component, this.controller = Nr.forCustomElement(this.viewModel, this.container, this.host, this.strategy), !0 === e.enableTimeSlicing ? this.lifecycle.enableTimeslicing(e.adaptiveTimeSlicing) : this.lifecycle.disableTimeslicing()
        }
    }
    class Zr {
        constructor(e = r.a.createContainer()) {
            this.container = e, this.task = Fi.done, this._isRunning = !1, this._isStarting = !1, this._isStopping = !1, this._root = void 0, this.next = void 0, r.j.instance(Zr, this).register(e)
        }
        get isRunning() {
            return this._isRunning
        }
        get isStarting() {
            return this._isStarting
        }
        get isStopping() {
            return this._isStopping
        }
        get root() {
            if (null == this._root) {
                if (null == this.next) throw new Error("root is not defined");
                return this.next
            }
            return this._root
        }
        register(...e) {
            return this.container.register(...e), this
        }
        app(e) {
            return this.next = new Qr(e, this.container), this.isRunning && this.start(), this
        }
        start(e = this.next) {
            if (null == e) throw new Error("There is no composition root");
            return this.stop(e), this.task.done ? this.onBeforeStart(e) : this.task = new Yi(this.task, this.onBeforeStart, this, e), this.task = this.root.activate(this.task), this.task.done ? this.task = this.onAfterStart(e) : this.task = new Yi(this.task, this.onAfterStart, this, e), this.task
        }
        stop(e = this._root) {
            return this._isRunning && null != e && (this.task.done ? this.onBeforeStop(e) : this.task = new Yi(this.task, this.onBeforeStop, this, e), this.task = e.deactivate(this.task), this.task.done ? this.task = this.onAfterStop(e) : this.task = new Yi(this.task, this.onAfterStop, this, e)), this.task
        }
        wait() {
            return this.task.wait()
        }
        onBeforeStart(e) {
            Reflect.set(e.host, "$aurelia", this), this._root = e, this._isStarting = !0
        }
        onAfterStart(e) {
            return this._isRunning = !0, this._isStarting = !1, this.dispatchEvent(e, "aurelia-composed", e.dom), this.dispatchEvent(e, "au-started", e.host), Fi.done
        }
        onBeforeStop(e) {
            this._isRunning = !1, this._isStopping = !0
        }
        onAfterStop(e) {
            return Reflect.deleteProperty(e.host, "$aurelia"), this._root = void 0, this._isStopping = !1, this.dispatchEvent(e, "au-stopped", e.host), Fi.done
        }
        dispatchEvent(e, t, n) {
            (n = "dispatchEvent" in n ? n : e.dom).dispatchEvent(e.dom.createCustomEvent(t, {
                detail: this,
                bubbles: !0,
                cancelable: !0
            }))
        }
    }
    r.g.global.Aurelia = Zr;
    const es = r.a.createInterface("IDOMInitializer").noDefault();

    function ts(e) {
        return function(t) {
            const n = function(...n) {
                const i = new t(...n);
                return i.instructionType = e, i
            };
            n.register = function(e) {
                r.j.singleton(Tr, n).register(e)
            };
            const i = r.f.getOwnKeys(t);
            for (const e of i) r.f.define(e, r.f.getOwn(e, t), n);
            const s = Object.getOwnPropertyDescriptors(t);
            return Object.keys(s).filter(e => "prototype" !== e).forEach(e => {
                Reflect.defineProperty(n, e, s[e])
            }), n
        }
    }
    class ns {
        constructor(e) {
            const t = this.instructionRenderers = {};
            e.forEach(e => {
                t[e.instructionType] = e.render.bind(e)
            })
        }
        static register(e) {
            return r.j.singleton(Er, this).register(e)
        }
        render(e, t, n, i, s, o, a, c) {
            const l = o.instructions,
                u = this.instructionRenderers;
            if (s.length !== l.length) throw s.length > l.length ? r.k.error(30) : r.k.error(31);
            let h, d, p;
            for (let r = 0, o = s.length; r < o; ++r) {
                h = l[r], d = s[r];
                for (let r = 0, s = h.length; r < s; ++r) p = h[r], u[p.type](e, t, n, i, d, p, c)
            }
            if (a) {
                const r = o.surrogates;
                for (let s = 0, o = r.length; s < o; ++s) p = r[s], u[p.type](e, t, n, i, a, p, c)
            }
        }
    }

    function is(e, t, n) {
        return "string" == typeof t ? e.parse(t, n) : t
    }

    function rs(e, t) {
        null == e.bindings ? e.bindings = [t] : e.bindings.push(t)
    }

    function ss(e, t) {
        null == e.controllers ? e.controllers = [t] : e.controllers.push(t)
    }

    function os(e) {
        return void 0 !== e.bindingContext ? e.bindingContext : e
    }

    function as(e, t, n) {
        let i = t.$au;
        void 0 === i && (i = t.$au = new cs), i[n] = e
    }
    ns.inject = [Object(r.n)(Tr)];
    class cs {}
    let ls = class {
        render(e, t, n, i, r, s) {
            os(r)[s.to] = "" === s.value || s.value
        }
    };
    ls = Object(s.__decorate)([ts("re")], ls);
    let us = class {
        render(e, t, n, i, r, s) {
            const o = n.beginComponentOperation(i, r, s, null, null, r, !0),
                a = n.get(vr.keyFrom(s.res)),
                c = n.get(Er).instructionRenderers,
                l = s.instructions,
                u = Nr.forCustomElement(a, n, r, e, s);
            let h;
            as(u, u.host, s.res);
            for (let r = 0, s = l.length; r < s; ++r) h = l[r], c[h.type](e, t, n, i, u, h);
            ss(i, u), o.dispose()
        }
    };
    us = Object(s.__decorate)([ts("ra")], us);
    let hs = class {
        render(e, t, n, i, r, s) {
            const o = n.beginComponentOperation(i, r, s),
                a = n.get(Ti.keyFrom(s.res)),
                c = n.get(Er).instructionRenderers,
                l = s.instructions,
                u = Nr.forCustomAttribute(a, n, e);
            let h;
            as(u, r, s.res);
            for (let r = 0, s = l.length; r < s; ++r) h = l[r], c[h.type](e, t, n, i, u, h);
            ss(i, u), o.dispose()
        }
    };
    hs = Object(s.__decorate)([ts("rb")], hs);
    let ds = class {
        constructor(e, t) {
            this.renderingEngine = e, this.observerLocator = t
        }
        render(e, t, n, i, r, s, o) {
            const a = this.renderingEngine.getViewFactory(t, s.def, n),
                c = t.convertToRenderLocation(r),
                l = n.beginComponentOperation(i, r, s, a, o, c, !1),
                u = n.get(Ti.keyFrom(s.res)),
                h = n.get(Er).instructionRenderers,
                d = s.instructions;
            void 0 !== s.parts && (o = void 0 === o ? s.parts : {
                ...o,
                ...s.parts
            });
            const p = Nr.forCustomAttribute(u, n, e);
            if (s.link) {
                const e = i.controllers;
                u.link(e[e.length - 1])
            }
            let f;
            as(p, c, s.res);
            for (let r = 0, s = d.length; r < s; ++r) f = d[r], h[f.type](e, t, n, i, p, f);
            ss(i, p), l.dispose()
        }
    };
    ds = Object(s.__decorate)([ts("rc"), Object(s.__param)(0, jr), Object(s.__param)(1, ti)], ds);
    let ps = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, s) {
            t.remove(r);
            const o = s.instructions,
                a = s.toBindingContext;
            let c, l, u;
            for (let e = 0, t = o.length; e < t; ++e) c = o[e], l = is(this.parser, c.from, 48), u = new jt(l, c.to, this.observerLocator, n, a), rs(i, u)
        }
    };
    ps = Object(s.__decorate)([ts("rd"), Object(s.__param)(0, _t), Object(s.__param)(1, ti)], ps);
    let fs = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, s) {
            const o = is(this.parser, s.from, 153);
            rs(i, new xt(o, os(r), s.to, this.observerLocator, n))
        }
    };
    fs = Object(s.__decorate)([ts("rh"), Object(s.__param)(0, _t), Object(s.__param)(1, ti)], fs);
    let gs = class {
        constructor(e) {
            this.parser = e
        }
        render(e, t, n, i, r, s) {
            const o = is(this.parser, s.from, 5376);
            rs(i, new Mt(o, function(e, t) {
                if ("element" === t) return e;
                const n = e.$au;
                if (void 0 === n) throw new Error(`No Aurelia APIs are defined for the element: "${e.tagName}".`);
                let i;
                switch (t) {
                    case "controller":
                        return e.$controller;
                    case "view":
                        throw new Error("Not supported API");
                    case "view-model":
                        return e.$controller.viewModel;
                    default:
                        if (i = n[t], void 0 === i) throw new Error(`Attempted to reference "${t}", but it was not found amongst the target's API.`);
                        return i.viewModel
                }
            }(r, s.to), n))
        }
    };
    gs = Object(s.__decorate)([ts("rj"), Object(s.__param)(0, _t)], gs);
    let ms = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, s) {
            let o;
            const a = is(this.parser, s.from, 2048);
            o = a.isMulti ? new Tt(this.observerLocator, a, os(r), s.to, Ve.toView, n) : new Et(a.firstExpression, a, os(r), s.to, Ve.toView, this.observerLocator, n, !0), rs(i, o)
        }
    };
    ms = Object(s.__decorate)([ts("rf"), Object(s.__param)(0, _t), Object(s.__param)(1, ti)], ms);
    let vs = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, s) {
            const o = is(this.parser, s.from, 48 | s.mode);
            rs(i, new kt(o, os(r), s.to, s.mode, this.observerLocator, n))
        }
    };
    vs = Object(s.__decorate)([ts("rg"), Object(s.__param)(0, _t), Object(s.__param)(1, ti)], vs);
    let bs = class {
        constructor(e, t) {
            this.parser = e, this.observerLocator = t
        }
        render(e, t, n, i, r, s) {
            const o = is(this.parser, s.from, 539);
            rs(i, new kt(o, os(r), s.to, Ve.toView, this.observerLocator, n))
        }
    };
    bs = Object(s.__decorate)([ts("rk"), Object(s.__param)(0, _t), Object(s.__param)(1, ti)], bs);
    const ys = ri,
        ws = ot,
        ks = ns,
        xs = [ys, ws, ks, qi, Kr],
        _s = er,
        Ss = tr,
        Os = rr,
        Cs = ar,
        As = cr,
        Ts = kr,
        Es = mi,
        js = ci,
        Ms = li,
        Ls = ui,
        Ps = bi,
        Rs = wi,
        Is = hi,
        Ds = vi,
        Ns = [Vi, Ni, $i, _s, Ss, Os, Cs, As, Ts, Yr, Es, js, Ms, Ls, Ps, Ds, Rs, Is],
        Vs = fs,
        $s = hs,
        Fs = us,
        Us = ms,
        Bs = bs,
        zs = ps,
        Hs = vs,
        Ws = gs,
        qs = ls,
        Gs = ds,
        Ks = [Hs, Bs, Vs, Ws, Us, qs, Fs, $s, Gs, zs],
        Ys = {
            register: e => e.register(...xs, ...Ns, ...Ks),
            createContainer() {
                return this.register(r.a.createContainer())
            }
        };
    class Xs {
        constructor(e, t) {
            this.type = "rf", this.from = e, this.to = t
        }
    }
    class Js {
        constructor(e, t) {
            this.type = "rg", this.from = e, this.mode = Ve.oneTime, this.oneTime = !0, this.to = t
        }
    }
    class Qs {
        constructor(e, t) {
            this.type = "rg", this.from = e, this.mode = Ve.toView, this.oneTime = !1, this.to = t
        }
    }
    class Zs {
        constructor(e, t) {
            this.type = "rg", this.from = e, this.mode = Ve.fromView, this.oneTime = !1, this.to = t
        }
    }
    class eo {
        constructor(e, t) {
            this.type = "rg", this.from = e, this.mode = Ve.twoWay, this.oneTime = !1, this.to = t
        }
    }
    class to {
        constructor(e, t) {
            this.type = "rk", this.from = e, this.to = t
        }
    }
    class no {
        constructor(e, t) {
            this.type = "rh", this.from = e, this.to = t
        }
    }
    class io {
        constructor(e, t) {
            this.from = e, this.to = t, this.type = "rj"
        }
    }
    class ro {
        constructor(e, t) {
            this.type = "re", this.to = t, this.value = e
        }
    }
    class so {
        constructor(e, t, n) {
            this.type = "ra", this.instructions = t, this.parts = n, this.res = e
        }
    }
    class oo {
        constructor(e, t) {
            this.type = "rb", this.instructions = t, this.res = e
        }
    }
    class ao {
        constructor(e, t, n, i, r) {
            this.type = "rc", this.def = e, this.instructions = n, this.link = i, this.parts = r, this.res = t
        }
    }
    class co {
        constructor(e, t) {
            this.type = "rd", this.instructions = e, this.toBindingContext = t
        }
    }
    class lo {
        constructor(e, t) {
            this.type = "ri", this.from = e, this.to = t
        }
    }
    n.d(t, "CallFunctionExpression", (function() {
        return we
    })), n.d(t, "connects", (function() {
        return Y
    })), n.d(t, "observes", (function() {
        return X
    })), n.d(t, "callsFunction", (function() {
        return J
    })), n.d(t, "hasAncestor", (function() {
        return Q
    })), n.d(t, "isAssignable", (function() {
        return Z
    })), n.d(t, "isLeftHandSide", (function() {
        return ee
    })), n.d(t, "isPrimary", (function() {
        return te
    })), n.d(t, "isResource", (function() {
        return ne
    })), n.d(t, "hasBind", (function() {
        return ie
    })), n.d(t, "hasUnbind", (function() {
        return re
    })), n.d(t, "isLiteral", (function() {
        return se
    })), n.d(t, "arePureLiterals", (function() {
        return oe
    })), n.d(t, "isPureLiteral", (function() {
        return ae
    })), n.d(t, "CustomExpression", (function() {
        return le
    })), n.d(t, "BindingBehaviorExpression", (function() {
        return ue
    })), n.d(t, "ValueConverterExpression", (function() {
        return he
    })), n.d(t, "AssignExpression", (function() {
        return de
    })), n.d(t, "ConditionalExpression", (function() {
        return pe
    })), n.d(t, "AccessThisExpression", (function() {
        return fe
    })), n.d(t, "AccessScopeExpression", (function() {
        return ge
    })), n.d(t, "AccessMemberExpression", (function() {
        return me
    })), n.d(t, "AccessKeyedExpression", (function() {
        return ve
    })), n.d(t, "CallScopeExpression", (function() {
        return be
    })), n.d(t, "CallMemberExpression", (function() {
        return ye
    })), n.d(t, "BinaryExpression", (function() {
        return ke
    })), n.d(t, "UnaryExpression", (function() {
        return xe
    })), n.d(t, "PrimitiveLiteralExpression", (function() {
        return _e
    })), n.d(t, "HtmlLiteralExpression", (function() {
        return Se
    })), n.d(t, "ArrayLiteralExpression", (function() {
        return Oe
    })), n.d(t, "ObjectLiteralExpression", (function() {
        return Ce
    })), n.d(t, "TemplateExpression", (function() {
        return Ae
    })), n.d(t, "TaggedTemplateExpression", (function() {
        return Te
    })), n.d(t, "ArrayBindingPattern", (function() {
        return Ee
    })), n.d(t, "ObjectBindingPattern", (function() {
        return je
    })), n.d(t, "BindingIdentifier", (function() {
        return Me
    })), n.d(t, "ForOfStatement", (function() {
        return Pe
    })), n.d(t, "Interpolation", (function() {
        return Re
    })), n.d(t, "PropertyBinding", (function() {
        return kt
    })), n.d(t, "CallBinding", (function() {
        return xt
    })), n.d(t, "connectable", (function() {
        return gt
    })), n.d(t, "IExpressionParser", (function() {
        return _t
    })), n.d(t, "BindingType", (function() {
        return Ot
    })), n.d(t, "MultiInterpolationBinding", (function() {
        return Tt
    })), n.d(t, "InterpolationBinding", (function() {
        return Et
    })), n.d(t, "LetBinding", (function() {
        return jt
    })), n.d(t, "RefBinding", (function() {
        return Mt
    })), n.d(t, "ArrayObserver", (function() {
        return an
    })), n.d(t, "enableArrayObservation", (function() {
        return sn
    })), n.d(t, "disableArrayObservation", (function() {
        return on
    })), n.d(t, "applyMutationsToIndices", (function() {
        return ln
    })), n.d(t, "synchronizeIndices", (function() {
        return un
    })), n.d(t, "MapObserver", (function() {
        return Sn
    })), n.d(t, "enableMapObservation", (function() {
        return xn
    })), n.d(t, "disableMapObservation", (function() {
        return _n
    })), n.d(t, "SetObserver", (function() {
        return Vn
    })), n.d(t, "enableSetObservation", (function() {
        return Dn
    })), n.d(t, "disableSetObservation", (function() {
        return Nn
    })), n.d(t, "BindingContext", (function() {
        return L
    })), n.d(t, "Scope", (function() {
        return P
    })), n.d(t, "OverrideContext", (function() {
        return R
    })), n.d(t, "CollectionLengthObserver", (function() {
        return $t
    })), n.d(t, "CollectionSizeObserver", (function() {
        return hn
    })), n.d(t, "computed", (function() {
        return Fn
    })), n.d(t, "createComputedObserver", (function() {
        return Bn
    })), n.d(t, "CustomSetterObserver", (function() {
        return zn
    })), n.d(t, "GetterObserver", (function() {
        return Hn
    })), n.d(t, "IDirtyChecker", (function() {
        return Gn
    })), n.d(t, "DirtyCheckProperty", (function() {
        return Xn
    })), n.d(t, "DirtyCheckSettings", (function() {
        return Kn
    })), n.d(t, "IObserverLocator", (function() {
        return ti
    })), n.d(t, "ITargetObserverLocator", (function() {
        return ni
    })), n.d(t, "ITargetAccessorLocator", (function() {
        return ii
    })), n.d(t, "getCollectionObserver", (function() {
        return si
    })), n.d(t, "ObserverLocator", (function() {
        return ri
    })), n.d(t, "PrimitiveObserver", (function() {
        return Qn
    })), n.d(t, "PropertyAccessor", (function() {
        return Zn
    })), n.d(t, "ProxyObserver", (function() {
        return A
    })), n.d(t, "SelfObserver", (function() {
        return oi
    })), n.d(t, "SetterObserver", (function() {
        return T
    })), n.d(t, "ISignaler", (function() {
        return I
    })), n.d(t, "subscriberCollection", (function() {
        return o
    })), n.d(t, "collectionSubscriberCollection", (function() {
        return c
    })), n.d(t, "proxySubscriberCollection", (function() {
        return a
    })), n.d(t, "bindingBehavior", (function() {
        return z
    })), n.d(t, "BindingBehavior", (function() {
        return W
    })), n.d(t, "BindingBehaviorDefinition", (function() {
        return H
    })), n.d(t, "BindingModeBehavior", (function() {
        return ai
    })), n.d(t, "OneTimeBindingBehavior", (function() {
        return ci
    })), n.d(t, "ToViewBindingBehavior", (function() {
        return li
    })), n.d(t, "FromViewBindingBehavior", (function() {
        return ui
    })), n.d(t, "TwoWayBindingBehavior", (function() {
        return hi
    })), n.d(t, "DebounceBindingBehavior", (function() {
        return mi
    })), n.d(t, "PriorityBindingBehavior", (function() {
        return vi
    })), n.d(t, "SignalBindingBehavior", (function() {
        return bi
    })), n.d(t, "ThrottleBindingBehavior", (function() {
        return wi
    })), n.d(t, "customAttribute", (function() {
        return Oi
    })), n.d(t, "CustomAttribute", (function() {
        return Ti
    })), n.d(t, "CustomAttributeDefinition", (function() {
        return Ai
    })), n.d(t, "templateController", (function() {
        return Ci
    })), n.d(t, "FrequentMutations", (function() {
        return Vi
    })), n.d(t, "InfrequentMutations", (function() {
        return Ni
    })), n.d(t, "ObserveShallow", (function() {
        return $i
    })), n.d(t, "If", (function() {
        return er
    })), n.d(t, "Else", (function() {
        return tr
    })), n.d(t, "Repeat", (function() {
        return rr
    })), n.d(t, "Replaceable", (function() {
        return ar
    })), n.d(t, "With", (function() {
        return cr
    })), n.d(t, "containerless", (function() {
        return gr
    })), n.d(t, "customElement", (function() {
        return pr
    })), n.d(t, "CustomElement", (function() {
        return vr
    })), n.d(t, "CustomElementDefinition", (function() {
        return mr
    })), n.d(t, "IProjectorLocator", (function() {
        return br
    })), n.d(t, "useShadowDOM", (function() {
        return fr
    })), n.d(t, "ValueConverter", (function() {
        return K
    })), n.d(t, "ValueConverterDefinition", (function() {
        return G
    })), n.d(t, "valueConverter", (function() {
        return q
    })), n.d(t, "ISanitizer", (function() {
        return wr
    })), n.d(t, "SanitizeValueConverter", (function() {
        return kr
    })), n.d(t, "ViewValueConverter", (function() {
        return Yr
    })), n.d(t, "bindable", (function() {
        return ki
    })), n.d(t, "BindableDefinition", (function() {
        return Si
    })), n.d(t, "Bindable", (function() {
        return _i
    })), n.d(t, "ChildrenDefinition", (function() {
        return dr
    })), n.d(t, "Children", (function() {
        return hr
    })), n.d(t, "children", (function() {
        return lr
    })), n.d(t, "Controller", (function() {
        return Nr
    })), n.d(t, "ViewFactory", (function() {
        return Fr
    })), n.d(t, "IViewLocator", (function() {
        return qr
    })), n.d(t, "ViewLocator", (function() {
        return Kr
    })), n.d(t, "view", (function() {
        return Wr
    })), n.d(t, "Views", (function() {
        return Hr
    })), n.d(t, "Aurelia", (function() {
        return Zr
    })), n.d(t, "IDOMInitializer", (function() {
        return es
    })), n.d(t, "CompositionRoot", (function() {
        return Qr
    })), n.d(t, "IfRegistration", (function() {
        return _s
    })), n.d(t, "ElseRegistration", (function() {
        return Ss
    })), n.d(t, "RepeatRegistration", (function() {
        return Os
    })), n.d(t, "ReplaceableRegistration", (function() {
        return Cs
    })), n.d(t, "WithRegistration", (function() {
        return As
    })), n.d(t, "SanitizeValueConverterRegistration", (function() {
        return Ts
    })), n.d(t, "DebounceBindingBehaviorRegistration", (function() {
        return Es
    })), n.d(t, "OneTimeBindingBehaviorRegistration", (function() {
        return js
    })), n.d(t, "ToViewBindingBehaviorRegistration", (function() {
        return Ms
    })), n.d(t, "FromViewBindingBehaviorRegistration", (function() {
        return Ls
    })), n.d(t, "PriorityBindingBehaviorRegistration", (function() {
        return Ds
    })), n.d(t, "SignalBindingBehaviorRegistration", (function() {
        return Ps
    })), n.d(t, "ThrottleBindingBehaviorRegistration", (function() {
        return Rs
    })), n.d(t, "TwoWayBindingBehaviorRegistration", (function() {
        return Is
    })), n.d(t, "RefBindingRendererRegistration", (function() {
        return Ws
    })), n.d(t, "CallBindingRendererRegistration", (function() {
        return Vs
    })), n.d(t, "CustomAttributeRendererRegistration", (function() {
        return $s
    })), n.d(t, "CustomElementRendererRegistration", (function() {
        return Fs
    })), n.d(t, "InterpolationBindingRendererRegistration", (function() {
        return Us
    })), n.d(t, "IteratorBindingRendererRegistration", (function() {
        return Bs
    })), n.d(t, "LetElementRendererRegistration", (function() {
        return zs
    })), n.d(t, "PropertyBindingRendererRegistration", (function() {
        return Hs
    })), n.d(t, "SetPropertyRendererRegistration", (function() {
        return qs
    })), n.d(t, "TemplateControllerRendererRegistration", (function() {
        return Gs
    })), n.d(t, "DefaultResources", (function() {
        return Ns
    })), n.d(t, "IObserverLocatorRegistration", (function() {
        return ys
    })), n.d(t, "ILifecycleRegistration", (function() {
        return ws
    })), n.d(t, "IRendererRegistration", (function() {
        return ks
    })), n.d(t, "RuntimeConfiguration", (function() {
        return Ys
    })), n.d(t, "HooksDefinition", (function() {
        return F
    })), n.d(t, "isTargetedInstruction", (function() {
        return $
    })), n.d(t, "ITargetedInstruction", (function() {
        return V
    })), n.d(t, "TargetedInstructionType", (function() {
        return N
    })), n.d(t, "alias", (function() {
        return U
    })), n.d(t, "registerAliases", (function() {
        return B
    })), n.d(t, "DOM", (function() {
        return Ri
    })), n.d(t, "INode", (function() {
        return Ei
    })), n.d(t, "IRenderLocation", (function() {
        return ji
    })), n.d(t, "IDOM", (function() {
        return Mi
    })), n.d(t, "NodeSequence", (function() {
        return Ii
    })), n.d(t, "BindingMode", (function() {
        return Ve
    })), n.d(t, "BindingStrategy", (function() {
        return $e
    })), n.d(t, "ExpressionKind", (function() {
        return ze
    })), n.d(t, "Hooks", (function() {
        return Ue
    })), n.d(t, "LifecycleFlags", (function() {
        return Be
    })), n.d(t, "State", (function() {
        return Fe
    })), n.d(t, "CallBindingInstruction", (function() {
        return no
    })), n.d(t, "FromViewBindingInstruction", (function() {
        return Zs
    })), n.d(t, "HydrateAttributeInstruction", (function() {
        return oo
    })), n.d(t, "HydrateElementInstruction", (function() {
        return so
    })), n.d(t, "HydrateTemplateController", (function() {
        return ao
    })), n.d(t, "InterpolationInstruction", (function() {
        return Xs
    })), n.d(t, "IteratorBindingInstruction", (function() {
        return to
    })), n.d(t, "LetBindingInstruction", (function() {
        return lo
    })), n.d(t, "LetElementInstruction", (function() {
        return co
    })), n.d(t, "OneTimeBindingInstruction", (function() {
        return Js
    })), n.d(t, "RefBindingInstruction", (function() {
        return io
    })), n.d(t, "SetPropertyInstruction", (function() {
        return ro
    })), n.d(t, "ToViewBindingInstruction", (function() {
        return Qs
    })), n.d(t, "TwoWayBindingInstruction", (function() {
        return eo
    })), n.d(t, "ViewModelKind", (function() {
        return He
    })), n.d(t, "ILifecycle", (function() {
        return Xe
    })), n.d(t, "IController", (function() {
        return We
    })), n.d(t, "IViewFactory", (function() {
        return Ge
    })), n.d(t, "MountStrategy", (function() {
        return qe
    })), n.d(t, "Priority", (function() {
        return Ye
    })), n.d(t, "AggregateContinuationTask", (function() {
        return Ji
    })), n.d(t, "TerminalTask", (function() {
        return Xi
    })), n.d(t, "AggregateTerminalTask", (function() {
        return Qi
    })), n.d(t, "ContinuationTask", (function() {
        return Yi
    })), n.d(t, "LifecycleTask", (function() {
        return Fi
    })), n.d(t, "PromiseTask", (function() {
        return Gi
    })), n.d(t, "TaskSlot", (function() {
        return Ui
    })), n.d(t, "StartTask", (function() {
        return Hi
    })), n.d(t, "IStartTask", (function() {
        return Bi
    })), n.d(t, "IStartTaskManager", (function() {
        return Wi
    })), n.d(t, "ProviderTask", (function() {
        return Ki
    })), n.d(t, "CollectionKind", (function() {
        return Rt
    })), n.d(t, "DelegationStrategy", (function() {
        return Pt
    })), n.d(t, "isIndexMap", (function() {
        return Vt
    })), n.d(t, "copyIndexMap", (function() {
        return It
    })), n.d(t, "cloneIndexMap", (function() {
        return Nt
    })), n.d(t, "createIndexMap", (function() {
        return Dt
    })), n.d(t, "instructionRenderer", (function() {
        return ts
    })), n.d(t, "ensureExpression", (function() {
        return is
    })), n.d(t, "addComponent", (function() {
        return ss
    })), n.d(t, "addBinding", (function() {
        return rs
    })), n.d(t, "CompiledTemplate", (function() {
        return Ar
    })), n.d(t, "ChildrenObserver", (function() {
        return Lr
    })), n.d(t, "IInstructionRenderer", (function() {
        return Tr
    })), n.d(t, "IRenderer", (function() {
        return Er
    })), n.d(t, "IRenderingEngine", (function() {
        return jr
    })), n.d(t, "ITemplateCompiler", (function() {
        return Sr
    })), n.d(t, "ITemplateFactory", (function() {
        return Cr
    })), n.d(t, "ViewCompileFlags", (function() {
        return Or
    })), n.d(t, "RenderContext", (function() {
        return xr
    }))
});
