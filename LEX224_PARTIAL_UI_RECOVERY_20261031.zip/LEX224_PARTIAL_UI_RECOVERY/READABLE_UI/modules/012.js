// Extracted webpack module 12. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";

    function i(e) {
        e.oncontextmenu = null
    }

    function r(e) {
        e.oncontextmenu = () => !1
    }

    function s() {
        document.addEventListener("keydown", e => {
            if ("Backspace" === e.key || "Delete" === e.key) {
                const t = e.composedPath()[0];
                t.matches && !t.matches("input:not([readonly]):not([type=radio]):not([type=checkbox]), textarea, [contentEditable], [contentEditable=true]") && e.preventDefault()
            }
        })
    }

    function o() {
        document.addEventListener("keydown", e => {
            if (" " === e.key || 32 == e.keyCode) {
                const t = e.composedPath()[0];
                t.matches && !t.matches("input[type=text]") && e.preventDefault()
            }
        })
    }

    function a(e, t = "change", n = {
        bubbles: !0
    }) {
        e.dispatchEvent(new Event(t, n))
    }
    n.d(t, "e", (function() {
        return i
    })), n.d(t, "b", (function() {
        return r
    })), n.d(t, "a", (function() {
        return s
    })), n.d(t, "c", (function() {
        return o
    })), n.d(t, "d", (function() {
        return a
    }))
});
