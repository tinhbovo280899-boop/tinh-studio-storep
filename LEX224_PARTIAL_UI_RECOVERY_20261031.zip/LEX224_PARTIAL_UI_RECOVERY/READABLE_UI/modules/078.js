// Extracted webpack module 78. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return w
        }));
        var i = n(0),
            r = n(1),
            s = n(17),
            o = n(10),
            a = n(5),
            c = n(19),
            l = n(13),
            u = n(7),
            h = n(12),
            d = n(96),
            p = n(3),
            f = n(4),
            g = n.n(f),
            m = n(8),
            v = n(9);
        let b = d;
        p.i && (b = g.a.readFileSync(g.a.resolve(e, "./ua-slider-range.html"), "utf-8"));
        const y = Object.assign(Object.assign({}, m.a), {
            orientation: o.a.horizontal
        });
        let w = class extends m.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = y, this.writable = !0, this.offset = 0, this.valueLow = 0, this.valueHigh = 1, this.valueType = a.c.normalized, this.activeSlider = "valueLow", this.onCoverTouchStart = e => {
                    if (e.preventDefault(), e.touches.length > 1) return !1;
                    const t = this.profile.isHorizontal(this.orientation) ? e.touches[0].clientX : e.touches[0].clientY;
                    return this.updateActiveSlider(t), this.onTouchStart(e), !0
                }, this.onCoverMouseDown = e => {
                    const t = this.profile.isHorizontal(this.orientation) ? e.clientX : e.clientY;
                    this.updateActiveSlider(t), this.onMouseDown(e, this.activeSlider)
                }, this.onTouchStart = e => {
                    if (e.preventDefault(), e.touches.length > 1) return;
                    if (this.disabled || this.scrolling) return;
                    if (this.profile.isRevertTouchEvent(e)) return void this.publishUANetInteraction({
                        action: "REVERT"
                    });
                    if (this.profile.isDefaultEvent(e)) return void this.publishUANetInteraction({
                        action: "DEFAULT"
                    });
                    this.configureStep(e), this.dragging = !0, this.publishUANetInteraction({
                        action: "START",
                        publishState: {
                            viewModelPropertyName: this.activeSlider
                        }
                    });
                    const t = this.createInteraction({
                        event: e
                    });
                    t.hasMoved && ("valueLow" === this.activeSlider ? (this.valueLow = this.discrete ? t.trackerState.value : Object(u.a)(t.trackerState.value, this.min, this.max), this.publishUANetInteraction({
                        action: "CHANGE",
                        publishState: {
                            viewModelPropertyName: "valueLow"
                        }
                    })) : (this.valueHigh = this.discrete ? t.trackerState.value : Object(u.a)(t.trackerState.value, this.min, this.max), this.publishUANetInteraction({
                        action: "CHANGE",
                        publishState: {
                            viewModelPropertyName: "valueHigh"
                        }
                    }))), window.addEventListener("touchmove", this.onTouchMove), window.addEventListener("touchend", this.createTouchEnd(this.activeSlider)), window.addEventListener("touchcancel", this.createTouchEnd(this.activeSlider))
                }, this.onTouchMove = e => {
                    if (e.preventDefault(), !(e.touches.length > 1) && !this.disabled && !this.scrolling && (this.dragging = !0, this.dragging)) {
                        this.configureStep(e);
                        const t = "valueLow" === this.activeSlider ? this.$inputRangeLow : this.$inputRangeHigh,
                            n = this.createInteraction({
                                event: e
                            });
                        n.hasMoved && (this[this.activeSlider] = this.discrete ? n.trackerState.value : Object(u.a)(n.trackerState.value, this.min, this.max), t.value = String(this[this.activeSlider]), this.publishUANetInteraction({
                            action: "CHANGE",
                            publishState: {
                                viewModelPropertyName: this.activeSlider
                            }
                        }))
                    }
                }, this.onMouseMove = e => {
                    if (e.preventDefault(), !this.disabled && !this.scrolling && this.dragging) {
                        this.configureStep(e);
                        let t = "valueLow" === this.activeSlider ? this.$inputRangeLow : this.$inputRangeHigh;
                        const n = this.createInteraction({
                            event: e
                        });
                        if (n.hasMoved) {
                            let e = this.discrete ? n.trackerState.value : Object(u.a)(n.trackerState.value, this.min, this.max);
                            this[this.activeSlider] = e, t.value = String(this[this.activeSlider]), this.publishUANetInteraction({
                                action: "CHANGE",
                                publishState: {
                                    viewModelPropertyName: this.activeSlider
                                }
                            })
                        }
                    }
                }, this.tryEndScroll = Object(c.a)(e => {
                    this.configureStep(null), this.scrolling = !1, this.publishUANetInteraction({
                        action: "END",
                        publishState: {
                            viewModelPropertyName: e
                        }
                    })
                }, 200).fn, this.initClassState(), this.disabled = !1, this.dragging = !1, this.scrolling = !1, this.wheelListener = e => this.onCoverMouseWheel(e)
            }
            getHardwareAcceleratedDisplay() {
                return this.$display
            }
            attached() {
                this.configureStep(null)
            }
            attaching() {
                this.element.addEventListener("wheel", this.wheelListener)
            }
            detaching() {
                this.element.removeEventListener("wheel", this.wheelListener)
            }
            overrideGenTrackerState(e) {
                return {
                    value: "valueLow" === this.activeSlider ? this.valueLow : this.valueHigh
                }
            }
            valueLowChanged(e, t) {
                if (Number.isNaN(e)) return void console.warn("valueLow is NaN");
                if (e = Object(u.b)(e), t = Object(u.b)(t), 0 === Math.abs(e - t)) return;
                const n = Object(u.a)(e, this.min, this.max - +this.step);
                n === e ? (n >= Object(u.b)(this.valueHigh) && (this.publishUANetInteraction({
                    action: "START",
                    publishState: {
                        viewModelPropertyName: "valueHigh"
                    }
                }), this.valueHigh = Object(u.a)(this.valueLow + +this.step, this.min + +this.step, this.max), this.publishUANetInteraction({
                    action: "CHANGE",
                    publishState: {
                        viewModelPropertyName: "valueHigh"
                    }
                }), this.publishUANetInteraction({
                    action: "END",
                    publishState: {
                        viewModelPropertyName: "valueHigh"
                    }
                })), Object(h.d)(this.element)) : this.valueLow = n
            }
            valueHighChanged(e, t) {
                if (Number.isNaN(e)) return void console.warn("valueHigh is NaN");
                if (e = Object(u.b)(e), t = Object(u.b)(t), 0 === Math.abs(e - t)) return;
                const n = Object(u.a)(e, this.min + +this.step, this.max);
                n === e ? (n <= Object(u.b)(this.valueLow) && (this.publishUANetInteraction({
                    action: "START",
                    publishState: {
                        viewModelPropertyName: "valueLow"
                    }
                }), this.valueLow = Object(u.a)(this.valueHigh - +this.step, this.min, this.max - +this.step), this.publishUANetInteraction({
                    action: "CHANGE",
                    publishState: {
                        viewModelPropertyName: "valueLow"
                    }
                }), this.publishUANetInteraction({
                    action: "END",
                    publishState: {
                        viewModelPropertyName: "valueLow"
                    }
                })), Object(h.d)(this.element)) : this.valueHigh = n
            }
            calculateLayoutProperties() {
                var e;
                if (this.$inputRangeLow && this.$inputRangeHigh) {
                    const t = this.$sliderContainer.getBoundingClientRect();
                    if (t.width > 0 && t.height > 0) {
                        let n = 0,
                            i = 0,
                            r = 0;
                        e = this.$inputRangeLow.getElementsByClassName("click-indicator")[0];
                        if (this.profile.isHorizontal(this.orientation)) n = t.width, i = t.left;
                        else {
                            let e = Math.round(t.top - (t.width - t.height) / 2);
                            Math.round(t.left + (t.width - t.height) / 2);
                            n = t.width, i = e
                        }
                        return {
                            startPx: i + Math.floor(r / 2),
                            rangePx: n - r
                        }
                    }
                    console.warn("ua-slider-range: rect bounds are 0. cannot calculate rangePx and startPx")
                } else console.warn("ua-slider-range: refs are undefined. cannot calculate rangePx and startPx")
            }
            setLayoutProperties() {
                const e = this.calculateLayoutProperties();
                e && (this.startPx = e.startPx, this.rangePx = e.rangePx)
            }
            handleLifecycle({
                type: e,
                payload: t
            }) {
                switch (e) {
                    case "TRACKER_STATE_INIT":
                        this.setLayoutProperties()
                }
            }
            getInteraction() {
                return this
            }
            subscribe(e, t) {
                return this.ea.subscribe(e, t)
            }
            configureStep(e) {
                if (e && void 0 !== this.step) {
                    let t = this.step;
                    void 0 !== this.fineStep && (t = this.profile.isFineTuneEvent(e) ? this.fineStep : this.step), this.$inputRangeLow.step = t.toString(), this.$inputRangeHigh.step = t.toString()
                }
            }
            configureFromUANet(e, t, n, i) {
                if (this.states = i.getRealValues({
                        paramName: t
                    }), i.isDiscreteParam(t)) {
                    this.discrete = !0, this.min = 0 + this.offset, this.max = i.numStepsParam(t) - 1 + this.offset, this.step = 1;
                    let e = (Object(u.b)(this.valueLow) - this.min) / (this.max - this.min),
                        r = (Object(u.b)(this.valueHigh) - this.min) / (this.max - this.min),
                        s = e * (this.max - this.min) + this.min,
                        o = r * (this.max - this.min) + this.min;
                    o !== Object(u.b)(this.valueHigh) && (this.valueHigh = o), s !== Object(u.b)(this.valueLow) && (this.valueLow = s), n.valueType = this.valueType === a.c.string ? a.c.string : a.c.real
                } else {
                    this.discrete = !1;
                    let e = (Object(u.b)(this.valueLow) - this.min) / (this.max - this.min),
                        t = (Object(u.b)(this.valueHigh) - this.min) / (this.max - this.min);
                    this.min = 0, this.max = 1, t !== Object(u.b)(this.valueHigh) && (this.valueHigh = t), e !== Object(u.b)(this.valueLow) && (this.valueLow = e), this.configureStep(null)
                }
            }
            setUANetValue(e, t) {
                this.discrete ? this[e] = this.valueType === a.c.string ? parseInt(t) : t : this[e] = t * (this.max - this.min)
            }
            getUANetValue(e) {
                return this.discrete ? this[e] : this[e] / (this.max - this.min)
            }
            updateActiveSlider(e) {
                const t = this.$sliderContainer.getBoundingClientRect();
                let n, i, r;
                if (this.profile.isHorizontal(this.orientation)) n = t.width, i = t.left, r = e - i;
                else {
                    let s = Math.round(t.top - (t.width - t.height) / 2);
                    n = t.width, i = s, r = n - (e - i)
                }
                const s = (this.valueLow - this.offset) / (this.max - this.min);
                r <= (((this.valueHigh - this.offset) / (this.max - this.min) - s) / 2 + s) * n ? (this.$inputRangeLow.uaActiveSlider = !0, this.$inputRangeLow.style.zIndex = "10", this.$inputRangeHigh.uaActiveSlider = !1, this.$inputRangeHigh.style.zIndex = "0", this.activeSlider = "valueLow") : (this.$inputRangeHigh.uaActiveSlider = !0, this.$inputRangeHigh.style.zIndex = "10", this.$inputRangeLow.uaActiveSlider = !1, this.$inputRangeLow.style.zIndex = "0", this.activeSlider = "valueHigh")
            }
            createTouchEnd(e) {
                const t = n => {
                    this.configureStep(null), this.createInteraction({
                        event: n
                    }), this.publishUANetInteraction({
                        action: "END",
                        publishState: {
                            viewModelPropertyName: e
                        }
                    }), window.removeEventListener("touchend", t), window.removeEventListener("touchcancel", t), window.removeEventListener("touchmove", this.onTouchMove), this.dragging = !1
                };
                return t
            }
            onMouseDown(e, t) {
                if (0 != e.button) return;
                if (e.preventDefault(), this.disabled || !this.writable || this.scrolling) return;
                if (this.profile.isRevertEvent(e)) return void this.publishUANetInteraction({
                    action: "REVERT",
                    publishState: {
                        viewModelPropertyName: this.activeSlider
                    }
                });
                if (this.profile.isDefaultEvent(e)) return void this.publishUANetInteraction({
                    action: "DEFAULT",
                    publishState: {
                        viewModelPropertyName: this.activeSlider
                    }
                });
                this.configureStep(e), this.dragging = !0, this.publishUANetInteraction({
                    action: "START",
                    publishState: {
                        viewModelPropertyName: this.activeSlider
                    }
                });
                const n = this.createInteraction({
                    event: e
                });
                n.hasMoved && ("valueLow" === this.activeSlider ? (this.valueLow = this.discrete ? n.trackerState.value : Object(u.a)(n.trackerState.value, this.min, this.max), this.publishUANetInteraction({
                    action: "CHANGE",
                    publishState: {
                        viewModelPropertyName: "valueLow"
                    }
                })) : (this.valueHigh = this.discrete ? n.trackerState.value : Object(u.a)(n.trackerState.value, this.min, this.max), this.publishUANetInteraction({
                    action: "CHANGE",
                    publishState: {
                        viewModelPropertyName: "valueHigh"
                    }
                }))), window.addEventListener("mousemove", this.onMouseMove), window.addEventListener("mouseup", this.createMouseUp(this.activeSlider))
            }
            createMouseUp(e) {
                const t = n => {
                    0 == n.button && (this.configureStep(null), this.createInteraction({
                        event: n
                    }), this.publishUANetInteraction({
                        action: "END",
                        publishState: {
                            viewModelPropertyName: e
                        }
                    }), this.dragging = !1, window.removeEventListener("mouseup", t), window.removeEventListener("mousemove", this.onMouseMove))
                };
                return t
            }
            tryStartScroll(e) {
                this.scrolling || (this.scrolling = !0, this.publishUANetInteraction({
                    action: "START",
                    publishState: {
                        viewModelPropertyName: e
                    }
                }))
            }
            onCoverMouseWheel(e) {
                if (this.disabled || this.dragging) return;
                const t = e.clientX;
                this.updateActiveSlider(t), e.preventDefault(), this.onMouseWheel && this.onMouseWheel(e, this.activeSlider)
            }
            onMouseWheel(e, t) {
                if (e.preventDefault(), this.disabled || !this.writable) return;
                this.tryStartScroll(t);
                const n = "valueLow" === t ? this.$inputRangeLow : this.$inputRangeHigh,
                    i = this.createInteraction({
                        event: e
                    });
                if (i.hasMoved) {
                    let e = i.trackerState.value;
                    this.discrete || (e = Object(u.a)(e, this.min, this.max)), n.value = String(e), this[t] = e, this.publishUANetInteraction({
                        action: "CHANGE",
                        publishState: {
                            viewModelPropertyName: t
                        }
                    })
                }
                this.tryEndScroll(void 0, t)
            }
        };
        Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Boolean)], w.prototype, "writable", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Number)], w.prototype, "offset", void 0), Object(i.__decorate)([Object(r.bindable)({
            mode: r.BindingMode.twoWay
        }), Object(i.__metadata)("design:type", Object)], w.prototype, "valueLow", void 0), Object(i.__decorate)([Object(r.bindable)({
            mode: r.BindingMode.twoWay
        }), Object(i.__metadata)("design:type", Object)], w.prototype, "valueHigh", void 0), Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", String)], w.prototype, "valueType", void 0), w = Object(i.__decorate)([p.i ? Object(r.customElement)({
            name: "ua-slider-range",
            template: b
        }) : Object(r.customElement)(b), s.a, Object(i.__metadata)("design:paramtypes", [HTMLElement, l.a, v.a])], w)
    }).call(this, "/")
});
