// Extracted webpack module 72. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    (function(e) {
        n.d(t, "a", (function() {
            return v
        }));
        var i = n(0),
            r = n(1),
            s = n(26),
            o = n(21),
            a = n(12),
            c = n(13),
            l = n(89),
            u = n(3),
            h = n(4),
            d = n.n(h),
            p = n(8),
            f = n(45),
            g = n(9);
        let m = l;
        u.i && (m = d.a.readFileSync(d.a.resolve(e, "./ua-knob.html"), "utf-8"));
        let v = class extends p.b {
            constructor(e, t, n) {
                super(e, t, n), this.element = e, this.profile = t, this.uaScheduler = n, this.DEFAULT_TRACKER_STATE = f.a, this.options = null, this.initClassState(), this.disabled = !1, this.dragging = !1, this.scrolling = !1
            }
            hardwareAcceleratedChanged() {
                this.skin || super.hardwareAcceleratedChanged()
            }
            getHardwareAcceleratedDisplay() {
                return this.$display
            }
            binding() {
                this.updateIndex()
            }
            valueChanged() {
                this.updateIndex(), Object(a.d)(this.element)
            }
            configureFromUANet(e, t, n, i) {
                var r, s;
                const a = i.getRealValues({
                    paramName: t
                });
                this.states = Array.isArray(a) ? a.slice(0) : null, i.isDiscreteParam(t) ? (this.min = 0, this.max = i.numStepsParam(t) - 1, n.valueType = o.f.real, this.discrete = !0, this.value = null !== (r = i.getRealValue(t)) && void 0 !== r ? r : 0) : (this.min = 0, this.max = 1, n.valueType = o.f.normalized, this.discrete = !1, this.value = null !== (s = i.getNormalizedValue(t)) && void 0 !== s ? s : 0), this.updateIndex()
            }
            updateIndex() {
                let e = this.index;
                e = Array.isArray(this.states) && this.states.length > 0 ? this.profile.getIndexFromRealValue({
                    value: this.value,
                    states: this.states,
                    curIndex: this.index
                }) : this.value, -1 === e ? console.warn("index cannot be determined from real value ") : this.index = e
            }
            setUANetValue(e, t) {
                this.value = t
            }
            getUANetValue(e) {
                return this.value
            }
        };
        Object(i.__decorate)([r.bindable, Object(i.__metadata)("design:type", Object)], v.prototype, "options", void 0), v = Object(i.__decorate)([u.i ? Object(r.customElement)({
            name: "ua-knob",
            template: m
        }) : Object(r.customElement)(m), s.e, Object(i.__metadata)("design:paramtypes", [HTMLElement, c.a, g.a])], v)
    }).call(this, "/")
});
