// Extracted webpack module 40. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return l
    }));
    var i, r = n(0),
        s = n(6),
        o = n(1),
        a = n(5),
        c = n(14);
    ! function(e) {
        e[e.none = 0] = "none", e[e.net = 1] = "net"
    }(i || (i = {}));
    let l = class {
        constructor(e, t, n) {
            this.element = e, this.audioPlugin = t, this.isAttached = !1, this.automatorSubscriptions = {}, this.updateSource = i.none, this.seedStore = {}, this.automator = n.locateAutomatorFor(e, this)
        }
        attached() {
            this.isAttached = !0, this.valueChanged(this.value)
        }
        detached() {
            this.isAttached = !1, this.cleanupSeedStore()
        }
        valueChanged(e, t) {
            this.localValue !== e && this.isAttached && (this.localValue = e, "string" != typeof e ? this.cleanupSeedStore() : (this.tearDownSubscriptions({
                value: t
            }), this.setupSubscriptions({
                value: e
            }), this.injectIDAttribute()))
        }
        injectIDAttribute() {
            void 0 !== this.value && null !== this.value && this.element.setAttribute("ua-test-param-name", this.value)
        }
        setupSubscriptions(e) {
            const {
                value: t
            } = e;
            if ("string" != typeof t) return;
            const n = t.split(",").map(e => e.trim());
            if (1 === n.length) this.tryConnectToParam({
                componentViewModelProperty: a.a,
                id: n[0]
            });
            else
                for (let e = 0, t = n.length; e < t; ++e) {
                    const t = n[e].split("=>").map(e => e.trim());
                    this.tryConnectToParam({
                        componentViewModelProperty: t[0],
                        id: t[1],
                        isMultiParamRegistration: !0
                    })
                }
        }
        tearDownSubscriptions(e) {
            const {
                value: t
            } = e;
            if ("string" != typeof t) return;
            const n = t.split(",").map(e => e.trim());
            if (1 === n.length) this.cleanupCallbackListeners({
                id: n[0]
            });
            else
                for (let e = 0, t = n.length; e < t; ++e) {
                    const t = n[e].split("=>").map(e => e.trim());
                    this.cleanupCallbackListeners({
                        id: t[1]
                    })
                }
        }
        cleanupCallbackListeners(e) {
            const {
                id: t
            } = e;
            return !!this.seedStore[t] && (this.cleanupCallbackListener({
                id: t,
                type: "value"
            }), this.cleanupCallbackListener({
                id: t,
                type: "volatile"
            }), this.cleanupCallbackListener({
                id: t,
                type: "touchCount"
            }), delete this.seedStore[t], !!this.automatorSubscriptions[t] && (this.automatorSubscriptions[t].dispose(), delete this.automatorSubscriptions[t], !0))
        }
        cleanupCallbackListener({
            id: e,
            type: t
        }) {
            var n;
            if (!this.seedStore[e]) return !1;
            const i = null === (n = this.seedStore[e][t]) || void 0 === n ? void 0 : n.seed;
            return i && this.audioPlugin.unregisterCallbackListener({
                seed: i
            }), !0
        }
        cleanupSeedStore() {
            Object.keys(this.seedStore).forEach(e => this.cleanupCallbackListeners({
                id: e
            }))
        }
        tryConnectToParam({
            id: e,
            componentViewModelProperty: t,
            isMultiParamRegistration: n
        }) {
            const i = this.audioPlugin.checkInvalidProperty({
                selector: "controls",
                id: e,
                property: this.getAutomatorValueType()
            });
            i ? this.audioPlugin.isStoreValid && console.warn(`ua-param: cannot listen to parameter: ${e} because it is not in the UANET store. error: ${JSON.stringify(i)}`) : this.connectToParam({
                componentViewModelProperty: t,
                id: e,
                isMultiParamRegistration: n
            })
        }
        getDescriptorsFromSeed(e) {
            const {
                id: t
            } = e, n = this.seedStore[t], i = Object.keys(n.valueConfig.properties);
            return {
                selector: n.valueConfig.selector,
                id: t,
                property: i[0]
            }
        }
        handleInternalReconciliation({
            id: e,
            componentViewModelProperty: t,
            publishState: n
        }) {
            this.updatePublishState({
                id: e,
                publishState: n
            }), this.handleExternalReconciliation({
                id: e,
                componentViewModelProperty: t
            })
        }
        handleExternalReconciliation({
            id: e,
            componentViewModelProperty: t
        }) {
            const n = this.getDescriptorsFromSeed({
                    id: e
                }),
                i = this.audioPlugin.getStoreValue(n);
            this.updateComponent({
                componentViewModelProperty: t,
                value: i
            })
        }
        updatePublishState({
            id: e,
            publishState: t
        }) {
            const n = this.getDescriptorsFromSeed({
                    id: e
                }),
                i = this.audioPlugin.getStoreValue(n);
            null != t.value && (t.value = i)
        }
        handleInteraction(e) {
            var t, n;
            const {
                action: i,
                id: r,
                componentViewModelProperty: s,
                publishState: o
            } = e, a = c.l.getUANetConfig({
                element: this.element
            });
            switch (o.uaNet = a, i) {
                case "START":
                    this.audioPlugin.setTouch(r, !0);
                    const {
                        property: i
                    } = this.getDescriptorsFromSeed({
                        id: r
                    });
                    this.audioPlugin.setStoreCurrentTouchingProperty({
                        selector: "controls",
                        id: r,
                        property: i
                    }), (null === (t = null == a ? void 0 : a.reconciliation) || void 0 === t ? void 0 : t.START) && this.handleInternalReconciliation({
                        id: r,
                        componentViewModelProperty: s,
                        publishState: o
                    });
                    break;
                case "CHANGE":
                    if (null == o.value) {
                        console.warn("UAParamAttribute.handleInteraction: CHANGE action encountered an undefined newValue", e);
                        break
                    }
                    this.setParamValue(r, o.value);
                    break;
                case "END":
                    (null === (n = null == a ? void 0 : a.reconciliation) || void 0 === n ? void 0 : n.END) && this.handleInternalReconciliation({
                        id: r,
                        componentViewModelProperty: s,
                        publishState: o
                    }), this.audioPlugin.setTouch(r, !1);
                    break;
                case "DEFAULT":
                    this.tryDefaultValue(r);
                    break;
                case "REVERT":
                    this.tryRevertValue(r);
                    break;
                default:
                    console.warn("UAParamAttribute.handleInteraction: Unexpected Interaction action", e)
            }
        }
        getIsExternalTouching({
            id: e,
            type: t,
            isTouching: n,
            isLinkedComponent: i
        }) {
            const r = !!this.audioPlugin.getStoreTouching({
                    id: e
                }),
                {
                    bypassLinkedComponentLogic: s
                } = c.l.getUANetConfig({
                    element: this.element
                });
            return i && !n && r && !s
        }
        connectToParam({
            componentViewModelProperty: e,
            id: t,
            isMultiParamRegistration: n
        }) {
            let r = !1,
                s = !1,
                o = !1,
                a = !0,
                l = !1;
            this.automator.configure(e, t, this.audioPlugin), this.updateComponent({
                componentViewModelProperty: e,
                value: this.getParamValue(t)
            }), this.automator.subscribe || console.warn("ua-param: automator.subscribe is undefined"), this.automator.subscribe && (this.automatorSubscriptions[t] = this.automator.subscribe(e, {
                start: n => {
                    this.updateSource !== i.net && (r ? console.warn("ua-param-attribute, start(): Cannot send post set_touch true for an ongoing interaction", {
                        id: t,
                        publishState: n,
                        isTouching: r
                    }) : (r = !0, a = !1, l = !1, this.handleInteraction({
                        action: "START",
                        componentViewModelProperty: e,
                        id: t,
                        publishState: n
                    })))
                },
                change: n => {
                    this.updateSource !== i.net && (r ? (a = !1, this.handleInteraction({
                        action: "CHANGE",
                        componentViewModelProperty: e,
                        id: t,
                        publishState: n
                    })) : console.warn("ua-param-attribute, change(): Cannot send set for an ongoing interaction", {
                        id: t,
                        publishState: n,
                        isTouching: r
                    }))
                },
                end: n => {
                    this.updateSource !== i.net && (r ? (this.handleInteraction({
                        action: "END",
                        componentViewModelProperty: e,
                        id: t,
                        publishState: n
                    }), r = !1, l = !1) : console.warn("ua-param-attribute, end(): Cannot send post set_touch false for an interaction that is not running", {
                        id: t,
                        publishState: n,
                        isTouching: r
                    }))
                },
                revert: n => {
                    r = !1, s = !0, this.handleInteraction({
                        action: "REVERT",
                        componentViewModelProperty: e,
                        id: t,
                        publishState: n
                    }), s = !1, r = !1, a = !0, l = !1
                },
                default: n => {
                    r = !1, o = !0, this.handleInteraction({
                        action: "DEFAULT",
                        componentViewModelProperty: e,
                        id: t,
                        publishState: n
                    }), o = !1, r = !1, a = !0, l = !1
                }
            }));
            const u = t => {
                const n = this.getAutomatorValueType(),
                    i = {
                        selector: "controls",
                        id: t,
                        properties: {
                            [n]: {
                                allowTaggedUANET: ["set", "get"]
                            }
                        }
                    },
                    u = this.audioPlugin.registerCallbackListener(Object.assign(Object.assign({}, i), {
                        callback: i => {
                            var u, h, d, p;
                            const f = null === (u = i.values[n]) || void 0 === u ? void 0 : u.isShortCircuit,
                                g = "set" === (null === (d = null === (h = i.values[n]) || void 0 === h ? void 0 : h.message.parameters) || void 0 === d ? void 0 : d.cmd_id),
                                m = this.audioPlugin.getStoreCurrentTouchingProperty({
                                    id: t
                                }) === n;
                            if (l = this.getIsExternalTouching({
                                    id: t,
                                    type: n,
                                    isLinkedComponent: a,
                                    isTouching: r
                                }), l && !f && m || r && !f && !s && !o) return;
                            if (g) {
                                const e = c.l.getUANetConfig({
                                    element: this.element
                                });
                                if (!(null === (p = null == e ? void 0 : e.reconciliation) || void 0 === p ? void 0 : p.END)) return
                            }
                            const {
                                value: v,
                                property: b
                            } = i.events[i.events.length - 1];
                            b === n ? this.updateComponent({
                                componentViewModelProperty: e,
                                value: v
                            }) : console.warn(`ua-param: listener fired upon a different property than requested.\n            requested: ${n}, listener property: ${b}`)
                        }
                    }));
                return u.error ? (console.warn(`ua-param: encountered an error registering a listener for parameter: ${t} and value type: ${n}.\n        error object: ${JSON.stringify(u.error)}`), !1) : (this.seedStore[t] || (this.seedStore[t] = {}), this.seedStore[t].value = u, this.seedStore[t].valueConfig = i, !0)
            };
            if (!u(t) || !(t => {
                    const n = {
                            selector: "controls",
                            id: t,
                            properties: {
                                real_values: {}
                            }
                        },
                        i = this.audioPlugin.registerCallbackListener({
                            selector: "controls",
                            id: t,
                            properties: {
                                real_values: {}
                            },
                            callback: () => (this.automator.configure(e, t, this.audioPlugin), this.seedStore[t] ? this.seedStore[t].value.seed ? void(this.getAutomatorValueType() in this.seedStore[t].valueConfig.properties || (this.cleanupCallbackListener({
                                id: t,
                                type: "value"
                            }), u(t) || (console.warn(`ua-param: could not register a new listener for parameter: ${t} after a real_values change`), this.cleanupCallbackListeners({
                                id: t
                            })))) : (console.warn(`ua-param: value seed was not registered correctly for parameter: ${t}.\n            registration object: ${JSON.stringify(this.seedStore[t])}`), void this.cleanupCallbackListeners({
                                id: t
                            })) : (console.warn(`ua-param: missing entry in the seed store for ${t}.\n            seed store: ${JSON.stringify(this.seedStore)}`), void this.cleanupCallbackListeners({
                                id: t
                            })))
                        });
                    return i.error ? (console.warn(`ua-param: encountered an error registering a listener for volatile parameter: ${t}.\n        error object: ${JSON.stringify(i.error)}`), !1) : (this.seedStore[t].volatile = i, this.seedStore[t].volatileConfig = n, !0)
                })(t) || !this.seedStore[t]) return console.warn(`ua-param: failed to connect to param or did not find a registration in the seed store for ${t}.\n      seed store: ${JSON.stringify(this.seedStore)}`), void this.cleanupCallbackListeners({
                id: t
            });
            (t => {
                if (!n) {
                    const n = {
                            selector: "controls",
                            id: t,
                            properties: {
                                touch_count: {
                                    allowTaggedUANET: ["set", "get"]
                                }
                            }
                        },
                        i = this.audioPlugin.registerCallbackListener(Object.assign(Object.assign({}, n), {
                            callback: n => {
                                const i = n.values.touch_count.value,
                                    r = !!this.audioPlugin.getStoreTouching({
                                        id: t
                                    });
                                0 === i && (l && a && !r && (this.handleExternalReconciliation({
                                    id: t,
                                    componentViewModelProperty: e
                                }), l = !1), a = !0)
                            }
                        }));
                    return i.error ? (console.warn(`ua-param: encountered an error registering touch count listener for parameter: ${t}.\n          error object: ${JSON.stringify(i.error)}`), !0) : (this.seedStore[t].touchCount = i, this.seedStore[t].touchCountConfig = n, !0)
                }
            })(t)
        }
        getAutomatorValueType() {
            let e = "normalized_value";
            switch (this.automator.valueType) {
                case a.c.string:
                    e = s.kStringValue;
                    break;
                case a.c.real:
                    e = s.kRealValue;
                    break;
                case a.c.normalized:
                    e = s.kNormalizedValue;
                    break;
                default:
                    console.warn(`ua-param: unexpected value type in automator: ${this.automator.valueType}. defaulting to ${e}`)
            }
            return e
        }
        tryRevertValue(e) {
            switch (this.automator.valueType) {
                case a.c.normalized:
                    this.audioPlugin.tryRevertNormalizedValue(e);
                    break;
                case a.c.string:
                    this.audioPlugin.tryRevertStringValue(e);
                    break;
                case a.c.real:
                    this.audioPlugin.tryRevertRealValue(e)
            }
        }
        tryDefaultValue(e) {
            switch (this.automator.valueType) {
                case a.c.normalized:
                    this.audioPlugin.tryDefaultNormalizedValue(e);
                    break;
                case a.c.string:
                    this.audioPlugin.tryDefaultStringValue(e);
                    break;
                case a.c.real:
                    this.audioPlugin.tryDefaultRealValue(e)
            }
        }
        setParamValue(e, t) {
            switch (this.automator.valueType) {
                case a.c.normalized:
                    this.audioPlugin.setNormalizedValue(e, t);
                    break;
                case a.c.string:
                    this.audioPlugin.setStringValue(e, t);
                    break;
                case a.c.real:
                    this.audioPlugin.setRealValue(e, t);
                    break;
                default:
                    console.warn("setParamValue: unexpected value type " + this.automator.valueType)
            }
        }
        getParamValue(e) {
            switch (this.automator.valueType) {
                case a.c.normalized:
                    return this.audioPlugin.getNormalizedValue(e);
                case a.c.string:
                    return this.audioPlugin.getStringValue(e);
                case a.c.real:
                    return this.audioPlugin.getRealValue(e);
                case a.c.name:
                    return this.audioPlugin.getNameValue(e);
                default:
                    console.warn("getParamValue: unexpected valueType " + this.automator.valueType)
            }
        }
        updateComponent(e) {
            const {
                componentViewModelProperty: t,
                value: n
            } = e;
            this.updateSource === i.none && (this.updateSource = i.net, this.automator.setValue(t, n), this.updateSource = i.none)
        }
    };
    Object(r.__decorate)([o.bindable, Object(r.__metadata)("design:type", Object)], l.prototype, "value", void 0), l = Object(r.__decorate)([Object(o.customAttribute)("ua-param"), Object(r.__metadata)("design:paramtypes", [HTMLElement, s.AudioPlugin, a.b])], l)
});
