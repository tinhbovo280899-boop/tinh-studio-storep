// Extracted webpack module 23. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    var i;
    n.d(t, "a", (function() {
            return i
        })),
        function(e) {
            e.normal = "normal", e.reverse = "reverse"
        }(i || (i = {}))
});
