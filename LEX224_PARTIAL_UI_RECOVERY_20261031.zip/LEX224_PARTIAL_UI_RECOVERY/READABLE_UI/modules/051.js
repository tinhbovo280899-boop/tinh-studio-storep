// Extracted webpack module 51. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    var i = n(2),
        r = n(24),
        s = n(48),
        o = n(14);

    function a(e) {
        return `\n  <div style="position: relative; width: 100%; height: 100%">\n    ${e.shadow?c(e.shadow.frameSize||e.frameSize,e.frameCount,e.imageName,e.frameThreshold,"_S",e.shadow.width||e.width,e.shadow.left||e.left,e.shadow.top||e.top,e.direction,e.packing):""}\n    ${c(e.frameSize,e.frameCount,e.imageName,e.frameThreshold,void 0,e.width,e.left,e.top,e.direction,e.packing,e.hoverImageName)}\n  </div>\n  `
    }

    function c(e, t, n, i, r, s, o, a, c, l, u) {
        return `\n  <ua-film-strip\n    net.bind="$uanet"\n    hardware-accelerated.bind="hardwareAccelerated"\n    frame-size="${e}"\n    frame-count="${t}"\n    ${n?'image-name="'+n+'"':""}\n    position-normalized.bind="value | switchValueConverter:$this"\n    labels.bind="states"\n    ${r?'suffix="'+r+'"':""}\n    ${c?'direction="'+c+'"':""}\n    ${l?'packing="'+l+'"':""}\n    ${u?'hover-image-name="'+u+'" hover-on="parent-previous"':""}\n    style="position:absolute; top: ${a||"0px"}; left: ${o||"0px"}; width: ${s||"100%"}">\n  </ua-film-strip>\n  `
    }
    var l = n(20);

    function u(e) {
        return `\n    <ua-film-strip\n      class="display"\n      net.bind="$uanet"\n      hardware-accelerated.bind="hardwareAccelerated"\n      frame-size.bind="${e.frameSize}"\n      frame-count.bind="${e.frameCount}"\n      frame-map.bind="skinOptions.frameMap"\n      ${e.imageName?'image-name="'+e.imageName+'"':""}\n      position-normalized.bind="index* (1 / (max - min))"\n      ${e.direction?'direction="'+e.direction+'"':""}\n      ${e.packing?'packing="'+e.packing+'"':""}\n      ${e.hoverImageName?'hover-image-name="'+e.hoverImageName+'" hover-on="parent"':""}\n      style="top: ${e.top}; left: ${e.left}; width: ${e.width}">\n    </ua-film-strip>\n  `
    }

    function h(e) {
        return `\n  <div class="display" style="position: absolute; width: ${e.width||"100%"}; height: 100%">\n    ${e.shadow?d(e.shadow.frameSize||e.frameSize,e.frameCount,e.imageName,"_S",e.shadow.width||e.width,e.shadow.left||e.left,e.shadow.top||e.top,e.direction,e.packing):""}\n    ${d(e.frameSize,e.frameCount,e.imageName,void 0,e.width,e.left,e.top,e.direction,e.packing,e.hoverImageName)}\n  </div>\n  `
    }

    function d(e, t, n, i, r, s, o, a, c, l) {
        return `\n  <ua-film-strip\n    net.bind="$uanet"\n    hardware-accelerated.bind="hardwareAccelerated"\n    frame-size="${e}"\n    frame-count="${t}"\n    ${n?'image-name="'+n+'"':""}\n    position.bind="value ? 1 : 0"\n    ${i?'suffix="'+i+'"':""}\n    ${a?'direction="'+a+'"':""}\n    ${c?'packing="'+c+'"':""}\n    ${l?'hover-image-name="'+l+'" hover-on="parent-next"':""}\n    style="position:absolute; top: ${o||"0px"}; left: ${s||"0px"}; width: ${r||"100%"}">\n  </ua-film-strip>\n  `
    }

    function p(e) {
        return `\n<div style="position: relative; pointer-events: none;">\n    ${e.shadow?f(e.shadow.frameSize||e.frameSize,e.frameCount,e.imageName,e.frameThreshold,"_S",e.shadow.width||e.width,e.shadow.left||e.left,e.shadow.top||e.top,e.direction,e.packing):""}\n    ${f(e.frameSize,e.frameCount,e.imageName,e.frameThreshold,void 0,e.width,e.left,e.top,e.direction,e.packing,e.hoverImageName)}\n  </div>\n  `
    }

    function f(e, t, n, i, r, s, o, a, c, l, u) {
        return `\n  <ua-film-strip\n    net.bind="$uanet"\n    hardware-accelerated.bind="hardwareAccelerated"\n    frame-size="${e}"\n    frame-count="${t}"\n    frame-map.bind="skinOptions.frameMap"\n    ${n?'image-name="'+n+'"':""}\n    position-normalized.bind="index * (1 / (max - min))" \n    ${r?'suffix="'+r+'"':""}\n    ${c?'direction="'+c+'"':""}\n    ${l?'packing="'+l+'"':""}\n    ${u?'hover-image-name="'+u+'" hover-on="parent-previous"':""}\n    style="position:absolute; top: ${a||"0px"}; left: ${o||"0px"}; width: ${s||"100%"}">\n  </ua-film-strip>\n  `
    }

    function g(e) {
        return `\n  <div style="position: relative; width: 100%; height: 100%">\n    ${e.shadow?m(e.shadow.frameSize||e.frameSize,e.frameCount,e.imageName,"_S",e.shadow.width||e.width,e.shadow.left||e.left,e.shadow.top||e.top,e.direction,e.packing):""}\n    ${m(e.frameSize,e.frameCount,e.imageName,void 0,e.width,e.left,e.top,e.direction,e.packing,e.hoverImageName)}\n  </div>\n  `
    }

    function m(e, t, n, i, r, s, o, a, c, l) {
        return `\n  <ua-film-strip\n    class="toggle" \n    net.bind="$uanet"\n    hardware-accelerated.bind="hardwareAccelerated"\n    frame-size="${e}"\n    frame-count="${t}"\n    ${n?'image-name="'+n+'"':""}\n    position.bind="state"\n    ${i?'suffix="'+i+'"':""}\n    ${a?'direction="'+a+'"':""}\n    ${c?'packing="'+c+'"':""}\n    ${l?'hover-image-name="'+l+'" hover-on="parent"':""}\n    style="position:absolute; top: ${o||"0px"}; left: ${s||"0px"}; width: ${r||"100%"}">\n  </ua-film-strip>\n  `
    }

    function v(e) {
        return `\n  <div class="container">\n    <ua-film-strip\n      net.bind="$uanet"\n      hardware-accelerated.bind="hardwareAccelerated"\n      frame-size="${e.frameSize}"\n      frame-count="${e.frameCount}"\n      frame-map.bind="skinOptions.frameMap" \n      ${e.imageName?'image-name="'+e.imageName+'"':""}\n      position-normalized.bind="state / ${e.frameCount-1}"\n      ${e.direction?'direction="'+e.direction+'"':""}\n      ${e.packing?'packing="'+e.packing+'"':""}\n      ${e.hoverImageName?'hover-image-name="'+e.hoverImageName+'" hover-on="parent"':""}\n      style="position:absolute; top: ${e.top||"0px"}; left: ${e.left||"0px"}; width: ${e.width||"100%"}">\n    </ua-film-strip>\n  </div>\n  `
    }
    n.d(t, "a", (function() {
        return k
    }));
    class b {
        constructor(e, t, n) {
            this.skinConfiguration = e, this.elementType = t, this.createImageSkin = n
        }
        imageSkin(e) {
            this.skinConfiguration.addSkin({
                name: e.name,
                elementType: this.elementType,
                template: this.createImageSkin(e),
                imageNames: Object(s.a)(e)
            })
        }
        customSkin(e) {
            this.skinConfiguration.addSkin(Object.assign({
                elementType: this.elementType
            }, e))
        }
    }
    class y {
        constructor(e) {
            this.manager = e
        }
        load(...e) {
            return this.loadAllResolutions(...e)
        }
        loadAllResolutions(...e) {
            return Promise.all(e.flatMap(e => this.manager.loadImageFromName(e)))
        }
    }
    class w {
        constructor(e) {
            this.manager = e
        }
        load(...e) {
            return Promise.all(e.map(e => this.manager.loadFontFromName(e)))
        }
        loadFromSystem(...e) {
            return Promise.all(e.map(e => this.manager.loadFontFromUrl(e, e)))
        }
    }
    class k {
        constructor(e, t) {
            this.skinManager = e, this.resourceManager = t, this.knob = new b(this, o.q, u), this.switch = new b(this, o.x, a), this.checkbox = new b(this, o.j, h), this.slider = new b(this, o.v, p), this.toggleButton = new b(this, o.z, g), this.button = new b(this, o.i, v), this.images = new y(t), this.fonts = new w(t)
        }
        static register(e) {
            e.register(i.j.singleton(k, this))
        }
        configureAndLoadResources() {
            return this.configure(), this.resourceManager.waitForAllReady()
        }
        configure() {}
        addSkin(e) {
            if (e.name) this.skinManager.addSkin(e.template, e.name, e.elementType);
            else {
                if (!e.elementType) throw new Error("Skins must have a name or a default type.");
                this.skinManager.setDefaultSkin(e.template, e.elementType)
            }
            e.imageNames && this.images.load(...e.imageNames)
        }
    }
    k.inject = [r.a, l.a]
});
