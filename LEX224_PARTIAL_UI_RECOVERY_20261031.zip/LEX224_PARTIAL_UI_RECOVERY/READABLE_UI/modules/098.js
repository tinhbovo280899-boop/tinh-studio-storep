// Extracted webpack module 98. Requires the original bundle runtime.
module.exports = (function(e, t, n) {
    "use strict";
    n.r(t);
    var i = n(1),
        r = n(2);
    n.d(t, "name", (function() {
        return s
    })), n.d(t, "template", (function() {
        return o
    })), n.d(t, "dependencies", (function() {
        return a
    })), n.d(t, "shadowOptions", (function() {
        return c
    })), n.d(t, "register", (function() {
        return u
    }));
    const s = "ua-button",
        o = '<template class="${disabled ? \'disabled\' : \'\'}">\n\n  \x3c!-- Container --\x3e\n  <div class="container">\n\n    \x3c!-- BG: HBGF-1335: Prevent implicit compositing by placing "static" click region underneath composited display --\x3e\n    \x3c!-- Click Region --\x3e\n    <div class="click-region"></div>\n\n    \x3c!-- Display (CSS or Skin) --\x3e\n    <div \n      class="display \n        ${(cssSkin === \'toggle\') ? \'toggle-skin\' : \'\'} \n        ${disabled ? \'disabled\' : \'\'}"\n      skin-site="value.bind: skin; type.bind: skinType"\n      ref="$display"\n    >\n      <div class="background state-${state}"></div>\n      <div class="indicator state-${state}">${(typeof text == "string") ? text : \'\'}</div>\n    </div>\n\n  </div>\n\n</template>\n';
    t.default = o;
    const a = [r.j.defer(".css", ":host {\n  /* Any CSS Properties set in the :host can be overriden by the consumer. */\n  /* The internal component operation should not depend on these in any way */\n  /* These are simply \"nice defaults\" to make it easier for the consumer */\n\n  display: inline-block; /* Best all around default. Allows the element to be displayed between text and other components without introducing a line-break */\n  height: 100%;\n  width: 100%;\n  pointer-events: none; /* Disable pointer-events on the host (and all child elements because pointer-events is inherited). */\n}\n\n:host(.disabled) {\n  opacity: var(--ua-disabled-opacity, 1.0);\n}\n\n\n/* This container 'protects' the component from the outside world by setting postion: relative */\n.container {\n  position: relative; /* Limit the scope of absolutely positioned child elements, so a child of the relatively positioned element can be absolutely positioned within that block. */\n  top: 0;\n  left: 0;\n  width: 100%;\n  height: 100%;\n}\n\n\n/* Display */\n.display {\n  position: absolute;\n  display: var(--ua-button-display, block);\n  height: 100%;\n  width: 100%;\n  border-radius: var(--ua-button-border-radius, var(--ua-button-radius, 0));\n  background: var(--ua-button-background, transparent);\n  box-shadow: var(--ua-button-box-shadow, none);\n  pointer-events: none;\n}\n\n.background {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  height: var(--ua-button-background-height, 100%);\n  width: var(--ua-button-background-width, 100%);\n  transform: translate(-50%, -50%);\n  background: var(--ua-button-background-background, transparent);\n  border-radius: var(--ua-button-radius, 0);\n  box-shadow: var(--ua-button-background-box-shadow, none);\n}\n\n.indicator {\n  position: absolute;\n  top: 50%;\n  left: 50%;\n  height: var(--ua-button-indicator-height, 100%);\n  width: var(--ua-button-indicator-width, 100%);\n  padding: var(--ua-button-indicator-padding, 0);\n  transform: translate(-50%, -50%);\n  background: var(--ua-button-indicator-background, transparent);\n  border-radius: var(--ua-button-radius, 0);\n  \n  font-size: var(--ua-button-font-size, 12px);\n  color: var(--ua-button-font-color, #000000);\n\n  display: -webkit-inline-box;\n  -webkit-box-pack: center;\n  -webkit-box-orient: vertical;\n  vertical-align: middle;\n  text-align: center;\n  \n}\n\n/* offPressed = 2, onPressed = 3 */\n.background.state-2, .background.state-3 {\n  height: var(--ua-button-background-height-pressed, inherit);\n  width: var(--ua-button-background-width-pressed, inherit); \n}\n\n/* offPressed = 2, onPressed = 3 */\n.indicator.state-2, .indicator.state-3 {\n  height: var(--ua-button-indicator-height-pressed, inherit);\n  width: var(--ua-button-indicator-width-pressed, inherit); \n}\n\n/* on = 1, onPressed = 3 */\n.indicator.state-1, .indicator.state-3 {\n  background: var(--ua-button-indicator-background-enabled, transparent);\n  box-shadow: var(--ua-button-indicator-background-box-shadow-enabled, none);\n  color: var(--ua-button-font-color-enabled, #ffffff);\n}\n\n\n/* Click Region */\n.click-region {\n  position: absolute;\n  top: var(--ua-button-click-region-top, 0px);\n  left: var(--ua-button-click-region-left, 0px);\n  height: var(--ua-button-click-region-height, 100%);\n  width: var(--ua-button-click-region-width, 100%);\n  border-radius: var(--ua-button-click-region-border-radius, var(--ua-button-border-radius, var(--ua-button-radius, 0)));\n  border: var(--ua-click-region-border, none); /* Used for displaying the click region */\n  outline: var(--ua-click-region-outline, none); /* Used for displaying the click region */\n  box-shadow: var(--ua-click-region-box-shadow, none); /* Used for displaying the click region */\n  background: var(--ua-click-region-background, none); /* Used for displaying the click region */\n  pointer-events: auto; /* Turn on pointer events */\n}\n\n\n\n\n/* FUTURE IMPLEMENTATION\n   The CSS below will recreate the default look of ua-checkbox, ua-toggle-button, ua-switch\n*/\n\n/* ua-toggle-button settings */\n.toggle-skin {\n  --ua-button-radius: 50%;\n  --ua-button-background: black;\n  --ua-button-box-shadow: 1px 1px 2px rgba(0, 0, 0, .5);\n  \n  --ua-button-background-height: 82%;\n  --ua-button-background-width: 82%;\n  --ua-button-background-background: radial-gradient(circle, rgba(33,33,33,1) 0%, rgba(65,57,57,1) 92%);\n  \n  --ua-button-indicator-height: 37%;\n  --ua-button-indicator-width: 37%;\n  --ua-button-indicator-background: rgb(90, 39, 39);\n\n  --ua-button-background-height-pressed: 75%;\n  --ua-button-background-width-pressed: 75%;\n  \n  --ua-button-indicator-height-pressed: 34%;\n  --ua-button-indicator-width-pressed: 34%;\n  \n  --ua-button-indicator-box-shadow: inset 0px 1px 2px rgba(255,255,255,0.25);\n  --ua-button-indicator-background-enabled: rgb(252, 56, 45);\n  --ua-button-indicator-background-box-shadow-enabled: 0px 0px 5px rgb(252, 56, 45);\n}\n\n\n\n")],
        c = {
            mode: "open"
        };
    let l;

    function u(e) {
        l || (l = i.CustomElement.define({
            name: s,
            template: o,
            dependencies: a,
            shadowOptions: c
        })), e.register(l)
    }
});
