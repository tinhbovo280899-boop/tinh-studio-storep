# Vocal Dynamics Bundle 1.0.1

Gói mã nguồn gồm **T-DeEsser** và **T-RVox**, dùng một bộ build/test và một bộ cài cho mỗi hệ điều hành. Trong DAW vẫn có hai VST3 riêng để đặt thứ tự theo vocal. Đã bỏ logo vẽ bằng mã và file TBrand khỏi giao diện; tên plugin hiển thị bằng văn bản thông thường, không nhúng ảnh/logo/font riêng. Các thông báo giấy phép của JUCE và thư viện đi kèm được giữ.

ZIP này chứa mã nguồn, JUCE 8.0.12, kiểm thử và script tạo bộ cài. **Chưa có VST3 Windows/macOS, EXE hoặc PKG đã biên dịch native.** Bản sửa đã được build/test trên Linux; chưa thử với vocal thật hoặc DAW của người dùng.

## Windows x64

Cần Visual Studio có Desktop development with C++, CMake 3.22+ và Inno Setup 6.3+ nếu muốn tạo bộ cài.

1. Giải nén ra một thư mục trên máy.
2. Chạy `1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat`.
3. Script build cả hai VST3, chạy đủ kiểm thử, rồi xuất `dist/windows/VST3` và tạo `Installers/TStudio_VocalDynamics_1.0.1_Windows_x64_Setup.exe`.

`2_CHI_BUILD_WINDOWS.bat` chỉ build/test/xuất VST3. Có thể chép hai thư mục `.vst3` vào thư mục VST3 hệ thống để dùng mà không cần Inno Setup. Log nằm ở `build/logs`.

## macOS Universal

Cần Xcode Command Line Tools và CMake 3.22+.

Chạy `1_BUILD_VA_TAO_BO_CAI_MAC.command` để build arm64+x86_64, kiểm thử, kiểm tra kiến trúc, ký ad-hoc và tạo một bộ cài `Installers/TStudio_VocalDynamics_1.0.1_macOS_universal.pkg` chứa cả hai VST3. `2_CHI_BUILD_MAC.command` chỉ build/test/xuất plugin vào `dist/mac-universal/VST3`.

Đây là ad-hoc signing; chưa có Developer ID/notarization. Script macOS và Inno Setup chưa được chạy native trong đợt sửa này.

## Thay đổi âm thanh cần biết

- **DeEsser:** Split chuyển sang FIR tuyến tính pha, hai nhánh cộng lại đúng bản sao có trễ khi không nén; stereo dùng detector riêng từng kênh rồi link. Không cắt đỉnh cố định ở ±1 trong đường de-ess. Monitor được chuẩn mức theo đáp ứng bộ lọc và chuyển đường êm. Tần số/Q/HP-BP đổi bằng hai bank crossfade có khởi tạo lịch sử. Đồ thị dùng đáp ứng bộ lọc thật, Detector hiển thị chuẩn mức.
- **RVox:** đường nén đổi thành soft knee 6 dB, ratio 4:1, đơn điệu; tâm ngưỡng thực bằng nút Comp trừ 6 dB để giữ cách nén vocal sớm. Limiter đo đỉnh bằng FIR 4 pha theo bảng hệ số tham chiếu ITU-R BS.1770-4, hold đủ cửa sổ và attack theo lookahead. Đặt đệm đỉnh nội bộ 0.96, khoảng -0.35 dB, để chừa sai số tái dựng/điều chế. Gain được làm mượt ở sau limiter.
- **Cả hai:** reset xóa DSP và dry delay; mẫu NaN/Inf được đổi về 0 trước xử lý; đầu vào hữu hạn cực lớn được giới hạn ở ±64 (khoảng +36 dBFS nội bộ). Lưu/khôi phục nhãn preset, kiểm tra đúng loại state, đọc tham số hữu hạn và không cấp phát C++ trong phép đo audio callback ổn định.

Tên, mã VST3, thứ tự/ID/range/default tham số và giá trị 14+8 factory preset được giữ. Âm thanh của preset có thể khác vì Split và đường nén cũ đã được sửa. State cũ không có metadata tên preset vẫn đọc parameter, UI hiện Custom. Không có tuyên bố tái tạo chính xác DSP hãng khác.

## Độ trễ để hát live

| Sample rate | T-DeEsser | T-RVox | Tổng khi nối cả hai |
| --- | ---: | ---: | ---: |
| 44.1 kHz | 59 mẫu | 59 mẫu | khoảng 2.68 ms |
| 48 kHz | 64 mẫu | 64 mẫu | khoảng 2.67 ms |
| 96 kHz | 128 mẫu | 128 mẫu | khoảng 2.67 ms |

DeEsser cũ báo 0 mẫu; phần FIR mới thêm khoảng 1.33 ms ở 48 kHz để giữ phân tần đúng pha. Host được báo latency mới, bypass được bù cùng số mẫu. Các số trên chưa gồm buffer soundcard/DAW và plugin khác.

## Kiểm chứng

5/5 nhóm CTest qua; cả hai VST3 được build và nạp bằng host Linux tối thiểu trong 12 trường hợp mono/stereo × 44.1/48/96 kHz. Bộ core qua AddressSanitizer/UndefinedBehaviorSanitizer. Phép đo độc lập 16× kiểm tra 135 trường hợp limiter và 24 trường hợp plugin/preset, gồm đầu/cuối tone có silence, đều dưới 0 dBFS tái dựng trong bộ thử.

Test gốc RVox giữ nguyên. Test gốc DeEsser chỉ đổi kỳ vọng latency từ 0 sang 64 mẫu tại 48 kHz; toàn bộ tiêu chí giảm âm xuýt/bảo toàn thân giọng giữ nguyên. Tại bài thử gốc: 7.5 kHz giảm khoảng 37 dB, 250 Hz chênh khoảng 0.01 dB. Không hạ tiêu chí giảm âm xuýt.

Xem `GHI_CHU_BAN_SUA.md`, `VALIDATION.txt`, `Validation/` và `SOURCE_SHA256SUMS.txt` để biết kết quả, phạm vi và checksum. JUCE đóng gói đủ module/build helpers để build không cần tải SDK từ mạng; demo applications và ví dụ không đi kèm.

## Build thủ công

```bash
cmake -S . -B build-manual -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build-manual --config Release --parallel 4
ctest --test-dir build-manual -C Release --output-on-failure
cmake --install build-manual --config Release --component Plugins --prefix dist/manual
```

Chỉ kiểm tra core không cần JUCE/platform GUI: thêm `-DTVD_CORE_ONLY=ON`. Build bình thường chạy cả test core lẫn các test ở cấp processor. Các phép đo Python 16× là tùy chọn và cần NumPy/SciPy, không phải phụ thuộc bắt buộc để build plugin.
