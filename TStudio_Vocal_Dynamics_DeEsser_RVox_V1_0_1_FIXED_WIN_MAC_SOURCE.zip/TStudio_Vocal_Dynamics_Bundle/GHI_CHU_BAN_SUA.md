# Bản sửa 1.0.1

Hai dự án được gom vào một gói build/bộ cài, vẫn là T-DeEsser và T-RVox riêng trong DAW. Chỉ bỏ phần nhận diện bằng hình vẽ trong header; giữ tên plugin, manufacturer code, product code, bundle ID và component/controller CIDs. Không chứa ảnh hoặc font nhúng riêng của sản phẩm. File TBrand.h và các hàm vẽ logo không còn trong gói.

## T-DeEsser

Phân tần allpass bậc 1 cũ để thành phần 7.5 kHz lọt qua nhánh low và không thể đạt tiêu chí >6 dB. Bản sửa dùng FIR Kaiser tuyến tính pha 129 taps ở 48 kHz, thay đổi số tap theo sample rate, trễ 64 mẫu. High là phần dư của input đã trễ trừ Low, nên hai nhánh cộng đúng bản sao có trễ khi gain bằng 1. Mẫu float vượt 1 vẫn được giữ trong headroom bình thường; không có hard clip ±1 ở cuối DeEsser.

Detector HP/BP bốn biquad vẫn giữ cấu trúc và tham số, nhưng có bank riêng cho L/R rồi lấy peak liên kết thay vì cộng L+R. Như vậy không triệt tiêu detector với tín hiệu ngược pha. Filter bank mới được prime từ lịch sử và crossfade 10 ms. FIR đổi tần số cũng crossfade 10 ms, không đổi latency khi đang phát.

Monitor dùng mức chuẩn hóa theo cộng hưởng bộ lọc, có delay phù hợp và crossfade. Chuyển Split/Wide được làm mượt. Đồ thị lấy đáp ứng số thực tế; đường Detector chuẩn mức riêng để nhìn đúng hình dạng Q.

Test cũ giữ nguyên tiêu chí giảm 7.5 kHz >6 dB và bảo toàn 250 Hz <1 dB. Chỉ đổi assert latency 0 →64 vì đường FIR mới. Kết quả tương ứng khoảng 37.0 dB và 0.01 dB.

## T-RVox

Đường rational cũ có vùng input tăng mà output giảm. Bản mới dùng soft knee 6 dB, ratio 4:1, tâm threshold=Comp-6 dB. Đây là phép ánh xạ đã định nghĩa rõ cho nút Comp; không phải tuyên bố thuật toán nguyên bản của một hãng. UI dùng cùng hàm transfer với DSP.

Các nhánh được gọi là allpass trong bản cũ không phải allpass có độ lớn phẳng, cũng không bắt được đỉnh giữa các mẫu trong bài thử 12 kHz. Bản sửa dùng bảng nội suy FIR 4 pha tham chiếu BS.1770-4 Annex 2. Đường gate/comp/makeup được làm mượt trước detector limiter, sau đó đưa vào delay. Sliding minimum giữ đủ cửa sổ lookahead+1 bằng deque, attack có thời hạn trước mẫu cần bảo vệ và release 35 ms. Không quét cách 4 mẫu như bản cũ. Gain ở sau limiter có ramp 20 ms để hạ trần không tạo bước nhảy tức thì.

Guard mẫu ±1 vẫn tồn tại để dự phòng. Counter trong test stress bằng 0, tức các ca thử không cần dựa vào guard này để giữ trần mẫu. Target detector 0.96 chừa khoảng 0.35 dB sai số. Phép đo độc lập 16× gồm 135 ca bộ limiter (cao nhất khoảng -0.070 dB) và 24 ca plugin/preset (cao nhất khoảng -0.325 dB) không vượt 0 dB trong bộ thử. Đây là phạm vi kiểm chứng, không phải chứng nhận BS.1770 hoặc cam kết cho mọi dạng sóng có thể có.

## Chung

- Cache pointer/range/default parameter ở khởi tạo; giá trị điều khiển không hữu hạn có fallback.
- Guard NaN/Inf trước analyser, bypass, filter và dynamics; headroom đầu vào hữu hạn được bảo vệ ở ±64.
- Reset không cấp phát, xóa delay/DSP/envelope và đồng bộ trạng thái bypass/meter.
- Bypass của host và nút trên giao diện dùng dry delay cùng latency và crossfade, DSP vẫn chạy để giữ trạng thái ấm.
- State chỉ nhận đúng loại STATE; kiểm tra giá trị parameter trước replaceState. Lưu metadata factoryPreset; legacy không có metadata hiện Custom thay vì tên sai. Tên/giá trị 14+8 preset không thay đổi.
- Shared NTUI/TKit/TProc và DSPTools ở common, tránh sửa lệch giữa hai plugin.
- Một CMake, một SDK JUCE, một script Windows/macOS; build và test xong mới stage/tạo bộ cài.

## Giới hạn kiểm tra

Đã build VST3 Linux Release và tải bằng host tối thiểu, không phải DAW thực. Chưa chạy MSVC/Xcode, ISCC/pkgbuild hoặc kiểm tra bộ cài native; Bash syntax và PowerShell grammar đã qua. Core C++ được ASAN/UBSAN, framework JUCE Release không được instrument toàn bộ. Chưa nghe A/B trên vocal của người dùng. Nén và Split thay đổi đáp ứng so với bản lỗi, nên các preset cũ có thể cho mức xử lý khác dù parameter được giữ.
