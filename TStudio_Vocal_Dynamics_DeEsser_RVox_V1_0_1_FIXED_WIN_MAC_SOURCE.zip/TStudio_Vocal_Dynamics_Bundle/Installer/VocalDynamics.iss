#ifndef BundleVersion
  #define BundleVersion "1.0.1"
#endif
#ifndef StageDir
  #define StageDir AddBackslash(SourcePath) + "..\dist\windows"
#endif

[Setup]
AppId={{718227D9-1C7C-478F-93CF-71CFC907A4C8}
AppName=T Studio Vocal Dynamics Bundle
AppVersion={#BundleVersion}
AppPublisher=T Studio
DefaultDirName={autopf}\T Studio\Vocal Dynamics Bundle
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\Installers
OutputBaseFilename=TStudio_VocalDynamics_{#BundleVersion}_Windows_x64_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UninstallDisplayName=T Studio Vocal Dynamics Bundle

[Files]
Source: "{#StageDir}\VST3\T-DeEsser.vst3\*"; DestDir: "{commoncf64}\VST3\T-DeEsser.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-RVox.vst3\*"; DestDir: "{commoncf64}\VST3\T-RVox.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\HUONG_DAN.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs

[Messages]
WelcomeLabel2=This installer installs both T Studio VST3 plugins. Close your DAW before continuing.
