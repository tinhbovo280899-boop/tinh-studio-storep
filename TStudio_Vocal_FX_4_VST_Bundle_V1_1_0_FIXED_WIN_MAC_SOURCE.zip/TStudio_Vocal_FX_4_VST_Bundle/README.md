# Vocal FX 4 VST Bundle 1.1.0

Một ZIP mã nguồn, một bộ build/test và một bộ cài cho mỗi hệ điều hành, gồm bốn VST3 riêng:

| Plugin trong DAW | Phiên bản | Vai trò |
| --- | --- | --- |
| T-DeEsser | 1.0.1 | Giảm âm xuýt |
| T-RVox | 1.0.1 | Gate, nén và giới hạn đỉnh |
| Sonitus fx Reverb | 3.0.1 | Early reflections và stereo reverb tank |
| D82 Sonic Maximizer | 2.4.1 | Chỉnh Low Contour, Process và Output |

DeEsser/RVox giữ nguyên mã nguồn xử lý của gói hai VST đã sửa. Hai plugin mới được sửa DSP/host/state; đã bỏ hoàn toàn các file ảnh nền, logo, núm và nút nhúng trong hai gói mới. Giao diện mới được vẽ bằng mã, hiển thị thông số trực tiếp; Reverb vẫn có A/B và sao chép setup. Không nhúng font/ảnh thương hiệu riêng.

**Đây là ZIP mã nguồn và script build/bộ cài, chưa chứa plugin Windows/macOS, EXE hay PKG đã biên dịch native.** Đã build/test bốn VST3 trên Linux. Chưa chạy native Windows/macOS hoặc nghe A/B bằng vocal thật.

## Build Windows x64

Cần CMake 3.22+, Visual Studio có Desktop development with C++, và Inno Setup 6.3+ nếu muốn tạo EXE.

- `1_BUILD_VA_TAO_BO_CAI_WINDOWS.bat`: build bốn plugin, chạy đủ test, xuất VST3 và tạo một bộ cài.
- `2_CHI_BUILD_WINDOWS.bat`: build/test/xuất VST3, không cần Inno Setup.
- Plugin: `dist/windows/VST3`.
- Bộ cài: `Installers/TStudio_VocalFX_4VST_1.1.0_Windows_x64_Setup.exe`.

## Build macOS Universal

Cần Xcode Command Line Tools và CMake 3.22+.

- `1_BUILD_VA_TAO_BO_CAI_MAC.command`: build arm64+x86_64, chạy test, kiểm tra kiến trúc, ký ad-hoc và tạo một PKG cho cả bốn plugin.
- `2_CHI_BUILD_MAC.command`: chỉ build/test/xuất VST3.
- Plugin: `dist/mac-universal/VST3`.
- Bộ cài: `Installers/TStudio_VocalFX_4VST_1.1.0_macOS_universal.pkg`.

Các script dừng nếu build/test thất bại. Log nằm trong `build/logs`. macOS dùng ad-hoc signing, chưa Developer ID/notarization. Các tool tạo EXE/PKG chưa chạy native trong môi trường kiểm tra này.

JUCE 8.0.12 đã đóng gói chung, chỉ gồm module/build helpers và giấy phép, không cần tải SDK từ mạng khi build. Có thể dùng cây JUCE riêng qua `T_JUCE_PATH`.

## Những phần đã sửa ở hai plugin mới

**Reverb:** sửa Low Cut từ phép triệt mức gần như toàn dải thành highpass đúng; sửa chiều Decay và phân bố gain cho bốn điểm hồi tiếp, có bù thời gian nhóm của allpass/filter. Crossover bass không còn gần như áp lên toàn dải. Delay có bộ nhớ/cursor cố định; thay Room/Predelay bằng crossfade các tap trong 30 ms. Các gain, mute và bypass được làm mượt, bypass vẫn duy trì tank. Sửa giới hạn tap theo đúng tank, predelay 0 ms, mono/mono→stereo, reset, báo tail, preset và lưu cả setup A/B.

**Sonic Maximizer:** giữ bộ lọc, bộ dò và phép trộn của nguồn cũ trong các ca chuẩn 44.1–192 kHz đã so sánh; bổ sung guard mẫu/parameter lỗi, làm mượt nút xoay và Process 20 ms, duy trì trạng thái khi bypass, meter theo tín hiệu ra, reset và metadata preset. Hệ số Chamberlin được giới hạn ở sample rate thấp để tránh bất ổn ở 8 kHz; đáp ứng ở miền đó không được coi là giống bản cũ vốn phát NaN.

Giữ tên plugin, VST3 manufacturer/product code, component/controller CID, ID/thứ tự/range/default parameter và 12+16 factory preset của hai dự án mới. Publisher hiển thị là T Studio; macOS bundle identifier được khai báo hợp lệ, rõ ràng. State cũ không có tên preset vẫn đọc tham số, giao diện có thể hiện Custom.

Reverb vẫn là một cấu trúc ER + stereo tank, không có các engine riêng cho Plate/Spring/Gated/Shimmer theo tên preset. Tên preset mô tả cách đặt thông số; không có pitch-shimmer hay gate mới được thêm. Sonic Maximizer giữ clipper của nguồn trước Output; Output dương có thể đưa mức ra trên 0 dBFS trong chuỗi float, nên đây không phải limiter đặt trần ở sau Output. Không có xác nhận tái tạo chính xác plugin thương mại của hãng.

## Dùng cho vocal/FX Send

Nếu dùng Reverb trên FX Send/AUX, bật **Mute Dry** để return chỉ còn ER và đuôi vang. Input, ER và Reverb vẫn có mức riêng. Gain và sắc thái wet sẽ khác nguồn cũ vì Low Cut/Decay đã sửa đúng chức năng.

Ở 48 kHz: DeEsser 64 mẫu, RVox 64 mẫu, Reverb và Sonic Maximizer báo 0 mẫu lookahead. Nối cả bốn cộng khoảng 2.67 ms latency khai báo, chưa gồm buffer soundcard/DAW và plugin khác. Predelay của reverb là thời gian hiệu ứng wet, không phải độ trễ đường dry.

## Kiểm chứng

- Build mới cả bốn VST3 Linux Release; **8/8 nhóm CTest qua**.
- 36 trường hợp native Linux VST3 ở 44.1/48/96 kHz: mono, stereo, thêm mono→stereo và stereo-duplicate cho hai plugin mới. Mono→stereo khớp checksum với đầu vào stereo nhân đôi.
- ASAN/UBSAN/float-cast-overflow cho core hai engine mới qua. Framework JUCE Release không được instrument toàn bộ.
- Reverb: Low Cut phân biệt dải thấp/cao, Decay tăng chiều dài đuôi theo đúng chiều trong phép thử, Room/Predelay đổi không cấp phát, reset và lỗi NaN/Inf được kiểm tra.
- Sonic Maximizer: 12 ca xử lý tĩnh 44.1/48/96/192 kHz × ba mức nút khớp nguồn đầu vào với sai khác float 0; kiểm tra ổn định 8–384 kHz, chuyển Process, bypass/meter và mẫu lỗi.
- Kiểm tra preset/state/A-B, reset, host bypass, và 0 cấp phát C++ quan sát được trong audio callback ổn định của hai plugin mới.
- Giao diện mới đã render và xem ảnh trên Linux; không phải xác nhận chạy trong DAW Windows/macOS.
- Script Bash và grammar PowerShell qua; kiểm tra guard PE x64 bằng fixture. Chưa chạy MSVC/Xcode/ISCC/pkgbuild native.

Bằng chứng của gói DeEsser/RVox cũ, gồm các phép đo peak 16×, được giữ riêng trong `Validation/DeEsser_RVox_1_0_1`. Mã DSP của hai plugin đó không đổi. Xem `GHI_CHU_BAN_SUA.md`, `VALIDATION.txt`, `Validation/compatibility.json` và `SOURCE_SHA256SUMS.txt`.

## Build thủ công

```bash
cmake -S . -B build-manual -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build-manual --config Release --parallel 4
ctest --test-dir build-manual -C Release --output-on-failure
cmake --install build-manual --config Release --component Plugins --prefix dist/manual
```

Thêm `-DTVD_CORE_ONLY=ON` nếu chỉ chạy kiểm tra core không cần JUCE/platform GUI. Normal build chạy cả core và host/state tests.
