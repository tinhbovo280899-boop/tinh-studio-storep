#!/bin/bash
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
/bin/bash "$ROOT/tools/mac.sh" all "arm64;x86_64"
result=$?
if [[ -t 0 ]]; then read -r -p "Press Return to close..."; fi
exit "$result"
