The supplied product sources and factory preset values were provided by the project owner.
JUCE 8.0.12 is bundled under its own commercial/open-source terms. See ThirdParty/JUCE/LICENSE.md (or LICENSE.txt) and the copyright notices inside its modules.
Only modules and build helpers are included; demo applications and example artwork are omitted.
Numeric interpolation coefficients are published reference data from ITU-R BS.1770-4 Annex 2. No third-party plugin artwork, fonts, or binary code is included.
