# Ghi chú gói bốn VST 1.1.0

Ngày 30/10/2026, theo giờ Bangkok. Bổ sung hai dự án người dùng gửi, gom cùng T-DeEsser và T-RVox đã sửa. Không dùng gói NT Studio Lite gửi nhầm trước đó.

## Sonitus fx Reverb 3.0.1

Phép thử nguồn cũ cho thấy Low Cut 100 Hz bị quy về gain gần như phẳng khoảng 0.00650 (-43.74 dB), vì trạng thái trong công thức lọc bị trộn sai. Bản sửa dùng highpass bilinear đúng, kiểm tra tone thấp 80 Hz và cao 4 kHz để xác nhận chức năng lọc. High Cut và damping giữ kiểu lọc một cực.

Công thức Decay cũ làm hệ số hồi tiếp tiến sát 1 khi đặt thời gian rất ngắn và nhỏ lại khi đặt thời gian dài. Bản sửa phân bố suy hao đều ở bốn vị trí của một vòng stereo, dùng log(0.001) theo thời gian vòng có bù group delay của allpass/filter. Mỗi vị trí có shelf low/high với gain nhỏ hơn 1; Bass Multiplier điều chỉnh suy hao bass mà không tạo hệ số khuếch đại hồi tiếp lớn hơn 1. Đây là hiệu chỉnh của dự án, không phải xác nhận thuật toán hãng. Tail được host báo theo ước lượng RT90 bảo thủ từ Decay/Bass, Predelay và thời gian mạng; không còn cố định 3 giây.

Bộ nhớ delay và cursor không đổi kích thước/vị trí khi tự động hóa. Room và Predelay crossfade tap đọc trong 30 ms; các hệ số/gain, mute và bypass được làm mượt. Giữ đuôi khi bypass bằng cách tiếp tục chạy engine. Sửa giới hạn tap theo đúng tank được đọc và cho phép predelay 0 ms. Không thêm latency đường dry.

Wrapper đọc đúng mono input trước khi tạo hai kênh ra, downmix khi output mono, thêm reset, guard mẫu/điều khiển lỗi, lưu nhãn preset và cả hai snapshot A/B. A/B/save/load dùng khóa ngoài audio processing; audio callback chỉ đọc parameter atomics, xử lý DSP và cập nhật meter.

Giữ 12 preset và các bảng delay từ đầu vào. Tên Plate, Spring, Gated hoặc Shimmer là tên preset trong cùng một cấu trúc ER + tank; không thêm các engine hay pitch-shimmer/gate riêng.

## D82 Sonic Maximizer 2.4.1

Giữ bộ lọc, envelope, ba-band recombination và clipper của nguồn cũ ở miền sample rate thông thường. So sánh 12 ca tĩnh tại 44.1/48/96/192 kHz với ba mức nút cho sai khác float bằng 0 trong bài thử. Test tham chiếu là mã người dùng gửi, không phải đo plugin hãng.

Nguồn cũ phát mẫu không hữu hạn ở 8 kHz trong phép thử tone. Hệ số Chamberlin mới được giới hạn an toàn ở sample rate thấp; các rate thông thường trong bài so sánh không bị thay hệ số. Thêm finite guard cho sample rate, input và setter điều khiển.

Nút xoay và Process có ramp 20 ms. Khi Process Off hoặc host bypass, engine vẫn cập nhật để không giữ trạng thái cũ; output chuyển về dry, meter theo output thật. Thêm reset và lưu nhãn preset. Giữ bốn parameter, 16 factory preset và cách bỏ qua Output khi Process Off. Clipper vẫn nằm trước Output; Output dương có thể đưa mức ra trên 0 dBFS float.

## Giao diện và tương thích

Đã bỏ các file SonitusGuiAssets/D82GuiAssets, ảnh nền/logo/filmstrip/nút nhúng. Hai UI mới dùng chung LookAndFeel vẽ bằng mã, đầy đủ parameter trực tiếp, preset selector, meter; Reverb có A/B/copy/default. Các nút/đồ thị giao diện bitmap cũ được thay bằng điều khiển trực tiếp. Không có ảnh/font nhúng riêng trong nguồn sản phẩm.

Publisher mới ghi T Studio; khai báo macOS bundle identifier hợp lệ com.tstudio.sonitusfxreverb và com.tstudio.d82sonicmaximizer. Tên VST3/file, manufacturer/product code cũ, component/controller CID, parameter layout và factory arrays của hai plugin mới được giữ. Native CID được kiểm tra theo tuple manufacturer/product của nguồn. Không đổi cấu trúc bypass parameter của JUCE để tránh remap ID host.

T-DeEsser, T-RVox và các file common DSP/UI gốc của gói 1.0.1 giữ nguyên byte. Chi tiết bản sửa đó: docs/DEESSER_RVOX_1_0_1.md. Bằng chứng cũ được phân riêng trong Validation/DeEsser_RVox_1_0_1.

## Phạm vi xác minh

8/8 nhóm CTest, 36 native Linux VST3 cases, core mới qua ASAN/UBSAN/float-cast-overflow. Hai UI mới đã render ảnh và kiểm tra trên Linux. Script Bash/PowerShell qua kiểm tra cú pháp; guard xuất PE AMD64 đã được thử bằng fixture. Build/stage bốn plugin Linux thành công.

Chưa chạy native Windows/MSVC, macOS/Xcode, Inno Setup hoặc pkgbuild; chưa có EXE/PKG native trong ZIP. Chưa có vocal hoặc DAW thật để nghe A/B. Không khẳng định khớp hãng hay đã loại mọi nguyên nhân tiếng nổ từ soundcard/host/chuỗi plugin.
