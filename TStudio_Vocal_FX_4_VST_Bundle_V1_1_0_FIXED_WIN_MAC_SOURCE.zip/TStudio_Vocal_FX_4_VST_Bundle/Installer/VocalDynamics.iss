#ifndef BundleVersion
  #define BundleVersion "1.1.0"
#endif
#ifndef StageDir
  #define StageDir AddBackslash(SourcePath) + "..\dist\windows"
#endif

[Setup]
AppId={{7799B33C-776B-46C8-91D8-D2C7527C2D03}
AppName=T Studio Vocal FX 4 VST Bundle
AppVersion={#BundleVersion}
AppPublisher=T Studio
DefaultDirName={autopf}\T Studio\Vocal FX 4 VST Bundle
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
OutputDir=..\Installers
OutputBaseFilename=TStudio_VocalFX_4VST_{#BundleVersion}_Windows_x64_Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
CloseApplications=yes
RestartApplications=no
UninstallDisplayName=T Studio Vocal FX 4 VST Bundle

[Files]
Source: "{#StageDir}\VST3\T-DeEsser.vst3\*"; DestDir: "{commoncf64}\VST3\T-DeEsser.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\T-RVox.vst3\*"; DestDir: "{commoncf64}\VST3\T-RVox.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\Sonitus fx Reverb.vst3\*"; DestDir: "{commoncf64}\VST3\Sonitus fx Reverb.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#StageDir}\VST3\D82 Sonic Maximizer.vst3\*"; DestDir: "{commoncf64}\VST3\D82 Sonic Maximizer.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "..\HUONG_DAN.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "..\Licenses\*"; DestDir: "{app}\Licenses"; Flags: ignoreversion recursesubdirs createallsubdirs

[Messages]
WelcomeLabel2=This installer installs all four T Studio VST3 plugins. Close your DAW before continuing.
