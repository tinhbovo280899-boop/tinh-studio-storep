#include "PluginProcessor.h"
#include "HwEditor.h"
#include "PluginEditor.h"

// One source, four plugins: TMOD_UNIT selects the unit that was a mode of the old T-CLA-2A
// (0 = T-Mod, 1 = T-Opto, 2 = T-Compander, 3 = T-TapeFlanger). Parameter IDs are unchanged.
#ifndef TMOD_UNIT
 #error "TMOD_UNIT must be defined (0..3)"
#endif

juce::AudioProcessorValueTreeState::ParameterLayout ModSuiteAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> p;

#if TMOD_UNIT == 0
    p.push_back(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"KAL_EN_1", 1}, "Effect 1 On", true));
    p.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"KAL_TYPE_1", 1}, "Effect 1 Type",
        juce::StringArray{"Phaser", "Flanger", "Chorus", "Tremolo"}, 0));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_SPEED_1", 1}, "Effect 1 Speed (Hz)",
        juce::NormalisableRange<float>(0.02f, 15.0f, 0.01f, 0.4f), 0.45f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_RES_1", 1}, "Effect 1 Resonance",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 55.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_WIDTH_1", 1}, "Effect 1 Width",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 75.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_MIX_1", 1}, "Effect 1 Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 85.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_DEPTH_1", 1}, "Effect 1 Depth",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 72.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_HPF_1", 1}, "Effect 1 HPF (Hz)",
        juce::NormalisableRange<float>(10.0f, 1000.0f, 1.0f, 0.4f), 20.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_LPF_1", 1}, "Effect 1 LPF (Hz)",
        juce::NormalisableRange<float>(1000.0f, 22000.0f, 10.0f, 0.4f), 18000.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_SENS_1", 1}, "Trigger 1 Sensitivity",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 35.0f));

    p.push_back(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"KAL_EN_2", 1}, "Effect 2 On", true));
    p.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"KAL_TYPE_2", 1}, "Effect 2 Type",
        juce::StringArray{"Phaser", "Flanger", "Chorus", "Tremolo"}, 2));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_SPEED_2", 1}, "Effect 2 Speed (Hz)",
        juce::NormalisableRange<float>(0.02f, 15.0f, 0.01f, 0.4f), 0.85f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_RES_2", 1}, "Effect 2 Resonance",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 40.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_WIDTH_2", 1}, "Effect 2 Width",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 90.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_MIX_2", 1}, "Effect 2 Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 65.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_DEPTH_2", 1}, "Effect 2 Depth",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 60.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_HPF_2", 1}, "Effect 2 HPF (Hz)",
        juce::NormalisableRange<float>(10.0f, 1000.0f, 1.0f, 0.4f), 40.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_LPF_2", 1}, "Effect 2 LPF (Hz)",
        juce::NormalisableRange<float>(1000.0f, 22000.0f, 10.0f, 0.4f), 16000.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_SENS_2", 1}, "Trigger 2 Sensitivity",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 30.0f));

    p.push_back(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"KAL_PARALLEL", 1}, "Cascade Parallel Mode", false));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_DRIVE", 1}, "Analog Drive",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 15.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_IN_GAIN", 1}, "Input Gain (dB)",
        juce::NormalisableRange<float>(-24.0f, 18.0f, 0.1f), 0.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"KAL_OUT_GAIN", 1}, "Output Gain (dB)",
        juce::NormalisableRange<float>(-24.0f, 18.0f, 0.1f), 0.0f));
#endif

#if TMOD_UNIT == 1
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"CLA_PEAK_RED", 1}, "Opto Peak Reduction",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 46.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"CLA_GAIN", 1}, "Opto Makeup Gain",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 40.0f));
    p.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"CLA_LIMITER", 1}, "Opto Comp/Limiter", false));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"CLA_HIFREQ", 1}, "Opto HiFreq Contour",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f));
    p.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"CLA_VU_MODE", 1}, "Opto VU Display",
        juce::StringArray{"Input", "Gain Reduction", "Output"}, 1));
    p.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID{"CLA_ANALOG", 1}, "Opto Analog Hum",
        juce::StringArray{"Off", "50 Hz", "60 Hz"}, 2));
#endif

#if TMOD_UNIT == 2
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_THRESH", 1}, "Compander Threshold (dB)",
        juce::NormalisableRange<float>(-60.0f, 0.0f, 0.1f), -18.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_RATIO", 1}, "Compander Ratio",
        juce::NormalisableRange<float>(0.5f, 50.0f, 0.1f, 0.4f), 3.5f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_ATTACK", 1}, "Compander Attack (ms)",
        juce::NormalisableRange<float>(0.1f, 200.0f, 0.1f, 0.4f), 12.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_RELEASE", 1}, "Compander Release (ms)",
        juce::NormalisableRange<float>(5.0f, 2000.0f, 1.0f, 0.4f), 180.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_MAKEUP", 1}, "Compander Makeup Gain (dB)",
        juce::NormalisableRange<float>(-20.0f, 24.0f, 0.1f), 3.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_GATE_OPEN", 1}, "Compander Gate Open (dB)",
        juce::NormalisableRange<float>(-80.0f, 0.0f, 0.1f), -48.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_FLT_FREQ", 1}, "Compander Filter Freq (Hz)",
        juce::NormalisableRange<float>(20.0f, 20000.0f, 1.0f, 0.35f), 2400.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"C1_FLT_Q", 1}, "Compander Filter Q",
        juce::NormalisableRange<float>(0.1f, 0.6f, 0.01f), 0.35f));
#endif

#if TMOD_UNIT == 3
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"MF_MIX", 1}, "Tape Flanger Mix (%)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 50.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"MF_FEEDBACK", 1}, "Tape Flanger Feedback (%)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 55.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"MF_DELAY", 1}, "Tape Flanger Delay (ms)",
        juce::NormalisableRange<float>(0.1f, 50.0f, 0.05f, 0.4f), 3.2f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"MF_RATE", 1}, "Tape Flanger Rate (Hz)",
        juce::NormalisableRange<float>(0.01f, 20.0f, 0.01f, 0.35f), 0.40f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"MF_DEPTH", 1}, "Tape Flanger Depth (%)",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 80.0f));
    p.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID{"MF_STEREO", 1}, "Tape Flanger Stereo (deg)",
        juce::NormalisableRange<float>(0.0f, 180.0f, 1.0f), 90.0f));
    p.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID{"MF_TAPE", 1}, "Tape Flanger Tape Mode", true));
#endif

    return { p.begin(), p.end() };
}

ModSuiteAudioProcessor::ModSuiteAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "KaleidoscopesState", createParameterLayout())
{
    initFactoryPresets();
}

ModSuiteAudioProcessor::~ModSuiteAudioProcessor() = default;

void ModSuiteAudioProcessor::initFactoryPresets()
{
    presets = {
        { "T-CLA-2A: Vintage Dual Phaser + Chorus", 0, 0, 0.42f, 75.0f, 60.0f, 80.0f, 85.0f, 2, 0.88f, 65.0f, 35.0f, 95.0f, 70.0f, 0, 18.0f, 0.0f, 0.0f, 46.0f, 40.0f, 0, 100.0f, -18.0f, 3.5f, -48.0f, 2400.0f, 50.0f, 55.0f, 3.2f, 0.4f, 80.0f },
        { "T-CLA-2A: Jet Tape Flanger Cascade",     0, 1, 0.25f, 88.0f, 78.0f, 90.0f, 90.0f, 0, 0.65f, 55.0f, 50.0f, 70.0f, 60.0f, 0, 32.0f, 0.0f, 0.0f, 46.0f, 40.0f, 0, 100.0f, -18.0f, 3.5f, -48.0f, 2400.0f, 50.0f, 55.0f, 3.2f, 0.4f, 80.0f },
        { "T-CLA-2A: Parallel Stereo Trem-Chorus",  0, 3, 3.60f, 72.0f, 20.0f, 90.0f, 85.0f, 2, 0.55f, 80.0f, 40.0f, 100.0f, 85.0f, 1, 24.0f, 0.0f, 0.0f, 46.0f, 40.0f, 0, 100.0f, -18.0f, 3.5f, -48.0f, 2400.0f, 50.0f, 55.0f, 3.2f, 0.4f, 80.0f },
        { "Opto: Start Me Up (Lead Vocal Opto)",       1, 0, 0.42f, 75.0f, 60.0f, 80.0f, 85.0f, 2, 0.88f, 65.0f, 35.0f, 95.0f, 70.0f, 0, 15.0f, 0.0f, 0.0f, 52.0f, 42.0f, 0, 78.0f, -18.0f, 3.5f, -48.0f, 2400.0f, 50.0f, 55.0f, 3.2f, 0.4f, 80.0f },
        { "Opto: Warm Bass Optical Limiter",           1, 0, 0.42f, 75.0f, 60.0f, 80.0f, 85.0f, 2, 0.88f, 65.0f, 35.0f, 95.0f, 70.0f, 0, 15.0f, 0.0f, 0.0f, 64.0f, 45.0f, 1, 100.0f, -18.0f, 3.5f, -48.0f, 2400.0f, 50.0f, 55.0f, 3.2f, 0.4f, 80.0f },
        { "Compander: Studio Vocal Comp + De-Esser",  2, 0, 0.42f, 75.0f, 60.0f, 80.0f, 85.0f, 2, 0.88f, 65.0f, 35.0f, 95.0f, 70.0f, 0, 15.0f, 0.0f, 0.0f, 46.0f, 40.0f, 0, 100.0f, -21.0f, 4.2f, -46.0f, 5600.0f, 50.0f, 55.0f, 3.2f, 0.4f, 80.0f },
        { "Tape Flanger: Thru The Null Tape Flange",      3, 0, 0.42f, 75.0f, 60.0f, 80.0f, 85.0f, 2, 0.88f, 65.0f, 35.0f, 95.0f, 70.0f, 0, 15.0f, 0.0f, 0.0f, 46.0f, 40.0f, 0, 100.0f, -18.0f, 3.5f, -48.0f, 2400.0f, 55.0f, 72.0f, 1.8f, 0.28f, 85.0f }
    };
    // Keep only this unit's presets, without the old "T-CLA-2A:" / "Opto:" style prefixes.
    std::vector<FactoryPreset> mine;
    for (auto pr : presets)
        if (pr.modelMode == TMOD_UNIT)
        {
            const int colon = pr.name.indexOfChar (':');
            if (colon > 0) pr.name = pr.name.substring (colon + 1).trim();
            mine.push_back (pr);
        }
    presets = std::move (mine);
}

void ModSuiteAudioProcessor::loadFactoryPreset(int index)
{
    if (index < 0 || index >= static_cast<int>(presets.size()))
        return;
    currentPresetIndex.store (index, std::memory_order_relaxed);
    const auto& pr = presets[static_cast<size_t>(index)];

    auto setP = [this](const char* id, float realVal) {
        if (auto* param = apvts.getParameter(id))
            param->setValueNotifyingHost(param->convertTo0to1(realVal));
    };

    setP("KAL_TYPE_1", pr.eff1Type);
    setP("KAL_SPEED_1", pr.eff1Speed);
    setP("KAL_DEPTH_1", pr.eff1Depth);
    setP("KAL_RES_1", pr.eff1Res);
    setP("KAL_WIDTH_1", pr.eff1Width);
    setP("KAL_MIX_1", pr.eff1Mix);
    setP("KAL_TYPE_2", pr.eff2Type);
    setP("KAL_SPEED_2", pr.eff2Speed);
    setP("KAL_DEPTH_2", pr.eff2Depth);
    setP("KAL_RES_2", pr.eff2Res);
    setP("KAL_WIDTH_2", pr.eff2Width);
    setP("KAL_MIX_2", pr.eff2Mix);
    setP("KAL_PARALLEL", pr.serPar);
    setP("KAL_DRIVE", pr.drive);
    setP("KAL_IN_GAIN", pr.inGain);
    setP("KAL_OUT_GAIN", pr.outGain);
    setP("CLA_PEAK_RED", pr.claPeakRed);
    setP("CLA_GAIN", pr.claGain);
    setP("CLA_LIMITER", pr.claCompLim);
    setP("CLA_HIFREQ", pr.claHiFreq);
    setP("C1_THRESH", pr.c1Thresh);
    setP("C1_RATIO", pr.c1Ratio);
    setP("C1_GATE_OPEN", pr.c1GateOpen);
    setP("C1_FLT_FREQ", pr.c1FltFreq);
    setP("MF_MIX", pr.mfMix);
    setP("MF_FEEDBACK", pr.mfFeedback);
    setP("MF_DELAY", pr.mfDelay);
    setP("MF_RATE", pr.mfRate);
    setP("MF_DEPTH", pr.mfDepth);
}

int ModSuiteAudioProcessor::getNumPrograms() { return static_cast<int>(presets.size()); }
void ModSuiteAudioProcessor::setCurrentProgram(int index) { loadFactoryPreset(index); }
const juce::String ModSuiteAudioProcessor::getProgramName(int index)
{
    if (index >= 0 && index < static_cast<int>(presets.size()))
        return presets[static_cast<size_t>(index)].name;
    return "Default";
}

void ModSuiteAudioProcessor::prepareToPlay(double sampleRate, int                    )
{
    modUnit1.prepare(sampleRate);
    modUnit2.prepare(sampleRate);
    opto.prepare(sampleRate);
    compander.prepare(sampleRate);
    tapeFlanger.prepare(sampleRate);
}

void ModSuiteAudioProcessor::releaseResources() {}

bool ModSuiteAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return layouts.getMainInputChannelSet() == out;
}

float ModSuiteAudioProcessor::rawParam (const char* id) const
{
    // Parameters that belong to another unit are not part of this plugin.
    if (auto* v = apvts.getRawParameterValue (id)) return v->load();
    return 0.0f;
}

void ModSuiteAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numSamples = buffer.getNumSamples();
    const int numChannels = buffer.getNumChannels();
    if (numSamples <= 0 || numChannels <= 0)
        return;

    license.ensureAutomaticTrial();
    if (! license.isAllowed())
    {
        // Not activated / trial ended: the host audio passes through untouched.
        if (getTotalNumInputChannels() == 1 && numChannels > 1) buffer.copyFrom (1, 0, buffer, 0, 0, numSamples);
        outVuLeftDb.store (-60.0f, std::memory_order_relaxed);
        outVuRightDb.store (-60.0f, std::memory_order_relaxed);
        return;
    }

    float* chL = buffer.getWritePointer(0);
    float* chR = (numChannels > 1) ? buffer.getWritePointer(1) : chL;

    constexpr int modelMode = TMOD_UNIT;

    const bool en1     = rawParam("KAL_EN_1") > 0.5f;
    const int type1    = static_cast<int>(rawParam("KAL_TYPE_1"));
    const float spd1   = rawParam("KAL_SPEED_1");
    const float res1   = rawParam("KAL_RES_1") * 0.01f;
    const float wid1   = rawParam("KAL_WIDTH_1") * 0.01f;
    const float mix1   = rawParam("KAL_MIX_1") * 0.01f;
    const float dep1   = rawParam("KAL_DEPTH_1") * 0.01f;
    const float hpf1   = rawParam("KAL_HPF_1");
    const float lpf1   = rawParam("KAL_LPF_1");
    const float senoise_clean  = rawParam("KAL_SENS_1") * 0.01f;

    const bool en2     = rawParam("KAL_EN_2") > 0.5f;
    const int type2    = static_cast<int>(rawParam("KAL_TYPE_2"));
    const float spd2   = rawParam("KAL_SPEED_2");
    const float res2   = rawParam("KAL_RES_2") * 0.01f;
    const float wid2   = rawParam("KAL_WIDTH_2") * 0.01f;
    const float mix2   = rawParam("KAL_MIX_2") * 0.01f;
    const float dep2   = rawParam("KAL_DEPTH_2") * 0.01f;
    const float hpf2   = rawParam("KAL_HPF_2");
    const float lpf2   = rawParam("KAL_LPF_2");
    const float sens2  = rawParam("KAL_SENS_2") * 0.01f;

    const bool isPar   = rawParam("KAL_PARALLEL") > 0.5f;
    const float drive  = rawParam("KAL_DRIVE") * 0.01f;
    const float inG    = kdsp::dbToGain(rawParam("KAL_IN_GAIN"));
    const float outG   = kdsp::dbToGain(rawParam("KAL_OUT_GAIN"));

    const float claPR  = rawParam("CLA_PEAK_RED");
    const float claG   = rawParam("CLA_GAIN");
    const bool claLim  = rawParam("CLA_LIMITER") > 0.5f;
    const float claHF  = rawParam("CLA_HIFREQ");
    const int claAna   = static_cast<int>(rawParam("CLA_ANALOG"));

    const float c1Th   = rawParam("C1_THRESH");
    const float c1Rat  = rawParam("C1_RATIO");
    const float c1Att  = rawParam("C1_ATTACK");
    const float c1Rel  = rawParam("C1_RELEASE");
    const float c1Mk   = rawParam("C1_MAKEUP");
    const float c1GOp  = rawParam("C1_GATE_OPEN");
    const float c1FF   = rawParam("C1_FLT_FREQ");
    const float c1FQ   = rawParam("C1_FLT_Q");

    const float mfMix  = rawParam("MF_MIX") * 0.01f;
    const float mfFb   = rawParam("MF_FEEDBACK") * 0.01f;
    const float mfDly  = rawParam("MF_DELAY");
    const float mfRate = rawParam("MF_RATE");
    const float mfDep  = rawParam("MF_DEPTH") * 0.01f;
    const float mfSt   = rawParam("MF_STEREO");
    const bool mfTape  = rawParam("MF_TAPE") > 0.5f;

    float peakInL = 0.0f, peakInR = 0.0f;
    float peakOutL = 0.0f, peakOutR = 0.0f;

    for (int i = 0; i < numSamples; ++i)
    {
        // A single NaN/Inf must not remain in recursive filters/delay lines.
        float xL = std::isfinite(chL[i]) ? chL[i] : 0.0f;
        float xR = (numChannels > 1) ? (std::isfinite(chR[i]) ? chR[i] : 0.0f) : xL;

        peakInL = std::max(peakInL, std::fabs(xL));
        peakInR = std::max(peakInR, std::fabs(xR));

        if constexpr (modelMode == 0)
        {
            xL *= inG;
            xR *= inG;

            if (drive > 0.005f)
            {
                const float drvScale = 1.0f + drive * 3.5f;
                xL = std::tanh(xL * drvScale) / std::tanh(drvScale);
                xR = std::tanh(xR * drvScale) / std::tanh(drvScale);
            }

            if (isPar)
            {
                float u1L = xL, u1R = xR;
                float u2L = xL, u2R = xR;
                modUnit1.processSample(xL, xR, u1L, u1R, en1, type1, spd1, dep1, res1, wid1, mix1, hpf1, lpf1, senoise_clean, 0);
                modUnit2.processSample(xL, xR, u2L, u2R, en2, type2, spd2, dep2, res2, wid2, mix2, hpf2, lpf2, sens2, 0);
                xL = 0.5f * (u1L + u2L);
                xR = 0.5f * (u1R + u2R);
            }
            else
            {
                float u1L = xL, u1R = xR;
                modUnit1.processSample(xL, xR, u1L, u1R, en1, type1, spd1, dep1, res1, wid1, mix1, hpf1, lpf1, senoise_clean, 0);
                modUnit2.processSample(u1L, u1R, xL, xR, en2, type2, spd2, dep2, res2, wid2, mix2, hpf2, lpf2, sens2, 0);
            }

            xL *= outG;
            xR *= outG;
        }
        else if constexpr (modelMode == 1)
        {
            opto.processSample(xL, xR, claPR, claG, claLim, claHF, claAna);
        }
        else if constexpr (modelMode == 2)
        {
            compander.processSample(xL, xR, c1Th, c1Rat, c1Att, c1Rel, c1Mk, c1GOp, c1GOp - 6.0f, -60.0f, 0, c1FF, c1FQ, 0);
        }
        else
        {
            tapeFlanger.processSample(xL, xR, mfMix, mfFb, false, false, mfDly, mfRate, mfDep, mfSt, 8.0f, true, mfTape, false);
        }

        peakOutL = std::max(peakOutL, std::fabs(xL));
        peakOutR = std::max(peakOutR, std::fabs(xR));

        chL[i] = xL;
        if (numChannels > 1)
            chR[i] = xR;
    }

    inVuLeftDb.store(kdsp::gainToDb(peakInL));
    inVuRightDb.store(kdsp::gainToDb(peakInR));
    outVuLeftDb.store(kdsp::gainToDb(peakOutL));
    outVuRightDb.store(kdsp::gainToDb(peakOutR));
    optoGrDb.store(opto.getGainReductionDb());
    companderGrDb.store(compander.getCompGrDb());
    mod1Phase.store(modUnit1.getLastModValue());
    mod2Phase.store(modUnit2.getLastModValue());
    flangeOscVal.store(tapeFlanger.getOscillatorValue());
}

void ModSuiteAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty ("factoryPreset", currentPresetIndex.load (std::memory_order_relaxed), nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void ModSuiteAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
    {
        auto state = juce::ValueTree::fromXml(*xmlState);
        const double saved = (double) state.getProperty ("factoryPreset", 0);
        const int index = std::isfinite (saved) ? (int) std::clamp (saved, 0.0, (double) presets.size() - 1.0) : 0;
        currentPresetIndex.store (index, std::memory_order_relaxed);
        apvts.replaceState(state); /* v1.2.1: snap on/off params to exactly 0/1 (JUCE skips them in replaceState when already matching) */ for (auto* tsP : getParameters()) if (auto* tsB = dynamic_cast<juce::AudioParameterBool*> (tsP)) { const float tsV = tsB->get() ? 1.0f : 0.0f; if (tsP->getValue() != tsV) tsP->setValueNotifyingHost (tsV); }
    }
}

juce::AudioProcessorEditor* ModSuiteAudioProcessor::createEditor()
{
    return new tmod_hw::Editor(*this);
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new ModSuiteAudioProcessor();
}
