#pragma once
#include "HwKit.h"
#include "NTEqProcessor.h"

// T-EQ: black / light-orange hardware face. The curve is the EQ the audio thread really runs;
// drag a numbered point to move that band (left/right = frequency, up/down = gain).
namespace teq_hw
{
using namespace thw;
class Editor final : public thw::Editor
{
public:
    explicit Editor (NTEqProcessor& p) : thw::Editor (p, p.apvts, p.getLicense(), { "T-EQ", "8-band vocal EQ", 1100, 640, "nteq" }), proc (p)
    {
        specPost.fill (-100.0f);
        auto& scr = screen (110, 84, 880, 210, [this] (juce::Graphics& g, juce::Rectangle<float> r) { drawGraph (g, r); });
        scr.onDown = [this, &scr] (const juce::MouseEvent& e) { dragBand = nearestBand (scr.getLocalBounds().toFloat(), e.position); if (dragBand >= 0) gesture (true); };
        scr.onDrag = [this, &scr] (const juce::MouseEvent& e) { if (dragBand >= 0) dragTo (scr.getLocalBounds().toFloat(), e.position); };
        scr.onUp = [this] (const juce::MouseEvent&) { if (dragBand >= 0) gesture (false); dragBand = -1; };
        small ("eqInput", 58, 170, 22, "INPUT", "-24", "+24", unit ("eqInput", "dB"));
        small ("eqOutput", 1042, 170, 22, "OUTPUT", "-24", "+24", unit ("eqOutput", "dB"));
        const juce::StringArray shortTypes { "BELL", "LO SH", "HI SH", "HP", "LP", "NOTCH" };
        for (int b = 1; b <= 8; ++b)
        {
            const float x = 20.0f + (float) (b - 1) * 132.5f, cx = x + 62.0f;
            auto id = [b] (const char* s) { return NTEqProcessor::bandParamId (b, s); };
            section (x, 310, 124, 270, "BAND " + String (b));
            button (id ("on"), x + 10, 336, 50, "ON");
            select (id ("type"), x + 64, 335, 52, {}, shortTypes);
            small (id ("freq"), cx, 388, 20, "FREQ", {}, {}, [this, b] { return hz (value (NTEqProcessor::bandParamId (b, "freq"))); });
            small (id ("gain"), cx - 29, 478, 15, "GAIN", {}, {}, [this, b] { const float v = value (NTEqProcessor::bandParamId (b, "gain")); return (v > 0 ? "+" : "") + String (v, 1); }, {}, 54);
            small (id ("q"), cx + 29, 478, 15, "Q", {}, {}, [this, b] { return String (value (NTEqProcessor::bandParamId (b, "q")), 2); }, {}, 54);
            // placement / slope / dynamic live in a small menu on the chip
            auto& chip = button ({}, x + 10, 552, 104, {}, 18);
            chip.onClick = [this, b, &chip] { showBandMenu (b, chip); };
            chips.push_back (&chip);
            for (auto* s : { "slope", "place", "dyn" }) markCovered (id (s));
        }
        button ("eqAutoGain", 24, 260 - 4, 70, "AUTO", 24).setTooltip (vn ("Tự bù âm lượng"));
        infoItem ("AUTO GAIN", [this] { return value ("eqAutoGain") > 0.5f ? String (proc.autoGainDb.load(), 1) + " dB" : String ("OFF"); });
        infoItem ("BYPASS", [this] { return value ("eqBypass") > 0.5f ? String ("ON") : String ("OFF"); });
        finish();
    }
private:
    static String hz (float f) { return f >= 1000.0f ? String (f / 1000.0f, f >= 10000.0f ? 1 : 2) + " kHz" : String (juce::roundToInt (f)) + " Hz"; }
    void tick() override
    {
        analyse (proc.postFifo, specPost);
        for (int b = 1; b <= 8; ++b)
        {
            const int place = juce::roundToInt (value (NTEqProcessor::bandParamId (b, "place")));
            const int slope = juce::roundToInt (value (NTEqProcessor::bandParamId (b, "slope")));
            const bool dyn = value (NTEqProcessor::bandParamId (b, "dyn")) > 0.5f;
            static const char* places[] = { "STEREO", "MID", "SIDE" };
            const String t = String (places[juce::jlimit (0, 2, place)]) + " " + String (12 * (slope + 1)) + (dyn ? " DYN" : "");
            if (chips[(size_t) b - 1]->getButtonText() != t) chips[(size_t) b - 1]->setButtonText (t);
        }
    }
    void analyse (NTEqProcessor::Fifo& f, std::array<float, 256>& out)
    {
        if (! f.hasBlock.load (std::memory_order_acquire)) { for (auto& v : out) v = juce::jmax (-100.0f, v - 1.2f); return; }
        std::copy (f.ready.begin(), f.ready.end(), work.begin());
        f.hasBlock.store (false, std::memory_order_release);
        std::fill (work.begin() + NTEqProcessor::fftSize, work.end(), 0.0f);
        window.multiplyWithWindowingTable (work.data(), (size_t) NTEqProcessor::fftSize);
        fft.performFrequencyOnlyForwardTransform (work.data());
        const double sr = proc.getSampleRate() > 0 ? proc.getSampleRate() : 48000.0, binHz = sr / NTEqProcessor::fftSize;
        const float norm = 4.0f / (float) NTEqProcessor::fftSize;
        for (int i = 0; i < 256; ++i)
        {
            const double f0 = 20.0 * std::pow (1000.0, (i - 0.5) / 255.0), f1 = 20.0 * std::pow (1000.0, (i + 0.5) / 255.0);
            const int k0 = juce::jlimit (1, NTEqProcessor::fftSize / 2 - 1, (int) std::floor (f0 / binHz));
            const int k1 = juce::jlimit (k0, NTEqProcessor::fftSize / 2 - 1, (int) std::ceil (f1 / binHz));
            float m = 0; for (int k = k0; k <= k1; ++k) m = juce::jmax (m, work[(size_t) k]);
            const float d = m > 0 ? 20.0f * std::log10 (m * norm) : -100.0f;
            out[(size_t) i] = juce::jmax (d, out[(size_t) i] - 1.5f);
        }
    }
    juce::Point<float> nodePos (juce::Rectangle<float> r, int b)
    {
        const float f = value (NTEqProcessor::bandParamId (b, "freq"));
        const int type = juce::roundToInt (value (NTEqProcessor::bandParamId (b, "type")));
        const float gain = (type == 3 || type == 4 || type == 5) ? 0.0f : value (NTEqProcessor::bandParamId (b, "gain"));
        return { freqX (r, f), dbY (r, gain) };
    }
    static float dbY (juce::Rectangle<float> r, float db) { return r.getCentreY() - 6 - db * (r.getHeight() - 50) / 36.0f; }
    int nearestBand (juce::Rectangle<float> r, juce::Point<float> p)
    {
        int best = -1; float bestD = 22.0f;
        for (int b = 1; b <= 8; ++b) { const float d = nodePos (r, b).getDistanceFrom (p); if (d < bestD) { bestD = d; best = b; } }
        return best;
    }
    void gesture (bool begin)
    {
        for (auto* s : { "freq", "gain" })
            if (auto* p = param (NTEqProcessor::bandParamId (dragBand, s))) { if (begin) p->beginChangeGesture(); else p->endChangeGesture(); }
    }
    void dragTo (juce::Rectangle<float> r, juce::Point<float> p)
    {
        const float t = juce::jlimit (0.0f, 1.0f, (p.x - r.getX() - 10) / (r.getWidth() - 20));
        const float f = 20.0f * std::pow (1000.0f, t);
        if (auto* fp = param (NTEqProcessor::bandParamId (dragBand, "freq"))) fp->setValueNotifyingHost (fp->convertTo0to1 (f));
        const int type = juce::roundToInt (value (NTEqProcessor::bandParamId (dragBand, "type")));
        if (type != 3 && type != 4 && type != 5)
            if (auto* gp = param (NTEqProcessor::bandParamId (dragBand, "gain")))
                gp->setValueNotifyingHost (gp->convertTo0to1 (juce::jlimit (-18.0f, 18.0f, (r.getCentreY() - 6 - p.y) * 36.0f / (r.getHeight() - 50))));
    }
    void drawGraph (juce::Graphics& g, juce::Rectangle<float> r)
    {
        spectrum (g, r, specPost.data(), 256, dim().withAlpha (0.45f), true, -90.0f, 0.0f);
        g.setColour (juce::Colours::white.withAlpha (0.12f));
        g.drawHorizontalLine (juce::roundToInt (dbY (r, 0)), r.getX() + 10, r.getRight() - 10);
        for (auto [d, l] : { std::pair<float, const char*> { 12, "+12" }, { 6, "+6" }, { -6, "-6" }, { -12, "-12" } })
            thw::text (g, l, r.getX() + 22, dbY (r, d), 9.0f, Colour (0xff8f897f), 7);
        double sr = 48000.0;
        std::array<BandShape, 8> shapes;
        for (int b = 0; b < 8; ++b) shapes[(size_t) b] = proc.getBandShapeForDisplay (b, sr);
        juce::Path p;
        for (int i = 0; i <= 300; ++i)
        {
            const float f = 20.0f * std::pow (1000.0f, (float) i / 300.0f);
            double db = 0; for (auto& s : shapes) db += s.magnitudeDb (f, sr);
            const float x = freqX (r, f), y = dbY (r, (float) juce::jlimit (-24.0, 24.0, db));
            if (i == 0) p.startNewSubPath (x, y); else p.lineTo (x, y);
        }
        juce::Path fill (p); fill.lineTo (freqX (r, 20000), dbY (r, 0)); fill.lineTo (freqX (r, 20), dbY (r, 0)); fill.closeSubPath();
        g.setColour (orangeLight().withAlpha (0.12f)); g.fillPath (fill);
        g.setColour (orangeLight()); g.strokePath (p, juce::PathStrokeType (2.2f));
        for (int b = 1; b <= 8; ++b)
        {
            const bool on = value (NTEqProcessor::bandParamId (b, "on")) > 0.5f;
            const auto n = nodePos (r, b);
            if (on) glowDot (g, n.x, n.y, b == dragBand ? 7.0f : 5.5f);
            else { g.setColour (dim()); g.drawEllipse (n.x - 5, n.y - 5, 10, 10, 1.2f); }
            thw::text (g, String (b), n.x, n.y - 14, 9.5f, on ? orangeLight() : dim(), 8);
        }
        freqLabels (g, r, { { 20.0f, "20" }, { 50.0f, "50" }, { 100.0f, "100" }, { 200.0f, "200" }, { 500.0f, "500" }, { 1000.0f, "1k" },
                            { 2000.0f, "2k" }, { 5000.0f, "5k" }, { 10000.0f, "10k" }, { 20000.0f, "20k" } });
    }
    void showBandMenu (int b, juce::Component& target)
    {
        juce::PopupMenu m;
        auto* place = dynamic_cast<juce::AudioParameterChoice*> (param (NTEqProcessor::bandParamId (b, "place")));
        auto* slope = dynamic_cast<juce::AudioParameterChoice*> (param (NTEqProcessor::bandParamId (b, "slope")));
        auto* dyn = param (NTEqProcessor::bandParamId (b, "dyn"));
        if (place) { m.addSectionHeader ("PLACEMENT"); for (int i = 0; i < place->choices.size(); ++i) m.addItem (100 + i, place->choices[i], true, place->getIndex() == i); }
        if (slope) { m.addSectionHeader ("SLOPE (HP / LP)"); for (int i = 0; i < slope->choices.size(); ++i) m.addItem (200 + i, slope->choices[i], true, slope->getIndex() == i); }
        if (dyn) { m.addSeparator(); m.addItem (300, "Dynamic EQ", true, dyn->getValue() > 0.5f); }
        m.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&target), [safe = juce::Component::SafePointer<Editor>(this), b] (int r)
        {
            if (safe == nullptr) return;
            auto* place = dynamic_cast<juce::AudioParameterChoice*> (safe->param (NTEqProcessor::bandParamId (b, "place")));
            auto* slope = dynamic_cast<juce::AudioParameterChoice*> (safe->param (NTEqProcessor::bandParamId (b, "slope")));
            auto* dyn = safe->param (NTEqProcessor::bandParamId (b, "dyn"));
            auto set = [] (juce::RangedAudioParameter* p, float v) { if (! p) return; p->beginChangeGesture(); p->setValueNotifyingHost (p->convertTo0to1 (v)); p->endChangeGesture(); };
            if (r >= 100 && r < 200) set (place, (float) (r - 100));
            else if (r >= 200 && r < 300) set (slope, (float) (r - 200));
            else if (r == 300 && dyn) set (dyn, dyn->getValue() > 0.5f ? 0.0f : 1.0f);
        });
    }
    NTEqProcessor& proc;
    juce::dsp::FFT fft { NTEqProcessor::fftOrder };
    juce::dsp::WindowingFunction<float> window { (size_t) NTEqProcessor::fftSize, juce::dsp::WindowingFunction<float>::hann };
    std::array<float, NTEqProcessor::fftSize * 2> work {};
    std::array<float, 256> specPost {};
    std::vector<LedButton*> chips;
    int dragBand = -1;
};
}
