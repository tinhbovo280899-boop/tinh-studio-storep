#!/usr/bin/env python3
"""Apply the five audited source files; reject other versions before any writes."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
import sys
import tempfile


HERE = Path(__file__).resolve().parent
BACKUP_SUFFIX = ".before-31-vst-audit"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def atomic_write(path, data, mode):
    descriptor, name = tempfile.mkstemp(prefix=path.name + ".audit-", dir=str(path.parent))
    temporary = Path(name)
    try:
        with os.fdopen(descriptor, "wb") as stream:
            stream.write(data)
            stream.flush()
            os.fsync(stream.fileno())
        os.chmod(temporary, mode)
        os.replace(temporary, path)
    finally:
        if temporary.exists():
            temporary.unlink()


def project_folder(root, project, relative_files):
    # Search only this folder and three directory levels below it.
    candidates = []
    current = [root]
    for depth in range(4):
        following = []
        for folder in current:
            if folder.name == project or depth == 0:
                if all((folder / relative).is_file() for relative in relative_files):
                    candidates.append(folder)
            if depth < 3:
                following.extend(p for p in sorted(folder.iterdir())
                                 if p.is_dir() and not p.is_symlink()
                                 and p.name not in {".git", "build", "build-qa", "JUCE", "Patch_Source"})
        current = following
    candidates = sorted(set(p.resolve() for p in candidates))
    if len(candidates) != 1:
        raise ValueError("Expected exactly one source folder for %s; found %d. "
                         "Point --source-root at the intended project or its parent."
                         % (project, len(candidates)))
    return candidates[0]


def apply(root, selected=None, check=False):
    root = root.resolve(strict=True)
    manifest = json.loads((HERE / "PATCH_MANIFEST.json").read_text(encoding="utf-8"))
    rows = [row for row in manifest if selected is None or row["path"].split("/")[0] == selected]
    projects = sorted({row["path"].split("/")[0] for row in rows})
    locations = {}
    for project in projects:
        relatives = [Path(*Path(row["path"]).parts[1:]) for row in rows
                     if row["path"].split("/")[0] == project]
        locations[project] = project_folder(root, project, relatives)

    plan = []
    for row in rows:
        relative = Path(row["path"])
        path = (locations[relative.parts[0]] / Path(*relative.parts[1:])).resolve(strict=True)
        path.relative_to(root)  # Refuse symlink escapes from the selected source tree.
        original = path.read_bytes()
        current_sha = sha(original)
        payload = (HERE / "Patch_Source" / relative).read_bytes()
        if sha(payload) != row["after_sha256"]:
            raise ValueError("Patch payload checksum mismatch: " + row["path"])
        if current_sha == row["after_sha256"]:
            print("ALREADY FIXED: " + row["path"])
            continue
        if current_sha != row["before_sha256"]:
            raise ValueError("Different source version; no files changed: " + row["path"])
        backup = path.with_name(path.name + BACKUP_SUFFIX)
        if backup.exists() and sha(backup.read_bytes()) != row["before_sha256"]:
            raise ValueError("Existing backup differs; no files changed: " + str(backup))
        plan.append((path, backup, original, payload, stat.S_IMODE(path.stat().st_mode)))

    if check:
        print("CHECK OK: %d file(s) need updates; no files changed." % len(plan))
        return len(plan)

    written = []
    try:
        for path, backup, original, payload, mode in plan:
            if path.read_bytes() != original:
                raise ValueError("Source changed during apply: " + str(path))
            if not backup.exists():
                atomic_write(backup, original, mode)
            atomic_write(path, payload, mode)
            written.append((path, original, mode))
    except Exception:
        for path, original, mode in reversed(written):
            atomic_write(path, original, mode)
        raise
    print("APPLIED: %d source file(s). Backups use %s. Rebuild the affected plugins." %
          (len(written), BACKUP_SUFFIX))
    return len(written)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-root", type=Path, required=True)
    parser.add_argument("--project", choices=("T-Studio_Plugins", "T-Studio_FX"))
    parser.add_argument("--check", action="store_true", help="Verify hashes without changing files")
    args = parser.parse_args()
    try:
        apply(args.source_root, args.project, args.check)
    except (OSError, ValueError) as error:
        print("ERROR: " + str(error), file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
