#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include <juce_dsp/juce_dsp.h>
#include "licensing/PluginLicense.h"
#include <cstdio>
#include <cstdlib>
#include <new>
#include <limits>
#include <random>
#include <stdexcept>
namespace heap {thread_local bool active=false;thread_local unsigned long long count=0;}
void* operator new(std::size_t n){if(heap::active)++heap::count;if(void* p=std::malloc(n?n:1))return p;throw std::bad_alloc();}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void* p)noexcept{std::free(p);}void operator delete[](void* p)noexcept{std::free(p);}
void operator delete(void* p,std::size_t)noexcept{std::free(p);}void operator delete[](void* p,std::size_t)noexcept{std::free(p);}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
static juce::var obj(){return juce::var(new juce::DynamicObject);}
static void put(juce::var& v,const char* k,juce::var x){v.getDynamicObject()->setProperty(k,x);}
int main(){try{
    juce::ScopedJuceInitialiser_GUI init;
    auto p=std::unique_ptr<juce::AudioProcessor>(createPluginFilter());
    auto result=obj();put(result,"name",p->getName());
    auto* srRows=new juce::Array<juce::var>;
    tak::license::PluginLicense proof;proof.ensureAutomaticTrial();
    for(int n=0;n<120&&!proof.isAllowed();++n)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
    if(!proof.isAllowed())throw std::runtime_error("QA license not ready");
    juce::MemoryBlock initial;p->getStateInformation(initial);
    juce::Array<juce::var> ids;
    for(auto* q:p->getParameters())if(auto* id=dynamic_cast<juce::AudioProcessorParameterWithID*>(q))ids.add(id->paramID);
    put(result,"parameter_ids",ids);
    for(double fs:{48000.,96000.}){
        p->setStateInformation(initial.getData(),int(initial.getSize()));
        p->setRateAndBufferSizeDetails(fs,512);p->prepareToPlay(fs,512);
        auto row=obj();put(row,"sample_rate",fs);put(row,"host_latency_samples",p->getLatencySamples());
        put(row,"host_bypass_parameter",p->getBypassParameter()!=nullptr);
        juce::AudioBuffer<float>b(2,512);juce::MidiBuffer midi;double phase=0.;
        std::mt19937 rng(31);std::uniform_real_distribution<float> noise(-.025f,.025f);
        auto audio=[&](int n,bool anti,bool count){
            b.setSize(2,n,false,false,true);
            for(int i=0;i<n;++i){phase+=2.*juce::MathConstants<double>::pi*220./fs;
                float x=float(.06*std::sin(phase))+noise(rng);b.setSample(0,i,x);b.setSample(1,i,anti?-x:x);}
            heap::active=count;const double start=juce::Time::getMillisecondCounterHiRes();p->processBlock(b,midi);
            const double ms=juce::Time::getMillisecondCounterHiRes()-start;heap::active=false;
            return ms;
        };
        for(int i=0;i<30;++i)audio(128,false,false);
        unsigned long long bad=0;double maxMs=0.,peak=0.;heap::count=0;
        for(int i=0;i<48;++i){maxMs=std::max(maxMs,audio(i%3==0?1:i%3==1?127:511,i%2,true));
            for(int c=0;c<2;++c)for(int n=0;n<b.getNumSamples();++n){float x=b.getSample(c,n);if(!std::isfinite(x))++bad;else peak=std::max(peak,double(std::abs(x)));}}
        put(row,"steady_cpp_allocations",juce::int64(heap::count));put(row,"steady_nonfinite",juce::int64(bad));
        put(row,"steady_peak",peak);put(row,"max_steady_callback_ms",maxMs);
        juce::Array<juce::var> sweep;
        for(auto* q:p->getParameters()){
            auto item=obj();const float original=q->getValue();
            if(auto* id=dynamic_cast<juce::AudioProcessorParameterWithID*>(q))put(item,"id",id->paramID);
            else put(item,"id",q->getName(128));
            heap::count=0;unsigned long long nonfinite=0;double maximum=0.;
            for(float endpoint:{0.f,1.f}){
                q->setValueNotifyingHost(endpoint);
                for(int k=0;k<8;++k){maximum=std::max(maximum,audio(127,false,true));
                    for(int c=0;c<2;++c)for(int n=0;n<127;++n)if(!std::isfinite(b.getSample(c,n)))++nonfinite;}
            }
            q->setValueNotifyingHost(original);
            put(item,"cpp_allocations",juce::int64(heap::count));put(item,"nonfinite",juce::int64(nonfinite));put(item,"max_callback_ms",maximum);
            sweep.add(item);
        }
        put(row,"parameter_sweep",sweep);
        p->setStateInformation(initial.getData(),int(initial.getSize()));p->reset();
        b.setSize(2,512,false,false,true);b.clear();b.setSample(0,0,std::numeric_limits<float>::quiet_NaN());
        p->processBlock(b,midi);unsigned long long recoveryBad=0;
        for(int k=0;k<int(fs/512)+2;++k){b.clear();p->processBlock(b,midi);
            for(int c=0;c<2;++c)for(int n=0;n<512;++n)if(!std::isfinite(b.getSample(c,n)))++recoveryBad;}
        put(row,"nonfinite_after_invalid_input",juce::int64(recoveryBad));
        p->reset();unsigned long long resetBad=0;
        for(int k=0;k<20;++k){b.clear();p->processBlock(b,midi);
            for(int c=0;c<2;++c)for(int n=0;n<512;++n)if(!std::isfinite(b.getSample(c,n)))++resetBad;}
        put(row,"nonfinite_after_reset",juce::int64(resetBad));
        for(int k=0;k<80;++k){b.clear();p->processBlockBypassed(b,midi);}
        int peakIndex=-1;float impulsePeak=0.;
        for(int k=0;k<32;++k){b.clear();if(k==0){b.setSample(0,16,.1f);b.setSample(1,16,.1f);}p->processBlockBypassed(b,midi);
            for(int n=0;n<512;++n)if(std::isfinite(b.getSample(0,n))&&std::abs(b.getSample(0,n))>impulsePeak){impulsePeak=std::abs(b.getSample(0,n));peakIndex=k*512+n;}}
        put(row,"host_bypass_impulse_lag",peakIndex<0?-1:peakIndex-16);put(row,"host_bypass_peak",impulsePeak);
        srRows->add(row);p->releaseResources();
    }
    put(result,"sample_rates",juce::var(*srRows));delete srRows;
    std::printf("AUDIT_JSON %s\n",juce::JSON::toString(result,true).toRawUTF8());return 0;
}catch(const std::exception& e){std::fprintf(stderr,"SIGNAL FAIL: %s\n",e.what());return 1;}}
