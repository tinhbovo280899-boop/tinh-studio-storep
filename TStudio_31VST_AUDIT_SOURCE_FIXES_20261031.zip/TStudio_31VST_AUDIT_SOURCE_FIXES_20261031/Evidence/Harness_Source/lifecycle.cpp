#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include <juce_dsp/juce_dsp.h>
#include <cstdio>
#include <thread>
#include <atomic>
#include <stdexcept>
#include "licensing/PluginLicense.h"
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
static int checks=0;
static void require(bool x,const char* text){++checks;if(!x)throw std::runtime_error(text);}
int main(){std::string name="(unknown)";try{
    juce::ScopedJuceInitialiser_GUI init;
    double slowestDelete=0.;
    for(int cycle=0;cycle<6;++cycle){
        auto p=std::unique_ptr<juce::AudioProcessor>(createPluginFilter());
        require(p!=nullptr,"factory returned null");
        name=p->getName().toStdString();
        if(cycle<2){p.reset();continue;}
        const double fs=cycle%2?96000.:48000.;
        p->setRateAndBufferSizeDetails(fs,128);p->prepareToPlay(fs,128);
        std::printf("LATENCY fs=%.0f samples=%d\n",fs,p->getLatencySamples());
        {tak::license::PluginLicense probe;probe.ensureAutomaticTrial();
         for(int n=0;n<120&&!probe.isAllowed();++n)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
         require(probe.isAllowed(),"QA trial could not start");}
        // Allow any independent worker to observe the same task-owned trial.
        auto editor=std::unique_ptr<juce::AudioProcessorEditor>(p->createEditor());
        require(editor!=nullptr,"editor failed");
        juce::MemoryBlock state;p->getStateInformation(state);require(state.getSize()>0,"empty state");
        p->setStateInformation(state.getData(),int(state.getSize()));
        std::atomic<bool> done{false},finite{true};std::atomic<int> blocks{0};
        std::thread audio([&]{juce::AudioBuffer<float>b(2,128);juce::MidiBuffer midi;double phase=0.;
            while(!done.load()){
                for(int n=0;n<128;++n){phase+=2.*juce::MathConstants<double>::pi*220./fs;
                    float s=float(.04*std::sin(phase));b.setSample(0,n,s);b.setSample(1,n,s);}
                p->processBlock(b,midi);
                for(int ch=0;ch<2;++ch)for(int n=0;n<128;++n)if(!std::isfinite(b.getSample(ch,n)))finite=false;
                ++blocks;std::this_thread::yield();
            }});
        for(int n=0;n<10;++n)juce::MessageManager::getInstance()->runDispatchLoopUntil(10);
        editor.reset(); // Close the real editor while processing continues.
        juce::MessageManager::getInstance()->runDispatchLoopUntil(10);
        done=true;audio.join();require(finite,"nonfinite audio");require(blocks>0,"audio did not run");
        juce::AudioBuffer<float>b(2,128);juce::MidiBuffer midi;b.clear();p->processBlockBypassed(b,midi);
        for(int ch=0;ch<2;++ch)for(int n=0;n<128;++n)require(std::isfinite(b.getSample(ch,n)),"nonfinite bypass");
        p->reset();p->releaseResources();
        const double start=juce::Time::getMillisecondCounterHiRes();
        {const juce::MessageManagerLock lock;p.reset();}
        const double elapsed=juce::Time::getMillisecondCounterHiRes()-start;
        slowestDelete=std::max(slowestDelete,elapsed);
    }
    std::printf("PASS %s: %d checks, 6 lifecycles, 4 editors, 4 UI-locked deletions, max_delete_ms=%.3f\n",name.c_str(),checks,slowestDelete);
    return 0;
}catch(const std::exception& e){std::fprintf(stderr,"FAIL %s: %s\n",name.c_str(),e.what());return 1;}}
