# T Studio — kiểm tra 31 VST và bản vá mã nguồn

Ngày kiểm tra: 31/10/2026. Gói này chứa báo cáo của 31 plugin và **5 file nguồn đã sửa**, tác động tới 7 plugin. Đây là bản vá bổ sung cho đúng các ZIP anh đã gửi; không phải bộ cài hay toàn bộ mã nguồn 31 plugin.

Lỗi đã tái hiện và sửa:

- **T-EQ:** callback menu có thể dùng tham số đã bị giải phóng khi cửa sổ/plugin bị xóa. AddressSanitizer bắt được lỗi ở nguồn gốc; callback đã sửa vượt qua cùng phép thử.
- **T-Verb, T-Mod, T-Opto, T-TapeFlanger:** một mẫu NaN đầu vào làm trạng thái DSP tiếp tục sinh NaN. Đã chặn mẫu không hữu hạn trước bộ lọc/đường hồi tiếp. T-Compander nhận cùng bản vá vì dùng chung file nguồn, dù bài thử gốc của nó không gặp lỗi này.
- **T-Limiter:** nhánh host bypass đi thẳng, bỏ mất độ trễ plugin đã báo. Đã dùng đường dry có bù trễ và chuyển mượt; phép đo sau sửa khớp 258/498 mẫu ở 48/96 kHz.

Không thay đổi mã nhận diện plugin, thứ tự tham số, thuật toán tạo màu cho tín hiệu hữu hạn hay chính sách/key bản quyền.

## Áp dụng trên mã nguồn

Giải nén các dự án gốc. Với VocalPack, file 1.7.3 anh gửi chỉ là overlay; phần kiểm tra dùng overlay đó trên toàn bộ nguồn 1.7.2 Live đã gửi trước. Bản vá 5 file này chỉ sửa hai thư mục **T-Studio_Plugins** và **T-Studio_FX** trong ZIP T-Studio_FX.zip lần này.

Cách chép tay: sao lưu file cũ, rồi chép các file trong `Patch_Source/` vào đúng dự án theo đường dẫn tương ứng. `PATCH_MANIFEST.json` ghi SHA-256 trước/sau; dừng nếu nguồn cũ khác hash.

Hoặc dùng Python 3.9 trở lên, không cần cài thêm thư viện. Ví dụ thư mục `D:\VST_Source` chứa cả hai dự án:

```powershell
py -3 Apply-Fixes.py --source-root "D:\VST_Source" --check
py -3 Apply-Fixes.py --source-root "D:\VST_Source"
```

Nếu giải nén hai dự án ở hai chỗ khác nhau, áp dụng riêng:

```powershell
py -3 Apply-Fixes.py --source-root "D:\VST_Source\T-Studio_Plugins" --project T-Studio_Plugins
py -3 Apply-Fixes.py --source-root "D:\VST_Source\T-Studio_FX" --project T-Studio_FX
```

Trên macOS/Linux dùng `python3` thay `py -3`. Công cụ tìm dự án trong thư mục đã chọn và tối đa ba cấp bên dưới, kiểm tra tất cả hash trước khi ghi, từ chối nguồn khác phiên bản, giữ bản cũ ở đuôi `.before-31-vst-audit`, chạy lại không ghi đè lần nữa. Nếu ghi thất bại giữa chừng, các file đã đổi được khôi phục.

Sau đó build lại **T-EQ, T-Limiter, T-Mod, T-Opto, T-Compander, T-TapeFlanger và T-Verb** bằng công cụ Windows/macOS sẵn có của dự án. Giữ nguyên cấu hình public key/branding đã dùng cho sản phẩm của anh.

## Kết quả và giới hạn

`BAO_CAO_31_VST.md` có kết luận chi tiết và bảng 31 plugin. `31_VST.csv` mở được bằng Excel; `Evidence/` chứa log và số liệu trước/sau. Các thay đổi nguồn nằm trong `SOURCE_CHANGES.patch` và `Patch_Source/`.

Đã biên dịch nguồn processor/editor của 31 plugin và chạy QA trên Linux với JUCE 8.0.12. Chưa chạy các DLL VST3 Windows trong Cubase 15, chưa thử tháo DLL thật, chưa build bộ cài Windows/macOS. Kết quả này không xác nhận mọi tình huống đơ Cubase đã hết hoặc chất tiếng đã đạt mức nào qua nghe thực tế.

Một điểm còn cần theo dõi là worker license có thể đợi tối đa 30 giây khi đóng nếu I/O bị kẹt. Chưa tái hiện kẹt I/O trong các phép thử này; bản vá không đổi cơ chế đó. Các kiểm thử license dùng kho QA riêng và khóa thử tạm; gói này không chứa private key hay công cụ cấp key đã nhúng khóa của chủ sở hữu.
