# Third-party notices

The user supplied the source compressor model; the original upload is preserved byte-for-byte in Reference/ORIGINAL_UPLOAD.zip. Original claims of binary equivalence have not been independently established. Gold uses a corrective revision of that source with a new T Studio native UI and host wrapper. It does not embed IK Multimedia logos, manufacturer executable code or activation material.

JUCE 8.0.12 is vendored at third_party/JUCE, under its original commercial/GPL terms. Original licence and SDK notices are retained, including third_party/JUCE/LICENSE.md and Steinberg notices under modules/juce_audio_processors_headless/format_types/VST3_SDK.
