#include "ClassicCore.h"
#include <vector>
#include <iostream>
#include <fstream>
#include <cmath>
using IK::KIS::FX::TR3::ClassicComp::ClassicCompModule;
constexpr double pi=3.141592653589793;
struct Result{double rms,gr;};
Result run(float db,float ratio=3.1f,float output=0,float hpf=76,float freq=1000,float stereo=0,bool side=false){
 ClassicCompModule c;c.setSampleRate(48000);c.setAttackTimeMs(25);c.setReleaseTimeMs(250);c.setInputDriveDb(0);c.setRatio(ratio);c.setOutputGainDb(output);c.setSidechainHpfHz(hpf);c.setStereoEnhancementDb(stereo);c.reset();double sum=0,gr=0;
 int n=96000;for(int i=0;i<n;++i){double x=std::pow(10.,db/20)*std::sin(2*pi*freq*i/48000),l,r,g;c.processSampleStereo(x,side?-x:x,l,r,g);if(i>=72000){sum+=l*l;gr+=-20*std::log10(g);}}return{std::sqrt(sum/24000),gr/24000};}
int main(int argc,char**argv){
 std::cout<<"{\"curve\":[";bool first=true;for(float db:{-60.f,-48.f,-36.f,-24.f,-18.f,-12.f,-6.f,0.f}){auto r=run(db);if(!first)std::cout<<",";first=false;std::cout<<"{\"input_peak_dbfs\":"<<db<<",\"output_rms_dbfs\":"<<20*std::log10(r.rms)<<",\"gr_db\":"<<r.gr<<"}";}
 auto lo=run(-6,1.5),hi=run(-6,4.68),base=run(-12),up=run(-12,3.1,3),hp1=run(-6,3.1,0,32,50),hp2=run(-6,3.1,0,218,50),sw1=run(-60,3.1,0,76,1000,-5,true),sw2=run(-60,3.1,0,76,1000,5,true);
 double outputDelta=20*std::log10(up.rms/base.rms),widthDelta=20*std::log10(sw2.rms/sw1.rms);
 std::cout<<"],\"output_plus3_measured_db\":"<<outputDelta<<",\"ratio_low_gr_db\":"<<lo.gr<<",\"ratio_high_gr_db\":"<<hi.gr<<",\"hpf32_gr_at50hz_db\":"<<hp1.gr<<",\"hpf218_gr_at50hz_db\":"<<hp2.gr<<",\"stereo_enh_minus5_to_plus5_db\":"<<widthDelta<<",\"transients\":[";
 bool firstT=true;for(float attack:{12.f,82.f})for(float release:{29.f,1400.f}){
  ClassicCompModule c;c.setSampleRate(48000);c.setAttackTimeMs(attack);c.setReleaseTimeMs(release);c.setInputDriveDb(0);c.reset();std::ofstream f; if(argc>1)f.open(std::string(argv[1])+"/envelope-"+std::to_string(int(attack))+"-"+std::to_string(int(release))+".f32",std::ios::binary);
  double a20=0,r100=0;for(int i=0;i<96000;++i){double amp=i<24000||i>=48000?.015:.7,l,r,g;double x=amp*std::sin(2*pi*1000*i/48000);c.processSampleStereo(x,x,l,r,g);float gr=float(-20*std::log10(g));if(f)f.write((char*)&gr,4);if(i==24960)a20=gr;if(i==52800)r100=gr;}
  if(!firstT)std::cout<<",";firstT=false;std::cout<<"{\"attack_ms\":"<<attack<<",\"release_ms\":"<<release<<",\"gr20ms_after_upstep\":"<<a20<<",\"gr100ms_after_downstep\":"<<r100<<"}";
 }
 bool ok=std::abs(outputDelta-3)<.02&&std::abs(widthDelta-10)<.1&&hi.gr>lo.gr&&hp2.gr<hp1.gr;
 std::cout<<"],\"invariant_checks_pass\":"<<(ok?"true":"false")<<"}\n";return ok?0:1;
}
