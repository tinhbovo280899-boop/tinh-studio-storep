#include "NTCompDSP.h"
#include <iostream>
#include <vector>
using IK::KIS::FX::TR3::ClassicComp::ClassicCompModule;
constexpr double pi=3.141592653589793;
double rms(const std::vector<float>& x){double s=0;for(int i=int(x.size()/2);i<int(x.size());++i)s+=x[i]*x[i];return std::sqrt(s/(x.size()/2));}
int main(){
 for(float level:{-50.f,-18.f,-6.f}){
  int n=96000;std::vector<float>x(n),r(n),y(n),z(n);for(int i=0;i<n;++i)x[i]=float(std::pow(10.,level/20)*std::sin(2*pi*1000*i/48000));
  ClassicCompModule a,b;a.setSampleRate(48000);a.setInputDriveDb(0);a.setRatio(3.1f);a.reset();b=a;
  a.processStereo(x.data(),x.data(),y.data(),z.data(),n);double block=rms(y);
  for(int i=0;i<n;++i){double l,rr,gr;b.processSampleStereo(x[i],x[i],l,rr,gr);y[i]=float(l);}double single=rms(y);
  NTCompDSP c;c.drive=0;c.prepare(48000,128);r=x;z=x;c.process(r.data(),z.data(),n);
  std::cout<<"level="<<level<<" core_block_minus_sample_dB="<<20*std::log10(block/single)<<" hybrid_minus_single_dB="<<20*std::log10(rms(r)/single)<<"\n";
 }
 NTCompDSP a,b;a.prepare(48000,128);b.prepare(48000,128);b.autoReleaseEnabled=true;std::vector<float>x(96000),y;for(int i=0;i<int(x.size());++i)x[i]=float((i<24000?.6:.04)*std::sin(2*pi*1000*i/48000));y=x;std::vector<float>xr=x,yr=y;a.process(x.data(),xr.data(),int(x.size()));b.process(y.data(),yr.data(),int(y.size()));std::cout<<"classic_autorelease_bit_identical="<<(x==y)<<"\n";
}
