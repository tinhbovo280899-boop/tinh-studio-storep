#include "Processor.h"
#include <limits>
#include <cstdio>
#include <new>
static int checks=0,failures=0;
#define CHECK(x) do{++checks;if(!(x)){if(failures<20)std::printf("FAIL %d %s\n",__LINE__,#x);++failures;}}while(false)
static std::atomic<bool> counting{false};static std::atomic<int> allocations{0};
void* operator new(std::size_t n){if(counting)++allocations;if(auto* p=std::malloc(n?n:1))return p;throw std::bad_alloc();}void* operator new[](std::size_t n){return ::operator new(n);}void operator delete(void* p)noexcept{std::free(p);}void operator delete[](void* p)noexcept{std::free(p);}void operator delete(void* p,std::size_t)noexcept{std::free(p);}void operator delete[](void* p,std::size_t)noexcept{std::free(p);}
static juce::Component* find(juce::Component& c,const juce::String& id){if(c.getComponentID()==id)return &c;for(int i=0;i<c.getNumChildComponents();++i)if(auto* p=find(*c.getChildComponent(i),id))return p;return nullptr;}
int main(){juce::ScopedJuceInitialiser_GUI gui;
 using Core=IK::KIS::FX::TR3::ClassicComp::ClassicCompModule;
 for(float sr:{8000.f,44100.f,48000.f,96000.f,192000.f}){
  Core a,b,c;a.setSampleRate(sr);a.setInputDriveDb(0);a.setOutputGainDb(0);a.reset();b=a;c=a;const int n=4096;std::vector<float>x(n),y(n),l(n),r(n),mono(n);for(int i=0;i<n;++i)x[size_t(i)]=y[size_t(i)]=.05f*std::sin(float(i*.1));
  a.processStereo(x.data(),y.data(),l.data(),r.data(),n);c.processMono(x.data(),mono.data(),n);
  for(int i=0;i<n;++i){double u,v,g;b.processSampleStereo(x[size_t(i)],y[size_t(i)],u,v,g);CHECK(std::abs(float(u)-l[size_t(i)])<1e-7);CHECK(std::abs(l[size_t(i)]-r[size_t(i)])<1e-7f);CHECK(l[size_t(i)]==mono[size_t(i)]);}
  // Low-level unity confirms no +6 dB M/S normalization error.
  Core d;d.setInputDriveDb(0);d.reset();double u,v,g;d.processSampleStereo(1e-7,1e-7,u,v,g);CHECK(std::abs(u/1e-7-1)<1e-5);
 }
 for(int cycle=0;cycle<6;++cycle){gold::Processor p;const int channels=cycle%2?1:2;const int n=cycle%2?7:128;double sr=cycle%3==0?96000:48000;p.setPlayConfigDetails(channels,channels,sr,n);p.prepareToPlay(sr,n);juce::AudioBuffer<float>b(channels,n);juce::MidiBuffer m;
  CHECK(p.getLatencySamples()==0);CHECK(p.getParameters().size()==8);
  for(int preset=0;preset<3;++preset){p.setCurrentProgram(preset);p.reset();for(int k=0;k<100;++k){for(int i=0;i<n;++i)for(int c=0;c<channels;++c)b.setSample(c,i,.25f*std::sin(float((k*n+i)*.1+c*.3)));p.processBlock(b,m);for(int c=0;c<channels;++c)for(int i=0;i<n;++i)CHECK(std::isfinite(b.getSample(c,i)));}}
  for(int i=0;i<7;++i){auto* q=p.state.getParameter(gold::specs[size_t(i)].id);auto text=q->getText(q->getValue(),128);CHECK(std::abs(q->getValueForText(text)-q->getValue())<.005f);}
  p.setCurrentProgram(1);p.selectSlot(1);p.setReal(5,7);p.selectSlot(0);CHECK(std::abs(p.value(5)+6)<.01);p.selectSlot(1);CHECK(std::abs(p.value(5)-7)<.01);
  juce::MemoryBlock bytes;p.getStateInformation(bytes);gold::Processor restored;restored.setStateInformation(bytes.getData(),int(bytes.getSize()));for(int i=0;i<8;++i)CHECK(std::abs(p.value(i)-restored.value(i))<.01);CHECK(restored.selectedSlot()==1);restored.selectSlot(0);CHECK(std::abs(restored.value(5)+6)<.01);
  p.state.getParameter("bypass")->setValueNotifyingHost(1);p.reset();b.clear();for(int i=0;i<n;++i)for(int c=0;c<channels;++c)b.setSample(c,i,.123f);p.processBlock(b,m);for(int c=0;c<channels;++c)for(int i=0;i<n;++i)CHECK(std::abs(b.getSample(c,i)-.123f)<1e-7);
  p.state.getParameter("bypass")->setValueNotifyingHost(0);p.reset();b.clear();b.setSample(0,0,std::numeric_limits<float>::quiet_NaN());p.processBlock(b,m);for(int c=0;c<channels;++c)for(int i=0;i<n;++i)CHECK(std::isfinite(b.getSample(c,i)));
  p.reset();b.clear();allocations=0;counting=true;for(int k=0;k<100;++k)p.processBlock(b,m);counting=false;CHECK(allocations==0);std::printf("AUDIO_ALLOC cycle=%d count=%d\n",cycle,allocations.load());
  if(cycle<3){std::unique_ptr<juce::AudioProcessorEditor> e(p.createEditor());for(const auto& s:gold::specs){auto* slider=dynamic_cast<juce::Slider*>(find(*e,s.id));CHECK(slider);if(slider){slider->setValue(s.hi,juce::sendNotificationSync);CHECK(std::abs(p.state.getRawParameterValue(s.id)->load()-s.hi)<.01);}}
   auto* reset=dynamic_cast<juce::Button*>(find(*e,"reset"));CHECK(reset);if(reset)reset->onClick();for(int i=0;i<7;++i)CHECK(std::abs(p.value(i)-gold::specs[size_t(i)].initial)<.01);
   if(cycle==0){p.setCurrentProgram(1);auto dir=juce::SystemStats::getEnvironmentVariable("GOLD_QA_SNAPSHOT",{});if(dir.isNotEmpty()){juce::Image image(juce::Image::ARGB,e->getWidth(),e->getHeight(),true);juce::Graphics g(image);e->paintEntireComponent(g,true);auto out=juce::File(dir).createOutputStream();if(out){out->setPosition(0);out->truncate();juce::PNGImageFormat().writeImageToStream(image,*out);}}}
   e.reset();}
 }
 std::printf("GOLD: %d checks, %d failures\n",checks,failures);return failures?1:0;}
