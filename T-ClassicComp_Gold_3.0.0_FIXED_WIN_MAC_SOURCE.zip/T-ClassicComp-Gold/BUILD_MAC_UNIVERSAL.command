#!/bin/bash
set -euo pipefail
TSTUDIO_DIR="$(cd -- "$(dirname -- "$0")" && pwd)"
TSTUDIO_BUILD="$TSTUDIO_DIR/build/mac-universal"
cmake -S "$TSTUDIO_DIR" -B "$TSTUDIO_BUILD" -DCMAKE_BUILD_TYPE=Release '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64' -DBUILD_TESTING=OFF -DTSTUDIO_USE_INSTALLED_JUCE=OFF
cmake --build "$TSTUDIO_BUILD" --config Release --target TClassicGold_VST3 --parallel 2
TSTUDIO_BUNDLE="$TSTUDIO_BUILD/TClassicGold_artefacts/Release/VST3/T-ClassicComp Gold.vst3"
TSTUDIO_EXECUTABLE="$TSTUDIO_BUNDLE/Contents/MacOS/T-ClassicComp Gold"
test -f "$TSTUDIO_EXECUTABLE"
lipo -verify_arch arm64 x86_64 "$TSTUDIO_EXECUTABLE"
TSTUDIO_EXPORT="$TSTUDIO_DIR/_EXPORT_MAC/Build-$(date +%Y%m%d-%H%M%S)-$$"
mkdir -p "$TSTUDIO_EXPORT"
ditto "$TSTUDIO_BUNDLE" "$TSTUDIO_EXPORT/T-ClassicComp Gold.vst3"
codesign --force --deep --sign - "$TSTUDIO_EXPORT/T-ClassicComp Gold.vst3"
codesign --verify --deep --strict "$TSTUDIO_EXPORT/T-ClassicComp Gold.vst3"
echo "BUILD AND EXPORT COMPLETE: $TSTUDIO_EXPORT"
open "$TSTUDIO_EXPORT"
