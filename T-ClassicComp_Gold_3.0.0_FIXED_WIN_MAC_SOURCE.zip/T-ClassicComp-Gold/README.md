# T-ClassicComp Gold 3.0.0

Bản riêng theo mục tiêu **bố cục vàng 7 núm và chất nén classic** trong ảnh T-RackS CS Classic Comp anh gửi. Thương hiệu, hình vẽ và ID plugin là T Studio. **Không xác nhận âm thanh/thuật toán giống IK Multimedia 100%.**

Đây là **mã nguồn kèm BAT build Windows và script build macOS**, có sẵn JUCE 8.0.12. Chưa có VST3 Windows/macOS biên dịch sẵn trong ZIP. Đã build, nạp và chạy VST3 Linux; chưa thử MSVC/Cubase 15 Windows hoặc macOS.

## Sử dụng

Mặt máy gồm Sidechain HPF, Attack, Release, Stereo Enhancement, Ratio, Input Drive, Output; đồng hồ kim đo Gain Reduction; Bypass; Reset; preset và 4 ô so sánh A/B/C/D.

- `Vocal Start`: HPF 76 Hz, Attack 25 ms, Release 250 ms, Ratio 3.1, Stereo 0, Input 0, Output 0.
- `Photo Reference`: cùng các thông số trên, **Input −6 dB, Output +3 dB**, theo phần số đọc được trong ảnh. Đây là thiết lập tham khảo trong ảnh, không gọi là preset mặc định của hãng.
- `Gentle Vocal`: Ratio 2.2, Attack 32 ms, Release 430 ms, Input −3, Output +1.
- Reset trở về `Vocal Start` và tắt Bypass, không gọi reset mạch từ luồng giao diện.
- Khi chuyển A/B/C/D, ô đang dùng lưu lại 7 núm trước khi gọi ô khác. Bypass dùng chung. Các ô được lưu cùng project trong DAW.
- Mono và Stereo được hỗ trợ. Stereo Enhancement chỉ đổi thành phần Side, nên không mở rộng một nguồn mono có L=R hoàn toàn.
- SC HPF lọc tín hiệu dò nén, không cắt bass trực tiếp của vocal. Tăng HPF sẽ làm bass kích nén ít hơn.
- Bypass crossfade 5 ms; không có lookahead/FIR nên báo host **0 sample latency**. Không bao gồm độ trễ soundcard, buffer hay plugin khác trong dây xử lý.

Gold chạy trực tiếp phương thức feedback M/S trong lõi C++ gửi vào đã hiệu chỉnh. Không chạy các lớp Clean/Opto, Auto Threshold, Auto Gain, Air, saturation Drive, Soft Clip, External Sidechain, Mix hoặc Lookahead của bản cũ. Input Drive vẫn là núm drive đầu vào cho mạch nén, không phải tầng saturation bổ sung. Các tính năng cũ và nguyên gói gốc được giữ tại `Reference/ORIGINAL_UPLOAD.zip`.

## Build Windows x64

1. Giải nén toàn bộ ZIP ra thư mục mới, không bỏ thư mục `third_party`.
2. Cài Visual Studio 2022/2019/2026: Desktop development with C++, MSVC x64 và Windows SDK; CMake 3.22+.
3. Chạy **`BUILD_RELEASE.bat`**. Script tìm CMake trong PATH hoặc Visual Studio; không tải thêm JUCE khi build.
4. Sau `BUILD AND EXPORT COMPLETE`, lấy nguyên thư mục `T-ClassicComp Gold.vst3` trong `_EXPORT/Build-.../VST3`.
5. Đóng Cubase, chép nguyên thư mục đó vào `C:\Program Files\Common Files\VST3`, mở Cubase và quét lại plugin.

Log nằm trong `_BUILD_LOGS`. Script kiểm tra binary PE32+ x64, chỉ công bố bản xuất hoàn chỉnh, giữ lại bản xuất thành công trước khi có lỗi. Đây là công cụ build/xuất, không phải installer tự cài vào Program Files.

Gold dùng tên/ID mới, **không tự thay thế T-ClassicComp cũ hoặc nạp state cũ**. Vì đường nén đã thay đổi, nên dùng bản mới để so A/B, giữ lại project/bản cũ để đối chiếu. Khi so với hãng, dùng cùng đầu vào, cùng thông số và cân mức âm lượng đầu ra; lớn hơn không chứng minh chất nén giống hơn.

## Build macOS

Cần Xcode Command Line Tools và CMake 3.22+. Chạy `BUILD_MAC_UNIVERSAL.command` (hoặc `bash BUILD_MAC_UNIVERSAL.command`). Script yêu cầu Universal arm64+x86_64, kiểm tra lipo và ký ad-hoc rồi xuất sang `_EXPORT_MAC`. **Ở lượt này chỉ kiểm tra cú pháp script; chưa chạy compile/lipo/codesign trên Mac.** Có thể build bằng CMake với kiến trúc riêng nếu máy/SDK không hỗ trợ Universal.

## Kiểm tra và phạm vi

Xem `Validation/REVIEW.md`, số đo, ảnh mặt máy và log. Có kiểm tra đáp ứng thực sự của các núm, mono/stereo, chuẩn hóa M/S, preset/state/A-B, bypass, giá trị nhập dạng chữ, audio NaN và cấp phát bộ nhớ; có ASan/UBSan cho code của dự án và host VST3 Linux thật.

Không có binary hãng/bộ thu A/B âm thanh hãng trong file gửi vào. Ảnh chỉ cung cấp bố cục và các thiết lập nhìn thấy. Các địa chỉ binary và chữ “bit-accurate” trong tài liệu gốc chưa phải bằng chứng model trùng hãng; mã gốc và bản Gold đều cần phép đo đối chiếu với plugin tham chiếu để hiệu chỉnh sát hơn.
