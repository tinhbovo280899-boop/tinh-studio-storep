/**
 * @file TR5_ClassicComp_DSP.hpp
 * @brief Corrective revision of the submitted C++ compressor model for
 *        `TR5 Classic Comp.vst3` (IK::KIS::FX::TR3::ClassicComp::Module)
 *
 * Original source attributes the following addresses to
 * `TR5 Classic Comp.vst3` (Version 5.10.3, VST 3.6.13, MSVC 14.29):
 *   - Module Constructor:          0x18044B1D0 - 0x18044B55B
 *   - Module Reset:                0x18044B810 - 0x18044B933
 *   - Parameter Setters:           0x18044B940 - 0x18044BA45
 *   - Attack/Release RC Network:   0x18044D970 - 0x18044DD64
 *   - Input/Stereo/M-S Matrix:     0x18044DD70 - 0x18044DDF1
 *   - Sidechain HPF Bilinear:      0x18044DE00 - 0x18044DECC
 *   - Stereo Feedback DSP Loop:    0x18044BA90 - 0x18044C1D7
 *   - Mono Feedback DSP Loop:      0x18044C1E0 - 0x18044C619
 *   - External Sidechain Loop:     0x18044C620 - 0x18044D969
 *   - 1-Pole Parameter Smoother:   0x1804713C0 - 0x180471C80
 */

#pragma once
#include <cmath>
#include <algorithm>
#include <cstdint>

namespace IK {
namespace KIS {
namespace FX {
namespace TR3 {
namespace ClassicComp {

/**
 * @brief 1-Pole Bilinear Parameter Smoother (0x1804713C0 / 0x180476590)
 * Smooths parameter changes with a 100 Hz low-pass filter
 * to eliminate zipper noise inside the feedback loop.
 */
struct ParameterSmoother {
    float sampleRate = 44100.0f;
    float cutoffHz   = 100.0f;   // 0x42C80000 (100.0f) at 0x1804713EA
    float targetVal  = 1.0f;     // offset +0x14
    float currentVal = 1.0f;     // offset +0x1C
    float b0         = 1.0f;     // offset +0x28
    float b1         = 0.0f;     // offset +0x2C
    float a1         = 0.0f;     // offset +0x30
    float z1         = 0.0f;     // offset +0x34
    int   state      = 4;        // offset +0x20 (0 = filtering, 4 = settled)

    void setSampleRate(float fs) {
        sampleRate = std::isfinite(fs)?std::clamp(fs,8000.f,384000.f):48000.f;
        // Bilinear transform 1-pole LPF (0x180476590):
        // w = pi * cutoffHz; norm = 1.0f / (w + fs)
        const float w    = 3.14159274f * cutoffHz;
        const float norm = 1.0f / (w + sampleRate);
        b0 = w * norm;
        b1 = w * norm;
        a1 = (w - sampleRate) * norm;
        reset(targetVal);
    }

    void reset(float val) {
        targetVal  = val;
        currentVal = val;
        // Steady-state z1 initialization (0x180475850)
        z1    = val * b1 - (val * (b0 + b1) / (a1 + 1.0f)) * a1;
        state = 4;
    }

    void snapToTarget() {
        reset(targetVal);
    }

    void setTarget(float val) {
        targetVal = val;
        state     = 0;
    }

    inline void tick() {
        if (state == 0) {
            // DF-II Transposed 1st-order filter step (0x1804719FD)
            float y = targetVal * b0 + z1;
            z1      = targetVal * b1 - y * a1;
            currentVal = y;
            if (std::fabs(currentVal - targetVal) <= 0.001f) {
                currentVal = targetVal;
                state      = 4;
            }
        }
    }

    inline float apply(float x) const {
        return x * currentVal;
    }
};

/**
 * @brief Peak Level Detector / Meter Ballistics (0x180471020 / 0x18044BC01)
 * Configured at 0x18044B5F9 with Attack = 100.0 ms, Release = 350.0 ms.
 */
struct LevelEnvelopeDetector {
    float sampleRate  = 44100.0f;
    float envState    = 0.0f;    // offset +0x388
    float attackMs    = 100.0f;  // 0x180574458 (100.0f)
    float releaseMs   = 350.0f;  // 0x1805C9030 (350.0f)
    float attackCoef  = 0.0f;    // offset +0x394
    float releaseCoef = 0.0f;    // offset +0x398
    float scale       = 1.0f;    // offset +0x39C

    static float computeTimeCoef(float timeMs, float fs) {
        // 0x180471310: base = 10^(-2.0 / 20.0) = 0.79432823f (-2 dB constant)
        if (timeMs <= 0.0f || fs <= 0.0f) return 0.0f;
        const float base = 0.79432823f; // 10^(-0.1)
        return std::pow(base, 1000.0f / (timeMs * fs));
    }

    void setSampleRate(float fs) {
        sampleRate  = std::isfinite(fs)?std::clamp(fs,8000.f,384000.f):48000.f;
        attackCoef  = computeTimeCoef(attackMs, sampleRate);
        releaseCoef = computeTimeCoef(releaseMs, sampleRate);
    }

    void reset() {
        envState = 0.0f;
    }

    inline float process(float inAbs) {
        // 0x18044BC10: Asymmetric 1-pole ballistics
        float diff = envState - inAbs;
        if (inAbs < envState) {
            envState = inAbs + diff * releaseCoef;
        } else {
            envState = inAbs + diff * attackCoef;
        }
        return envState * scale;
    }
};

/**
 * @brief Core DSP Engine of IK Multimedia T-RackS Classic Compressor
 *        (`IK::KIS::FX::TR3::ClassicComp::Module`)
 */
class ClassicCompModule {
public:
    // User Parameters (with exact binary defaults from 0x18044B1FD - 0x18044B21A)
    float sampleRate        = 44100.0f; // +0x04
    float attackTimeSec     = 0.032f;   // +0x0C (UI Default: 32.0 ms, Range: 12.0..82.0 ms)
    float releaseTimeSec    = 0.430f;   // +0x10 (UI Default: 430.0 ms, Range: 29.0..1400.0 ms)
    float inputDriveDb      = -3.3f;    // +0x14 (UI Default: -3.3 dB, Range: -18..+18 dB)
    float stereoEnhanceDb   = 0.0f;     // +0x18 (Default: 0.0 dB, Range: -5..+5 dB)
    float sideChainHpfHz    = 76.0f;    // +0x1C (UI Default: 76.0 Hz, Range: 32.0..218.0 Hz)
    float ratioValue        = 3.1f;     // UI Ratio 1.5:1 .. 4.68:1 (Default: 3.1:1)
    float outputGainDb      = 0.0f;     // Output Trim (-15..+15 dB)

    // Internal Feedback Envelope States (double precision in binary: +0x28 .. +0x1C0)
    double envM_fast        = 0.0;      // +0x28
    double envM_slow        = 0.0;      // +0x30
    double envS_fast        = 0.0;      // +0x38
    double envS_slow        = 0.0;      // +0x40

    // Sidechain HPF Coefficients & States (Mid and Side)
    double hpfM_b0 = 1.0, hpfM_b1 = -1.0, hpfM_a1 = 0.0; // +0x48, +0x50, +0x58
    double hpfM_x1 = 0.0, hpfM_y1 = 0.0;                 // +0x60, +0x68
    double hpfS_b0 = 1.0, hpfS_b1 = -1.0, hpfS_a1 = 0.0; // +0x70, +0x78, +0x80
    double hpfS_x1 = 0.0, hpfS_y1 = 0.0;                 // +0x88, +0x90

    // Attack Pre-Filter & Dual-Pole Bilinear Filter Coefficients (Mid & Side)
    double attPre_b0  = 0.0, attPre_b1  = 0.0, attPre_a1  = 0.0; // +0x98, +0xA0, +0xA8
    double attFast_b0 = 0.0, attFast_b1 = 0.0, attFast_a1 = 0.0; // +0x108..+0x118
    double attSlow_b0 = 0.0, attSlow_b1 = 0.0, attSlow_a1 = 0.0; // +0x158..+0x168

    // Filter Delay States for M (Sum) Envelope
    double attM_x1 = 0.0, attM_preY1 = 0.0, attM_x1_copy = 0.0, attM_slowIn1 = 0.0; // +0xB0..+0xC8
    double attM_fastX1 = 0.0, attM_fastY1 = 0.0; // +0x120, +0x128
    double attM_slowX1 = 0.0, attM_slowY1 = 0.0; // +0x170, +0x178

    // Filter Delay States for S (Diff) Envelope
    double attS_x1 = 0.0, attS_preY1 = 0.0, attS_x1_copy = 0.0, attS_slowIn1 = 0.0; // +0xE8..+0x100
    double attS_fastX1 = 0.0, attS_fastY1 = 0.0; // +0x148, +0x150
    double attS_slowX1 = 0.0, attS_slowY1 = 0.0; // +0x198, +0x1A0

    // Release Exponential Decay Multipliers (+0x1A8 .. +0x1C0)
    double relFast_coef = 0.0; // +0x1A8 / +0x1B8
    double relSlow_coef = 0.0; // +0x1B0 / +0x1C0

    // Metering outputs
    float meterGainReductionLinear = 1.0f; // +0x20
    float minGainReductionL        = 1.0f; // +0x1C8
    float minGainReductionR        = 1.0f; // +0x1CC

    // 6 Internal Parameter Smoothers (+0x1D0, +0x218, +0x260, +0x2A8, +0x2F0, +0x338)
    ParameterSmoother smoothDriveM;      // +0x1D0
    ParameterSmoother smoothDriveS;      // +0x218
    ParameterSmoother smoothRatioM;      // +0x260
    ParameterSmoother smoothRatioS;      // +0x2A8
    ParameterSmoother smoothStereoWidth; // +0x2F0
    ParameterSmoother smoothOutputGain;  // +0x338
    LevelEnvelopeDetector grDetector;    // +0x380

    ClassicCompModule() {
        smoothRatioM.reset(2.6f);      // 3.1f - 0.5f = 2.6f (0x18044B3D0)
        smoothRatioS.reset(2.6f);
        smoothOutputGain.reset(1.0f);  // 0x1805679F0 (1.0f) at 0x18044B3F8
        setSampleRate(44100.0f);
        reset();
    }

    static inline float dbToLinear(float db) {
        // 0x180449BD0: exp(db * 0.115129254758358f) where ln(10)/20 = 0.115129254758358
        return std::exp(db * 0.115129254758358f);
    }

    static inline float linearToDb(float lin) {
        // 0x180449BB0: log(lin) * 8.68588924407959f where 20/ln(10) = 8.68588924407959
        return std::log(std::max(lin, 1e-12f)) * 8.68588924407959f;
    }

    /**
     * @brief 1st-Order Bilinear Transform Filter Designer (0x180471C90)
     * Maps analog transfer function H(s) = (b1_s * s + b0_s) / (a1_s * s + a0_s)
     * into digital Z-domain via s <- 2 * fs * (1 - z^-1) / (1 + z^-1).
     */
    static inline void bilinear1stOrder(
        float b1_s, float b0_s, float a1_s, float a0_s, float fs,
        double& out_b0, double& out_b1, double& out_a1)
    {
        const float twoFs = 2.0f * fs;
        const float A     = twoFs * a1_s;
        const float B     = twoFs * b1_s;
        const float invD  = 1.0f / (A + a0_s);
        out_b0 = static_cast<double>((B + b0_s) * invD);
        out_b1 = static_cast<double>((b0_s - B) * invD);
        // out_a1 is negated at 0x18044DB5E / 0x18044DEA2 for additive feedback difference equation
        out_a1 = -static_cast<double>((a0_s - A) * invD);
    }

    /**
     * @brief Reset all internal states (0x18044B810)
     */
    void reset() {
        grDetector.reset();
        smoothDriveM.snapToTarget();
        smoothDriveS.snapToTarget();
        smoothRatioM.snapToTarget();
        smoothRatioS.snapToTarget();
        smoothStereoWidth.snapToTarget();
        smoothOutputGain.snapToTarget();

        envM_fast = envM_slow = 0.0;
        envS_fast = envS_slow = 0.0;
        hpfM_x1 = hpfM_y1 = 0.0;
        hpfS_x1 = hpfS_y1 = 0.0;
        attM_x1 = attM_preY1 = attM_x1_copy = attM_slowIn1 = 0.0;
        attM_fastX1 = attM_fastY1 = 0.0;
        attM_slowX1 = attM_slowY1 = 0.0;
        attS_x1 = attS_preY1 = attS_x1_copy = attS_slowIn1 = 0.0;
        attS_fastX1 = attS_fastY1 = 0.0;
        attS_slowX1 = attS_slowY1 = 0.0;
        meterGainReductionLinear = 1.0f;
        minGainReductionL = 1.0f;
        minGainReductionR = 1.0f;
    }

    void setSampleRate(float fs) {
        sampleRate = std::isfinite(fs)?std::clamp(fs,8000.f,384000.f):48000.f;
        grDetector.setSampleRate(sampleRate);
        smoothDriveM.setSampleRate(sampleRate);
        smoothDriveS.setSampleRate(sampleRate);
        smoothRatioM.setSampleRate(sampleRate);
        smoothRatioS.setSampleRate(sampleRate);
        smoothStereoWidth.setSampleRate(sampleRate);
        smoothOutputGain.setSampleRate(sampleRate);
        updateAttackReleaseCoeffs();
        updateInputAndStereoCoeffs();
        updateSidechainHpfCoeffs();
    }

    /**
     * @brief Parameter Setters (0x18044B940 - 0x18044BA45)
     */
    void setAttackTimeMs(float attackMs) {
        attackMs=std::isfinite(attackMs)?std::clamp(attackMs,12.f,82.f):25.f;
        // 0x18044B940: multiplies ms by 0.001f (0x1805742A4)
        float sec = std::max(0.0001f, attackMs * 0.001f);
        if (std::fabs(sec - attackTimeSec) > 1e-6f) {
            attackTimeSec = sec;
            updateAttackReleaseCoeffs();
        }
    }

    void setReleaseTimeMs(float releaseMs) {
        releaseMs=std::isfinite(releaseMs)?std::clamp(releaseMs,29.f,1400.f):250.f;
        // 0x18044B960: multiplies ms by 0.001f (0x1805742A4)
        float sec = std::max(0.001f, releaseMs * 0.001f);
        if (std::fabs(sec - releaseTimeSec) > 1e-6f) {
            releaseTimeSec = sec;
            updateAttackReleaseCoeffs();
        }
    }

    void setInputDriveDb(float driveDb) {
        driveDb=std::isfinite(driveDb)?std::clamp(driveDb,-18.f,18.f):0.f;
        // 0x18044B9A0
        if (std::fabs(driveDb - inputDriveDb) > 1e-4f) {
            inputDriveDb = driveDb;
            updateInputAndStereoCoeffs();
        }
    }

    void setStereoEnhancementDb(float enhanceDb) {
        enhanceDb=std::isfinite(enhanceDb)?std::clamp(enhanceDb,-5.f,5.f):0.f;
        // 0x18044B9B0
        if (std::fabs(enhanceDb - stereoEnhanceDb) > 1e-4f) {
            stereoEnhanceDb = enhanceDb;
            updateInputAndStereoCoeffs();
        }
    }

    void setRatio(float ratio) {
        ratio=std::isfinite(ratio)?std::clamp(ratio,1.5f,4.68f):3.1f;
        // 0x18044B9C0: subtracts 0.5f (0x1805742F4) from Ratio [1.5 .. 4.68]
        ratioValue = std::max(1.0f, ratio);
        float target = std::max(0.0f, ratioValue - 0.5f);
        if (std::fabs(target - smoothRatioM.targetVal) > 1e-4f) {
            smoothRatioM.setTarget(target);
            smoothRatioS.setTarget(target);
        }
    }

    void setRatioNormalized(float normVal) {
        // Maps [0..1] across TR5 hardware range [1.5 .. 4.68]
        setRatio(1.5f + std::clamp(normVal, 0.0f, 1.0f) * (4.68f - 1.5f));
    }

    void setSidechainHpfHz(float freqHz) {
        freqHz=std::isfinite(freqHz)?std::clamp(freqHz,32.f,218.f):76.f;
        // 0x18044BA10
        float f = std::max(1.0f, freqHz);
        if (std::fabs(f - sideChainHpfHz) > 1e-3f) {
            sideChainHpfHz = f;
            updateSidechainHpfCoeffs();
        }
    }

    void setOutputGainDb(float outDb) {
        outDb=std::isfinite(outDb)?std::clamp(outDb,-15.f,15.f):0.f;
        // 0x18044BA20
        if (std::fabs(outDb - outputGainDb) > 1e-4f) {
            outputGainDb = outDb;
            smoothOutputGain.setTarget(dbToLinear(outDb));
        }
    }

    /**
     * @brief Exact Coupled Dual-RC Attack/Release Network Calculation (0x18044D970)
     */
    void updateAttackReleaseCoeffs() {
        // Hardware circuit constants from .rdata:
        // C1 = 1.6e-6 F (0x1805C9008)
        // C2 = 4.7e-6 F (0x1805C900C)
        // C_sum = 6.3e-6 F (0x1805C9010)
        // R_fixed = 20000.0 Ohm (0x1805C8C44)
        // Scale = 0.032 (0x1805C9028)
        constexpr float kC1     = 1.6e-6f;
        constexpr float kC2     = 4.7e-6f;
        constexpr float kCsum   = 6.3e-6f;
        constexpr float kRfixed = 20000.0f;
        constexpr float kScale  = 0.032f;

        const double rRel=double(releaseTimeSec)/kC2,rAtt=double(attackTimeSec)/kC1;
        const double numA=rRel*kRfixed*kCsum,den=(rRel*kScale)*kC2*rAtt;
        const double bTerm=(((rRel*kC2)+kScale)*rAtt+numA)/den;
        const double cTerm=(rRel+kRfixed+rAtt)/den;
        const double root=std::sqrt(std::max(0.0,bTerm*bTerm-4*cTerm));
        if(sampleRate<=0)return;
        const double pole2=.5*(bTerm+root),pole1=cTerm/pole2;

        // 1. Pre-filter stage (0x18044DADC):
        bilinear1stOrder(0.0f, pole1, 1.0f, pole1, sampleRate, attPre_b0, attPre_b1, attPre_a1);

        // 2. Fast Attack Pole (0x18044DBA1):
        float a1_fast = (1.0f / (rAtt * kC1)) / pole1;
        float a0_fast = (1.0f / (rRel * kC1 * kC2 * rAtt)) / pole1;
        bilinear1stOrder(a1_fast, a0_fast, 1.0f, pole2, sampleRate, attFast_b0, attFast_b1, attFast_a1);

        // 3. Slow Attack Pole (0x18044DC54):
        constexpr float kC1C2 = 1.504e-7f; // 0x1805C9004 (kScale * kC2)
        float a1_slow = (1.0f / (rAtt * kC2)) / pole1;
        float a0_slow = (1.0f / (rAtt * kC1C2)) / pole1;
        bilinear1stOrder(a1_slow, a0_slow, 1.0f, pole2, sampleRate, attSlow_b0, attSlow_b1, attSlow_a1);

        // 4. Release Exponential Decay Multipliers (0x18044DCBD - 0x18044DD33):
        float twoOverFs = 2.0f / sampleRate;
        relFast_coef = std::pow(10.0, -static_cast<double>(twoOverFs / kScale));
        relSlow_coef = std::pow(10.0, -static_cast<double>(twoOverFs / (rRel * kC2)));
    }

    /**
     * @brief Input Drive & Stereo Enhancement Matrix (0x18044DD70)
     */
    void updateInputAndStereoCoeffs() {
        // 1. Mid Input Drive = 10^(inputDriveDb / 20)
        smoothDriveM.setTarget(dbToLinear(inputDriveDb));

        // 2. Side Input Drive = 10^((inputDriveDb + 6.0f + 0.2f * stereoEnhanceDb) / 20)
        float sideDriveDb = inputDriveDb + 6.0f + 0.2f * stereoEnhanceDb;
        smoothDriveS.setTarget(dbToLinear(sideDriveDb));

        // 3. Post-Compression Side Makeup = 10^((0.8f * stereoEnhanceDb - 6.0f) / 20)
        float sideOutDb = 0.8f * stereoEnhanceDb - 6.0f;
        smoothStereoWidth.setTarget(dbToLinear(sideOutDb));
    }

    /**
     * @brief Sidechain High-Pass Filter Bilinear Design (0x18044DE00)
     */
    void updateSidechainHpfCoeffs() {
        if (sampleRate <= 0.0f) return;
        // Warp & scale cutoff frequency (0x18044DE26 - 0x18044DE6B):
        float wc = 2.0f * 3.14159274f * std::max(sideChainHpfHz, 0.1f);
        float scale = (200.0f / wc) * (2.5f / 1.3f);
        float a1_s  = 1.0f / scale;
        float a0_s  = wc   / scale;

        // H_HPF(s) = (a1_s * s + 0) / (a1_s * s + a0_s)
        bilinear1stOrder(a1_s, 0.0f, a1_s, a0_s, sampleRate, hpfM_b0, hpfM_b1, hpfM_a1);
        hpfS_b0 = hpfM_b0;
        hpfS_b1 = hpfM_b1;
        hpfS_a1 = hpfM_a1;
    }

    /**
     * @brief Step the coupled dual-RC envelope network for Mid or Side channel
     */
    inline void stepEnvelopeM(double rectM, double totalEnvM) {
        constexpr double kDenormFloor = 1.0e-22; // 0x1805C9020
        if (rectM > totalEnvM) {
            double v4     = rectM * attPre_b0;
            double fastIn = v4 + attM_x1 * attPre_b1 + attM_preY1 * attPre_a1;
            double slowIn = v4 + attM_x1_copy * attPre_b1 + attM_slowIn1 * attPre_a1;
            attM_x1       = rectM;
            attM_preY1    = fastIn;

            double newFast = fastIn * attFast_b0 + attM_fastX1 * attFast_b1 + attM_fastY1 * attFast_a1;
            attM_fastX1    = fastIn;
            attM_fastY1    = newFast;
            envM_fast      = newFast;

            attM_x1_copy   = rectM;
            attM_slowIn1   = slowIn;

            double newSlow = slowIn * attSlow_b0 + attM_slowX1 * attSlow_b1 + attM_slowY1 * attSlow_a1;
            attM_slowX1    = slowIn;
            attM_slowY1    = newSlow;
            envM_slow      = newSlow;
        } else {
            double newFast = attM_fastY1 * relFast_coef;
            if (newFast < kDenormFloor) newFast = 0.0;
            envM_fast   = newFast;
            attM_fastX1 = newFast;
            attM_fastY1 = newFast;
            attM_x1     = newFast;
            attM_preY1  = newFast;

            double newSlow = attM_slowY1 * relSlow_coef;
            if (newSlow < kDenormFloor) newSlow = 0.0;
            envM_slow    = newSlow;
            attM_x1_copy = newSlow;
            attM_slowIn1 = newSlow;
            attM_slowX1  = newSlow;
            attM_slowY1  = newSlow;
        }
    }

    inline void stepEnvelopeS(double rectS, double totalEnvS) {
        constexpr double kDenormFloor = 1.0e-22; // 0x1805C9020
        if (rectS > totalEnvS) {
            double v4     = rectS * attPre_b0;
            double fastIn = v4 + attS_x1 * attPre_b1 + attS_preY1 * attPre_a1;
            double slowIn = v4 + attS_x1_copy * attPre_b1 + attS_slowIn1 * attPre_a1;
            attS_x1       = rectS;
            attS_preY1    = fastIn;

            double newFast = fastIn * attFast_b0 + attS_fastX1 * attFast_b1 + attS_fastY1 * attFast_a1;
            attS_fastX1    = fastIn;
            attS_fastY1    = newFast;
            envS_fast      = newFast;

            attS_x1_copy   = rectS;
            attS_slowIn1   = slowIn;

            double newSlow = slowIn * attSlow_b0 + attS_slowX1 * attSlow_b1 + attS_slowY1 * attSlow_a1;
            attS_slowX1    = slowIn;
            attS_slowY1    = newSlow;
            envS_slow      = newSlow;
        } else {
            double newFast = attS_fastY1 * relFast_coef;
            if (newFast < kDenormFloor) newFast = 0.0;
            envS_fast   = newFast;
            attS_fastX1 = newFast;
            attS_fastY1 = newFast;
            attS_x1     = newFast;
            attS_preY1  = newFast;

            double newSlow = attS_slowY1 * relSlow_coef;
            if (newSlow < kDenormFloor) newSlow = 0.0;
            envS_slow    = newSlow;
            attS_x1_copy = newSlow;
            attS_slowIn1 = newSlow;
            attS_slowX1  = newSlow;
            attS_slowY1  = newSlow;
        }
    }

    /**
     * @brief Single-sample Stereo M/S Feedback Compression step (with optional External Sidechain & HPF toggle)
     * Returns linear gain reduction factor in `outGrLinear` (1.0 = no reduction, < 1.0 = gain reduction).
     */
    inline void processSampleStereo(
        double inL, double inR,
        double& outL, double& outR,
        double& outGrLinear,
        bool hpfOn = true,
        const double* extScL = nullptr,
        const double* extScR = nullptr)
    {
        inL=std::isfinite(inL)?std::clamp(inL,-64.0,64.0):0.0;
        inR=std::isfinite(inR)?std::clamp(inR,-64.0,64.0):0.0;
        constexpr double kAntiDenorm = 1.0e-35; // 0x1805C9018
        constexpr double kMinGain    = 0.01;    // 0x1805A6FC0 (-40 dB floor)

        double totalEnvM = envM_fast + envM_slow;
        double totalEnvS = envS_fast + envS_slow;

        smoothDriveM.tick();
        smoothDriveS.tick();
        smoothRatioM.tick();
        smoothRatioS.tick();
        smoothOutputGain.tick();
        smoothStereoWidth.tick();

        float envM_f32 = static_cast<float>(totalEnvM);
        float envS_f32 = static_cast<float>(totalEnvS);

        // Feedback gain factors before drive (in [0.01 .. 1.0])
        double grFactorM = std::clamp(1.0 - static_cast<double>(smoothRatioM.apply(envM_f32)), kMinGain, 1.0);
        double grFactorS = std::clamp(1.0 - static_cast<double>(smoothRatioS.apply(envS_f32)), kMinGain, 1.0);

        double gainM = std::max(kMinGain, static_cast<double>(smoothDriveM.currentVal) * grFactorM);
        double gainS = std::max(kMinGain, static_cast<double>(smoothDriveS.currentVal) * grFactorS);

        meterGainReductionLinear = grDetector.process(float(std::min(grFactorM,grFactorS)));
        outGrLinear = std::min(grFactorM, grFactorS);

        // Encode Stereo Input into Mid (L+R) and Side (L-R) and apply Feedback Gain
        double midCompressed  = (inL + inR) * gainM + kAntiDenorm;
        double sideCompressed = (inL - inR) * gainS + kAntiDenorm;

        // Detector source: internal feedback (0x18044BC44) or external sidechain (0x18044C620)
        double detM = midCompressed;
        double detS = sideCompressed;
        if (extScL != nullptr && extScR != nullptr) {
            detM = (*extScL + *extScR) * gainM + kAntiDenorm;
            detS = (*extScL - *extScR) * gainS + kAntiDenorm;
        }

        double scM = detM;
        double scS = detS;
        if (hpfOn) {
            scM = detM * hpfM_b0 + hpfM_x1 * hpfM_b1 + hpfM_y1 * hpfM_a1;
            hpfM_x1 = detM;
            hpfM_y1 = scM;

            scS = detS * hpfS_b0 + hpfS_x1 * hpfS_b1 + hpfS_y1 * hpfS_a1;
            hpfS_x1 = detS;
            hpfS_y1 = scS;
        }

        stepEnvelopeM(std::fabs(scM), totalEnvM);
        stepEnvelopeS(std::fabs(scS), totalEnvS);

        double mOut = static_cast<double>(smoothOutputGain.currentVal) * midCompressed;
        double sOut = static_cast<double>(smoothStereoWidth.currentVal) * (static_cast<double>(smoothOutputGain.currentVal) * sideCompressed);

        // 0.5 normalization compensates (L+R) + (L-R) = 2L so 0 dB InputDrive + 0 dB Output = Unity Gain (0 dB) below threshold
        outL = 0.5 * (mOut + sOut);
        outR = 0.5 * (mOut - sOut);
    }

    /**
     * @brief Main Stereo Feedback Compression Loop (0x18044BA90 - 0x18044C1D7)
     */
    void processStereo(const float* l,const float* r,float* ol,float* or_,int n){
        if(!l||!r||!ol||!or_||n<=0)return;
        for(int i=0;i<n;++i){double a,b,g;processSampleStereo(l[i],r[i],a,b,g);ol[i]=float(a);or_[i]=float(b);}
    }

    /**
     * @brief Mono Feedback Compression Loop (0x18044C1E0 - 0x18044C619)
     */
    void processMono(const float* in,float* out,int n){
        if(!in||!out||n<=0)return;
        for(int i=0;i<n;++i){double a,b,g;processSampleStereo(in[i],in[i],a,b,g);out[i]=float(a);}
    }
};

} // namespace ClassicComp
} // namespace TR3
} // namespace FX
} // namespace KIS
} // namespace IK
