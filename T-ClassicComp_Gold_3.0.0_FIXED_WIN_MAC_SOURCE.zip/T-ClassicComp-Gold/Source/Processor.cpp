#include "Processor.h"
namespace gold {
juce::AudioProcessorValueTreeState::ParameterLayout Processor::layout(){juce::AudioProcessorValueTreeState::ParameterLayout l;
 for(auto s:specs){juce::NormalisableRange<float> range(s.lo,s.hi,s.step);if(juce::String(s.id)=="release")range.setSkewForCentre(250);
 l.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{s.id,1},s.name,range,s.initial,juce::AudioParameterFloatAttributes().withLabel(s.unit)
 .withStringFromValueFunction([s](float v,int){if(std::abs(v)<s.step*.1f)v=0;return juce::String(v,s.step<.1f?2:s.step<1?1:0)+" "+s.unit;})
 .withValueFromStringFunction([](const juce::String& t){return t.getFloatValue();})));}
 l.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{"bypass",1},"Bypass",false));return l;}
Processor::Processor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),state(*this,nullptr,"TClassicGold3",layout()){
 for(size_t i=0;i<7;++i)raw[i]=state.getRawParameterValue(specs[i].id);raw[7]=state.getRawParameterValue("bypass");}
float Processor::value(int i) const noexcept {const float v=raw[size_t(i)]->load(std::memory_order_relaxed);if(i==7)return std::isfinite(v)&&v>=.5f?1.f:0.f;const auto& s=specs[size_t(i)];return std::isfinite(v)?juce::jlimit(s.lo,s.hi,v):s.initial;}
bool Processor::isBusesLayoutSupported(const BusesLayout& b) const{return b.getMainInputChannelSet()==b.getMainOutputChannelSet()&&(b.getMainOutputChannelSet()==juce::AudioChannelSet::mono()||b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo());}
void Processor::prepareToPlay(double sr,int){core.setSampleRate(float(std::isfinite(sr)&&sr>=8000&&sr<=384000?sr:48000));bypass.reset(core.sampleRate,.005);setLatencySamples(0);reset();}
void Processor::updateCore(){core.setSidechainHpfHz(value(0));core.setAttackTimeMs(value(1));core.setReleaseTimeMs(value(2));core.setStereoEnhancementDb(value(3));core.setRatio(value(4));core.setInputDriveDb(value(5));core.setOutputGainDb(value(6));}
void Processor::reset(){updateCore();core.reset();bypass.setCurrentAndTargetValue(hostBypass||value(7)>=.5f?1.f:0.f);grDb=0;inputDb=outputDb=-100;}
void Processor::processBlock(juce::AudioBuffer<float>& b,juce::MidiBuffer&){juce::ScopedNoDenormals guard;const int n=b.getNumSamples(),channels=std::min(2,b.getNumChannels());if(n<=0||channels<=0)return;
 updateCore();bypass.setTargetValue(hostBypass||value(7)>=.5f?1.f:0.f);float inPeak=0,outPeak=0,maxGR=0;auto* l=b.getWritePointer(0);auto* r=channels>1?b.getWritePointer(1):l;
 for(int i=0;i<n;++i){const float x=std::isfinite(l[i])?juce::jlimit(-64.f,64.f,l[i]):0, y=std::isfinite(r[i])?juce::jlimit(-64.f,64.f,r[i]):0;double u,v,g;
 core.processSampleStereo(x,y,u,v,g);float fade=bypass.getNextValue();float a=float(u)+(x-float(u))*fade,c=float(v)+(y-float(v))*fade;
 l[i]=std::abs(a)<1e-30f?0:a;if(channels>1)r[i]=std::abs(c)<1e-30f?0:c;
 inPeak=std::max({inPeak,std::abs(x),std::abs(y)});outPeak=std::max({outPeak,std::abs(a),std::abs(c)});maxGR=std::max(maxGR,float(-20*std::log10(std::max(g,.000001)))*(1-fade));}
 grDb=maxGR;inputDb=juce::Decibels::gainToDecibels(inPeak,-100.f);outputDb=juce::Decibels::gainToDecibels(outPeak,-100.f);}
void Processor::processBlockBypassed(juce::AudioBuffer<float>& b,juce::MidiBuffer& m){hostBypass=true;processBlock(b,m);hostBypass=false;}
void Processor::setReal(int i,float v){auto* p=state.getParameter(specs[size_t(i)].id);p->setValueNotifyingHost(p->convertTo0to1(v));}
void Processor::setCurrentProgram(int i){if(i<0||i>=3)return;for(int j=0;j<7;++j)setReal(j,presets[size_t(i)][size_t(j)]);program=i;}
void Processor::selectSlot(int index){const juce::ScopedLock lock(bankLock);if(index<0||index>3||index==currentSlot)return;for(int i=0;i<7;++i)slots[size_t(currentSlot)][size_t(i)]=value(i);currentSlot=index;for(int i=0;i<7;++i)setReal(i,slots[size_t(index)][size_t(i)]);}
void Processor::getStateInformation(juce::MemoryBlock& dst){const juce::ScopedLock lock(bankLock);auto tree=state.copyState();tree.setProperty("product",getName(),nullptr);tree.setProperty("program",program.load(),nullptr);tree.setProperty("slot",currentSlot.load(),nullptr);
 for(int i=0;i<7;++i)slots[size_t(currentSlot)][size_t(i)]=value(i);
 for(int bank=0;bank<4;++bank)for(int j=0;j<7;++j)tree.setProperty("bank"+juce::String(bank)+"_"+juce::String(j),slots[size_t(bank)][size_t(j)],nullptr);
 copyXmlToBinary(*tree.createXml(),dst);}
void Processor::setStateInformation(const void* data,int size){const juce::ScopedLock lock(bankLock);if(auto xml=getXmlFromBinary(data,size)){if(!xml->hasTagName("TClassicGold3"))return;auto tree=juce::ValueTree::fromXml(*xml);if(tree.getProperty("product").toString()!=getName())return;state.replaceState(tree);program=juce::jlimit(0,2,int(tree.getProperty("program",0)));currentSlot=juce::jlimit(0,3,int(tree.getProperty("slot",0)));
 for(int bank=0;bank<4;++bank)for(int j=0;j<7;++j){const auto& s=specs[size_t(j)];float v=float(tree.getProperty("bank"+juce::String(bank)+"_"+juce::String(j),s.initial));slots[size_t(bank)][size_t(j)]=std::isfinite(v)?juce::jlimit(s.lo,s.hi,v):s.initial;}}}
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new gold::Processor;}
