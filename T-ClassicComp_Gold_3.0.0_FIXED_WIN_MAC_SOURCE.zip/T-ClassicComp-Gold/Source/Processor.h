#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "ClassicCore.h"
#include <array>
namespace gold {
struct Spec {const char* id;const char* name;float lo,hi,step,initial;const char* unit;};
inline constexpr std::array<Spec,7> specs {{{"scfreq","Sidechain HPF",32,218,1,76,"Hz"},{"attack","Attack Time",12,82,.1f,25,"ms"},{"release","Release Time",29,1400,1,250,"ms"},{"stereo","Stereo Enhancement",-5,5,.1f,0,"dB"},{"ratio","Ratio",1.5f,4.68f,.01f,3.1f,":1"},{"input","Input Drive",-18,18,.1f,0,"dB"},{"output","Output",-15,15,.1f,0,"dB"}}};
inline constexpr const char* presetNames[]{"Vocal Start","Photo Reference","Gentle Vocal"};
inline constexpr std::array<std::array<float,7>,3> presets {{{76,25,250,0,3.1f,0,0},{76,25,250,0,3.1f,-6,3},{76,32,430,0,2.2f,-3,1}}};
class Processor final:public juce::AudioProcessor {
public:
 Processor();
 void prepareToPlay(double,int) override;void reset() override;void releaseResources() override{}
 bool isBusesLayoutSupported(const BusesLayout&) const override;
 using AudioProcessor::processBlock;using AudioProcessor::processBlockBypassed;
 void processBlock(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
 void processBlockBypassed(juce::AudioBuffer<float>&,juce::MidiBuffer&) override;
 juce::AudioProcessorEditor* createEditor() override;bool hasEditor() const override{return true;}
 const juce::String getName() const override{return "T-ClassicComp Gold";}
 bool acceptsMidi() const override{return false;}bool producesMidi() const override{return false;}bool isMidiEffect() const override{return false;}
 double getTailLengthSeconds() const override{return 0;}
 int getNumPrograms() override{return 3;}int getCurrentProgram() override{return program.load();}
 void setCurrentProgram(int) override;const juce::String getProgramName(int i) override{return i>=0&&i<3?presetNames[i]:"";}void changeProgramName(int,const juce::String&) override{}
 void getStateInformation(juce::MemoryBlock&) override;void setStateInformation(const void*,int) override;
 juce::AudioProcessorParameter* getBypassParameter() const override{return state.getParameter("bypass");}
 float value(int) const noexcept;void setReal(int,float);void selectSlot(int);int selectedSlot() const{return currentSlot.load();}
 juce::AudioProcessorValueTreeState state;std::atomic<float> grDb{0},inputDb{-100},outputDb{-100};
private:
 static juce::AudioProcessorValueTreeState::ParameterLayout layout();void updateCore();
 IK::KIS::FX::TR3::ClassicComp::ClassicCompModule core;
 std::array<std::atomic<float>*,8> raw{};juce::SmoothedValue<float> bypass;
 std::array<std::array<float,7>,4> slots{{presets[0],presets[0],presets[0],presets[0]}};
 std::atomic<int> program{0},currentSlot{0};juce::CriticalSection bankLock;bool hostBypass=false;
 JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(Processor)
};
}
