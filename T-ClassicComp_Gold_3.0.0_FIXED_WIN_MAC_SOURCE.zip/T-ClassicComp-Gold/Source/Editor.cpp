#include "Processor.h"
namespace gold {
namespace {const juce::Colour ink(0xff262018),gold(0xffe3a323);}
class Look final:public juce::LookAndFeel_V4 {
public:
 Look(){setColour(juce::Slider::textBoxTextColourId,ink);setColour(juce::Slider::textBoxBackgroundColourId,juce::Colour(0xfff4d16b));setColour(juce::Slider::textBoxOutlineColourId,juce::Colour(0xff996d20));setColour(juce::ComboBox::backgroundColourId,juce::Colour(0xff24282a));setColour(juce::TextButton::buttonColourId,juce::Colour(0xff272b2d));setColour(juce::TextButton::buttonOnColourId,juce::Colour(0xff936518));}
 void drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float start,float end,juce::Slider&) override {
  auto box=juce::Rectangle<float>(float(x),float(y),float(w),float(h)).reduced(7);float d=std::min(box.getWidth(),box.getHeight());box=box.withSizeKeepingCentre(d,d);auto c=box.getCentre();
  for(int i=0;i<=30;++i){float a=start+(end-start)*i/30.f;auto p=c.getPointOnCircumference(d*.5f,a),q=c.getPointOnCircumference(d*(i%5==0?.45f:.47f),a);g.setColour(ink.withAlpha(.7f));g.drawLine({p,q},i%5==0?1.5f:.7f);}
  auto knob=box.reduced(9);g.setColour(juce::Colour(0xff7d5419));g.fillEllipse(knob.translated(2,4));g.setGradientFill(juce::ColourGradient(juce::Colour(0xff8e8b7c),knob.getTopLeft(),juce::Colour(0xff171919),knob.getBottomRight(),false));g.fillEllipse(knob);auto face=knob.reduced(5);g.setGradientFill(juce::ColourGradient(juce::Colour(0xff444746),face.getTopLeft(),juce::Colour(0xff101414),face.getBottomRight(),false));g.fillEllipse(face);g.setColour(juce::Colour(0xff777a74));g.drawEllipse(face,1);float a=start+(end-start)*pos;auto p=c.getPointOnCircumference(d*.13f,a),q=c.getPointOnCircumference(d*.33f,a);g.setColour(juce::Colour(0xfff6f1d9));g.drawLine({p,q},3.5f);
 }
};
class Meter final:public juce::Component {
public:float reduction=0;
 void paint(juce::Graphics& g) override{auto r=getLocalBounds().toFloat();g.setColour(juce::Colour(0xff503c23));g.fillRoundedRectangle(r.translated(2,4),7);g.setColour(juce::Colour(0xff1b1d1d));g.fillRoundedRectangle(r,7);g.setColour(juce::Colour(0xff77756a));g.drawRoundedRectangle(r.reduced(2),6,2);
 for(auto p:{r.getTopLeft()+juce::Point<float>(10,10),r.getTopRight()+juce::Point<float>(-10,10),r.getBottomLeft()+juce::Point<float>(10,-10),r.getBottomRight()+juce::Point<float>(-10,-10)}){g.setColour(juce::Colour(0xff8b8d83));g.fillEllipse(p.x-3,p.y-3,6,6);g.setColour(juce::Colours::black);g.drawLine(p.x-2,p.y,p.x+2,p.y,.8f);}
 auto face=r.reduced(15);g.setGradientFill(juce::ColourGradient(juce::Colour(0xfffff6d8),face.getTopLeft(),juce::Colour(0xffbdb999),face.getBottomRight(),false));g.fillRoundedRectangle(face,face.getWidth()*.38f);auto pivot=juce::Point<float>(r.getCentreX(),r.getBottom()-45);float rad=r.getWidth()*.43f;
 for(int i=0;i<=20;++i){float a=(-.88f+1.76f*i/20);auto p=pivot.getPointOnCircumference(rad,a),q=pivot.getPointOnCircumference(rad-(i%5==0?9:5),a);g.setColour(i>18?juce::Colour(0xff9b3425):ink);g.drawLine({p,q},i%5==0?1.4f:.7f);if(i%5==0){auto t=pivot.getPointOnCircumference(rad+12,a);g.setFont(juce::FontOptions(11));g.drawText(juce::String(20-i),juce::Rectangle<float>(t.x-13,t.y-8,26,16),juce::Justification::centred);}}
 g.setColour(ink);g.setFont(juce::FontOptions(10,juce::Font::bold));g.drawText("GAIN REDUCTION / dB",face.withHeight(20).translated(0,51),juce::Justification::centred);
 float angle=.88f-1.76f*juce::jlimit(0.f,20.f,reduction)/20;auto tip=pivot.getPointOnCircumference(rad-2,angle);g.setColour(juce::Colour(0xff8b241e));g.drawLine({pivot,tip},1.7f);g.setColour(juce::Colour(0xff1c2020));g.fillEllipse(pivot.x-8,pivot.y-8,16,16);g.setColour(juce::Colour(0xff6b706c));g.drawEllipse(pivot.x-8,pivot.y-8,16,16,2);}
};
class Editor final:public juce::AudioProcessorEditor,private juce::Timer {
 Processor& proc;Look look;Meter meter;juce::ComboBox preset;juce::TextButton resetButton{"RESET"},bypassButton{"BYPASS"};std::array<juce::TextButton,4> banks;
 std::array<juce::Slider,7> sliders;std::array<juce::Label,7> labels;juce::Label status;
 std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> attachments;std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;
public:
 Editor(Processor& p):AudioProcessorEditor(p),proc(p){setLookAndFeel(&look);
  for(int i=0;i<7;++i){auto& s=sliders[size_t(i)];s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);s.setTextBoxStyle(juce::Slider::TextBoxAbove,false,112,23);s.setColour(juce::Slider::textBoxTextColourId,ink);s.setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);s.setDoubleClickReturnValue(true,specs[size_t(i)].initial);s.setComponentID(specs[size_t(i)].id);addAndMakeVisible(s);auto& label=labels[size_t(i)];label.setText(specs[size_t(i)].name,juce::dontSendNotification);label.setFont(juce::FontOptions(12,juce::Font::bold));label.setColour(juce::Label::textColourId,ink);label.setJustificationType(juce::Justification::centred);addAndMakeVisible(label);attachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,specs[size_t(i)].id,s));}
  for(int i=0;i<3;++i)preset.addItem(presetNames[i],i+1);preset.setSelectedId(p.getCurrentProgram()+1,juce::dontSendNotification);preset.onChange=[this]{proc.setCurrentProgram(preset.getSelectedId()-1);};addAndMakeVisible(preset);addAndMakeVisible(resetButton);resetButton.setComponentID("reset");resetButton.onClick=[this]{proc.setCurrentProgram(0);proc.state.getParameter("bypass")->setValueNotifyingHost(0);};
  addAndMakeVisible(bypassButton);bypassButton.setComponentID("bypass");bypassButton.setClickingTogglesState(true);bypassAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,"bypass",bypassButton);
  for(int i=0;i<4;++i){auto& b=banks[size_t(i)];b.setButtonText(juce::String::charToString(juce::juce_wchar('A'+i)));b.setComponentID("slot"+juce::String(i));b.onClick=[this,i]{proc.selectSlot(i);};addAndMakeVisible(b);}
  addAndMakeVisible(meter);status.setFont(juce::FontOptions(11));status.setColour(juce::Label::textColourId,juce::Colour(0xffd1d5d2));addAndMakeVisible(status);setSize(1080,540);timerCallback();startTimerHz(30);
 }
 ~Editor() override {stopTimer();setLookAndFeel(nullptr);}
 void paint(juce::Graphics& g) override{g.fillAll(juce::Colour(0xff202426));auto panel=juce::Rectangle<float>(12,62,1056,432);g.setGradientFill(juce::ColourGradient(juce::Colour(0xfffbcd50),panel.getTopLeft(),juce::Colour(0xffac6014),panel.getBottomRight(),false));g.fillRoundedRectangle(panel,6);
  for(int y=65;y<492;y+=3){g.setColour(juce::Colour(0xff6c4016).withAlpha(y%9==0?.07f:.035f));g.drawHorizontalLine(y,15,1065);}
  for(int x:{16,1052}){g.setColour(juce::Colour(0xff72501f));g.fillRect(x,68,12,420);for(int y:{80,474}){g.setColour(juce::Colour(0xff99958a));g.fillEllipse(float(x)-1,float(y),14,14);g.setColour(ink);g.drawEllipse(float(x)-1,float(y),14,14,2);g.drawLine(float(x+2),float(y+7),float(x+10),float(y+7),1);}}
  g.setColour(juce::Colour(0xffe9b64c));g.setFont(juce::FontOptions(23,juce::Font::bold));g.drawText("T-ClassicComp",25,11,265,30,juce::Justification::centredLeft);g.setColour(juce::Colour(0xffd3d6d0));g.setFont(juce::FontOptions(12));g.drawText("GOLD  /  T STUDIO",300,16,200,22,juce::Justification::centredLeft);
  g.setColour(ink);g.setFont(juce::FontOptions(31,juce::Font::bold));g.drawText("T STUDIO",70,425,320,40,juce::Justification::centredLeft);g.setFont(juce::FontOptions(13));g.drawText("CLASSIC COMPRESSOR",72,461,300,20,juce::Justification::centredLeft);
  auto light=juce::Rectangle<float>(962,100,23,23);g.setColour(proc.value(7)<.5f?juce::Colour(0xffe93f30):juce::Colour(0xff602c21));g.fillEllipse(light);g.setColour(juce::Colour(0xffffd3a1));g.drawEllipse(light,2);g.setFont(juce::FontOptions(11));g.setColour(ink);g.drawText("ON",955,126,40,18,juce::Justification::centred);
 }
 void resized() override {preset.setBounds(725,15,325,29);resetButton.setBounds(55,167,80,31);bypassButton.setBounds(925,156,105,31);meter.setBounds(651,114,240,293);
  std::array<juce::Rectangle<int>,7> b{{{153,101,122,153},{278,101,122,153},{403,101,122,153},{528,101,122,153},{278,289,122,150},{419,274,180,181},{918,294,122,151}}};
  for(int i=0;i<7;++i){sliders[size_t(i)].setBounds(b[size_t(i)]);labels[size_t(i)].setBounds(b[size_t(i)].getX()-10,b[size_t(i)].getBottom(),b[size_t(i)].getWidth()+20,25);}status.setBounds(24,504,640,22);for(int i=0;i<4;++i)banks[size_t(i)].setBounds(725+i*83,504,76,24);
 }
 void timerCallback() override {float target=proc.grDb.load();meter.reduction+=(target>meter.reduction?.45f:.09f)*(target-meter.reduction);meter.repaint();for(int i=0;i<4;++i)banks[size_t(i)].setToggleState(proc.selectedSlot()==i,juce::dontSendNotification);preset.setSelectedId(proc.getCurrentProgram()+1,juce::dontSendNotification);status.setText("IN "+juce::String(proc.inputDb.load(),1)+" dBFS     OUT "+juce::String(proc.outputDb.load(),1)+" dBFS     GR "+juce::String(target,1)+" dB",juce::dontSendNotification);repaint(950,95,52,52);}
};
juce::AudioProcessorEditor* Processor::createEditor(){return new Editor(*this);}
}
