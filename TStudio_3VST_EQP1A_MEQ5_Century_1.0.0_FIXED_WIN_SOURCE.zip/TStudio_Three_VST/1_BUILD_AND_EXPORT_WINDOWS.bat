@echo off
setlocal
set "TSTUDIO_PROJECT_DIR=%~dp0"
where powershell.exe >nul 2>nul
if errorlevel 1 (
  echo Windows PowerShell was not found.
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TSTUDIO_PROJECT_DIR%tools\Build-Windows.ps1"
set "TSTUDIO_BUILD_EXIT=%ERRORLEVEL%"
if not "%TSTUDIO_BUILD_EXIT%"=="0" pause
exit /b %TSTUDIO_BUILD_EXIT%
