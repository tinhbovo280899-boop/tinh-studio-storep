#pragma once
#include <cmath>
#include <algorithm>
#include "Presets.h"

namespace uad_uadpultecmeq5 {

inline constexpr double kPi = 3.141592653589793238462643383279502884;


/**
 * UADx Pultec MEQ-5 Mid-Range Passive Tube Equalizer — Complete C++ DSP Implementation
 *
 * Models the Pulse Techniques MEQ-5 Mid-Range Equalizer:
 * 1. Low-Mid Peak Boost Section:
 *    - `lm_freq`: 5 steps -> 200, 300, 500, 700, 1000 Hz
 *    - `lm_peak`: 0..10 -> 0..+10.5 dB Passive LCR Proportional-Q Bell Boost
 * 2. Mid-Range Resonant Dip (Attenuation) Section:
 *    - `mid_freq`: 11 steps -> 200, 300, 500, 700, 1000, 1500, 2000, 3000, 4000, 5000, 7000 Hz
 *    - `mid_dip`: 0..10 -> 0..-10.5 dB Passive LCR Resonant Notch/Bell Dip
 * 3. High-Mid Peak Boost Section:
 *    - `hm_freq`: 5 steps -> 1.5, 2.0, 3.0, 4.0, 5.0 kHz
 *    - `hm_peak`: 0..10 -> 0..+10.5 dB Passive LCR Proportional-Q Bell Boost
 * 4. Passive Tank Interaction & 12AX7/12AU7 Tube Makeup Amplifier + Triad Transformer Stage:
 *    - Models the smooth overlapping interaction when adjacent Peak and Dip bands are set close
 *      together, plus the warm tube & transformer makeup stage.
 */
class UADPultecMEQ5 {
public:
    struct Biquad {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
        double z1L = 0.0, z2L = 0.0;
        double z1R = 0.0, z2R = 0.0;

        void reset() { z1L = z2L = z1R = z2R = 0.0; }

        // Parameter edits change coefficients, never the running filter history.
        void setCoefficients(const Biquad& c) noexcept {
            b0=c.b0; b1=c.b1; b2=c.b2; a1=c.a1; a2=c.a2;
        }

        inline void processStereo(double& L, double& R) {
            double outL = b0 * L + z1L;
            z1L = b1 * L - a1 * outL + z2L;
            z2L = b2 * L - a2 * outL;
            L = outL;

            double outR = b0 * R + z1R;
            z1R = b1 * R - a1 * outR + z2R;
            z2R = b2 * R - a2 * outR;
            R = outR;
        }

        double magResponsedB(double freqHz, double sampleRate) const {
            double w = 2.0 * kPi * freqHz / sampleRate;
            double cw = std::cos(w), c2w = std::cos(2.0 * w);
            double sw = std::sin(w), s2w = std::sin(2.0 * w);
            double numR = b0 + b1 * cw + b2 * c2w;
            double numI = -(b1 * sw + b2 * s2w);
            double denR = 1.0 + a1 * cw + a2 * c2w;
            double denI = -(a1 * sw + a2 * s2w);
            double mag2 = (numR * numR + numI * numI) / std::max(1e-18, denR * denR + denI * denI);
            return 10.0 * std::log10(std::max(1e-18, mag2));
        }
    };

    UADPultecMEQ5() { prepare(48000.0); }

    void prepare(double sampleRate);
    void reset();

    void setParameters(float lmFreqNorm, float lmPeakNorm,
                       float midFreqNorm, float midDipNorm,
                       float hmFreqNorm, float hmPeakNorm,
                       float enableNorm, float outputNorm);

    void loadPreset(int index);

    void processBlock(float* left, float* right, int numSamples);
    double getMagnitudeResponsedB(double freqHz) const;

    double getLMFreqHz() const { return currentLMFreqHz_; }
    double getMidFreqHz() const { return currentMidFreqHz_; }
    double getHMFreqHz() const { return currentHMFreqHz_; }

private:
    void updateFilters();
    static Biquad makePeaking(double fc, double gaindB, double Q, double fs);

    double sampleRate_ = 48000.0;

    float lm_freq_ = 0.0f;
    float lm_peak_ = 0.0f;
    float mid_freq_ = 0.5f;
    float mid_dip_ = 0.0f;
    float hm_freq_ = 0.5f;
    float hm_peak_ = 0.0f;
    float enable_ = 1.0f;
    float output_ = 0.5f;

    bool eqEnabled_ = true;
    bool powerOn_ = true;
    double outputGainLin_ = 1.0;

    double currentLMFreqHz_ = 200.0;
    double currentMidFreqHz_ = 1500.0;
    double currentHMFreqHz_ = 3000.0;

    Biquad bqLMPeak_;
    Biquad bqMidDip_;
    Biquad bqHMPeak_;
    Biquad bqTransformerBump_;
};

} // namespace uad_uadpultecmeq5
