#include "UADPultecMEQ5.h"

namespace uad_uadpultecmeq5 {

static const double kLMFreqTable[5] = { 200.0, 300.0, 500.0, 700.0, 1000.0 };
static const double kMidDipFreqTable[11] = {
    200.0, 300.0, 500.0, 700.0, 1000.0, 1500.0, 2000.0, 3000.0, 4000.0, 5000.0, 7000.0
};
static const double kHMFreqTable[5] = { 1500.0, 2000.0, 3000.0, 4000.0, 5000.0 };

void UADPultecMEQ5::prepare(double sampleRate) {
    sampleRate_ = std::isfinite(sampleRate) && sampleRate >= 8000.0 && sampleRate <= 768000.0 ? sampleRate : 48000.0;
    reset();
    updateFilters();
}

void UADPultecMEQ5::reset() {
    bqLMPeak_.reset();
    bqMidDip_.reset();
    bqHMPeak_.reset();
    bqTransformerBump_.reset();
}

void UADPultecMEQ5::loadPreset(int index) {
    int count = sizeof(kFactoryPresets) / sizeof(kFactoryPresets[0]);
    if (index < 0 || index >= count) return;
    const auto& p = kFactoryPresets[index];
    setParameters(p.lm_freq, p.lm_peak, p.mid_freq, p.mid_dip,
                  p.hm_freq, p.hm_peak, p.enable, p.output);
}

void UADPultecMEQ5::setParameters(float lmFreqNorm, float lmPeakNorm,
                                  float midFreqNorm, float midDipNorm,
                                  float hmFreqNorm, float hmPeakNorm,
                                  float enableNorm, float outputNorm) {
    lm_freq_ = std::isfinite(lmFreqNorm) ? std::clamp(lmFreqNorm, 0.0f, 1.0f) : lm_freq_;
    lm_peak_ = std::isfinite(lmPeakNorm) ? std::clamp(lmPeakNorm, 0.0f, 1.0f) : lm_peak_;
    mid_freq_ = std::isfinite(midFreqNorm) ? std::clamp(midFreqNorm, 0.0f, 1.0f) : mid_freq_;
    mid_dip_ = std::isfinite(midDipNorm) ? std::clamp(midDipNorm, 0.0f, 1.0f) : mid_dip_;
    hm_freq_ = std::isfinite(hmFreqNorm) ? std::clamp(hmFreqNorm, 0.0f, 1.0f) : hm_freq_;
    hm_peak_ = std::isfinite(hmPeakNorm) ? std::clamp(hmPeakNorm, 0.0f, 1.0f) : hm_peak_;
    enable_ = std::isfinite(enableNorm) ? std::clamp(enableNorm, 0.0f, 1.0f) : enable_;
    output_ = std::isfinite(outputNorm) ? std::clamp(outputNorm, 0.0f, 1.0f) : output_;

    eqEnabled_ = (enable_ >= 0.5f);
    powerOn_ = (output_ >= 0.01f);

    double outdB = (static_cast<double>(output_) - 0.5) * 24.0;
    outputGainLin_ = std::pow(10.0, outdB / 20.0);

    updateFilters();
}

UADPultecMEQ5::Biquad UADPultecMEQ5::makePeaking(double fc, double gaindB, double Q, double fs) {
    Biquad bq;
    if (std::abs(gaindB) < 1e-4) return bq;
    fc = std::clamp(fc, 20.0, 0.475 * fs);
    double A = std::pow(10.0, gaindB / 40.0);
    double w0 = 2.0 * kPi * fc / fs;
    double cw = std::cos(w0);
    double sw = std::sin(w0);
    double alpha = sw / (2.0 * Q);

    double a0 = 1.0 + alpha / A;
    bq.b0 = (1.0 + alpha * A) / a0;
    bq.b1 = (-2.0 * cw) / a0;
    bq.b2 = (1.0 - alpha * A) / a0;
    bq.a1 = (-2.0 * cw) / a0;
    bq.a2 = (1.0 - alpha / A) / a0;
    return bq;
}

void UADPultecMEQ5::updateFilters() {
    int lmIdx = std::clamp(static_cast<int>(std::round(lm_freq_ * 4.0f)), 0, 4);
    int midIdx = std::clamp(static_cast<int>(std::round(mid_freq_ * 10.0f)), 0, 10);
    int hmIdx = std::clamp(static_cast<int>(std::round(hm_freq_ * 4.0f)), 0, 4);

    currentLMFreqHz_ = kLMFreqTable[lmIdx];
    currentMidFreqHz_ = kMidDipFreqTable[midIdx];
    currentHMFreqHz_ = kHMFreqTable[hmIdx];

    // Passive LCR proportional-Q behavior: Q sharpens smoothly as boost/dip increases
    double lmGaindB = static_cast<double>(lm_peak_) * 10.5;
    double lmQ = 0.65 + 0.95 * static_cast<double>(lm_peak_);
    bqLMPeak_.setCoefficients(makePeaking(currentLMFreqHz_, lmGaindB, lmQ, sampleRate_));

    double midDipdB = -static_cast<double>(mid_dip_) * 11.0;
    double midQ = 0.85 + 1.35 * static_cast<double>(mid_dip_);
    bqMidDip_.setCoefficients(makePeaking(currentMidFreqHz_, midDipdB, midQ, sampleRate_));

    double hmGaindB = static_cast<double>(hm_peak_) * 10.5;
    double hmQ = 0.70 + 1.05 * static_cast<double>(hm_peak_);
    bqHMPeak_.setCoefficients(makePeaking(currentHMFreqHz_, hmGaindB, hmQ, sampleRate_));

    bqTransformerBump_.setCoefficients(makePeaking(32.0, 0.35, 0.75, sampleRate_));
}

void UADPultecMEQ5::processBlock(float* left, float* right, int numSamples) {
    if (left == nullptr || numSamples <= 0) return;
    for (int i=0; i<numSamples; ++i) {
        left[i] = std::isfinite(left[i]) ? std::clamp(left[i], -64.0f, 64.0f) : 0.0f;
        if (right) right[i] = std::isfinite(right[i]) ? std::clamp(right[i], -64.0f, 64.0f) : 0.0f;
    }
    if (!powerOn_) return;

    for (int i = 0; i < numSamples; ++i) {
        double L = static_cast<double>(left[i]);
        double R = right ? static_cast<double>(right[i]) : L;

        if (eqEnabled_) {
            bqLMPeak_.processStereo(L, R);
            bqMidDip_.processStereo(L, R);
            bqHMPeak_.processStereo(L, R);
        }

        bqTransformerBump_.processStereo(L, R);

        // 12AX7 / 12AU7 Tube Makeup Amplifier subtle warmth
        auto tubeStage = [](double x) -> double {
            double d = x * 0.8;
            return (std::tanh(d) + 0.015 * d * d / (1.0 + d * d)) / 0.8;
        };
        L = tubeStage(L) * outputGainLin_;
        R = tubeStage(R) * outputGainLin_;

        left[i] = static_cast<float>(L);
        if (right) right[i] = static_cast<float>(R);
    }
}

double UADPultecMEQ5::getMagnitudeResponsedB(double freqHz) const {
    if (!powerOn_) return 0.0;
    double dB = 20.0 * std::log10(std::max(1e-9, outputGainLin_));
    dB += bqTransformerBump_.magResponsedB(freqHz, sampleRate_);
    if (eqEnabled_) {
        dB += bqLMPeak_.magResponsedB(freqHz, sampleRate_);
        dB += bqMidDip_.magResponsedB(freqHz, sampleRate_);
        dB += bqHMPeak_.magResponsedB(freqHz, sampleRate_);
    }
    return dB;
}

} // namespace uad_uadpultecmeq5
