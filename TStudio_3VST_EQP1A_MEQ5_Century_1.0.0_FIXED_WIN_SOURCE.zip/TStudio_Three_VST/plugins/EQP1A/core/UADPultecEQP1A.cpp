#include "UADPultecEQP1A.h"

namespace uad_uadpulteceqp1a {

static const double kLowFreqTable[4] = { 20.0, 30.0, 60.0, 100.0 };
static const double kHighFreqTable[7] = { 3000.0, 4000.0, 5000.0, 8000.0, 10000.0, 12000.0, 16000.0 };
static const double kHiAttenFreqTable[3] = { 5000.0, 10000.0, 20000.0 };

void UADPultecEQP1A::prepare(double sampleRate) {
    sampleRate_ = std::isfinite(sampleRate) && sampleRate >= 8000.0 && sampleRate <= 768000.0 ? sampleRate : 48000.0;
    reset();
    updateFilters();
}

void UADPultecEQP1A::reset() {
    bqTransformerHeadBump_.reset();
    bqLowBoostShelf_.reset();
    bqLowAttenShelf_.reset();
    bqPultecCoupledDip_.reset();
    bqHighBellBoost_.reset();
    bqHighAttenShelf_.reset();
    bqTubeHFSoftRoll_.reset();
}

void UADPultecEQP1A::loadPreset(int index) {
    int count = sizeof(kFactoryPresets) / sizeof(kFactoryPresets[0]);
    if (index < 0 || index >= count) return;
    const auto& p = kFactoryPresets[index];
    setParameters(p.low_freq, p.lf_boost, p.lf_atten,
                  p.high_freq, p.hf_boost, p.hf_q,
                  p.hf_atten_freq, p.hf_atten, p.enable, p.output);
}

void UADPultecEQP1A::setParameters(float lowFreqNorm, float lfBoostNorm, float lfAttenNorm,
                                   float highFreqNorm, float hfBoostNorm, float hfQNorm,
                                   float hfAttenFreqNorm, float hfAttenNorm,
                                   float enableNorm, float outputNorm) {
    low_freq_ = std::isfinite(lowFreqNorm) ? std::clamp(lowFreqNorm, 0.0f, 1.0f) : low_freq_;
    lf_boost_ = std::isfinite(lfBoostNorm) ? std::clamp(lfBoostNorm, 0.0f, 1.0f) : lf_boost_;
    lf_atten_ = std::isfinite(lfAttenNorm) ? std::clamp(lfAttenNorm, 0.0f, 1.0f) : lf_atten_;
    high_freq_ = std::isfinite(highFreqNorm) ? std::clamp(highFreqNorm, 0.0f, 1.0f) : high_freq_;
    hf_boost_ = std::isfinite(hfBoostNorm) ? std::clamp(hfBoostNorm, 0.0f, 1.0f) : hf_boost_;
    hf_q_ = std::isfinite(hfQNorm) ? std::clamp(hfQNorm, 0.0f, 1.0f) : hf_q_;
    hf_atten_freq_ = std::isfinite(hfAttenFreqNorm) ? std::clamp(hfAttenFreqNorm, 0.0f, 1.0f) : hf_atten_freq_;
    hf_atten_ = std::isfinite(hfAttenNorm) ? std::clamp(hfAttenNorm, 0.0f, 1.0f) : hf_atten_;
    enable_ = std::isfinite(enableNorm) ? std::clamp(enableNorm, 0.0f, 1.0f) : enable_;
    output_ = std::isfinite(outputNorm) ? std::clamp(outputNorm, 0.0f, 1.0f) : output_;

    eqEnabled_ = (enable_ >= 0.5f);
    powerOn_ = (output_ >= 0.01f);

    // Output knob: 0.5 = 0.0 dB, range -12.0 dB .. +12.0 dB
    double outdB = (static_cast<double>(output_) - 0.5) * 24.0;
    outputGainLin_ = std::pow(10.0, outdB / 20.0);

    updateFilters();
}

UADPultecEQP1A::Biquad UADPultecEQP1A::makeLowShelf(double fc, double gaindB, double Q, double fs) {
    Biquad bq;
    if (std::abs(gaindB) < 1e-4) return bq;
    fc = std::clamp(fc, 10.0, 0.47 * fs);
    double A = std::pow(10.0, gaindB / 40.0);
    double w0 = 2.0 * kPi * fc / fs;
    double cw = std::cos(w0);
    double sw = std::sin(w0);
    double alpha = sw / (2.0 * Q);
    double twoSqrtAAlpha = 2.0 * std::sqrt(A) * alpha;

    double a0 = (A + 1.0) + (A - 1.0) * cw + twoSqrtAAlpha;
    bq.b0 = (A * ((A + 1.0) - (A - 1.0) * cw + twoSqrtAAlpha)) / a0;
    bq.b1 = (2.0 * A * ((A - 1.0) - (A + 1.0) * cw)) / a0;
    bq.b2 = (A * ((A + 1.0) - (A - 1.0) * cw - twoSqrtAAlpha)) / a0;
    bq.a1 = (-2.0 * ((A - 1.0) + (A + 1.0) * cw)) / a0;
    bq.a2 = ((A + 1.0) + (A - 1.0) * cw - twoSqrtAAlpha) / a0;
    return bq;
}

UADPultecEQP1A::Biquad UADPultecEQP1A::makeHighShelf(double fc, double gaindB, double Q, double fs) {
    Biquad bq;
    if (std::abs(gaindB) < 1e-4) return bq;
    fc = std::clamp(fc, 20.0, 0.475 * fs);
    double A = std::pow(10.0, gaindB / 40.0);
    double w0 = 2.0 * kPi * fc / fs;
    double cw = std::cos(w0);
    double sw = std::sin(w0);
    double alpha = sw / (2.0 * Q);
    double twoSqrtAAlpha = 2.0 * std::sqrt(A) * alpha;

    double a0 = (A + 1.0) - (A - 1.0) * cw + twoSqrtAAlpha;
    bq.b0 = (A * ((A + 1.0) + (A - 1.0) * cw + twoSqrtAAlpha)) / a0;
    bq.b1 = (-2.0 * A * ((A - 1.0) + (A + 1.0) * cw)) / a0;
    bq.b2 = (A * ((A + 1.0) + (A - 1.0) * cw - twoSqrtAAlpha)) / a0;
    bq.a1 = (2.0 * ((A - 1.0) - (A + 1.0) * cw)) / a0;
    bq.a2 = ((A + 1.0) - (A - 1.0) * cw - twoSqrtAAlpha) / a0;
    return bq;
}

UADPultecEQP1A::Biquad UADPultecEQP1A::makePeaking(double fc, double gaindB, double Q, double fs) {
    Biquad bq;
    if (std::abs(gaindB) < 1e-4) return bq;
    fc = std::clamp(fc, 15.0, 0.475 * fs);
    double A = std::pow(10.0, gaindB / 40.0);
    double w0 = 2.0 * kPi * fc / fs;
    double cw = std::cos(w0);
    double sw = std::sin(w0);
    double alpha = sw / (2.0 * Q);

    double a0 = 1.0 + alpha / A;
    bq.b0 = (1.0 + alpha * A) / a0;
    bq.b1 = (-2.0 * cw) / a0;
    bq.b2 = (1.0 - alpha * A) / a0;
    bq.a1 = (-2.0 * cw) / a0;
    bq.a2 = (1.0 - alpha / A) / a0;
    return bq;
}

void UADPultecEQP1A::updateFilters() {
    int lowIdx = std::clamp(static_cast<int>( std::round(low_freq_ * 3.0f) ), 0, 3);
    int highIdx = std::clamp(static_cast<int>( std::round(high_freq_ * 6.0f) ), 0, 6);
    int hiAttenIdx = std::clamp(static_cast<int>( std::round(hf_atten_freq_ * 2.0f) ), 0, 2);

    currentLowFreqHz_ = kLowFreqTable[lowIdx];
    currentHighFreqHz_ = kHighFreqTable[highIdx];
    currentHiAttenFreqHz_ = kHiAttenFreqTable[hiAttenIdx];

    // 1. Triad HS-29 Transformer + Tube Amplifier always-on contour
    bqTransformerHeadBump_.setCoefficients(makePeaking(28.0, 0.45, 0.75, sampleRate_));
    bqTubeHFSoftRoll_.setCoefficients(makeHighShelf(19500.0, -0.35, 0.65, sampleRate_));

    // 2. Passive Low-Frequency Network (Pultec Low-End Trick)
    // In the hardware passive RC bridge, the Boost shelf corner sits ~2.2x above nominal dial label
    // with gentle slope (Q ~ 0.52), while Atten shelf corner sits ~3.4x above nominal dial label.
    // When both Boost and Atten are turned up simultaneously, the loading interaction creates
    // an additional mid-bass dip around 2.8x nominal frequency.
    double lfBoostdB = static_cast<double>(lf_boost_) * 13.5;
    double lfAttendB = -static_cast<double>(lf_atten_) * 17.5;

    double boostCornerHz = currentLowFreqHz_ * 2.15;
    double attenCornerHz = currentLowFreqHz_ * 3.55;
    bqLowBoostShelf_.setCoefficients(makeLowShelf(boostCornerHz, lfBoostdB, 0.52, sampleRate_));
    bqLowAttenShelf_.setCoefficients(makeLowShelf(attenCornerHz, lfAttendB, 0.55, sampleRate_));

    double coupledDipdB = -4.2 * static_cast<double>(lf_boost_ * lf_atten_);
    double coupledDipHz = currentLowFreqHz_ * 3.1;
    bqPultecCoupledDip_.setCoefficients(makePeaking(coupledDipHz, coupledDipdB, 0.85, sampleRate_));

    // 3. Passive High-Frequency LCR Resonant Bell Boost
    // Bandwidth knob (hf_q_): 0.0 = Sharp (Q = 3.2), 1.0 = Broad (Q = 0.45)
    // In a passive LCR tank, broadening bandwidth slightly reduces peak gain (~18 dB sharp -> ~13.5 dB broad)
    double qFactor = 3.2 * std::pow(0.45 / 3.2, static_cast<double>(hf_q_));
    double maxHfBoostdB = 18.0 - 4.2 * static_cast<double>(hf_q_);
    double hfBoostdB = static_cast<double>(hf_boost_) * maxHfBoostdB;
    bqHighBellBoost_.setCoefficients(makePeaking(currentHighFreqHz_, hfBoostdB, qFactor, sampleRate_));

    // 4. Passive High-Frequency Shelf Attenuation
    double hfAttendB = -static_cast<double>(hf_atten_) * 16.0;
    bqHighAttenShelf_.setCoefficients(makeHighShelf(currentHiAttenFreqHz_, hfAttendB, 0.52, sampleRate_));
}

void UADPultecEQP1A::processBlock(float* left, float* right, int numSamples) {
    if (left == nullptr || numSamples <= 0) return;
    for (int i=0; i<numSamples; ++i) {
        left[i] = std::isfinite(left[i]) ? std::clamp(left[i], -64.0f, 64.0f) : 0.0f;
        if (right) right[i] = std::isfinite(right[i]) ? std::clamp(right[i], -64.0f, 64.0f) : 0.0f;
    }
    if (!powerOn_) return;

    for (int i = 0; i < numSamples; ++i) {
        double L = static_cast<double>(left[i]);
        double R = right ? static_cast<double>(right[i]) : L;

        if (eqEnabled_) {
            bqLowBoostShelf_.processStereo(L, R);
            bqLowAttenShelf_.processStereo(L, R);
            bqPultecCoupledDip_.processStereo(L, R);
            bqHighBellBoost_.processStereo(L, R);
            bqHighAttenShelf_.processStereo(L, R);
        }

        // Triad HS-29 Interstage Transformer + Push-Pull 12AX7/12AU7 Tube Makeup Stage
        bqTransformerHeadBump_.processStereo(L, R);
        bqTubeHFSoftRoll_.processStereo(L, R);

        // Push-pull tube saturation (subtle 2nd + 3rd harmonic warmth)
        auto tubeStage = [](double x) -> double {
            double drive = x * 0.85;
            double sat = std::tanh(drive) + 0.018 * drive * drive / (1.0 + drive * drive);
            return sat / 0.85;
        };
        L = tubeStage(L) * outputGainLin_;
        R = tubeStage(R) * outputGainLin_;

        left[i] = static_cast<float>(L);
        if (right) right[i] = static_cast<float>(R);
    }
}

double UADPultecEQP1A::getMagnitudeResponsedB(double freqHz) const {
    if (!powerOn_) return 0.0;
    double dB = 20.0 * std::log10(std::max(1e-9, outputGainLin_));
    dB += bqTransformerHeadBump_.magResponsedB(freqHz, sampleRate_);
    dB += bqTubeHFSoftRoll_.magResponsedB(freqHz, sampleRate_);
    if (eqEnabled_) {
        dB += bqLowBoostShelf_.magResponsedB(freqHz, sampleRate_);
        dB += bqLowAttenShelf_.magResponsedB(freqHz, sampleRate_);
        dB += bqPultecCoupledDip_.magResponsedB(freqHz, sampleRate_);
        dB += bqHighBellBoost_.magResponsedB(freqHz, sampleRate_);
        dB += bqHighAttenShelf_.magResponsedB(freqHz, sampleRate_);
    }
    return dB;
}

} // namespace uad_uadpulteceqp1a
