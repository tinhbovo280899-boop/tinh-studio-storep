#pragma once
#include <cmath>
#include <algorithm>
#include "Presets.h"

namespace uad_uadpulteceqp1a {

inline constexpr double kPi = 3.141592653589793238462643383279502884;


/**
 * UADx Pultec EQP-1A Program Equalizer — Complete C++ DSP Implementation
 *
 * Models the classic Pulse Techniques EQP-1A Passive Program Equalizer +
 * Push-Pull 12AX7 / 12AU7 Vacuum Tube Makeup Amplifier & Triad HS-29 Transformer:
 *
 * 1. Passive Low-Frequency Coupled Shelf + Resonant Interaction ("Pultec Low-End Trick"):
 *    - Selector (`low_freq`): 4 steps -> 20 Hz, 30 Hz, 60 Hz, 100 Hz
 *    - `lf_boost` (0..10 -> 0..+13.5 dB): Passive RC low-shelf boost
 *    - `lf_atten` (0..10 -> 0..-17.5 dB): Passive RC low-shelf cut whose effective corner
 *      frequency sits ~1.45x higher than the boost network, plus an interactive LCR mid-bass
 *      dip when both `lf_boost` and `lf_atten` are simultaneously engaged (producing the iconic
 *      sub-bass punch + tight upper-bass scoop).
 *
 * 2. Passive High-Frequency LCR Resonant Bell Boost:
 *    - Selector (`high_freq`): 7 steps -> 3, 4, 5, 8, 10, 12, 16 kHz
 *    - `hf_boost` (0..10 -> 0..+18.0 dB): Inductor-Capacitor-Resistor bell boost
 *    - `hf_q` (0..10): Variable damping resistor (Sharp Q=3.5 at 0.0 -> Broad Q=0.45 at 1.0),
 *      with passive Q-dependent gain interaction matching the Pultec tank circuit.
 *
 * 3. Passive High-Frequency Shelf Attenuation:
 *    - Selector (`hf_atten_freq`): 3 steps -> 5, 10, 20 kHz
 *    - `hf_atten` (0..10 -> 0..-16.0 dB): Smooth 6 dB/oct passive RC high-shelf rolloff.
 *
 * 4. Triad HS-29 Interstage Transformer & 12AX7/12AU7 Push-Pull Tube Amplifier:
 *    - Always active when Power (`output > 0.01`) is ON, even when `enable` (EQ IN) is bypassed,
 *      providing the signature warm low-end transformer head-bump (~28 Hz) and subtle
 *      even/odd harmonic tube saturation.
 */
class UADPultecEQP1A {
public:
    struct Biquad {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
        double z1L = 0.0, z2L = 0.0;
        double z1R = 0.0, z2R = 0.0;

        void reset() { z1L = z2L = z1R = z2R = 0.0; }

        // Parameter edits change coefficients, never the running filter history.
        void setCoefficients(const Biquad& c) noexcept {
            b0=c.b0; b1=c.b1; b2=c.b2; a1=c.a1; a2=c.a2;
        }

        inline void processStereo(double& L, double& R) {
            double outL = b0 * L + z1L;
            z1L = b1 * L - a1 * outL + z2L;
            z2L = b2 * L - a2 * outL;
            L = outL;

            double outR = b0 * R + z1R;
            z1R = b1 * R - a1 * outR + z2R;
            z2R = b2 * R - a2 * outR;
            R = outR;
        }

        double magResponsedB(double freqHz, double sampleRate) const {
            double w = 2.0 * kPi * freqHz / sampleRate;
            double cw = std::cos(w), c2w = std::cos(2.0 * w);
            double sw = std::sin(w), s2w = std::sin(2.0 * w);
            double numR = b0 + b1 * cw + b2 * c2w;
            double numI = -(b1 * sw + b2 * s2w);
            double denR = 1.0 + a1 * cw + a2 * c2w;
            double denI = -(a1 * sw + a2 * s2w);
            double mag2 = (numR * numR + numI * numI) / std::max(1e-18, denR * denR + denI * denI);
            return 10.0 * std::log10(std::max(1e-18, mag2));
        }
    };

    UADPultecEQP1A() { prepare(48000.0); }

    void prepare(double sampleRate);
    void reset();

    // Set normalized parameters [0.0 .. 1.0] matching UAD preset chunks & GUI
    void setParameters(float lowFreqNorm, float lfBoostNorm, float lfAttenNorm,
                       float highFreqNorm, float hfBoostNorm, float hfQNorm,
                       float hfAttenFreqNorm, float hfAttenNorm,
                       float enableNorm, float outputNorm);

    void loadPreset(int index);

    void processBlock(float* left, float* right, int numSamples);
    double getMagnitudeResponsedB(double freqHz) const;

    // Parameter getters
    double getLowFreqHz() const { return currentLowFreqHz_; }
    double getHighFreqHz() const { return currentHighFreqHz_; }
    double getHiAttenFreqHz() const { return currentHiAttenFreqHz_; }
    bool isBypassed() const { return !powerOn_; }

private:
    void updateFilters();
    static Biquad makeLowShelf(double fc, double gaindB, double Q, double fs);
    static Biquad makeHighShelf(double fc, double gaindB, double Q, double fs);
    static Biquad makePeaking(double fc, double gaindB, double Q, double fs);

    double sampleRate_ = 48000.0;

    // Normalized parameters (0..1)
    float low_freq_ = 0.0f;
    float lf_boost_ = 0.0f;
    float lf_atten_ = 0.0f;
    float high_freq_ = 0.5f;
    float hf_boost_ = 0.0f;
    float hf_q_ = 0.5f;
    float hf_atten_freq_ = 0.5f;
    float hf_atten_ = 0.0f;
    float enable_ = 1.0f;
    float output_ = 0.5f;

    bool eqEnabled_ = true;
    bool powerOn_ = true;
    double outputGainLin_ = 1.0;

    double currentLowFreqHz_ = 20.0;
    double currentHighFreqHz_ = 8000.0;
    double currentHiAttenFreqHz_ = 10000.0;

    // Filter cascade
    Biquad bqTransformerHeadBump_; // Triad HS-29 28 Hz +0.45 dB resonance
    Biquad bqLowBoostShelf_;       // Passive LF Boost Shelf
    Biquad bqLowAttenShelf_;       // Passive LF Atten Shelf (shifted corner)
    Biquad bqPultecCoupledDip_;    // Interactive LCR dip when both LF Boost & Atten are active
    Biquad bqHighBellBoost_;       // Passive LCR HF Resonant Bell Boost
    Biquad bqHighAttenShelf_;      // Passive RC HF Attenuation Shelf
    Biquad bqTubeHFSoftRoll_;      // Push-pull tube amplifier ultrasonic transformer roll
};

} // namespace uad_uadpulteceqp1a
