#include "UADCenturyChannelStrip.h"

namespace uad_uadcenturychannelstrip {

void UADCenturyChannelStrip::prepare(double sampleRate) {
    sampleRate_ = std::isfinite(sampleRate) && sampleRate >= 8000.0 && sampleRate <= 768000.0 ? sampleRate : 48000.0;
    // Optical cell time constants: ~10 ms program attack, 60 ms fast release, 650 ms slow memory release
    attCoeff_ = std::exp(-1.0 / (0.010 * sampleRate_));
    relFastCoeff_ = std::exp(-1.0 / (0.060 * sampleRate_));
    relSlowCoeff_ = std::exp(-1.0 / (0.650 * sampleRate_));
    vuCoeff_ = std::exp(-1.0 / (0.300 * sampleRate_));
    reset();
    updateFilters();
}

void UADCenturyChannelStrip::reset() {
    bqLowCut2nd_.reset();
    bqLowCut1st_.reset();
    bqDCBlocker_.reset();
    bqLowShelf110_.reset();
    bqMidBell_.reset();
    bqHighShelf10k_.reset();
    optoFastEnv_ = 0.0;
    optoSlowEnv_ = 0.0;
    vuEnv_ = 0.0;
    currentGRdB_ = 0.0;
    currentVUdB_ = -60.0;
}

void UADCenturyChannelStrip::loadPreset(int index) {
    int count = sizeof(kFactoryPresets) / sizeof(kFactoryPresets[0]);
    if (index < 0 || index >= count) return;
    const auto& p = kFactoryPresets[index];
    setParameters(p.input_select, p.low_cut, p.phase, p.pad,
                  p.gain, p.level, p.high_shelf, p.mid_freq,
                  p.mid_gain, p.low_shelf, p.eq_in,
                  p.compression, p.gr_in, p.output, p.power);
}

void UADCenturyChannelStrip::setParameters(float inputSelect, float lowCut, float phase, float pad,
                                           float gainSwitch, float preampLevel,
                                           float highShelf, float midFreq, float midGain, float lowShelf, float eqIn,
                                           float compression, float grIn, float output, float power) {
    input_select_ = std::isfinite(inputSelect) ? std::clamp(inputSelect, 0.0f, 1.0f) : input_select_;
    low_cut_ = std::isfinite(lowCut) ? std::clamp(lowCut, 0.0f, 1.0f) : low_cut_;
    phase_ = std::isfinite(phase) ? std::clamp(phase, 0.0f, 1.0f) : phase_;
    pad_ = std::isfinite(pad) ? std::clamp(pad, 0.0f, 1.0f) : pad_;
    gain_ = std::isfinite(gainSwitch) ? std::clamp(gainSwitch, 0.0f, 1.0f) : gain_;
    level_ = std::isfinite(preampLevel) ? std::clamp(preampLevel, 0.0f, 1.0f) : level_;
    high_shelf_ = std::isfinite(highShelf) ? std::clamp(highShelf, 0.0f, 1.0f) : high_shelf_;
    mid_freq_ = std::isfinite(midFreq) ? std::clamp(midFreq, 0.0f, 1.0f) : mid_freq_;
    mid_gain_ = std::isfinite(midGain) ? std::clamp(midGain, 0.0f, 1.0f) : mid_gain_;
    low_shelf_ = std::isfinite(lowShelf) ? std::clamp(lowShelf, 0.0f, 1.0f) : low_shelf_;
    eq_in_ = std::isfinite(eqIn) ? std::clamp(eqIn, 0.0f, 1.0f) : eq_in_;
    compression_ = std::isfinite(compression) ? std::clamp(compression, 0.0f, 1.0f) : compression_;
    gr_in_ = std::isfinite(grIn) ? std::clamp(grIn, 0.0f, 1.0f) : gr_in_;
    output_ = std::isfinite(output) ? std::clamp(output, 0.0f, 1.0f) : output_;
    power_ = std::isfinite(power) ? std::clamp(power, 0.0f, 1.0f) : power_;

    updateFilters();
}

void UADCenturyChannelStrip::updateFilters() {
    // 1. 80 Hz 18 dB/octave Butterworth High-Pass Filter (Q = 1.0 biquad + 1st-order pole at 80 Hz)
    {
        double fc = 80.0;
        double w0 = 2.0 * kPi * std::min(fc, 0.475 * sampleRate_) / sampleRate_;
        double cw = std::cos(w0), sw = std::sin(w0);
        double alpha = sw / (2.0 * 1.0); // Q = 1.0 for 3rd-order Butterworth biquad section
        double a0 = 1.0 + alpha;
        bqLowCut2nd_.b0 = ((1.0 + cw) * 0.5) / a0;
        bqLowCut2nd_.b1 = -(1.0 + cw) / a0;
        bqLowCut2nd_.b2 = ((1.0 + cw) * 0.5) / a0;
        bqLowCut2nd_.a1 = (-2.0 * cw) / a0;
        bqLowCut2nd_.a2 = (1.0 - alpha) / a0;

        double k = std::tan(kPi * fc / sampleRate_);
        bqLowCut1st_.b0 = 1.0 / (1.0 + k);
        bqLowCut1st_.b1 = -bqLowCut1st_.b0;
        bqLowCut1st_.b2 = 0.0;
        bqLowCut1st_.a1 = (k - 1.0) / (k + 1.0);
        bqLowCut1st_.a2 = 0.0;
    }

    // DC Blocker at 10 Hz
    {
        double k = std::tan(kPi * 10.0 / sampleRate_);
        bqDCBlocker_.b0 = 1.0 / (1.0 + k);
        bqDCBlocker_.b1 = -bqDCBlocker_.b0;
        bqDCBlocker_.b2 = 0.0;
        bqDCBlocker_.a1 = (k - 1.0) / (k + 1.0);
        bqDCBlocker_.a2 = 0.0;
    }

    // 2. 3-Band Tube EQ
    // Low Shelf at 110 Hz (-12 .. +12 dB)
    {
        double gaindB = (static_cast<double>(low_shelf_) - 0.5) * 24.0;
        double fc = 110.0;
        if (std::abs(gaindB) < 1e-4) {
            bqLowShelf110_.setCoefficients(Biquad());
        } else {
            double A = std::pow(10.0, gaindB / 40.0);
            double w0 = 2.0 * kPi * std::min(fc, 0.475 * sampleRate_) / sampleRate_;
            double cw = std::cos(w0), sw = std::sin(w0);
            double alpha = sw / (2.0 * 0.65);
            double twoSqrtAAlpha = 2.0 * std::sqrt(A) * alpha;
            double a0 = (A + 1.0) + (A - 1.0) * cw + twoSqrtAAlpha;
            bqLowShelf110_.b0 = (A * ((A + 1.0) - (A - 1.0) * cw + twoSqrtAAlpha)) / a0;
            bqLowShelf110_.b1 = (2.0 * A * ((A - 1.0) - (A + 1.0) * cw)) / a0;
            bqLowShelf110_.b2 = (A * ((A + 1.0) - (A - 1.0) * cw - twoSqrtAAlpha)) / a0;
            bqLowShelf110_.a1 = (-2.0 * ((A - 1.0) + (A + 1.0) * cw)) / a0;
            bqLowShelf110_.a2 = ((A + 1.0) + (A - 1.0) * cw - twoSqrtAAlpha) / a0;
        }
    }

    // Mid Sweepable Bell (300 Hz .. 7200 Hz, -12 .. +12 dB)
    {
        double fc = 300.0 * std::pow(7200.0 / 300.0, static_cast<double>(mid_freq_));
        double gaindB = (static_cast<double>(mid_gain_) - 0.5) * 24.0;
        if (std::abs(gaindB) < 1e-4) {
            bqMidBell_.setCoefficients(Biquad());
        } else {
            double A = std::pow(10.0, gaindB / 40.0);
            double Q = 0.70 + 0.55 * (std::abs(gaindB) / 12.0);
            double w0 = 2.0 * kPi * std::min(fc, 0.475 * sampleRate_) / sampleRate_;
            double cw = std::cos(w0), sw = std::sin(w0);
            double alpha = sw / (2.0 * Q);
            double a0 = 1.0 + alpha / A;
            bqMidBell_.b0 = (1.0 + alpha * A) / a0;
            bqMidBell_.b1 = (-2.0 * cw) / a0;
            bqMidBell_.b2 = (1.0 - alpha * A) / a0;
            bqMidBell_.a1 = (-2.0 * cw) / a0;
            bqMidBell_.a2 = (1.0 - alpha / A) / a0;
        }
    }

    // High Shelf at 10 kHz (-12 .. +12 dB)
    {
        double gaindB = (static_cast<double>(high_shelf_) - 0.5) * 24.0;
        double fc = 10000.0;
        if (std::abs(gaindB) < 1e-4) {
            bqHighShelf10k_.setCoefficients(Biquad());
        } else {
            double A = std::pow(10.0, gaindB / 40.0);
            double w0 = 2.0 * kPi * std::min(fc, 0.475 * sampleRate_) / sampleRate_;
            double cw = std::cos(w0), sw = std::sin(w0);
            double alpha = sw / (2.0 * 0.65);
            double twoSqrtAAlpha = 2.0 * std::sqrt(A) * alpha;
            double a0 = (A + 1.0) - (A - 1.0) * cw + twoSqrtAAlpha;
            bqHighShelf10k_.b0 = (A * ((A + 1.0) + (A - 1.0) * cw + twoSqrtAAlpha)) / a0;
            bqHighShelf10k_.b1 = (-2.0 * A * ((A - 1.0) + (A + 1.0) * cw)) / a0;
            bqHighShelf10k_.b2 = (A * ((A + 1.0) + (A - 1.0) * cw - twoSqrtAAlpha)) / a0;
            bqHighShelf10k_.a1 = (2.0 * ((A - 1.0) - (A + 1.0) * cw)) / a0;
            bqHighShelf10k_.a2 = ((A + 1.0) - (A - 1.0) * cw - twoSqrtAAlpha) / a0;
        }
    }
}

void UADCenturyChannelStrip::processBlock(float* left, float* right, int numSamples) {
    if (left == nullptr || numSamples <= 0) return;
    for (int i=0; i<numSamples; ++i) {
        left[i] = std::isfinite(left[i]) ? std::clamp(left[i], -64.0f, 64.0f) : 0.0f;
        if (right) right[i] = std::isfinite(right[i]) ? std::clamp(right[i], -64.0f, 64.0f) : 0.0f;
    }
    if (power_ < 0.5f) {
        currentGRdB_ = 0.0;
        currentVUdB_ = -60.0;
        return;
    }

    // Preamp input gain structure
    double polarity = (phase_ >= 0.5f) ? -1.0 : 1.0;
    double padGain = (input_select_ >= 0.5f && pad_ >= 0.5f) ? 0.1 : 1.0; // -20 dB pad in Mic mode
    double modeBoost = (input_select_ >= 0.5f) ? 2.0 : 1.0;               // Mic input transformer step-up
    double hiGainSwitch = (gain_ >= 0.5f) ? 2.511886 : 1.0;               // High gain (+8 dB tube stage boost)
    double driveAmount = 0.25 + 3.75 * static_cast<double>(level_);
    double totalPreampDrive = padGain * modeBoost * hiGainSwitch * driveAmount;
    double preampCompensate = 1.0 / std::max(0.5, std::sqrt(totalPreampDrive));

    // Master output fader: 0.5 = 0 dB, range -24 dB .. +12 dB
    double outdB = (output_ <= 0.5f)
        ? (static_cast<double>(output_) * 2.0 - 1.0) * 24.0
        : (static_cast<double>(output_) - 0.5) * 2.0 * 12.0;
    double masterGainLin = std::pow(10.0, outdB / 20.0);

    bool lowCutActive = (low_cut_ >= 0.5f);
    bool eqActive = (eq_in_ >= 0.5f);
    bool compActive = (gr_in_ >= 0.5f && compression_ > 0.005f);

    // Optical Leveler threshold & makeup
    double compAmount = static_cast<double>(compression_);
    double threshLin = std::pow(10.0, (-2.0 - 26.0 * compAmount) / 20.0);
    double ratio = 2.8 + 1.2 * compAmount; // Smooth ~3:1 to 4:1 optical knee
    double autoMakeupdB = 5.5 * compAmount;
    double autoMakeupLin = std::pow(10.0, autoMakeupdB / 20.0);

    for (int i = 0; i < numSamples; ++i) {
        double L = static_cast<double>(left[i]) * polarity;
        double R = (right ? static_cast<double>(right[i]) : static_cast<double>(left[i])) * polarity;

        // 1. 80 Hz 18 dB/oct Low Cut Filter
        if (lowCutActive) {
            bqLowCut2nd_.processStereo(L, R);
            bqLowCut1st_.processStereo(L, R);
        }

        // 2. Dual-Stage 12AX7 Triode Preamp Saturation
        auto triodeStage = [&](double x) -> double {
            double v = x * totalPreampDrive;
            // Asymmetric 12AX7 cathode-biased transfer curve (rich 2nd + 3rd harmonics)
            double asym = (v >= 0.0)
                ? std::tanh(v)
                : (std::tanh(v * 0.88) / 0.88);
            double evenHarm = 0.045 * v * v / (1.0 + v * v);
            return (asym + evenHarm) * preampCompensate;
        };
        L = triodeStage(L);
        R = triodeStage(R);
        bqDCBlocker_.processStereo(L, R);

        // 3. 3-Band Voiced Tube Equalizer
        if (eqActive) {
            bqLowShelf110_.processStereo(L, R);
            bqMidBell_.processStereo(L, R);
            bqHighShelf10k_.processStereo(L, R);
        }

        // 4. Electro-Optical Leveler (Compressor)
        if (compActive) {
            double det = std::max(std::abs(L), std::abs(R));
            if (det > optoFastEnv_) {
                optoFastEnv_ = attCoeff_ * optoFastEnv_ + (1.0 - attCoeff_) * det;
            } else {
                optoFastEnv_ = relFastCoeff_ * optoFastEnv_ + (1.0 - relFastCoeff_) * det;
            }
            if (det > optoSlowEnv_) {
                optoSlowEnv_ = attCoeff_ * optoSlowEnv_ + (1.0 - attCoeff_) * det;
            } else {
                optoSlowEnv_ = relSlowCoeff_ * optoSlowEnv_ + (1.0 - relSlowCoeff_) * det;
            }
            // Dual-release T4B electroluminescent blend (70% fast + 30% slow memory)
            double env = 0.70 * optoFastEnv_ + 0.30 * optoSlowEnv_;
            double grLin = 1.0;
            if (env > threshLin) {
                double overdB = 20.0 * std::log10(env / threshLin);
                // Soft optical knee
                double compressedOverdB = overdB / ratio;
                double grdB = compressedOverdB - overdB; // negative dB
                grLin = std::pow(10.0, grdB / 20.0);
                currentGRdB_ = -grdB;
            } else {
                currentGRdB_ *= 0.999;
            }
            L *= grLin * autoMakeupLin;
            R *= grLin * autoMakeupLin;
        } else {
            currentGRdB_ = 0.0;
        }

        // 5. Master Output Fader + VU Ballistics
        L *= masterGainLin;
        R *= masterGainLin;

        double outPeak = 0.5 * (std::abs(L) + std::abs(R));
        vuEnv_ = vuCoeff_ * vuEnv_ + (1.0 - vuCoeff_) * (outPeak * outPeak);
        currentVUdB_ = 10.0 * std::log10(std::max(1e-12, vuEnv_));

        left[i] = static_cast<float>(L);
        if (right) right[i] = static_cast<float>(R);
    }
}

double UADCenturyChannelStrip::getEQMagnitudeResponsedB(double freqHz) const {
    if (power_ < 0.5f) return 0.0;
    double dB = 0.0;
    if (low_cut_ >= 0.5f) {
        dB += bqLowCut2nd_.magResponsedB(freqHz, sampleRate_);
        dB += bqLowCut1st_.magResponsedB(freqHz, sampleRate_);
    }
    if (eq_in_ >= 0.5f) {
        dB += bqLowShelf110_.magResponsedB(freqHz, sampleRate_);
        dB += bqMidBell_.magResponsedB(freqHz, sampleRate_);
        dB += bqHighShelf10k_.magResponsedB(freqHz, sampleRate_);
    }
    return dB;
}

int UADCenturyChannelStrip::getGRNeedleFrame() const {
    // The submitted sprite has frame 0 at the right-hand 0 dB mark.
    // Increasing gain reduction moves the needle left toward frame 99.
    double norm = std::clamp(currentGRdB_ / 20.0, 0.0, 1.0);
    return std::clamp(static_cast<int>(std::round(norm * 99.0)), 0, 99);
}

int UADCenturyChannelStrip::getVUNeedleFrame() const {
    // -20 dB .. +3 dB mapped across 0..99 frames
    double norm = std::clamp((currentVUdB_ + 20.0) / 23.0, 0.0, 1.0);
    return std::clamp(static_cast<int>(std::round(norm * 99.0)), 0, 99);
}

} // namespace uad_uadcenturychannelstrip
