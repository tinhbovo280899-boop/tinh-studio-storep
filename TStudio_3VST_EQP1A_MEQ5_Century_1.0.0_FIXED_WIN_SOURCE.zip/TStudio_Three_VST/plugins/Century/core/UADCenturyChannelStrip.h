#pragma once
#include <cmath>
#include <algorithm>
#include "Presets.h"

namespace uad_uadcenturychannelstrip {

inline constexpr double kPi = 3.141592653589793238462643383279502884;


/**
 * UADx Century Tube Channel Strip — Complete C++ DSP Implementation
 *
 * Models the complete 3-stage vintage tube channel strip:
 * 1. Dual-Triode 12AX7 Tube Preamp Stage:
 *    - `input_select`: Line (0.0) vs Mic Transformer Input (1.0)
 *    - `low_cut`: 80 Hz 18 dB/octave (3rd-order Butterworth) High-Pass Filter
 *    - `phase`: 180-degree Polarity Invert
 *    - `pad`: -20 dB Input Attenuation Pad (active in Mic mode)
 *    - `gain`: Low / High Preamp Tube Gain structure switch
 *    - `level`: Continuous Preamp Tube Saturation / Drive Level (asymmetric triode waveshaper
 *      with grid-current soft limiting and DC blocker)
 *
 * 2. 3-Band Classic Voiced Tube Equalizer:
 *    - `high_shelf`: 10 kHz Baxandall High Shelf (-12.0 .. +12.0 dB)
 *    - `mid_freq`: Sweepable Mid Bell Frequency (300 Hz .. 7.2 kHz logarithmic taper)
 *    - `mid_gain`: Proportional-Q Tube Bell (-12.0 .. +12.0 dB)
 *    - `low_shelf`: 110 Hz Baxandall Low Shelf (-12.0 .. +12.0 dB)
 *    - `eq_in`: EQ Section In/Out Bypass
 *
 * 3. Electro-Optical Tube Leveler (Compressor):
 *    - `compression`: Single-knob Opto Leveler Amount (0..10) with T4B-style program-dependent
 *      dual-stage release (fast initial recovery + slow electroluminescent memory tail) and
 *      automatic makeup gain.
 *    - `gr_in`: Compressor Section In/Out Bypass
 *
 * 4. Master Output & Metering:
 *    - `output`: Master Output Fader (-24.0 .. +12.0 dB, 0.5 = 0 dB)
 *    - `power`: Master Channel Strip Power Bypass
 *    - Real-time GR Needle (`getGainReductiondB()`) and VU Needle (`getOutputVUdB()`) outputs
 *      mapped directly to the 100-frame `tube_cs_needle_GR.png` and `tube_cs_needle_VU.png` strips.
 */
class UADCenturyChannelStrip {
public:
    struct Biquad {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
        double z1L = 0.0, z2L = 0.0;
        double z1R = 0.0, z2R = 0.0;

        void reset() { z1L = z2L = z1R = z2R = 0.0; }

        // Parameter edits change coefficients, never the running filter history.
        void setCoefficients(const Biquad& c) noexcept {
            b0=c.b0; b1=c.b1; b2=c.b2; a1=c.a1; a2=c.a2;
        }

        inline void processStereo(double& L, double& R) {
            double outL = b0 * L + z1L;
            z1L = b1 * L - a1 * outL + z2L;
            z2L = b2 * L - a2 * outL;
            L = outL;

            double outR = b0 * R + z1R;
            z1R = b1 * R - a1 * outR + z2R;
            z2R = b2 * R - a2 * outR;
            R = outR;
        }

        double magResponsedB(double freqHz, double sampleRate) const {
            double w = 2.0 * kPi * freqHz / sampleRate;
            double cw = std::cos(w), c2w = std::cos(2.0 * w);
            double sw = std::sin(w), s2w = std::sin(2.0 * w);
            double numR = b0 + b1 * cw + b2 * c2w;
            double numI = -(b1 * sw + b2 * s2w);
            double denR = 1.0 + a1 * cw + a2 * c2w;
            double denI = -(a1 * sw + a2 * s2w);
            double mag2 = (numR * numR + numI * numI) / std::max(1e-18, denR * denR + denI * denI);
            return 10.0 * std::log10(std::max(1e-18, mag2));
        }
    };

    UADCenturyChannelStrip() { prepare(48000.0); }

    void prepare(double sampleRate);
    void reset();

    void setParameters(float inputSelect, float lowCut, float phase, float pad,
                       float gainSwitch, float preampLevel,
                       float highShelf, float midFreq, float midGain, float lowShelf, float eqIn,
                       float compression, float grIn, float output, float power);

    void loadPreset(int index);

    void processBlock(float* left, float* right, int numSamples);
    double getEQMagnitudeResponsedB(double freqHz) const;

    // Metering getters for GUI 100-frame needles
    double getGainReductiondB() const { return currentGRdB_; }
    double getOutputVUdB() const { return currentVUdB_; }
    int getGRNeedleFrame() const; // 0..99
    int getVUNeedleFrame() const; // 0..99

private:
    void updateFilters();

    double sampleRate_ = 48000.0;

    // Normalized parameters
    float input_select_ = 0.0f;
    float low_cut_ = 0.0f;
    float phase_ = 0.0f;
    float pad_ = 0.0f;
    float gain_ = 0.0f;
    float level_ = 0.35f;
    float high_shelf_ = 0.5f;
    float mid_freq_ = 0.5f;
    float mid_gain_ = 0.5f;
    float low_shelf_ = 0.5f;
    float eq_in_ = 1.0f;
    float compression_ = 0.0f;
    float gr_in_ = 1.0f;
    float output_ = 0.5f;
    float power_ = 1.0f;

    // 80 Hz 18 dB/oct HPF (2nd-order biquad + 1st-order pole)
    Biquad bqLowCut2nd_;
    Biquad bqLowCut1st_;

    // DC Blocker after asymmetric 12AX7 triode saturation
    Biquad bqDCBlocker_;

    // 3-Band Tube EQ
    Biquad bqLowShelf110_;
    Biquad bqMidBell_;
    Biquad bqHighShelf10k_;

    // Electro-Optical Leveler state (dual-time-constant T4B cell)
    double optoFastEnv_ = 0.0;
    double optoSlowEnv_ = 0.0;
    double attCoeff_ = 0.0;
    double relFastCoeff_ = 0.0;
    double relSlowCoeff_ = 0.0;

    // VU meter ballistics
    double vuEnv_ = 0.0;
    double vuCoeff_ = 0.0;

    double currentGRdB_ = 0.0;
    double currentVUdB_ = -60.0;
};

} // namespace uad_uadcenturychannelstrip
