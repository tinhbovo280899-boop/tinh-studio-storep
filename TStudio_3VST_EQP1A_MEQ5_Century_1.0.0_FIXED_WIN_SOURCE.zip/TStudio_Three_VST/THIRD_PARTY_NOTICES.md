# Third-party sources

JUCE 8.0.12 is included under `third_party/JUCE`. Its existing copyright, licence and bundled dependency notices are retained. See `third_party/JUCE/LICENSE.md` and the notices accompanying its modules.

The DSP implementations, original preset data and graphical assets were supplied in the user's `1_UAD_Pultec_EQP1A.zip`, `2_UAD_Pultec_MEQ5.zip` and `3_UAD_Century_Channel_Strip.zip`. Original comments, resource names and graphical marks are retained. Asset attribution is not a claim of authorship by T Studio or of approval by the original manufacturer. This bundle does not establish that the submitted C++ implementations were recovered from the manufacturer's binaries.

The new JUCE processor/editor, CMake integration, export script and corrective source changes are provided for the user's project. No original manufacturer executable, activation material or private signing key is distributed here. VST3 interface sources and their notices are included with JUCE.
