#include "PluginProcessor.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include <cstdio>
#include <cstdlib>
#include <new>
#include <limits>
static std::atomic<bool> countNew{false};static std::atomic<unsigned long long> cppNew{0};
void* operator new(std::size_t n){if(countNew.load())++cppNew;if(auto* p=std::malloc(n?n:1))return p;throw std::bad_alloc();}
void* operator new[](std::size_t n){return ::operator new(n);}
void operator delete(void* p) noexcept {std::free(p);}void operator delete[](void* p) noexcept {std::free(p);}
void operator delete(void* p,std::size_t) noexcept {std::free(p);}void operator delete[](void* p,std::size_t) noexcept {std::free(p);}
static int failures=0,checks=0;
#define CHECK(x) do {++checks;if(!(x)){if(failures<20)std::printf("FAIL line %d: %s\n",__LINE__,#x);++failures;}}while(false)
static void set(studio::PluginProcessor& p,const char* id,float value){auto* q=p.state.getParameter(id);CHECK(q);if(q)q->setValueNotifyingHost(value);}
static juce::Component* find(juce::Component& c,const juce::String& id){if(c.getComponentID()==id)return &c;for(int i=0;i<c.getNumChildComponents();++i)if(auto* found=find(*c.getChildComponent(i),id))return found;return nullptr;}
int main(){
 juce::ScopedJuceInitialiser_GUI gui;
 for(int cycle=0;cycle<6;++cycle){
  studio::PluginProcessor p;const int channels=cycle%2?1:2,block=cycle%3?128:7;const double sr=cycle%2?96000:48000;
  p.setPlayConfigDetails(channels,channels,sr,block);p.prepareToPlay(sr,block);CHECK(p.getLatencySamples()==0);CHECK(p.getParameters().size()==studio::parameterCount);
  juce::AudioBuffer<float>b(channels,block);juce::MidiBuffer midi;
  for(int preset=0;preset<p.getNumPrograms();++preset){
   p.setCurrentProgram(preset);const auto values=studio::presetValues(preset);
   for(int i=0;i<studio::dspParameterCount;++i)CHECK(std::abs(p.parameter(i)-values[size_t(i)])<2.e-5f);
   for(int k=0;k<4;++k){for(int i=0;i<block;++i)for(int c=0;c<channels;++c)b.setSample(c,i,.08f*std::sin(float((k*block+i)*.071+c*.1)));p.processBlock(b,midi);
    for(int c=0;c<channels;++c)for(int i=0;i<block;++i)CHECK(std::isfinite(b.getSample(c,i)));}
  }
  p.setCurrentProgram(studio::defaultPreset);set(p,"bypass",0);p.reset();
  juce::MemoryBlock state;p.getStateInformation(state);studio::PluginProcessor restored;restored.setStateInformation(state.getData(),int(state.getSize()));
  CHECK(restored.getCurrentProgram()==p.getCurrentProgram());for(int i=0;i<studio::parameterCount;++i)CHECK(p.parameter(i)==restored.parameter(i));
  auto xml=juce::AudioProcessor::getXmlFromBinary(state.getData(),int(state.getSize()));CHECK(xml!=nullptr);
  if(xml){xml->setAttribute("product","OTHER PRODUCT");juce::AudioProcessor::copyXmlToBinary(*xml,state);const auto before=restored.parameter(0);restored.setStateInformation(state.getData(),int(state.getSize()));CHECK(restored.parameter(0)==before);}
  // Exercise both values of every boolean and non-default continuous values.
  for(int pass=0;pass<2;++pass){
   for(int i=0;i<studio::parameterCount;++i)set(p,studio::parameterSpecs[size_t(i)].id,
       studio::parameterSpecs[size_t(i)].kind==studio::Kind::Switch?float(pass):float((i*17+pass*23)%101)/100.f);
   p.getStateInformation(state);restored.setStateInformation(state.getData(),int(state.getSize()));
   for(int i=0;i<studio::parameterCount;++i)CHECK(std::abs(p.parameter(i)-restored.parameter(i))<2.e-5f);
  }
  p.setCurrentProgram(studio::defaultPreset);set(p,"bypass",0);p.reset();
  // Direct host bypass and the bypass parameter must both settle to exact dry.
  for(int mode=0;mode<2;++mode){set(p,"bypass",mode==0?1.f:0.f);
   for(int k=0;k<int(sr*.04)/block+1;++k){b.clear();if(mode)p.processBlockBypassed(b,midi);else p.processBlock(b,midi);}
   for(int i=0;i<block;++i)for(int c=0;c<channels;++c)b.setSample(c,i,.123f);
   if(mode)p.processBlockBypassed(b,midi);else p.processBlock(b,midi);
   for(int c=0;c<channels;++c)for(int i=0;i<block;++i)CHECK(std::abs(b.getSample(c,i)-.123f)<1.e-6f);
  }
  set(p,"bypass",0);p.reset();
  for(int k=0;k<32;++k){b.clear();p.processBlock(b,midi);}
  cppNew=0;countNew=true;
  for(int k=0;k<100;++k){b.clear();p.processBlock(b,midi);}
  countNew=false;CHECK(cppNew.load()==0);std::printf("AUDIO_ALLOCS cycle=%d cpp_new=%llu\n",cycle,cppNew.load());
  b.clear();b.setSample(0,0,std::numeric_limits<float>::quiet_NaN());b.setSample(0,1,std::numeric_limits<float>::infinity());p.processBlock(b,midi);
  for(int c=0;c<channels;++c)for(int i=0;i<block;++i)CHECK(std::isfinite(b.getSample(c,i)));
  p.reset();b.clear();p.processBlock(b,midi);CHECK(b.getMagnitude(0,block)==0);
  #if TSTUDIO_PRODUCT == 2
  if(cycle==1){
   float meter[2]{};
   for(int pass=0;pass<2;++pass){
    set(p,"output",pass==0?.25f:.75f);p.reset();
    for(int k=0;k<600;++k){for(int i=0;i<block;++i)b.setSample(0,i,.08f*std::sin(float((k*block+i)*.071)));p.processBlock(b,midi);}
    meter[pass]=p.vuDb.load();
   }
   CHECK(std::abs(meter[1]-meter[0]-18.f)<.01f);
   p.setCurrentProgram(studio::defaultPreset);p.reset();
  }
  #endif
  if(cycle<3){
   std::unique_ptr<juce::AudioProcessorEditor> e(p.createEditor());CHECK(e!=nullptr);
   for(int i=0;i<studio::parameterCount;++i)CHECK(find(*e,"param_"+juce::String(studio::parameterSpecs[size_t(i)].id))!=nullptr);
   // Every drawn panel control must send its value to the matching host parameter.
   for(const auto& spec:studio::parameterSpecs){
    auto* component=find(*e,"param_"+juce::String(spec.id));
    if(auto* slider=dynamic_cast<juce::Slider*>(component)){
     slider->setValue(.75,juce::sendNotificationSync);
     CHECK(std::abs(p.parameter(spec.id)-float(slider->getValue()))<2.e-5f);
    }else if(auto* button=dynamic_cast<juce::Button*>(component)){
     for(bool enabled:{true,false}){button->setToggleState(enabled,juce::sendNotificationSync);CHECK(p.parameter(spec.id)==float(enabled));}
    }
   }
   p.setCurrentProgram(studio::defaultPreset);set(p,"bypass",0);
   const auto first=std::find_if(studio::parameterSpecs.begin(),studio::parameterSpecs.end(),[](const auto& s){return s.kind==studio::Kind::Knob;});
   if(first!=studio::parameterSpecs.end())if(auto* slider=dynamic_cast<juce::Slider*>(find(*e,"param_"+juce::String(first->id)))){
    slider->setValue(.75,juce::sendNotificationSync);CHECK(std::abs(p.parameter(first->id)-.75f)<1.e-5f);
   }
   const auto snap=juce::SystemStats::getEnvironmentVariable("TSTUDIO_QA_SNAPSHOT_DIR",{});
   if(cycle==0&&snap.isNotEmpty()){
    std::printf("SNAPSHOT gr=%.6f vu=%.6f power=%d\n",double(p.gainReductionDb.load()),double(p.vuDb.load()),int(p.powered()));
    #if JUCE_MODAL_LOOPS_PERMITTED
    juce::MessageManager::getInstance()->runDispatchLoopUntil(40);
    #endif
    juce::Image image(juce::Image::ARGB,e->getWidth(),e->getHeight(),true);juce::Graphics g(image);e->paintEntireComponent(g,true);
    auto output=juce::File(snap).getChildFile(juce::String(studio::productName)+".png").createOutputStream();CHECK(output!=nullptr);
    if(output){CHECK(output->setPosition(0));CHECK(output->truncate().wasOk());CHECK(juce::PNGImageFormat().writeImageToStream(image,*output));}
   }
   {juce::MessageManagerLock lock;e.reset();}
  }
  p.releaseResources();
 }
 std::printf("%s PLUGIN: %d checks, %d failures; 6 processor / 3 editor lifecycles\n",studio::productName,checks,failures);return failures?1:0;
}
