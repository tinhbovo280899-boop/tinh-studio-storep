#include "plugins/EQP1A/core/UADPultecEQP1A.h"
#include "plugins/MEQ5/core/UADPultecMEQ5.h"
#include "plugins/Century/core/UADCenturyChannelStrip.h"
#include <array>
#include <vector>
#include <limits>
#include <cstdio>
#include <cmath>
#include <cstring>
#include <iterator>

using EQ=uad_uadpulteceqp1a::UADPultecEQP1A;
using MEQ=uad_uadpultecmeq5::UADPultecMEQ5;
using Strip=uad_uadcenturychannelstrip::UADCenturyChannelStrip;
static int failures=0, checks=0;
#define CHECK(x) do {++checks;if(!(x)){if(failures<15)std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;}}while(false)
static void configure(EQ& p){p.setParameters(.666667f,.6f,.2f,.5f,.4f,.6f,.5f,.2f,1,.5f);}
static void configure(MEQ& p){p.setParameters(.25f,.6f,.4f,.3f,.5f,.4f,1,.5f);}
static void configure(Strip& p){p.setParameters(0,1,1,0,1,.6f,.6f,.4f,.3f,.6f,1,.8f,1,.5f,1);}
template<class T> void repeatedParameters(const char* name){
 T p,q;p.prepare(48000);q.prepare(48000);configure(p);configure(q);
 double difference=0;
 for(int off=0;off<48000;off+=128){
  const int n=std::min(128,48000-off);std::array<float,128>a{},b{},ar{},br{};
  for(int i=0;i<n;++i)a[i]=b[i]=ar[i]=br[i]=float(.04*std::sin((off+i)*.01308996939)+.02*std::sin((off+i)*.1308996939));
  configure(p);p.processBlock(a.data(),ar.data(),n);q.processBlock(b.data(),br.data(),n);
  for(int i=0;i<n;++i)difference=std::max(difference,std::abs(double(a[i])-b[i]));
 }
 std::printf("REPEATED_PARAMETERS %s max_difference=%.12g\n",name,difference);CHECK(difference==0);
}
static void monoPolarity(){
 Strip p,q;p.prepare(48000);q.prepare(48000);configure(p);configure(q);double error=0;
 for(int off=0;off<48000;off+=128){
  std::array<float,128>a{},b{},right{};const int n=std::min(128,48000-off);
  for(int i=0;i<n;++i)a[i]=b[i]=right[i]=float(.3*std::sin((off+i)*.071)+.13*std::cos((off+i)*.013));
  p.processBlock(a.data(),nullptr,n);q.processBlock(b.data(),right.data(),n);
  for(int i=0;i<n;++i)error=std::max(error,std::abs(double(a[i])-b[i]));
 }
 std::printf("MONO_POLARITY max_difference_vs_identical_stereo=%.12g\n",error);CHECK(error==0);
}
template<class T> void safety(const char* name){
 for(double sr:{8000.,16000.,32000.,44100.,48000.,96000.,192000.,384000.,std::numeric_limits<double>::infinity()}){
  T p;p.prepare(sr);configure(p);
  std::array<float,128> l{},r{};
  for(int k=0;k<48;++k){
   for(int i=0;i<128;++i){l[i]=.05f*std::sin((i+k*128)*.035f);r[i]=-.03f*std::cos((i+k*128)*.023f);}
   if(k==3){l[10]=std::numeric_limits<float>::quiet_NaN();r[11]=std::numeric_limits<float>::infinity();}
   p.processBlock(l.data(),r.data(),128);
   for(int i=0;i<128;++i)CHECK(std::isfinite(l[i])&&std::isfinite(r[i]));
  }
  p.reset();l.fill(0);r.fill(0);p.processBlock(l.data(),r.data(),128);
  for(int i=0;i<128;++i)CHECK(l[i]==0&&r[i]==0);
 }
 std::printf("SAFETY %s rates/NaN/Inf/reset completed\n",name);
}
template<class T> void presets(const char* name,int n){
 for(int i=0;i<n;++i){T p;p.prepare(48000);p.loadPreset(i);std::array<float,256>x{},y{};
  for(int k=0;k<4;++k){for(int t=0;t<256;++t)x[t]=y[t]=.1f*std::sin((k*256+t)*.037f);p.processBlock(x.data(),y.data(),256);
   for(int t=0;t<256;++t)CHECK(std::isfinite(x[t])&&std::isfinite(y[t]));}
 }
 std::printf("PRESETS %s count=%d completed\n",name,n);
}
static void invalidParameters(){
 const float bad=std::numeric_limits<float>::quiet_NaN();
 EQ p;p.prepare(48000);p.setParameters(bad,bad,bad,bad,bad,bad,bad,bad,bad,bad);
 MEQ q;q.prepare(48000);q.setParameters(bad,bad,bad,bad,bad,bad,bad,bad);
 Strip r;r.prepare(48000);r.setParameters(bad,bad,bad,bad,bad,bad,bad,bad,bad,bad,bad,bad,bad,bad,bad);
 std::array<float,256>a{},b{};a[10]=b[10]=.1f;p.processBlock(a.data(),b.data(),256);q.processBlock(a.data(),b.data(),256);r.processBlock(a.data(),b.data(),256);
 for(int i=0;i<256;++i)CHECK(std::isfinite(a[i])&&std::isfinite(b[i]));
}
static void reductionNeedle(){
 Strip p;p.prepare(48000);CHECK(p.getGRNeedleFrame()==0);configure(p);
 std::array<float,128>x{};
 for(int k=0;k<400;++k){for(int i=0;i<128;++i)x[i]=.7f*std::sin(float((k*128+i)*.071));p.processBlock(x.data(),nullptr,128);}
 CHECK(p.getGainReductiondB()>0);
 CHECK(p.getGRNeedleFrame()==int(std::round(std::clamp(p.getGainReductiondB()/20.,0.,1.)*99)));
 p.reset();CHECK(p.getGRNeedleFrame()==0);
 std::printf("GR_NEEDLE zero-at-frame-0, reduction-left, reset completed\n");
}
int main(int argc,char** argv){
 repeatedParameters<EQ>("EQP1A");repeatedParameters<MEQ>("MEQ5");repeatedParameters<Strip>("Century");monoPolarity();
 if(argc==1||std::strcmp(argv[1],"--baseline")!=0){
  safety<EQ>("EQP1A");safety<MEQ>("MEQ5");safety<Strip>("Century");invalidParameters();reductionNeedle();
  presets<EQ>("EQP1A",int(std::size(uad_uadpulteceqp1a::kFactoryPresets)));
  presets<MEQ>("MEQ5",int(std::size(uad_uadpultecmeq5::kFactoryPresets)));
  presets<Strip>("Century",int(std::size(uad_uadcenturychannelstrip::kFactoryPresets)));
 }
 std::printf("CORE REGRESSION: %d checks, %d failures\n",checks,failures);return failures?1:0;
}
