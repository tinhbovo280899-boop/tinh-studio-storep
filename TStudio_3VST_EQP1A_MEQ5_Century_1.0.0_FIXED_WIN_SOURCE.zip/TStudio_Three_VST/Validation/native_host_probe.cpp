#include "pluginterfaces/base/ipluginbase.h"
#include "pluginterfaces/vst/ivstaudioprocessor.h"
#include "pluginterfaces/vst/ivstcomponent.h"
#include <dlfcn.h>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace Steinberg;
using namespace Steinberg::Vst;
int main(int argc,char**argv){
    if(argc<2||argc>3)return 2;
    const bool m2s=argc==3 && std::strcmp(argv[2],"mono-to-stereo")==0;
    const bool duplicate=argc==3 && std::strcmp(argv[2],"duplicate-stereo")==0;
    const int channels=argc==3 && !m2s && !duplicate?1:2;
    const int inputChannels=m2s?1:channels;
    void* lib=dlopen(argv[1],RTLD_NOW|RTLD_LOCAL);
    if(!lib){std::printf("DLOPEN_FAIL %s\n",dlerror());return 3;}
    auto entry=(bool(*)(void*))dlsym(lib,"ModuleEntry");auto exitModule=(bool(*)())dlsym(lib,"ModuleExit");
    if(entry&&!entry(lib))return 4;
    auto getFactory=(IPluginFactory*(*)())dlsym(lib,"GetPluginFactory");if(!getFactory)return 5;
    IPluginFactory* factory=getFactory();int failures=0;
    for(int ci=0;ci<factory->countClasses();++ci){
        PClassInfo info{};factory->getClassInfo(ci,&info);
        if(std::strcmp(info.category,kVstAudioEffectClass)!=0)continue;
        IComponent* component=nullptr;IAudioProcessor* processor=nullptr;
        if(factory->createInstance(info.cid,IComponent_iid,(void**)&component)!=kResultOk||!component)return 6;
        if(component->initialize(nullptr)!=kResultOk)return 7;
        if(component->queryInterface(IAudioProcessor_iid,(void**)&processor)!=kResultOk)return 8;
        SpeakerArrangement layout=channels==1?SpeakerArr::kMono:SpeakerArr::kStereo;
        const int inputCount=component->getBusCount(kAudio,kInput);
        SpeakerArrangement inputLayouts[2]{inputChannels==1?SpeakerArr::kMono:SpeakerArr::kStereo,SpeakerArr::kEmpty};
        if(inputCount<1||inputCount>2)return 11;
        if(processor->setBusArrangements(inputLayouts,inputCount,&layout,1)!=kResultOk)return 10;
        component->activateBus(kAudio,kInput,0,true);component->activateBus(kAudio,kOutput,0,true);
        if(inputCount>1)component->activateBus(kAudio,kInput,1,false);
        for(double sr:{44100.,48000.,96000.}){
            ProcessSetup setup{};setup.processMode=kRealtime;setup.symbolicSampleSize=kSample32;setup.maxSamplesPerBlock=128;setup.sampleRate=sr;
            if(processor->setupProcessing(setup)!=kResultOk)return 9;
            component->setActive(true);processor->setProcessing(true);
            float il[128],ir[128],ol[128],orr[128];float* ins[]{il,ir};float* outs[]{ol,orr};
            AudioBusBuffers ib[2]{},ob{};ib[0].numChannels=inputChannels;ib[0].channelBuffers32=ins;ob.numChannels=channels;ob.channelBuffers32=outs;
            ProcessData pd{};pd.processMode=kRealtime;pd.symbolicSampleSize=kSample32;pd.numInputs=inputCount;pd.numOutputs=1;pd.inputs=ib;pd.outputs=&ob;
            float peak=0;bool finite=true;int samples=0;unsigned long long checksum=1469598103934665603ULL;
            for(int b=0;b<1200;++b){
                pd.numSamples=b%3==0?64:128;
                for(int i=0;i<pd.numSamples;++i){il[i]=.1f*std::sin(6.283185307179586*220*(samples+i)/sr);ir[i]=duplicate?il[i]:.07f*std::sin(6.283185307179586*330*(samples+i)/sr);ol[i]=orr[i]=0;}
                if(processor->process(pd)!=kResultOk){++failures;break;}
                for(int i=0;i<pd.numSamples;++i){finite&=std::isfinite(ol[i])&&std::isfinite(orr[i]);peak=std::max({peak,std::abs(ol[i]),std::abs(orr[i])});}
                for(int c=0;c<channels;++c)for(int i=0;i<pd.numSamples;++i){unsigned int bits=0;std::memcpy(&bits,&outs[c][i],sizeof(bits));checksum^=bits;checksum*=1099511628211ULL;}
                samples+=pd.numSamples;
            }
            std::printf("VST3 %s inputs=%d outputs=%d sr=%.0f variable_blocks=64/128 finite=%d peak=%.9f latency=%u tail_samples=%u checksum=%llu\n",info.name,inputChannels,channels,sr,(int)finite,peak,processor->getLatencySamples(),processor->getTailSamples(),checksum);
            failures+=!finite;
            processor->setProcessing(false);component->setActive(false);
        }
        processor->release();component->terminate();component->release();
    }
    factory->release();if(exitModule)exitModule();dlclose(lib);return failures?1:0;
}
