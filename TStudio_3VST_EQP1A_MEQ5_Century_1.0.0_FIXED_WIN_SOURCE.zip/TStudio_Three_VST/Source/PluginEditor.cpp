#include "PluginProcessor.h"
#include "StudioImages.h"
#include <functional>

namespace studio {
static juce::Image resourceImage(const char* name){int size=0;const auto* data=StudioImages::getNamedResource(name,size);return data&&size>0?juce::ImageCache::getFromMemory(data,size):juce::Image{};}
struct Sprite {
    AtlasSpec spec;juce::Image image;
    explicit Sprite(AtlasSpec s):spec(s),image(resourceImage(s.resource)){}
    void draw(juce::Graphics& g,juce::Rectangle<float> bounds,float norm) const {
        if(!image.isValid())return;
        const int frame=juce::jlimit(0,spec.frames-1,juce::roundToInt(norm*float(spec.frames-1)));
        g.drawImage(image,bounds.getX(),bounds.getY(),bounds.getWidth(),bounds.getHeight(),
            (frame%spec.columns)*spec.frameWidth,(frame/spec.columns)*spec.frameHeight,spec.frameWidth,spec.frameHeight,false);
    }
};
class SpriteSlider final:public juce::Slider {
public:
    explicit SpriteSlider(AtlasSpec s):sprite(s){setSliderStyle(RotaryHorizontalVerticalDrag);setTextBoxStyle(NoTextBox,false,0,0);setMouseDragSensitivity(180);setWantsKeyboardFocus(false);}
    void paint(juce::Graphics& g) override {sprite.draw(g,getLocalBounds().toFloat(),float(valueToProportionOfLength(getValue())));}
private:Sprite sprite;
};
class SpriteButton final:public juce::Button {
public:
    explicit SpriteButton(AtlasSpec s):Button(""),sprite(s){setClickingTogglesState(true);setWantsKeyboardFocus(false);}
    std::function<float()> frameValue;
    bool centerHotspot=false;
    bool hitTest(int x,int y) override {return !centerHotspot||getLocalBounds().reduced(getWidth()/4,getHeight()/4).contains(x,y);}
    void paintButton(juce::Graphics& g,bool,bool) override {sprite.draw(g,getLocalBounds().toFloat(),frameValue?frameValue():getToggleState()?1.f:0.f);}
private:Sprite sprite;
};

class PluginEditor final:public juce::AudioProcessorEditor,private juce::Timer {
public:
    explicit PluginEditor(PluginProcessor& p):AudioProcessorEditor(p),processor(p),panel(resourceImage(panelResource)),tooltips(this,750){
        setOpaque(true);setWantsKeyboardFocus(false);
        preset.setComponentID("factoryPreset");
        for(int i=0;i<presetCount;++i)preset.addItem(juce::String::fromUTF8(presetName(i)),i+1);
        preset.setSelectedId(p.getCurrentProgram()+1,juce::dontSendNotification);
        preset.onChange=[this]{processor.setCurrentProgram(preset.getSelectedId()-1);};addAndMakeVisible(preset);
        bypass.setButtonText("BYPASS");bypass.setComponentID("param_bypass");addAndMakeVisible(bypass);
        bypassAttachment=std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,"bypass",bypass);
        for(const auto& layout:controlLayouts){
            const int index=parameterIndex(layout.id);jassert(index>=0);
            const auto& spec=parameterSpecs[size_t(index)];
            if(spec.kind==Kind::Switch){
                auto button=std::make_unique<SpriteButton>(layout.atlas);button->setComponentID("param_"+juce::String(layout.id));button->setTooltip(spec.label);
                addAndMakeVisible(*button);buttonAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment>(p.state,layout.id,*button));
                controls.push_back({button.get(),layout.bounds});buttons.push_back(std::move(button));
            }else{
                auto slider=std::make_unique<SpriteSlider>(layout.atlas);slider->setComponentID("param_"+juce::String(layout.id));slider->setTooltip(spec.label);
                slider->setDoubleClickReturnValue(true,spec.defaultValue);
                slider->onDragStart=[this,index]{selected=index;repaint();};slider->onValueChange=[this,index]{selected=index;repaint();};
                addAndMakeVisible(*slider);sliderAttachments.push_back(std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment>(p.state,layout.id,*slider));
                controls.push_back({slider.get(),layout.bounds});sliders.push_back(std::move(slider));
            }
        }
        #if TSTUDIO_PRODUCT != 2
        const AtlasSpec lamp={TSTUDIO_PRODUCT==0?"pultec_power_light_1_png":"pultec_power_light_2_png",170,170,2,2};
        powerLamp=std::make_unique<SpriteButton>(lamp);powerLamp->centerHotspot=true;powerLamp->setClickingTogglesState(false);powerLamp->setComponentID("powerLamp");
        powerLamp->frameValue=[this]{return processor.powered()?1.f:0.f;};
        powerLamp->onClick=[this]{if(auto* out=processor.state.getParameter("output")){out->beginChangeGesture();out->setValueNotifyingHost(processor.powered()?0.f:savedOutput);out->endChangeGesture();}};
        powerLamp->setTooltip("Power: click to switch off / restore Output");addAndMakeVisible(*powerLamp);
        #else
        grNeedle=std::make_unique<Sprite>(AtlasSpec{"tube_cs_needle_GR_png",302,190,100,8});
        vuNeedle=std::make_unique<Sprite>(AtlasSpec{"tube_cs_needle_VU_png",302,190,100,8});
        greenLed=std::make_unique<Sprite>(AtlasSpec{"tube_cs_led_green_png",34,60,2,2});
        #endif
        setResizable(true,true);getConstrainer()->setFixedAspectRatio(double(panelWidth)/double(panelHeight+headerHeight+footerHeight));
        setResizeLimits(int(panelWidth*.75),int((panelHeight+headerHeight+footerHeight)*.75),int(panelWidth*1.5),int((panelHeight+headerHeight+footerHeight)*1.5));
        setSize(panelWidth,panelHeight+headerHeight+footerHeight);startTimerHz(30);
    }
    ~PluginEditor() override {stopTimer();preset.onChange=nullptr;}
    void paint(juce::Graphics& g) override {
        const float sx=float(getWidth())/panelWidth,sy=float(getHeight())/(panelHeight+headerHeight+footerHeight);
        g.fillAll(juce::Colour(0xff171b20));
        g.setColour(juce::Colour(0xff77d6d9));g.setFont(16.f*sy);g.drawText(juce::String("T STUDIO  /  ")+productName,10,int(3*sy),int(320*sx),int(32*sy),juce::Justification::centredLeft);
        g.drawImage(panel,juce::Rectangle<float>(0,headerHeight*sy,float(getWidth()),panelHeight*sy));
        #if TSTUDIO_PRODUCT == 2
        if(grNeedle)grNeedle->draw(g,scaled({390,64,151,95}),juce::jlimit(0.f,1.f,processor.gainReductionDb.load()/20.f));
        if(vuNeedle)vuNeedle->draw(g,scaled({576,64,151,95}),juce::jlimit(0.f,1.f,(processor.vuDb.load()+20.f)/23.f));
        if(greenLed){
            const bool power=processor.powered();
            greenLed->draw(g,scaled({327,438,17,30}),power&&processor.parameter("eq_in")>=.5f?0.f:1.f);
            greenLed->draw(g,scaled({512,438,17,30}),power&&processor.parameter("gr_in")>=.5f?0.f:1.f);
            greenLed->draw(g,scaled({700,438,17,30}),power?0.f:1.f);
        }
        #endif
        g.setColour(juce::Colour(0xffdce2e7));g.setFont(13.f*sy);
        const auto value=parameterText(parameterSpecs[size_t(selected)],processor.parameter(selected));
        g.drawText(juce::String(parameterSpecs[size_t(selected)].label)+": "+value,10,int((headerHeight+panelHeight+2)*sy),int((panelWidth-20)*sx),int(21*sy),juce::Justification::centredLeft);
        g.setColour(juce::Colour(0xffa8b2bf));g.setFont(11.f*sy);
        const auto text="IN "+juce::String(processor.inputDb.load(),1)+" dBFS    OUT "+juce::String(processor.outputDb.load(),1)+" dBFS";
        g.drawText(text,10,int((headerHeight+panelHeight+23)*sy),int((panelWidth-20)*sx),int(20*sy),juce::Justification::centredLeft);
    }
    void resized() override {
        const float sx=float(getWidth())/panelWidth,sy=float(getHeight())/(panelHeight+headerHeight+footerHeight);
        preset.setBounds(int((panelWidth-410)*sx),int(7*sy),int(285*sx),int(25*sy));
        bypass.setBounds(int((panelWidth-112)*sx),int(7*sy),int(100*sx),int(25*sy));
        for(auto& c:controls)c.component->setBounds(scaled(c.bounds).toNearestInt());
        #if TSTUDIO_PRODUCT != 2
        if(powerLamp)powerLamp->setBounds(scaled(TSTUDIO_PRODUCT==0?juce::Rectangle<int>{724,101,85,85}:juce::Rectangle<int>{796,2,85,85}).toNearestInt());
        #endif
    }
private:
    juce::Rectangle<float> scaled(juce::Rectangle<int> b) const {
        const float sx=float(getWidth())/panelWidth,sy=float(getHeight())/(panelHeight+headerHeight+footerHeight);
        return {b.getX()*sx,(b.getY()+headerHeight)*sy,b.getWidth()*sx,b.getHeight()*sy};
    }
    static int parameterIndex(const char* id){for(int i=0;i<parameterCount;++i)if(juce::String(id)==parameterSpecs[size_t(i)].id)return i;return -1;}
    void timerCallback() override {
        const int current=processor.getCurrentProgram()+1;if(preset.getSelectedId()!=current)preset.setSelectedId(current,juce::dontSendNotification);
        #if TSTUDIO_PRODUCT != 2
        if(processor.powered())savedOutput=processor.parameter("output");
        if(powerLamp)powerLamp->repaint();
        #else
        for(auto& button:buttons)if(button->getComponentID()=="param_pad")button->setEnabled(processor.parameter("input_select")>=.5f);
        #endif
        repaint();
    }
    struct Positioned {juce::Component* component;juce::Rectangle<int> bounds;};
    static constexpr int headerHeight=40,footerHeight=48;
    PluginProcessor& processor;juce::Image panel;juce::TooltipWindow tooltips;
    juce::ComboBox preset;juce::ToggleButton bypass;
    std::vector<std::unique_ptr<SpriteSlider>> sliders;std::vector<std::unique_ptr<SpriteButton>> buttons;
    std::vector<Positioned> controls;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment>> sliderAttachments;
    std::vector<std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment>> buttonAttachments;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> bypassAttachment;
    std::unique_ptr<SpriteButton> powerLamp;std::unique_ptr<Sprite> grNeedle,vuNeedle,greenLed;
    int selected=0;float savedOutput=.5f;
};
juce::AudioProcessorEditor* PluginProcessor::createEditor(){return new PluginEditor(*this);}
}
