#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include <array>
#include <vector>
#include <iterator>
namespace studio {
enum class Kind { Knob, Choice, Switch, EqOutput, StripOutput, ToneDB, MidHz };
struct ParameterSpec {const char* id;const char* label;Kind kind;float defaultValue;const char* choices;};
struct AtlasSpec {const char* resource;int frameWidth,frameHeight,frames,columns;};
struct ControlLayout {const char* id;juce::Rectangle<int> bounds;AtlasSpec atlas;};
}
#if TSTUDIO_PRODUCT == 0
#include "../plugins/EQP1A/core/UADPultecEQP1A.h"
namespace studio {
using Core = uad_uadpulteceqp1a::UADPultecEQP1A;
inline constexpr const char* productName="T-EQP1A";
inline constexpr int panelWidth=950, panelHeight=264;
inline constexpr const char* panelResource="pultec_eqp_1a_back_png";
inline constexpr int dspParameterCount=10, parameterCount=dspParameterCount+1;
inline constexpr int defaultPreset=13;
inline constexpr int presetCount=static_cast<int>(std::size(uad_uadpulteceqp1a::kFactoryPresets));
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
    {"low_freq","Low Frequency",Kind::Choice,0.333333000f,"20 Hz|30 Hz|60 Hz|100 Hz"},
    {"lf_boost","Low Boost",Kind::Knob,0.000000000f,""},
    {"lf_atten","Low Attenuation",Kind::Knob,0.000000000f,""},
    {"high_freq","High Frequency",Kind::Choice,0.500000000f,"3 kHz|4 kHz|5 kHz|8 kHz|10 kHz|12 kHz|16 kHz"},
    {"hf_boost","High Boost",Kind::Knob,0.000000000f,""},
    {"hf_q","Bandwidth",Kind::Knob,0.000000000f,""},
    {"hf_atten_freq","HF Attenuation Frequency",Kind::Choice,0.500000000f,"5 kHz|10 kHz|20 kHz"},
    {"hf_atten","High Attenuation",Kind::Knob,0.000000000f,""},
    {"enable","EQ In",Kind::Switch,1.000000000f,""},
    {"output","Output / Power",Kind::EqOutput,0.500000000f,""},
    {"bypass","Bypass",Kind::Switch,0.f,""}
}};
inline std::array<float,dspParameterCount> presetValues(int index) {
    const auto& p=uad_uadpulteceqp1a::kFactoryPresets[static_cast<size_t>(index)];
    return {p.low_freq,p.lf_boost,p.lf_atten,p.high_freq,p.hf_boost,p.hf_q,p.hf_atten_freq,p.hf_atten,p.enable,p.output};
}
inline const char* presetName(int i) {return uad_uadpulteceqp1a::kFactoryPresets[static_cast<size_t>(i)].name;}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v) {
    core.setParameters(v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9]);
}
inline const std::vector<ControlLayout> controlLayouts {
    {"low_freq",{274,139,120,124},{"pultec_freq_switch_4_step_png",240,248,4,3}},
    {"lf_boost",{222,11,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"lf_atten",{343,11,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"high_freq",{559,139,120,124},{"pultec_freq_switch_7_step_png",240,248,7,3}},
    {"hf_boost",{508,11,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"hf_q",{426,140,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"hf_atten_freq",{767,13,78,120},{"pultec_atten_select_png",156,240,3,3}},
    {"hf_atten",{629,11,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"enable",{190,149,55,100},{"pultec_in_switch_V1_png",110,200,2,2}},
    {"output",{781,161,65,68},{"pultec_power_switch_270_png",130,136,51,8}},
};
} // namespace studio
#elif TSTUDIO_PRODUCT == 1
#include "../plugins/MEQ5/core/UADPultecMEQ5.h"
namespace studio {
using Core = uad_uadpultecmeq5::UADPultecMEQ5;
inline constexpr const char* productName="T-MEQ5";
inline constexpr int panelWidth=950, panelHeight=188;
inline constexpr const char* panelResource="pultec_meq_5_back_png";
inline constexpr int dspParameterCount=8, parameterCount=dspParameterCount+1;
inline constexpr int defaultPreset=47;
inline constexpr int presetCount=static_cast<int>(std::size(uad_uadpultecmeq5::kFactoryPresets));
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
    {"lm_freq","Low Mid Frequency",Kind::Choice,0.000000000f,"200 Hz|300 Hz|500 Hz|700 Hz|1 kHz"},
    {"lm_peak","Low Mid Peak",Kind::Knob,0.000000000f,""},
    {"mid_freq","Mid Frequency",Kind::Choice,0.300000000f,"200 Hz|300 Hz|500 Hz|700 Hz|1 kHz|1.5 kHz|2 kHz|3 kHz|4 kHz|5 kHz|7 kHz"},
    {"mid_dip","Mid Dip",Kind::Knob,0.000000000f,""},
    {"hm_freq","High Mid Frequency",Kind::Choice,0.000000000f,"1.5 kHz|2 kHz|3 kHz|4 kHz|5 kHz"},
    {"hm_peak","High Mid Peak",Kind::Knob,0.000000000f,""},
    {"enable","EQ In",Kind::Switch,1.000000000f,""},
    {"output","Output / Power",Kind::EqOutput,0.500000000f,""},
    {"bypass","Bypass",Kind::Switch,0.f,""}
}};
inline std::array<float,dspParameterCount> presetValues(int index) {
    const auto& p=uad_uadpultecmeq5::kFactoryPresets[static_cast<size_t>(index)];
    return {p.lm_freq,p.lm_peak,p.mid_freq,p.mid_dip,p.hm_freq,p.hm_peak,p.enable,p.output};
}
inline const char* presetName(int i) {return uad_uadpultecmeq5::kFactoryPresets[static_cast<size_t>(i)].name;}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v) {
    core.setParameters(v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7]);
}
inline const std::vector<ControlLayout> controlLayouts {
    {"lm_freq",{130,32,120,124},{"pultec_freq_switch_5_step_png",240,248,5,3}},
    {"lm_peak",{250,35,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"mid_freq",{357,32,120,124},{"pultec_freq_switch_11_step_png",240,248,11,4}},
    {"mid_dip",{482,35,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"hm_freq",{587,32,120,124},{"pultec_freq_switch_5_step_png",240,248,5,3}},
    {"hm_peak",{716,35,105,123},{"pultec_continuous_knob_png",210,246,111,12}},
    {"enable",{75,43,55,100},{"pultec_in_switch_V2_png",110,200,2,2}},
    {"output",{812,87,65,68},{"pultec_power_switch_270_png",130,136,51,8}},
};
} // namespace studio
#elif TSTUDIO_PRODUCT == 2
#include "../plugins/Century/core/UADCenturyChannelStrip.h"
namespace studio {
using Core = uad_uadcenturychannelstrip::UADCenturyChannelStrip;
inline constexpr const char* productName="T-Century";
inline constexpr int panelWidth=746, panelHeight=508;
inline constexpr const char* panelResource="tube_cs_background_png";
inline constexpr int dspParameterCount=15, parameterCount=dspParameterCount+1;
inline constexpr int defaultPreset=60;
inline constexpr int presetCount=static_cast<int>(std::size(uad_uadcenturychannelstrip::kFactoryPresets));
inline const std::array<ParameterSpec,parameterCount> parameterSpecs {{
    {"input_select","Mic Input",Kind::Switch,0.000000000f,""},
    {"low_cut","Low Cut",Kind::Switch,0.000000000f,""},
    {"phase","Polarity",Kind::Switch,0.000000000f,""},
    {"pad","Pad",Kind::Switch,0.000000000f,""},
    {"gain","High Gain",Kind::Switch,0.000000000f,""},
    {"level","Preamp Level",Kind::Knob,0.580933000f,""},
    {"high_shelf","High Shelf",Kind::ToneDB,0.500000000f,""},
    {"mid_freq","Mid Frequency",Kind::MidHz,0.000000000f,""},
    {"mid_gain","Mid Gain",Kind::ToneDB,0.500000000f,""},
    {"low_shelf","Low Shelf",Kind::ToneDB,0.500000000f,""},
    {"eq_in","EQ In",Kind::Switch,0.000000000f,""},
    {"compression","Compression",Kind::Knob,0.463898000f,""},
    {"gr_in","Compressor In",Kind::Switch,0.000000000f,""},
    {"output","Output",Kind::StripOutput,0.500000000f,""},
    {"power","Power",Kind::Switch,1.000000000f,""},
    {"bypass","Bypass",Kind::Switch,0.f,""}
}};
inline std::array<float,dspParameterCount> presetValues(int index) {
    const auto& p=uad_uadcenturychannelstrip::kFactoryPresets[static_cast<size_t>(index)];
    return {p.input_select,p.low_cut,p.phase,p.pad,p.gain,p.level,p.high_shelf,p.mid_freq,p.mid_gain,p.low_shelf,p.eq_in,p.compression,p.gr_in,p.output,p.power};
}
inline const char* presetName(int i) {return uad_uadcenturychannelstrip::kFactoryPresets[static_cast<size_t>(i)].name;}
inline void setCore(Core& core,const std::array<float,dspParameterCount>& v) {
    core.setParameters(v[0],v[1],v[2],v[3],v[4],v[5],v[6],v[7],v[8],v[9],v[10],v[11],v[12],v[13],v[14]);
}
inline const std::vector<ControlLayout> controlLayouts {
    {"power",{600,438,118,30},{"tube_cs_switch_horizontal_png",208,60,2,1}},
    {"output",{586,283,129,144},{"tube_cs_knob_skirt_png",258,288,121,12}},
    {"gr_in",{412,438,118,30},{"tube_cs_switch_horizontal_png",208,60,2,1}},
    {"compression",{401,283,129,144},{"tube_cs_knob_skirt_png",258,288,121,12}},
    {"eq_in",{227,438,118,30},{"tube_cs_switch_horizontal_png",208,60,2,1}},
    {"low_shelf",{271,310,97,107},{"tube_cs_knob_png",194,214,131,13}},
    {"mid_gain",{271,189,97,107},{"tube_cs_knob_png",194,214,131,13}},
    {"mid_freq",{198,179,73,80},{"tube_cs_knob_sml_png",146,160,131,12}},
    {"high_shelf",{271,68,97,107},{"tube_cs_knob_png",194,214,131,13}},
    {"level",{29,283,129,144},{"tube_cs_knob_skirt_png",258,288,121,12}},
    {"gain",{56,67,82,106},{"tube_cs_knob_chickenhead_png",164,212,2,2}},
    {"phase",{96,186,30,77},{"tube_cs_switch_vertical_png",60,154,2,3}},
    {"low_cut",{61,186,30,77},{"tube_cs_switch_vertical_png",60,154,2,3}},
    {"input_select",{26,186,30,77},{"tube_cs_switch_vertical_png",60,154,2,3}},
    {"pad",{131,186,30,77},{"tube_cs_switch_vertical_png",60,154,2,3}},
};
} // namespace studio
#endif
