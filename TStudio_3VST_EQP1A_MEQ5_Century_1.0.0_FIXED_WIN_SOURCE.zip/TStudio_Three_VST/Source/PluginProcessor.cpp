#include "PluginProcessor.h"

namespace studio {
juce::String parameterText(const ParameterSpec& spec,float v) {
    v=juce::jlimit(0.f,1.f,v);
    if(spec.kind==Kind::Choice){auto labels=juce::StringArray::fromTokens(spec.choices,"|","");return labels[juce::jlimit(0,labels.size()-1,juce::roundToInt(v*float(labels.size()-1)))];}
    if(spec.kind==Kind::Switch)return v>=.5f?"On":"Off";
    if(spec.kind==Kind::EqOutput)return v<.01f?"Power Off":juce::String((v-.5f)*24,1)+" dB";
    if(spec.kind==Kind::StripOutput)return juce::String(v<=.5f?(v*2-1)*24:(v-.5f)*24,1)+" dB";
    if(spec.kind==Kind::ToneDB)return juce::String((v-.5f)*24,1)+" dB";
    if(spec.kind==Kind::MidHz){const auto hz=300.f*std::pow(24.f,v);return hz>=1000?juce::String(hz/1000,2)+" kHz":juce::String(hz,0)+" Hz";}
    return juce::String(v*10,2);
}
juce::AudioProcessorValueTreeState::ParameterLayout PluginProcessor::makeLayout(){
    juce::AudioProcessorValueTreeState::ParameterLayout layout;
    for(const auto& spec:parameterSpecs){
        if(spec.kind==Kind::Switch){layout.add(std::make_unique<juce::AudioParameterBool>(juce::ParameterID{spec.id,1},spec.label,spec.defaultValue>=.5f));continue;}
        float step=0;
        if(spec.kind==Kind::Choice){const auto labels=juce::StringArray::fromTokens(spec.choices,"|","");step=1.f/float(labels.size()-1);}
        layout.add(std::make_unique<juce::AudioParameterFloat>(juce::ParameterID{spec.id,1},spec.label,juce::NormalisableRange<float>(0,1,step),spec.defaultValue,
            juce::AudioParameterFloatAttributes().withStringFromValueFunction([spec](float v,int){return parameterText(spec,v);})));
    }
    return layout;
}
PluginProcessor::PluginProcessor():AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true).withOutput("Output",juce::AudioChannelSet::stereo(),true)),
 state(*this,nullptr,"TStudioThreeVST",makeLayout()){
    for(size_t i=0;i<values.size();++i)values[i]=state.getRawParameterValue(parameterSpecs[i].id);
}
bool PluginProcessor::isBusesLayoutSupported(const BusesLayout& b) const {
    return b.getMainInputChannelSet()==b.getMainOutputChannelSet()&&(b.getMainOutputChannelSet()==juce::AudioChannelSet::mono()||b.getMainOutputChannelSet()==juce::AudioChannelSet::stereo());
}
float PluginProcessor::parameter(int i) const noexcept {
    const auto v=values[size_t(i)]->load(std::memory_order_relaxed);
    return std::isfinite(v)?juce::jlimit(0.f,1.f,v):parameterSpecs[size_t(i)].defaultValue;
}
float PluginProcessor::parameter(const juce::String& id) const noexcept {
    for(int i=0;i<parameterCount;++i)if(id==parameterSpecs[size_t(i)].id)return parameter(i);
    return 0;
}
bool PluginProcessor::powered() const noexcept {
    #if TSTUDIO_PRODUCT == 2
    return parameter(dspParameterCount-1)>=.5f;
    #else
    return parameter(dspParameterCount-1)>=.01f;
    #endif
}
float PluginProcessor::gainForOutput(float v) noexcept {
    #if TSTUDIO_PRODUCT == 2
    const float db=v<=.5f?(v*2-1)*24:(v-.5f)*24;
    #else
    const float db=v<.01f?0.f:(v-.5f)*24;
    #endif
    return std::pow(10.f,db*.05f);
}
void PluginProcessor::prepareToPlay(double sr,int block){
    const auto rate=std::isfinite(sr)&&sr>=8000&&sr<=768000?sr:48000.;
    dry.setSize(2,std::max(512,block),false,true,true);
    engine.prepare(rate);
    outputMeterCoefficient=std::exp(-1.0/(.300*rate));
    for(auto& s:controls)s.reset(rate,.02);
    bypassRamp.reset(rate,.02);outputRamp.reset(rate,.02);setLatencySamples(0);reset();
}
void PluginProcessor::setEngineParameters(){
    std::array<float,dspParameterCount> p{};
    for(size_t i=0;i<p.size();++i)p[i]=controls[i].getCurrentValue();
    // Keep the engine warm while native/host bypass ramps. Output gain ramps
    // sample-by-sample after the submitted core, whose output is linear.
    #if TSTUDIO_PRODUCT == 2
    p[13]=.5f;p[14]=1.f;
    #else
    p[size_t(dspParameterCount-1)]=.5f;
    #endif
    setCore(engine,p);
}
void PluginProcessor::reset(){
    for(int i=0;i<dspParameterCount;++i)controls[size_t(i)].setCurrentAndTargetValue(parameter(i));
    setEngineParameters();engine.reset();controlRemaining=0;
    bypassRamp.setCurrentAndTargetValue(hostBypass||parameter(parameterCount-1)>=.5f||!powered()?1.f:0.f);
    outputRamp.setCurrentAndTargetValue(gainForOutput(parameter(TSTUDIO_PRODUCT==2?13:dspParameterCount-1)));
    inputDb.store(-100);outputDb.store(-100);gainReductionDb.store(0);vuDb.store(-100);
    outputMeterEnvelope=0;
}
void PluginProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&){
    juce::ScopedNoDenormals noDenormals;
    const int channels=std::min(2,buffer.getNumChannels()),frames=buffer.getNumSamples();
    if(channels<1||frames<=0)return;
    if(dry.getNumSamples()==0){buffer.clear();return;}
    for(int c=getTotalNumInputChannels();c<buffer.getNumChannels();++c)buffer.clear(c,0,frames);
    for(int i=0;i<dspParameterCount;++i){const auto v=parameter(i);auto& s=controls[size_t(i)];
        if(parameterSpecs[size_t(i)].kind==Kind::Switch||parameterSpecs[size_t(i)].kind==Kind::Choice)s.setCurrentAndTargetValue(v);else s.setTargetValue(v);}
    bypassRamp.setTargetValue(hostBypass||parameter(parameterCount-1)>=.5f||!powered()?1.f:0.f);
    outputRamp.setTargetValue(gainForOutput(parameter(TSTUDIO_PRODUCT==2?13:dspParameterCount-1)));
    float inPeak=0,outPeak=0;
    for(int start=0;start<frames;){
        if(controlRemaining==0){setEngineParameters();controlRemaining=32;}
        const int n=std::min({frames-start,controlRemaining,dry.getNumSamples()});
        for(int c=0;c<channels;++c){auto* src=buffer.getWritePointer(c,start);auto* dst=dry.getWritePointer(c);
            for(int i=0;i<n;++i){const float x=std::isfinite(src[i])?juce::jlimit(-64.f,64.f,src[i]):0.f;src[i]=dst[i]=x;inPeak=std::max(inPeak,std::abs(x));}}
        auto* left=buffer.getWritePointer(0,start);auto* right=channels>1?buffer.getWritePointer(1,start):nullptr;
        engine.processBlock(left,right,n);
        for(int i=0;i<n;++i){const float g=outputRamp.getNextValue(),b=bypassRamp.getNextValue();
            for(int c=0;c<channels;++c){auto* out=buffer.getWritePointer(c,start);const float wet=out[i]*g;out[i]=wet+(dry.getSample(c,i)-wet)*b;outPeak=std::max(outPeak,std::abs(out[i]));}
            #if TSTUDIO_PRODUCT == 2
            // Match the submitted 300 ms meter ballistics after the smoothed
            // master gain, so Output automation is reflected in the VU needle.
            const double peak=.5*(std::abs(left[i])+std::abs(right?right[i]:left[i]));
            outputMeterEnvelope=outputMeterCoefficient*outputMeterEnvelope+(1-outputMeterCoefficient)*peak*peak;
            #endif
        }
        for(auto& s:controls)s.skip(n);
        start+=n;controlRemaining-=n;
    }
    inputDb.store(juce::Decibels::gainToDecibels(inPeak,-100.f),std::memory_order_relaxed);
    outputDb.store(juce::Decibels::gainToDecibels(outPeak,-100.f),std::memory_order_relaxed);
    #if TSTUDIO_PRODUCT == 2
    gainReductionDb.store(powered()?float(engine.getGainReductiondB()):0.f,std::memory_order_relaxed);
    vuDb.store(powered()?float(10*std::log10(std::max(1.e-12,outputMeterEnvelope))): -100.f,std::memory_order_relaxed);
    #endif
}
void PluginProcessor::processBlockBypassed(juce::AudioBuffer<float>& b,juce::MidiBuffer& m){hostBypass=true;processBlock(b,m);hostBypass=false;}
void PluginProcessor::setCurrentProgram(int index){
    if(index<0||index>=presetCount)return;
    const auto p=presetValues(index);
    for(int i=0;i<dspParameterCount;++i)if(auto* param=state.getParameter(parameterSpecs[size_t(i)].id))param->setValueNotifyingHost(p[size_t(i)]);
    currentProgram.store(index);
}
const juce::String PluginProcessor::getProgramName(int i){return i>=0&&i<presetCount?juce::String::fromUTF8(presetName(i)):juce::String{};}
void PluginProcessor::getStateInformation(juce::MemoryBlock& dest){auto tree=state.copyState();tree.setProperty("product",productName,nullptr);tree.setProperty("factoryPreset",currentProgram.load(),nullptr);auto xml=tree.createXml();copyXmlToBinary(*xml,dest);}
void PluginProcessor::setStateInformation(const void* data,int size){
    if(auto xml=getXmlFromBinary(data,size)){if(!xml->hasTagName(state.state.getType().toString()))return;
        auto tree=juce::ValueTree::fromXml(*xml);if(tree.getProperty("product").toString()!=productName)return;
        const auto index=int(tree.getProperty("factoryPreset",defaultPreset));state.replaceState(tree);currentProgram.store(juce::jlimit(0,presetCount-1,index));}
}
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter(){return new studio::PluginProcessor;}
