# T Studio — EQP1A / MEQ5 / Century 1.0.0

Gói mã nguồn đã sửa, kèm JUCE 8.0.12 và file build Windows x64. Ba plugin xuất ra là **T-EQP1A**, **T-MEQ5**, **T-Century**; đây là ba VST3 riêng, không phải một plugin chứa ba effect.

## Build trên Windows

1. Giải nén **toàn bộ ZIP** vào một thư mục mới, đường dẫn ngắn, ví dụ `C:\TStudio\ThreeVST`. Không chạy file BAT ngay trong cửa sổ xem ZIP.
2. Cài **Visual Studio 2022 hoặc Build Tools 2022**, chọn **Desktop development with C++**, MSVC x64/x86 và Windows SDK. Script cũng nhận Visual Studio 2019/2026 nếu CMake hỗ trợ generator tương ứng.
3. Cài **CMake từ 3.22 trở lên**, thêm vào PATH; hoặc cài công cụ CMake của Visual Studio. Không cần Git, Python hay tải JUCE thêm.
4. Bấm đúp **`1_BUILD_AND_EXPORT_WINDOWS.bat`**. Lần đầu sẽ biên dịch JUCE nên có thể mất vài phút. Script dùng hai luồng build để giảm nhu cầu RAM.
5. Khi thành công, cửa sổ Explorer mở thư mục `_EXPORT\Build-...\VST3` chứa đủ ba thư mục `.vst3`. Đường dẫn lần xuất mới nhất cũng được ghi vào `_EXPORT\LATEST_EXPORT.txt`.
6. Đóng Cubase, chép **nguyên ba thư mục `.vst3`** vào `C:\Program Files\Common Files\VST3`, rồi mở Cubase và quét lại plugin. Windows có thể hỏi quyền quản trị khi chép vào Program Files.

File `.vst3` ở dạng thư mục là định dạng bundle hợp lệ. Không chỉ chép riêng binary nằm bên trong `Contents`. Script chỉ build và xuất trong thư mục dự án; việc chép vào thư mục VST3 do anh thực hiện.

Nếu build lỗi, cửa sổ dừng để đọc thông báo; xem `_BUILD_LOGS\...\configure.log` và `build.log`. Bản export đã thành công trước đó được giữ lại. Có thể gửi hai file log này để kiểm tra.

## Những phần đã sửa

- EQP1A và MEQ5: cập nhật hệ số bộ lọc giữ lại bộ nhớ tín hiệu. Bản gửi ban đầu xóa bộ nhớ khi dựng lại filter, kể cả khi gửi lại cùng giá trị tham số.
- Century: sửa trường hợp tín hiệu mono đảo cực bị áp dụng cực tính khác stereo; sửa chiều kim giảm gain theo đúng thứ tự frame ảnh. VU trong plugin mới đo sau Output.
- Cả ba core: bỏ phụ thuộc `M_PI`, kiểm tra sample rate, bỏ NaN/Inf khỏi đầu vào, và giữ giá trị tham số hợp lệ nếu nhận NaN/Inf. Không giới hạn audio ở ±1.
- Bổ sung CMake, bộ khung VST3 và giao diện JUCE kết nối trực tiếp các núm/công tắc với DSP, automation và lưu/khôi phục trạng thái.
- Làm mượt các tham số liên tục, Output và bypass trong 20 ms. Việc cập nhật hệ số không reset filter. Power/host bypass chuyển về dry; engine tiếp tục chạy để giữ trạng thái.
- Đóng gói lại sprite thành atlas nhỏ hơn, giữ nguyên từng pixel của mọi frame để tránh ảnh quá cao đối với bộ dựng giao diện Windows.
- Giữ 62 preset EQP1A, 48 preset MEQ5, 61 preset Century: **171 preset** tổng cộng.

Output và Power của hai Pultec vốn dùng chung một tham số trong giao diện được gửi: kéo về đầu hành trình sẽ tắt nguồn; mức giữa là 0 dB. Quy ước này được giữ lại. Có thể bấm đèn đỏ để tắt/bật lại mức Output trước đó.

## Phạm vi bản giao

DSP là các triển khai C++ trong ba ZIP anh gửi, đã vá các lỗi nêu trên. Giao diện dùng ảnh được gửi và bộ điều khiển JUCE mới; không chạy JavaScript phụ thuộc backend UA. Tên và ID plugin mới giúp chúng tồn tại cùng plugin hãng hoặc T-PultecEQ cũ. Không tự chuyển preset/session của các plugin đó.

Không nhúng DLL của hãng, thông tin kích hoạt hay hệ thống cấp phép mới. Giữ ghi công và giấy phép JUCE trong `third_party/JUCE`; nguồn ảnh/preset được ghi trong `Validation` và `THIRD_PARTY_NOTICES.md`.

**Đây là ZIP mã nguồn, chưa có VST3 Windows biên dịch sẵn.** Kiểm thử tại môi trường Linux không thay thế cho chạy trên Windows/Cubase 15. Chưa có bằng chứng khẳng định DSP hoặc âm thanh giống UAD 100%; cần so bằng tín hiệu tham chiếu và mức âm lượng khớp nhau.

Plugin báo 0 sample độ trễ xử lý; độ trễ nghe khi hát vẫn còn phụ thuộc buffer ASIO, soundcard và chuỗi plugin.

## Cấu trúc

- `Source/`: processor, editor và ánh xạ tham số/preset.
- `plugins/*/core/`: các core DSP đã sửa và preset C++.
- `plugins/*/presets_json/`: dữ liệu preset được gửi ban đầu.
- `Resources/`: ảnh giao diện đóng gói dạng atlas.
- `tools/Build-Windows.ps1`: phát hiện công cụ, build Release x64, kiểm tra đủ ba binary PE32+ x64 và xuất toàn bộ bundle kèm SHA-256.
- `tests/`, `Validation/`: bài thử, báo cáo và bằng chứng sửa lỗi.

Các target CMake là `TEQP1A_VST3`, `TMEQ5_VST3`, `TCentury_VST3`. Có thể mở `CMakeLists.txt` trong Visual Studio để build thủ công. Nếu dùng PowerShell trực tiếp, ví dụ:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\tools\Build-Windows.ps1 -Generator "Visual Studio 17 2022" -Parallel 2
```

