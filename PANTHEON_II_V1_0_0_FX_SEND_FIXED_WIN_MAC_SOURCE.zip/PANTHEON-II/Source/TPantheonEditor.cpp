#include "TPantheonEditor.h"
#include "BinaryData.h"

TPantheonLookAndFeel::TPantheonLookAndFeel()
{
    faderCapImage = juce::ImageCache::getFromMemory(BinaryData::pantheon_fader_png, BinaryData::pantheon_fader_pngSize);

    setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff1c242c));
    setColour(juce::PopupMenu::textColourId, juce::Colour(0xffe8f0f8));
    setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff3a5068));
}

void TPantheonLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                            float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                                            juce::Slider& slider)
{
    // Both the large REVERB TYPE knob and the 10 small rotary knobs are already rendered in pantheon_bg_png.
    // We draw the recessed metallic Lexicon dimple/dot indicator at the exact rotation angle!
    const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
    const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
    const float angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);

    const bool isLarge = (slider.getProperties()["knobSize"].toString() == "large");
    const float indicatorRadius = isLarge ? 23.0f : 7.0f;
    const float dotR = isLarge ? 4.2f : 2.1f;

    const float dx = centreX + std::sin(angle) * indicatorRadius;
    const float dy = centreY - std::cos(angle) * indicatorRadius;

    // Recessed dimple shadow & highlight matching Screenshot 2026-10-27 193841.jpg
    g.setColour(juce::Colour(0x99303840));
    g.fillEllipse(dx - dotR, dy - dotR, dotR * 2.0f, dotR * 2.0f);
    g.setColour(juce::Colour(0x88ffffff));
    g.drawEllipse(dx - dotR, dy - dotR, dotR * 2.0f, dotR * 2.0f, 0.8f);
}

void TPantheonLookAndFeel::drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
                                            float sliderPos, float minSliderPos, float maxSliderPos,
                                            const juce::Slider::SliderStyle, juce::Slider& slider)
{
    juce::ignoreUnused(sliderPos, minSliderPos, maxSliderPos);
    const double val = slider.getValue();
    const double minV = slider.getMinimum();
    const double maxV = slider.getMaximum();
    const float norm = static_cast<float>(slider.valueToProportionOfLength(juce::jlimit(minV, maxV, val)));

    // Draw authentic Lexicon Pantheon II fader cap (pantheon_fader_png: 25x44)
    if (faderCapImage.isValid())
    {
        const int capW = faderCapImage.getWidth();   // 25
        const int capH = faderCapImage.getHeight();  // 44
        const int travel = juce::jmax(1, height - capH);
        const int capX = x + (width - capW) / 2;
        const int capY = y + juce::roundToInt((1.0f - norm) * static_cast<float>(travel));
        g.drawImageAt(faderCapImage, capX, capY);
    }
}

TPantheonAudioProcessorEditor::TPantheonAudioProcessorEditor(TPantheonAudioProcessor& p)
    : AudioProcessorEditor(&p),
      audioProcessor(p),
      licenseOverlay(
          [this]() { return audioProcessor.getLicenseManager().snapshot(); },
          [this](const juce::String& k) { audioProcessor.getLicenseManager().requestActivation(k); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { audioProcessor.getLicenseManager().requestTrial(); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { licenseOverlay.setVisible(false); updateLicenseBadge(); repaint(); }
      )
{
    setLookAndFeel(&customLookAndFeel);
    pantheonBgImage = juce::ImageCache::getFromMemory(BinaryData::pantheon_bg_png, BinaryData::pantheon_bg_pngSize);

    // Preset selector (triggered by clicking the top dark glass LCD display)
    const auto& presets = TPantheonAudioProcessor::getFactoryPresets();
    for (int i = 0; i < static_cast<int>(presets.size()); ++i)
        presetBox.addItem(juce::String::fromUTF8(presets[static_cast<size_t>(i)].name), i + 1);
    presetBox.setSelectedId(audioProcessor.getCurrentProgram() + 1, juce::dontSendNotification);
    presetBox.onChange = [this]
    {
        int idx = presetBox.getSelectedId() - 1;
        if (idx >= 0)
        {
            audioProcessor.setCurrentProgram(idx);
            repaint();
        }
    };

    // Reverb Type selector
    reverbTypeBox.addItemList({ "Hall", "Chamber", "Room", "Plate", "Ambience", "Custom" }, 1);
    reverbTypeBox.setTooltip("Preset category only: all categories currently use the chamber network.");
    reverbTypeBox.onChange = [this] { repaint(); };
    reverbTypeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "reverbType", reverbTypeBox);

    // Large REVERB TYPE Rotary Knob (x=42, y=160, w=78, h=78)
    reverbTypeKnob.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    reverbTypeKnob.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    reverbTypeKnob.getProperties().set("knobSize", "large");
    reverbTypeKnob.setRotaryParameters(juce::MathConstants<float>::pi * 1.25f,
                                       juce::MathConstants<float>::pi * 2.75f, true);
    reverbTypeKnob.setTooltip("Preset category only: this does not select another DSP engine.");
    addAndMakeVisible(reverbTypeKnob);
    reverbTypeKnobAtt = std::make_unique<SliderAttachment>(audioProcessor.getAPVTS(), "reverbType", reverbTypeKnob);

    // 6 Middle Vertical Faders
    for (auto* f : { &preDelaySlider, &roomSizeSlider, &rt60Slider, &dampingSlider, &mixSlider, &levelSlider })
        setupVerticalFader(*f);

    // 10 Bottom Small Silver Rotary Knobs
    for (auto* k : { &regenSlider, &delaySlider,
                     &echoTimeLSlider, &echoLevelLSlider, &echoTimeRSlider, &echoLevelRSlider,
                     &spreadSlider, &diffusionSlider, &bassBoostSlider, &bassFreqSlider })
    {
        setupSmallRotaryKnob(*k);
    }

    auto& apvts = audioProcessor.getAPVTS();
    preDelayAtt   = std::make_unique<SliderAttachment>(apvts, "preDelay",   preDelaySlider);
    roomSizeAtt   = std::make_unique<SliderAttachment>(apvts, "roomSize",   roomSizeSlider);
    rt60Att       = std::make_unique<SliderAttachment>(apvts, "rt60",       rt60Slider);
    dampingAtt    = std::make_unique<SliderAttachment>(apvts, "damping",    dampingSlider);
    mixAtt        = std::make_unique<SliderAttachment>(apvts, "mix",        mixSlider);
    levelAtt      = std::make_unique<SliderAttachment>(apvts, "level",      levelSlider);

    regenAtt      = std::make_unique<SliderAttachment>(apvts, "regen",      regenSlider);
    delayAtt      = std::make_unique<SliderAttachment>(apvts, "delay",      delaySlider);
    echoTimeLAtt  = std::make_unique<SliderAttachment>(apvts, "echoTimeL",  echoTimeLSlider);
    echoLevelLAtt = std::make_unique<SliderAttachment>(apvts, "echoLevelL", echoLevelLSlider);
    echoTimeRAtt  = std::make_unique<SliderAttachment>(apvts, "echoTimeR",  echoTimeRSlider);
    echoLevelRAtt = std::make_unique<SliderAttachment>(apvts, "echoLevelR", echoLevelRSlider);
    spreadAtt     = std::make_unique<SliderAttachment>(apvts, "spread",     spreadSlider);
    diffusionAtt  = std::make_unique<SliderAttachment>(apvts, "diffusion",  diffusionSlider);
    bassBoostAtt  = std::make_unique<SliderAttachment>(apvts, "bassBoost",  bassBoostSlider);
    bassFreqAtt   = std::make_unique<SliderAttachment>(apvts, "bassFreq",   bassFreqSlider);

    addChildComponent(licenseOverlay);
    if (!audioProcessor.isPluginUnlocked())
        licenseOverlay.setVisible(true);

    updateLicenseBadge();
    setSize(512, 374);
    startTimerHz(30);
}

TPantheonAudioProcessorEditor::~TPantheonAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
}

void TPantheonAudioProcessorEditor::setupVerticalFader(juce::Slider& s)
{
    s.setSliderStyle(juce::Slider::LinearVertical);
    s.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    s.onValueChange = [this] { repaint(); };
    addAndMakeVisible(s);
}

void TPantheonAudioProcessorEditor::setupSmallRotaryKnob(juce::Slider& s)
{
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::NoTextBox, true, 0, 0);
    s.getProperties().set("knobSize", "small");
    s.setRotaryParameters(juce::MathConstants<float>::pi * 1.2f,
                          juce::MathConstants<float>::pi * 2.8f, true);
    s.onValueChange = [this] { repaint(); };
    addAndMakeVisible(s);
}

void TPantheonAudioProcessorEditor::mouseDown(const juce::MouseEvent& e)
{
    const auto pt = e.getPosition();

    // 1. Clicking inside the top LCD display (x=32..250, y=22..87) opens the Factory Preset menu
    if (pt.x >= 32 && pt.x <= 250 && pt.y >= 22 && pt.y <= 87)
    {
        juce::PopupMenu m;
        const auto& presets = TPantheonAudioProcessor::getFactoryPresets();
        for (int i = 0; i < static_cast<int>(presets.size()); ++i)
            m.addItem(i + 1, juce::String::fromUTF8(presets[static_cast<size_t>(i)].name), true, i == audioProcessor.getCurrentProgram());
        m.showMenuAsync(juce::PopupMenu::Options().withTargetScreenArea(localAreaToGlobal(juce::Rectangle<int>(32, 22, 218, 65))),
                        [this](int res)
                        {
                            if (res > 0)
                            {
                                audioProcessor.setCurrentProgram(res - 1);
                                repaint();
                            }
                        });
        return;
    }

    // 2. Clicking the Reverb Type readout box (x=54..109, y=122..136) opens the Reverb Type menu
    if (pt.x >= 54 && pt.x <= 109 && pt.y >= 120 && pt.y <= 138)
    {
        juce::PopupMenu m;
        const juce::StringArray types { "Hall", "Chamber", "Room", "Plate", "Ambience", "Custom" };
        const int cur = static_cast<int>(audioProcessor.getAPVTS().getRawParameterValue("reverbType")->load());
        for (int i = 0; i < types.size(); ++i)
            m.addItem(i + 1, types[i], true, i == cur);
        m.showMenuAsync(juce::PopupMenu::Options().withTargetScreenArea(localAreaToGlobal(juce::Rectangle<int>(54, 122, 56, 15))),
                        [this](int res)
                        {
                            if (res > 0)
                            {
                                if (auto* param = audioProcessor.getAPVTS().getParameter("reverbType"))
                                    param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(res - 1)));
                                repaint();
                            }
                        });
        return;
    }

    // 3. Clicking the PANTHEON II by lexicon logo area (x=290..490, y=20..85) toggles the license panel
    if (pt.x >= 290 && pt.x <= 490 && pt.y >= 20 && pt.y <= 85)
    {
        audioProcessor.refreshLicenseState();
        licenseOverlay.setVisible(!licenseOverlay.isVisible());
        if (licenseOverlay.isVisible())
            licenseOverlay.toFront(true);
        resized();
    }
}

void TPantheonAudioProcessorEditor::updateLicenseBadge()
{
}

void TPantheonAudioProcessorEditor::timerCallback()
{
}

void TPantheonAudioProcessorEditor::paint(juce::Graphics& g)
{
    // 1. Draw 100% original Lexicon Pantheon II 512x374 faceplate skin
    if (pantheonBgImage.isValid())
        g.drawImageAt(pantheonBgImage, 0, 0);
    else
        g.fillAll(juce::Colour(0xff2c3844));

    auto& apvts = audioProcessor.getAPVTS();
    const int   revType   = juce::jlimit(0, 5, static_cast<int>(apvts.getRawParameterValue("reverbType")->load()));
    const float roomSize  = apvts.getRawParameterValue("roomSize")->load();
    const float rt60      = apvts.getRawParameterValue("rt60")->load();
    const float preDelay  = apvts.getRawParameterValue("preDelay")->load();
    const float damping   = apvts.getRawParameterValue("damping")->load();
    const float mix       = apvts.getRawParameterValue("mix")->load();
    const float level     = apvts.getRawParameterValue("level")->load();
    const float regen     = apvts.getRawParameterValue("regen")->load();
    const float delay     = apvts.getRawParameterValue("delay")->load();
    const float echoTimeL = apvts.getRawParameterValue("echoTimeL")->load();
    const float echoLvlL  = apvts.getRawParameterValue("echoLevelL")->load();
    const float echoTimeR = apvts.getRawParameterValue("echoTimeR")->load();
    const float echoLvlR  = apvts.getRawParameterValue("echoLevelR")->load();
    const float spread    = apvts.getRawParameterValue("spread")->load();
    const float diffusion = apvts.getRawParameterValue("diffusion")->load();
    const float bassBoost = apvts.getRawParameterValue("bassBoost")->load();
    const float bassFreq  = apvts.getRawParameterValue("bassFreq")->load();

    static const char* kTypeNames[6] = { "Hall", "Chamber", "Room", "Plate", "Ambience", "Custom" };
    const juce::String typeStr(kTypeNames[revType]);

    // 2. Top Dark Glass LCD Display (x=32..250, y=22..87) matching Screenshot 2026-10-27 193841.jpg verbatim:
    //    Reverb Type: Hall
    //    Room Size: 38 meters
    //    Reverb Time: 2.03 seconds
    //    Predelay:  12 milliseconds
    g.setColour(juce::Colour(0xffe6f0fa));
    g.setFont(juce::Font(juce::FontOptions(12.5f, juce::Font::plain)));
    g.drawText("Reverb Type: " + typeStr,                                         42, 25, 200, 15, juce::Justification::centredLeft, false);
    g.drawText(juce::String::formatted("Room Size: %.0f meters", roomSize),       42, 40, 200, 15, juce::Justification::centredLeft, false);
    g.drawText(juce::String::formatted("Reverb Time: %.2f seconds", rt60),        42, 55, 200, 15, juce::Justification::centredLeft, false);
    g.drawText(juce::String::formatted("Predelay:  %.0f milliseconds", preDelay), 42, 70, 200, 15, juce::Justification::centredLeft, false);

    // Helper for all 17 dark value readout boxes on the faceplate
    g.setColour(juce::Colour(0xffe8f0f8));
    g.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::plain)));
    auto drawValBox = [&](int bx, int by, int bw, int bh, const juce::String& text)
    {
        g.drawText(text, bx, by, bw, bh, juce::Justification::centred, false);
    };

    // 3. Middle Row Value Boxes (y=122, h=15)
    drawValBox(54,  122, 56, 15, typeStr);
    drawValBox(166, 122, 41, 15, juce::String::formatted("%.0fms", preDelay));
    drawValBox(221, 122, 41, 15, juce::String::formatted("%.0fm",  roomSize));
    drawValBox(275, 122, 41, 15, juce::String::formatted("%.2fs",  rt60));

    const juce::String dampStr = (damping >= 1000.0f)
        ? juce::String::formatted("%.2fkHz", damping * 0.001f)
        : juce::String::formatted("%.0fHz", damping);
    drawValBox(329, 122, 41, 15, dampStr);
    drawValBox(383, 122, 41, 15, juce::String::formatted("%.0f%%", mix));

    const juce::String lvlStr = (std::fabs(level) < 0.05f)
        ? juce::String("-0dB")
        : juce::String::formatted("%.0fdB", level);
    drawValBox(437, 122, 41, 15, lvlStr);

    // 4. Bottom Row Value Boxes (DENSITY, ECHO LEFT/RIGHT, SPREAD, DIFFUSION, BASS BOOST, BASS FREQ)
    drawValBox(9,   308, 41, 14, juce::String::formatted("%.0f%%", regen));
    drawValBox(58,  308, 41, 14, juce::String::formatted("%.0fms", delay));

    drawValBox(116, 308, 41, 14, juce::String::formatted("%.0fms", echoTimeL));
    drawValBox(116, 340, 41, 14, (echoLvlL <= -59.5f) ? juce::String("Off") : juce::String::formatted("%.0fdB", echoLvlL));

    drawValBox(259, 308, 41, 14, juce::String::formatted("%.0fms", echoTimeR));
    drawValBox(259, 340, 41, 14, (echoLvlR <= -59.5f) ? juce::String("Off") : juce::String::formatted("%.0fdB", echoLvlR));

    drawValBox(316, 308, 41, 14, juce::String::formatted("%.0f%%", spread));
    drawValBox(364, 308, 41, 14, juce::String::formatted("%.0f%%", diffusion));
    drawValBox(412, 308, 41, 14, juce::String::formatted("%.1fX",  bassBoost));
    drawValBox(460, 308, 41, 14, juce::String::formatted("%.0fHz", bassFreq));
}

void TPantheonAudioProcessorEditor::resized()
{
    // Large REVERB TYPE rotary knob (center = 81, 199)
    reverbTypeKnob.setBounds(42, 160, 78, 78);

    // 6 Middle Vertical Faders (slot y = 142..262, cap width = 25)
    preDelaySlider.setBounds(173, 142, 25, 120);
    roomSizeSlider.setBounds(228, 142, 25, 120);
    rt60Slider.setBounds(282,     142, 25, 120);
    dampingSlider.setBounds(336,  142, 25, 120);
    mixSlider.setBounds(390,      142, 25, 120);
    levelSlider.setBounds(444,    142, 25, 120);

    // 10 Bottom Small Silver Rotary Knobs (30x30 centered over each physical knob on pantheon_bg_png)
    regenSlider.setBounds(14,      327, 30, 30);
    delaySlider.setBounds(63,      327, 30, 30);

    echoTimeLSlider.setBounds(162,  300, 30, 30);
    echoLevelLSlider.setBounds(162, 334, 30, 30);
    echoTimeRSlider.setBounds(224,  300, 30, 30);
    echoLevelRSlider.setBounds(224, 334, 30, 30);

    spreadSlider.setBounds(321,     327, 30, 30);
    diffusionSlider.setBounds(369,  327, 30, 30);
    bassBoostSlider.setBounds(417,  327, 30, 30);
    bassFreqSlider.setBounds(465,   327, 30, 30);

    licenseOverlay.setBounds(getLocalBounds());
}
