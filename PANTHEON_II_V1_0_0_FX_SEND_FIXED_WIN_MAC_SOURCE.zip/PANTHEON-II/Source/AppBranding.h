#pragma once
// Generated from ThuongHieu.json.
namespace AppBranding {
inline constexpr const char* kAppDisplayName = "PantheonII";
inline constexpr const char* kBrandWord1 = "PANTHEON";
inline constexpr const char* kBrandWord2 = "II";
inline constexpr const char* kBrandSubtitle = "LEXICON REVERB";
inline constexpr const char* kSplashLine2 = "LEXICON / NT STUDIO";
inline constexpr const char* kPublisher = "Lexicon";
inline constexpr const char* kAppVersion = "1.0.0";
inline constexpr const char* kExeName = "PantheonII.exe";
inline constexpr const char* kSetupName = "Setup_PantheonII";
inline constexpr const char* kLicenseBrand = "PANTHEONII";
inline constexpr const char* kContactPhone = "0329575243";
inline constexpr const char* kContactNote = "Gọi / Zalo để mua bản quyền, gia hạn hoặc hỗ trợ kỹ thuật.";
inline constexpr const char* kAppDataDirName = "PantheonII";
inline constexpr int kTrialDays = 7;
}
