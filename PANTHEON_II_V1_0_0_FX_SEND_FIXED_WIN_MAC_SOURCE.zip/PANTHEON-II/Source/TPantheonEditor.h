#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "TPantheonProcessor.h"
#include "licensing/LicensePanel.h"

class TPantheonLookAndFeel : public juce::LookAndFeel_V4
{
public:
    TPantheonLookAndFeel();

    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider& slider) override;

    void drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float minSliderPos, float maxSliderPos,
                          const juce::Slider::SliderStyle style, juce::Slider& slider) override;

    juce::Image faderCapImage;
};

class TPantheonAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      private juce::Timer
{
public:
    explicit TPantheonAudioProcessorEditor(TPantheonAudioProcessor&);
    ~TPantheonAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void mouseDown(const juce::MouseEvent& event) override;

private:
    void timerCallback() override;
    void updateLicenseBadge();
    void setupVerticalFader(juce::Slider& s);
    void setupSmallRotaryKnob(juce::Slider& s);

    TPantheonAudioProcessor& audioProcessor;
    TPantheonLookAndFeel customLookAndFeel;
    juce::Image pantheonBgImage;

    // Hidden/Popup Preset & Reverb Type selectors
    juce::ComboBox presetBox;
    juce::ComboBox reverbTypeBox;

    // Large Reverb Type Rotary Knob (x=42, y=160, w=78, h=78)
    juce::Slider reverbTypeKnob;

    // 6 Middle Vertical Faders (PRE-DELAY, ROOM SIZE, RT 60, DAMPING, MIX, LEVEL)
    juce::Slider preDelaySlider, roomSizeSlider, rt60Slider, dampingSlider, mixSlider, levelSlider;

    // 10 Bottom Small Silver Rotary Knobs (REGEN, DELAY, ECHO TIME/LVL L/R, SPREAD, DIFFUSION, BASS BOOST, BASS FREQ)
    juce::Slider regenSlider, delaySlider;
    juce::Slider echoTimeLSlider, echoLevelLSlider, echoTimeRSlider, echoLevelRSlider;
    juce::Slider spreadSlider, diffusionSlider, bassBoostSlider, bassFreqSlider;

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<ComboAttachment>  reverbTypeAtt;
    std::unique_ptr<SliderAttachment> reverbTypeKnobAtt;
    std::unique_ptr<SliderAttachment> roomSizeAtt, rt60Att, preDelayAtt, spreadAtt, diffusionAtt, regenAtt;
    std::unique_ptr<SliderAttachment> dampingAtt, bassBoostAtt, bassFreqAtt, delayAtt;
    std::unique_ptr<SliderAttachment> echoTimeLAtt, echoLevelLAtt, echoTimeRAtt, echoLevelRAtt;
    std::unique_ptr<SliderAttachment> levelAtt, mixAtt;

    AutoKeyLicensePanel licenseOverlay;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TPantheonAudioProcessorEditor)
};
