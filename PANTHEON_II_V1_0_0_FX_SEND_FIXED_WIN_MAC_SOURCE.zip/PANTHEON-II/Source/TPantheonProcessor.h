#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <vector>
#include <atomic>
#include <cmath>
#include <algorithm>
#include "AppBranding.h"
#include "licensing/LicenseManager.h"
#include "licensing/ProductConfig.h"

#include "dsp/PhoenixChamber.h"

class TPantheonAudioProcessor : public juce::AudioProcessor
{
public:
    TPantheonAudioProcessor();
    // Dependency injection for isolated tests; normal license verification is retained.
    explicit TPantheonAudioProcessor(const tak::license::StorePaths& paths);
    ~TPantheonAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return AppBranding::kAppDisplayName; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentPresetIndex.load(std::memory_order_relaxed); }
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    tak::license::LicenseManager& getLicenseManager() noexcept { return licenseManager; }
    bool isPluginUnlocked() const noexcept { return pluginUnlocked.load(std::memory_order_relaxed); }
    void refreshLicenseState();

    float getOutputLevelL() const noexcept { return meterOutL.load(std::memory_order_relaxed); }
    float getOutputLevelR() const noexcept { return meterOutR.load(std::memory_order_relaxed); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    static const std::vector<tpantheon::PantheonPreset>& getFactoryPresets();

private:
    juce::AudioProcessorValueTreeState apvts;
    tak::license::LicenseManager licenseManager;
    std::atomic<bool> pluginUnlocked { true };

    tpantheon::PhoenixChamber chamber;
    std::atomic<int> currentPresetIndex { 0 };
    std::atomic<float> meterOutL { 0.0f }, meterOutR { 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TPantheonAudioProcessor)
};
