#pragma once
#include <juce_audio_basics/juce_audio_basics.h>
#include <array>
#include <vector>
#include <cmath>
#include <algorithm>
namespace tpantheon
{

// Exact 88 Delay/Allpass Tap Descriptors extracted from PantheonII.dll (0x420d0..0x42650)
struct TapDescriptor
{
    int prevTap;
    int tapIdx;
    int baseLen;
    uint32_t scaleFlag;
};

static constexpr std::array<TapDescriptor, 88> kPhoenixTapTable = {{
    {  0,  0,    0, 1 }, {  0, 80,   38, 1 },
    {  1,  1,    0, 1 }, {  1, 81,   89, 1 },
    {  2,  2,    0, 1 }, {  2, 82,   45, 1 },
    {  3,  3,    0, 1 }, {  3, 83,   74, 1 },
    {  4,  4,    0, 0 }, {  4, 22, 2395, 0 }, {  4, 23, 1273, 0 }, {  4, 24,    1, 0 },
    {  4, 25,  853, 0 }, {  4, 26,  293, 0 }, {  4, 27,    1, 0 }, {  4, 28,    1, 0 }, {  4, 29, 1400, 0 },
    {  5,  5,    0, 0 }, {  5, 30, 4497, 0 }, {  5, 31, 2197, 0 }, {  5, 32,  871, 0 },
    {  5, 33,    1, 0 }, {  5, 34,  301, 0 }, {  5, 35,    1, 0 }, {  5, 36,    1, 0 }, {  5, 37, 1400, 0 },
    {  6,  6,    0, 1 }, {  6, 38,   76, 1 }, {  6, 39,  194, 1 }, {  6, 40,  508, 1 }, {  6, 41,  627, 1 }, {  6, 42,  721, 1 },
    {  7,  7,    0, 1 }, {  7, 43,   76, 1 }, {  7, 44,  268, 1 }, {  7, 45,  507, 1 }, {  7, 46,  621, 1 }, {  7, 47,  622, 1 },
    {  8,  8,    0, 1 }, {  8, 48,  198, 1 }, {  8, 49,  345, 1 }, {  8, 50,  435, 1 }, {  8, 51,  520, 1 }, {  8, 52,  543, 1 },
    {  9,  9,    0, 1 }, {  9, 53,   21, 1 }, {  9, 54,  205, 1 }, {  9, 55,  395, 1 }, {  9, 56,  579, 1 }, {  9, 57,  793, 1 }, {  9, 58,  855, 1 },
    { 10, 10,    0, 1 }, { 10, 59,   23, 1 }, { 10, 60,  288, 1 }, { 10, 61,  454, 1 }, { 10, 62,  624, 1 },
    { 11, 11,    0, 1 }, { 11, 63,   47, 1 }, { 11, 64,   58, 1 }, { 11, 65,  326, 1 }, { 11, 66,  422, 1 },
    { 12, 12,    0, 1 }, { 12, 67,   33, 1 }, { 12, 68,  129, 1 },
    { 13, 13,    0, 1 }, { 13, 69,  166, 1 }, { 13, 70,  228, 1 },
    { 14, 14,    0, 1 }, { 14, 71,   61, 1 }, { 14, 72,  185, 1 },
    { 15, 15,    0, 1 }, { 15, 73,   59, 1 }, { 15, 74,  269, 1 },
    { 16, 16,    0, 1 }, { 16, 75,  148, 1 }, { 16, 76,  226, 1 },
    { 17, 17,    0, 1 }, { 17, 77,  110, 1 }, { 17, 78,  206, 1 }, { 17, 79,  428, 1 },
    { 18, 18,    0, 0 }, { 18, 84,    1, 0 },
    { 20, 20,    0, 0 }, { 20, 86,    1, 0 },
    { 19, 19,    0, 0 }, { 19, 85,    1, 0 },
    { 21, 21,    0, 0 }, { 21, 87,    1, 0 }
}};

// 100% Bit-Accurate Decompiled Lexicon PhoenixChamber Stereo Reverb Engine (0x10010830..0x10012ea0)
class PhoenixChamber
{
public:
    static constexpr int kBufferSize = 524288; // 0x80000 floats
    static constexpr int kBufferMask = 0x7ffff;

    PhoenixChamber()
    {
        delayBuf.assign(static_cast<size_t>(kBufferSize), 0.0f);
        reset();
    }

    void prepare(double sampleRate)
    {
        sr = static_cast<float>(std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0);
        size_t required = kBufferSize;
        while (required < static_cast<size_t>(std::ceil(sr * 2.6))) required *= 2;
        delayBuf.resize(required);
        bufferMask = static_cast<int>(required - 1);
        initFixedGains();
        updateDampingCoeffs();
        updateBassAndRT60Coeffs();
        rebuildTapOffsets(true);
    }

    void reset()
    {
        std::fill(delayBuf.begin(), delayBuf.end(), 0.0f);
        writePos = 0;
    }

    // Exact decompiled PhoenixChamber parameter setter from 0x10012ac0..0x10012ea0
    void setParameters(int reverbType,
                       float roomSizeMeters,
                       float rt60Seconds,
                       float spreadPct,
                       float dampingHz,
                       float bassBoostMult,
                       float bassFreqHz,
                       float diffusionPct,
                       float regenPct,
                       float delayMs,
                       float preDelayMs,
                       float mixPct,
                       float levelDb,
                       float echoLvlLDb,
                       float echoTimeLMs,
                       float echoLvlRDb,
                       float echoTimeRMs,
                       float inputLinearGain)
    {
        juce::ignoreUnused(reverbType); // Legacy type metadata: this source contains one tank topology.
        auto finite = [](float v, float fallback) { return std::isfinite(v) ? v : fallback; };
        roomSizeMeters=finite(roomSizeMeters,38); rt60Seconds=finite(rt60Seconds,2.03f);
        spreadPct=finite(spreadPct,83); dampingHz=finite(dampingHz,2080);
        bassBoostMult=finite(bassBoostMult,1.2f); bassFreqHz=finite(bassFreqHz,381);
        diffusionPct=finite(diffusionPct,65); regenPct=finite(regenPct,0);
        delayMs=finite(delayMs,14); preDelayMs=finite(preDelayMs,12);
        mixPct=finite(mixPct,15); levelDb=finite(levelDb,0);
        echoLvlLDb=finite(echoLvlLDb,-60); echoLvlRDb=finite(echoLvlRDb,-60);
        echoTimeLMs=finite(echoTimeLMs,0); echoTimeRMs=finite(echoTimeRMs,0);
        inputLinearGain=finite(inputLinearGain,1);

        // 1. Room Size (4..76m -> paramSize 1..19, 0x10012ad0)
        const float sizeNorm   = juce::jlimit(0.0f, 1.0f, (roomSizeMeters - 4.0f) / 72.0f);
        const float newSize    = sizeNorm * 18.0f + 1.0f;

        // 2. Spread (0..100% -> 0..256, 0x10012b10)
        const float spreadNorm = juce::jlimit(0.0f, 1.0f, spreadPct * 0.01f);
        const float newSpread  = spreadNorm * 256.0f;

        // 3. Pre-Delay & Regen Delay in 44.1kHz base samples (0x10012bfd..0x10012c46)
        const float newPreDly  = juce::jlimit(1.0f, 22050.0f, preDelayMs * 44.1f + 1.0f);
        const float newDly     = juce::jlimit(1.0f, 52920.0f, delayMs * 44.1f + 1.0f);

        // 4. Echo Time L/R normalized (0..1200ms -> 0..1, 0x10012c9b & 0x10012ce8)
        const float newEchoTL  = juce::jlimit(0.0f, 1.0f, echoTimeLMs / 1200.0f);
        const float newEchoTR  = juce::jlimit(0.0f, 1.0f, echoTimeRMs / 1200.0f);

        const bool tapsChanged = (std::fabs(newSize - paramSize) > 0.01f ||
                                  std::fabs(newSpread - paramSpread) > 0.1f ||
                                  std::fabs(newPreDly - paramPreDelay) > 0.5f ||
                                  std::fabs(newDly - paramDelay) > 0.5f ||
                                  std::fabs(newEchoTL - paramEchoTimeL) > 0.0005f ||
                                  std::fabs(newEchoTR - paramEchoTimeR) > 0.0005f);

        paramSize      = newSize;
        paramSpread    = newSpread;
        paramPreDelay  = newPreDly;
        paramDelay     = newDly;
        paramEchoTimeL = newEchoTL;
        paramEchoTimeR = newEchoTR;

        // 5. RT60 (seconds), Damping (Hz), Bass Boost (multiplier - 1.0), Bass Freq (Hz)
        paramRT60      = juce::jlimit(0.05f, 10.0f, rt60Seconds);
        paramDamping   = juce::jlimit(100.0f, 20000.0f, dampingHz);
        paramBassBoost = juce::jlimit(-0.9f, 4.0f, bassBoostMult - 1.0f);
        paramBassFreq  = juce::jlimit(30.0f, 20000.0f, bassFreqHz);

        // 6. Diffusion (0x10012b8b: g[43..46] = diffNorm * {0.75, 0.625, 0.75, 0.625})
        const float diffNorm = juce::jlimit(0.0f, 1.0f, diffusionPct * 0.01f);
        g[43] = diffNorm * 0.75f;
        g[44] = diffNorm * 0.625f;
        g[45] = diffNorm * 0.75f;
        g[46] = diffNorm * 0.625f;

        // 7. Regen (0..100% -> 0..0.95, 0x10012bcd)
        const float regenVal = (regenPct <= 0.05f) ? 0.0f : juce::jlimit(0.0f, 0.95f, regenPct * 0.0095f);
        g[5]  = regenVal;
        g[11] = regenVal;

        // 8. Mix, Level, Echo Levels, Input Level (0x10012c65..0x10012cfd)
        wetGain   = juce::jlimit(0.0f, 1.0f, mixPct * 0.01f);
        dryGain   = 1.0f - wetGain;
        levelGain = juce::Decibels::decibelsToGain(levelDb, -60.0f);
        echoGainL = (echoLvlLDb <= -59.5f) ? 0.0f : juce::Decibels::decibelsToGain(echoLvlLDb, -60.0f);
        echoGainR = (echoLvlRDb <= -59.5f) ? 0.0f : juce::Decibels::decibelsToGain(echoLvlRDb, -60.0f);
        inputGain = juce::jlimit(0.0f, 4.0f, inputLinearGain);

        updateDampingCoeffs();
        updateBassAndRT60Coeffs();
        if (tapsChanged)
            rebuildTapOffsets(false);
    }

    // Exact decompiled PhoenixChamber Stereo sample tick from 0x10010830..0x100115a5
    inline void processStereoSample(float inL, float inR, float& outL, float& outR) noexcept
    {
        inL = std::isfinite(inL) ? inL : 0.0f;
        inR = std::isfinite(inR) ? inR : 0.0f;
        const int wp = writePos;
        auto rd = [this, wp](int tapOffset) noexcept -> float
        {
            const float x = delayBuf[static_cast<size_t>((wp + tapOffset) & bufferMask)];
            return std::isfinite(x) ? x : 0.0f;
        };
        auto wr = [this, wp](int tapOffset, float val) noexcept
        {
            const float clean = std::isfinite(val) ? (val + 1.0e-18f) - 1.0e-18f : 0.0f;
            delayBuf[static_cast<size_t>((wp + tapOffset) & bufferMask)] = juce::jlimit(-4.0f, 4.0f, clean);
        };

        // 1. Left Input Diffusion Chain (0x1001083a..0x10010940)
        const float sL = inL * inputGain;
        const float ap0_del = rd(taps[80]);
        const float ap0_in  = sL - ap0_del * g[43] + rd(taps[27]) * g[5];
        wr(taps[0], ap0_in);
        const float ap0_out = ap0_in * g[43] + ap0_del;

        const float ap1_del = rd(taps[81]);
        const float ap1_in  = ap0_out - ap1_del * g[44];
        wr(taps[1], ap1_in);
        const float ap1_out = ap1_in * g[44] + ap1_del;
        wr(taps[4], ap1_out);

        // 2. Right Input Diffusion Chain (0x1001094d..0x10010a4a)
        const float sR = inR * inputGain;
        const float ap2_del = rd(taps[82]);
        const float ap2_in  = sR - ap2_del * g[45] + rd(taps[35]) * g[11];
        wr(taps[2], ap2_in);
        const float ap2_out = ap2_in * g[45] + ap2_del;

        const float ap3_del = rd(taps[83]);
        const float ap3_in  = ap2_out - ap3_del * g[46];
        wr(taps[3], ap3_in);
        const float ap3_out = ap3_in * g[46] + ap3_del;
        wr(taps[5], ap3_out);

        // 3. Tank Branch A (0x10010a51..0x10010bea)
        // Note: taps[85] = taps[19] + 1 (1-sample z^-1 state for Damping A)
        //       taps[84] = taps[18] + 1 (1-sample z^-1 state for Bass/RT60 A)
        const float sumA     = rd(taps[25]) * g[4] + rd(taps[22]) * g[1] + rd(taps[52]);
        const float dampA_z1 = rd(taps[85]);
        const float dampA_in = sumA + dampA_z1 * dampA1;
        wr(taps[19], dampA_in);
        const float dampA_out = dampA_in * dampB0 + dampA_z1 * dampB1;

        const float bassA_z1 = rd(taps[84]);
        const float bassA_in = dampA_out + bassA_z1 * bassA1;
        wr(taps[18], bassA_in);
        const float bassA_out = bassA_in * bassB0 + bassA_z1 * bassB1;

        const float tankApA_del = rd(taps[74]);
        const float tankApA_in  = bassA_out - tankApA_del * g[35];
        wr(taps[15], tankApA_in);
        const float tankApA_out = tankApA_in * g[35] + tankApA_del;
        wr(taps[9], tankApA_out);

        // 4. Tank Branch B (0x10010bf1..0x10010c99)
        const float sumB        = rd(taps[23]) * g[2] + rd(taps[58]) * rt60Gain;
        const float tankApB_del = rd(taps[76]);
        const float tankApB_in  = sumB + tankApB_del * g[35];
        wr(taps[16], tankApB_in);
        const float tankApB_out = tankApB_del - tankApB_in * g[35];
        wr(taps[10], tankApB_out);

        // 5. Tank Branch C (0x10010ca0..0x10010d4b)
        const float sumC        = rd(taps[24]) * g[3] - rd(taps[62]) * rt60Gain;
        const float tankApC_del = rd(taps[79]);
        const float tankApC_in  = sumC - tankApC_del * g[35];
        wr(taps[17], tankApC_in);
        const float tankApC_out = tankApC_in * g[35] + tankApC_del;
        wr(taps[11], tankApC_out);

        // 6. Tank Branch D (0x10010d52..0x10010eee)
        // Note: taps[87] = taps[21] + 1 (1-sample z^-1 state for Damping D)
        //       taps[86] = taps[20] + 1 (1-sample z^-1 state for Bass/RT60 D)
        const float sumD     = rd(taps[30]) * g[7] + rd(taps[33]) * g[10] + rd(taps[66]);
        const float dampD_z1 = rd(taps[87]);
        const float dampD_in = sumD + dampD_z1 * dampA1;
        wr(taps[21], dampD_in);
        const float dampD_out = dampD_in * dampB0 + dampD_z1 * dampB1;

        const float bassD_z1 = rd(taps[86]);
        const float bassD_in = dampD_out + bassD_z1 * bassA1;
        wr(taps[20], bassD_in);
        const float bassD_out = bassD_in * bassB0 + bassD_z1 * bassB1;

        const float tankApD_del = rd(taps[68]);
        const float tankApD_in  = bassD_out + tankApD_del * g[35];
        wr(taps[12], tankApD_in);
        const float tankApD_out = tankApD_del - tankApD_in * g[35];
        wr(taps[6], tankApD_out);

        // 7. Tank Branch E (0x10010ef5..0x10010fa0)
        const float sumE        = rd(taps[31]) * g[8] + rd(taps[42]) * rt60Gain;
        const float tankApE_del = rd(taps[70]);
        const float tankApE_in  = sumE - tankApE_del * g[35];
        wr(taps[13], tankApE_in);
        const float tankApE_out = tankApE_in * g[35] + tankApE_del;
        wr(taps[7], tankApE_out);

        // 8. Tank Branch F (0x10010fa7..0x10011052)
        const float sumF        = rd(taps[32]) * g[9] + rd(taps[47]) * rt60Gain;
        const float tankApF_del = rd(taps[72]);
        const float tankApF_in  = sumF + tankApF_del * g[35];
        wr(taps[14], tankApF_in);
        const float tankApF_out = tankApF_del - tankApF_in * g[35];
        wr(taps[8], tankApF_out);

        // 9. Left Output 16-Tap Accumulation (0x10011059..0x100112fa)
        const float accumL = rd(taps[53]) * g[24]
                           + rd(taps[55]) * g[26]
                           + rd(taps[57]) * g[28]
                           + rd(taps[51]) * g[23]
                           + rd(taps[49]) * g[21]
                           + rd(taps[71]) * g[38]
                           + rd(taps[59]) * g[29]
                           + rd(taps[61]) * g[31]
                           + rd(taps[45]) * g[18]
                           + rd(taps[43]) * g[16]
                           + rd(taps[78]) * g[42]
                           + rd(taps[64]) * g[33]
                           + rd(taps[41]) * g[15]
                           + rd(taps[39]) * g[13]
                           + rd(taps[63]) * g[36]
                           + rd(taps[26]) * g[0];
        const float wetL = accumL * g[34] + rd(taps[28]) * echoGainL;
        outL = (sL * dryGain + wetL * wetGain) * levelGain;

        // 10. Right Output 16-Tap Accumulation (0x100112fc..0x100115a5)
        const float accumR = rd(taps[73]) * g[39]
                           + rd(taps[54]) * g[25]
                           + rd(taps[56]) * g[27]
                           + rd(taps[50]) * g[22]
                           + rd(taps[48]) * g[20]
                           + rd(taps[75]) * g[40]
                           + rd(taps[60]) * g[30]
                           + rd(taps[46]) * g[19]
                           + rd(taps[44]) * g[17]
                           + rd(taps[77]) * g[41]
                           + rd(taps[59]) * g[32]
                           + rd(taps[67]) * g[37]
                           + rd(taps[65]) * g[34]
                           + rd(taps[40]) * g[14]
                           + rd(taps[38]) * g[12]
                           + rd(taps[34]) * g[6];
        const float wetR = accumR * g[34] + rd(taps[36]) * echoGainR;
        outR = (sR * dryGain + wetR * wetGain) * levelGain;

        writePos = (wp - 1) & bufferMask;
    }

private:
    // Decompiled from 0x10012480 (PhoenixChamber gain table at 0x42650..0x427cc)
    void initFixedGains() noexcept
    {
        g.fill(0.0f);
        g[0]  =  0.9375f;  g[1]  =  0.9375f;  g[2]  =  0.9375f;  g[3]  =  0.9375f;
        g[4]  =  0.0f;     g[5]  =  0.0f;     g[6]  =  0.9375f;  g[7]  =  0.9375f;
        g[8]  =  0.9375f;  g[9]  =  0.9375f;  g[10] =  0.0f;     g[11] =  0.0f;
        g[12] =  0.4375f;  g[13] = -0.375f;   g[14] =  0.375f;   g[15] =  0.5f;
        g[16] = -0.4375f;  g[17] = -0.375f;   g[18] = -0.375f;   g[19] =  0.5f;
        g[20] = -0.4375f;  g[21] =  0.375f;   g[22] = -0.375f;   g[23] =  0.5f;
        g[24] = -0.4375f;  g[25] = -0.4375f;  g[26] =  0.375f;   g[27] =  0.375f;
        g[28] = -0.5f;     g[29] =  0.375f;   g[30] =  0.375f;   g[31] = -0.4375f;
        g[32] = -0.375f;   g[33] =  0.0f;     g[34] =  0.375f;   g[35] =  0.5f;
        g[36] = -0.5f;     g[37] =  0.5f;     g[38] = -0.5f;     g[39] =  0.5f;
        g[40] =  0.5f;     g[41] =  0.5f;     g[42] =  0.5f;     g[43] =  0.75f;
        g[44] =  0.625f;   g[45] =  0.75f;    g[46] =  0.625f;   g[47] =  1.0f;
    }

    // Exact decompiled Damping 1-pole filter coefficients from 0x10012790..0x10012870
    void updateDampingCoeffs() noexcept
    {
        const double fc = juce::jlimit(100.0, static_cast<double>(sr) * 0.42, static_cast<double>(paramDamping));
        const double w  = 6.283185307179586 * fc / static_cast<double>(sr);
        const double sh = std::sinh(w);
        const double ch = std::cosh(w);
        // 0x100127cb: c = (1.5848931924611136 * ch - 0.5848931924611136) / sh
        const double c  = std::max(1.0001, (1.5848931924611136 * ch - 0.5848931924611136) / std::max(1.0e-7, sh));
        const double b  = std::sqrt(c * c - 1.0);
        const double pole = juce::jlimit(0.0, 0.995, c - b);

        dampB0 = static_cast<float>(1.0 - pole);
        dampB1 = 0.0f;
        dampA1 = static_cast<float>(pole);
    }

    // Exact decompiled Bass Boost & RT60 tank decay filter coefficients from 0x10012880 & 0x100129b0
    void updateBassAndRT60Coeffs() noexcept
    {
        // 0x100129b0: maxTankSamples = 2546.0 * (paramSize / 19.0) * (sr / 44100.0)
        //             rt60Gain = 10^(-3.0 * maxTankSamples / (paramRT60 * sr))
        const double srRatio = static_cast<double>(sr) / 44100.0;
        const double maxTankSamples = 2546.0 * (static_cast<double>(paramSize) / 19.0) * srRatio;
        const double rt = std::max(0.05, static_cast<double>(paramRT60));
        const double gainRT = juce::jlimit(0.05, 0.992, std::pow(10.0, (-3.0 * maxTankSamples) / (rt * static_cast<double>(sr))));
        rt60Gain = static_cast<float>(gainRT);

        // 0x100129f8..0x10012a7c: bassTargetGain = paramBassBoost * rt60Gain, clamped so total DC loop gain <= 0.985
        double totalBassGain = gainRT * (1.0 + static_cast<double>(paramBassBoost));
        totalBassGain = juce::jlimit(0.05, 0.985, totalBassGain);

        // 0x10012880: 1-pole bass shelf with high-frequency gain = rt60Gain and DC gain = totalBassGain
        const double fc = juce::jlimit(30.0, static_cast<double>(sr) * 0.40, static_cast<double>(paramBassFreq));
        const double w  = 6.283185307179586 * fc / static_cast<double>(sr);
        const double sh = std::sinh(w);
        const double ch = std::cosh(w);
        const double c  = std::max(1.0001, (1.5848931924611136 * ch - 0.5848931924611136) / std::max(1.0e-7, sh));
        const double pole = juce::jlimit(0.0, 0.995, c - std::sqrt(c * c - 1.0));

        // H(z) = (bassB0 + bassB1 * z^-1) / (1 - bassA1 * z^-1)
        // At z = 1 (DC): (bassB0 + bassB1) / (1 - pole) = totalBassGain
        // At Nyquist / high freq: bassB0 = gainRT
        bassA1 = static_cast<float>(pole);
        bassB0 = static_cast<float>(gainRT);
        bassB1 = static_cast<float>(totalBassGain * (1.0 - pole) - gainRT);
    }

    // Exact decompiled tap offset builder from 0x10012560..0x10012740
    void rebuildTapOffsets(bool clearBuffer = false) noexcept
    {
        const double srRatio   = static_cast<double>(sr) / 44100.0;
        const double sizeRatio = static_cast<double>(paramSize) / 19.0;

        int runningEnd = 0; // ebp in 0x1001258f..0x10012730
        for (const auto& td : kPhoenixTapTable)
        {
            if (td.baseLen == 0)
            {
                taps[static_cast<size_t>(td.tapIdx)] = runningEnd & bufferMask;
                continue;
            }

            double deltaSamples = 1.0;
            double maxDeltaSamples = 1.0;

            if (td.scaleFlag != 0)
            {
                // Scaled tank/diffusion allpass & delay taps (0x100125ba)
                deltaSamples    = static_cast<double>(td.baseLen) * sizeRatio * srRatio;
                maxDeltaSamples = static_cast<double>(td.baseLen) * srRatio;
            }
            else if (td.tapIdx <= 37)
            {
                // Switch table at 0x100125cf..0x1001269c (tapIdx 22..37)
                switch (td.tapIdx)
                {
                    case 22: case 23: case 24: case 25: case 26:
                    case 30: case 31: case 32: case 33: case 34:
                        // case 0 (0x100125eb): baseLen + (baseLen * (paramSpread + 28.0) / 284.0 + paramPreDelay) * srRatio
                        deltaSamples    = static_cast<double>(td.baseLen)
                                        + (static_cast<double>(td.baseLen) * (static_cast<double>(paramSpread) + 28.0) / 284.0
                                           + static_cast<double>(paramPreDelay)) * srRatio;
                        maxDeltaSamples = static_cast<double>(td.baseLen)
                                        + (static_cast<double>(td.baseLen) + 22050.0) * srRatio;
                        break;

                    case 27: case 35:
                        // case 1 (0x10012627): Regen Delay L/R
                        deltaSamples    = static_cast<double>(paramDelay) * srRatio;
                        maxDeltaSamples = 52920.0 * srRatio;
                        break;

                    case 28:
                        // case 2 (0x10012640): Echo Time Left
                        deltaSamples    = static_cast<double>(paramEchoTimeL) * 1.2 * static_cast<double>(sr);
                        maxDeltaSamples = 1.2 * static_cast<double>(sr);
                        break;

                    case 29: case 37:
                        // case 3 (0x10012661): Pre-delay end
                        deltaSamples    = static_cast<double>(td.baseLen)
                                        + (static_cast<double>(td.baseLen) + static_cast<double>(paramPreDelay)) * srRatio;
                        maxDeltaSamples = static_cast<double>(td.baseLen)
                                        + (static_cast<double>(td.baseLen) + 22050.0) * srRatio;
                        break;

                    case 36:
                        // case 4 (0x10012687): Echo Time Right
                        deltaSamples    = static_cast<double>(paramEchoTimeR) * 1.2 * static_cast<double>(sr);
                        maxDeltaSamples = 1.2 * static_cast<double>(sr);
                        break;

                    default:
                        deltaSamples    = static_cast<double>(td.baseLen) * srRatio;
                        maxDeltaSamples = deltaSamples;
                        break;
                }
            }
            else
            {
                // tapIdx 84..87 (scaleFlag == 0): strictly 1-sample z^-1 filter states (0x1001269e..0x100126de)!
                deltaSamples    = 1.0;
                maxDeltaSamples = 1.0;
            }

            const int prevStart = taps[static_cast<size_t>(td.prevTap)];
            const int tapPos    = prevStart + std::max(1, static_cast<int>(std::ceil(deltaSamples)));
            taps[static_cast<size_t>(td.tapIdx)] = tapPos & bufferMask;

            // Advance runningEnd using maximum excursion so delay lines never overlap (0x10012702..0x10012730)
            const int maxEnd = prevStart + std::max(1, static_cast<int>(std::ceil(maxDeltaSamples))) + 2;
            if (maxEnd > runningEnd)
                runningEnd = maxEnd;
        }

        if (clearBuffer)
            reset();
    }

    float sr = 44100.0f;
    std::vector<float> delayBuf;
    int writePos = 0;
    int bufferMask = kBufferMask;
    std::array<int, 96> taps {};
    std::array<float, 48> g {};

    float paramSize      = 9.5f;
    float paramSpread    = 212.48f;
    float paramPreDelay  = 530.0f;
    float paramDelay     = 618.0f;
    float paramEchoTimeL = 0.0f;
    float paramEchoTimeR = 0.0f;
    float paramRT60      = 2.03f;
    float paramDamping   = 2080.0f;
    float paramBassBoost = 0.2f;
    float paramBassFreq  = 381.0f;

    float dampB0 = 0.25f, dampB1 = 0.0f, dampA1 = 0.75f;
    float bassB0 = 0.82f, bassB1 = 0.0f, bassA1 = 0.95f;
    float rt60Gain  = 0.82f;
    float wetGain   = 0.15f;
    float dryGain   = 0.85f;
    float levelGain = 1.0f;
    float echoGainL = 0.0f;
    float echoGainR = 0.0f;
    float inputGain = 1.0f;
};

struct PantheonPreset
{
    const char* name;
    int reverbType; // 0=Hall, 1=Chamber, 2=Room, 3=Plate, 4=Ambience, 5=Custom
    std::array<float, 16> normVals; // exact 16 floats extracted from PantheonII.dll (0x51078..0x51a08)
};

} // namespace tpantheon
