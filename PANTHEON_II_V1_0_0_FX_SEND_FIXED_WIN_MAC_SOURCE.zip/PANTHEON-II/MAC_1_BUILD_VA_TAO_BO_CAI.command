#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
BUILD="$ROOT/build_mac_universal"
EXPORT="$ROOT/_EXPORT_MAC"
LOG="$ROOT/BUILD_LOG_MAC.txt"
TARGET="PantheonII"
fail() { printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG"; exit 1; }
CMAKE="$(command -v cmake || true)"
for candidate in /opt/homebrew/bin/cmake /usr/local/bin/cmake /Applications/CMake.app/Contents/bin/cmake; do
    if [[ -z "$CMAKE" && -x "$candidate" ]]; then CMAKE="$candidate"; fi
done
[[ -n "$CMAKE" ]] || fail 'Install CMake 3.22 or newer'
xcrun --find clang++ >/dev/null 2>&1 || fail 'Install Xcode Command Line Tools'
json_get() { /usr/bin/osascript -l JavaScript -e 'function run(a){ObjC.import("Foundation"); var s=$.NSString.stringWithContentsOfFileEncodingError(a[0],$.NSUTF8StringEncoding,null);return String(JSON.parse(ObjC.unwrap(s))[a[1]]);}' "$ROOT/ThuongHieu.json" "$1"; }
NAME="$(json_get vst3Name)"; VERSION="$(json_get appVersion)"
[[ -n "$NAME" && "$NAME" != *'/'* && "$NAME" != *':'* ]] || fail 'Invalid plugin name'
: > "$LOG"
JOBS="$(sysctl -n hw.ncpu 2>/dev/null || echo 2)"; [[ "$JOBS" =~ ^[0-9]+$ ]] || JOBS=2
(( JOBS > 4 )) && JOBS=4
"$CMAKE" -S "$ROOT" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64' -DBUILD_TESTING=ON >> "$LOG" 2>&1 || fail 'Configure failed'
"$CMAKE" --build "$BUILD" --config Release --target "${TARGET}_VST3" "${TARGET}_AU" "${TARGET}_Standalone" DSPRegressionTests ProcessorRegressionTests OwnerLicenseTool --parallel "$JOBS" >> "$LOG" 2>&1 || fail 'Build failed'
CTEST="$(dirname "$CMAKE")/ctest"; [[ -x "$CTEST" ]] || CTEST="$(command -v ctest || true)"
[[ -n "$CTEST" ]] || fail 'ctest not found'
"$CTEST" --test-dir "$BUILD" -C Release --output-on-failure >> "$LOG" 2>&1 || fail 'Regression tests failed'
STAGE="$ROOT/_EXPORT_MAC.new"
rm -rf "$STAGE"; mkdir -p "$STAGE/vst3" "$STAGE/au" "$STAGE/apps"
for spec in 'VST3:vst3:vst3' 'AU:au:component' 'Standalone:apps:app'; do
    IFS=: read -r format destination extension <<< "$spec"
    bundle="$BUILD/${TARGET}_artefacts/Release/$format/$NAME.$extension"
    [[ -d "$bundle" ]] || fail "Missing bundle: $bundle"
    ditto "$bundle" "$STAGE/$destination/$NAME.$extension"
    bundle="$STAGE/$destination/$NAME.$extension"
    executable="$(/usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$bundle/Contents/Info.plist")"
    lipo -verify_arch arm64 x86_64 "$bundle/Contents/MacOS/$executable" >> "$LOG" 2>&1 || fail 'Universal architecture check failed'
    if [[ -n "${APP_SIGN_ID:-}" ]]; then
        /usr/bin/codesign --force --options runtime --timestamp --sign "$APP_SIGN_ID" "$bundle" >> "$LOG" 2>&1 || fail 'Signing failed'
    else
        /usr/bin/codesign --force --sign - "$bundle" >> "$LOG" 2>&1 || fail 'Ad-hoc signing failed'
    fi
    /usr/bin/codesign --verify --strict "$bundle" >> "$LOG" 2>&1 || fail 'Signature verification failed'
done
rm -rf "$EXPORT"; mv "$STAGE" "$EXPORT"
WORK="$BUILD/pkgwork"; rm -rf "$WORK"; mkdir -p "$WORK" "$ROOT/Output"
PARTS=()
for spec in 'vst3:/Library/Audio/Plug-Ins/VST3' 'au:/Library/Audio/Plug-Ins/Components' 'apps:/Applications'; do
    kind="${spec%%:*}"; destination="${spec#*:}"; plist="$WORK/$kind.plist"
    pkgbuild --analyze --root "$EXPORT/$kind" "$plist" >> "$LOG" 2>&1 || fail 'Package analysis failed'
    i=0
    while /usr/libexec/PlistBuddy -c "Print :$i" "$plist" >/dev/null 2>&1; do
        /usr/libexec/PlistBuddy -c "Set :$i:BundleIsRelocatable false" "$plist" >> "$LOG" 2>&1 || fail 'Package relocatability configuration failed'
        /usr/libexec/PlistBuddy -c "Set :$i:BundleOverwriteAction upgrade" "$plist" >> "$LOG" 2>&1 || fail 'Package overwrite configuration failed'
        i=$((i+1))
    done
    pkgbuild --root "$EXPORT/$kind" --component-plist "$plist" --install-location "$destination" --identifier "com.lexicon.pantheonii.$kind" --version "$VERSION" "$WORK/$kind.pkg" >> "$LOG" 2>&1 || fail 'pkgbuild failed'
    PARTS+=(--package "$WORK/$kind.pkg")
done
SAFE_NAME="$(printf '%s' "$NAME" | tr ' ' '_' | tr -cd 'A-Za-z0-9_.-')"
[[ -n "$SAFE_NAME" ]] || SAFE_NAME="$TARGET"
OUT="$ROOT/Output/${SAFE_NAME}_${VERSION}_mac.pkg"
if [[ -n "${INSTALLER_SIGN_ID:-}" ]]; then
    productbuild --sign "$INSTALLER_SIGN_ID" "${PARTS[@]}" "$OUT" >> "$LOG" 2>&1 || fail 'productbuild failed'
else
    productbuild "${PARTS[@]}" "$OUT" >> "$LOG" 2>&1 || fail 'productbuild failed'
fi
printf 'Build/tests/export complete: %s\nInstaller: %s\n' "$EXPORT" "$OUT"
