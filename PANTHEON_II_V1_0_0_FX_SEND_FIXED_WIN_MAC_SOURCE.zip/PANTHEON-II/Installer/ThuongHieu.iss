﻿// Generated from ThuongHieu.json.
#define MyAppName "PantheonII"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Lexicon"
#define MyAppExeName "PantheonII.exe"
#define MySetupName "Setup_PantheonII"
#define MyVst3Name "PantheonII"
#define MyAppId "{{9B4E8C12-7D31-4E58-8F29-62C94A1E2052}"
