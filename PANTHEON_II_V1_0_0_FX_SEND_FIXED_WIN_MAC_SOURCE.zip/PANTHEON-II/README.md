> Bản sửa FX Send: xem **GHI_CHU_DOT_SUA_FX_SEND.md** để biết thay đổi, preset mới, cách build và giới hạn. Đây là ZIP mã nguồn.

# PANTHEON II 1.0.0 — mã nguồn đã sửa

Bản sửa ngày 27/10/2026. Giữ nguyên bundle ID, manufacturer/plugin code và parameter ID từ mã đầu vào.

## Đã sửa

- Ngăn NaN/Inf vào mạng hồi tiếp và đọc/ghi state, tránh một mẫu lỗi làm hỏng đuôi reverb.
- Tách DSP ra Source/dsp/PhoenixChamber.h để kiểm thử trực tiếp.
- Buffer tăng theo sample rate ở prepare, giữ vùng tap không chồng lấn tại các rate cao; không cấp phát khi xử lý mẫu.
- Mono vào/stereo ra được cấp cùng tín hiệu đầu vào cho hai nhánh, tránh mất dry kênh phải.
- Báo tail theo RT60, predelay/echo và regeneration, thay số cố định 4 giây để host có thời gian xuất đuôi.
- Lưu/khôi phục cả chỉ số factory preset; chỉ số dùng atomic.
- Sửa brand-sync để sinh đúng namespace AppBranding, giữ product ID/public key khi brand không đổi; giữ installer AppId cũ cho brand hiện tại.
- CMake lấy tên/publisher/version từ ThuongHieu.json. Sửa script Windows/macOS và thêm test.

## Giới hạn thật của mã nguồn

Source hiện chỉ có một mạng PhoenixChamber. reverbType là nhãn phân loại preset, chưa chọn sáu topology Hall/Chamber/Room/Plate/Ambience/Custom khác nhau; đã thêm tooltip giải thích. Các tên preset Nonlinear cũng chưa chứng minh có thuật toán gated reverb riêng. Không tự dựng thêm engine rồi gọi là đúng thuật toán hãng.

## Kết quả kiểm thử

DSP: 10 trường hợp rate/NaN/Inf, gồm 8 rate 8–384 kHz, dry identity, impulse phải có wet output, reset, đối chiếu đầu vào lỗi với mẫu zero. Processor: mono→stereo, 35 preset, state/preset recall, tail và tạo editor. Thêm test codec license. Xem TEST_RESULTS.

## Build và kiểm thử

Đây là **mã nguồn**, không có sẵn VST3 Windows/macOS hay installer đã build. README cũ nói có sẵn Melodic X và không cần C++ là không đúng với hai gói này.

- Windows: Visual Studio Desktop development with C++, Windows SDK, CMake 3.22+. Chạy `1_BUILD_WINDOWS.bat`; script dùng Ninja nếu có, nếu không dùng NMake. `5_SUA_LOI_BUILD_NINJA.bat` xóa cache cấu hình được tạo trong build-diag khi anh chủ động chọn sửa cache. Tạo installer cần Inno Setup 6/7, chạy `2_TAO_BO_CAI_WINDOWS.bat` sau khi build. Gói staging được lấy từ `XuatBan`; luôn build lại sau khi sửa source.
- macOS: Xcode Command Line Tools và CMake. Chạy `chmod +x *.command`, rồi `./MAC_1_BUILD_VA_TAO_BO_CAI.command`. Script chọn đúng VST3/AU/Standalone target, chạy test, xác minh cả arm64+x86_64, ký và tạo .pkg. Có thể đặt APP_SIGN_ID/INSTALLER_SIGN_ID; mặc định plugin chỉ ký ad-hoc. Chưa chạy native macOS, notarization hoặc tạo installer ở môi trường đánh giá này.
- Thư viện JUCE đi kèm trong ThirdParty/JUCE. Có thể dùng gói JUCE 8.0.12 đã cài bằng JUCE_DIR khi cần.

Kiểm thử DSP không cần GUI:

```sh
cmake -S . -B build-dsp -DDSP_TESTS_ONLY=ON -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build-dsp --config Release
ctest --test-dir build-dsp -C Release --output-on-failure
```

Kiểm thử đầy đủ: bỏ DSP_TESTS_ONLY, bật BUILD_TESTING, build các target VST3, DSPRegressionTests, ProcessorRegressionTests và OwnerLicenseTool, rồi chạy ctest. Test processor cần desktop/display (trên Linux có thể dùng Xvfb). Test dùng trial hợp lệ trong thư mục tạm và xóa thư mục sau khi chạy; bộ xác minh license sản phẩm vẫn giữ nguyên. Các kiểm tra dùng mã thoát trực tiếp, không bị NDEBUG tắt trong Release.

## Tiện ích cấp license cho chủ sản phẩm

Bộ sinh key PowerShell cũ ghi RSA XML và cắt ngắn chữ ký thành chuỗi không tương thích với TAK1 trong plugin. Đã thay bằng OwnerLicenseTool dùng chính LicenseCodec.cpp của plugin:

- `OwnerLicenseTool self-test`: tạo cặp khóa tạm trong RAM, ký/xác minh, kiểm tra từ chối token bị sửa, sai product, sai máy, hết hạn.
- `OwnerLicenseTool sign PRIVATE_KEY.txt REQUEST.txt "Tên khách" 365 OUTPUT.taklic`: ký phiếu kích hoạt đúng product/brand. `0` ngày nghĩa là vĩnh viễn. Tool tự xác minh bằng public key nhúng trong bản build trước khi lưu file, từ chối ghi đè output.
- `SINH_KEY.bat`: dùng tool đã build. Phải có private key đúng với public key của sản phẩm. Khi thiếu, tool báo cần khôi phục khóa gốc; không tự đổi khóa và không xuất key giả thành công.
- Chỉ khi chủ động tạo/đổi cặp khóa: `SINH_KEY.bat -CreateNewKeyPair`, sau đó build lại cả plugin và tool. Cặp mới không thay thế được khóa gốc để duy trì license khách cũ.

Các khóa ký riêng lẫn từ dự án khác trong ZIP đầu vào không được kèm trong ZIP bàn giao. Bản ZIP gốc vẫn còn nguyên để anh lưu trữ riêng. Không chia sẻ private key cho khách; installer chỉ lấy bundle VST3 từ XuatBan.

## Phạm vi xác minh

Đã biên dịch VST3 Linux x86_64 và chạy test DSP/processor/codec. PowerShell được kiểm tra cú pháp; script macOS được bash -n kiểm tra cú pháp và rà đúng target/đường dẫn. Chưa chạy Visual Studio, Xcode, AU validation, installer, DAW hoặc nghe A/B với plugin hãng. Các nhãn EXACT/bit-accurate trong ZIP/comment ban đầu chưa có dữ liệu đối chứng.
