# PANTHEON II 1.0.0 — ghi chú

## Đã sửa

- Ngăn NaN/Inf vào mạng hồi tiếp và đọc/ghi state, tránh một mẫu lỗi làm hỏng đuôi reverb.
- Tách DSP ra Source/dsp/PhoenixChamber.h để kiểm thử trực tiếp.
- Buffer tăng theo sample rate ở prepare, giữ vùng tap không chồng lấn tại các rate cao; không cấp phát khi xử lý mẫu.
- Mono vào/stereo ra được cấp cùng tín hiệu đầu vào cho hai nhánh, tránh mất dry kênh phải.
- Báo tail theo RT60, predelay/echo và regeneration, thay số cố định 4 giây để host có thời gian xuất đuôi.
- Lưu/khôi phục cả chỉ số factory preset; chỉ số dùng atomic.
- Sửa brand-sync để sinh đúng namespace AppBranding, giữ product ID/public key khi brand không đổi; giữ installer AppId cũ cho brand hiện tại.
- CMake lấy tên/publisher/version từ ThuongHieu.json. Sửa script Windows/macOS và thêm test.

## Giới hạn thật của mã nguồn

Source hiện chỉ có một mạng PhoenixChamber. reverbType là nhãn phân loại preset, chưa chọn sáu topology Hall/Chamber/Room/Plate/Ambience/Custom khác nhau; đã thêm tooltip giải thích. Các tên preset Nonlinear cũng chưa chứng minh có thuật toán gated reverb riêng. Không tự dựng thêm engine rồi gọi là đúng thuật toán hãng.

## Kết quả kiểm thử

DSP: 10 trường hợp rate/NaN/Inf, gồm 8 rate 8–384 kHz, dry identity, impulse phải có wet output, reset, đối chiếu đầu vào lỗi với mẫu zero. Processor: mono→stereo, 35 preset, state/preset recall, tail và tạo editor. Thêm test codec license. Xem TEST_RESULTS.

Hướng dẫn build, cấp license và giới hạn xác minh nằm trong README.md.
