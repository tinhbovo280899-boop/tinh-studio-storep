# PANTHEON II — preset vang ngắn cho FX Send

Giữ engine và 35 preset cũ; thêm:

- Vocal Short - FX Send: RT60 đặt 0,45 s, Room 12 m, Predelay 10 ms, Diffusion 80%, Damping khoảng 3,5 kHz.
- Vocal Body - FX Send: RT60 đặt 0,75 s, Room 16 m, Predelay 12 ms, Diffusion 80%, Damping khoảng 4 kHz.

Cả hai Mix 100%, Echo tắt, Regen 0; chỉnh lượng bằng Send/Return. Đây là thông số khởi đầu để làm dày giọng, không phải preset đã nghe cùng vocal của anh. Không thay default/preset anh đang thích hoặc rút đuôi của project cũ.

Source vẫn có một mạng PhoenixChamber. Nhãn Hall/Room/Plate không chọn các topology khác nhau. Không dựng thêm engine rồi gọi là đúng hãng. Cách build/installer theo README và menu gốc. Bỏ LTO bắt buộc trong CMake để build/link ít tốn bộ nhớ hơn; không đổi biểu thức DSP.

## Phạm vi xác minh

ZIP là mã nguồn dành cho Windows/macOS, chưa phải plugin hoặc bộ cài Windows/macOS đã biên dịch. Kiểm thử native hiện thực hiện trên Linux; xem TEST_RESULTS_BATCH sau khi đóng gói. Chưa có bản vocal của anh để xác nhận cảm giác mềm/quyện. Không tuyên bố tương đương 1:1 thuật toán của hãng; các comment địa chỉ/nguồn tham khảo cũ không phải kết quả xác minh đó.

Giữ plugin ID, ID tham số và các preset cũ theo thứ tự ban đầu. Preset FX Send được thêm cuối danh sách; preset mới không tự áp lên project cũ. Sao lưu project/plugin trước khi thay bản để nghe A/B.
