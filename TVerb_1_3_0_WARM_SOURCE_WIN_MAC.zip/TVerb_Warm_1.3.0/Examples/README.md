# Mẫu nghe tổng hợp

Ba WAV stereo PCM16, 48 kHz, 14 giây, có khoảng trống cuối để nghe đuôi.

1. `01_Legacy_reference.wav`: cấu hình smooth dùng làm mốc, Decay 3,5 s và Predelay 35 ms; không phải toàn bộ preset mặc định nguyên gốc.
2. `02_Day_Oang_Warmth_0.wav`: cấu hình Dày Oang Ấm, Warmth 0%.
3. `03_Day_Oang_Am_Warmth_35.wav`: cùng cấu hình mẫu 02, Warmth 35%.

Cùng dry và cân cùng RMS wet trên toàn clip, không cân LUFS. Mẫu 02/03 dùng cùng Early −1 dB/Late 0 dB. Import vào DAW ở cùng vị trí rồi bật từng mẫu để so; tránh phát đồng thời. Đây là nguyên âm tổng hợp, không phải giọng thật hoặc render plugin hãng. File mô tả gain ở `Validation/listening-files.json`.
