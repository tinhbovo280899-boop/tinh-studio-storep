@echo off
setlocal
cd /d "%~dp0"
where cmake >nul 2>nul
if errorlevel 1 (
  echo Install CMake 3.22+ and Visual Studio 2022 Desktop development with C++ first.
  pause
  exit /b 1
)
cmake -S . -B build-win -G "Visual Studio 17 2022" -A x64 -DBUILD_TESTING=ON
if errorlevel 1 goto failed
cmake --build build-win --config Release --parallel 2
if errorlevel 1 goto failed
ctest --test-dir build-win -C Release --output-on-failure
if errorlevel 1 goto failed
cmake --install build-win --config Release --component Plugins --prefix "%CD%/dist"
if errorlevel 1 goto failed
echo.
echo Done: dist\VST3\T-Verb.vst3
explorer "%CD%\dist\VST3"
pause
exit /b 0
:failed
echo Build or tests failed. Review the error above.
pause
exit /b 1
