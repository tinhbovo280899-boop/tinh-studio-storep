#include "TVerbParameters.h"
#include <iostream>
#include <limits>
#include <vector>

using namespace tverbdsp;
int checks = 0, failures = 0;
void check(bool pass, const std::string& name, double value = 0) {
    ++checks; if (!pass) ++failures;
    std::cout << (pass ? "PASS " : "FAIL ") << name << " value=" << value << '\n';
}
struct Stereo { std::vector<float> l, r; };
Stereo input(int sr, int seconds = 2) {
    Stereo x{std::vector<float>(sr * seconds), std::vector<float>(sr * seconds)};
    for (int i = 0; i < sr * seconds; ++i) {
        x.l[i] = i < sr ? float(.12 * std::sin(2 * M_PI * 233 * i / sr)) : 0;
        x.r[i] = i < sr ? float(.10 * std::sin(2 * M_PI * 337 * i / sr)) : 0;
    }
    return x;
}
void wet(TVerbPluginWrapper& p) {
    p.setParameter(kParam_DryLevelEnable, 0);
    p.setParameter(kParam_WetLevel, TVScaling::SquareToNorm(1, TVScaling::kMinGainLinear, TVScaling::kMaxGainLinear));
}
void render(TVerbPluginWrapper& p, Stereo& x, int block = 256, bool accumulating = false) {
    for (int start = 0; start < int(x.l.size()); start += block) {
        const int n = std::min<int>(block, int(x.l.size()) - start);
        float* io[2] = {x.l.data() + start, x.r.data() + start};
        if (accumulating) {
            std::vector<float> l(n), r(n); float* out[2] = {l.data(), r.data()};
            p.processAccumulating(io, out, n);
            std::copy(l.begin(), l.end(), x.l.begin() + start);
            std::copy(r.begin(), r.end(), x.r.begin() + start);
        } else p.processReplacing(io, io, n);
    }
}
double difference(const Stereo& a, const Stereo& b) {
    double e = 0;
    for (size_t i = 0; i < a.l.size(); ++i)
        e = std::max({e, std::abs(double(a.l[i]) - b.l[i]), std::abs(double(a.r[i]) - b.r[i])});
    return e;
}
void colorTests() {
    for (int sr : {22050, 44100, 96000}) {
        for (int f : {320, 10000}) {
            double previous = 0;
            for (double amount : {0.0, 0.35, 1.0}) {
                WarmthTone<double> tone; tone.prepare(sr);
                double a = 0, b = 0, neutralError = 0;
                for (int i = 0; i < sr; ++i) {
                    const double x = .2 * std::sin(2 * M_PI * f * i / sr);
                    const double y = tone.process(x, 0, amount);
                    if (amount == 0) neutralError = std::max(neutralError, std::abs(y - x));
                    if (i > sr / 2) { a += x * x; b += y * y; }
                }
                const double db = 10 * std::log10(b / a);
                const auto tag = std::to_string(sr) + "_" + std::to_string(f) + "_" + std::to_string(amount);
                check(std::isfinite(db), "warmth_finite_" + tag, db);
                if (amount == 0) check(neutralError == 0, "warmth_zero_exact_" + tag, neutralError);
                else check(f == 320 ? db > previous : db < previous, "warmth_monotonic_" + tag, db);
                if (amount == 1) check(f == 320 ? db > .8 && db < 1.1 : db < -1.5 && db > -2.1,
                                      "warmth_gentle_range_" + tag, db);
                previous = db;
            }
        }
    }
}
void independentLevels() {
    for (int quality : {0, 1, 2}) {
        TVerbPluginWrapper full(48000, 256), early(48000, 256), late(48000, 256), earlyWarm(48000, 256);
        for (auto* p : {&full, &early, &late, &earlyWarm}) { wet(*p); p->setParameter(kParam_Quality, quality / 2.f); }
        early.setParameter(kParam_LateLevel, 0);
        earlyWarm.setParameter(kParam_LateLevel, 0); earlyWarm.setParameter(kParam_Warmth, 1);
        late.setParameter(kParam_EarlyLevel, 0);
        auto a = input(48000), b = a, c = a, d = a;
        render(full, a); render(early, b); render(late, c); render(earlyWarm, d);
        double err = 0, earlyEnergy = 0, lateEnergy = 0;
        for (size_t i = 0; i < a.l.size(); ++i) {
            err = std::max({err, std::abs(double(a.l[i]) - b.l[i] - c.l[i]), std::abs(double(a.r[i]) - b.r[i] - c.r[i])});
            earlyEnergy += double(b.l[i]) * b.l[i]; lateEnergy += double(c.l[i]) * c.l[i];
        }
        check(err < 2e-6 && earlyEnergy > .01 && lateEnergy > .01, "independent_early_plus_late_q" + std::to_string(quality), err);
        check(difference(b, d) == 0, "warmth_does_not_color_early_q" + std::to_string(quality), difference(b, d));
    }
}
void finiteInputTests() {
    for (bool accumulating : {false, true}) for (float bad : {std::numeric_limits<float>::quiet_NaN(),
            std::numeric_limits<float>::infinity(), -std::numeric_limits<float>::infinity()}) {
        TVerbPluginWrapper reference(48000, 128), damaged(48000, 128);
        wet(reference); wet(damaged);
        reference.setParameter(kParam_Warmth, .35f); damaged.setParameter(kParam_Warmth, .35f);
        auto clean = input(48000), faulty = clean;
        clean.l[24000] = clean.r[24000] = 0;
        faulty.l[24000] = faulty.r[24000] = bad;
        render(reference, clean, 128, accumulating); render(damaged, faulty, 128, accumulating);
        bool finite = true; double energy = 0;
        for (size_t i = 0; i < faulty.l.size(); ++i) {
            finite &= std::isfinite(faulty.l[i]) && std::isfinite(faulty.r[i]);
            if (i > 48000) energy += double(faulty.l[i]) * faulty.l[i];
        }
        check(finite && difference(clean, faulty) == 0 && energy > .01,
              "nonfinite_input_equals_zero_without_erasing_tail_" + std::to_string(checks), difference(clean, faulty));
    }
    TVerbPluginWrapper p;
    bool unchanged = true;
    for (int id = 0; id < kNumVstParameters; ++id) {
        const float before = p.getParameter(id);
        p.setParameter(id, std::numeric_limits<float>::quiet_NaN());
        p.setParameter(id, std::numeric_limits<float>::infinity());
        unchanged &= p.getParameter(id) == before;
    }
    check(unchanged, "nonfinite_parameters_leave_last_good_values");
}
void dryAndSmoothingTests() {
    TVerbPluginWrapper p(48000, 128);
    p.setParameter(kParam_WetLevelEnable, 0); p.setParameter(kParam_DryLevelEnable, 1);
    p.setParameter(kParam_DryLevel, TVScaling::SquareToNorm(1, TVScaling::kMinGainLinear, TVScaling::kMaxGainLinear));
    p.setParameter(kParam_Warmth, 1);
    auto dry = input(48000), result = dry;
    render(p, result);
    check(difference(dry, result) < 1e-7, "warmth_preserves_dry_path", difference(dry, result));
    p.setParameter(kParam_DryLevelEnable, 0);
    std::vector<float> l(1600, .5f), r = l; float* io[2] = {l.data(), r.data()};
    p.processReplacing(io, io, 1600);
    double increase = 0;
    for (int i = 1; i < 1600; ++i) increase = std::max(increase, double(l[i] - l[i - 1]));
    check(l[0] > .49f && l[1500] == 0 && increase < 1e-7, "dry_toggle_fades_in_30ms", l[0]);
}
Stereo automated(bool variable) {
    TVerbPluginWrapper p(48000, 128); wet(p);
    auto x = input(48000);
    const int sizes[] = {1, 7, 64, 511, 23, 2048};
    int start = 0, step = 0;
    while (start < int(x.l.size())) {
        if (start == 12000) p.setParameter(kParam_Warmth, .65f);
        if (start == 24000) p.setParameter(kParam_LateLevel, TVScaling::LinearToNorm(-5, -60, 6));
        if (start == 36000) p.setParameter(kParam_EarlyLevel, TVScaling::LinearToNorm(-7, -60, 6));
        const int nextEvent = start < 12000 ? 12000 : start < 24000 ? 24000 : start < 36000 ? 36000 : int(x.l.size());
        const int n = std::min(nextEvent - start, variable ? sizes[step++ % 6] : 128);
        float* io[2] = {x.l.data() + start, x.r.data() + start}; p.processReplacing(io, io, n);
        start += n;
    }
    return x;
}
void transitionTests() {
    for (int parameter : {kParam_RevType, kParam_Quality}) {
        TVerbPluginWrapper p(48000, 128), reference(48000, 128);
        wet(p); wet(reference);
        auto a = input(48000, 1), b = a; render(p, a); render(reference, b);
        p.setParameter(parameter, parameter == kParam_RevType ? 2.f / 12.f : 1.f);
        std::vector<float> l(128), r(128), rl(128), rr(128);
        float* io[2] = {l.data(), r.data()}; float* ref[2] = {rl.data(), rr.data()};
        bool adopted = false;
        double err = 0, peak = 0;
        for (int attempt = 0; attempt < 2000; ++attempt) {
            std::fill(l.begin(), l.end(), 0); std::fill(r.begin(), r.end(), 0);
            std::fill(rl.begin(), rl.end(), 0); std::fill(rr.begin(), rr.end(), 0);
            p.processReplacing(io, io, 128); reference.processReplacing(ref, ref, 128);
            const int applied = parameter == kParam_RevType ? p.getReverbEngine()->get_Type() : p.getReverbEngine()->get_Quality();
            if (applied == 2) {
                adopted = true;
                for (int i = 0; i < 16; ++i) {
                    peak = std::max({peak, std::abs(double(rl[i])), std::abs(double(rr[i]))});
                    err = std::max({err, std::abs(double(l[i]) - rl[i]), std::abs(double(r[i]) - rr[i])});
                }
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        check(adopted && peak > 1e-5 && err < peak * .005,
              "async_configuration_crossfade_preserves_initial_tail_" + std::to_string(parameter), peak ? err / peak : 1);
        p.setParameter(parameter, parameter == kParam_RevType ? 7.f / 12.f : 0.f);
        bool finite = true;
        for (int k = 0; k < 1200; ++k) {
            if (k < 30) p.setParameter(kParam_Warmth, (k % 8) / 8.f);
            std::fill(l.begin(), l.end(), 0); std::fill(r.begin(), r.end(), 0);
            p.processReplacing(io, io, 128);
            for (int i = 0; i < 128; ++i) finite &= std::isfinite(l[i]) && std::isfinite(r[i]);
            if (!p.hasPendingConfiguration()) break;
            std::this_thread::sleep_for(std::chrono::milliseconds(1));
        }
        const int applied = parameter == kParam_RevType ? p.getReverbEngine()->get_Type() : p.getReverbEngine()->get_Quality();
        check(finite && !p.hasPendingConfiguration() && applied == (parameter == kParam_RevType ? 7 : 0),
              "queued_configuration_applies_latest_request_" + std::to_string(parameter), applied);
    }
}
int main() {
    static_assert(kParam_BitDepth == 24 && kParam_Warmth == 25 && kNumVstParameters == 28, "Retain legacy DSP IDs");
    colorTests(); independentLevels(); finiteInputTests(); dryAndSmoothingTests();
    const auto fixed = automated(false), variable = automated(true);
    const double error = difference(fixed, variable);
    check(error < 1e-6, "automated_new_controls_are_block_partition_invariant", error);
    transitionTests();
    {
        TVerbPluginWrapper p(48000,64);
        p.beginProcessingBlock(false);
        p.setParameter(kParam_RevType,2.f/12.f);
        float l[64]{},r[64]{};float* io[2]{l,r};
        p.processReplacing(io,io,64);
        check(p.getReverbEngine()->get_Type()==0 && p.hasPendingConfiguration(),
              "first_live_buffer_defers_late_geometry_updates");
    }
    bool lifecycle = true;
    for (int i = 0; i < 10; ++i) {
        TVerbPluginWrapper p(48000, 64);
        float l[64]{}, r[64]{}; float* io[2]{l, r};
        p.processReplacing(io, io, 64);
        p.setParameter(kParam_RevType, 2.f/12.f);
        p.processReplacing(io, io, 64);
        p.suspend();
        lifecycle &= p.getReverbEngine()->get_Type() == 2;
        p.setSampleRateAndBlockSize(96000, 128);
        lifecycle &= p.getReverbEngine()->get_SampleRate() == 96000;
    }
    check(lifecycle, "stop_prepare_and_destroy_with_configuration_in_flight");
    auto offlineRender = [] {
        TVerbPluginWrapper p(48000, 128); wet(p); p.setNonRealtimeProcessing(true);
        auto x = input(48000);
        for (int start = 0; start < int(x.l.size()); start += 128) {
            if (start == 12032) p.setParameter(kParam_RevType, 2.f/12.f);
            if (start == 24064) p.setParameter(kParam_Quality, 1.f);
            const int n=std::min(128,int(x.l.size())-start);
            float* io[2] = {x.l.data()+start,x.r.data()+start};
            p.processReplacing(io,io,n);
        }
        return x;
    };
    const auto offlineA=offlineRender(), offlineB=offlineRender();
    check(difference(offlineA,offlineB)==0, "offline_configuration_automation_is_repeatable", difference(offlineA,offlineB));
    std::cout << "TOTAL " << checks << " FAILED " << failures << std::endl;
    return failures ? 1 : 0;
}
