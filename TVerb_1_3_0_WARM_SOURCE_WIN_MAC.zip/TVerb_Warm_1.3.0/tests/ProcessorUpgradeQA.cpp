#include "VerbProcessor.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include <iostream>
#include <limits>

int failures = 0, checks = 0;
void check(bool ok, const char* name) {
    ++checks; if (!ok) ++failures;
    std::cout << (ok ? "PASS " : "FAIL ") << name << std::endl;
}
void saveTree(const juce::ValueTree& state, juce::MemoryBlock& block) {
    auto xml = state.createXml();
    juce::AudioProcessor::copyXmlToBinary(*xml, block);
}
int main(int argc, char** argv) {
    juce::ScopedJuceInitialiser_GUI gui;
    tverb::Processor p;
    p.prepareToPlay(48000, 256);
    const auto& parameters = p.getParameters();
    check(parameters.size() == 29, "29_host_parameters_including_existing_bypass");
    auto id = [&](int index) { return dynamic_cast<juce::AudioProcessorParameterWithID*>(parameters[index])->paramID; };
    check(id(24) == "bitdepth" && id(25) == "bypass" && id(26) == "warmth" && id(28) == "latelevel",
          "legacy_host_order_and_appended_controls");
    const auto set = [&](const char* key, float value) {
        auto* parameter = p.apvts.getParameter(key);
        parameter->setValueNotifyingHost(parameter->convertTo0to1(value));
    };
    set("warmth", 35); set("earlylevel", -1); set("latelevel", 2);
    juce::MemoryBlock warmState; p.getStateInformation(warmState);
    set("warmth", 0); set("earlylevel", 0); set("latelevel", 0);
    p.setStateInformation(warmState.getData(), int(warmState.getSize()));
    check(std::abs(p.param("warmth") - 35) < .001 && std::abs(p.param("earlylevel") + 1) < .001
          && std::abs(p.param("latelevel") - 2) < .001, "new_controls_state_roundtrip");
    auto old = p.apvts.copyState();
    for (int i = old.getNumChildren(); --i >= 0;) {
        const auto key = old.getChild(i).getProperty("id").toString();
        if (key == "warmth" || key == "earlylevel" || key == "latelevel") old.removeChild(i, nullptr);
    }
    juce::MemoryBlock oldState; saveTree(old, oldState);
    p.setStateInformation(oldState.getData(), int(oldState.getSize()));
    check(p.param("warmth") == 0 && std::abs(p.param("earlylevel")) < .0001f
          && std::abs(p.param("latelevel")) < .0001f, "old_state_restores_neutral_over_warm_preset");
    const int warmIndex = p.getNumPrograms() - 3;
    p.setCurrentProgram(warmIndex);
    check(std::abs(p.param("warmth") - 35) < .001 && p.param("dryon") == 0 && p.param("weton") == 1,
          "warm_aux_preset_loads_real_controls_and_mutes_dry");
    p.setCurrentProgram(0);
    check(p.param("warmth") == 0 && std::abs(p.param("earlylevel")) < .0001f,
          "old_preset_resets_new_controls");
    const float before = p.param("decay");
    const char invalid[] = "not a saved plugin state";
    p.setStateInformation(invalid, sizeof(invalid));
    check(p.param("decay") == before, "invalid_state_ignored");
    p.setCurrentProgram(warmIndex);
    p.setNonRealtime(true);
    juce::AudioBuffer<float> audio(2,256); audio.clear();
    audio.setSample(0,10,std::numeric_limits<float>::quiet_NaN());
    audio.setSample(1,20,std::numeric_limits<float>::infinity());
    juce::MidiBuffer midi;
    p.processBlock(audio,midi);
    check(std::abs(p.getWrapper().getParameter(tverbdsp::kParam_Warmth)-.35f)<.0001f
          && p.getWrapper().getReverbEngine()->get_Type()==2,
          "host_controls_reach_engine_in_real_processBlock");
    bool finite=true;
    for(int c=0;c<2;++c)for(int i=0;i<audio.getNumSamples();++i)
        finite &= std::isfinite(audio.getSample(c,i));
    check(finite,"processor_and_bypass_sanitize_nonfinite_input");
    if (argc > 1) {
        p.setCurrentProgram(warmIndex);
        auto editor = std::unique_ptr<juce::AudioProcessorEditor>(p.createEditor());
        editor->setSize(1040, 866);
        auto image = editor->createComponentSnapshot(editor->getLocalBounds());
        juce::File destination(juce::String::fromUTF8(argv[1]));
        auto output = destination.createOutputStream();
        if (output) { output->setPosition(0); output->truncate(); }
        juce::PNGImageFormat png;
        check(output && png.writeImageToStream(image, *output), "editor_png_rendered");
    }
    p.releaseResources();
    std::cout << "TOTAL " << checks << " FAILED " << failures << std::endl;
    return failures ? 1 : 0;
}
