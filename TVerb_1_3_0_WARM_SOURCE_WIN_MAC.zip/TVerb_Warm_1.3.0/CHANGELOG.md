# 1.3.0

- Add a smooth, late-only Warmth control and independent Early/Late trims.
- Append three warm vocal presets; retain existing preset and host parameter ordering.
- Restore neutral new controls when loading legacy state.
- Ramp Dry/Wet gains, enable changes and new controls over 30 ms.
- Prepare Room Type/Quality changes and reset the spare tank on a background worker; crossfade ready configurations for 150 ms.
- Queue the latest configuration, serialize worker ownership with lock-free state and join the worker at lifecycle boundaries.
- Make offline configuration changes repeatable for the same block/event schedule.
- Sanitize nonfinite input before bypass, meters and DSP; recover from nonfinite tank output.
- Use atomic spectrum/UI sample rate handoffs.
- Remove reconstruction/offset comments without removing processing code or tables.
- Supply a self-contained JUCE project, Windows/macOS build scripts and validation material.
