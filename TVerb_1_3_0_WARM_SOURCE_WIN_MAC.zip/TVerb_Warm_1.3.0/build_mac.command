#!/bin/bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
if ! command -v cmake >/dev/null; then
  echo "Install CMake 3.22+ and Xcode command line tools first."
  exit 1
fi
cmake -S . -B build-mac -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build-mac --config Release --parallel 2
ctest --test-dir build-mac -C Release --output-on-failure
cmake --install build-mac --config Release --component Plugins --prefix "$PWD/dist"
echo "Done: dist/VST3 and dist/Components"
open "$PWD/dist"
