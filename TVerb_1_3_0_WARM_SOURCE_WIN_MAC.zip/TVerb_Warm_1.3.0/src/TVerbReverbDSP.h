#pragma once
#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <cstring>
#include <cstdint>
#include <cstdlib>
#include <vector>
#include <memory>
#include <algorithm>
#include "TVerbTables.h"
#include "TVerbSubComponents.h"
#include "TVerbEnhancements.h"

namespace tverbdsp {

// ============================================================================
                                                                           
// ============================================================================
enum BitDepth_t : int {
    kBitDepth_32BitFloat  = 0, // CReverb<float>
    kBitDepth_64BitDouble = 1  // CReverb<double>
};

enum Quality_t : int {
    kQuality_Low    = 0,                                                 
    kQuality_Normal = 1,                                                 
    kQuality_High   = 2                                                  
};

// ============================================================================
// CReverbBase — Abstract Dual-Precision Reverb Engine Interface
                                                                                        
// ============================================================================
class CReverbBase {
public:
    virtual ~CReverbBase() = default;

                                                              
    static bool CreateAndInit(CReverbBase** ppOutReverb, float sampleRate, long blockSize, int quality, BitDepth_t bitDepth);
    static bool ChangeBitDepth(CReverbBase** ppInOutReverb, BitDepth_t newBitDepth);

                                                                             
    virtual void       DoReverb(float** inputs, float** outputs, long sampleFrames, bool replacing) = 0;
    virtual void       DoSilence(float** inputs, float** outputs, long sampleFrames, bool replacing) = 0;
    virtual void       set_DecayInSec(float decaySec) = 0;
    virtual void       set_DryLevel(float dryLinear) = 0;
    virtual void       set_WetLevel(float wetLinear) = 0;
    virtual void       set_Type(int type) = 0;
    virtual void       set_Warmth(float amount) = 0;
    virtual void       set_EarlyLevel(float gain) = 0;
    virtual void       set_LateLevel(float gain) = 0;
    virtual void       set_Damping(float lowFreq, float highFreq, float lowRatio, float midRatio, float highRatio) = 0;
    virtual void       set_RoomSize(float roomSizeNorm) = 0;
    virtual void       set_Attack(float attackNorm) = 0;
    virtual void       set_Spread(float spreadNorm) = 0;
    virtual void       set_Diffusion(float diffusionNorm) = 0;
    virtual void       set_Density(float densityNorm) = 0;
    virtual void       set_Echo(float echoIntensityNorm, float echoSizeMs) = 0;
    virtual void       set_Predelay(float predelayMs) = 0;
    virtual void       set_RoomWidth(float widthNorm) = 0;
    virtual void       set_Modulation(float modNorm) = 0;
    virtual void       set_PostEQFreq(float loCutHz, float hiCutHz) = 0;
    virtual void       get_PostEQFreq(float* outLoCutHz, float* outHiCutHz) const = 0;
    virtual void       set_PostEQOnOff(bool loCutOn, bool hiCutOn) = 0;
    virtual void       set_Quality(int quality) = 0;
    virtual void       set_DryLevelEnable(bool enable) = 0;
    virtual void       set_WetLevelEnable(bool enable) = 0;
    virtual void       set_SampleRate(float hostSampleRate) = 0;
    virtual void       set_BlockSize(long hostBlockSize) = 0;
    virtual float      get_SampleRate() const = 0;
    virtual long       get_BlockSize() const = 0;
    virtual int        get_Quality() const = 0;
    virtual void       suspend() = 0;
    virtual void       beginConfiguration() = 0;
    virtual void       endConfiguration() = 0;
    virtual int        get_Type() const = 0;
    virtual BitDepth_t get_bitDepth() const = 0;
    virtual void       get_Reflections(ReflectionStruct* outRefl) const = 0;
    virtual bool       ConstructorSucceded() = 0;
};

// ============================================================================
                                                                                   
                                                                                               
// ============================================================================
template <typename T>
class CReverb final : public CReverbBase {
public:
    static constexpr int kMaxCombsPerChannel     = 40;  
    static constexpr int kMaxAllpassesPerChannel = 40;  
    static constexpr int kCombInputRingSize      = CComb<T>::kSharedRingBufSize; // up to 57,600 samples

    CReverb();
    ~CReverb() override;

    void       DoReverb(float** inputs, float** outputs, long sampleFrames, bool replacing) override;
    void       DoSilence(float** inputs, float** outputs, long sampleFrames, bool replacing) override;
    void       set_DecayInSec(float decaySec) override;
    void       set_DryLevel(float dryLinear) override;
    void       set_WetLevel(float wetLinear) override;
    void       set_Type(int type) override;
    void       set_Warmth(float amount) override;
    void       set_EarlyLevel(float gain) override;
    void       set_LateLevel(float gain) override;
    void       set_Damping(float lowFreq, float highFreq, float lowRatio, float midRatio, float highRatio) override;
    void       set_RoomSize(float roomSizeNorm) override;
    void       set_Attack(float attackNorm) override;
    void       set_Spread(float spreadNorm) override;
    void       set_Diffusion(float diffusionNorm) override;
    void       set_Density(float densityNorm) override;
    void       set_Echo(float echoIntensityNorm, float echoSizeMs) override;
    void       set_Predelay(float predelayMs) override;
    void       set_RoomWidth(float widthNorm) override;
    void       set_Modulation(float modNorm) override;
    void       set_PostEQFreq(float loCutHz, float hiCutHz) override;
    void       get_PostEQFreq(float* outLoCutHz, float* outHiCutHz) const override;
    void       set_PostEQOnOff(bool loCutOn, bool hiCutOn) override;
    void       set_Quality(int quality) override;
    void       set_DryLevelEnable(bool enable) override;
    void       set_WetLevelEnable(bool enable) override;
    void       set_SampleRate(float hostSampleRate) override;
    void       set_BlockSize(long hostBlockSize) override;
    float      get_SampleRate() const override { return static_cast<float>(m_fHostSampleRate); }
    long       get_BlockSize() const override  { return m_nHostBlockSize; }
    int        get_Quality() const override    { return m_nQuality; }
    void       suspend() override;
    void       beginConfiguration() override { m_DeferringReset = true; m_HasProcessed = false; }
    void       endConfiguration() override { m_DeferringReset = false; ResetBuffer(); }
    int        get_Type() const override { return m_nType; }
    BitDepth_t get_bitDepth() const override;
    void       get_Reflections(ReflectionStruct* outRefl) const override;
    bool       ConstructorSucceded() override  { return m_bConstructorSucceeded; }

    void       CalcParams(int mode);
    void       ResetBuffer();

private:
    void AllocateWorkBuffers();
    void SnapControls() noexcept;
    ControlRamp m_DryRamp{0}, m_WetRamp{1}, m_WarmthRamp{0};
    ControlRamp m_EarlyRamp{1}, m_LateRamp{1};
    WarmthTone<T> m_WarmthTone;
    bool m_HasProcessed = false;
    bool m_DeferringReset = false;

    // Single-owner DSP: prepare, setters, process and suspend must be serialized
    // by the host/processor. Never read or mutate this engine from the UI thread.

     
    std::vector<T> m_BufInL;        
    std::vector<T> m_BufInR;        
    std::vector<T> m_BufLateL;      
    std::vector<T> m_BufLateR;      
    std::vector<T> m_BufEarlyL;     
    std::vector<T> m_BufEarlyR;     
    std::vector<float> m_DryCopyL;
    std::vector<float> m_DryCopyR;

     
    T  m_CombInputRingL[kCombInputRingSize];  
    T  m_CombInputRingR[kCombInputRingSize];  
    T* m_pCombRingWriteL;                     
    T* m_pCombRingWriteR;                     
    int m_nActiveCombRingSize;                

    // DSP sub-modules
    CSampleRateConvert<T> m_ResamplerInL;     
    CSampleRateConvert<T> m_ResamplerInR;     
    CSampleRateConvert<T> m_ResamplerOutL;    
    CSampleRateConvert<T> m_ResamplerOutR;    
    CDelay<T>             m_PreDelayL;        
    CDelay<T>             m_PreDelayR;        
    CComb<T>              m_Combs[kMaxCombsPerChannel * 2];        
    CAllpass<T>           m_Allpasses[kMaxAllpassesPerChannel * 2]; 
    CPattern<T>           m_Pattern;          
    CStereoModDelay<T>    m_ModDelay1;        
    CStereoModDelay<T>    m_ModDelay2;        
    CBiQuad<T>            m_PostEqHiCutL;     
    CBiQuad<T>            m_PostEqLoCutL;     
    CBiQuad<T>            m_PostEqHiCutR;     
    CBiQuad<T>            m_PostEqLoCutR;     

     
    int    m_nCombs;                  
    double m_fCombDelayMaxMs;         
    double m_fCombDelayRatio;         
    int    m_nAllpasses;              
    double m_fAllpassDelayMaxMs;      
    double m_fAllpassDelayRatio;                              
    double m_fLowRatio;               
    double m_fMidRatio;               
    double m_fHighRatio;              
    double m_fCombGainLow;            
    double m_fCombGainMid;            
    double m_fCombGainHigh;           
    double m_fLowCrossoverCoeff;      
    double m_fHighCrossoverCoeff;     
    double m_fLowCrossoverHz;
    double m_fHighCrossoverHz;
    double m_fTypeGain;               
    double m_fDecayInSec;             
    double m_fDiffusion;              
    double m_fDensity;                
    double m_fWidthCrossGain;         
    double m_fWidthCombCorr;          
    double m_fRoomWidth;              
    double m_fModulation;             
    double m_fRoomSize;               
    double m_fPredelayMs;             
    double m_fEchoIntensity;          
    double m_fEchoSizeMs;             
    int    m_nType;                   
    int    m_nQuality;                
    double m_fAttack;                 
    double m_fSpread;                 
    long   m_nHostBlockSize;          
    long   m_nInternalBlockSize;
    double m_fDspSampleRate;          
    double m_fHostSampleRate;         
    float  m_fWetLevel;               
    float  m_fDryLevel;               
    bool   m_bDryLevelEnable;         
    bool   m_bWetLevelEnable;         
    double m_fEarlyGain;              
    double m_fOverallCombGain;        
    double m_fLateGain;               
    double m_fLoCutHz;                
    double m_fHiCutHz;                
    bool   m_bLoCutOn;                
    bool   m_bHiCutOn;                
    bool   m_bConstructorSucceeded;   
    T      m_fPreEmphasisStateL;      
    T      m_fPreEmphasisStateR;      
};

}                          
