#pragma once
#include <juce_core/juce_core.h>
#include <cmath>

namespace tverb { namespace orbit {
    inline juce::String display (const juce::String& id, float v)
    {
        if (id == "decay") return juce::String (v, 3) + " s";
        if (id == "predelay" || id == "echosize") return juce::String (juce::roundToInt (v)) + " ms";
        if (id == "size") return juce::String (v, 1) + " mtr";
        if (id == "width") return juce::String (juce::roundToInt (v)) + juce::String::fromUTF8 ("\xc2\xb0");
        if (id == "dry" || id == "wet") return v <= -95.5f ? "-oo dB" : juce::String (v, 2) + " dB";
        if (id == "earlylevel" || id == "latelevel") return v <= -59.99f ? "mute" : juce::String(v, 2) + " dB";
        if (id == "loratio" || id == "midratio" || id == "hiratio") return juce::String (v, 2) + " x";
        if (id == "locut" && v <= 21.0f) return "off";
        if (id == "hicut" && v >= 19999.0f) return "off";
        if (id == "locut" || id == "hicut" || id == "crosslo" || id == "crosshi")
            return v >= 1000.0f ? juce::String (v / 1000.0f, 2) + " kHz"
                               : juce::String (juce::roundToInt (v)) + " Hz";
        if ((id == "mod" || id == "echoint") && v < 0.5f) return "off";
        return juce::String (juce::roundToInt (v)) + " %";
    }

    inline float freqToNorm (float f) { return std::log (juce::jlimit (20.0f, 20000.0f, f) / 20) / std::log (1000.0f); }
    inline float normToFreq (float n) { return 20 * std::pow (1000.0f, juce::jlimit (0.0f, 1.0f, n)); }
    inline float ratioToNorm (float r) { return std::log (juce::jlimit (0.05f, 5.0f, r) / 0.05f) / std::log (100.0f); }
    inline float normToRatio (float n) { return 0.05f * std::pow (100.0f, juce::jlimit (0.0f, 1.0f, n)); }
}}
