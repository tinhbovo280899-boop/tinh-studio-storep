#pragma once
#include "HwKit.h"
#include "VerbProcessor.h"
#include "TVerbPanelStyle.h"

// T-Verb 1.3.0: two displays, TIME / ROOM design, Warmth and Early/Late controls.
// The frequency display also shows the reverb output as LED spectrum columns.
namespace tverb
{
namespace hw
{
using namespace thw;
inline String hz (float f) { return f >= 1000.0f ? String (f / 1000.0f, f >= 10000.0f ? 1 : 2) + " kHz" : String (juce::roundToInt (f)) + " Hz"; }

class Editor final : public thw::Editor
{
public:
    explicit Editor (Processor& p)
        : thw::Editor (p, p.apvts, p.getLicense(), { String("T-Verb"), "Spatial reverb", 1040, 866, "tverb", { "T-Verb" } }), proc (p)
    {
        section(24, 322, 492, 190, "TIME DESIGN");
        section(524, 322, 492, 190, "ROOM DESIGN");
        section(24, 524, 992, 112, "TAIL COLOR / BALANCE");
        section(24, 644, 992, 164, "LEVEL / DAMPING / ECHO");
        auto pct = [this] (const char* id) { return [this, id] { return String (juce::roundToInt (value (id))) + " %"; }; };
        auto ratio = [this] (const char* id) { return [this, id] { return String (value (id), 2) + "x"; }; };
        auto level = [this] (const char* id) { return [this, id] { const float v = value (id); return v <= -95.9f ? vn ("-∞ dB") : String (v, 2) + " dB"; }; };

        // ---- displays (bezel + glass are in the skin panel)
        screen (34, 98, 466, 192, [this] (juce::Graphics& g, juce::Rectangle<float> r) { paintTime (g, r); });
        auto& fs = screen (540, 98, 466, 192, [this] (juce::Graphics& g, juce::Rectangle<float> r) { paintDamping (g, r); });
        fs.onDown = [this, &fs] (const juce::MouseEvent& e) { pickDamping (fs.getLocalBounds().toFloat(), e.position); };
        fs.onDrag = [this, &fs] (const juce::MouseEvent& e) { dragDamping (fs.getLocalBounds().toFloat(), e.position, e.mods.isShiftDown()); };
        fs.onUp = [this] (const juce::MouseEvent&) { if (dragId.isNotEmpty()) param (dragId)->endChangeGesture(); dragId = {}; };

        // ---- TIME DESIGN
        dial ("decay", 92, 410, 40, "DECAY", "0.2", "45 s", [this] { return String (value ("decay"), 3) + " s"; });
        dial ("predelay", 206, 404, 26, "PREDELAY", "0", "1000", [this] { return String (juce::roundToInt (value ("predelay"))) + " ms"; });
        dial ("attack", 296, 404, 26, "ATTACK", "0", "100", pct ("attack"));
        dial ("spread", 386, 404, 26, "SPREAD", "0", "100", pct ("spread"));
        select ("type", 432, 396, 76, "TYPE").setBounds (432, 396, 76, 24);
        // ---- ROOM DESIGN
        dial ("size", 598, 410, 40, "ROOM SIZE", "2", "62 m", [this] { return String (value ("size"), 1) + " m"; });
        dial ("width", 716, 404, 26, "WIDTH", "-180", vn ("180°"), [this] { return String (juce::roundToInt (value ("width"))) + vn ("°"); });
        dial ("diffusion", 820, 404, 26, "DIFFUSION", "0", "100", pct ("diffusion"));
        dial ("density", 924, 404, 26, "DENSITY", "0", "100", pct ("density"));
        // ---- bottom row
        const float ky = 690;
        dial ("dry", 62, ky, 22, "DRY", vn ("-∞"), "+6", level ("dry"));
        dial ("wet", 146, ky, 22, "WET", vn ("-∞"), "+6", level ("wet"));
        dial ("locut", 242, ky, 22, "LO CUT", "off", "10k", [this] { const float f = value ("locut"); return f <= 20.5f ? String ("off") : hz (f); });
        dial ("hicut", 326, ky, 22, "HI CUT", "200", "off", [this] { const float f = value ("hicut"); return f >= 19990.0f ? String ("off") : hz (f); });
        dial ("crosslo", 418, ky, 18, vn ("LO‹›MID"), {}, {}, [this] { return hz (value ("crosslo")); }, 56);
        dial ("crosshi", 482, ky, 18, vn ("MID‹›HI"), {}, {}, [this] { return hz (value ("crosshi")); }, 56);
        dial ("loratio", 550, ky, 18, "LO RATIO", {}, {}, ratio ("loratio"), 56);
        dial ("midratio", 612, ky, 18, "MID RATIO", {}, {}, ratio ("midratio"), 56);
        dial ("hiratio", 674, ky, 18, "HI RATIO", {}, {}, ratio ("hiratio"), 56);
        dial ("echoint", 762, ky, 22, "INTENSITY", "0", "100", [this] { const float v = value ("echoint"); return v < 0.05f ? String ("off") : String (juce::roundToInt (v)) + " %"; });
        dial ("echosize", 846, ky, 22, "SIZE", "50", "750", [this] { return String (juce::roundToInt (value ("echosize"))) + " ms"; });
        dial ("mod", 960, 684, 20, "MODULATION", "off", "100", [this] { const float v = value ("mod"); return v < 0.05f ? String ("off") : String (juce::roundToInt (v)) + " %"; }, 56);
        caption ("QUALITY", 960, 768, 7.5f, 1.0f);
        select ("quality", 922, 776, 76).setBounds (922, 776, 76, 24);

        dial("warmth", 280, 544, 16, "WARMTH", "0", "100", pct("warmth"));
        dial("earlylevel", 520, 544, 16, "EARLY LEVEL", "mute", "+6", [this] {
            const float v=value("earlylevel"); return v <= -59.99f ? String("mute") : String(v, 1)+" dB";
        });
        dial("latelevel", 760, 544, 16, "LATE LEVEL", "mute", "+6", [this] {
            const float v=value("latelevel"); return v <= -59.99f ? String("mute") : String(v, 1)+" dB";
        });
        infoItem ("ENGINE", [this] { return value ("bitdepth") > 0.5f ? String ("64-BIT") : String ("32-BIT"); });
        infoItem ("OUT", [this] { return String (juce::Decibels::gainToDecibels (juce::jmax (proc.vuOutL.load(), proc.vuOutR.load()), -60.0f), 1) + " dB"; });
        finish();
    }

private:
    // knob + printed min/max + amber value window + engraved name (same geometry as the approved mock-up)
    void dial (const char* id, float cx, float cy, float R, const String& label, const String& lo, const String& hi,
               std::function<String()> fmt, float lcdW = 0.0f)
    {
        knobFor (id, cx, cy, R, 0.0f, true);
        if (lo.isNotEmpty()) caption (lo, cx - R * 0.75f - 6.0f, cy + R + 12.0f, 7.5f, 0.0f);
        if (hi.isNotEmpty()) caption (hi, cx + R * 0.75f + 6.0f, cy + R + 12.0f, 7.5f, 0.0f);
        const float w = lcdW > 0.0f ? lcdW : (R >= 30.0f ? 78.0f : 64.0f);
        valueBox (param (id), juce::Rectangle<float> (cx - w * 0.5f, cy + R + 22.0f, w, 19.0f).toNearestInt(), 12.0f, std::move (fmt));
        caption (label, cx, cy + R + 53.0f, R >= 30.0f ? 9.0f : 8.2f, 1.2f);
    }

    // ---- spectrum columns: newest 2048 output samples -> 32 log bands (message thread, 30 Hz)
    void tick() override
    {
        constexpr int order = 11, n = 1 << order;
        std::array<float, n * 2> buf {};
        proc.copySpectrumInput (buf.data(), n);
        for (int i = 0; i < n; ++i) buf[(size_t) i] *= 0.5f - 0.5f * std::cos (juce::MathConstants<float>::twoPi * (float) i / (float) (n - 1));
        fft.performFrequencyOnlyForwardTransform (buf.data(), true);
        const double fsr = juce::jmax (8000.0, proc.getSampleRateForUI());
        for (int b = 0; b < bands; ++b)
        {
            const double f0 = 20.0 * std::pow (1000.0, (double) b / bands), f1 = 20.0 * std::pow (1000.0, (double) (b + 1) / bands);
            const int i0 = juce::jlimit (1, n / 2 - 1, (int) std::floor (f0 / fsr * n)), i1 = juce::jlimit (i0, n / 2 - 1, (int) std::ceil (f1 / fsr * n));
            float m = 0.0f;
            for (int i = i0; i <= i1; ++i) m = juce::jmax (m, buf[(size_t) i]);
            const float db = juce::Decibels::gainToDecibels (m / (float) (n / 4), -100.0f);
            const float lvNow = juce::jlimit (0.0f, 1.0f, (db + 72.0f) / 66.0f);
            level[(size_t) b] = juce::jmax (lvNow, level[(size_t) b] * 0.86f);
            peak[(size_t) b] = juce::jmax (peak[(size_t) b] - 0.012f, level[(size_t) b]);
        }
    }

    // ---- time display: early reflections + decay envelope on a log time axis (0 .. 8 s), amber phosphor
    void paintTime (juce::Graphics& g, juce::Rectangle<float> r)
    {
        const float x = r.getX(), w = r.getWidth(), t0 = x + 20, base = r.getBottom() - 26, peakY = r.getY() + 26;
        auto tx = [&] (float s) { return t0 + (w - 40) * std::log10 (1.0f + juce::jlimit (0.0f, 8.0f, s) * 9.0f / 8.0f); };
        g.setColour (Colour (0xff26160a));
        for (float s : { 0.01f, 0.1f, 0.5f, 1.0f, 2.0f, 5.0f, 8.0f }) g.drawVerticalLine (juce::roundToInt (tx (s)), r.getY() + 14, base);
        for (int i = 0; i < 4; ++i) g.drawHorizontalLine (juce::roundToInt (peakY + (base - peakY) * (float) i / 3.0f), t0, r.getRight() - 20);
        const float decay = value ("decay"), pre = value ("predelay") / 1000.0f;
        const float att = value ("attack") / 100.0f * juce::jmin (decay, 2.0f) * 0.3f;
        const int ers = 8 + juce::roundToInt (value ("density") * 0.16f);
        juce::Random rnd (7);
        for (int i = 0; i < ers; ++i)
        {
            const float s = pre + 0.004f + (float) i * (0.006f + 0.01f * value ("size") / 62.0f) + rnd.nextFloat() * 0.005f;
            const float hh = (base - peakY) * (0.35f + 0.4f * rnd.nextFloat()) * std::exp (-(float) i / 16.0f);
            g.setColour (Colour (0xffe6822a)); g.fillRect (tx (s), base - hh, 1.6f, hh);
        }
        juce::Path env; const float s0 = pre + 0.005f, end = juce::jmin (8.0f, s0 + att + decay);
        env.startNewSubPath (tx (s0), base);
        env.lineTo (tx (s0 + att), peakY);
        for (float s = s0 + att; s <= end; s += 0.02f) env.lineTo (tx (s), peakY + (base - peakY) * (s - s0 - att) / juce::jmax (0.01f, decay));
        env.lineTo (tx (end), peakY + (base - peakY) * juce::jmin (1.0f, (end - s0 - att) / juce::jmax (0.01f, decay)));
        juce::Path fill (env); fill.lineTo (tx (end), base); fill.closeSubPath();
        g.setGradientFill (juce::ColourGradient (Colour (0xcc965014), 0, peakY, Colour (0x22190c04), 0, base, false));
        g.fillPath (fill);
        g.setColour (tverbstyle::amberDeep().withAlpha (0.35f)); g.strokePath (env, juce::PathStrokeType (5.0f));
        g.setColour (Colour (0xffffc46e)); g.strokePath (env, juce::PathStrokeType (1.8f));
        for (auto m : { std::pair<float, const char*> { 0.01f, "0.01" }, { 0.1f, "0.1" }, { 0.5f, "0.5" }, { 1.0f, "1" }, { 2.0f, "2" }, { 5.0f, "5" }, { 8.0f, "8 s" } })
            thw::text (g, m.second, juce::jmin (tx (m.first), r.getRight() - 20), base + 14, 8.5f, tverbstyle::amberDim(), 7);
        tverbstyle::glowText (g, font (13.0f, 8), String (decay, 3) + " s", { r.getRight() - 130, r.getY() + 10, 116, 22 }, juce::Justification::centredRight, tverbstyle::amber());
        thw::text (g, "RT60", r.getRight() - 16, r.getY() + 38, 8.0f, tverbstyle::amberDim(), 8, 1, 1.5f);
    }

    // ---- damping display: decay-time ratio per band + spectrum columns; drag nodes up/down, lines sideways
    juce::Rectangle<float> plot (juce::Rectangle<float> r) const { return r.reduced (20, 0).withTrimmedTop (10).withTrimmedBottom (28); }
    float fx (juce::Rectangle<float> r, float f) const { const auto p = plot (r); return p.getX() + p.getWidth() * std::log10 (juce::jlimit (20.0f, 20000.0f, f) / 20.0f) / 3.0f; }
    float fFromX (juce::Rectangle<float> r, float x) const { const auto p = plot (r); return 20.0f * std::pow (1000.0f, juce::jlimit (0.0f, 1.0f, (x - p.getX()) / p.getWidth())); }
    float yr (juce::Rectangle<float> r, float ratio) const { const auto p = plot (r); return juce::jlimit (p.getY() + 4, p.getBottom() - 4, p.getY() + p.getHeight() * 0.55f - std::log2 (juce::jmax (0.05f, ratio)) * 26.0f); }
    float ratioFromY (juce::Rectangle<float> r, float y) const { const auto p = plot (r); return std::pow (2.0f, (p.getY() + p.getHeight() * 0.55f - y) / 26.0f); }
    float nodeF (int i) const
    {
        const float lo = value ("crosslo"), hi = value ("crosshi");
        if (i == 0) return juce::jmax (30.0f, lo / 2.7f);
        if (i == 1) return std::sqrt (lo * juce::jmax (lo, hi));
        return juce::jmin (16000.0f, hi * 2.25f);
    }
    static const char* ratioId (int i) { return i == 0 ? "loratio" : i == 1 ? "midratio" : "hiratio"; }
    float ratioAt (float f) const
    {
        const float lo = value ("crosslo"), hi = juce::jmax (lo, value ("crosshi"));
        const float l = std::log2 (value ("loratio")), m = std::log2 (value ("midratio")), h = std::log2 (value ("hiratio"));
        auto blend = [] (float a, float b, float t) { t = juce::jlimit (0.0f, 1.0f, t); t = t * t * (3 - 2 * t); return a + (b - a) * t; };
        const float o = std::log2 (f);
        const float v = o < std::log2 (std::sqrt (lo * hi)) ? blend (l, m, (o - std::log2 (lo) + 0.4f) / 0.8f) : blend (m, h, (o - std::log2 (hi) + 0.4f) / 0.8f);
        return std::pow (2.0f, v);
    }
    void paintDamping (juce::Graphics& g, juce::Rectangle<float> r)
    {
        const auto p = plot (r);
        const float xl = fx (r, value ("crosslo")), xh = fx (r, value ("crosshi"));
        g.setColour (Colour (0xff26160a));
        for (float f : { 50.0f, 100.0f, 200.0f, 500.0f, 1000.0f, 2000.0f, 5000.0f, 10000.0f }) g.drawVerticalLine (juce::roundToInt (fx (r, f)), p.getY(), p.getBottom());
        g.setColour (Colour (0x281e1005)); g.fillRect (xl, p.getY(), juce::jmax (0.0f, xh - xl), p.getHeight());
        // LED spectrum columns (dim, behind the curve)
        const float bw = p.getWidth() / (float) bands;
        const int nseg = juce::jmax (4, (int) (p.getHeight() / 5.0f));
        for (int b = 0; b < bands; ++b)
        {
            const float bx = p.getX() + (float) b * bw + 1.5f;
            const int lit = (int) (level[(size_t) b] * 0.82f * (float) nseg);
            for (int s = 0; s < lit; ++s)
            {
                const float frac = ((float) s + 0.5f) / (float) nseg;
                g.setColour (frac < 0.6f ? Colour (0xff3a1e09) : frac < 0.85f ? Colour (0xff4e280b) : Colour (0xff64340e));
                g.fillRect (bx, p.getBottom() - 2.0f - (float) s * 5.0f - 3.2f, bw - 3.0f, 3.2f);
            }
            const int pk = (int) (peak[(size_t) b] * 0.82f * (float) nseg);
            if (pk > 0) { g.setColour (Colour (0xff96581e)); g.fillRect (bx, p.getBottom() - 2.0f - (float) pk * 5.0f - 2.0f, bw - 3.0f, 2.0f); }
        }
        g.setColour (Colour (0xff46280e)); g.drawHorizontalLine (juce::roundToInt (yr (r, 1.0f)), p.getX(), p.getRight());
        juce::Path c;
        for (int i = 0; i <= 200; ++i)
        {
            const float f = 20.0f * std::pow (1000.0f, (float) i / 200.0f), X = fx (r, f), Y = yr (r, ratioAt (f));
            if (i == 0) c.startNewSubPath (X, Y); else c.lineTo (X, Y);
        }
        g.setColour (tverbstyle::amberDeep().withAlpha (0.35f)); g.strokePath (c, juce::PathStrokeType (6.0f));
        g.setColour (Colour (0xffffbe64)); g.strokePath (c, juce::PathStrokeType (2.0f));
        for (float x : { xl, xh })
        {
            juce::Path l; l.startNewSubPath (x, p.getY()); l.lineTo (x, p.getBottom());
            juce::Path d; const float dash[] = { 3.0f, 4.0f }; juce::PathStrokeType (1.2f).createDashedStroke (d, l, dash, 2);
            g.setColour (Colour (0xffdc7828)); g.fillPath (d);
            juce::Path t; t.addTriangle (x - 6, p.getBottom() + 2, x + 6, p.getBottom() + 2, x, p.getBottom() - 6);
            g.setColour (tverbstyle::orange()); g.fillPath (t);
        }
        const char* names[] = { "LO", "MID", "HI" };
        for (int i = 0; i < 3; ++i)
        {
            const float X = fx (r, nodeF (i)), Y = yr (r, value (ratioId (i)));
            g.setColour (tverbstyle::amberDeep().withAlpha (0.4f)); g.fillEllipse (X - 8, Y - 8, 16, 16);
            g.setColour (Colour (0xffffecc8)); g.fillEllipse (X - 4.5f, Y - 4.5f, 9, 9);
            tverbstyle::glowText (g, font (9.5f, 8), String (names[i]) + " " + String (value (ratioId (i)), 2) + "x", { X - 50, Y - 27, 100, 20 }, juce::Justification::centred, tverbstyle::amber(), 0.4f);
        }
        for (auto m : { std::pair<float, const char*> { 20.0f, "20" }, { 100.0f, "100" }, { 400.0f, "400" }, { 1000.0f, "1k" }, { 4000.0f, "4k" }, { 10000.0f, "10k" }, { 20000.0f, "20k Hz" } })
            thw::text (g, m.second, juce::jmin (fx (r, m.first), r.getRight() - 24), r.getBottom() - 12, 8.5f, tverbstyle::amberDim(), 7);
    }
    void pickDamping (juce::Rectangle<float> r, juce::Point<float> pos)
    {
        dragId = {}; float best = 14.0f;
        for (int i = 0; i < 3; ++i)
        {
            const float d = pos.getDistanceFrom ({ fx (r, nodeF (i)), yr (r, value (ratioId (i))) });
            if (d < best) { best = d; dragId = ratioId (i); }
        }
        if (dragId.isEmpty())
        {
            best = 10.0f;
            for (auto id : { "crosslo", "crosshi" })
                if (std::abs (fx (r, value (id)) - pos.x) < best) { best = std::abs (fx (r, value (id)) - pos.x); dragId = id; }
        }
        if (dragId.isNotEmpty()) { param (dragId)->beginChangeGesture(); dragDamping (r, pos, false); }
    }
    void dragDamping (juce::Rectangle<float> r, juce::Point<float> pos, bool)
    {
        if (dragId.isEmpty()) return;
        auto* p = param (dragId);
        const float v = dragId.startsWith ("cross") ? fFromX (r, pos.x) : ratioFromY (r, pos.y);
        p->setValueNotifyingHost (p->convertTo0to1 (juce::jlimit (p->getNormalisableRange().start, p->getNormalisableRange().end, v)));
    }

    Processor& proc;
    String dragId;
    static constexpr int bands = 32;
    juce::dsp::FFT fft { 11 };
    std::array<float, bands> level {}, peak {};
};
}
}
