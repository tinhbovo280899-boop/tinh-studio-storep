#include "VerbProcessor.h"
#include "HwEditor.h"

juce::AudioProcessorEditor* tverb::Processor::createEditor() { return new hw::Editor (*this); }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new tverb::Processor(); }
