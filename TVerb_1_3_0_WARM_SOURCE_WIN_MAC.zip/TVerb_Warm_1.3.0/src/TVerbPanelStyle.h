#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

// Procedural display colors: no external panel image is needed.
namespace tverbstyle {
inline juce::Colour amber() { return juce::Colour(0xffffbe7d); }
inline juce::Colour amberDim() { return juce::Colour(0xff99673d); }
inline juce::Colour amberDeep() { return juce::Colour(0xffce782c); }
inline juce::Colour orange() { return juce::Colour(0xfff7b26a); }
inline void glowText(juce::Graphics& g, const juce::Font& font, const juce::String& text,
                     juce::Rectangle<float> bounds,
                     juce::Justification align = juce::Justification::centred,
                     juce::Colour color = amber(), float glow = 0.55f) {
    g.setFont(font);
    if (glow > 0) {
        g.setColour(color.withAlpha(glow * 0.25f));
        g.drawText(text, bounds.translated(0, 1), align, false);
    }
    g.setColour(color);
    g.drawText(text, bounds, align, false);
}
}
