#pragma once
#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <cmath>
#include <cstring>
#include <cstdio>
#include <string>
#include <algorithm>
#include <array>
#include <atomic>
#include <thread>
#include <mutex>
#include <condition_variable>
#include <chrono>
#include "TVerbReverbDSP.h"

namespace tverbdsp {

// ============================================================================
                                                                                           
// ============================================================================
enum TVParamID : int {
    kParam_DryLevel       = 0,  // "DryLevel",        dB,  CVstScalingSquare (1.58489e-5 .. 1.99526, def 1.0 = 0.00 dB)
    kParam_WetLevel       = 1,  // "WetLevel",        dB,  CVstScalingSquare (1.58489e-5 .. 1.99526, def 0.25 = -12.0 dB)
    kParam_RevType        = 2,  // "Rev Type",        idx, CVstScalingLinearInteger (0..12, def 0 "smooth")
    kParam_Decay          = 3,  // "Decay",           s,   CVstScalingPow(exp=2.0) (0.2 .. 45.2 s, def 1.8 s)
    kParam_RoomSize       = 4,  // "Room Size",       mtr, CVstScalingPow(exp=2.0) (2.0 .. 62.0 m, def 40.0 m)
    kParam_Diffusion      = 5,  // "Diffusion",       %,   CVstScalingLinear (0 .. 100 %, def 70 %)
    kParam_Density        = 6,  // "Density",         %,   CVstScalingLinear (0 .. 100 %, def 80 %)
    kParam_Attack         = 7,  // "Attack",          %,   CVstScalingLinear (0 .. 100 %, def 0 %)
    kParam_Spread         = 8,  // "Spread",          %,   CVstScalingLinear (0 .. 100 %, def 10 %)
    kParam_Predelay       = 9,  // "Predelay",        ms,  CVstScalingSquare (0 .. 1000 ms, def 0 ms)
    kParam_HiRatio        = 10, // "Hi Ratio",        x,   CVstScaling_DIR_Ratio (0.05 .. 5.0 x, def 0.6 x)
    kParam_MidRatio       = 11, // "Mid Ratio",       x,   CVstScaling_DIR_Ratio (0.05 .. 5.0 x, def 1.0 x)
    kParam_LoRatio        = 12, // "Lo Ratio",        x,   CVstScaling_DIR_Ratio (0.05 .. 5.0 x, def 1.0 x)
    kParam_CrossLoMid     = 13, // "Cross Lo-Mid",    Hz,  CVstScalingSquare (20 .. 5500 Hz, def 800 Hz)
    kParam_CrossMidHi     = 14, // "Cross Mid-Hi",    Hz,  CVstScalingSquare (200 .. 16000 Hz, def 4000 Hz)
    kParam_RoomWidth      = 15, // "Room Width",      deg, CVstScalingLinear (-180 .. 180, def 160)
    kParam_Modulation     = 16, // "Modulation",      %,   CVstScalingLinear (0 .. 100 %, def 10 %)
    kParam_EchoInt        = 17, // "Echo Int",        %,   CVstScalingLinear (0 .. 100 %, def 0 %)
    kParam_EchoSize       = 18, // "Echo Size",       ms,  CVstScalingLinear (50 .. 750 ms, def 400 ms)
    kParam_LoCut          = 19, // "Lo Cut",          Hz,  CVstScalingSquare (20 .. 10000 Hz, def 20 Hz = Off)
    kParam_HiCut          = 20, // "Hi Cut",          Hz,  CVstScalingSquare (200 .. 20000 Hz, def 12000 Hz)
    kParam_Quality        = 21, // "Quality",         idx, CVstScalingLinearInteger (0=lo, 1=normal, 2=ultra, def 1)
    kParam_DryLevelEnable = 22, // "DryLevel Enable", idx, CVstScalingLinearInteger (0..1, def 1)
    kParam_WetLevelEnable = 23, // "WetLevel Enable", idx, CVstScalingLinearInteger (0..1, def 1)
    kParam_BitDepth       = 24, // "BitDepth",        idx, CVstScalingLinearInteger (0=32-bit, 1=64-bit, def 1)
    kParam_Warmth         = 25, // Late-path warmth, 0..100%, neutral at 0
    kParam_EarlyLevel     = 26, // Early trim, -60..+6 dB; -60 = mute
    kParam_LateLevel      = 27, // Late trim, -60..+6 dB; -60 = mute
    kNumVstParameters     = 28
};

// ============================================================================
                                                                       
// ============================================================================
struct TVScaling {
    static constexpr float kMinGainLinear = 1.58489319e-5f;                         
    static constexpr float kMaxGainLinear = 1.99526231f;                            

     
    static float LinearFromNorm(float norm, float minVal, float maxVal) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return minVal + norm * (maxVal - minVal);
    }
    static float LinearToNorm(float val, float minVal, float maxVal) {
        if (maxVal <= minVal) return 0.0f;
        return std::clamp((val - minVal) / (maxVal - minVal), 0.0f, 1.0f);
    }

     
    static int IntFromNorm(float norm, int minVal, int maxVal) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return static_cast<int>(minVal + norm * static_cast<float>(maxVal - minVal) + 0.5f);
    }
    static float IntToNorm(int val, int minVal, int maxVal) {
        if (maxVal <= minVal) return 0.0f;
        return std::clamp(static_cast<float>(val - minVal) / static_cast<float>(maxVal - minVal), 0.0f, 1.0f);
    }

     
    static float SquareFromNorm(float norm, float minVal, float maxVal) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return minVal + (norm * norm) * (maxVal - minVal);
    }
    static float SquareToNorm(float val, float minVal, float maxVal) {
        if (maxVal <= minVal) return 0.0f;
        float r = std::clamp((val - minVal) / (maxVal - minVal), 0.0f, 1.0f);
        return std::sqrt(r);
    }

                                                                      
    static float PowFromNorm(float norm, float minVal, float maxVal, float exponent = 2.0f) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        return minVal + static_cast<float>(std::pow(static_cast<double>(norm), static_cast<double>(exponent))) * (maxVal - minVal);
    }
    static float PowToNorm(float val, float minVal, float maxVal, float exponent = 2.0f) {
        if (maxVal <= minVal || exponent <= 0.0f) return 0.0f;
        double r = std::clamp(static_cast<double>(val - minVal) / static_cast<double>(maxVal - minVal), 0.0, 1.0);
        return static_cast<float>(std::pow(r, 1.0 / static_cast<double>(exponent)));
    }

                                            
    // Piecewise quadratic curve mapping norm=0.0 -> 0.05, norm=0.5 -> 1.0, norm=1.0 -> 5.0
    static float RatioFromNorm(float norm, float minVal = 0.05f, float maxVal = 5.0f) {
        norm = std::clamp(norm, 0.0f, 1.0f);
        float span  = maxVal - minVal;
        float mid   = 0.5f;
        float midSq = mid * mid;
        float corr  = -(midSq * span + minVal - 1.0f);
        float shape = (norm <= mid) ? (norm * norm) : ((1.0f - norm) * (1.0f - norm));
        float out   = (norm * norm) * span + minVal + (shape * corr) / midSq;
        if (std::fabs(out - 1.0f) < 1e-4f) out = 1.0f;
        return std::clamp(out, minVal, maxVal);
    }

    static float RatioToNorm(float val, float minVal = 0.05f, float maxVal = 5.0f) {
        val = std::clamp(val, minVal, maxVal);
        float span  = maxVal - minVal;
        float mid   = 0.5f;
        float midSq = mid * mid;
        float corr  = -(midSq * span + minVal - 1.0f);
        if (val <= 1.0f) {
            float denom = (span * midSq + corr) / midSq;
            return std::clamp(std::sqrt(std::max(0.0f, (val - minVal) / denom)), 0.0f, 1.0f);
        } else {
            float a = (span * midSq + corr) / midSq;
            float b = (-2.0f * corr) / midSq;
            float c = (corr / midSq) + minVal - val;
            float disc = std::max(0.0f, 0.25f * b * b - a * c);
            return std::clamp((-0.5f * b + std::sqrt(disc)) / a, 0.0f, 1.0f);
        }
    }

     
    static float DbToLinearGain(float db) {
        if (db <= -95.9f) return 0.0f;
        return std::clamp(std::pow(10.0f, db / 20.0f), 0.0f, kMaxGainLinear);
    }
    static float LinearGainToDb(float lin) {
        if (lin <= kMinGainLinear * 1.01f) return -96.0f;
        return 20.0f * std::log10(lin);
    }
};

// ============================================================================
                                                                               
                                                                                
// ============================================================================
class TVerbPluginWrapper {
public:
    TVerbPluginWrapper(float sampleRate = 44100, long blockSize = 512) {
        CReverbBase* engine = nullptr;
        if (!CReverbBase::CreateAndInit(&engine, sampleRate, blockSize, kQuality_Normal, kBitDepth_64BitDouble)) throw std::bad_alloc();
        m_pReverb.reset(engine);
        engine = nullptr;
        if (!CReverbBase::CreateAndInit(&engine, sampleRate, blockSize, kQuality_Normal, kBitDepth_64BitDouble)) throw std::bad_alloc();
        m_spareReverb.reset(engine);
        prepareTransition(sampleRate, blockSize);
        InitDefaultPreset();
        UpdateAllParameters();
        startWorker();
    }
    ~TVerbPluginWrapper() {
        stopWorker();

    }
    TVerbPluginWrapper(const TVerbPluginWrapper&) = delete;
    TVerbPluginWrapper& operator=(const TVerbPluginWrapper&) = delete;

    void InitDefaultPreset() {
        m_NormParams.fill(0);
        m_NormParams[kParam_DryLevel] = 0;
        m_NormParams[kParam_WetLevel] = TVScaling::SquareToNorm(TVScaling::DbToLinearGain(.84f), TVScaling::kMinGainLinear, TVScaling::kMaxGainLinear);
        m_NormParams[kParam_Decay] = TVScaling::PowToNorm(3.506f, .2f, 45.2f);
        m_NormParams[kParam_RoomSize] = TVScaling::PowToNorm(40, 2, 62);
        m_NormParams[kParam_Diffusion] = .7f;
        m_NormParams[kParam_Density] = .8f;
        m_NormParams[kParam_Attack] = .07f;
        m_NormParams[kParam_Spread] = .1f;
        m_NormParams[kParam_Predelay] = TVScaling::SquareToNorm(70, 0, 1000);
        m_NormParams[kParam_HiRatio] = TVScaling::RatioToNorm(.6f);
        m_NormParams[kParam_MidRatio] = m_NormParams[kParam_LoRatio] = TVScaling::RatioToNorm(1);
        m_NormParams[kParam_CrossLoMid] = TVScaling::SquareToNorm(800, 20, 5500);
        m_NormParams[kParam_CrossMidHi] = TVScaling::SquareToNorm(4000, 200, 16000);
        m_NormParams[kParam_RoomWidth] = TVScaling::LinearToNorm(160, -180, 180);
        m_NormParams[kParam_Modulation] = .1f;
        m_NormParams[kParam_EchoSize] = TVScaling::LinearToNorm(400, 50, 750);
        m_NormParams[kParam_LoCut] = TVScaling::SquareToNorm(120, 20, 10000);
        m_NormParams[kParam_HiCut] = TVScaling::SquareToNorm(9819, 200, 20000);
        m_NormParams[kParam_Quality] = .5f;
        m_NormParams[kParam_DryLevelEnable] = m_NormParams[kParam_WetLevelEnable] = 1;
        m_NormParams[kParam_BitDepth] = 1;
        m_NormParams[kParam_EarlyLevel] = m_NormParams[kParam_LateLevel] = 60.f / 66.f;
    }
    float getParameter(int index) const {
        return index >= 0 && index < kNumVstParameters ? m_NormParams[index] : 0;
    }
    void HandleCrossDamping(int changedParam) {
        float lo = TVScaling::SquareFromNorm(m_NormParams[kParam_CrossLoMid], 20, 5500);
        float hi = TVScaling::SquareFromNorm(m_NormParams[kParam_CrossMidHi], 200, 16000);
        if (changedParam == kParam_CrossLoMid && lo * 1.05f > hi)
            m_NormParams[kParam_CrossMidHi] = TVScaling::SquareToNorm(std::clamp(lo * 1.05f, 200.f, 16000.f), 200, 16000);
        if (changedParam == kParam_CrossMidHi && lo * 1.05f > hi)
            m_NormParams[kParam_CrossLoMid] = TVScaling::SquareToNorm(std::clamp(hi / 1.05f, 20.f, 5500.f), 20, 5500);
    }
    void setParameter(int index, float normValue) {
        if (!m_pReverb || index < 0 || index >= kNumVstParameters || !std::isfinite(normValue)) return;
        m_NormParams[index] = std::clamp(normValue, 0.f, 1.f);
        if (index == kParam_BitDepth) { m_NormParams[index] = 1; return; }
        if (index == kParam_CrossLoMid || index == kParam_CrossMidHi) HandleCrossDamping(index);
        if (m_seenAudio && (index == kParam_RevType || index == kParam_Quality)) {
            m_pendingConfiguration = true;
            return;
        }
        applyParameter(*m_pReverb, index, m_NormParams);
    }

    // Lifecycle operations: call while host processing is stopped. They may join
    // the configuration worker and reset/resize prepared storage.
    void UpdateAllParameters() { applyAll(*m_pReverb, m_NormParams); }
    void setSampleRateAndBlockSize(float sampleRate, long blockSize) {
        stopWorker();
        for (auto* engine : {m_pReverb.get(), m_spareReverb.get()}) {
            engine->set_SampleRate(sampleRate);
            engine->set_BlockSize(blockSize);
            engine->suspend();
        }
        prepareTransition(sampleRate, blockSize);
        UpdateAllParameters();
        m_seenAudio = m_pendingConfiguration = false;
        m_transitionRemaining = 0;
        startWorker();
    }
    void suspend() {
        stopWorker();
        if (m_pendingConfiguration) UpdateAllParameters();
        m_pReverb->suspend();
        m_spareReverb->suspend();
        m_seenAudio = m_pendingConfiguration = false;
        m_transitionRemaining = 0;
        startWorker();
    }
    void setNonRealtimeProcessing(bool offline) noexcept { m_nonRealtime = offline; }
    void beginProcessingBlock(bool offline) noexcept {
        m_nonRealtime = offline;
        m_seenAudio = true;
    }
    void processReplacing(float** inputs, float** outputs, int frames) { process(inputs, outputs, frames, true); }
    void processAccumulating(float** inputs, float** outputs, int frames) { process(inputs, outputs, frames, false); }
    CReverbBase* getReverbEngine() const { return m_pReverb.get(); }

    // Audio-owner query, also useful to render hosts waiting for asynchronous
    // Room Type/Quality updates. A stopped host can suspend() to apply them now.
    bool hasPendingConfiguration() const noexcept {
        return m_pendingConfiguration || m_transitionRemaining > 0
            || m_job.load(std::memory_order_acquire) != Job::idle;
    }
private:
    using Parameters = std::array<float, kNumVstParameters>;
    enum class Job { idle, requested, working, ready, transitioning, clearRequested, clearing };
    static_assert(std::atomic<Job>::is_always_lock_free && std::atomic<bool>::is_always_lock_free, "Lock-free audio handoff required");

    static void applyParameter(CReverbBase& e, int index, const Parameters& p) {
        const float n = p[index];
        switch (index) {
        case kParam_DryLevel:
        case kParam_WetLevel: {
            const float v = TVScaling::SquareFromNorm(n, TVScaling::kMinGainLinear, TVScaling::kMaxGainLinear);
            const float gain = v <= TVScaling::kMinGainLinear * 1.01f ? 0 : v;
            if (index == kParam_DryLevel) e.set_DryLevel(gain); else e.set_WetLevel(gain);
            break;
        }
        case kParam_RevType: e.set_Type(TVScaling::IntFromNorm(n, 0, 12)); break;
        case kParam_Decay: e.set_DecayInSec(TVScaling::PowFromNorm(n, .2f, 45.2f)); break;
        case kParam_RoomSize: e.set_RoomSize(n); break;
        case kParam_Diffusion: e.set_Diffusion(n); break;
        case kParam_Density: e.set_Density(n); break;
        case kParam_Attack: e.set_Attack(n); break;
        case kParam_Spread: e.set_Spread(n); break;
        case kParam_Predelay: e.set_Predelay(TVScaling::SquareFromNorm(n, 0, 1000)); break;
        case kParam_HiRatio:
        case kParam_MidRatio:
        case kParam_LoRatio:
        case kParam_CrossLoMid:
        case kParam_CrossMidHi:
            e.set_Damping(TVScaling::SquareFromNorm(p[kParam_CrossLoMid], 20, 5500),
                TVScaling::SquareFromNorm(p[kParam_CrossMidHi], 200, 16000),
                TVScaling::RatioFromNorm(p[kParam_LoRatio]), TVScaling::RatioFromNorm(p[kParam_MidRatio]),
                TVScaling::RatioFromNorm(p[kParam_HiRatio]));
            break;
        case kParam_RoomWidth: e.set_RoomWidth(n); break;
        case kParam_Modulation: e.set_Modulation(TVScaling::LinearFromNorm(n, 0, 100) / 100); break;
        case kParam_EchoInt:
        case kParam_EchoSize:
            e.set_Echo(p[kParam_EchoInt], TVScaling::LinearFromNorm(p[kParam_EchoSize], 50, 750)); break;
        case kParam_LoCut:
        case kParam_HiCut: {
            const float lo = TVScaling::SquareFromNorm(p[kParam_LoCut], 20, 10000);
            const float hi = TVScaling::SquareFromNorm(p[kParam_HiCut], 200, 20000);
            e.set_PostEQOnOff(lo > 21, hi < 19999);
            e.set_PostEQFreq(lo, hi); break;
        }
        case kParam_Quality:
            e.set_Quality(TVScaling::IntFromNorm(n, 0, 2));
            applyParameter(e, kParam_HiRatio, p);
            applyParameter(e, kParam_LoCut, p);
            break;
        case kParam_DryLevelEnable: e.set_DryLevelEnable(n >= .5f); break;
        case kParam_WetLevelEnable: e.set_WetLevelEnable(n >= .5f); break;
        case kParam_Warmth: e.set_Warmth(n); break;
        case kParam_EarlyLevel:
        case kParam_LateLevel: {
            float db = TVScaling::LinearFromNorm(n, -60, 6);
            if (std::fabs(db) < 1e-4f) db = 0;
            const float gain = db <= -59.99f ? 0 : std::pow(10.f, db / 20);
            if (index == kParam_EarlyLevel) e.set_EarlyLevel(gain); else e.set_LateLevel(gain);
            break;
        }
        default: break;
        }
    }
    static void applyAll(CReverbBase& engine, const Parameters& values) {
        engine.beginConfiguration();
        for (int i = 0; i < kNumVstParameters; ++i)
            if (i != kParam_BitDepth) applyParameter(engine, i, values);
        engine.endConfiguration();
    }
    void prepareTransition(float sampleRate, long blockSize) {
        m_preparedBlock = std::max<long>(16, blockSize);
        m_transitionLength = std::max(1, static_cast<int>(sampleRate * .15f));
        for (auto* b : {&m_oldL, &m_oldR, &m_newL, &m_newR}) b->resize(size_t(m_preparedBlock));
    }
    void startWorker() {
        m_job.store(Job::idle, std::memory_order_release);
        m_stop.store(false, std::memory_order_release);
        m_worker = std::thread([this] {
            setConfigurationWorkerPriority();
            while (!m_stop.load(std::memory_order_acquire)) {
                const auto job = m_job.load(std::memory_order_acquire);
                if (job == Job::requested) {
                    m_job.store(Job::working, std::memory_order_release);
                    applyAll(*m_spareReverb, m_snapshot);
                    m_job.store(Job::ready, std::memory_order_release);
                    m_wake.notify_all();
                    continue;
                }
                if (job == Job::clearRequested) {
                    m_job.store(Job::clearing, std::memory_order_release);
                    m_spareReverb->suspend();
                    m_job.store(Job::idle, std::memory_order_release);
                    m_wake.notify_all();
                    continue;
                }
                std::unique_lock<std::mutex> lock(m_waitMutex);
                // Audio only publishes atomic state: it never locks, wakes or
                // joins this thread. Shutdown notification is non-realtime.
                m_wake.wait_for(lock, std::chrono::milliseconds(20), [this] {
                    const auto phase = m_job.load(std::memory_order_acquire);
                    return m_stop.load(std::memory_order_acquire) || phase == Job::requested || phase == Job::clearRequested;
                });
            }
        });
    }
    void stopWorker() noexcept {
        m_stop.store(true, std::memory_order_release);
        m_wake.notify_one();
        if (m_worker.joinable()) m_worker.join();
    }
    void queueSnapshot() noexcept {
        m_snapshot = m_NormParams;
        m_job.store(Job::requested, std::memory_order_release);
    }
    void serviceConfiguration() noexcept {
        const auto job = m_job.load(std::memory_order_acquire);
        if (job == Job::idle && m_pendingConfiguration) queueSnapshot();
        else if (job == Job::ready) {
            if (m_snapshot != m_NormParams) { queueSnapshot(); return; }
            std::swap(m_pReverb, m_spareReverb);
            m_pendingConfiguration = false;
            m_transitionRemaining = m_transitionLength;
            m_job.store(Job::transitioning, std::memory_order_release);
        }
    }
    void finishPendingOffline() {
        // Offline renders wait for the requested configuration at a deterministic
        // sample boundary. This branch is never used by live process callbacks.
        while (m_pendingConfiguration && m_transitionRemaining == 0) {
            serviceConfiguration();
            if (!m_pendingConfiguration || m_transitionRemaining > 0) break;
            m_wake.notify_all();
            std::unique_lock<std::mutex> lock(m_waitMutex);
            m_wake.wait_for(lock, std::chrono::milliseconds(50), [this] {
                const auto phase = m_job.load(std::memory_order_acquire);
                return phase == Job::ready || phase == Job::idle || m_stop.load(std::memory_order_acquire);
            });
        }
    }
    void process(float** inputs, float** outputs, int frames, bool replacing) {
        if (!inputs || !outputs || !inputs[0] || !outputs[0] || frames <= 0) return;
        for (int start = 0; start < frames;) {
            const int n = std::min<int>(int(m_preparedBlock), frames - start);
            float* in[2] = {inputs[0] + start, (inputs[1] ? inputs[1] : inputs[0]) + start};
            float* out[2] = {outputs[0] + start, (outputs[1] ? outputs[1] : outputs[0]) + start};
            if (m_nonRealtime) finishPendingOffline();
            serviceConfiguration();
            if (m_transitionRemaining > 0) {
                float* oldOutput[2] = {m_oldL.data(), m_oldR.data()};
                float* newOutput[2] = {m_newL.data(), m_newR.data()};
                m_spareReverb->DoReverb(in, oldOutput, n, true);
                m_pReverb->DoReverb(in, newOutput, n, true);
                for (int i = 0; i < n; ++i) {
                    const float mix = m_transitionRemaining > 0
                        ? 1 - float(--m_transitionRemaining) / m_transitionLength : 1;
                    for (int c = 0; c < 2; ++c) {
                        const float value = oldOutput[c][i] + (newOutput[c][i] - oldOutput[c][i]) * mix;
                        if (replacing) out[c][i] = value;
                        else out[c][i] += value;
                    }
                }
                if (m_transitionRemaining == 0) m_job.store(Job::clearRequested, std::memory_order_release);
            } else m_pReverb->DoReverb(in, out, n, replacing);
            m_seenAudio = true;
            start += n;
        }
    }
    std::unique_ptr<CReverbBase> m_pReverb, m_spareReverb;
    Parameters m_NormParams{}, m_snapshot{};
    std::vector<float> m_oldL, m_oldR, m_newL, m_newR;
    long m_preparedBlock = 512;
    int m_transitionLength = 6615, m_transitionRemaining = 0;
    bool m_seenAudio = false, m_pendingConfiguration = false, m_nonRealtime = false;
    std::atomic<Job> m_job{Job::idle};
    std::atomic<bool> m_stop{false};
    std::thread m_worker;
    std::mutex m_waitMutex;
    std::condition_variable m_wake;
};
} // namespace tverbdsp
