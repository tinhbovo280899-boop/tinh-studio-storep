#pragma once
#ifndef _USE_MATH_DEFINES
#define _USE_MATH_DEFINES
#endif
#include <cmath>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
#include <cstring>
#include <cstdint>
#include <algorithm>
#include <vector>
#include "TVerbTables.h"

namespace tverbdsp {

// ============================================================================
// Deterministic 31-bit Park-Miller BSD LCG matching macOS 10.6 SDK rand()/srand()
                                                         
// Ensures identical Comb & All-Pass delay distributions on Windows, macOS, and Linux.
// ============================================================================
class TVRandom {
public:
    static constexpr double kRandMax = 2147483647.0;           

    explicit TVRandom(uint32_t seed = 0x22) : m_State(seed ? seed : 1u) {}

    void srand(uint32_t seed) {
        m_State = seed ? seed : 1u;
    }

    // Standard macOS Libc rand() (Park-Miller minimal standard 16807 mod 2^31-1)
    int rand() {
        uint64_t prod = static_cast<uint64_t>(m_State) * 16807ULL;
        m_State = static_cast<uint32_t>((prod & 0x7fffffffULL) + (prod >> 31));
        if (m_State > 0x7fffffffU) {
            m_State -= 0x7fffffffU;
        }
        return static_cast<int>(m_State);
    }

    double nextNorm() {
        return static_cast<double>(rand()) / kRandMax;
    }

private:
    uint32_t m_State;
};

// ============================================================================
// 1. CFastSin — Coupled 2nd-Order Digital Waveguide Sinusoidal Oscillator
                                                                              
//    Uses recursion: y[n] = (2 * cos(omega)) * y[n-1] - y[n-2]
// ============================================================================
class CFastSin {
public:
    CFastSin(float sampleRate = 44100.0f, float freq = 490.0f, float startPhase = 0.0f)
        : m_fSampleRate(44100.0)
        , m_fFreq(static_cast<double>(freq))
        , m_fOmega(2.0 * M_PI * static_cast<double>(freq) / 44100.0)
        , m_fStartPhase(static_cast<double>(startPhase))
        , m_fB1(0.0)
        , m_fY0(0.0)
        , m_fY1(0.0)
        , m_fY2(0.0)
        , m_bNeedsReset(true)
    {
        SetSamplerate(sampleRate, true);
        SetFrequencyInHz(freq, true);
    }

                                                    
    void SetSamplerate(float sr, bool immediate = true) {
        if (sr > 1.0f) {
            m_fSampleRate = static_cast<double>(sr);
            m_bNeedsReset = true;
            if (immediate) {
                Update();
            }
        }
    }

                                                       
    void SetFrequencyInHz(float freq, bool immediate = true) {
        if (freq > 0.0f) {
            m_fFreq = static_cast<double>(freq);
            m_bNeedsReset = true;
            if (immediate) {
                Update();
            }
        }
    }

                                  
    void Update() {
        m_fOmega = 2.0 * M_PI * m_fFreq / m_fSampleRate;
        m_fB1    = 2.0 * std::cos(m_fOmega);
        m_fY1    = std::sin(m_fStartPhase - m_fOmega);
        m_fY2    = std::sin(m_fStartPhase - 2.0 * m_fOmega);
        m_fY0    = std::sin(m_fStartPhase);
        m_bNeedsReset = false;
    }

                                                                                        
    inline double Tick() {
        if (m_bNeedsReset) {
            Update();
        }
        m_fY0 = m_fB1 * m_fY1 - m_fY2;
        m_fY2 = m_fY1;
        // Clamp against numerical drift beyond [-1, +1]
        if (m_fY0 > 1.0) {
            m_fY1 = 1.0;
            m_fY2 = std::sin((M_PI * 0.5) - m_fOmega);
        } else if (m_fY0 < -1.0) {
            m_fY1 = -1.0;
            m_fY2 = std::sin((-M_PI * 0.5) - m_fOmega);
        } else {
            m_fY1 = m_fY0;
        }
        return m_fY0;
    }

private:
    double m_fSampleRate;  
    double m_fFreq;        
    double m_fOmega;       
    double m_fStartPhase;  
    double m_fB1;          
    double m_fY0;          
    double m_fY1;          
    double m_fY2;          
    bool   m_bNeedsReset;  
};

// ============================================================================
// 2. CDelay<T> — Circular Pre-Delay Line
                                                                               
                                                                                
// ============================================================================
template <typename T>
class CDelay {
public:
    static constexpr int kMaxDelaySamples = 110000;           

    CDelay() : m_nReadWriteIdx(0), m_nDelaySamples(0) {
        Reset();
    }

    void Reset() {
        std::fill(m_Buffer.begin(), m_Buffer.end(), static_cast<T>(0));
        m_nReadWriteIdx = 0;
    }

                                                                                                 
    void set_DelaySamples(int delaySamples) {
        delaySamples = std::clamp(delaySamples, 0, kMaxDelaySamples);
        if (delaySamples < kMaxDelaySamples) {
            std::fill(m_Buffer.begin() + delaySamples, m_Buffer.end(), static_cast<T>(0));
        }
        m_nDelaySamples = delaySamples;
        if (m_nReadWriteIdx >= std::max(1, m_nDelaySamples)) {
            m_nReadWriteIdx = 0;
        }
    }

                                                                        
    void DoDelay(T* buf, long numSamples) {
        if (numSamples <= 0 || m_nDelaySamples <= 0) return;
        const int wrapLen = m_nDelaySamples;
        for (long i = 0; i < numSamples; ++i) {
            T delayed = m_Buffer[static_cast<size_t>(m_nReadWriteIdx)];
            m_Buffer[static_cast<size_t>(m_nReadWriteIdx)] = buf[i];
            buf[i] = delayed;
            if (++m_nReadWriteIdx >= wrapLen) {
                m_nReadWriteIdx = 0;
            }
        }
    }

private:
    std::vector<T> m_Buffer = std::vector<T>(kMaxDelaySamples, static_cast<T>(0));
    int m_nReadWriteIdx;  
    int m_nDelaySamples;  
};

// ============================================================================
// 3. CBiQuad<T> — 2nd-Order Butterworth Filter with 30-Sample Clickless Crossfade
                      
                                                                          
                                                                           
                                                                 
                                
// ============================================================================
template <typename T>
class CBiQuad {
public:
    CBiQuad() {
        m_fInvSampleRate = 1.0 / 44100.0;
        m_b0 = static_cast<T>(1.0);
        m_b1 = m_b2 = m_a1 = m_a2 = static_cast<T>(0);
        m_old_b0 = static_cast<T>(1.0);
        m_old_b1 = m_old_b2 = m_old_a1 = m_old_a2 = static_cast<T>(0);
        m_bParamChanged = false;
        Reset();
    }

    void Reset() {
        m_x1 = static_cast<T>(0);
        m_x2 = static_cast<T>(0);
        m_y1 = static_cast<T>(0);
        m_y2 = static_cast<T>(0);
        m_old_y1 = static_cast<T>(0);
        m_old_y2 = static_cast<T>(0);
        m_bParamChanged = false;
        m_nCrossfadePosition = 0;
    }

    void set_SampleRate(double sr) {
        if (sr > 1.0) {
            m_fInvSampleRate = 1.0 / sr;
        }
    }

                                         
    void ParamChange() {
        if (!m_bParamChanged) {
            m_old_b0 = m_b0;
            m_old_b1 = m_b1;
            m_old_b2 = m_b2;
            m_old_a1 = m_a1;
            m_old_a2 = m_a2;
            m_old_y1 = m_y1;
            m_old_y2 = m_y2;
            m_bParamChanged = true;
            m_nCrossfadePosition = 0;
        }
    }

                                                                                   
    void set_TP2(double freq, double q_inv) {
        ParamChange();
        double maxFreq = 0.499 / m_fInvSampleRate;
        double f = std::min(freq, maxFreq);
        if (f < 5.0) f = 5.0;
        double k  = std::tan(M_PI * f * m_fInvSampleRate);
        double k2 = k * k;
        double kq = q_inv * k;
        double a0 = k2 + kq + 1.0;
        m_b0 = static_cast<T>(k2 / a0);
        m_b1 = static_cast<T>((2.0 * k2) / a0);
        m_b2 = m_b0;
        m_a1 = static_cast<T>((-2.0 * (1.0 - k2)) / a0);
        m_a2 = static_cast<T>((1.0 - kq + k2) / a0);
    }

                                                                                    
    void set_HP2(double freq, double q_inv) {
        ParamChange();
        double maxFreq = 0.499 / m_fInvSampleRate;
        double f = std::min(freq, maxFreq);
        if (f < 5.0) f = 5.0;
        double k  = std::tan(M_PI * f * m_fInvSampleRate);
        double k2 = k * k;
        double kq = q_inv * k;
        double a0 = k2 + kq + 1.0;
        m_b0 = static_cast<T>(1.0 / a0);
        m_b1 = static_cast<T>(-2.0 / a0);
        m_b2 = m_b0;
        m_a1 = static_cast<T>((-2.0 * (1.0 - k2)) / a0);
        m_a2 = static_cast<T>((1.0 - kq + k2) / a0);
    }

                                                             
    void DoBiQuad(T* buf, long numSamples) {
        if (numSamples <= 0) return;

        if ((m_y1 < static_cast<T>(1e-34) && m_y1 > static_cast<T>(-1e-34)) || std::isnan(static_cast<double>(m_y1))) {
            m_y1 = static_cast<T>(0);
        }
        if ((m_y2 < static_cast<T>(1e-34) && m_y2 > static_cast<T>(-1e-34)) || std::isnan(static_cast<double>(m_y2))) {
            m_y2 = static_cast<T>(0);
        }

        long idx = 0;
        if (m_bParamChanged) {
            long xfadeLen = std::min<long>(numSamples, 30 - m_nCrossfadePosition);
            const T inv30 = static_cast<T>(1.0 / 30.0);
            for (; idx < xfadeLen; ++idx) {
                T x0 = buf[idx];
                T yNew = m_b0 * x0 + m_b1 * m_x1 + m_b2 * m_x2 - m_a1 * m_y1 - m_a2 * m_y2;
                m_y2 = m_y1;
                m_y1 = yNew;

                T yOld = m_old_b0 * x0 + m_old_b1 * m_x1 + m_old_b2 * m_x2 - m_old_a1 * m_old_y1 - m_old_a2 * m_old_y2;
                m_old_y2 = m_old_y1;
                m_old_y1 = yOld;

                m_x2 = m_x1;
                m_x1 = x0;

                T alpha = static_cast<T>(m_nCrossfadePosition++) * inv30;
                buf[idx] = alpha * yNew + (static_cast<T>(1.0) - alpha) * yOld;
            }
            m_bParamChanged = m_nCrossfadePosition < 30;
        }

        for (; idx < numSamples; ++idx) {
            T x0 = buf[idx];
            T y0 = m_b0 * x0 + m_b1 * m_x1 + m_b2 * m_x2 - m_a1 * m_y1 - m_a2 * m_y2;
            m_x2 = m_x1;
            m_x1 = x0;
            m_y2 = m_y1;
            m_y1 = y0;
            buf[idx] = y0;
        }
    }

private:
    double m_fInvSampleRate;                               
    T      m_b0, m_b1, m_b2, m_a1, m_a2;                   
    bool   m_bParamChanged;                                
    int    m_nCrossfadePosition = 0;
    T      m_x1, m_x2, m_y1, m_y2;                         
    T      m_old_b0, m_old_b1, m_old_b2, m_old_a1, m_old_a2;
    T      m_old_y1, m_old_y2;
};

// ============================================================================
// 4. CSampleRateConvert<T> — 4-Point Cubic Hermite Resampler + AA Filter
                                               
// ============================================================================
template <typename T>
class CSampleRateConvert {
public:
    CSampleRateConvert() {
        m_fHostRate = static_cast<T>(44100.0);
        m_fDspRate  = static_cast<T>(44100.0);
        m_WorkBufIn.assign(16384, static_cast<T>(0));
        m_WorkBufOut.assign(16384, static_cast<T>(0));
        m_OutFifo.assign(32768, 0.0f);
        Reset();
        UpdateAAFilter();
    }

    // Call outside processing (or with existing capacity when changing quality).
    void PrepareBlockSize(long hostSamples, long dspSamples) {
        const auto capacity = static_cast<size_t>(std::max(hostSamples, dspSamples)) + 64;
        if (m_WorkBufIn.size() < capacity) m_WorkBufIn.resize(capacity, static_cast<T>(0));
        if (m_WorkBufOut.size() < capacity) m_WorkBufOut.resize(capacity, static_cast<T>(0));
    }

    void Reset() {
        std::fill(m_WorkBufIn.begin(), m_WorkBufIn.end(), static_cast<T>(0));
        std::fill(m_WorkBufOut.begin(), m_WorkBufOut.end(), static_cast<T>(0));
        std::fill(m_OutFifo.begin(), m_OutFifo.end(), 0.0f);
        m_fPhaseIn  = 2.0;                                
        m_fPhaseOut = 2.0;
                                                                             
        int lead = static_cast<int>(static_cast<double>(m_fHostRate) / 22050.0 + 0.5) + 1;
        m_nFifoRead  = 0;
        m_nFifoWrite = lead;
        m_AAFilterIn.Reset();
        m_AAFilterOut.Reset();
    }

    void set_SampleRates(T hostRate, T dspRate) {
        m_fHostRate = hostRate;
        m_fDspRate  = dspRate;
        UpdateAAFilter();
        Reset();
    }

                                
    void UpdateAAFilter() {
        double hRate = static_cast<double>(m_fHostRate);
        double dRate = static_cast<double>(m_fDspRate);
        if (hRate < dRate) {
            m_AAFilterIn.set_SampleRate(dRate);
            m_AAFilterIn.set_TP2(0.5 * hRate, 0.8);
            m_AAFilterOut.set_SampleRate(dRate);
            m_AAFilterOut.set_TP2(0.5 * hRate, 0.8);
        } else {
            m_AAFilterIn.set_SampleRate(hRate);
            m_AAFilterIn.set_TP2(0.5 * dRate, 0.8);
            m_AAFilterOut.set_SampleRate(hRate);
            m_AAFilterOut.set_TP2(0.5 * dRate, 0.8);
        }
    }

                                                               
    static inline T CubicInterpolate(T y_m1, T y0, T y1, T y2, T x) {
        constexpr T kHalf = static_cast<T>(0.5);
        T c1 = kHalf * (y1 - y_m1);
        T c2 = y_m1 + static_cast<T>(2.0) * y1 - kHalf * (static_cast<T>(5.0) * y0 + y2);
        T c3 = kHalf * (static_cast<T>(3.0) * (y0 - y1) - y_m1 + y2);
        return ((c3 * x + c2) * x + c1) * x + y0;
    }

                                                      
    long DoConvertInput(const float* inHost, T* outDsp, long numHostSamples) {
        if (numHostSamples <= 0) return 0;
        if (m_fHostRate == m_fDspRate) {
            for (long i = 0; i < numHostSamples; ++i) {
                outDsp[i] = static_cast<T>(inHost[i]);
            }
            return numHostSamples;
        }

        if (static_cast<size_t>(numHostSamples + 16) > m_WorkBufIn.size()) {
            m_WorkBufIn.resize(static_cast<size_t>(numHostSamples + 64), static_cast<T>(0));
        }

        T* work = m_WorkBufIn.data();
        for (long i = 0; i < numHostSamples; ++i) {
            work[4 + i] = static_cast<T>(inHost[i]);
        }

                                                                       
        if (m_fHostRate > m_fDspRate) {
            m_AAFilterIn.DoBiQuad(work + 4, numHostSamples);
        }

        const double step = static_cast<double>(m_fHostRate) / static_cast<double>(m_fDspRate);
        const double startPhase = m_fPhaseIn;
        long outCount = static_cast<long>((static_cast<double>(numHostSamples) + 1.0 - startPhase) / step + 1.0);
        if (outCount < 0) outCount = 0;

        double phase = startPhase;
        for (long c = 0; c < outCount; ++c) {
            int idx = static_cast<int>(phase);
            T frac = static_cast<T>(phase - static_cast<double>(idx));
            outDsp[c] = CubicInterpolate(work[idx - 1], work[idx], work[idx + 1], work[idx + 2], frac);
            phase += step;
        }

        m_fPhaseIn = startPhase + static_cast<double>(outCount) * step - static_cast<double>(numHostSamples);

                                                                       
        work[0] = work[numHostSamples + 0];
        work[1] = work[numHostSamples + 1];
        work[2] = work[numHostSamples + 2];
        work[3] = work[numHostSamples + 3];

        return outCount;
    }

                                                                            
    void DoConvertOutput(T* inDsp, float* outHost, long numHostSamples, long numDspSamples, bool replacing) {
        if (numHostSamples <= 0) return;
        if (m_fHostRate == m_fDspRate) {
            if (replacing) {
                for (long i = 0; i < numHostSamples; ++i) {
                    outHost[i] = static_cast<float>(inDsp[i]);
                }
            } else {
                for (long i = 0; i < numHostSamples; ++i) {
                    outHost[i] += static_cast<float>(inDsp[i]);
                }
            }
            return;
        }

        if (static_cast<size_t>(numDspSamples + 16) > m_WorkBufOut.size()) {
            m_WorkBufOut.resize(static_cast<size_t>(numDspSamples + 64), static_cast<T>(0));
        }

        T* work = m_WorkBufOut.data();
        for (long i = 0; i < numDspSamples; ++i) {
            work[4 + i] = inDsp[i];
        }

                                                                                                 
        if (m_fDspRate > m_fHostRate && numDspSamples > 0) {
            m_AAFilterOut.DoBiQuad(work + 4, numDspSamples);
        }

        const double step = static_cast<double>(m_fDspRate) / static_cast<double>(m_fHostRate);
        const double startPhase = m_fPhaseOut;
        long outCount = static_cast<long>((static_cast<double>(numDspSamples) + 1.0 - startPhase) / step + 1.0);
        if (outCount < 0) outCount = 0;

        const int fifoSize = static_cast<int>(m_OutFifo.size());
        double phase = startPhase;
        for (long c = 0; c < outCount; ++c) {
            int idx = static_cast<int>(phase);
            T frac = static_cast<T>(phase - static_cast<double>(idx));
            float val = static_cast<float>(CubicInterpolate(work[idx - 1], work[idx], work[idx + 1], work[idx + 2], frac));
            m_OutFifo[static_cast<size_t>(m_nFifoWrite)] = val;
            if (++m_nFifoWrite >= fifoSize) m_nFifoWrite = 0;
            phase += step;
        }

        m_fPhaseOut = startPhase + static_cast<double>(outCount) * step - static_cast<double>(numDspSamples);

        // The prefix contains the four preceding samples. Shift it even when
        // this call produced only 0..3 DSP samples; the forward copy also works
        // for overlapping prefixes and leaves history intact for zero samples.
        work[0] = work[numDspSamples + 0];
        work[1] = work[numDspSamples + 1];
        work[2] = work[numDspSamples + 2];
        work[3] = work[numDspSamples + 3];

        if (replacing) {
            for (long i = 0; i < numHostSamples; ++i) {
                outHost[i] = m_OutFifo[static_cast<size_t>(m_nFifoRead)];
                if (++m_nFifoRead >= fifoSize) m_nFifoRead = 0;
            }
        } else {
            for (long i = 0; i < numHostSamples; ++i) {
                outHost[i] += m_OutFifo[static_cast<size_t>(m_nFifoRead)];
                if (++m_nFifoRead >= fifoSize) m_nFifoRead = 0;
            }
        }
    }

private:
    CBiQuad<T>         m_AAFilterIn;
    CBiQuad<T>         m_AAFilterOut;
    T                  m_fHostRate;
    T                  m_fDspRate;
    std::vector<T>     m_WorkBufIn;
    std::vector<T>     m_WorkBufOut;
    std::vector<float> m_OutFifo;
    int                m_nFifoRead  = 0;
    int                m_nFifoWrite = 3;
    double             m_fPhaseIn   = 2.0;
    double             m_fPhaseOut  = 2.0;
};

// ============================================================================
// 5. CAllpass<T> — Schroeder/Moorer All-Pass Diffuser
                      
                                                                           
                                                                         
                                                        
//      delayed      = m_Buffer[idx]
//      y[n]         = delayed - g * x[n]
//      m_Buffer[idx]= x[n] + g * y[n]
// ============================================================================
template <typename T>
class CAllpass {
public:
    static constexpr int kMaxAllpassDelay = 2200;  

    CAllpass()
        : m_nDelay(200)
        , m_nIdx(0)
        , m_fGain(static_cast<T>(-0.5))
    {
        Reset();
    }

    void Reset() {
        std::fill(m_Buffer.begin(), m_Buffer.end(), static_cast<T>(0));
        m_nIdx = 0;
    }

                                                             
    void set_Delay(int delaySamples) {
        delaySamples = std::clamp(delaySamples, 10, kMaxAllpassDelay);
        if (delaySamples < kMaxAllpassDelay) {
            std::fill(m_Buffer.begin() + delaySamples, m_Buffer.end(), static_cast<T>(0));
        }
        m_nDelay = delaySamples;
        if (m_nIdx >= m_nDelay) {
            m_nIdx = 0;
        }
    }

    void set_Gain(T gain) {
        m_fGain = gain;
    }

                                                                                         
    void DoAllpass(const T* inBuf, T* outBuf, long numSamples) {
        if (numSamples <= 0) return;
        const T g = m_fGain;
        const int D = m_nDelay;
        for (long i = 0; i < numSamples; ++i) {
            T x = inBuf[i];
            T delayed = m_Buffer[static_cast<size_t>(m_nIdx)];
            T y = delayed - g * x;
            m_Buffer[static_cast<size_t>(m_nIdx)] = x + g * y;
            outBuf[i] = y;
            if (++m_nIdx >= D) {
                m_nIdx = 0;
            }
        }
    }

    void DoAllpassReplace(T* buf, long numSamples) {
        DoAllpass(buf, buf, numSamples);
    }

private:
    std::vector<T> m_Buffer = std::vector<T>(kMaxAllpassDelay, static_cast<T>(0));
    int m_nDelay;  
    int m_nIdx;    
    T   m_fGain;   
};

// ============================================================================
// 6. CComb<T> — Parallel Negative-Feedback Comb Filter with 3-Band Damping
                      
                                                        
                                                                                                               
                                                        
                                                                                  
                                   
                                                            
// ============================================================================
template <typename T>
class CComb {
public:
    static constexpr int kMaxCombDelay      = 33000;                            
    static constexpr int kSharedRingBufSize = 57600;                                          

    CComb()
        : m_pSharedRingBase(nullptr)
        , m_nSharedRingSize(0)
        , m_pPendingTapPtr(nullptr)
        , m_pActiveTapPtr(nullptr)
        , m_bTapDirty(true)
        , m_nInputDelay(0)
        , m_nDelay(1000)
        , m_nReadWriteIdx(0)
        , m_fFeedbackGain(static_cast<T>(-0.6))
        , m_fMaxDampPerSample(0.9)
        , m_fAttackEnv(0.0)
        , m_fTypeGain(0.0)
        , m_nRoomAttackScale(3000)
        , m_fInputFeedGain(static_cast<T>(1.0))
        , m_b0(static_cast<T>(0.0)), m_b1(static_cast<T>(0.0)), m_b2(static_cast<T>(0.0))
        , m_a1(static_cast<T>(0.0)), m_a2(static_cast<T>(0.0))
        , m_w1(static_cast<T>(0.0)), m_w2(static_cast<T>(0.0))
    {
        Reset();
    }

    void bindSharedInputBuffer(T* ringBase, int ringSize, T* currentWritePtr) {
        m_pSharedRingBase = ringBase;
        m_nSharedRingSize = ringSize;
        int tap = m_nInputDelay;
        if (tap >= ringSize) tap = 0;
        T* p = currentWritePtr + tap;
        if (p >= ringBase + ringSize) {
            p -= ringSize;
        }
        m_pPendingTapPtr = p;
        m_pActiveTapPtr  = p;
        m_bTapDirty      = true;
        calc_InputDamp();
    }

    void Reset() {
        std::fill(m_Buffer.begin(), m_Buffer.end(), static_cast<T>(0));
        m_nReadWriteIdx = 0;
        m_w1 = static_cast<T>(0);
        m_w2 = static_cast<T>(0);
    }

                                                  
    void set_Delay(int delaySamples) {
        delaySamples = std::clamp(delaySamples, 10, kMaxCombDelay);
        if (delaySamples < kMaxCombDelay) {
            std::fill(m_Buffer.begin() + delaySamples, m_Buffer.end(), static_cast<T>(0));
        }
        m_nDelay = delaySamples;
        if (m_nReadWriteIdx >= m_nDelay) {
            m_nReadWriteIdx = 0;
        }
        m_fFeedbackGain = static_cast<T>(-std::pow(m_fMaxDampPerSample, static_cast<double>(m_nDelay)));
        calc_InputDamp();
    }

    int get_Delay() const { return m_nDelay; }

                                                          
    // Aligns input tap offset to an integer multiple of m_nDelay!
    void set_InputDelay(int inputDelaySamples, T* currentWritePtr) {
        int D = std::max(1, m_nDelay);
        int aligned = inputDelaySamples - (inputDelaySamples % D);
        if (aligned < 0) aligned = 0;
        if (m_nSharedRingSize > 0 && aligned >= m_nSharedRingSize) {
            aligned %= m_nSharedRingSize;
        }
        m_nInputDelay = aligned;
        if (m_pSharedRingBase && currentWritePtr && m_nSharedRingSize > 0) {
            T* p = currentWritePtr + aligned;
            if (p >= m_pSharedRingBase + m_nSharedRingSize) {
                p -= m_nSharedRingSize;
            }
            m_pPendingTapPtr = p;
            m_bTapDirty      = true;
        }
        calc_InputDamp();
    }

                                                                                                           
    void set_AttackParams(double attackEnv, double typeGain, int roomAttackSamples) {
        m_fAttackEnv       = attackEnv;
        m_fTypeGain        = typeGain;
        m_nRoomAttackScale = roomAttackSamples;
        calc_InputDamp();
    }

                                          
    void calc_InputDamp() {
        double gain = std::pow(m_fMaxDampPerSample, static_cast<double>(m_nInputDelay)) + m_fAttackEnv;
        if (m_nDelay < m_nRoomAttackScale && m_nRoomAttackScale > 0) {
            double minFactor = (1.0 - m_fTypeGain) * 0.75 + 0.25;
            double ramp = minFactor + ((1.0 - minFactor) / static_cast<double>(m_nRoomAttackScale)) * static_cast<double>(m_nDelay);
            gain *= ramp;
        }
        m_fInputFeedGain = static_cast<T>(gain);
    }

                                                                                                                      
    // Raises per-sample damping factors (dampLow, dampMid, dampHigh) to the power m_nDelay
    // and computes the exact Jot 3-Band Absorptive Allpass-Crossover Biquad.
    void set_3BandDamping(double cLow, double cHigh, double dampLow, double dampMid, double dampHigh) {
        m_fMaxDampPerSample = std::max(dampHigh, std::max(dampLow, dampMid));
        calc_InputDamp();

        const double D  = static_cast<double>(m_nDelay);
        const double gH = (dampHigh > 0.0) ? std::pow(dampHigh, D) : 0.0;
        const double gM = (dampMid  > 0.0) ? std::pow(dampMid,  D) : 0.0;
        const double gL = (dampLow  > 0.0) ? std::pow(dampLow,  D) : 0.0;

                                                      
        //   tHigh = (gM - gH) * (1.0 + cHigh)  --> controls Nyquist / High band (> fHi)
        //   tLow  = (gM - gL) * (1.0 - cLow)   --> controls DC / Low band (< fLo)
        const double dLow  = gM - gL;
        const double dHigh = gM - gH;
        const double tHigh = dHigh * (1.0 + cHigh);
        const double tLow  = dLow  * (1.0 - cLow);

        m_a1 = static_cast<T>(-cLow - cHigh);
        m_a2 = static_cast<T>(cLow * cHigh);
        m_b0 = static_cast<T>(gM - 0.5 * (tHigh + tLow));
        m_b1 = static_cast<T>((-cHigh * gM - cLow * gM) + 0.5 * (tHigh * (1.0 + cLow) - tLow * (1.0 - cHigh)));
        m_b2 = static_cast<T>((cLow * cHigh * gM) + 0.5 * (tLow * cHigh - tHigh * cLow));

        m_w1 = static_cast<T>(0);
        m_w2 = static_cast<T>(0);
    }

                                                                   
                                                               
    void Do3BandComb(T* accumBuf, long numSamples) {
        if (numSamples <= 0 || m_nDelay <= 0) return;

        if (m_bTapDirty) {
            m_pActiveTapPtr = m_pPendingTapPtr;
            m_bTapDirty     = false;
        }

        const int D = m_nDelay;
        const T feedGain = m_fInputFeedGain;
        const T b0 = m_b0, b1 = m_b1, b2 = m_b2;
        const T a1 = m_a1, a2 = m_a2;
        T w1 = m_w1, w2 = m_w2;
        T* tapPtr = m_pActiveTapPtr;
        T* ringBase = m_pSharedRingBase;
        const int ringSize = m_nSharedRingSize;

        for (long i = 0; i < numSamples; ++i) {
            T delayed = m_Buffer[static_cast<size_t>(m_nReadWriteIdx)];
            accumBuf[i] += delayed;

            T inSample = static_cast<T>(0);
            if (tapPtr) {
                inSample = (*tapPtr) * feedGain;
                if (--tapPtr < ringBase) {
                    tapPtr += ringSize;
                }
            }

            T w0 = inSample + delayed - a1 * w1 - a2 * w2;
            // DF2 output must use the previous states, not the updated states.
            T y0 = -(b0 * w0 + b1 * w1 + b2 * w2);
            w2 = w1;
            w1 = w0;
            m_Buffer[static_cast<size_t>(m_nReadWriteIdx)] = y0;

            if (++m_nReadWriteIdx >= D) {
                m_nReadWriteIdx = 0;
            }
        }

        if (w1 > static_cast<T>(-1e-34) && w1 < static_cast<T>(1e-34)) w1 = static_cast<T>(0);
        if (w2 > static_cast<T>(-1e-34) && w2 < static_cast<T>(1e-34)) w2 = static_cast<T>(0);
        m_w1 = w1;
        m_w2 = w2;
        m_pActiveTapPtr = tapPtr;
    }

private:
    T*             m_pSharedRingBase;       
    int            m_nSharedRingSize;       
    T*             m_pPendingTapPtr;        
    T*             m_pActiveTapPtr;         
    bool           m_bTapDirty;             
    int            m_nInputDelay;           
    int            m_nDelay;                
    int            m_nReadWriteIdx;         
    T              m_fFeedbackGain;         
    double         m_fMaxDampPerSample;     
    double         m_fAttackEnv;            
    double         m_fTypeGain;             
    int            m_nRoomAttackScale;      
    T              m_fInputFeedGain;        
    T              m_b0, m_b1, m_b2;        
    T              m_a1, m_a2;              
    T              m_w1, m_w2;              
    std::vector<T> m_Buffer = std::vector<T>(kMaxCombDelay, static_cast<T>(0));
};

// ============================================================================
// 7. CStereoModDelay<T> — Modulated Stereo Figure-8 Delay with Dual 3-Band Damping
                      
                                    
                                         
                                                       
                                                                                                               
                                                                                      
// ============================================================================
template <typename T>
class CStereoModDelay {
public:
    static constexpr int kRingBufferSize = 80000;                                                                    

    CStereoModDelay()
        : m_fSampleRate(44100.0)
        , m_LfoL(44100.0f, 490.0f, 0.0f)
        , m_LfoR(44100.0f, 367.5f, 0.0f)
        , m_nWriteIdxL(1)
        , m_nWriteIdxR(1)
        , m_fModOffsetL(static_cast<T>(0))
        , m_fModOffsetR(static_cast<T>(0))
        , m_nPeriodSamplesL(90)
        , m_nPeriodSamplesR(120)
        , m_nExcursionL(110)
        , m_nExcursionR(90)
        , m_fHalfExcursionL(static_cast<T>(55.0))
        , m_fHalfExcursionR(static_cast<T>(45.0))
        , m_nFbDelayL(0)
        , m_nFbDelayR(0)
        , m_b0L(static_cast<T>(0)), m_b1L(static_cast<T>(0)), m_b2L(static_cast<T>(0))
        , m_a1L(static_cast<T>(0)), m_a2L(static_cast<T>(0))
        , m_b0R(static_cast<T>(0)), m_b1R(static_cast<T>(0)), m_b2R(static_cast<T>(0))
        , m_a1R(static_cast<T>(0)), m_a2R(static_cast<T>(0))
        , m_w1L(static_cast<T>(0)), m_w2L(static_cast<T>(0))
        , m_w1R(static_cast<T>(0)), m_w2R(static_cast<T>(0))
    {
        Reset();
    }

    void Reset() {
        std::fill(m_BufL.begin(), m_BufL.end(), static_cast<T>(0));
        std::fill(m_BufR.begin(), m_BufR.end(), static_cast<T>(0));
        m_nWriteIdxL = 1;
        m_nWriteIdxR = 1;
        m_w1L = m_w2L = static_cast<T>(0);
        m_w1R = m_w2R = static_cast<T>(0);
    }

                                                          
    void set_SampleRate(double sr) {
        if (sr <= 1.0) return;
        double ratio = sr / m_fSampleRate;
        m_fSampleRate = sr;

        m_nFbDelayL = std::clamp(static_cast<int>(static_cast<double>(m_nFbDelayL) * ratio), 0, kRingBufferSize);
        m_nFbDelayR = std::clamp(static_cast<int>(static_cast<double>(m_nFbDelayR) * ratio), 0, kRingBufferSize);
        m_nPeriodSamplesL = std::max(1, static_cast<int>(static_cast<double>(m_nPeriodSamplesL) * ratio));
        m_nPeriodSamplesR = std::max(1, static_cast<int>(static_cast<double>(m_nPeriodSamplesR) * ratio));
        m_nExcursionL = static_cast<int>(static_cast<double>(m_nExcursionL) * ratio);
        m_nExcursionR = static_cast<int>(static_cast<double>(m_nExcursionR) * ratio);
        m_fHalfExcursionL = static_cast<T>(0.5 * static_cast<double>(m_nExcursionL));
        m_fHalfExcursionR = static_cast<T>(0.5 * static_cast<double>(m_nExcursionR));

        m_LfoL.SetSamplerate(static_cast<float>(sr), true);
        m_LfoR.SetSamplerate(static_cast<float>(sr), true);
        Reset();
    }

                                                                        
    void set_Rate(double rateL, double rateR) {
        rateL = std::clamp(rateL, 0.0, 1.0);
        rateR = std::clamp(rateR, 0.0, 1.0);

        double freqL = 19.95 * rateL * rateL + 0.05;
        double freqR = 19.95 * rateR * rateR + 0.05;

        m_nPeriodSamplesL = std::max(1, static_cast<int>(m_fSampleRate / freqL));
        m_nPeriodSamplesR = std::max(1, static_cast<int>(m_fSampleRate / freqR));

        float actualFreqL = static_cast<float>(m_fSampleRate / static_cast<double>(m_nPeriodSamplesL));
        float actualFreqR = static_cast<float>(m_fSampleRate / static_cast<double>(m_nPeriodSamplesR));

        m_LfoL.SetFrequencyInHz(actualFreqL, true);
        m_LfoR.SetFrequencyInHz(actualFreqR, true);
    }

                                                                                            
    void set_Excursions(int excSamplesL, int excSamplesR) {
        m_nExcursionL     = std::clamp(excSamplesL, 0, kRingBufferSize - 4);
        m_nExcursionR     = std::clamp(excSamplesR, 0, kRingBufferSize - 4);
        m_fHalfExcursionL = static_cast<T>(0.5 * static_cast<double>(m_nExcursionL));
        m_fHalfExcursionR = static_cast<T>(0.5 * static_cast<double>(m_nExcursionR));
    }

                                                                                                  
    void set_FbDelays(int delaySamplesL, int delaySamplesR) {
        delaySamplesL = std::clamp(delaySamplesL, 0, kRingBufferSize);
        delaySamplesR = std::clamp(delaySamplesR, 0, kRingBufferSize);
        if (delaySamplesL < kRingBufferSize) {
            std::fill(m_BufL.begin() + delaySamplesL, m_BufL.end(), static_cast<T>(0));
        }
        if (delaySamplesR < kRingBufferSize) {
            std::fill(m_BufR.begin() + delaySamplesR, m_BufR.end(), static_cast<T>(0));
        }
        m_nFbDelayL = delaySamplesL;
        m_nFbDelayR = delaySamplesR;
    }

                                                                                                                                
    void set_3BandDamping(double cLow, double cHigh, double dampLow, double dampMid, double dampHigh) {
        auto computeBiquad = [&](int delaySamples, T& b0, T& b1, T& b2, T& a1, T& a2) {
            const double D  = static_cast<double>(delaySamples);
            const double gH = (dampHigh > 0.0) ? std::pow(dampHigh, D) : 0.0;
            const double gM = (dampMid  > 0.0) ? std::pow(dampMid,  D) : 0.0;
            const double gL = (dampLow  > 0.0) ? std::pow(dampLow,  D) : 0.0;

            const double dLow  = gM - gL;
            const double dHigh = gM - gH;
            const double tHigh = dHigh * (1.0 + cHigh);
            const double tLow  = dLow  * (1.0 - cLow);

            a1 = static_cast<T>(-cLow - cHigh);
            a2 = static_cast<T>(cLow * cHigh);
            b0 = static_cast<T>(gM - 0.5 * (tHigh + tLow));
            b1 = static_cast<T>((-cHigh * gM - cLow * gM) + 0.5 * (tHigh * (1.0 + cLow) - tLow * (1.0 - cHigh)));
            b2 = static_cast<T>((cLow * cHigh * gM) + 0.5 * (tLow * cHigh - tHigh * cLow));
        };

        computeBiquad(m_nFbDelayL, m_b0L, m_b1L, m_b2L, m_a1L, m_a2L);
        computeBiquad(m_nFbDelayR, m_b0R, m_b1R, m_b2R, m_a1R, m_a2R);
        m_w1L = m_w2L = static_cast<T>(0);
        m_w1R = m_w2R = static_cast<T>(0);
    }

                                                                                                                   
                                                                               
    void DoStereoModDelay(const T* inL, const T* inR, T* outL, T* outR, long numSamples) {
        if (numSamples <= 0) return;

        int fbIdxL = m_nWriteIdxL + m_nFbDelayL;
        if (fbIdxL > kRingBufferSize) fbIdxL -= kRingBufferSize;
        int fbIdxR = m_nWriteIdxR + m_nFbDelayR;
        if (fbIdxR > kRingBufferSize) fbIdxR -= kRingBufferSize;

        for (long i = 0; i < numSamples; ++i) {
                                                                       
            double readPosL = static_cast<double>(m_nWriteIdxL) - static_cast<double>(m_fModOffsetL);
            if (readPosL < 1.0) {
                readPosL += static_cast<double>(kRingBufferSize);
            }
            int idxL = static_cast<int>(readPosL);
            if (idxL > kRingBufferSize) idxL = kRingBufferSize;
            if (idxL < 1) idxL = 1;
            T fracL = static_cast<T>(readPosL - static_cast<double>(idxL));

            T s1L = m_BufL[static_cast<size_t>(idxL)];
            T s0L = m_BufL[static_cast<size_t>(idxL - 1)];

                                                                                         
            m_BufL[static_cast<size_t>(m_nWriteIdxL)] += inL[i];

            T yL = s0L + fracL * (s1L - s0L);
            outL[i] = yL;

                                                                 
            T w0L = yL - m_a1L * m_w1L - m_a2L * m_w2L;
            T dampL = -(m_b0L * w0L + m_b1L * m_w1L + m_b2L * m_w2L);
            m_w2L = m_w1L;
            m_w1L = w0L;

                                                                        
            double readPosR = static_cast<double>(m_nWriteIdxR) - static_cast<double>(m_fModOffsetR);
            if (readPosR < 1.0) {
                readPosR += static_cast<double>(kRingBufferSize);
            }
            int idxR = static_cast<int>(readPosR);
            if (idxR > kRingBufferSize) idxR = kRingBufferSize;
            if (idxR < 1) idxR = 1;
            T fracR = static_cast<T>(readPosR - static_cast<double>(idxR));

            T s1R = m_BufR[static_cast<size_t>(idxR)];
            T s0R = m_BufR[static_cast<size_t>(idxR - 1)];

            m_BufR[static_cast<size_t>(m_nWriteIdxR)] += inR[i];

            T yR = s0R + fracR * (s1R - s0R);
            outR[i] = yR;

                                                                  
            T w0R = yR - m_a1R * m_w1R - m_a2R * m_w2R;
            T dampR = -(m_b0R * w0R + m_b1R * m_w1R + m_b2R * m_w2R);
            m_w2R = m_w1R;
            m_w1R = w0R;

                                                                                                       
            if (fbIdxL > kRingBufferSize) fbIdxL = 1;
            if (fbIdxR > kRingBufferSize) fbIdxR = 1;
            m_BufL[static_cast<size_t>(fbIdxL)] = dampR;
            m_BufR[static_cast<size_t>(fbIdxR)] = dampL;
            ++fbIdxL;
            ++fbIdxR;

                                                                                        
            if (++m_nWriteIdxL >= kRingBufferSize + 1) {
                m_BufL[0] = m_BufL[kRingBufferSize];
                m_nWriteIdxL = 1;
            }
            if (++m_nWriteIdxR >= kRingBufferSize + 1) {
                m_BufR[0] = m_BufR[kRingBufferSize];
                m_nWriteIdxR = 1;
            }

                                                                                  
            double sinL = m_LfoL.Tick();
            m_fModOffsetL = static_cast<T>((sinL + 1.0) * static_cast<double>(m_fHalfExcursionL));

            double sinR = m_LfoR.Tick();
            m_fModOffsetR = static_cast<T>((sinR + 1.0) * static_cast<double>(m_fHalfExcursionR));
        }

        if (m_w1L > static_cast<T>(-1e-34) && m_w1L < static_cast<T>(1e-34)) m_w1L = static_cast<T>(0);
        if (m_w2L > static_cast<T>(-1e-34) && m_w2L < static_cast<T>(1e-34)) m_w2L = static_cast<T>(0);
        if (m_w1R > static_cast<T>(-1e-34) && m_w1R < static_cast<T>(1e-34)) m_w1R = static_cast<T>(0);
        if (m_w2R > static_cast<T>(-1e-34) && m_w2R < static_cast<T>(1e-34)) m_w2R = static_cast<T>(0);
    }

private:
    double         m_fSampleRate;                  
    CFastSin       m_LfoL;                         
    CFastSin       m_LfoR;                         
    std::vector<T> m_BufL = std::vector<T>(kRingBufferSize + 2, static_cast<T>(0));
    std::vector<T> m_BufR = std::vector<T>(kRingBufferSize + 2, static_cast<T>(0));
    int            m_nWriteIdxL;                   
    int            m_nWriteIdxR;                   
    T              m_fModOffsetL;                  
    T              m_fModOffsetR;                  
    int            m_nPeriodSamplesL;              
    int            m_nPeriodSamplesR;              
    int            m_nExcursionL;                  
    int            m_nExcursionR;                  
    T              m_fHalfExcursionL;              
    T              m_fHalfExcursionR;              
    int            m_nFbDelayL;                    
    int            m_nFbDelayR;                    
    T              m_b0L, m_b1L, m_b2L, m_a1L, m_a2L;
    T              m_b0R, m_b1R, m_b2R, m_a1R, m_a2R;
    T              m_w1L, m_w2L;
    T              m_w1R, m_w2R;
};

// ============================================================================
// 8. CPattern<T> — Input All-Pass Diffusion + 20-Tap Early Reflection Engine
                      
                             
                                                    
                                     
                                      
                                       
                                             
                                                                               
                                                    
// ============================================================================
struct ReflectionStruct {
    int   numTapsL;
    int   numTapsR;
    float delayNormL[20];
    float gainL[20];
    float delayNormR[20];
    float gainR[20];
};

template <typename T>
class CPattern {
public:
    static constexpr int kEarlyRingPairs = 70000;                                                      

    void PrepareBlockSize(long samples) {
        for (int i = 0; i < 3; ++i) {
            m_StageBufL[i].reserve(static_cast<size_t>(samples));
            m_StageBufR[i].reserve(static_cast<size_t>(samples));
        }
    }

    CPattern()
        : m_nWritePairIdx(0)
        , m_nType(0)
        , m_fSampleRate(44100.0)
        , m_fDecaySec(0.1)
        , m_fRoomTimeScale(0.5)
        , m_fSpread(0.1)
        , m_fDensity(1.0)
        , m_fWidth2x(1.0)
        , m_fDirectFeedGain(static_cast<T>(0.1))
        , m_fPatternGainScalar(1.17f)
        , m_nActiveTaps(0)
        , m_fMinTapDelayMs(5.0)
        , m_fMaxTapDelayMs(700.0)
    {
        Reset();
        set_Type(0);
        for (int m = 0; m < 5; ++m) {
            CalcParams(m);
        }
    }

    void Reset() {
        std::fill(m_AccumRing.begin(), m_AccumRing.end(), static_cast<T>(0));
        m_nWritePairIdx = 0;
        for (int i = 0; i < 6; ++i) {
            m_InputAllpass[i].Reset();
        }
        CalcParams(0);
    }

                                                   
    void set_SampleRate(T fsDsp) {
        m_fSampleRate = static_cast<double>(fsDsp);
        m_nWritePairIdx = 0;
        CalcParams(0);
        CalcParams(1);
        CalcParams(4);
        CalcParams(3);
    }

                                                                                               
    void set_DecayInSec(T decaySec) {
        m_fDecaySec = std::min(1.0, std::max(0.01, static_cast<double>(decaySec)));
        CalcParams(1);
        CalcParams(3);
    }

                                                 
    // Computes m_fRoomTimeScale = 0.95 * clamp(roomSize, 0.0, 1.0) + 0.05
    void set_RoomSize(T roomSize) {
        double r = std::clamp(static_cast<double>(roomSize), 0.0, 1.0);
        m_fRoomTimeScale = 0.95 * r + 0.05;
        CalcParams(0);
        CalcParams(1);
        CalcParams(3);
    }

                                                                                                         
    void set_Spread(T spread) {
        double s = std::clamp(0.5 * static_cast<double>(spread) + 0.07, 0.0, 1.0);
        m_fSpread = s;
        CalcParams(1);
        CalcParams(3);
    }

                                                
    void set_Density(T density) {
        double d = std::clamp(static_cast<double>(density), 0.0, 1.0);
        if (d <= 0.2 && m_fDensity > 0.2) {
            m_InputAllpass[0].Reset();
            m_InputAllpass[1].Reset();
        }
        if (d <= 0.4 && m_fDensity > 0.4) {
            m_InputAllpass[2].Reset();
            m_InputAllpass[3].Reset();
        }
        if (d <= 0.6 && m_fDensity > 0.6) {
            m_InputAllpass[4].Reset();
            m_InputAllpass[5].Reset();
        }
        m_fDensity = d;
    }

                                                                                            
    void set_RoomWidth(T widthNorm) {
        m_fWidth2x = 2.0 * std::clamp(static_cast<double>(widthNorm), 0.0, 1.0);
        CalcParams(2);
        CalcParams(3);
    }

                                                                                     
    void set_DirectFeedGain(T feedGain) {
        m_fDirectFeedGain = feedGain;
    }

                                                   
    // Two-zone stereo width expansion law:
    //   - Zone 1 (m_fWidth2x <= 1.0, i.e., Width <= 0 deg):
    //       out = (pan - 0.5) * sqrt(m_fWidth2x) + 0.5
    //   - Zone 2 (m_fWidth2x > 1.0, i.e., Width in 0 .. +180 deg):
    //       pushes taps outward toward hard L (0.0) and hard R (1.0)!
    double panconvert(double pan) const {
        if (m_fWidth2x < 1.0) {
            return (pan - 0.5) * std::sqrt(std::max(0.0, m_fWidth2x)) + 0.5;
        }
        double rem = 2.0 - m_fWidth2x;
        if (pan < 0.5) {
            return pan * rem;
        }
        return 1.0 - (1.0 - pan) * rem;
    }

                                                            
    void set_Type(int type) {
        m_nType = std::clamp(type, 0, kNumReverbTypes - 1);
        m_nActiveTaps    = 0;
        m_fMinTapDelayMs = 10000.0;                      
        m_fMaxTapDelayMs = 0.0;

        for (int i = 0; i < 20; ++i) {
            const EarlyTapEntry& e = c_EarlyPatterns[m_nType][i];
            if (e.delayMsL == 0.0 || e.delayMsR == 0.0) {
                break;
            }
            m_RawTapsL[m_nActiveTaps] = { e.delayMsL, e.gainL, e.panL };
            m_RawTapsR[m_nActiveTaps] = { e.delayMsR, e.gainR, e.panR };

            if (e.delayMsL > m_fMaxTapDelayMs) m_fMaxTapDelayMs = e.delayMsL;
            if (e.delayMsR > m_fMaxTapDelayMs) m_fMaxTapDelayMs = e.delayMsR;
            if (e.delayMsL < m_fMinTapDelayMs) m_fMinTapDelayMs = e.delayMsL;
            if (e.delayMsR < m_fMinTapDelayMs) m_fMinTapDelayMs = e.delayMsR;

            ++m_nActiveTaps;
        }

        m_nWritePairIdx = 0;
        CalcParams(0);
        CalcParams(1);
        CalcParams(2);
        CalcParams(3);
        m_fPatternGainScalar = c_PatternGainScalars[m_nType];
    }

                                                 
    void CalcParams(int mode) {
        switch (mode) {
        case 0: {
                                                                                            
            double scale = 0.001 * m_fSampleRate * m_fRoomTimeScale;
            int maxPairs = std::clamp(static_cast<int>(m_fMaxTapDelayMs * scale) + 2, 4, kEarlyRingPairs);
            m_nActiveRingPairs = maxPairs;

            for (int i = 0; i < m_nActiveTaps; ++i) {
                int dL = static_cast<int>(m_RawTapsL[i].delayMs * scale);
                int dR = static_cast<int>(m_RawTapsR[i].delayMs * scale);
                m_DelayPairsL[i] = std::clamp(dL, 1, maxPairs - 1);
                m_DelayPairsR[i] = std::clamp(dR, 1, maxPairs - 1);
            }

            m_nSplit1 = m_nActiveTaps / 3;
            m_nSplit2 = 2 * m_nSplit1;
            if (m_nWritePairIdx >= m_nActiveRingPairs) {
                m_nWritePairIdx = 0;
            }
            break;
        }

        case 1: {
                                                                                                      
            if (m_nActiveTaps <= 0) break;
            double logVal      = std::log(std::max(1e-6, 0.2 * m_fSpread - 0.002));
            double decayScaled = 0.2 * m_fDecaySec;
            double minMs       = std::max(0.1, m_fMinTapDelayMs);
            double maxMs       = std::max(minMs + 0.1, m_fMaxTapDelayMs);
            double exponent    = 1.2 - decayScaled;
            double slope       = logVal / (minMs + maxMs);
            double offset      = (-logVal) / ((maxMs / minMs) + 1.0);
            double spreadComp  = (1.0 - std::sqrt(m_fSpread)) * 0.8 + 1.0;

            for (int i = 0; i < m_nActiveTaps; ++i) {
                double sign = (i & 1) ? -1.0 : 1.0;
                double envL = std::exp(std::pow(m_RawTapsL[i].delayMs, exponent) * slope + offset);
                double envR = std::exp(std::pow(m_RawTapsR[i].delayMs, exponent) * slope + offset);

                m_TapGainL[i] = envL * spreadComp * m_RawTapsL[i].gain * sign;
                m_TapGainR[i] = envR * spreadComp * m_RawTapsR[i].gain * sign;
            }
            break;
        }

        case 2: {
                                                                                           
            for (int i = 0; i < m_nActiveTaps; ++i) {
                m_ConvPanL[i] = panconvert(m_RawTapsL[i].pan);
                m_ConvPanR[i] = panconvert(m_RawTapsR[i].pan);
            }
            break;
        }

        case 3: {
                                                                                               
            for (int i = 0; i < m_nActiveTaps; ++i) {
                m_PanLL[i] = static_cast<T>((1.0 - m_ConvPanL[i]) * m_TapGainL[i]);
                m_PanLR[i] = static_cast<T>(m_ConvPanL[i] * m_TapGainL[i]);
                m_PanRL[i] = static_cast<T>((1.0 - m_ConvPanR[i]) * m_TapGainR[i]);
                m_PanRR[i] = static_cast<T>(m_ConvPanR[i] * m_TapGainR[i]);
            }
            break;
        }

        case 4: {
                                                                                                               
            for (int i = 0; i < 6; ++i) {
                double len = static_cast<double>(6 - i) * 80.0 / 44100.0 * m_fSampleRate;
                m_InputAllpass[i].set_Gain(static_cast<T>(-0.6));
                m_InputAllpass[i].set_Delay(static_cast<int>(len));
            }
            break;
        }

        default:
            break;
        }
    }

                                                                                                     
                                                                                      
    void DoPattern(const T* inL, const T* inR, T* outL, T* outR, long numSamples) {
        if (numSamples <= 0) return;

                                                                                      
        m_StageBufL[0].assign(inL, inL + numSamples);
        m_StageBufR[0].assign(inR, inR + numSamples);
        if (m_fDensity > 0.2) {
            m_InputAllpass[0].DoAllpassReplace(m_StageBufL[0].data(), numSamples);
            m_InputAllpass[1].DoAllpassReplace(m_StageBufR[0].data(), numSamples);
        }

        m_StageBufL[1] = m_StageBufL[0];
        m_StageBufR[1] = m_StageBufR[0];
        if (m_fDensity > 0.4) {
            m_InputAllpass[2].DoAllpassReplace(m_StageBufL[1].data(), numSamples);
            m_InputAllpass[3].DoAllpassReplace(m_StageBufR[1].data(), numSamples);
        }

        m_StageBufL[2] = m_StageBufL[1];
        m_StageBufR[2] = m_StageBufR[1];
        if (m_fDensity > 0.6) {
            m_InputAllpass[4].DoAllpassReplace(m_StageBufL[2].data(), numSamples);
            m_InputAllpass[5].DoAllpassReplace(m_StageBufR[2].data(), numSamples);
        }

        const int ringPairs = std::max(4, m_nActiveRingPairs);
        const int split1    = m_nSplit1;
        const int split2    = m_nSplit2;
        const int nTaps     = m_nActiveTaps;
        const T   directG   = m_fDirectFeedGain;

        for (long s = 0; s < numSamples; ++s) {
            const size_t si = static_cast<size_t>(s);

                                                                                         
            for (int t = 0; t < nTaps; ++t) {
                int st = (t < split1) ? 0 : ((t < split2) ? 1 : 2);
                T xL = m_StageBufL[st][si];
                T xR = m_StageBufR[st][si];

                int idxL = m_nWritePairIdx + m_DelayPairsL[t];
                if (idxL >= ringPairs) idxL -= ringPairs;
                m_AccumRing[static_cast<size_t>(idxL * 2)]     += xL * m_PanLL[t];
                m_AccumRing[static_cast<size_t>(idxL * 2 + 1)] += xL * m_PanLR[t];

                int idxR = m_nWritePairIdx + m_DelayPairsR[t];
                if (idxR >= ringPairs) idxR -= ringPairs;
                m_AccumRing[static_cast<size_t>(idxR * 2)]     += xR * m_PanRL[t];
                m_AccumRing[static_cast<size_t>(idxR * 2 + 1)] += xR * m_PanRR[t];
            }

                                                                                                               
            size_t curSlot = static_cast<size_t>(m_nWritePairIdx * 2);
            outL[s] = inL[s] * directG + m_AccumRing[curSlot];
            outR[s] = inR[s] * directG + m_AccumRing[curSlot + 1];
            m_AccumRing[curSlot]     = static_cast<T>(0);
            m_AccumRing[curSlot + 1] = static_cast<T>(0);

            if (++m_nWritePairIdx >= ringPairs) {
                m_nWritePairIdx = 0;
            }
        }
    }

                                                              
    void getReflections(ReflectionStruct* outRefl) const {
        if (!outRefl) return;
        std::memset(outRefl, 0, sizeof(ReflectionStruct));

        outRefl->numTapsL = m_nActiveTaps;
        outRefl->numTapsR = m_nActiveTaps;
        const float maxDelayMs = 700.0f;
        for (int i = 0; i < m_nActiveTaps; ++i) {
            outRefl->delayNormL[i] = static_cast<float>(m_RawTapsL[i].delayMs * m_fRoomTimeScale) / maxDelayMs;
            outRefl->gainL[i]      = static_cast<float>(std::fabs(m_RawTapsL[i].gain * m_TapGainL[i]) * static_cast<double>(m_fPatternGainScalar));
            outRefl->delayNormR[i] = static_cast<float>(m_RawTapsR[i].delayMs * m_fRoomTimeScale) / maxDelayMs;
            outRefl->gainR[i]      = static_cast<float>(std::fabs(m_RawTapsR[i].gain * m_TapGainR[i]) * static_cast<double>(m_fPatternGainScalar));
        }
    }

private:
    struct RawTap {
        double delayMs;
        double gain;
        double pan;
    };

    CAllpass<T>    m_InputAllpass[6];                
    std::vector<T> m_AccumRing = std::vector<T>(kEarlyRingPairs * 2, static_cast<T>(0));                      
    int            m_nWritePairIdx;                             
    int            m_nActiveRingPairs = kEarlyRingPairs;
    int            m_nType;
    double         m_fSampleRate;                               
    double         m_fDecaySec;                                 
    double         m_fRoomTimeScale;                            
    double         m_fSpread;                                   
    double         m_fDensity;                                  
    double         m_fWidth2x;                                  
    T              m_fDirectFeedGain;                           
    float          m_fPatternGainScalar;                        
    int            m_nActiveTaps;                               
    int            m_nSplit1 = 0;                               
    int            m_nSplit2 = 0;                               
    double         m_fMinTapDelayMs;                            
    double         m_fMaxTapDelayMs;                            
    RawTap         m_RawTapsL[20];
    RawTap         m_RawTapsR[20];
    int            m_DelayPairsL[20]{};
    int            m_DelayPairsR[20]{};
    double         m_TapGainL[20]{};
    double         m_TapGainR[20]{};
    double         m_ConvPanL[20]{};
    double         m_ConvPanR[20]{};
    T              m_PanLL[20]{}, m_PanLR[20]{};
    T              m_PanRL[20]{}, m_PanRR[20]{};
    std::vector<T> m_StageBufL[3];
    std::vector<T> m_StageBufR[3];
};

}                          
