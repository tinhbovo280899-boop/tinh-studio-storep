#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

namespace tverbdsp {

void setConfigurationWorkerPriority() noexcept;

// Exact endpoints, sample-counted ramps; no allocation or block-size dependence.
class ControlRamp {
public:
    explicit ControlRamp(double initial = 1.0) : value(initial), target(initial) {}
    void prepare(double sampleRate, double seconds = 0.03) noexcept {
        length = std::max(1, static_cast<int>(sampleRate * seconds));
        snap();
    }
    void set(double next, bool immediate = false) noexcept {
        if (!std::isfinite(next)) return;
        if (immediate) { value = target = next; remaining = 0; return; }
        if (next == target) return;
        target = next;
        remaining = length;
        step = (target - value) / remaining;
    }
    double next() noexcept {
        if (remaining > 0) {
            value += step;
            if (--remaining == 0) value = target;
        }
        return value;
    }
    void snap() noexcept { value = target; remaining = 0; }
    double getTarget() const noexcept { return target; }
private:
    double value, target, step = 0;
    int length = 1, remaining = 0;
};

// A broad +1 dB body bell and -2 dB high shelf at full Warmth.
// Fixed filters stay warm at 0%; only the parallel blend is automated.
// This colors the late path without adding a nonlinear stage or lookahead.
template <typename T>
class WarmthTone {
    struct Filter {
        double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0;
        double z1 = 0, z2 = 0;
        void set(double B0, double B1, double B2, double A0, double A1, double A2) noexcept {
            b0 = B0 / A0; b1 = B1 / A0; b2 = B2 / A0;
            a1 = A1 / A0; a2 = A2 / A0;
        }
        double process(double x) noexcept {
            const double y = b0 * x + z1;
            z1 = b1 * x - a1 * y + z2;
            z2 = b2 * x - a2 * y;
            return y;
        }
        void reset() noexcept { z1 = z2 = 0; }
    };
public:
    void prepare(double fs) noexcept {
        constexpr double pi = 3.14159265358979323846;
        const double wb = 2 * pi * 320.0 / fs;
        const double ab = std::sin(wb) / (2 * 0.7), cb = std::cos(wb);
        const double A = std::pow(10.0, 1.0 / 40.0);
        Filter body;
        body.set(1 + ab * A, -2 * cb, 1 - ab * A,
                 1 + ab / A, -2 * cb, 1 - ab / A);
        const double ws = 2 * pi * std::min(5500.0, fs * 0.4) / fs;
        const double cs = std::cos(ws), as = std::sin(ws) / std::sqrt(2.0);
        const double S = std::pow(10.0, -2.0 / 40.0), beta = 2 * std::sqrt(S) * as;
        Filter shelf;
        shelf.set(S * ((S + 1) + (S - 1) * cs + beta),
                 -2 * S * ((S - 1) + (S + 1) * cs),
                 S * ((S + 1) + (S - 1) * cs - beta),
                 (S + 1) - (S - 1) * cs + beta,
                 2 * ((S - 1) - (S + 1) * cs),
                 (S + 1) - (S - 1) * cs - beta);
        for (int c = 0; c < 2; ++c) { bodyFilter[c] = body; shelfFilter[c] = shelf; }
    }
    void reset() noexcept {
        for (int c = 0; c < 2; ++c) { bodyFilter[c].reset(); shelfFilter[c].reset(); }
    }
    T process(T x, int channel, double amount) noexcept {
        const double colored = shelfFilter[channel].process(bodyFilter[channel].process(x));
        // Preserve the exact neutral signal, including its rounding order.
        return amount <= 0 ? x : static_cast<T>(x + amount * (colored - x));
    }
private:
    Filter bodyFilter[2], shelfFilter[2];
};

} // namespace tverbdsp
