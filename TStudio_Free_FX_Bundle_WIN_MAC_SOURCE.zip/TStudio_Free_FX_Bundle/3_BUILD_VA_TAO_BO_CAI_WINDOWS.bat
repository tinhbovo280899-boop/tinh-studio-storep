@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0" || exit /b 2
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Build-Windows.ps1" -Action Both
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" echo BUILD FAILED. See build\win-x64\BUNDLE_BUILD_LOG.txt
pause
exit /b %RESULT%
