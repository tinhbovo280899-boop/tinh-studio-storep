#ifndef BundleStage
  #error Pass /DBundleStage=path_to_verified_export
#endif
#ifndef BundleOutput
  #error Pass /DBundleOutput=installer_output_directory
#endif
#define BundleName "T Studio Free FX Bundle"
#define BundleVersion "1.0.0"
#if !DirExists(BundleStage + "\VST3\T-Verb.vst3") || !DirExists(BundleStage + "\VST3\T-RVerb.vst3") || !DirExists(BundleStage + "\VST3\PantheonII.vst3") || !DirExists(BundleStage + "\VST3\Liquid Delays II.vst3")
  #error The export does not contain all four VST3 bundles
#endif
[Setup]
AppId={{F9DB0BDA-37B2-4E5E-B9DA-6E1C48E5F9BD}
AppName={#BundleName}
AppVersion={#BundleVersion}
AppPublisher=T Studio
DefaultDirName={commonpf}\T Studio\Free FX Bundle
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir={#BundleOutput}
OutputBaseFilename=Setup_TStudio_FreeFX_WIN_x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#BundleName}
[Files]
Source: "{#BundleStage}\VST3\*"; DestDir: "{commoncf64}\VST3"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#BundleStage}\Docs\*"; DestDir: "{app}\Docs"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#BundleStage}\BundleManifest.json"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#BundleStage}\SHA256SUMS.txt"; DestDir: "{app}"; Flags: ignoreversion
