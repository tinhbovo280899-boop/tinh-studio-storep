#!/bin/bash
set -euo pipefail
ACTION="${1:-both}"
case "$ACTION" in build|installer|both) ;; *) echo 'Use build, installer or both.'; exit 2;; esac
[[ "$(uname -s)" == Darwin ]] || { echo 'Run this script on macOS.'; exit 2; }
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
BUILD="$ROOT/build/mac-universal"
EXPORT="$ROOT/_EXPORT"
OUTPUT="$ROOT/_INSTALLERS"
CMAKE="$(command -v cmake || true)"
if [[ -z "$CMAKE" ]]; then
    for p in /opt/homebrew/bin/cmake /usr/local/bin/cmake /Applications/CMake.app/Contents/bin/cmake; do
        if [[ -x "$p" ]]; then CMAKE="$p"; break; fi
    done
fi
[[ -n "$CMAKE" ]] || { echo 'Install CMake 3.22 or newer.'; exit 2; }
mkdir -p "$BUILD"
LOG="$BUILD/BUNDLE_BUILD_LOG.txt"
run() { "$@" 2>&1 | tee -a "$LOG"; }
if [[ "$ACTION" == build || "$ACTION" == both ]]; then
    xcrun --find clang++ >/dev/null 2>&1 || { echo 'Install Xcode Command Line Tools: xcode-select --install'; exit 2; }
    run "$CMAKE" -S "$ROOT" -B "$BUILD" '-DCMAKE_OSX_ARCHITECTURES=arm64;x86_64' -DFX_CHILD_JOBS=2 "-DFX_EXPORT_DIR=$EXPORT"
    run "$CMAKE" --build "$BUILD" --config Release --target bundle --parallel 2
    CTEST="$(dirname "$CMAKE")/ctest"
    [[ -x "$CTEST" ]] || CTEST="$(command -v ctest)"
    run "$CTEST" --test-dir "$BUILD" -C Release --output-on-failure
fi
if [[ "$ACTION" == installer || "$ACTION" == both ]]; then
    run "$CMAKE" "-DFX_EXPORT_DIR=$EXPORT" -DFX_EXPECTED_SYSTEM=Darwin '-DFX_ARCHS=arm64;x86_64' -P "$ROOT/scripts/VerifyExport.cmake"
    STAGING="$BUILD/pkg-root"
    rm -rf "$STAGING"
    mkdir -p "$STAGING/Library/Audio/Plug-Ins/VST3" "$STAGING/Library/Application Support/T Studio/Free FX Bundle"
    for plugin in "$EXPORT"/VST3/*.vst3; do
        [[ -d "$plugin" ]] || { echo "Missing VST3 bundle: $plugin"; exit 1; }
        name="$(basename "$plugin")"
        ditto "$plugin" "$STAGING/Library/Audio/Plug-Ins/VST3/$name"
        run /usr/bin/codesign --force --deep --sign - "$STAGING/Library/Audio/Plug-Ins/VST3/$name"
    done
    ditto "$EXPORT/Docs" "$STAGING/Library/Application Support/T Studio/Free FX Bundle/Docs"
    run "$CMAKE" "-DFX_EXPORT_DIR=$EXPORT" "-DFX_PACKAGE_ROOT=$STAGING" -P "$ROOT/scripts/PrepareMacPackage.cmake"
    run /bin/chmod -R u=rwX,go=rX "$STAGING"
    for plugin in "$STAGING"/Library/Audio/Plug-Ins/VST3/*.vst3; do
        run /usr/bin/codesign --verify --deep --strict "$plugin"
    done
    run /usr/bin/pkgbuild --analyze --root "$STAGING" "$BUILD/components.plist"
    /usr/bin/plutil -convert xml1 "$BUILD/components.plist"
    count=$(/usr/libexec/PlistBuddy -c Print "$BUILD/components.plist" | awk '/BundleIsRelocatable/{n++} END{print n+0}')
    for (( i=0; i<count; i++ )); do
        /usr/libexec/PlistBuddy -c "Set :$i:BundleIsRelocatable false" "$BUILD/components.plist"
        /usr/libexec/PlistBuddy -c "Set :$i:BundleIsVersionChecked false" "$BUILD/components.plist"
    done
    mkdir -p "$OUTPUT"
    PACKAGE="$OUTPUT/TStudio_FreeFX_MAC_Universal.pkg"
    run /usr/bin/pkgbuild --root "$STAGING" --component-plist "$BUILD/components.plist" --identifier com.tstudio.freefxbundle --version 1.0.0 --install-location / --ownership recommended "$PACKAGE"
    [[ -s "$PACKAGE" ]] || { echo 'pkgbuild produced no installer.'; exit 1; }
    echo "Installer ready: $PACKAGE"
fi
echo "Done. Export: $EXPORT"
