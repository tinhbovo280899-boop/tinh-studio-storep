param([ValidateSet('Build','Installer','Both')][string]$Action='Both')
Set-StrictMode -Version Latest
$ErrorActionPreference='Stop'
$Root=Split-Path -Parent $PSScriptRoot
$Build=Join-Path $Root 'build\win-x64'
$Export=Join-Path $Root '_EXPORT'
$Output=Join-Path $Root '_INSTALLERS'
if ($env:OS -ne 'Windows_NT') {throw 'Run the Windows build script on Windows.'}
function Find-CMake {
    $cmd=Get-Command cmake.exe -ErrorAction SilentlyContinue
    if($cmd){return $cmd.Source}
    $vswhere=Join-Path ${env:ProgramFiles(x86)} 'Microsoft Visual Studio\Installer\vswhere.exe'
    if(Test-Path -LiteralPath $vswhere){
        $vs=& $vswhere -latest -products '*' -requires Microsoft.VisualStudio.Component.VC.Tools.x86.x64 -property installationPath
        if($vs){$tool=Join-Path $vs 'Common7\IDE\CommonExtensions\Microsoft\CMake\CMake\bin\cmake.exe';if(Test-Path -LiteralPath $tool){return $tool}}
    }
    throw 'Install CMake 3.22+ and Visual Studio Desktop development with C++.'
}
$CMake=Find-CMake
New-Item -ItemType Directory -Force -Path $Build | Out-Null
$Log=Join-Path $Build 'BUNDLE_BUILD_LOG.txt'
function Invoke-Tool([string]$Tool,[string[]]$ToolArgs){
    if(-not(Test-Path -LiteralPath $Tool -PathType Leaf)){throw "Tool not found: $Tool"}
    $previous=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        & $Tool @ToolArgs 2>&1 | Tee-Object -FilePath $Log -Append
        $result=$LASTEXITCODE
    } finally {$ErrorActionPreference=$previous}
    if($result -ne 0){throw "Command failed ($result). See $Log"}
}
if($Action -eq 'Build' -or $Action -eq 'Both'){
    $env:CMAKE_GENERATOR=''
    $env:CMAKE_GENERATOR_PLATFORM=''
    $configure=@('-S',$Root,'-B',$Build,'-DFX_CHILD_JOBS=2',('-DFX_EXPORT_DIR='+$Export))
    if(-not(Test-Path -LiteralPath (Join-Path $Build 'CMakeCache.txt'))){$configure+=@('-A','x64')}
    Invoke-Tool $CMake $configure
    Invoke-Tool $CMake @('--build',$Build,'--config','Release','--target','bundle','--parallel','2')
    $CTest=Join-Path (Split-Path -Parent $CMake) 'ctest.exe'
    Invoke-Tool $CTest @('--test-dir',$Build,'-C','Release','--output-on-failure')
}
if($Action -eq 'Installer' -or $Action -eq 'Both'){
    Invoke-Tool $CMake @(('-DFX_EXPORT_DIR='+$Export),'-DFX_EXPECTED_SYSTEM=Windows','-P',(Join-Path $Root 'scripts\VerifyExport.cmake'))
    $iscc=Get-Command ISCC.exe -ErrorAction SilentlyContinue
    $Compiler=if($iscc){$iscc.Source}else{Join-Path ${env:ProgramFiles(x86)} 'Inno Setup 6\ISCC.exe'}
    if(-not(Test-Path -LiteralPath $Compiler)){throw 'Install Inno Setup 6.3+ to create the .exe installer. Build outputs are already in _EXPORT.'}
    New-Item -ItemType Directory -Force -Path $Output | Out-Null
    Invoke-Tool $Compiler @(('/DBundleStage='+$Export),('/DBundleOutput='+$Output),(Join-Path $Root 'installer\windows\Bundle.iss'))
    $Setup=Join-Path $Output 'Setup_TStudio_FreeFX_WIN_x64.exe'
    if(-not(Test-Path -LiteralPath $Setup)){throw 'Installer compiler finished without producing the expected .exe.'}
    Write-Host "Installer ready: $Setup"
}
Write-Host "Done. Export: $Export"
