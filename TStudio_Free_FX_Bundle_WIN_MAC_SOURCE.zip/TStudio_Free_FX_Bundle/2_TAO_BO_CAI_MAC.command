#!/bin/bash
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
"$ROOT/scripts/build-mac.sh" installer
RESULT=$?
if [[ -t 0 ]]; then read -r -p "Press Return to close..." _unused; fi
exit "$RESULT"
