# Xác minh bản Free Bundle

- Build mới bốn VST3 trên Linux từ nguồn đã bỏ activation.
- 13 test của bốn dự án đều đạt: T-Verb 6, T-RVerb 2, PANTHEON 2, LIQUID 3. Test license của phiên bản trả phí không còn trong bản free; các test DSP/state/UI/shutdown được giữ.
- T-Verb gồm 320 kiểm tra engine và các phép đo cấp phát.
- Hai test gói chung đạt: audit bỏ activation; staging đủ 4 native bundle, chặn thiếu plugin, file lạ, chỉnh sửa và sai nền tảng.
- Mã engine/preset của cả bốn so byte với bản sửa trước: không đổi.
- VST3 component/controller CID và tên so với bản sửa trước: giữ nguyên; binary không có symbol lớp activation của dự án.
- Luồng mặc định tạo SDK JUCE dùng chung từ cây nguồn đi kèm đã thử sạch trên Linux.
- Script macOS đã kiểm tra cú pháp bash; script Windows đã parse bằng grammar PowerShell.

Chưa chạy native Windows/macOS, ISCC, pkgbuild hoặc ký/notarize bằng Developer ID. Chưa kiểm tra cài/gỡ trong DAW trên máy thật. ZIP là nguồn và luồng build/bộ cài sẵn để chạy trên hệ điều hành đích; không chứa installer Windows/macOS đã biên dịch.
