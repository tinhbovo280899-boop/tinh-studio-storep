#include "TDelayProcessor.h"
#include <cstdio>
#include <limits>
#include <cmath>
#include <vector>
static int failures=0;
#define CHECK(x) do { if(!(x)){std::printf("FAIL line %d: %s\n",__LINE__,#x);++failures;} }while(0)

static void set(juce::AudioProcessorValueTreeState& v,const char* id,float value){auto* p=v.getParameter(id);CHECK(p);if(p)p->setValueNotifyingHost(p->convertTo0to1(value));}
int main(){juce::ScopedJuceInitialiser_GUI gui;
 TDelayAudioProcessor p;p.setPlayConfigDetails(1,2,32000,128);p.prepareToPlay(32000,128);
 auto& v=p.getAPVTS();set(v,"mix",0);set(v,"peakLimit",0);
 juce::AudioBuffer<float>b(2,128);juce::MidiBuffer m;for(int i=0;i<128;++i){b.setSample(0,i,-.25f);b.setSample(1,i,.9f);}p.processBlock(b,m);
 for(int i=0;i<128;++i){CHECK(std::abs(b.getSample(0,i)+.25f)<1e-6);CHECK(std::abs(b.getSample(1,i)+.25f)<1e-6);}
 CHECK(p.getInputLevelL()>.2f&&p.getOutputLevelL()>.2f);
 set(v,"dlyTempo",145);set(v,"dlySync",1);set(v,"dlyLXTime",7);p.processBlock(b,m);CHECK(std::abs(p.getEffectiveDelayMsL()-60000.f/145)<.01f);
 set(v,"bypass",1);for(int i=0;i<128;++i){b.setSample(0,i,.1f);b.setSample(1,i,0);}p.processBlock(b,m);CHECK(std::abs(b.getSample(1,0)-.1f)<1e-6);set(v,"bypass",0);
 set(v,"dlyFeedback",90);CHECK(p.getTailLengthSeconds()>10);

 set(v,"mix",100);set(v,"filterOn",0);set(v,"overdrive",0);set(v,"inLoop",1);set(v,"dlyLOn",0);set(v,"dlyROn",0);set(v,"peakLimit",0);
 for(int i=0;i<128;++i){b.setSample(0,i,.1f);b.setSample(1,i,0);}p.processBlock(b,m);CHECK(std::abs(b.getSample(0,0)-.1f)<1e-6f);CHECK(std::abs(b.getSample(1,0)-.1f)<1e-6f);
 for(int preset=0;preset<p.getNumPrograms();++preset){p.setCurrentProgram(preset);p.releaseResources();p.prepareToPlay(32000,128);for(int k=0;k<6;++k){for(int i=0;i<128;++i){b.setSample(0,i,.1f*std::sin((i+k*128)*.2));b.setSample(1,i,0);}p.processBlock(b,m);for(int ch=0;ch<2;++ch)for(int i=0;i<128;++i)CHECK(std::isfinite(b.getSample(ch,i)));}}
 const int index=p.getNumPrograms()-1;p.setCurrentProgram(index);juce::MemoryBlock state;p.getStateInformation(state);TDelayAudioProcessor q;q.setStateInformation(state.getData(),int(state.getSize()));CHECK(q.getCurrentProgram()==index);
 for(const auto* id:{"mix","inputLevel"})CHECK(std::abs(p.getAPVTS().getRawParameterValue(id)->load()-q.getAPVTS().getRawParameterValue(id)->load())<1e-6);

 auto renderLfo=[&](int block){
  TDelayAudioProcessor proc;proc.setPlayConfigDetails(2,2,48000,block);proc.prepareToPlay(48000,block);auto& state=proc.getAPVTS();
  set(state,"mix",100);set(state,"peakLimit",0);set(state,"dlyLOn",0);set(state,"dlyROn",0);set(state,"inLoop",0);set(state,"overdrive",0);set(state,"filterOn",1);set(state,"lfoOn",1);set(state,"lfoRate",1.2f);set(state,"lfoDepth",50);
  std::vector<float> out(20000);juce::MidiBuffer midi;
  for(int off=0;off<20000;off+=block){const int n=std::min(block,20000-off);juce::AudioBuffer<float> b(2,n);for(int i=0;i<n;++i){float x=.05f*std::sin((off+i)*.13);b.setSample(0,i,x);b.setSample(1,i,x);}proc.processBlock(b,midi);for(int i=0;i<n;++i)out[off+i]=b.getSample(0,i);}
  return out;
 };
 const auto small=renderLfo(7),large=renderLfo(128);float blockError=0;for(size_t i=0;i<small.size();++i)blockError=std::max(blockError,std::abs(small[i]-large[i]));CHECK(blockError<1e-6f);std::printf("LFO block 7 vs 128 max error=%g\n",blockError);
 std::unique_ptr<juce::AudioProcessorEditor> e(p.createEditor());CHECK(e!=nullptr);p.releaseResources();
 std::printf("TDelayAudioProcessor mono/stereo, meters/tempo/tail, %d presets, state/editor: %d failures\n",p.getNumPrograms(),failures);
 return failures?1:0;}
