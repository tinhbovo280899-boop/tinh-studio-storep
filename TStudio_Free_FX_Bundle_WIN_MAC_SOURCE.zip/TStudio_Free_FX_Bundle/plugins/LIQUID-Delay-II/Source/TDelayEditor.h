#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "TDelayProcessor.h"

class TDelayLookAndFeel : public juce::LookAndFeel_V4
{
public:
    TDelayLookAndFeel();

    void drawLinearSlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float minSliderPos, float maxSliderPos,
                          const juce::Slider::SliderStyle style, juce::Slider& slider) override;

    void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                          bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override;

    void drawComboBox(juce::Graphics& g, int width, int height, bool isButtonDown,
                      int buttonX, int buttonY, int buttonW, int buttonH,
                      juce::ComboBox& box) override;

    juce::Image knobLargeImage;
    juce::Image switchPanelImage;
    juce::Image modeDisplayImage;
};

class TDelayAudioProcessorEditor : public juce::AudioProcessorEditor,
                                   private juce::Timer
{
public:
    explicit TDelayAudioProcessorEditor(TDelayAudioProcessor&);
    ~TDelayAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;
    void mouseDown(const juce::MouseEvent& event) override;

private:
    void timerCallback() override;
    void setupBoxSlider(juce::Slider& s, juce::Colour barCol, const juce::String& styleTag);
    int syncIndexToNoteRow(int syncIdx) const noexcept;
    int noteRowToSyncIndex(int row) const noexcept;

    TDelayAudioProcessor& audioProcessor;
    TDelayLookAndFeel customLookAndFeel;

    juce::Image bgSkinImage;
    juce::Image routingDisplayImage;

    // Top Preset Bar Controls (matching Nomad Factory Liquid Delays II 666x484 skin)
    juce::TextButton saveBtn    { "Save" };
    juce::TextButton prevPreBtn { "<" };
    juce::TextButton nextPreBtn { ">" };
    juce::TextButton utilityBtn { "Utility" };
    juce::ComboBox   presetBox;

    // Bottom Routing Mode ComboBox (x=323, y=441, w=171, h=20)
    juce::ComboBox fxModeBox;

    // 6 Black "ON" Pill Toggle Buttons
    juce::ToggleButton filterOnBtn { "ON" };
    juce::ToggleButton inLoopBtn   { "ON" };
    juce::ToggleButton lfoOnBtn    { "ON" };
    juce::ToggleButton dlySyncBtn  { "ON" };
    juce::ToggleButton dlyLOnBtn   { "ON" };
    juce::ToggleButton dlyROnBtn   { "ON" };

    // 2 Oval Toggle Buttons (LFO Sync & Master Peak Limiter)
    juce::ToggleButton lfoSyncBtn   { "Sync" };
    juce::ToggleButton peakLimitBtn { "Peak\nLimiter" };

    // Master Bypass Button (x=561, y=445, w=78, h=22)
    juce::ToggleButton bypassBtn { "Bypass" };

    // L-Delay & R-Delay Triplet ("3") and Dotted (".") Toggle Buttons
    juce::ToggleButton dlyLTriBtn { "3" };
    juce::ToggleButton dlyLDotBtn { "." };
    juce::ToggleButton dlyRTriBtn { "3" };
    juce::ToggleButton dlyRDotBtn { "." };

    // Hidden ComboBoxes bound to APVTS for dlyLXTime, dlyRXTime, lfoWave
    juce::ComboBox dlyLXTimeBox;
    juce::ComboBox dlyRXTimeBox;
    juce::ComboBox lfoWaveBox;

    // 9 Metallic Parameter Box Sliders (86x51 with right-side vertical level bar)
    juce::Slider lowCutSlider, resonanceSlider, highCutSlider, overdriveSlider;
    juce::Slider lfoRateSlider, lfoDepthSlider, stereoWidthSlider;
    juce::Slider dlyTempoSlider, dlyFeedbackSlider;

    // 3 Right-Panel Dark LCD Sliders (Input Level, Output Level, Mix)
    juce::Slider inputLevelSlider, outputLevelSlider, mixSlider;

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboAttachment  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<ComboAttachment>  fxModeAtt, dlyLXTimeAtt, dlyRXTimeAtt, lfoWaveAtt;
    std::unique_ptr<ButtonAttachment> dlyLOnAtt, dlyROnAtt, dlySyncAtt, inLoopAtt;
    std::unique_ptr<ButtonAttachment> dlyLDotAtt, dlyRDotAtt, dlyLTriAtt, dlyRTriAtt;
    std::unique_ptr<ButtonAttachment> filterOnAtt, lfoOnAtt, lfoSyncAtt;
    std::unique_ptr<ButtonAttachment> peakLimitAtt, bypassAtt;
    std::unique_ptr<SliderAttachment> dlyTempoAtt, dlyFeedbackAtt;
    std::unique_ptr<SliderAttachment> lowCutAtt, resonanceAtt, highCutAtt, overdriveAtt;
    std::unique_ptr<SliderAttachment> lfoRateAtt, lfoDepthAtt;
    std::unique_ptr<SliderAttachment> inputLevelAtt, outputLevelAtt, stereoWidthAtt, mixAtt;


    juce::TooltipWindow tips { this, 500 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TDelayAudioProcessorEditor)
};
