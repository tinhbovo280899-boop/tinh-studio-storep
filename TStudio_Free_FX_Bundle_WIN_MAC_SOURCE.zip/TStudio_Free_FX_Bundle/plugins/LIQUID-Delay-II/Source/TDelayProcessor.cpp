#include "TDelayProcessor.h"
#include "TDelayEditor.h"

namespace tdelay
{

static const std::vector<FactoryPreset> kPresets = {
    // Preset 00 matches the user's exact Cubase screenshot (Low Cut 104.09Hz, Res 50%, High Cut 1.25kHz, LFO On 1.00Hz/50%, 1/8 - 1/4 @ 145 BPM, FB 33%, In-Loop On, Mix 35%, Mode: Drive -> Filters -> Delays)
    { "Factory Setting",                                  5, 0.0f, 0.0f, 35.0f, true, true, true, 7, 4, false, false, false, false, 145.0f, 33.0f, false, true, true,  104.09f, 1250.0f, 50.0f,  0.0f, false, false, 1.00f, 50.0f, 0, 100.0f, true  },
    { "01. Vocal Ping-Pong 1/8 - 1/4 (Bolero/Ballad)",    5, 0.0f, 0.0f, 35.0f, true, true, true, 4, 7, false, false, false, false, 120.0f, 33.0f, true,  true, true,  104.09f, 1250.0f, 50.0f,  0.0f, true,  false, 1.00f, 50.0f, 0, 100.0f, true  },
    { "02. Liquid Warm Tape Echo (1/4D - 1/4)",           5, 0.0f, 0.0f, 35.0f, true, true, true, 7, 9, false, true,  false, false, 118.0f, 42.0f, true,  true, true,  180.0f,  2400.0f, 45.0f, 15.0f, true,  false, 0.85f, 45.0f, 0, 100.0f, true  },
    { "03. Slapback Vocal Doubler (1/16 - 1/16D)",        2, 0.0f, 0.0f, 26.0f, true, true, true, 1, 3, false, true,  false, false, 125.0f, 18.0f, false, true, false, 150.0f,  4200.0f, 25.0f,  0.0f, true,  false, 1.20f, 35.0f, 1,  90.0f, true  },
    { "04. Nomad Factory Default (1/8T - 1/4)",           0, 0.0f, 0.0f, 35.0f, true, true, true, 2, 7, false, false, false, false, 120.0f, 33.0f, false, true, true,  800.2f,  2300.0f, 50.0f,  0.0f, false, false, 1.00f, 50.0f, 2, 100.0f, false },
    { "05. Wide Stereo Chorus Delay (Modulated)",         1, 0.0f, 0.0f, 38.0f, true, true, true, 4, 6, false, true,  false, false, 120.0f, 40.0f, true,  true, true,  120.0f,  2800.0f, 50.0f,  0.0f, true,  false, 0.75f, 55.0f, 0, 100.0f, true  },
    { "06. Analog BBD Dark Vocal Tail",                   5, 0.0f, 0.5f, 32.0f, true, true, true, 4, 7, false, false, false, false, 110.0f, 44.0f, true,  true, true,  140.0f,  1500.0f, 52.0f, 12.0f, true,  false, 0.60f, 48.0f, 0, 100.0f, true  },
    { "07. Dub Reggae Resonant Filter Echo",              0, 0.0f, 0.0f, 45.0f, true, true, true, 6, 7, true,  false, false, false, 130.0f, 62.0f, true,  true, true,  450.0f,  1850.0f, 70.0f, 25.0f, true,  true,  0.50f, 60.0f, 1, 100.0f, true  },
    { "08. Karaoke / Live Mic Sweetener",                 5, 0.0f, 0.0f, 33.0f, true, true, true, 4, 7, false, false, false, false, 128.0f, 34.0f, true,  true, true,  104.09f, 1600.0f, 45.0f,  0.0f, true,  false, 1.00f, 45.0f, 0, 100.0f, true  },
    { "09. Tube Driven Rock Lead Delay",                  4, 1.5f, 0.0f, 34.0f, true, true, true, 7, 9, false, true,  false, false, 128.0f, 38.0f, false, true, true,  220.0f,  3200.0f, 40.0f, 35.0f, true,  false, 1.10f, 40.0f, 0, 100.0f, true  },
    { "10. Shimmering Ambient 1/2 Bar Throws",            3, 0.0f, 0.0f, 42.0f, true, true, true, 9, 10, true, false, false, false, 100.0f, 54.0f, true,  true, true,  110.0f,  3400.0f, 45.0f,  0.0f, true,  false, 0.45f, 50.0f, 0, 100.0f, true  },
    { "11. Triplet Groove Echo (1/8T - 1/4T)",            5, 0.0f, 0.0f, 33.0f, true, true, true, 2, 5, false, false, true,  true,  120.0f, 40.0f, true,  true, true,  160.0f,  2100.0f, 45.0f,  0.0f, true,  false, 1.00f, 50.0f, 0, 100.0f, true  },
    { "12. Lo-Fi Telephone Radio Echo",                   0, 0.0f, 1.0f, 40.0f, true, true, true, 4, 4, false, false, false, false, 120.0f, 35.0f, false, true, true,  750.0f,  1750.0f, 60.0f, 30.0f, true,  false, 1.50f, 45.0f, 1,  75.0f, true  },
    { "Vocal Support - FX Send", 5,0.0f,0.0f,100.0f,true,true,true,4,7,false,false,false,false,120.0f,25.0f,false,true,true,150.0f,3000.0f,20.0f,0.0f,false,false,1.0f,0.0f,0,100.0f,true },
    { "Vocal Slap - FX Send", 5,0.0f,0.0f,100.0f,true,true,false,1,3,false,false,false,false,125.0f,12.0f,false,true,true,150.0f,4500.0f,15.0f,0.0f,false,false,1.0f,0.0f,0,100.0f,true }

};

} // namespace tdelay

const std::vector<tdelay::FactoryPreset>& TDelayAudioProcessor::getFactoryPresets()
{
    return tdelay::kPresets;
}

juce::AudioProcessorValueTreeState::ParameterLayout TDelayAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // Exact 6 routing modes from Liquid Delays II x64.dll (0x18007add8..0x18007ae90)
    juce::StringArray fxModes {
        "Filters -> Drive -> Delays",
        "Filters -> Delays -> Drive",
        "Delays -> Drive -> Filters",
        "Delays -> Filters -> Drive",
        "Drive -> Delays -> Filters",
        "Drive -> Filters -> Delays"
    };
    params.push_back(std::make_unique<juce::AudioParameterChoice>("fxMode", "FX Mode", fxModes, 5));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "inputLevel", "Input Level",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "outputLevel", "Output Level",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "mix", "Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 35.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyLOn", "DLY L On/Off", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyROn", "DLY R On/Off", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlySync", "DLY Sync", true));

    juce::StringArray syncChoices;
    for (const auto& d : tdelay::kSyncDivisions)
        syncChoices.add(d.label);

    params.push_back(std::make_unique<juce::AudioParameterChoice>("dlyLXTime", "DLY L-XTime", syncChoices, 7));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("dlyRXTime", "DLY R-XTime", syncChoices, 4));

    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyLDot", "DLY L-Dot", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyRDot", "DLY R-Dot", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyLTri", "DLY L-Tri", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyRTri", "DLY R-Tri", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "dlyTempo", "DLY Tempo",
        juce::NormalisableRange<float>(40.0f, 500.0f, 0.1f), 145.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "dlyFeedback", "DLY Feedback",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 33.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("inLoop", "InLoop", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("filterOn", "Filter", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("hdFilter", "HDFilter", true));

    // Exact Low Cut (22..11025 Hz, curveType 8 exponential) & High Cut (501.14..22050 Hz, curveType 8 exponential)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lowCut", "Low Cut",
        juce::NormalisableRange<float>(22.0f, 11025.0f, 0.01f, 0.30f), 104.09f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "highCut", "High Cut",
        juce::NormalisableRange<float>(501.14f, 22050.0f, 0.1f, 0.35f), 1250.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "resonance", "Resonance",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 50.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "overdrive", "Overdrive",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("lfoOn", "LFO", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("lfoSync", "LFO Sync", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lfoRate", "LFO Rate",
        juce::NormalisableRange<float>(0.05f, 22.0f, 0.01f, 0.35f), 1.00f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lfoDepth", "LFO Depth",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 50.0f));

    juce::StringArray lfoWaves { "Sine", "Triangle", "Pulse", "Saw Up", "Saw Down" };
    params.push_back(std::make_unique<juce::AudioParameterChoice>("lfoWave", "LFO Wave", lfoWaves, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "stereoWidth", "Stereo Width",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("peakLimit", "PeakLimit", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("bypass", "Bypass", false));

    return { params.begin(), params.end() };
}

TDelayAudioProcessor::TDelayAudioProcessor()
    : AudioProcessor(BusesProperties().withInput("Input",juce::AudioChannelSet::stereo(),true)
                     .withOutput("Output",juce::AudioChannelSet::stereo(),true)),
      apvts(*this,nullptr,"TDelayParameters",createParameterLayout())
{
    setCurrentProgram(0);
}

void TDelayAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    juce::ignoreUnused(samplesPerBlock);
    const double sr = std::isfinite(sampleRate) && sampleRate >= 8000.0 ? sampleRate : 44100.0;
    lowCutFilter.prepare(sr);
    highCutFilter.prepare(sr);
    overdrive.prepare(sr);
    delayLine.prepare(sr);
    lfo.prepare(sr);
    brickWallLimiter.prepare(sr);
    lastLfoOut = 0.0f;
    filterModCounter = 0;
    // Exact meter decay from 0x18000d26b..0x18000d29c: 1.0 / pow(10.0, 1.0 / (sr * 0.8))
    meterDecayCoeff = 1.0 / std::pow(10.0, 1.0 / (sr * 0.8));
}

void TDelayAudioProcessor::releaseResources()
{
    delayLine.reset();
    lowCutFilter.reset();
    highCutFilter.reset();
    overdrive.reset();
    lfo.reset();
    brickWallLimiter.reset();
}

bool TDelayAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    const auto in  = layouts.getMainInputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return in == out || in == juce::AudioChannelSet::mono();
}

int TDelayAudioProcessor::getNumPrograms()
{
    return static_cast<int>(tdelay::kPresets.size());
}

const juce::String TDelayAudioProcessor::getProgramName(int index)
{
    if (index >= 0 && index < static_cast<int>(tdelay::kPresets.size()))
        return juce::String::fromUTF8(tdelay::kPresets[static_cast<size_t>(index)].name);
    return {};
}

void TDelayAudioProcessor::changeProgramName(int, const juce::String&) {}

void TDelayAudioProcessor::setCurrentProgram(int index)
{
    if (index < 0 || index >= static_cast<int>(tdelay::kPresets.size()))
        return;
    currentPresetIndex = index;
    const auto& p = tdelay::kPresets[static_cast<size_t>(index)];

    auto setVal = [this](const char* id, float plainVal)
    {
        if (auto* param = apvts.getParameter(id))
            param->setValueNotifyingHost(param->convertTo0to1(plainVal));
    };

    setVal("fxMode",      static_cast<float>(p.fxMode));
    setVal("inputLevel",  p.inputDb);
    setVal("outputLevel", p.outputDb);
    setVal("mix",         p.mixPct);
    setVal("dlyLOn",      p.dlyLOn ? 1.0f : 0.0f);
    setVal("dlyROn",      p.dlyROn ? 1.0f : 0.0f);
    setVal("dlySync",     p.dlySync ? 1.0f : 0.0f);
    setVal("dlyLXTime",   static_cast<float>(p.dlyLXTime));
    setVal("dlyRXTime",   static_cast<float>(p.dlyRXTime));
    setVal("dlyLDot",     p.dlyLDot ? 1.0f : 0.0f);
    setVal("dlyRDot",     p.dlyRDot ? 1.0f : 0.0f);
    setVal("dlyLTri",     p.dlyLTri ? 1.0f : 0.0f);
    setVal("dlyRTri",     p.dlyRTri ? 1.0f : 0.0f);
    setVal("dlyTempo",    p.dlyTempo);
    setVal("dlyFeedback", p.dlyFeedback);
    setVal("inLoop",      p.inLoop ? 1.0f : 0.0f);
    setVal("filterOn",    p.filterOn ? 1.0f : 0.0f);
    setVal("hdFilter",    p.hdFilter ? 1.0f : 0.0f);
    setVal("lowCut",      p.lowCutHz);
    setVal("highCut",     p.highCutHz);
    setVal("resonance",   p.resonancePct);
    setVal("overdrive",   p.overdrivePct);
    setVal("lfoOn",       p.lfoOn ? 1.0f : 0.0f);
    setVal("lfoSync",     p.lfoSync ? 1.0f : 0.0f);
    setVal("lfoRate",     p.lfoRateHz);
    setVal("lfoDepth",    p.lfoDepthPct);
    setVal("lfoWave",     static_cast<float>(p.lfoWave));
    setVal("stereoWidth", p.stereoWidth);
    setVal("peakLimit",   p.peakLimit ? 1.0f : 0.0f);
}

// 100% Bit-Accurate Decompiled CNomadVST::processReplacing from Liquid Delays II x64.dll (0x18000dc70..0x18000f0ce)
void TDelayAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;
    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    for (int i = getTotalNumInputChannels(); i < getTotalNumOutputChannels(); ++i)
        buffer.clear(i, 0, numSamples);

    if (numSamples <= 0 || numChannels <= 0)
        return;



    const bool bypass = apvts.getRawParameterValue("bypass")->load() > 0.5f;
    if (bypass)
    {
        if (getTotalNumInputChannels() == 1 && numChannels > 1) buffer.copyFrom(1, 0, buffer, 0, 0, numSamples);
        return;
    }

    const double sr = std::isfinite(getSampleRate()) && getSampleRate() >= 8000.0 ? getSampleRate() : 44100.0;

    // 1. Input/Output Level & Mix (0x18000dd7e..0x18000de33)
    const double inDb    = static_cast<double>(apvts.getRawParameterValue("inputLevel")->load());
    const double outDb   = static_cast<double>(apvts.getRawParameterValue("outputLevel")->load());
    const double inGain  = std::exp(inDb * 0.11512925465);  // 0x18000ddae
    const double outGain = std::exp(outDb * 0.11512925465); // 0x18000dddf
    const double wetMix  = juce::jlimit(0.0, 1.0, static_cast<double>(apvts.getRawParameterValue("mix")->load()) * 0.01);
    const double dryMix  = 1.0 - wetMix;

    // 2. Filter, Overdrive, Stereo Width, InLoop, FX Mode (0x18000de39..0x18000df01)
    const bool filterOn  = apvts.getRawParameterValue("filterOn")->load() > 0.5f;
    const float driveNorm = juce::jlimit(0.0f, 1.0f, apvts.getRawParameterValue("overdrive")->load() * 0.01f);
    if (driveNorm > 0.01f)
        overdrive.setDrive(driveNorm);

    const bool peakLimit = apvts.getRawParameterValue("peakLimit")->load() > 0.5f;
    const double stereoWidthNorm = juce::jlimit(0.0, 1.0, static_cast<double>(apvts.getRawParameterValue("stereoWidth")->load()) * 0.01);
    const double widthInv = 1.0 - stereoWidthNorm; // [rsp+0x78] at 0x18000debb

    // InLoop (param 25, 0x18000deaf): 1.0 when In-Loop is ON, 0.0 when OFF
    const double inLoopGain = (apvts.getRawParameterValue("inLoop")->load() > 0.5f) ? 1.0 : 0.0;
    const int fxMode = juce::jlimit(0, 5, static_cast<int>(apvts.getRawParameterValue("fxMode")->load()));

    // 3. LFO setup (0x18000dee6..0x18000e0e0)
    const bool lfoOn       = apvts.getRawParameterValue("lfoOn")->load() > 0.5f;
    const bool lfoSync     = apvts.getRawParameterValue("lfoSync")->load() > 0.5f;
    const float lfoRateHz  = juce::jlimit(0.05f, 22.0f, apvts.getRawParameterValue("lfoRate")->load());
    const float lfoDepth   = juce::jlimit(0.0f, 1.0f, apvts.getRawParameterValue("lfoDepth")->load() * 0.01f);
    const int lfoWave      = juce::jlimit(0, 4, static_cast<int>(apvts.getRawParameterValue("lfoWave")->load()));
    const float lfoRateNorm = static_cast<float>(std::log(lfoRateHz / 0.05f) / std::log(440.0f));

    // Query host BPM for LFO Sync / DLY Sync (0x18000c590)
    const double manualBpm = juce::jlimit(40.0, 500.0, static_cast<double>(apvts.getRawParameterValue("dlyTempo")->load()));
    double hostBpm = manualBpm;
    if (auto* playHead = getPlayHead())
    {
        if (auto pos = playHead->getPosition())
        {
            if (auto bpmOpt = pos->getBpm())
            {
                if (std::isfinite(*bpmOpt) && *bpmOpt > 0.0)
                    hostBpm = *bpmOpt;
            }
        }
    }

    const float effectiveLfoRate = lfoSync ? static_cast<float>(hostBpm / 60.0) : lfoRateHz;
    lfo.setParameters(effectiveLfoRate, lfoDepth, static_cast<float>(lfoWave) * 0.25f, lfoSync, lfoRateNorm);

    // 4. Filter cutoff & resonance modulation by LFO (0x18000df3a..0x18000e1b0)
    // Convert Low Cut (22..11025 Hz) and High Cut (501.136..22050 Hz) to exact curveType-8 normalized [0..1]
    const double rawLowCutHz  = juce::jlimit(22.0, 11025.0, static_cast<double>(apvts.getRawParameterValue("lowCut")->load()));
    const double rawHighCutHz = juce::jlimit(501.13635, 22050.0, static_cast<double>(apvts.getRawParameterValue("highCut")->load()));
    double lowCutNorm  = std::log(rawLowCutHz / 22.0) / std::log(11025.0 / 22.0);
    double highCutNorm = std::log(rawHighCutHz / 501.13635) / std::log(22050.0 / 501.13635);
    double resNorm     = juce::jlimit(0.0, 1.0, static_cast<double>(apvts.getRawParameterValue("resonance")->load()) * 0.01);

    // Exact LFO filter modulation from 0x18000e0fe..0x18000e125:
    // When LFO is ON, Low Cut, High Cut, and Resonance normalized values are blended 50/50 with lfoOut!
    if (lfoOn)
    {
        const double lfoMod = static_cast<double>(lastLfoOut) * 0.5;
        lowCutNorm  = lowCutNorm  * 0.5 + lfoMod;
        highCutNorm = highCutNorm * 0.5 + lfoMod;
        resNorm     = resNorm     * 0.5 + lfoMod;
    }

    const double resDB = resNorm * 20.0; // 0x18000e136: mulsd xmm14, 20.0
    // 0x18000e15e..0x18000e1ae: Low Cut uses [22.0, 8000.0 Hz], High Cut uses [600.0, 22000.0 Hz]
    if (!lfoOn)
    {
        lowCutFilter.setFilterFromNormalized(lowCutNorm, resDB, sr, 22.0, 11025.0);
        highCutFilter.setFilterFromNormalized(highCutNorm, resDB, sr, 501.13635, 22050.0);
    }

    // 5. Delay Line setup (0x18000e1b1..0x18000e42b)
    const bool dlyLOn   = apvts.getRawParameterValue("dlyLOn")->load() > 0.5f;
    const bool dlyROn   = apvts.getRawParameterValue("dlyROn")->load() > 0.5f;
    const bool dlySync  = apvts.getRawParameterValue("dlySync")->load() > 0.5f;
    const int dlyLXIdx  = juce::jlimit(0, 21, static_cast<int>(apvts.getRawParameterValue("dlyLXTime")->load()));
    const int dlyRXIdx  = juce::jlimit(0, 21, static_cast<int>(apvts.getRawParameterValue("dlyRXTime")->load()));
    const bool dlyLDot  = apvts.getRawParameterValue("dlyLDot")->load() > 0.5f;
    const bool dlyRDot  = apvts.getRawParameterValue("dlyRDot")->load() > 0.5f;
    const bool dlyLTri  = apvts.getRawParameterValue("dlyLTri")->load() > 0.5f;
    const bool dlyRTri  = apvts.getRawParameterValue("dlyRTri")->load() > 0.5f;

    const float fbNorm  = juce::jlimit(0.0f, 1.0f, apvts.getRawParameterValue("dlyFeedback")->load() * 0.01f);

    delayLine.setChannelOnOff(0, dlyLOn);
    delayLine.setChannelOnOff(1, dlyROn);
    delayLine.setFeedback(fbNorm);

    // Exact divisor calculation from 0x18000e288..0x18000e427
    double divL = tdelay::kSyncDivisions[static_cast<size_t>(dlyLXIdx)].beatDivisor;
    double divR = tdelay::kSyncDivisions[static_cast<size_t>(dlyRXIdx)].beatDivisor;
    if (dlyLDot) divL /= 1.5;
    if (dlyRDot) divR /= 1.5;
    if (dlyLTri) divL *= 1.5;
    if (dlyRTri) divR *= 1.5;

    const double activeBpm = dlySync ? hostBpm : manualBpm;
    const double beatMs = 60000.0 / std::max(20.0, activeBpm);
    const double delayMsL = juce::jlimit(1.0, 9990.0, beatMs / divL);
    const double delayMsR = juce::jlimit(1.0, 9990.0, beatMs / divR);

    currentDelayMsL.store(static_cast<float>(delayMsL), std::memory_order_relaxed);
    currentDelayMsR.store(static_cast<float>(delayMsR), std::memory_order_relaxed);

    delayLine.setTargetDelayMs(0, delayMsL);
    delayLine.setTargetDelayMs(1, delayMsR);

    // 6. Sample-by-sample processing loop (0x18000e460..0x18000f03d)
    float* chL = buffer.getWritePointer(0);
    float* chR = (numChannels > 1) ? buffer.getWritePointer(1) : chL;

    float inPeakL  = meterInL.load(std::memory_order_relaxed);
    float inPeakR  = meterInR.load(std::memory_order_relaxed);
    float outPeakL = meterOutL.load(std::memory_order_relaxed);
    float outPeakR = meterOutR.load(std::memory_order_relaxed);

    auto runFilters = [&](int c, float s) noexcept -> float
    {
        if (!filterOn)
            return s;
        float out = lowCutFilter.processSample(c, s, true);
        out = highCutFilter.processSample(c, out, false);
        return out;
    };

    auto runDrive = [&](int c, float s) noexcept -> float
    {
        if (driveNorm <= 0.01f)
            return s;
        return overdrive.processSample(c, s);
    };

    auto runDelays = [&](int c, float s) noexcept -> float
    {
        const float delayed = delayLine.processSample(c, s);
        const bool enabled = c == 0 ? dlyLOn : dlyROn;
        return enabled ? static_cast<float>(static_cast<double>(delayed) + static_cast<double>(s) * inLoopGain) : delayed;
    };

    for (int i = 0; i < numSamples; ++i)
    {
        // Advance LFO per sample (0x18000e46c)
        lastLfoOut = lfo.tick(0);

        // Update filter cutoffs dynamically every 16 samples when LFO is active for smooth liquid sweep
        if (lfoOn && ((filterModCounter++ & 15u) == 0))
        {
            const double lfoMod = static_cast<double>(lastLfoOut) * 0.5;
            const double modLow  = std::log(rawLowCutHz / 22.0) / std::log(11025.0 / 22.0) * 0.5 + lfoMod;
            const double modHigh = std::log(rawHighCutHz / 501.13635) / std::log(22050.0 / 501.13635) * 0.5 + lfoMod;
            const double modRes  = (juce::jlimit(0.0, 1.0, static_cast<double>(apvts.getRawParameterValue("resonance")->load()) * 0.01) * 0.5 + lfoMod) * 20.0;
            lowCutFilter.setFilterFromNormalized(modLow, modRes, sr, 22.0, 11025.0);
            highCutFilter.setFilterFromNormalized(modHigh, modRes, sr, 501.13635, 22050.0);
        }

        const float rawL = std::isfinite(chL[i]) ? chL[i] : 0.0f;
        const float rawR = getTotalNumInputChannels() > 1 && numChannels > 1 ? (std::isfinite(chR[i]) ? chR[i] : 0.0f) : rawL;

        const float inL = static_cast<float>(static_cast<double>(rawL) * inGain);
        const float inR = static_cast<float>(static_cast<double>(rawR) * inGain);

        // Input level envelope meters (0x18000e51c..0x18000e545)
        inPeakL = (std::abs(inL) > inPeakL) ? std::abs(inL) : static_cast<float>(static_cast<double>(inPeakL) * meterDecayCoeff);
        inPeakR = (std::abs(inR) > inPeakR) ? std::abs(inR) : static_cast<float>(static_cast<double>(inPeakR) * meterDecayCoeff);

        std::array<float, 2> rawIn {{ rawL, rawR }};
        std::array<float, 2> proc  {{ inL,  inR  }};
        std::array<float, 2> mixed {{ 0.0f, 0.0f }};

        for (int c = 0; c < 2; ++c)
        {
            float x = proc[c];

            // Exact 6 FX Mode Routing Switch (0x18000e54b..0x18000ea05)
            switch (fxMode)
            {
                case 0: // Filters -> Drive -> Delays
                    x = runFilters(c, x);
                    x = runDrive(c, x);
                    x = runDelays(c, x);
                    break;

                case 1: // Filters -> Delays -> Drive
                    x = runFilters(c, x);
                    x = runDelays(c, x);
                    x = runDrive(c, x);
                    break;

                case 2: // Delays -> Drive -> Filters
                    x = runDelays(c, x);
                    x = runDrive(c, x);
                    x = runFilters(c, x);
                    break;

                case 3: // Delays -> Filters -> Drive
                    x = runDelays(c, x);
                    x = runFilters(c, x);
                    x = runDrive(c, x);
                    break;

                case 4: // Drive -> Delays -> Filters
                    x = runDrive(c, x);
                    x = runDelays(c, x);
                    x = runFilters(c, x);
                    break;

                case 5: // Drive -> Filters -> Delays (User Screenshot Mode)
                default:
                    x = runDrive(c, x);
                    x = runFilters(c, x);
                    x = runDelays(c, x);
                    break;
            }

            // Apply Output Gain and Mix with raw dry input (0x18000ea94..0x18000eb11)
            const double wetScaled = static_cast<double>(x) * outGain;
            mixed[c] = static_cast<float>(wetScaled * wetMix + static_cast<double>(rawIn[c]) * dryMix);
        }

        // Apply Stereo Width cross-mixing (0x18000ec0c..0x18000ec7c)
        const double cross = widthInv * 0.5;
        const double main  = 1.0 - cross;
        float outL = static_cast<float>(static_cast<double>(mixed[0]) * main + static_cast<double>(mixed[1]) * cross);
        float outR = static_cast<float>(static_cast<double>(mixed[1]) * main + static_cast<double>(mixed[0]) * cross);

        // Apply Peak Limiter (cubic soft-clip + LUT brickwall limiter, 0x18000ec9b..0x18000ef51)
        outL = brickWallLimiter.processSample(0, outL, peakLimit);
        outR = brickWallLimiter.processSample(1, outR, peakLimit);

        chL[i] = outL;
        if (numChannels > 1)
            chR[i] = outR;

        outPeakL = (std::abs(outL) > outPeakL) ? std::abs(outL) : static_cast<float>(static_cast<double>(outPeakL) * meterDecayCoeff);
        outPeakR = (std::abs(outR) > outPeakR) ? std::abs(outR) : static_cast<float>(static_cast<double>(outPeakR) * meterDecayCoeff);
    }

    meterInL.store((inPeakL + 1.0e-18f) - 1.0e-18f, std::memory_order_relaxed);
    meterInR.store((inPeakR + 1.0e-18f) - 1.0e-18f, std::memory_order_relaxed);
    meterOutL.store((outPeakL + 1.0e-18f) - 1.0e-18f, std::memory_order_relaxed);
    meterOutR.store((outPeakR + 1.0e-18f) - 1.0e-18f, std::memory_order_relaxed);
    meterLfo.store(lastLfoOut, std::memory_order_relaxed);
}

juce::AudioProcessorEditor* TDelayAudioProcessor::createEditor()
{
    return new TDelayAudioProcessorEditor(*this);
}

void TDelayAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    state.setProperty("factoryPresetIndex", currentPresetIndex.load(), nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void TDelayAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
    {
        auto state=juce::ValueTree::fromXml(*xmlState);
        currentPresetIndex.store(juce::jlimit(0,getNumPrograms()-1,static_cast<int>(state.getProperty("factoryPresetIndex",0))));
        apvts.replaceState(state);
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new TDelayAudioProcessor();
}



double TDelayAudioProcessor::getTailLengthSeconds() const
{
    const double seconds = std::max(currentDelayMsL.load(), currentDelayMsR.load()) * .001;
    const double feedback = apvts.getRawParameterValue("dlyFeedback")->load() * .01;
    if (feedback >= 1.0) return 600.0; // 100% feedback is a deliberate non-decaying loop.
    const double repeats = feedback > 0.0 ? 1.0 + std::ceil(std::log(1.e-6) / std::log(feedback)) : 1.0;
    return std::min(600.0, seconds * repeats);
}
