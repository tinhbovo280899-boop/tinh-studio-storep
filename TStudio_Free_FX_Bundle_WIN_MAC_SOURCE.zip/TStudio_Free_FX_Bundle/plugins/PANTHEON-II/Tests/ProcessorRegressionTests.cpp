#include "TPantheonProcessor.h"
#include <cstdio>
#include <limits>
#include <cmath>
#include <vector>
static int failures=0;
#define CHECK(x) do { if(!(x)){std::printf("FAIL line %d: %s\n",__LINE__,#x);++failures;} }while(0)

static void set(juce::AudioProcessorValueTreeState& v,const char* id,float value){auto* p=v.getParameter(id);CHECK(p);if(p)p->setValueNotifyingHost(p->convertTo0to1(value));}
int main(){juce::ScopedJuceInitialiser_GUI gui;
 TPantheonAudioProcessor p;p.setPlayConfigDetails(1,2,32000,128);p.prepareToPlay(32000,128);
 auto& v=p.getAPVTS();set(v,"mix",0);set(v,"inputLevel",0);set(v,"level",0);
 juce::AudioBuffer<float>b(2,128);juce::MidiBuffer m;for(int i=0;i<128;++i){b.setSample(0,i,-.25f);b.setSample(1,i,.9f);}p.processBlock(b,m);
 for(int i=0;i<128;++i){CHECK(std::abs(b.getSample(0,i)+.25f)<1e-6);CHECK(std::abs(b.getSample(1,i)+.25f)<1e-6);}
 set(v,"rt60",6.59f);CHECK(p.getTailLengthSeconds()>12);

 for(int preset=0;preset<p.getNumPrograms();++preset){p.setCurrentProgram(preset);p.releaseResources();p.prepareToPlay(32000,128);for(int k=0;k<6;++k){for(int i=0;i<128;++i){b.setSample(0,i,.1f*std::sin((i+k*128)*.2));b.setSample(1,i,0);}p.processBlock(b,m);for(int ch=0;ch<2;++ch)for(int i=0;i<128;++i)CHECK(std::isfinite(b.getSample(ch,i)));}}
 const int index=p.getNumPrograms()-1;p.setCurrentProgram(index);juce::MemoryBlock state;p.getStateInformation(state);TPantheonAudioProcessor q;q.setStateInformation(state.getData(),int(state.getSize()));CHECK(q.getCurrentProgram()==index);
 for(const auto* id:{"mix","inputLevel"})CHECK(std::abs(p.getAPVTS().getRawParameterValue(id)->load()-q.getAPVTS().getRawParameterValue(id)->load())<1e-6);
 std::unique_ptr<juce::AudioProcessorEditor> e(p.createEditor());CHECK(e!=nullptr);p.releaseResources();
 std::printf("TPantheonAudioProcessor mono/stereo, meters/tempo/tail, %d presets, state/editor: %d failures\n",p.getNumPrograms(),failures);
 return failures?1:0;}
