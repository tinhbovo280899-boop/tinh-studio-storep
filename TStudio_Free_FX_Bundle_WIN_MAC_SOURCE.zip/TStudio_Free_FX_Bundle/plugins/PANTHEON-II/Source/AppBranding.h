#pragma once
// Generated from ThuongHieu.json.
namespace AppBranding {
inline constexpr const char* kAppDisplayName = "PantheonII";
inline constexpr const char* kBrandWord1 = "PANTHEON";
inline constexpr const char* kBrandWord2 = "II";
inline constexpr const char* kBrandSubtitle = "LEXICON REVERB";
inline constexpr const char* kSplashLine2 = "LEXICON / NT STUDIO";
inline constexpr const char* kPublisher = "Lexicon";
inline constexpr const char* kAppVersion = "1.0.0";
inline constexpr const char* kExeName = "PantheonII.exe";
inline constexpr const char* kSetupName = "Setup_PantheonII";
}
