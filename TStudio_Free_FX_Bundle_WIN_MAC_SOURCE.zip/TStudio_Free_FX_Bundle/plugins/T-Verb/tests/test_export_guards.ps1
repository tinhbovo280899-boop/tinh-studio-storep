param([string]$Source=(Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference='Stop'
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('tak-export-test-'+[guid]::NewGuid().ToString('N'))
function Assert([bool]$Condition,[string]$Message){if(-not $Condition){throw $Message}}
function MustReject([scriptblock]$Work){$rejected=$false;try{& $Work}catch{$rejected=$true};Assert $rejected 'Unsafe/stale output was accepted'}
try {
    New-Item -ItemType Directory -Force -Path $fixture|Out-Null
    foreach($folder in @('src','keygen','cmake','tests','tools')){Copy-Item -LiteralPath (Join-Path $Source $folder) -Destination (Join-Path $fixture $folder) -Recurse}
    foreach($file in @('CMakeLists.txt','ThuongHieu.json','LICENSE','HUONG_DAN_KHACH.txt')){Copy-Item -LiteralPath (Join-Path $Source $file) -Destination $fixture}
    New-Item -ItemType Directory -Force -Path (Join-Path $fixture 'Installer'),(Join-Path $fixture 'config')|Out-Null
    Copy-Item -LiteralPath (Join-Path $Source 'Installer/T-Verb.iss') -Destination (Join-Path $fixture 'Installer/T-Verb.iss')
    [IO.File]::WriteAllText((Join-Path $fixture 'config/public_key.txt'),('10001,'+('a'*511)+'b'))
    $tokens=$null;$parseErrors=$null
    $ast=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path $Source 'tools/windows.ps1'),[ref]$tokens,[ref]$parseErrors)
    Assert ($parseErrors.Count -eq 0) 'Windows script syntax errors'
    foreach($statement in $ast.EndBlock.Statements){if($statement -is [System.Management.Automation.Language.FunctionDefinitionAst]){Invoke-Expression $statement.Extent.Text}}
    $Root=$fixture;$Config=Get-Content -LiteralPath (Join-Path $Root 'ThuongHieu.json') -Raw -Encoding UTF8|ConvertFrom-Json
    $Build=Join-Path $Root 'build';$Export=Join-Path $Root '_EXPORT_WIN';$StoreName=[string]$Config.productId+'-'+[string]$Config.licenseBrand;$BundleName=[string]$Config.productName+'.vst3';$Log=Join-Path $Root 'test.log'
    $bundle=Join-Path $Build ('fake/VST3/'+$BundleName)
    $binary=Join-Path $bundle 'Contents/x86_64-win/fake.vst3'
    New-Item -ItemType Directory -Force -Path (Split-Path $binary)|Out-Null
    [IO.File]::WriteAllText($binary,'test plugin payload')
    @{sourceHash=(SourceHash);bundle=$bundle;files=(FileList $bundle)}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Build 'tak-build.json') -Encoding UTF8
    ExportFiles;VerifyExport
    $extra=Join-Path $Export 'unexpected.txt';[IO.File]::WriteAllText($extra,'unexpected');MustReject {VerifyExport};Remove-Item -LiteralPath $extra
    $exportBinary=Join-Path $Export ('VST3/'+$BundleName+'/Contents/x86_64-win/fake.vst3')
    [IO.File]::WriteAllText($exportBinary,'modified output');MustReject {VerifyExport};ExportFiles;VerifyExport
    $sourceFile=Join-Path $Root 'src/Plugin.cpp';$old=[IO.File]::ReadAllBytes($sourceFile);[IO.File]::AppendAllText($sourceFile,"`n// changed");MustReject {VerifyExport};[IO.File]::WriteAllBytes($sourceFile,$old);VerifyExport
    $privateDir=Join-Path $Root ('KhoaBanQuyen/'+$StoreName);New-Item -ItemType Directory -Force -Path $privateDir|Out-Null
    $fakePrivate=('b'*1024)+','+('c'*512);[IO.File]::WriteAllText((Join-Path $privateDir 'PRIVATE_KEY.txt'),$fakePrivate)
    [IO.File]::WriteAllText($binary,$fakePrivate)
    @{sourceHash=(SourceHash);bundle=$bundle;files=(FileList $bundle)}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Build 'tak-build.json') -Encoding UTF8
    MustReject {ExportFiles}
    Assert ([IO.File]::ReadAllText($exportBinary) -eq 'test plugin payload') 'Failed export replaced the last good customer output'
    $leak=Join-Path $Export 'PRIVATE_KEY.txt';[IO.File]::WriteAllText($leak,'test');MustReject {GuardCustomerFiles $Export}
    Write-Host 'EXPORT GUARD TESTS PASSED: checksums, stale source, extra files, private material, atomic staging'
}finally{if(Test-Path -LiteralPath $fixture){Remove-Item -LiteralPath $fixture -Recurse -Force}}
