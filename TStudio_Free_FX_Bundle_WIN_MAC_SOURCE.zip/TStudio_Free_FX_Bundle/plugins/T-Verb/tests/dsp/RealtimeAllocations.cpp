#include <atomic>
#include <cstdlib>
#include <new>
#include <iostream>
static std::atomic<int> allocationCount{0};
static bool track=false;
void* operator new(std::size_t n) { if(track) ++allocationCount; if(auto p=std::malloc(n?n:1))return p;throw std::bad_alloc(); }
void operator delete(void* p) noexcept {std::free(p);}
void operator delete(void* p,std::size_t) noexcept {std::free(p);}
void* operator new[](std::size_t n) {return ::operator new(n);}
void operator delete[](void* p) noexcept {std::free(p);}
void operator delete[](void* p,std::size_t) noexcept {std::free(p);}
#include "ArtsAcousticParameters.h"
int main(){
    ArtsAcoustic::ArtsAcousticPluginWrapper p(48000,512);
    std::vector<float> l(512,0),r(512,0);float* io[2]={l.data(),r.data()};
    for(int i=0;i<10;++i)p.processReplacing(io,io,512);
    allocationCount=0;track=true;
    for(int i=0;i<50;++i)p.processReplacing(io,io,512);
    track=false;
    const int steady=allocationCount.load();
    std::cout<<"Allocations in 50 warmed-up audio callbacks: "<<steady<<std::endl;
    // Exercise quality changes and all parameter endpoints with preallocated
    // maximum-quality storage. Hosts may also exceed their announced block size.
    std::vector<float> largeL(2048,0),largeR(2048,0);
    float* largeIO[2]={largeL.data(),largeR.data()};
    allocationCount=0;track=true;
    for(int id=0;id<ArtsAcoustic::kNumVstParameters;++id)for(float value:{0.f,1.f}){
        p.setParameter(id,value);p.processReplacing(io,io,512);
    }
    p.processReplacing(largeIO,largeIO,2048);
    track=false;
    const int automated=allocationCount.load();
    std::cout<<"Allocations while changing parameters/quality and processing an oversized block: "<<automated<<std::endl;
    return steady||automated?1:0;
}
