#include "VerbProcessor.h"
#include "VerbEditor.h"

juce::AudioProcessorEditor* tverb::Processor::createEditor() { return new Editor (*this); }

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new tverb::Processor(); }
