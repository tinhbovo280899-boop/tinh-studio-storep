# T Studio Free FX Bundle

Một gói nguồn, một lần build, một bộ cài gồm **4 VST3 riêng**:

- T-Verb — vang dài và preset Vocal Mềm Nhẹ FX Send.
- T-RVerb — vang ngắn, có các sửa lỗi an toàn/state/predelay từ đợt trước.
- PANTHEON II — thêm preset vang ngắn FX Send.
- LIQUID Delays II — chuyển Time/BPM trong 20 ms, có preset FX Send.

Bản free này đã **gỡ mã kiểm tra kích hoạt, hạn dùng thử, mã máy, giao diện nhập key và công cụ sinh key của dự án**. Không cần đăng nhập, key hoặc kết nối mạng để sử dụng plugin đã build. Không đổi DSP, plugin ID, ID tham số hoặc thứ tự preset so với bốn bản vừa sửa. Tên/ID từng plugin được giữ để đọc project cũ; đây là gói của các dự án nguồn người dùng cung cấp, không phải bộ cài chính hãng được xác minh.

## Windows x64

Cần Visual Studio với workload **Desktop development with C++**, CMake 3.22+; tạo bộ cài cần **Inno Setup 6.3+**.

- `1_BUILD_WINDOWS.bat`: build 4 VST3 và chạy kiểm thử.
- `2_TAO_BO_CAI_WINDOWS.bat`: tạo bộ cài từ kết quả build đã được kiểm tra.
- `3_BUILD_VA_TAO_BO_CAI_WINDOWS.bat`: chạy cả hai bước.

File dùng thử/cấp key cũ không còn trong menu. Kết quả plugin ở `_EXPORT/VST3`, bộ cài ở `_INSTALLERS/Setup_TStudio_FreeFX_WIN_x64.exe`. Bộ cài cài cả bốn vào thư mục VST3 chung chuẩn Windows. Đóng DAW trước khi cài để plugin cũ không giữ khóa file. Nếu cần gỡ các bộ cài riêng cũ, gỡ trước khi cài bộ này để trình gỡ cũ không xóa file vừa thay.

## macOS Intel + Apple Silicon

Cần Xcode Command Line Tools (`xcode-select --install`) và CMake 3.22+.

- `1_BUILD_MAC.command`: build Universal, chạy kiểm thử.
- `2_TAO_BO_CAI_MAC.command`: tạo `.pkg` từ kết quả build đã được kiểm tra.
- `3_BUILD_VA_TAO_BO_CAI_MAC.command`: chạy cả hai bước.

Kết quả `_INSTALLERS/TStudio_FreeFX_MAC_Universal.pkg`, cài vào `/Library/Audio/Plug-Ins/VST3`. Plugin được ký ad-hoc trong quy trình tạo gói; chưa cấu hình Developer ID/notarization. Metadata/checksum của payload được tạo lại sau khi ký. Đây là VST3, không bao gồm AU hay ứng dụng Standalone.

## Nội dung và giấy phép

JUCE 8.0.12 đi kèm một bản dùng chung trong `third_party/JUCE`; không cần tải lại JUCE riêng cho từng plugin. Mã plugin nằm trong `plugins`. Xem `docs/THAY_DOI_FREE.md` về phạm vi thay đổi và `docs/THIRD_PARTY_NOTICES.md` về giấy phép thư viện/font. Gỡ cơ chế kích hoạt của dự án không thay đổi giấy phép của JUCE hoặc các tài nguyên khác.

Các file trong `_EXPORT` phải giữ nguyên để tạo bộ cài. Nếu thiếu một plugin, sai hệ điều hành/kiến trúc hoặc checksum thay đổi, script dừng và yêu cầu build lại. Không tự đóng DAW, không xóa dữ liệu license hoặc preset đã cài trên máy.

Kết quả kiểm thử thực tế và giới hạn nền tảng xem `VALIDATION`. ZIP nguồn này chưa phải file `.exe`/`.pkg` đã build native Windows/macOS.
