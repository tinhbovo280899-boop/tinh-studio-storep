# Thay đổi trong bản Free Bundle

Giữ nguyên toàn bộ file engine/DSP và factory preset từ bốn bản đã sửa. Bỏ các lớp kiểm tra activation của dự án, nhánh chặn audio khi hết trial, timer/worker chỉ dùng để poll license, hộp nhập key, mã máy, public/private key của hệ thống kích hoạt và tool sinh key. Timer T-Verb phục vụ cập nhật tham số về host vẫn được giữ.

T-Verb hiển thị FREE ở vị trí nút kích hoạt cũ. Utility của LIQUID chỉ hiển thị thông tin free và hướng dẫn FX Send. PANTHEON không còn overlay và thao tác mở bảng activation.

Các plugin vẫn tách riêng khi DAW scan; không gộp bốn engine nối tiếp trong một plugin. ID/bundle ID/manufacturer code và bố cục tham số được giữ để mở lại project cũ. Bản free có thể thay thế cùng plugin đã cài; nên giữ bản sao project/plugin để so sánh trước khi thay.

Giới hạn DSP trước đó vẫn giữ: PANTHEON có một mạng Chamber, HDFilter của LIQUID chưa có DSP riêng, không thêm ping-pong/tối dần mới. Đợt này chỉ thay activation và cách đóng gói. Preset FX Send mới nằm cuối danh sách.

Luồng build chung: chuẩn bị một SDK JUCE dùng chung → build từng VST3 → chạy test của từng dự án → kiểm tra đủ bốn bundle đúng nền tảng → xuất staging nguyên bộ → tạo bộ cài bằng ISCC/pkgbuild trên nền tảng tương ứng. Lỗi giữa chừng không ghi đè export cũ bằng một bộ thiếu plugin.
