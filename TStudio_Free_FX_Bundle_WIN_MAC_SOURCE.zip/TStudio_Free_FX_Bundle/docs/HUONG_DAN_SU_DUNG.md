# Dùng bộ Free FX

Bốn plugin chạy riêng trong DAW, không có nhập key hay hạn dùng thử: T-Verb, T-RVerb, PantheonII và Liquid Delays II.

Sau khi cài, mở lại DAW và rescan VST3 nếu cần. Windows dùng thư mục Common Files/VST3 chuẩn; macOS dùng /Library/Audio/Plug-Ins/VST3.

Các preset thêm ở cuối danh sách có chữ FX Send. Để dùng trên FX Send/AUX:

- T-Verb: chọn Vocal Mềm Nhẹ - Giữ Đuôi - FX Send; Dry tắt/-∞, chỉnh lượng bằng send/return.
- T-RVerb: chọn Vocal Short - FX Send hoặc Vocal Soft Plate - FX Send; Wet/Dry 100%.
- PantheonII: chọn Vocal Short - FX Send hoặc Vocal Body - FX Send; Mix 100%.
- Liquid Delays II: chọn Vocal Support - FX Send hoặc Vocal Slap - FX Send; Mix 100%, InLoop Off, cả delay L/R On.

Độ mềm/quyện cần nghe theo vocal và bài hát. Giữ bản sao project/plugin cũ để so. Các preset gốc vẫn ở đúng vị trí trước đây.

Bộ này không tự thay ASIO buffer và không đồng bộ mọi plugin thành một chuỗi xử lý duy nhất. Chọn vị trí từng effect trong project như bình thường.
