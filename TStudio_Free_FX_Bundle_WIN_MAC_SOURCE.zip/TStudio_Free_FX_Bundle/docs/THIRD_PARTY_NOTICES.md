# Thư viện và tài nguyên

JUCE 8.0.12: bản nguồn và giấy phép trong `third_party/JUCE/LICENSE.md` và các notice đi kèm cây JUCE. Bản sao các file LICENSE/COPYING/COPYRIGHT nằm trong `ThirdParty/` cạnh tài liệu này để đi kèm bộ cài. Việc build/phân phối plugin với JUCE vẫn phải đáp ứng giấy phép JUCE áp dụng cho người phát hành; không biến JUCE thành mã public domain.

Font DejaVu trong T-Verb: xem `FONT_LICENSE.txt` kèm tài liệu này và `plugins/T-Verb/resources/FONT_LICENSE.txt`.

Giữ nguyên các notice bản quyền/thư viện trong nguồn. Các tên/tài nguyên tham chiếu thương hiệu trong dự án do người dùng cung cấp không phải xác nhận tương đương thuật toán hay liên kết chính thức với sản phẩm thương mại đó.
