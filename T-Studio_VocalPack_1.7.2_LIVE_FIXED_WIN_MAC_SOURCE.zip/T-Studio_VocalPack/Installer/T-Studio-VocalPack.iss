; One customer installer for the whole pack: T-AutoKey + T-AutoTune (VST3 x64).
; Only the verified export is packaged (no keys, no keygen).
#include "generated\Config.iss"
#define ExportDir SourcePath + "\..\_EXPORT_WIN"
[Setup]
AppId={#MyAppId}
AppName={#MyName}
AppVersion={#MyVersion}
AppPublisher={#MyPublisher}
DefaultDirName={commonappdata}\{#MyPublisher}\{#MyName}
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes
RestartApplications=no
OutputDir=..\Output
OutputBaseFilename=Setup_{#MyFileName}_{#MyVersion}_Win64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#MyName} (T-AutoKey + T-AutoTune)
LicenseFile=..\LICENSE

[Types]
Name: "full"; Description: "Cai ca 2 plugin (khuyen nghi)"
Name: "custom"; Description: "Tu chon"; Flags: iscustom

[Components]
Name: "autokey"; Description: "{#AutoKeyBundle} - do tong tu dong"; Types: full custom
Name: "autotune"; Description: "{#AutoTuneBundle} - chinh cao do"; Types: full custom

[InstallDelete]
; Older single-product builds used a different bundle name for the same plugin.
Type: filesandordirs; Name: "{commoncf64}\VST3\T-AUTO TUNE.vst3"; Components: autotune

[Files]
Source: "{#ExportDir}\VST3\{#AutoKeyBundle}\*"; DestDir: "{commoncf64}\VST3\{#AutoKeyBundle}"; Components: autokey; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#ExportDir}\VST3\{#AutoTuneBundle}\*"; DestDir: "{commoncf64}\VST3\{#AutoTuneBundle}"; Components: autotune; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#ExportDir}\HUONG_DAN_KHACH.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ExportDir}\LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ExportDir}\FONT_LICENSE_Inter.txt"; DestDir: "{app}"; Flags: ignoreversion

[Messages]
WelcomeLabel1=Chao mung den voi bo cai {#MyName}
WelcomeLabel2=Bo cai chep 2 plugin VST3 (T-AutoKey va T-AutoTune) vao thu muc plugin he thong.%n%nHay dong Cubase/FL Studio va cac DAW truoc khi cai.
FinishedLabel=Da cai {#MyName}. Mo DAW, quet lai VST3 neu can. Dung thu 7 ngay tu bat dau khi mo plugin lan dau; bam banh rang > Ban quyen & Kich hoat de nhap key. Mot key dung cho ca 2 plugin.
; License/trial data is stored outside the install tree and survives an uninstall.
