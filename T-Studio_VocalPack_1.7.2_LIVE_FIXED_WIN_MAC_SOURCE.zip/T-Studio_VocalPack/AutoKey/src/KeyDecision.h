// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>

// A winning analysis frame is a proposal, not permission to retune a voice.
// Times count accepted tonal evidence, never wall-clock time or silence.
class KeyDecision
{
public:
    static constexpr double initialSeconds = 2.5;
    static constexpr double changeSeconds = 5.0;
    static constexpr double relativeChangeSeconds = 6.0;
    static constexpr double ambiguityGraceSeconds = 0.30;

    void reset() noexcept { locked = -1; interrupt(); }
    void interrupt() noexcept { candidate = -1; candidateSeconds = uncertainSeconds = 0.0; }
    void setHold (bool enabled) noexcept
    {
        if (hold != enabled) interrupt();
        hold = enabled;
    }
    int key() const noexcept { return locked; }

    // Scores are heuristic key-template scores; they are not probabilities.
    bool update (const std::array<double, 24>& scores, double seconds) noexcept
    {
        if (! std::isfinite (seconds) || seconds <= 0.0 || seconds > 0.5)
        { interrupt(); return false; }
        if (hold && locked >= 0) { interrupt(); return false; }
        int best = -1, second = -1;
        for (int i = 0; i < 24; ++i)
        {
            if (! std::isfinite (scores[(std::size_t) i])) { interrupt(); return false; }
            if (best < 0 || scores[(std::size_t) i] > scores[(std::size_t) best])
            { second = best; best = i; }
            else if (second < 0 || scores[(std::size_t) i] > scores[(std::size_t) second]) second = i;
        }
        const double gap = scores[(std::size_t) best] - scores[(std::size_t) second];
        const double lead = locked >= 0 ? scores[(std::size_t) best] - scores[(std::size_t) locked] : gap;
        // Before the first lock, the same leading key may keep contributing at
        // a slightly lower margin. It must first establish the normal margin;
        // weak evidence accumulates more slowly and cannot start a candidate.
        const double minimumGap = locked < 0 && candidate == best ? 0.04 : 0.06;
        // A clear return to the current key cancels a modulation immediately.
        if (best == locked && gap >= 0.06) { interrupt(); return false; }
        if (best == locked || scores[(std::size_t) best] < 0.25 || gap < minimumGap
            || (locked >= 0 && lead < 0.10))
        {
            // Chord boundaries can briefly weaken the margin. They add no
            // confirmation and lose evidence; a long uncertain passage resets it.
            uncertainSeconds += seconds;
            candidateSeconds = std::max (0.0, candidateSeconds - 0.5 * seconds);
            if (uncertainSeconds > ambiguityGraceSeconds + 1.0e-9) interrupt();
            return false;
        }

        if (candidate != best) { candidate = best; candidateSeconds = 0.0; }
        uncertainSeconds = 0.0;
        const bool relative = locked >= 0 && isRelativePair (locked, best);
        // Only a large lead over BOTH the runner-up and the current key can
        // speed up a normal change. Even perfect evidence needs four seconds.
        const double strength = std::clamp (std::min ((gap - 0.12) / 0.10,
                                                      (lead - 0.18) / 0.14), 0.0, 1.0);
        const double speed = locked < 0 ? std::min (1.0, gap / 0.06)
                           : ! relative ? 1.0 + 0.25 * strength : 1.0;
        candidateSeconds += seconds * speed;
        const double required = locked < 0 ? initialSeconds
                              : relative ? relativeChangeSeconds : changeSeconds;
        if (candidateSeconds + 1.0e-9 < required) return false;
        locked = best;
        interrupt();
        return true;
    }

private:
    static bool isRelativePair (int a, int b) noexcept
    {
        if ((a < 12) == (b < 12)) return false;
        const int major = a < 12 ? a : b;
        const int minor = a >= 12 ? a % 12 : b % 12;
        return minor == (major + 9) % 12;
    }
    int locked = -1, candidate = -1;
    double candidateSeconds = 0.0, uncertainSeconds = 0.0;
    bool hold = false;
};
