// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstddef>

namespace autokey::bass
{
// Independent low-bass observation; never modifies the log/HSS spectrum or its
// MIDI-33 origin. Chord voices above 135 Hz cannot become bass via a fallback.
inline std::array<double,12> extract (const float* spectrum, int fftSize,
                                     double sampleRate, double tuningCents,
                                     double broadMaximum)
{
    std::array<double,12> result {};
    if (!spectrum || fftSize<8 || !std::isfinite(sampleRate) || sampleRate<=0
        || !std::isfinite(tuningCents) || !std::isfinite(broadMaximum) || broadMaximum<=0) return result;
    struct Peak { double hz, magnitude, salience; bool harmonic=false; };
    std::array<Peak,128> peaks {}; std::size_t count=0;
    const double binHz=sampleRate/fftSize;
    const int first=std::max(2,(int)std::floor(40.0/binHz));
    const int last=std::min(fftSize/2-2,(int)std::ceil(135.0/binHz));
    for(int b=first;b<=last && count<peaks.size();++b)
    {
        const double m=spectrum[b];
        if(!std::isfinite(m)||m<=0 ||m<spectrum[b-1]||m<=spectrum[b+1]||m<broadMaximum*0.025)continue;
        const double a=std::log(std::max((double)spectrum[b-1],1e-12));
        const double c=std::log(m),e=std::log(std::max((double)spectrum[b+1],1e-12));
        const double denominator=a-2*c+e;
        const double offset=denominator!=0?std::clamp(0.5*(a-e)/denominator,-0.5,0.5):0;
        const double hz=(b+offset)*binHz;
        if(!std::isfinite(hz)||hz<40.0||hz>135.0)continue;
        double harmonics=0.0;
        for(int h=2;h<=4;++h)
        {
            const int centre=(int)std::lround(h*hz/binHz);
            if(centre<1||centre+1>=fftSize/2)break;
            const double value=std::max({0.0,(double)spectrum[centre-1],(double)spectrum[centre],(double)spectrum[centre+1]});
            harmonics+=value/h;
        }
        peaks[count++]={hz,m,m+0.5*harmonics,false};
    }
    for(std::size_t i=0;i<count;++i)
        for(std::size_t j=i+1;j<count;++j)
        {
            const double ratio=peaks[j].hz/peaks[i].hz;
            const int h=(int)std::lround(ratio);
            if(h>=2&&h<=3&&std::abs(ratio-h)<0.025*h
                &&peaks[i].magnitude>0.25*peaks[j].magnitude)
                peaks[j].harmonic=true;
        }
    double maximum=0;
    for(std::size_t i=0;i<count;++i)if(!peaks[i].harmonic)maximum=std::max(maximum,peaks[i].salience);
    if(maximum<=0)return result;
    for(std::size_t i=0;i<count;++i)
    {
        if(peaks[i].harmonic)continue;
        const double midi=69+12*std::log2(peaks[i].hz/440.0)-tuningCents/100;
        const double rounded=std::round(midi),deviation=midi-rounded;
        if(std::abs(deviation)>0.46)continue;
        int pc=(int)rounded%12;if(pc<0)pc+=12;
        const double shape=std::cos(3.141592653589793*deviation);
        result[(std::size_t)pc]+=std::pow(peaks[i].salience/maximum,0.65)*shape*shape;
    }
    return result;
}
}
