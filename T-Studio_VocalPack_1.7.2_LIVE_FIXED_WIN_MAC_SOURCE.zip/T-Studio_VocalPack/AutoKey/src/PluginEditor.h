// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include "PluginProcessor.h"
#include "licensing/LicensePanel.h"

class KeyDetectorEditor : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit KeyDetectorEditor (KeyDetectorProcessor&);
    ~KeyDetectorEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;
    void mouseDown (const juce::MouseEvent&) override;
private:
    void timerCallback() override;
    juce::Rectangle<int> designArea (float x, float y, float w, float h) const;
    juce::String resultSignature() const;
    void showLicensePanel();
    void showSettingsMenu();
    KeyDetectorProcessor& processorRef;
    std::unique_ptr<juce::LookAndFeel_V4> theme;
    juce::TextButton detectButton, settingsButton;
    KeyAnalyzer::Result current;
    std::array<float, KeyDetectorProcessor::waveSize> waveBuf {};
    // Everything that never changes is rendered once into this image (at the screen's pixel
    // size) and blitted; only the parts whose content changed are repainted each tick.
    juce::Image plate;
    juce::String shownSignature;
    std::array<int, 12> shownChroma {};
    bool shownAllowed = true;
    std::unique_ptr<TLicensePanel> licensePanel;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (KeyDetectorEditor)
};
