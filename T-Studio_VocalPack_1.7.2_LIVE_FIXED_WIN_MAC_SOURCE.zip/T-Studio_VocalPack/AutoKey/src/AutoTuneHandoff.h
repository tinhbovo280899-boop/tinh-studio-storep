// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <atomic>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <locale>
#include <sstream>
#include <string>
#include <system_error>
#if defined(_WIN32)
 #ifndef NOMINMAX
  #define NOMINMAX 1
 #endif
 #include <windows.h>
#else
 #include <unistd.h>
#endif

namespace autokey::handoff
{
    // Exact field names, numeric mappings, ASCII/UTF-8 without BOM, CRLF and
    // one-decimal reference pitch from the user's TEST_AUTOKEY_GUI_v4 BAT.
    inline std::string encode (int encodedKey, double referenceHz)
    {
        if (encodedKey < 0 || encodedKey >= 24) return {};
        if (! std::isfinite (referenceHz) || referenceHz < 400.0 || referenceHz > 480.0)
            referenceHz = 440.0;
        std::ostringstream pitch;
        pitch.imbue (std::locale::classic());
        pitch << std::fixed << std::setprecision (1) << referenceHz;
        return "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\r\n\r\n<PROPERTIES>\r\n"
               "  <VALUE name=\"KeyClass\" val=\"" + std::to_string (encodedKey % 12) + "\"/>\r\n"
               "  <VALUE name=\"KeyType\" val=\"" + std::to_string (encodedKey >= 12 ? 1 : 0) + "\"/>\r\n"
               "  <VALUE name=\"ReferencePitch\" val=\"" + pitch.str() + "\"/>\r\n"
               "</PROPERTIES>\r\n";
    }

    // Called only by the background worker. The old file is retained if
    // validation or writing fails. The complete new XML replaces it in one move.
    inline bool write (const std::filesystem::path& destination, int encodedKey,
                       double referenceHz, std::string& error)
    {
        error.clear();
        const auto xml = encode (encodedKey, referenceHz);
        if (xml.empty()) { error = "No valid detected key"; return false; }
        if (! destination.is_absolute() || destination.filename().empty())
        { error = "Handoff path must be an absolute file path"; return false; }
        try
        {
            std::error_code ec;
            std::filesystem::create_directories (destination.parent_path(), ec);
            if (ec) { error = "Cannot create Auto-Key folder: " + ec.message(); return false; }
            static std::atomic<unsigned long long> sequence { 0 };
           #if defined(_WIN32)
            const auto pid = (unsigned long) ::GetCurrentProcessId();
           #else
            const auto pid = (unsigned long) ::getpid();
           #endif
            auto temporary = destination;
            temporary += ".tmp-" + std::to_string (pid) + "-"
                + std::to_string (std::chrono::steady_clock::now().time_since_epoch().count())
                + "-" + std::to_string (sequence.fetch_add (1));
            struct Cleanup
            {
                std::filesystem::path file;
                ~Cleanup() { std::error_code ignored; std::filesystem::remove (file, ignored); }
            } cleanup { temporary };
            {
                std::ofstream output (temporary, std::ios::binary | std::ios::trunc);
                if (! output) { error = "Cannot open temporary handoff file"; return false; }
                output.write (xml.data(), (std::streamsize) xml.size());
                output.close();
                if (! output) { error = "Cannot finish writing handoff file"; return false; }
            }
           #if defined(_WIN32)
            if (! ::MoveFileExW (temporary.c_str(), destination.c_str(), MOVEFILE_REPLACE_EXISTING | MOVEFILE_WRITE_THROUGH))
            { error = "Cannot replace handoff file (Windows " + std::to_string (::GetLastError()) + ")"; return false; }
           #else
            std::filesystem::rename (temporary, destination, ec);
            if (ec) { error = "Cannot replace handoff file: " + ec.message(); return false; }
           #endif
            return true;
        }
        catch (const std::exception& e) { error = e.what(); return false; }
    }
}
