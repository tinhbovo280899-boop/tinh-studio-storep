// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
// Upgraded with zplane tONaRT (Auto-Key 2) multi-profile dictionary tables.

#pragma once
#include <array>

// Pitch-class stability profiles (0 = tonic .. 11 = leading tone):
// - majorProfile / minorProfile / minorPopProfile: calibrated fundamental templates
// - tonartKKMajor / tonartKKMinorSym: zplane tONaRT symmetric Krumhansl-Kessler profiles (RVA 0x575980)
// - tonartTemperleyMajor / tonartTemperleyMinor: zplane tONaRT Temperley profiles (RVA 0x5759e0)
// - tonartDiatonicMajor / tonartDiatonicMinor: zplane tONaRT diatonic-gated profiles (RVA 0x575a40)
namespace KeyProfiles
{
    extern const std::array<float, 12> majorProfile;
    extern const std::array<float, 12> minorProfile;
    extern const std::array<float, 12> minorPopProfile;

    extern const std::array<float, 12> tonartKKMajor;
    extern const std::array<float, 12> tonartKKMinorSym;
    extern const std::array<float, 12> tonartTemperleyMajor;
    extern const std::array<float, 12> tonartTemperleyMinor;
    extern const std::array<float, 12> tonartDiatonicMajor;
    extern const std::array<float, 12> tonartDiatonicMinor;
}
