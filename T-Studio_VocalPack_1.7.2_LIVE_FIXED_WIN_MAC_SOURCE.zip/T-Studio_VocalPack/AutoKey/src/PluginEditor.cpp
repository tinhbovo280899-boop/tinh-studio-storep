// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
#include "PluginEditor.h"
#include "TBrand.h"
#include <cmath>

namespace {
const juce::Colour bg(0xff0b0c10), card(0xff13151b), top(0xff1c1f27);
const juce::Colour gold(0xffe9c27a), cream(0xfff3efe8), dim(0xff8f897f);

void label(juce::Graphics& g, const juce::String& text, juce::Rectangle<float> r,
           float size, juce::Colour c, bool bold=false, int align=juce::Justification::centredLeft)
{
    g.setColour(c); g.setFont(juce::Font(juce::FontOptions(size, bold ? juce::Font::bold : juce::Font::plain)));
    g.drawText(text,r,align,false);
}

void panel(juce::Graphics& g, juce::Rectangle<float> r)
{
    juce::DropShadow(juce::Colours::black.withAlpha(0.4f),18,{0,5}).drawForRectangle(g,r.toNearestInt());
    g.setGradientFill(juce::ColourGradient(top,r.getX(),r.getY(),card,r.getX(),r.getBottom(),false));
    g.fillRoundedRectangle(r,16); g.setColour(juce::Colours::white.withAlpha(0.07f));
    g.drawRoundedRectangle(r,16,1);
}

// Everything in the 680x400 design that does not depend on the analysis result.
void paintPlate(juce::Graphics& g)
{
    g.fillAll(bg);
    g.setGradientFill(juce::ColourGradient(gold,18,12,juce::Colour(0xffb98a3e),48,48,false));
    g.fillEllipse(20,17,34,34);
    juce::Path wave; wave.startNewSubPath(26,35);wave.lineTo(31,29);wave.lineTo(35,39);
    wave.lineTo(40,25);wave.lineTo(44,37);wave.lineTo(49,31);
    g.setColour(bg);g.strokePath(wave,juce::PathStrokeType(1.8f));
    txbrand::draw(g,{67,17,210,26},"AutoKey",juce::Font(juce::FontOptions(23.0f,juce::Font::bold)),cream,gold);
    label(g,"MUSICAL KEY ANALYSIS",{68,43,210,14},10,gold,true);
    panel(g,{20,82,414,248}); panel(g,{448,82,212,248});
    label(g,"AUTO-TUNE",{260,102,154,20},10,gold,true,juce::Justification::centredRight);
    for(int i=0;i<12;++i){const float x=42+i*30.5f; g.setColour(juce::Colour(0xff0d0e13)); g.fillRoundedRectangle(x,237,26,37,6);}
    label(g,"EVIDENCE",{470,103,165,20},11,dim,true);
    g.setColour(bg);g.fillRoundedRectangle(470,237,166,9,4.5f);
    label(g,"ESTIMATE STRENGTH",{470,260,170,20},10,dim);
    label(g,"TUNING",{470,289,60,18},10,dim,true);
    g.setColour(juce::Colour(0xff0d0e13));g.fillRoundedRectangle({24,342,516,40},8);
    label(g,"T STUDIO",{555,351,100,24},10,gold,true,juce::Justification::centredRight);
}

class HeaderLookAndFeel : public juce::LookAndFeel_V4
{
public:
    HeaderLookAndFeel()
    {
        setColour(juce::TextButton::buttonColourId, top);
        setColour(juce::TextButton::textColourOffId, gold);
        setColour(juce::TextButton::textColourOnId, cream);
    }

    void drawButtonBackground(juce::Graphics& g, juce::Button& b, const juce::Colour&,
                              bool isHighlighted, bool isDown) override
    {
        auto r = b.getLocalBounds().toFloat().reduced(0.75f);
        const float corner = 8.0f;
        const auto baseTop = isDown ? card.darker(0.25f) : (isHighlighted ? top.brighter(0.12f) : top);
        const auto baseBot = isDown ? bg : card;
        g.setGradientFill(juce::ColourGradient(baseTop, r.getX(), r.getY(), baseBot, r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle(r, corner);
        const float borderAlpha = b.isEnabled() ? (isHighlighted ? 0.55f : 0.28f) : 0.12f;
        g.setColour(gold.withAlpha(borderAlpha));
        g.drawRoundedRectangle(r, corner, 1.15f);
    }

    void drawButtonText(juce::Graphics& g, juce::TextButton& b, bool isHighlighted, bool) override
    {
        const auto col = b.isEnabled() ? (isHighlighted ? cream : gold) : dim.withAlpha(0.45f);
        if (b.getComponentID() == "settings")
        {
            // Crisp vector 8-tooth Settings gear icon
            const auto bounds = b.getLocalBounds().toFloat();
            const float cx = bounds.getCentreX();
            const float cy = bounds.getCentreY();
            const float scale = juce::jmin(bounds.getWidth(), bounds.getHeight()) / 32.0f;
            const float rOuter = 9.2f * scale;
            const float rBase  = 7.0f * scale;
            const float rInner = 3.3f * scale;
            constexpr int numTeeth = 8;
            constexpr float twoPi = juce::MathConstants<float>::twoPi;

            juce::Path gear;
            const int steps = numTeeth * 4;
            for (int i = 0; i < steps; ++i)
            {
                const float a = twoPi * (float)i / (float)steps - 0.1963495f;
                const bool isTip = ((i % 4) == 1 || (i % 4) == 2);
                const float rad = isTip ? rOuter : rBase;
                const float px = cx + rad * std::cos(a);
                const float py = cy + rad * std::sin(a);
                if (i == 0) gear.startNewSubPath(px, py);
                else        gear.lineTo(px, py);
            }
            gear.closeSubPath();
            gear.addEllipse(cx - rInner, cy - rInner, rInner * 2.0f, rInner * 2.0f);
            gear.setUsingNonZeroWinding(false);

            g.setColour(col);
            g.fillPath(gear);
            return;
        }

        const float fontSize = juce::jmax(11.0f, b.getHeight() * 0.42f);
        g.setColour(col);
        g.setFont(juce::Font(juce::FontOptions(fontSize, juce::Font::bold)));
        g.drawText(b.getButtonText(), b.getLocalBounds(), juce::Justification::centred, false);
    }
};

}

KeyDetectorEditor::KeyDetectorEditor(KeyDetectorProcessor& p)
    : juce::AudioProcessorEditor(&p), processorRef(p), theme(std::make_unique<HeaderLookAndFeel>())
{
    detectButton.setLookAndFeel(theme.get());
    settingsButton.setLookAndFeel(theme.get());

    detectButton.setButtonText(juce::String::fromUTF8("DÒ LẠI"));
    detectButton.setTooltip(juce::String::fromUTF8("Dò lại tông ngay lập tức (xóa kết quả cũ, nghe đoạn nhạc đang phát rồi tự cập nhật tông khi xác nhận). Khi bật Tự động, plugin cũng tự dò lại sau 5 giây im lặng khi đổi bài."));
    detectButton.onClick=[this]{processorRef.requestDetection();};

    settingsButton.setComponentID("settings");
    settingsButton.setButtonText({});
    settingsButton.setTooltip(juce::String::fromUTF8("Cài đặt: Bản quyền & Kích hoạt, Tự động dò tông (bật/tắt)."));
    settingsButton.onClick=[this]{showSettingsMenu();};

    addAndMakeVisible(detectButton);
    addAndMakeVisible(settingsButton);
    setResizable(true,true); setResizeLimits(544,320,1088,640);
    getConstrainer()->setFixedAspectRatio(1.7);
    current=processorRef.getLatestResult();
    setSize(680,400); startTimerHz(30);
}
KeyDetectorEditor::~KeyDetectorEditor()
{
    stopTimer();
    licensePanel.reset();
    detectButton.setLookAndFeel(nullptr);
    settingsButton.setLookAndFeel(nullptr);
}
juce::Rectangle<int> KeyDetectorEditor::designArea(float x, float y, float w, float h) const
{
    const float sx=getWidth()/680.0f, sy=getHeight()/400.0f;
    return juce::Rectangle<float>(x*sx,y*sy,w*sx,h*sy).getSmallestIntegerContainer().expanded(2);
}

// Text shown in the two result panels (everything except the live note levels).
juce::String KeyDetectorEditor::resultSignature() const
{
    juce::String s;
    s << (int) processorRef.holdKey.load() << "|" << processorRef.getHandoffStatus() << "|";
    if(current.key.valid) s << keyToString(current.key) << (int) current.key.tonic << (current.key.mode==Mode::Major?"M":"m");
    s << "|";
    if(current.second.valid) s << keyToString(current.second);
    s << "|" << juce::roundToInt(juce::jlimit(0.0f,1.0f,current.confidence)*100) << "|" << juce::String(current.tuningHz,1);
    return s;
}

void KeyDetectorEditor::timerCallback()
{
    current=processorRef.getLatestResult();
    const bool allowed=processorRef.hasLicenseAccess();
    if(allowed!=shownAllowed) { shownAllowed=allowed; detectButton.setEnabled(allowed); }

    // Waveform strip: repaint only when the picture moved.
    std::array<float, KeyDetectorProcessor::waveSize> fresh {};
    processorRef.copyWaveform(fresh.data(),(int)fresh.size());
    if(fresh!=waveBuf) { waveBuf=fresh; repaint(designArea(24,342,516,40)); }

    // Result panels: repaint only when their text changed.
    const auto sig=resultSignature();
    if(sig!=shownSignature) { shownSignature=sig; repaint(designArea(20,82,640,250)); }

    // Note level chips: repaint the chip row only when a level visibly changed.
    bool chromaChanged=false;
    for(int i=0;i<12;++i)
    {
        const int q=juce::roundToInt(juce::jlimit(0.0f,1.0f,current.chroma[(size_t)i])*74.0f);   // ~half-pixel steps
        if(q!=shownChroma[(size_t)i]) { shownChroma[(size_t)i]=q; chromaChanged=true; }
    }
    if(chromaChanged) repaint(designArea(42,237,362,37));
}

void KeyDetectorEditor::paint(juce::Graphics& g)
{
    // Static plate, rendered once per size / screen scale.
    const float scale=juce::jlimit(0.25f,8.0f,g.getInternalContext().getPhysicalPixelScaleFactor());
    const int pw=juce::jmax(1,juce::roundToInt(getWidth()*scale)), ph=juce::jmax(1,juce::roundToInt(getHeight()*scale));
    if(plate.isNull() || plate.getWidth()!=pw || plate.getHeight()!=ph)
    {
        plate=juce::Image(juce::Image::ARGB,pw,ph,true);
        juce::Graphics pg(plate);
        pg.addTransform(juce::AffineTransform::scale(pw/680.0f,ph/400.0f));
        paintPlate(pg);
    }
    g.setImageResamplingQuality(juce::Graphics::lowResamplingQuality);
    g.drawImage(plate,getLocalBounds().toFloat());
    g.addTransform(juce::AffineTransform::scale(getWidth()/680.0f,getHeight()/400.0f));

    label(g,processorRef.holdKey.load() ? "DETECTED KEY / HOLD" : "DETECTED KEY / AUTO",{42,102,196,20},11,dim,true);
    label(g,processorRef.getHandoffStatus(),{42,215,370,17},10,gold);

    label(g,current.key.valid?keyToString(current.key):juce::String::fromUTF8("—"),
          {40,132,374,80},current.key.valid?56:68,cream,true,juce::Justification::centred);
    static const char* notes[]={"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
    for(int i=0;i<12;++i) {
        const float x=42+i*30.5f;
        const bool selected=current.key.valid&&current.key.tonic==i;
        if(selected) {g.setColour(gold);g.fillRoundedRectangle(x,237,26,37,6);}
        // Level of this note in the music right now (pitch-class energy).
        const float level=juce::jlimit(0.0f,1.0f,current.chroma[(size_t)i]);
        if(!selected&&level>0.02f) {
            g.setColour(gold.withAlpha(0.18f+0.32f*level));
            g.fillRoundedRectangle(x,237+37*(1-level),26,37*level,6);
        }
        label(g,notes[i],{x,237,26,37},11,selected?bg:(level>0.6f?cream:dim),selected,juce::Justification::centred);
    }
    label(g,current.key.valid?(current.key.mode==Mode::Major?"MAJOR":"MINOR"):"LISTENING",
          {42,289,150,18},11,gold,true);
    if(current.second.valid) {
        label(g,"2ND",{246,289,40,18},10,dim,true);
        label(g,keyToString(current.second),{282,289,132,18},11,cream,true,juce::Justification::centredRight);
    }
    const float confidence=juce::jlimit(0.0f,1.0f,current.confidence);
    label(g,juce::String(juce::roundToInt(confidence*100))+"%",{468,150,170,64},47,cream,true);
    if(confidence>0) {g.setColour(gold);g.fillRoundedRectangle(470,237,166*confidence,9,4.5f);}
    label(g,"A = "+juce::String(current.tuningHz,1)+" Hz",{520,289,116,18},11,cream,true,juce::Justification::centredRight);

    // Waveform strip (last ~4 s of the input).
    const juce::Rectangle<float> strip{24,342,516,40};
    float peak=0.0f; for(float v:waveBuf) peak=juce::jmax(peak,v);
    if(peak>0.001f) {
        const int n=(int)waveBuf.size(); const float cy=strip.getCentreY(), h=strip.getHeight()*0.42f;
        const float gain=1.0f/juce::jmax(0.25f,peak);          // auto-scale so quiet input stays visible
        juce::Path p; p.startNewSubPath(strip.getX()+6,cy);
        for(int i=0;i<n;++i) p.lineTo(strip.getX()+6+(strip.getWidth()-12)*i/(n-1.0f),cy-h*juce::jmin(1.0f,waveBuf[(size_t)i]*gain));
        for(int i=n-1;i>=0;--i) p.lineTo(strip.getX()+6+(strip.getWidth()-12)*i/(n-1.0f),cy+h*juce::jmin(1.0f,waveBuf[(size_t)i]*gain));
        p.closeSubPath();
        g.setGradientFill(juce::ColourGradient(gold.withAlpha(0.9f),0,cy,juce::Colour(0xffb98a3e).withAlpha(0.55f),0,strip.getBottom(),false));
        g.fillPath(p);
    } else {
        label(g,juce::String::fromUTF8("PHÁT NHẠC ĐỂ TỰ ĐỘNG DÒ — HOẶC BẤM DÒ LẠI"),strip.reduced(12,0),11,dim,true,juce::Justification::centred);
    }
}

void KeyDetectorEditor::showSettingsMenu()
{
    const bool isHold = processorRef.holdKey.load();
    const bool allowed = processorRef.hasLicenseAccess();

    juce::PopupMenu menu;
    menu.addItem(1, juce::String::fromUTF8("Bản quyền & Kích hoạt..."));
    menu.addItem(2, juce::String::fromUTF8(isHold ? "Tự động dò tông: TẮT" : "Tự động dò tông: BẬT"),
                 allowed, !isHold);

    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&settingsButton),
        [safe = juce::Component::SafePointer<KeyDetectorEditor>(this), isHold](int res)
        {
            if (safe == nullptr || res == 0) return;
            if (res == 1)
            {
                safe->showLicensePanel();
            }
            else if (res == 2)
            {
                safe->processorRef.holdKey.store(!isHold);
                safe->processorRef.saveGlobalSettings();
                safe->shownSignature.clear();
                safe->repaint();
            }
        });
}

void KeyDetectorEditor::showLicensePanel()
{
    auto safe=juce::Component::SafePointer<KeyDetectorEditor>(this);
    licensePanel=std::make_unique<TLicensePanel>(
        [safe]{return safe?safe->processorRef.getLicenseSnapshot():tak::license::Snapshot{};},
        [safe](const juce::String& text){if(safe)safe->processorRef.activateLicense(text);},
        [safe]{if(safe)safe->processorRef.startLicenseTrial();},
        [safe]{juce::MessageManager::callAsync([safe]{if(safe)safe->licensePanel.reset();});});
    addAndMakeVisible(*licensePanel);licensePanel->setBounds(getLocalBounds());licensePanel->toFront(false);
}


void KeyDetectorEditor::mouseDown(const juce::MouseEvent& e)
{
    const float x=e.position.x*680.0f/(float)juce::jmax(1,getWidth());
    const float y=e.position.y*400.0f/(float)juce::jmax(1,getHeight());
    if(x<20 || x>434 || y<82 || y>330) return;
    if(!e.mods.isPopupMenu())
    {
        if(x>=40 && x<=414 && y>=132 && y<=232 && current.key.valid) processorRef.sendHandoffNow();
        return;
    }
    juce::PopupMenu menu;
    menu.addItem(1,juce::String::fromUTF8("Gửi lại tông đã chốt"),
                 processorRef.hasLicenseAccess() && current.key.valid);
    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(this),
        [safe=juce::Component::SafePointer<KeyDetectorEditor>(this)](int result)
        {
            if(safe!=nullptr && result==1) safe->processorRef.sendHandoffNow();
        });
}
void KeyDetectorEditor::resized()
{
    // "DÒ LẠI" button centered horizontally in the 680x400 interface (x = 285..395, center = 340)
    detectButton.setBounds(juce::roundToInt(285.0f * getWidth() / 680.0f),
                           juce::roundToInt(20.0f  * getHeight() / 400.0f),
                           juce::roundToInt(110.0f * getWidth() / 680.0f),
                           juce::roundToInt(32.0f  * getHeight() / 400.0f));

    // Settings gear icon button in the top-right corner (x = 622..660, right-aligned with main panel at x=660)
    settingsButton.setBounds(juce::roundToInt(622.0f * getWidth() / 680.0f),
                             juce::roundToInt(20.0f  * getHeight() / 400.0f),
                             juce::roundToInt(38.0f  * getWidth() / 680.0f),
                             juce::roundToInt(32.0f  * getHeight() / 400.0f));

    if (licensePanel)
        licensePanel->setBounds(getLocalBounds());
}
