// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <cmath>
#include <cstdint>

// Worker-side deduplication and continuous-evidence check. Never writes a
// placeholder C major while listening, and never resends on tuning-meter jitter.
class HandoffGate
{
public:
    bool ready (int key, double evidence, bool audioFresh, double nowMs,
                std::uint64_t generation, bool manual) noexcept
    {
        if (generation != epoch)
        { epoch = generation; lastWritten = candidate = -1; candidateSince = 0.0; }
        if (key < 0 || key >= 24) { candidate = -1; return false; }
        if (manual) return true;
        if (! audioFresh || ! std::isfinite (evidence) || evidence < 0.45)
        { candidate = -1; return false; }
        if (key == lastWritten) { candidate = -1; return false; }
        if (candidate != key)
        { candidate = key; candidateSince = nowMs; return false; }
        return nowMs - candidateSince >= 500.0;
    }
    void written (int key) noexcept { lastWritten = key; candidate = -1; }
private:
    std::uint64_t epoch = 0;
    int lastWritten = -1, candidate = -1;
    double candidateSince = 0.0;
};
