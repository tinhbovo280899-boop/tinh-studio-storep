// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
// T-AutoKey V1.6.4 — log-frequency chroma, local spectral whitening,
// harmonic summation and adaptive temporal key confirmation.

#pragma once
#include <juce_dsp/juce_dsp.h>
#include <array>
#include <memory>
#include <vector>
#include "Key.h"
#include "KeyDecision.h"

// Pure DSP core: feed mono/mid-side audio blocks, read the detected key. No host/UI deps.
class KeyAnalyzer
{
public:
    KeyAnalyzer() = default;

    void prepare (double sampleRate);   // allocates; call off the audio thread
    void reset();
    // A seek/loop boundary flushes the FFT, without discarding accumulated key
    // evidence. Only a measured long pause starts a fresh analysis history.
    void notifyTransportGap (double gapSeconds = 0.0);
    void setHold (bool enabled) { holdEnabled = enabled; decision.setHold (enabled); }
    bool isHold() const noexcept { return holdEnabled; }
    void processBlock (const float* mono, int numSamples);
    void processStereoBlock (const float* left, const float* right, int numSamples);

    struct Result
    {
        Key   key;                       // shown key (after hysteresis)
        float confidence = 0.0f;         // 0..1
        Key   second;                    // runner-up key
        float tuningHz   = 440.0f;       // estimated reference A
        std::array<float, 12> chroma {}; // 0..1, C..B
    };
    Result detect() const { return result; }

    // Seconds for old material to fade to ~37 %. Shorter = follows key changes faster.
    void setMemorySeconds (double seconds) { memorySeconds = seconds; updateDecay(); }

private:
    static constexpr int kBinsPerSemitone = 3;
    static constexpr int kBinsPerOctave   = 12 * kBinsPerSemitone; // 36 bins/octave (tONaRT standard)
    static constexpr int kNumPitchOctaves = 5;                     // 55 Hz (A1) .. 1760 Hz (A6)
    static constexpr int kNumScanOctaves  = 6;                     // 55 Hz (A1) .. 3520 Hz (A7)
    static constexpr int kNumPitchBins    = kNumPitchOctaves * kBinsPerOctave; // 180
    static constexpr int kNumLogBins      = kNumScanOctaves  * kBinsPerOctave; // 216
    static constexpr int kWhitenRadius    = 9;                     // +-9 sub-bins (+-3 semitones)
    static constexpr int kWhitenLen       = 2 * kWhitenRadius + 1; // 19-tap Hamming window

    struct LogBinFilter
    {
        int startBin = 0;
        std::vector<float> weights;
    };

    void analyseFrame();
    void rejectFrame (bool isSilent);
    void resetSectionTrackers();
    void startNewSongFromBreak();
    void updateDecay();
    void evaluate();

    double sampleRate = 44100.0;
    int fftOrder = 14, fftSize = 1 << 14, hopSize = 1 << 12;
    std::unique_ptr<juce::dsp::FFT> fft;
    std::vector<float> window, ring, ringSide, work, workSide;
    std::vector<LogBinFilter> logFilters;
    std::array<float, kWhitenLen> whitenKernel {};
    float whitenKernelSum = 1.0f;
    std::array<float, kNumPitchBins> shepardBell {};
    std::array<double, kNumLogBins> logSpec {};
    std::array<double, kNumLogBins> whitenMean {};
    std::array<double, kNumLogBins> whitenStd {};
    std::array<double, kNumLogBins> whitenedSpec {};
    std::array<double, kNumLogBins> hssResidual {};
    std::array<double, kNumPitchBins> hssPitch {};

    bool hasSideSignal = false;
    bool holdEnabled = false;
    bool songBreakArmed = false;
    int ringPos = 0, sinceHop = 0, filled = 0;

    std::array<double, 12> acc {};          // slow pitch-class profile (stable answer)
    std::array<double, 12> accFast {};      // fast profile (detects a new song)
    std::array<double, 12> accBass {};      // slow bass-root profile (40..135 Hz)
    std::array<double, 12> accBassFast {};  // fast bass-root profile
    std::array<double, 12> accAnchor {};    // phrase-opening / anchor chroma
    std::array<double, 12> accAnchorBass {};// phrase-opening / anchor bass root
    std::array<double, 24> chordScore {};   // accumulated instantaneous triad evidence (0..11 maj, 12..23 min)
    std::array<double, 24> chordFast {};    // fast instantaneous triad evidence
    std::array<double, 24> cadenceScore {}; // functional harmonic cadence evidence
    std::array<double, 24> cadenceFast {};  // fast cadence evidence
    std::array<double, 24> prevTriad {};    // smoothed previous chord triad state for transition detection

    // Section / New-Song candidate accumulator (tracks gapless song changes without old-song pollution)
    std::array<double, 12> accSection {};
    std::array<double, 12> accBassSection {};
    std::array<double, 12> accSectionAnchor {};
    std::array<double, 12> accSectionAnchorBass {};
    std::array<double, 24> chordSection {};
    std::array<double, 24> cadenceSection {};
    std::array<double, 24> smoothedSecScores {};
    std::array<double, 12> preRollChroma {};
    std::array<double, 12> preRollBass {};
    double preRollWeight = 0.0;
    double sectionWeight = 0.0, sectionAnchorWeight = 0.0, sectionSeconds = 0.0;
    double sectionMismatchSeconds = 0.0;

    double accWeight = 0.0, fastWeight = 0.0, anchorWeight = 0.0, totalPitchedSeconds = 0.0;
    double initialAnchorConflictSeconds = 0.0, initialAnchorFadeStart = 8.0;
    bool initialAnchorReleased = false;
    double fastDecay = 1.0, sectionDecay = 1.0, silenceTime = 0.0, unpitchedTime = 0.0, smoothConf = 0.0;
    struct Peak { double freq, mag, cleanMag, bassSalience; bool isFundamental; };
    std::vector<Peak> peaks;
    std::vector<unsigned char> isOctaveHarmonic;
    KeyDecision decision;
    double tuneRe = 0.0, tuneIm = 0.0;      // circular mean of cents deviation
    double tuneFastRe = 0.0, tuneFastIm = 0.0;
    double memorySeconds = 16.0, decay = 1.0, tuneDecay = 1.0;

    Result result;
};
