// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro

#include "Key.h"

juce::String keyToString (const Key& key)
{
    if (! key.valid)
        return juce::String (juce::CharPointer_UTF8 ("\xe2\x80\x94")); // em dash

    // Spelling used on lead sheets / karaoke: flats for most major keys,
    // sharps where the minor key is normally written that way (C#m, G#m).
    static const char* const majorNames[] =
        { "C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" };
    static const char* const minorNames[] =
        { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B" };

    return key.mode == Mode::Major ? juce::String (majorNames[key.tonic % 12]) + " major"
                                   : juce::String (minorNames[key.tonic % 12]) + " minor";
}
