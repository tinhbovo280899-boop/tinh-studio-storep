// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>

// Audio-thread owned. Quiet time is measured in samples, independent of host
// block size and rendering speed. A callback suspension can add missing time.
// Inspect channels independently so anti-phase stereo cannot look silent.
class SongRestartGate
{
public:
    static constexpr double quietSeconds = 5.0;
    static constexpr double quietRms = 0.001; // -60 dBFS, per channel.

    void prepare (double rate) noexcept
    {
        sampleRate = std::isfinite (rate) && rate > 0.0 ? rate : 48000.0;
        quietLimit = (std::uint64_t) std::ceil (sampleRate * quietSeconds);
        reset();
    }
    void reset() noexcept { quietSamples = 0; }

    bool process (const float* const* data, int channels, int samples,
                  bool hold, double missingSeconds = 0.0) noexcept
    {
        // An explicit HOLD remains authoritative. Releasing it starts a fresh
        // quiet interval rather than replaying an automatic reset queued earlier.
        if (hold) { reset(); return false; }
        if (channels <= 0 || samples <= 0 || data == nullptr) return false;
        if (std::isfinite (missingSeconds) && missingSeconds > 0.0)
            addQuiet ((std::uint64_t) std::ceil (sampleRate * std::min (missingSeconds, quietSeconds)));

        bool quiet = true;
        const double limit = quietRms * quietRms * samples;
        for (int ch = 0; ch < channels && quiet; ++ch)
        {
            double energy = 0.0;
            for (int i = 0; i < samples; ++i)
            {
                const double sample = data[ch][i];
                if (! std::isfinite (sample)) { reset(); return false; }
                energy += sample * sample;
            }
            quiet = energy <= limit;
        }
        if (quiet) { addQuiet ((std::uint64_t) samples); return false; }
        const bool restart = quietSamples >= quietLimit;
        reset();
        return restart;
    }

private:
    void addQuiet (std::uint64_t count) noexcept
    { quietSamples += std::min (count, quietLimit - quietSamples); }
    double sampleRate = 48000.0;
    std::uint64_t quietSamples = 0, quietLimit = 240000;
};
