// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
// T-AutoKey V1.6.4 — log-frequency chroma, local spectral whitening,
// harmonic summation and adaptive temporal key confirmation.

#include "KeyAnalyzer.h"
#include "KeyProfiles.h"
#include "BassChroma.h"
#include "SpectralRanking.h"
#include <algorithm>
#include <cmath>

namespace
{
    constexpr double kMinHz           = 55.0;   // Log/HSS grid A1, MIDI 33; independent of the bass band
    constexpr double kMidMinHz        = 130.0;  // harmonic mid band start
    constexpr double kMaxHz           = 1760.0; // A6 (1760 Hz): upper bound of fundamental pitch region
    constexpr double kScanMaxHz       = 3520.0; // A7 (3520 Hz): upper bound for overtone verification
    constexpr double kGamma           = 0.72;   // non-linear magnitude compression
    constexpr double kFloor           = 0.025;  // peak floor relative to frame max
    constexpr double kFastSeconds     = 3.2;    // 1 full 4-bar phrase cycle for modulation tracking
    constexpr double kSectionSeconds  = 8.5;    // clean new-section accumulator for gapless song changes
    constexpr double kConfSeconds     = 0.85;   // smoothing of the confidence display
    constexpr double kSongBreakSeconds = 2.4;  // tolerate rests, fills and brief stops
    constexpr int    kHssHarmonics    = 12;     // harmonics summed in IterativeHSS
    constexpr int    kHssIterations   = 20;     // exact zplane tONaRT IterativeHSS iteration count (0x14)
    constexpr double kHssStopRatio    = 0.01;   // exact zplane tONaRT IterativeHSS stop ratio (0x3c23d70a)
    constexpr double kTwoPi           = 6.283185307179586;

    // Harmonic offset in 36-bin/octave log-frequency grid: round(36 * log2(h))
    constexpr int kHarmonicBinOffsets[kHssHarmonics] =
        { 0, 36, 57, 72, 84, 93, 101, 108, 114, 120, 125, 129 };

    std::array<double, 12> normalizeL1 (const std::array<float, 12>& profile)
    {
        std::array<double, 12> out {};
        double sum = 0.0;
        for (int i = 0; i < 12; ++i) sum += (double) profile[(size_t) i];
        if (sum > 0.0)
            for (int i = 0; i < 12; ++i) out[(size_t) i] = (double) profile[(size_t) i] / sum;
        return out;
    }

    // Gentle overtone reinforcement for residual harmonics after IterativeHSS
    std::array<double, 12> withGentleHarmonics (const std::array<float, 12>& profile)
    {
        static const int interval[5] = { 0, 0, 7, 0, 4 };
        static const double weight[5] = { 1.0, 0.18, 0.05, 0.03, 0.01 };
        std::array<double, 12> out {};
        for (int pc = 0; pc < 12; ++pc)
            for (int h = 0; h < 5; ++h)
                out[(size_t) ((pc + interval[h]) % 12)] += (double) profile[(size_t) pc] * weight[h];
        return out;
    }

    double correlate (const std::array<double, 12>& hist, const std::array<double, 12>& profile, int tonic)
    {
        double hm = 0.0, pm = 0.0;
        for (int i = 0; i < 12; ++i) { hm += hist[(size_t) i]; pm += profile[(size_t) i]; }
        hm /= 12.0; pm /= 12.0;
        double num = 0.0, dh = 0.0, dp = 0.0;
        for (int p = 0; p < 12; ++p)
        {
            const double h = hist[(size_t) ((tonic + p) % 12)] - hm;
            const double q = profile[(size_t) p] - pm;
            num += h * q; dh += h * h; dp += q * q;
        }
        return (dh <= 0.0 || dp <= 0.0) ? -1.0 : num / std::sqrt (dh * dp);
    }

    // Exact zplane tONaRT KeyDictionary L1-normalized Euclidean similarity (Auto-Key 2 0x1802a2300..0x1802a237a):
    // Normalizes chroma by L1 norm, computes L2 distance to L1-normalized profile, returns (1 - dist)^2.
    double tonartEuclideanSimilarity (const std::array<double, 12>& histL1,
                                      const std::array<double, 12>& profileL1,
                                      int tonic)
    {
        double sumSq = 0.0;
        for (int p = 0; p < 12; ++p)
        {
            const double d = histL1[(size_t) ((tonic + p) % 12)] - profileL1[(size_t) p];
            sumSq += d * d;
        }
        const double dist = std::sqrt (sumSq);
        const double sim  = std::max (0.0, 1.0 - dist);
        return sim * sim;
    }

    // Exact zplane tONaRT structural triad dictionary profile (Auto-Key 2 0x1802a23f6..0x1802a26f3):
    // Combines Tonic (1.0), Dominant V (0.1), Subdominant IV/iv (0.1), and Relative vi/III (0.05)
    // using triad weights [0.75, 0.50, 0.50] for [Root, Third, Fifth].
    std::array<double, 12> buildTonartStructuralProfile (bool isMinor)
    {
        std::array<double, 12> p {};
        auto addTriad = [&] (int root, bool minTriad, double chordW)
        {
            p[(size_t) (root % 12)] += chordW * 0.75;
            p[(size_t) ((root + (minTriad ? 3 : 4)) % 12)] += chordW * 0.50;
            p[(size_t) ((root + 7) % 12)] += chordW * 0.50;
        };
        if (! isMinor)
        {
            addTriad (0, false, 1.00); // I
            addTriad (7, false, 0.10); // V
            addTriad (5, false, 0.10); // IV
            addTriad (9, true,  0.05); // vi
        }
        else
        {
            addTriad (0, true,  1.00); // i
            addTriad (7, false, 0.10); // V / v
            addTriad (5, true,  0.10); // iv
            addTriad (3, false, 0.05); // bIII
            addTriad (8, false, 0.05); // bVI
        }
        double sum = 0.0;
        for (double v : p) sum += v;
        if (sum > 0.0) for (double& v : p) v /= sum;
        return p;
    }

    struct Ranked { int best = -1, second = -1; double bestR = -2.0, secondR = -2.0; double r[24] {}; };

    Ranked rankKey (const std::array<double, 12>& hist,
                    const std::array<double, 12>& bassHist,
                    const std::array<double, 12>& anchorChroma,
                    const std::array<double, 12>& anchorBass,
                    const std::array<double, 24>& triads,
                    const std::array<double, 24>& cadences,
                    double effectiveAnchorStrength,
                    int currentLockedCode = -1, double anchorLimit = 0.08, const std::array<double,12>* modeChroma = nullptr, int modeLocked = -1)
    {
        static const auto majHarm      = withGentleHarmonics (KeyProfiles::majorProfile);
        static const auto minHarm      = withGentleHarmonics (KeyProfiles::minorProfile);
        static const auto minPopHarm   = withGentleHarmonics (KeyProfiles::minorPopProfile);
        static const auto kkMajL1      = normalizeL1 (KeyProfiles::tonartKKMajor);
        static const auto kkMinSymL1   = normalizeL1 (KeyProfiles::tonartKKMinorSym);
        static const auto tempMajL1    = normalizeL1 (KeyProfiles::tonartTemperleyMajor);
        static const auto tempMinL1    = normalizeL1 (KeyProfiles::tonartTemperleyMinor);
        static const auto diatMajL1    = normalizeL1 (KeyProfiles::tonartDiatonicMajor);
        static const auto diatMinL1    = normalizeL1 (KeyProfiles::tonartDiatonicMinor);
        static const auto structMajL1  = buildTonartStructuralProfile (false);
        static const auto structMinL1  = buildTonartStructuralProfile (true);

        double bassMax = 0.0, chromaMax = 0.0, chromaSum = 0.0;
        double ancMax = 0.0, ancBassMax = 0.0, triadMax = 0.0, cadenceMax = 0.0;
        for (int i = 0; i < 12; ++i)
        {
            bassMax    = std::max (bassMax, bassHist[(size_t) i]);
            chromaMax  = std::max (chromaMax, hist[(size_t) i]);
            chromaSum += std::max (0.0, hist[(size_t) i]);
            ancMax     = std::max (ancMax, anchorChroma[(size_t) i]);
            ancBassMax = std::max (ancBassMax, anchorBass[(size_t) i]);
        }
        for (int i = 0; i < 24; ++i)
        {
            triadMax   = std::max (triadMax, triads[(size_t) i]);
            cadenceMax = std::max (cadenceMax, cadences[(size_t) i]);
        }

        std::array<double, 12> histL1 {};
        if (chromaSum > 0.0)
            for (int i = 0; i < 12; ++i) histL1[(size_t) i] = std::max (0.0, hist[(size_t) i]) / chromaSum;

        std::array<double, 24> outScale {};
        double minOutScale = 1.0;
        if (chromaSum > 0.0)
        {
            for (int code = 0; code < 24; ++code)
            {
                const int t = code % 12;
                const bool isMin = (code >= 12);
                double os = 0.0;
                if (! isMin)
                {
                    os = histL1[(size_t) ((t + 1) % 12)] + histL1[(size_t) ((t + 3) % 12)]
                       + histL1[(size_t) ((t + 6) % 12)] + histL1[(size_t) ((t + 8) % 12)]
                       + histL1[(size_t) ((t + 10) % 12)];
                }
                else
                {
                    os = histL1[(size_t) ((t + 1) % 12)] + histL1[(size_t) ((t + 4) % 12)]
                       + histL1[(size_t) ((t + 6) % 12)] + histL1[(size_t) ((t + 9) % 12)];
                }
                outScale[(size_t) code] = os;
                minOutScale = std::min (minOutScale, os);
            }
        }
        else
        {
            minOutScale = 0.0;
        }

        Ranked k;
        std::array<double,24> primary {}, secondary {}, modePrimary {};
        for (int code = 0; code < 24; ++code) // 0..11 major, 12..23 minor
        {
            const int t = code % 12;
            const bool isMin = (code >= 12);

            // 1. Multi-Profile Correlation + zplane tONaRT L1-Euclidean Similarity
            double rCorr = 0.0;
            double rTonart = 0.0;
            if (! isMin)
            {
                const double c1 = correlate (hist, majHarm, t);
                rCorr = 0.65 * c1 + 0.35 * (0.55 * correlate (hist, kkMajL1, t) + 0.45 * correlate (hist, tempMajL1, t));
                rTonart = 0.55 * tonartEuclideanSimilarity (histL1, diatMajL1, t)
                        + 0.45 * tonartEuclideanSimilarity (histL1, structMajL1, t);
            }
            else
            {
                const double c1 = std::max (correlate (hist, minHarm, t), correlate (hist, minPopHarm, t));
                rCorr = 0.65 * c1 + 0.35 * (0.55 * correlate (hist, kkMinSymL1, t) + 0.45 * correlate (hist, tempMinL1, t));
                rTonart = 0.55 * tonartEuclideanSimilarity (histL1, diatMinL1, t)
                        + 0.45 * tonartEuclideanSimilarity (histL1, structMinL1, t);
            }
            primary[(size_t)code] = correlate (hist, isMin ? kkMinSymL1 : kkMajL1, t);
            modePrimary[(size_t)code] = modeChroma ? correlate (*modeChroma, isMin ? kkMinSymL1 : kkMajL1, t) : primary[(size_t)code];
            double r = 0.78 * rCorr + 0.22 * rTonart;

            // 2. Bass Root & Diatonic Bass Harmony Support
            if (bassMax > 0.0)
            {
                const double bRoot = bassHist[(size_t) t] / bassMax;
                const double bDom  = bassHist[(size_t) ((t + 7) % 12)] / bassMax;
                const double bSub  = bassHist[(size_t) ((t + 5) % 12)] / bassMax;
                if (! isMin)
                {
                    const double bVi = bassHist[(size_t) ((t + 9) % 12)] / bassMax;
                    r += 0.025 * bRoot + 0.004 * bDom + 0.003 * bSub + 0.002 * bVi;
                }
                else
                {
                    const double bVI  = bassHist[(size_t) ((t + 8) % 12)] / bassMax;
                    const double bVII = bassHist[(size_t) ((t + 10) % 12)] / bassMax;
                    r += 0.025 * bRoot + 0.004 * bDom + 0.003 * bSub + 0.001 * bVI + 0.001 * bVII;
                }
            }

            // 3. Instantaneous Diatonic Triad Support (tONaRT [I, V, IV, vi/III] dictionary)
            if (triadMax > 0.0)
            {
                const double tonicTriad = triads[(size_t) code] / triadMax;
                double diatonicTriads = 0.0;
                if (! isMin)
                {
                    const double iiMin  = triads[(size_t) (12 + (t + 2) % 12)] / triadMax;
                    const double ivMaj  = triads[(size_t) ((t + 5) % 12)] / triadMax;
                    const double vMaj   = triads[(size_t) ((t + 7) % 12)] / triadMax;
                    const double viMin  = triads[(size_t) (12 + (t + 9) % 12)] / triadMax;
                    diatonicTriads = 0.60 * tonicTriad + 0.14 * ivMaj + 0.15 * vMaj + 0.08 * viMin + 0.06 * iiMin;
                }
                else
                {
                    const double iiiMaj = triads[(size_t) ((t + 3) % 12)] / triadMax;
                    const double ivMin  = triads[(size_t) (12 + (t + 5) % 12)] / triadMax;
                    const double vMaj   = triads[(size_t) ((t + 7) % 12)] / triadMax;
                    const double vMin   = triads[(size_t) (12 + (t + 7) % 12)] / triadMax;
                    const double viMaj  = triads[(size_t) ((t + 8) % 12)] / triadMax;
                    const double viiMaj = triads[(size_t) ((t + 10) % 12)] / triadMax;
                    diatonicTriads = 0.62 * tonicTriad + 0.18 * ivMin + 0.20 * std::max (vMaj, 0.8 * vMin)
                                   + 0.13 * viMaj + 0.11 * viiMaj + 0.06 * iiiMaj;
                }
                r += 0.030 * diatonicTriads / (isMin ? 1.30 : 1.03);
            }

            // 4. Functional Harmonic Cadence Evidence + Harmonic Minor V7->i Discrimination
            if (cadenceMax > 0.0)
            {
                r += 0.025 * (cadences[(size_t) code] / cadenceMax);
            }
            if (chromaMax > 0.0 && triadMax > 0.0)
            {
                if (isMin)
                {
                    // Harmonic Minor signature: V major triad (e.g. E/E7 in Am) + leading tone #7 (G# in Am)
                    const double vMajTriad   = triads[(size_t) ((t + 7) % 12)] / triadMax;
                    const double leadingTone = hist[(size_t) ((t + 11) % 12)] / chromaMax;
                    const double minTonic    = triads[(size_t) (12 + t)] / triadMax;
                    r += 0.010 * std::sqrt (vMajTriad * minTonic) + 0.005 * leadingTone * minTonic;
                }
                else
                {
                    // If the relative minor's harmonic-minor V major triad (III# in major, e.g. E major in C major)
                    // and its minor tonic (vi, e.g. Am) are both strong, penalize false Relative Major!
                    const int relMin = (t + 9) % 12;
                    const double relDomMaj = triads[(size_t) ((relMin + 7) % 12)] / triadMax;
                    const double relMinTon = triads[(size_t) (12 + relMin)] / triadMax;
                    r -= 0.005 * std::sqrt (relDomMaj * relMinTon);
                }
            }

            // 4b. Pre-cadential ii/iv -> V/bVII Disambiguation:
            if (isMin && triadMax > 0.0)
            {
                const double majIV  = triads[(size_t) ((t + 5) % 12)] / triadMax;
                const double minIV  = triads[(size_t) (12 + (t + 5) % 12)] / triadMax;
                const double minTon = triads[(size_t) (12 + t)] / triadMax;
                if (majIV > 0.25 && majIV > 2.0 * minIV)
                    r -= 0.015 * std::sqrt (minTon * (majIV - minIV));
            }
            if (! isMin && triadMax > 0.0)
            {
                const double majII  = triads[(size_t) ((t + 2) % 12)] / triadMax;
                const double minII  = triads[(size_t) (12 + (t + 2) % 12)] / triadMax;
                const double majTon = triads[(size_t) t] / triadMax;
                if (majII > 0.25 && majII > 2.0 * minII)
                    r -= 0.015 * std::sqrt (majTon * (majII - minII));
            }

            // 4c. Out-of-scale chroma penalty against false subdominant/supertonic keys (e.g. Dm or F when G major plays B natural):
            const double excessOutScale = std::max (0.0, outScale[(size_t) code] - minOutScale);
            r -= 0.12 * excessOutScale;

            // 5. Decaying Initial Phrase Anchor (gated by in-scale consistency and submediant triad suppression):
            if (effectiveAnchorStrength > 0.01 && ancMax > 0.0)
            {
                const double scaleGate = std::clamp (1.0 - std::max (0.0, excessOutScale - 0.025) / 0.06, 0.0, 1.0);
                const double aRootBass = ancBassMax > 0.0 ? (anchorBass[(size_t) t] / ancBassMax) : (anchorChroma[(size_t) t] / ancMax);
                const double aRootChr  = anchorChroma[(size_t) t] / ancMax;
                const double aThird    = anchorChroma[(size_t) ((t + (isMin ? 3 : 4)) % 12)] / ancMax;
                const double aFifth    = anchorChroma[(size_t) ((t + 7) % 12)] / ancMax;
                const double aWrong3   = anchorChroma[(size_t) ((t + (isMin ? 4 : 3)) % 12)] / ancMax;
                const double bassGate  = std::clamp (aRootBass / 0.35, 0.15, 1.0);
                // When Bar 1 is a Major chord on (t+8)%12 (e.g. F-A-C when t=Am), its upper notes A-C must not create a false Am anchor:
                double bviPhantomGate = 1.0;
                if (isMin && ancBassMax > 0.0)
                {
                    const double bviBass = anchorBass[(size_t) ((t + 8) % 12)] / ancBassMax;
                    const double bviChr  = anchorChroma[(size_t) ((t + 8) % 12)] / ancMax;
                    if (bviBass > 0.70 && bviChr > 0.65 && bviBass >= aRootBass * 0.80)
                    {
                        bviPhantomGate = 0.0;
                        const int relMaj = (t + 3) % 12;
                        if (cadenceMax > 0.0 && cadences[(size_t) relMaj] > 1.20 * cadences[(size_t) code])
                            r -= 0.005;
                    }
                }
                const double openMatch = scaleGate * bassGate * bviPhantomGate
                    * (0.45 * aRootBass + 0.30 * aRootChr + 0.25 * aThird + 0.12 * aFifth - 0.22 * aWrong3);
                r += std::min (effectiveAnchorStrength, anchorLimit) * openMatch;
            }

            // 6. Tonic Triad Completeness & Third Discrimination in Main Chroma
            if (chromaMax > 0.0)
            {
                const double cRoot   = hist[(size_t) t] / chromaMax;
                const double cThird  = hist[(size_t) ((t + (isMin ? 3 : 4)) % 12)] / chromaMax;
                const double cFifth  = hist[(size_t) ((t + 7) % 12)] / chromaMax;
                const double cWrong3 = hist[(size_t) ((t + (isMin ? 4 : 3)) % 12)] / chromaMax;
                const double triadComplete = std::sqrt (cRoot * cThird) * (0.65 + 0.35 * cFifth);
                r += 0.030 * (0.42 * cRoot + 0.25 * cThird + 0.15 * cFifth + 0.35 * triadComplete - 0.18 * cWrong3);
            }

            // 7. Mild hysteresis against diatonic neighbor flicker
            if (code == currentLockedCode)
                r += 0.045;

            secondary[(size_t)code] = r;
        }
        const auto scores = autokey::ranking::combine (primary, secondary, modeChroma ? *modeChroma : hist, currentLockedCode >= 0 || modeChroma != nullptr, &modePrimary, modeLocked >= 0 ? modeLocked : currentLockedCode);
        for (int code=0;code<24;++code)
        {
            const double r=scores[(size_t)code]; k.r[code]=r;
            if (r>k.bestR) { k.second=k.best;k.secondR=k.bestR;k.best=code;k.bestR=r; }
            else if (r>k.secondR) { k.second=code;k.secondR=r; }
        }
        return k;
    }

    Key toKey (int code) { return code < 0 ? Key() : Key { code % 12, code < 12 ? Mode::Major : Mode::Minor, true }; }

    bool relativePair (int a, int b)
    {
        if (a < 0 || b < 0 || (a < 12) == (b < 12)) return false;
        const int major = a < 12 ? a : b;
        const int minor = a >= 12 ? a % 12 : b % 12;
        return minor == (major + 9) % 12;
    }
}

void KeyAnalyzer::prepare (double sr)
{
    sampleRate = sr > 0.0 ? sr : 44100.0;
    fftOrder = 14;
    while ((double) (1 << fftOrder) < sampleRate / 3.0 && fftOrder < 16) ++fftOrder;
    fftSize = 1 << fftOrder;
    hopSize = fftSize / 4;
    fft = std::make_unique<juce::dsp::FFT> (fftOrder);
    peaks.reserve ((size_t) fftSize / 2);
    isOctaveHarmonic.assign ((size_t) fftSize / 2, 0);
    window.assign ((size_t) fftSize, 0.0f);
    juce::dsp::WindowingFunction<float>::fillWindowingTables (window.data(), (size_t) fftSize,
        juce::dsp::WindowingFunction<float>::hann, false);
    ring.assign ((size_t) fftSize, 0.0f);
    ringSide.assign ((size_t) fftSize, 0.0f);
    work.assign ((size_t) fftSize * 2, 0.0f);
    workSide.assign ((size_t) fftSize * 2, 0.0f);

    const double binHz = sampleRate / (double) fftSize;
    logFilters.assign ((size_t) kNumLogBins, LogBinFilter {});
    for (int k = 0; k < kNumLogBins; ++k)
    {
        const double centerHz = kMinHz * std::pow (2.0, (double) k / (double) kBinsPerOctave);
        const double lowHz    = kMinHz * std::pow (2.0, (double) (k - 1) / (double) kBinsPerOctave);
        const double highHz   = kMinHz * std::pow (2.0, (double) (k + 1) / (double) kBinsPerOctave);
        const int bStart = std::max (1, (int) std::floor (lowHz / binHz));
        const int bEnd   = std::min (fftSize / 2 - 1, (int) std::ceil (highHz / binHz));
        logFilters[(size_t) k].startBin = bStart;
        logFilters[(size_t) k].weights.resize ((size_t) std::max (0, bEnd - bStart + 1), 0.0f);
        float wSum = 0.0f;
        for (int b = bStart; b <= bEnd; ++b)
        {
            const double f = b * binHz;
            const double logDist = (double) kBinsPerOctave * std::log2 (f / centerHz);
            if (std::abs (logDist) < 1.0)
            {
                const float w = (float) (0.5 + 0.5 * std::cos (juce::MathConstants<double>::pi * logDist));
                logFilters[(size_t) k].weights[(size_t) (b - bStart)] = w;
                wSum += w;
            }
        }
        if (wSum > 0.0f)
            for (float& w : logFilters[(size_t) k].weights) w /= wSum;
    }

    whitenKernelSum = 0.0f;
    for (int i = 0; i < kWhitenLen; ++i)
    {
        const double phase = kTwoPi * (double) (i - kWhitenRadius) / (double) (kWhitenLen - 1);
        whitenKernel[(size_t) i] = (float) (0.54 + 0.46 * std::cos (phase));
        whitenKernelSum += whitenKernel[(size_t) i];
    }

    for (int k = 0; k < kNumPitchBins; ++k)
    {
        const double phase = kTwoPi * (double) (k + 1) / (double) (kNumPitchBins + 1);
        shepardBell[(size_t) k] = (float) (0.35 + 0.65 * 0.5 * (1.0 - std::cos (phase)));
    }

    updateDecay();
    reset();
}

void KeyAnalyzer::updateDecay()
{
    const double hopSeconds = hopSize / sampleRate;
    decay        = std::exp (-hopSeconds / std::max (1.0, memorySeconds));
    fastDecay    = std::exp (-hopSeconds / kFastSeconds);
    sectionDecay = std::exp (-hopSeconds / kSectionSeconds);
    tuneDecay    = std::exp (-hopSeconds / 15.0);
}

void KeyAnalyzer::resetSectionTrackers()
{
    accSection.fill (0.0);
    accBassSection.fill (0.0);
    accSectionAnchor.fill (0.0);
    accSectionAnchorBass.fill (0.0);
    chordSection.fill (0.0);
    cadenceSection.fill (0.0);
    smoothedSecScores.fill (0.0);
    sectionWeight = 0.0;
    sectionAnchorWeight = 0.0;
    sectionSeconds = 0.0;
    sectionMismatchSeconds = 0.0;
}

void KeyAnalyzer::notifyTransportGap (double gapSeconds)
{
    // Do not invent a cadence between audio from opposite sides of a seek.
    // Retain evidence so a short DAW loop can still reach the initial lock.
    ringPos = sinceHop = filled = 0;
    prevTriad.fill (0.0);
    if (! holdEnabled && accWeight > 0.0 && gapSeconds >= kSongBreakSeconds)
        songBreakArmed = true;
}

void KeyAnalyzer::startNewSongFromBreak()
{
    songBreakArmed = false;
    if (holdEnabled) return;

    acc.fill (0.0); accFast.fill (0.0);
    accBass.fill (0.0); accBassFast.fill (0.0);
    accAnchor.fill (0.0); accAnchorBass.fill (0.0);
    chordScore.fill (0.0); chordFast.fill (0.0);
    cadenceScore.fill (0.0); cadenceFast.fill (0.0);
    prevTriad.fill (0.0);
    resetSectionTrackers();
    // Keep the last committed key across a rest. Fresh material must confirm
    // a change; an intro or the first chord after a pause cannot retune alone.
    decision.interrupt();
    accWeight = fastWeight = anchorWeight = totalPitchedSeconds = 0.0;
    initialAnchorConflictSeconds = 0.0; initialAnchorFadeStart = 8.0; initialAnchorReleased = false;
    tuneRe = tuneIm = tuneFastRe = tuneFastIm = 0.0;
    smoothConf = 0.0;
    result.confidence = 0.0f;
}

void KeyAnalyzer::reset()
{
    std::fill (ring.begin(), ring.end(), 0.0f);
    std::fill (ringSide.begin(), ringSide.end(), 0.0f);
    hasSideSignal = false;
    songBreakArmed = false;
    ringPos = sinceHop = filled = 0;
    acc.fill (0.0); accFast.fill (0.0);
    accBass.fill (0.0); accBassFast.fill (0.0);
    accAnchor.fill (0.0); accAnchorBass.fill (0.0);
    chordScore.fill (0.0); chordFast.fill (0.0);
    cadenceScore.fill (0.0); cadenceFast.fill (0.0);
    prevTriad.fill (0.0);
    resetSectionTrackers();
    decision.reset();
    peaks.clear();
    accWeight = fastWeight = anchorWeight = totalPitchedSeconds = 0.0;
    initialAnchorConflictSeconds = 0.0; initialAnchorFadeStart = 8.0; initialAnchorReleased = false;
    tuneRe = tuneIm = tuneFastRe = tuneFastIm = 0.0;
    silenceTime = unpitchedTime = smoothConf = 0.0;
    result = Result();
}

void KeyAnalyzer::processBlock (const float* mono, int numSamples)
{
    if (fft == nullptr) prepare (sampleRate);
    hasSideSignal = false;
    for (int i = 0; i < numSamples; ++i)
    {
        ring[(size_t) ringPos] = mono[i];
        ringPos = (ringPos + 1) % fftSize;
        filled = std::min (filled + 1, fftSize);
        if (++sinceHop >= hopSize)
        {
            sinceHop = 0;
            if (filled == fftSize) analyseFrame();
        }
    }
}

void KeyAnalyzer::processStereoBlock (const float* left, const float* right, int numSamples)
{
    if (right == nullptr)
    {
        processBlock (left, numSamples);
        return;
    }
    if (fft == nullptr) prepare (sampleRate);
    hasSideSignal = true;
    for (int i = 0; i < numSamples; ++i)
    {
        ring[(size_t) ringPos]     = 0.5f * (left[i] + right[i]);
        ringSide[(size_t) ringPos] = 0.5f * (left[i] - right[i]);
        ringPos = (ringPos + 1) % fftSize;
        filled = std::min (filled + 1, fftSize);
        if (++sinceHop >= hopSize)
        {
            sinceHop = 0;
            if (filled == fftSize) analyseFrame();
        }
    }
}

void KeyAnalyzer::analyseFrame()
{
    const double hopSeconds = hopSize / sampleRate;
    for (int i = 0; i < fftSize; ++i)
        work[(size_t) i] = ring[(size_t) ((ringPos + i) % fftSize)] * window[(size_t) i];
    std::fill (work.begin() + fftSize, work.end(), 0.0f);
    fft->performFrequencyOnlyForwardTransform (work.data(), true);

    if (hasSideSignal)
    {
        float sideEnergy = 0.0f;
        for (int i = 0; i < fftSize; i += 8) sideEnergy = std::max (sideEnergy, std::abs (ringSide[(size_t) i]));
        if (sideEnergy > 1.0e-4f)
        {
            for (int i = 0; i < fftSize; ++i)
                workSide[(size_t) i] = ringSide[(size_t) ((ringPos + i) % fftSize)] * window[(size_t) i];
            std::fill (workSide.begin() + fftSize, workSide.end(), 0.0f);
            fft->performFrequencyOnlyForwardTransform (workSide.data(), true);
            for (int b = 0; b <= fftSize / 2; ++b)
                work[(size_t) b] = std::hypot (work[(size_t) b], 0.75f * workSide[(size_t) b]);
        }
    }

    const double binHz = sampleRate / fftSize;
    const int lo     = std::max (2, (int) std::floor (kMinHz / binHz));
    const int midLo  = std::max (2, (int) std::floor (kMidMinHz / binHz));
    const int hi     = std::min (fftSize / 2 - 2, (int) std::ceil (kMaxHz / binHz));
    const int scanHi = std::min (fftSize / 2 - 2, (int) std::ceil (kScanMaxHz / binHz));

    float maxMag = 0.0f, midMaxMag = 0.0f;
    double midMeanMag = 0.0;
    for (int b = lo; b <= hi; ++b)
    {
        maxMag = std::max (maxMag, work[(size_t) b]);
        if (b >= midLo)
        {
            midMaxMag = std::max (midMaxMag, work[(size_t) b]);
            midMeanMag += work[(size_t) b];
        }
    }
    midMeanMag /= std::max (1, hi - midLo + 1);

    // A long quiet/unpitched break starts a fresh history on the next tonal
    // frame. The public key is retained until a different key is confirmed.
    if (maxMag < 3.5e-4f * (float) fftSize)
    {
        silenceTime += hopSeconds;
        if (silenceTime >= kSongBreakSeconds && accWeight > 0.0)
            songBreakArmed = true;
        rejectFrame (true);
        return;
    }

    // Tonalness / Spectral Crest Factor gate in the harmonic mid band (130..1760 Hz)
    const double midCrest = midMeanMag > 0.0 ? (double) midMaxMag / midMeanMag : 0.0;
    const double tonalGate = juce::jlimit (0.0, 1.0, (midCrest - 7.5) / 8.0);
    if (tonalGate < 0.08 || midMaxMag < maxMag * 0.22f)
    {
        if (unpitchedTime + hopSeconds >= kSongBreakSeconds && accWeight > 0.0)
            songBreakArmed = true;
        rejectFrame (false);
        return;
    }

    double logMax = 0.0;
    for (int k = 0; k < kNumLogBins; ++k)
    {
        const auto& flt = logFilters[(size_t) k];
        double sum = 0.0;
        for (size_t j = 0; j < flt.weights.size(); ++j)
            sum += (double) work[(size_t) (flt.startBin + (int) j)] * (double) flt.weights[j];
        logSpec[(size_t) k] = sum;
        logMax = std::max (logMax, sum);
    }
    if (logMax <= 0.0) { rejectFrame (false); return; }

    for (int k = 0; k < kNumLogBins; ++k)
    {
        const int c = juce::jlimit (kWhitenRadius, kNumLogBins - 1 - kWhitenRadius, k);
        double mu = 0.0;
        for (int j = -kWhitenRadius; j <= kWhitenRadius; ++j)
            mu += logSpec[(size_t) (c + j)] * (double) whitenKernel[(size_t) (j + kWhitenRadius)];
        mu /= (double) whitenKernelSum;
        whitenMean[(size_t) k] = mu;

        double var = 0.0;
        for (int j = -kWhitenRadius; j <= kWhitenRadius; ++j)
        {
            const double d = logSpec[(size_t) (c + j)] - mu;
            var += d * d * (double) whitenKernel[(size_t) (j + kWhitenRadius)];
        }
        var /= (double) whitenKernelSum;
        whitenStd[(size_t) k] = std::sqrt (std::max (var, 1.0e-12 * logMax * logMax));
    }

    const double stdFloor = 0.04 * logMax;
    for (int k = 0; k < kNumLogBins; ++k)
    {
        const double z = std::max (0.0, logSpec[(size_t) k] - whitenMean[(size_t) k])
                       / (whitenStd[(size_t) k] + stdFloor);
        whitenedSpec[(size_t) k] = z;
    }

    hssResidual = whitenedSpec;
    hssPitch.fill (0.0);
    double initialHssMax = 0.0;

    for (int iter = 0; iter < kHssIterations; ++iter)
    {
        int bestBin = -1;
        double bestSum = 0.0;
        for (int b = 0; b < kNumPitchBins; ++b)
        {
            if (hssResidual[(size_t) b] <= 1.0e-5) continue;
            double hSum = 0.0;
            for (int h = 0; h < kHssHarmonics; ++h)
            {
                const int hb = b + kHarmonicBinOffsets[h];
                if (hb >= kNumLogBins) break;
                double hVal = hssResidual[(size_t) hb];
                if (hb > 0) hVal = std::max (hVal, 0.75 * hssResidual[(size_t) (hb - 1)]);
                if (hb + 1 < kNumLogBins) hVal = std::max (hVal, 0.75 * hssResidual[(size_t) (hb + 1)]);
                hSum += hVal / (double) (h + 1);
            }
            if (hSum > bestSum)
            {
                bestSum = hSum;
                bestBin = b;
            }
        }

        if (bestBin < 0) break;
        if (iter == 0) initialHssMax = bestSum;
        if (bestSum < initialHssMax * kHssStopRatio) break;

        const double f0Energy = hssResidual[(size_t) bestBin];
        hssPitch[(size_t) bestBin] += bestSum;

        for (int h = 0; h < kHssHarmonics; ++h)
        {
            const int hb = bestBin + kHarmonicBinOffsets[h];
            if (hb >= kNumLogBins) break;
            const double sub = (h == 0) ? f0Energy : std::max (f0Energy / (double) (h + 1), 0.75 * hssResidual[(size_t) hb]);
            hssResidual[(size_t) hb] = std::max (0.0, hssResidual[(size_t) hb] - sub);
            if (hb > 0)
                hssResidual[(size_t) (hb - 1)] = std::max (0.0, hssResidual[(size_t) (hb - 1)] - 0.5 * sub);
            if (hb + 1 < kNumLogBins)
                hssResidual[(size_t) (hb + 1)] = std::max (0.0, hssResidual[(size_t) (hb + 1)] - 0.5 * sub);
        }
    }

    double maxHssPitch = 0.0;
    for (int b = 0; b < kNumPitchBins; ++b)
    {
        hssPitch[(size_t) b] = (hssPitch[(size_t) b] + 0.15 * hssResidual[(size_t) b])
                             * (double) shepardBell[(size_t) b];
        maxHssPitch = std::max (maxHssPitch, hssPitch[(size_t) b]);
    }

    peaks.clear();
    for (int b = lo; b <= scanHi; ++b)
    {
        const float m = work[(size_t) b];
        if (m <= work[(size_t) b - 1] || m < work[(size_t) b + 1]) continue;
        if (m < maxMag * (float) kFloor) continue;

        const double a = std::log (std::max (work[(size_t) b - 1], 1.0e-12f));
        const double c = std::log (m);
        const double e = std::log (std::max (work[(size_t) b + 1], 1.0e-12f));
        const double den = a - 2.0 * c + e;
        const double off = den != 0.0 ? juce::jlimit (-0.5, 0.5, 0.5 * (a - e) / den) : 0.0;
        const double freq = (b + off) * binHz;

        const int logIdx = juce::jlimit (0, kNumLogBins - 1,
            (int) std::round ((double) kBinsPerOctave * std::log2 (std::max (freq, kMinHz) / kMinHz)));
        const double localEnv = whitenMean[(size_t) logIdx] + whitenStd[(size_t) logIdx] + stdFloor;
        const double whitenedMag = ((double) m / localEnv) * (0.35 * logMax);
        const double blendedMag  = 0.78 * whitenedMag + 0.22 * (double) m;
        peaks.push_back ({ freq, (double) m, blendedMag, blendedMag, true });
    }

    if (peaks.empty() && maxHssPitch <= 0.0) { rejectFrame (false); return; }

    const size_t nPeaks = peaks.size();
    std::fill (isOctaveHarmonic.begin(), isOctaveHarmonic.begin() + (std::ptrdiff_t) nPeaks, (unsigned char) 0);
    int verifiedHarmonics = 0;
    double maxCleanMag = 0.0;
    for (size_t i = 0; i < nPeaks; ++i)
    {
        const double f0 = peaks[i].freq;
        if (f0 > 1100.0) break;
        const double m0 = peaks[i].cleanMag;
        if (m0 < maxMag * 0.03) continue;

        bool hasOctave = false;
        double refinedFreqSum = f0;
        double refinedWeight  = 1.0;

        for (size_t j = i + 1; j < nPeaks; ++j)
        {
            const double ratio = peaks[j].freq / f0;
            if (ratio > 8.3) break;
            const int h = (int) std::round (ratio);
            const double tol = (f0 < 100.0) ? 0.028 * h : 0.018 * h;
            if (h >= 2 && h <= 8 && std::abs (ratio - (double) h) < tol)
            {
                if (h == 2 || h == 4 || h == 8)
                {
                    if (peaks[j].mag > maxMag * 0.05) hasOctave = true;
                    if (f0 < 230.0 && peaks[j].mag > peaks[i].mag * 0.15)
                    {
                        const double hw = 1.5;
                        refinedFreqSum += (peaks[j].freq / (double) h) * hw;
                        refinedWeight  += hw;
                        peaks[i].bassSalience += 0.65 * peaks[j].cleanMag;
                    }
                    peaks[i].cleanMag += 0.25 * (peaks[j].cleanMag / (double) h);
                    peaks[j].cleanMag *= 0.55;
                    if (peaks[j].mag < peaks[i].mag * 0.85)
                        isOctaveHarmonic[j] = true;
                    continue;
                }
                if (isOctaveHarmonic[i] && h >= 3) continue;
                if (f0 < 230.0 && h == 3 && peaks[j].mag > peaks[i].mag * 0.15)
                {
                    refinedFreqSum += (peaks[j].freq / 3.0) * 0.6;
                    refinedWeight  += 0.6;
                    peaks[i].bassSalience += 0.35 * peaks[j].cleanMag;
                }
                peaks[i].cleanMag += 0.30 * (peaks[j].cleanMag / (double) h);
                peaks[j].cleanMag *= 0.14;
                peaks[j].isFundamental = false;
            }
        }
        if (refinedWeight > 1.0)
            peaks[i].freq = refinedFreqSum / refinedWeight;
        if (hasOctave)
        {
            peaks[i].cleanMag *= 1.18;
            if (f0 >= 95.0) ++verifiedHarmonics;
        }
    }

    for (const auto& pk : peaks) maxCleanMag = std::max (maxCleanMag, pk.cleanMag);
    if (verifiedHarmonics < 1 && midCrest < 12.5)
    {
        if (unpitchedTime + hopSeconds >= kSongBreakSeconds && accWeight > 0.0)
            songBreakArmed = true;
        rejectFrame (false);
        return;
    }

    // Refresh analysis after a long break, while keeping the committed output.
    if (songBreakArmed)
        startNewSongFromBreak();

    silenceTime = 0.0;
    unpitchedTime = 0.0;

    double tRe = 0.0, tIm = 0.0;
    for (const auto& pk : peaks)
    {
        if (pk.freq < 80.0 || pk.freq > 750.0 || ! pk.isFundamental || pk.cleanMag < maxCleanMag * 0.12) continue;
        const double w = std::pow (pk.cleanMag / std::max (maxCleanMag, 1.0e-9), kGamma);
        const double cents = 1200.0 * std::log2 (pk.freq / 440.0);
        tRe += w * std::cos (kTwoPi * cents / 100.0);
        tIm += w * std::sin (kTwoPi * cents / 100.0);
    }

    tuneRe     = tuneRe     * tuneDecay + tRe * tonalGate;
    tuneIm     = tuneIm     * tuneDecay + tIm * tonalGate;
    tuneFastRe = tuneFastRe * fastDecay + tRe * tonalGate;
    tuneFastIm = tuneFastIm * fastDecay + tIm * tonalGate;

    const double useRe = (accWeight < 25.0) ? tuneFastRe : tuneRe;
    const double useIm = (accWeight < 25.0) ? tuneFastIm : tuneIm;
    const double tuningCents = (useRe == 0.0 && useIm == 0.0) ? 0.0
                             : std::atan2 (useIm, useRe) / kTwoPi * 100.0;

    std::array<double, 12> peakChroma {};
    const auto bassFrame = autokey::bass::extract (work.data(), fftSize, sampleRate, tuningCents, maxMag);

    for (const auto& pk : peaks)
    {
        if (pk.freq > kMaxHz || pk.cleanMag <= 0.0) continue;

        const double semis = 69.0 + 12.0 * std::log2 (pk.freq / 440.0) - tuningCents / 100.0;
        const double nearest = std::round (semis);
        const double dev = std::abs (semis - nearest);
        if (dev > 0.46) continue;

        const double shape = std::cos (juce::MathConstants<double>::pi * (semis - nearest));
        int pc = (int) nearest % 12; if (pc < 0) pc += 12;

        if (pk.freq >= kMinHz)
        {
            const double w = std::pow (pk.cleanMag / std::max (maxCleanMag, 1.0e-9), kGamma) * shape * shape;
            peakChroma[(size_t) pc] += w;
        }

    }

    std::array<double, 12> hssChroma {};
    if (maxHssPitch > 0.0)
    {
        const double binShift = (tuningCents / 100.0) * (double) kBinsPerSemitone;
        for (int b = 0; b < kNumPitchBins; ++b)
        {
            if (hssPitch[(size_t) b] <= 0.0) continue;
            const double shiftedBin = (double) b - binShift;
            const double semis = 33.0 + shiftedBin / (double) kBinsPerSemitone;
            const int nearest = (int) std::round (semis);
            const double dev = std::abs (semis - (double) nearest);
            if (dev > 0.48) continue;
            const double shape = std::cos (juce::MathConstants<double>::pi * dev);
            int pc = nearest % 12; if (pc < 0) pc += 12;
            hssChroma[(size_t) pc] += (hssPitch[(size_t) b] / maxHssPitch) * shape * shape;
        }
    }

    double pMax = 0.0, hMax = 0.0;
    for (int i = 0; i < 12; ++i)
    {
        pMax = std::max (pMax, peakChroma[(size_t) i]);
        hMax = std::max (hMax, hssChroma[(size_t) i]);
    }
    if (pMax <= 0.0 && hMax <= 0.0) { rejectFrame (false); return; }

    std::array<double, 12> frame {};
    for (int i = 0; i < 12; ++i)
    {
        const double pVal = pMax > 0.0 ? (peakChroma[(size_t) i] / pMax) : 0.0;
        const double hVal = hMax > 0.0 ? (hssChroma[(size_t) i] / hMax) : 0.0;
        frame[(size_t) i] = 0.58 * pVal + 0.42 * hVal;
    }

    double fMax = 0.0, fSum = 0.0, bMax = 0.0;
    for (int i = 0; i < 12; ++i)
    {
        fMax  = std::max (fMax, frame[(size_t) i]);
        fSum += frame[(size_t) i];
        bMax  = std::max (bMax, bassFrame[(size_t) i]);
    }
    if (fMax <= 0.0 || fSum <= 0.0) { rejectFrame (false); return; }

    std::array<double, 12> normFrame {};
    for (int i = 0; i < 12; ++i)
        normFrame[(size_t) i] = 0.55 * (frame[(size_t) i] / fMax) + 0.45 * (frame[(size_t) i] / (fSum * 0.35));

    std::array<double, 12> normBass {};
    if (bMax > 0.0)
        for (int i = 0; i < 12; ++i) normBass[(size_t) i] = bassFrame[(size_t) i] / bMax;
    // No bass observed: retain zeros instead of relabelling upper voices as bass.

    std::array<double, 24> frameTriad {};
    for (int root = 0; root < 12; ++root)
    {
        const double rE = 0.25 * normBass[(size_t) root] + 0.75 * normFrame[(size_t) root];
        if (rE < 0.25) continue;
        const double maj3  = normFrame[(size_t) ((root + 4) % 12)];
        const double min3  = normFrame[(size_t) ((root + 3) % 12)];
        const double fifth = normFrame[(size_t) ((root + 7) % 12)];
        if (maj3 > min3 * 1.12 && fifth > 0.12)
            frameTriad[(size_t) root] = std::cbrt (std::max (0.0, rE * maj3 * fifth)) * std::max (0.0, 1.0 - 0.30 * min3 / std::max (maj3, 1.0e-9));
        else if (min3 > maj3 * 1.12 && fifth > 0.12)
            frameTriad[(size_t) (12 + root)] = std::cbrt (std::max (0.0, rE * min3 * fifth)) * std::max (0.0, 1.0 - 0.30 * maj3 / std::max (min3, 1.0e-9));
    }

    std::array<double, 24> frameCadence {};
    for (int t = 0; t < 12; ++t)
    {
        const double curI   = frameTriad[(size_t) t];
        const double curIV  = frameTriad[(size_t) ((t + 5) % 12)];
        const double curV   = frameTriad[(size_t) ((t + 7) % 12)];
        const double curVi  = frameTriad[(size_t) (12 + (t + 9) % 12)];
        const double prevV  = prevTriad[(size_t) ((t + 7) % 12)];
        const double prevIV = prevTriad[(size_t) ((t + 5) % 12)];
        const double prevII = prevTriad[(size_t) (12 + (t + 2) % 12)];
        const double prevI  = prevTriad[(size_t) t];
        const double prevVi = prevTriad[(size_t) (12 + (t + 9) % 12)];

        frameCadence[(size_t) t] = 1.30 * std::sqrt (prevV * curI)
                                 + 0.55 * std::sqrt (prevIV * curI)
                                 + 0.65 * std::sqrt (prevII * curV)
                                 + 0.55 * std::sqrt (prevIV * curV)
                                 + 0.45 * std::sqrt (prevI * curV)
                                 + 0.52 * std::sqrt (prevI * curVi)
                                 + 0.48 * std::sqrt (prevVi * curIV)
                                 + 0.20 * std::sqrt (prevV * curVi);

        const double curMinI   = frameTriad[(size_t) (12 + t)];
        const double curMinIV  = frameTriad[(size_t) (12 + (t + 5) % 12)];
        const double curMinV   = std::max (frameTriad[(size_t) ((t + 7) % 12)], frameTriad[(size_t) (12 + (t + 7) % 12)]);
        const double curbVI    = frameTriad[(size_t) ((t + 8) % 12)];
        const double curbVII   = frameTriad[(size_t) ((t + 10) % 12)];
        const double prevMinI  = prevTriad[(size_t) (12 + t)];
        const double prevMinV  = std::max (prevTriad[(size_t) ((t + 7) % 12)], prevTriad[(size_t) (12 + (t + 7) % 12)]);
        const double prevMinIV = prevTriad[(size_t) (12 + (t + 5) % 12)];
        const double prevbVI   = prevTriad[(size_t) ((t + 8) % 12)];
        const double prevbVII  = prevTriad[(size_t) ((t + 10) % 12)];

        frameCadence[(size_t) (12 + t)] = 1.25 * std::sqrt (prevMinV * curMinI)
                                        + 0.90 * std::sqrt (prevbVII * curMinI)
                                        + 0.65 * std::sqrt (prevMinIV * curMinI)
                                        + 0.78 * std::sqrt (prevMinI * curMinIV)
                                        + 0.58 * std::sqrt (prevMinI * curbVI)
                                        + 0.58 * std::sqrt (prevMinIV * curbVII)
                                        + 0.52 * std::sqrt (prevbVI * curbVII)
                                        + 0.55 * std::sqrt (prevbVII * curMinV)
                                        + 0.45 * std::sqrt (prevMinIV * curMinV);
    }

    // Equal response when all chord-transition terms have equal evidence.
    // These constants are the sums of the respective coefficients above.
    for (int key = 0; key < 12; ++key)
    {
        frameCadence[(size_t) key] /= 4.70;
        frameCadence[(size_t) (12 + key)] /= 6.26;
    }

    const double triadMemDecay = std::exp (-hopSeconds / 0.75);
    for (int i = 0; i < 24; ++i)
        prevTriad[(size_t) i] = prevTriad[(size_t) i] * triadMemDecay + frameTriad[(size_t) i] * (1.0 - triadMemDecay);

    for (int i = 0; i < 12; ++i)
    {
        acc[(size_t) i]         = acc[(size_t) i]         * decay     + normFrame[(size_t) i];
        accFast[(size_t) i]     = accFast[(size_t) i]     * fastDecay + normFrame[(size_t) i];
        accBass[(size_t) i]     = accBass[(size_t) i]     * decay     + normBass[(size_t) i];
        accBassFast[(size_t) i] = accBassFast[(size_t) i] * fastDecay + normBass[(size_t) i];
    }
    for (int i = 0; i < 24; ++i)
    {
        chordScore[(size_t) i]   = chordScore[(size_t) i]   * decay     + frameTriad[(size_t) i];
        chordFast[(size_t) i]    = chordFast[(size_t) i]    * fastDecay + frameTriad[(size_t) i];
        cadenceScore[(size_t) i] = cadenceScore[(size_t) i] * decay     + frameCadence[(size_t) i];
        cadenceFast[(size_t) i]  = cadenceFast[(size_t) i]  * fastDecay + frameCadence[(size_t) i];
    }

    accWeight  = accWeight  * decay     + 1.0;
    fastWeight = fastWeight * fastDecay + 1.0;
    totalPitchedSeconds += hopSeconds;

    // Capture Bar 1 (first 0.85s of pitched frames) as the initial phrase anchor
    const double anchorSeconds = anchorWeight * hopSeconds;
    if (anchorSeconds < 0.85)
    {
        const double aw = (anchorWeight < 2.0) ? 0.45 : 1.0;
        for (int i = 0; i < 12; ++i)
        {
            accAnchor[(size_t) i]     += normFrame[(size_t) i] * aw;
            accAnchorBass[(size_t) i] += normBass[(size_t) i]  * aw;
        }
        anchorWeight += 1.0;
    }

    // Track gapless song-change candidate section when already locked onto a key:
    const int currentLocked = decision.key();
    if (currentLocked >= 0 && ! holdEnabled)
    {
        const int lockTonic = currentLocked % 12;
        const bool lockMinor = (currentLocked >= 12);
        const auto& diatProfile = lockMinor ? KeyProfiles::tonartDiatonicMinor : KeyProfiles::tonartDiatonicMajor;
        double inScaleSum = 0.0, outScaleSum = 0.0;
        for (int p = 0; p < 12; ++p)
        {
            const double val = normFrame[(size_t) ((lockTonic + p) % 12)];
            if (diatProfile[(size_t) p] > 0.0f) inScaleSum += val;
            else outScaleSum += val;
        }
        const double outOfScaleRatio = (inScaleSum + outScaleSum > 0.0)
            ? (outScaleSum / (inScaleSum + outScaleSum)) : 0.0;

        // Detect if the current frame plays a dominant triad that has NEVER appeared in the
        // locked song (e.g. Am at Bar 1 when switching from Em-C-G-D to Am-F-C-G):
        double maxKnownTriad = 0.0;
        for (double v : chordScore) maxKnownTriad = std::max (maxKnownTriad, v);
        int domFrameTriad = -1;
        double domFrameTriadVal = 0.0;
        for (int i = 0; i < 24; ++i)
        {
            if (frameTriad[(size_t) i] > domFrameTriadVal)
            {
                domFrameTriadVal = frameTriad[(size_t) i];
                domFrameTriad = i;
            }
        }
        const bool novelTriad = (domFrameTriad >= 0 && domFrameTriad != currentLocked
            && domFrameTriadVal > 0.28 && maxKnownTriad > 0.0
            && chordScore[(size_t) domFrameTriad] < 0.10 * maxKnownTriad);

        // If a candidate section is already running (>= 2.5s), check if the music just switched
        // to YET ANOTHER song (strong out-of-scale energy relative to the candidate section):
        if (sectionSeconds >= 2.5 && sectionWeight > 0.0)
        {
            const auto curSecRank = rankKey (accSection, accBassSection, accSectionAnchor, accSectionAnchorBass,
                                             chordSection, cadenceSection, 0.35, -1);
            if (curSecRank.best >= 0)
            {
                const int secTonic = curSecRank.best % 12;
                const bool secMinor = (curSecRank.best >= 12);
                const auto& secDiat = secMinor ? KeyProfiles::tonartDiatonicMinor : KeyProfiles::tonartDiatonicMajor;
                double secIn = 0.0, secOut = 0.0;
                for (int p = 0; p < 12; ++p)
                {
                    const double val = normFrame[(size_t) ((secTonic + p) % 12)];
                    if (secDiat[(size_t) p] > 0.0f) secIn += val;
                    else secOut += val;
                }
                if (secIn + secOut > 0.0 && (secOut / (secIn + secOut)) > 0.16)
                    resetSectionTrackers();
            }
        }

        const bool isLockedTonicFrame = (domFrameTriad == currentLocked)
            && (normBass[(size_t) lockTonic] > 0.65);
        // A held vi chord followed by the established tonic is not a new
        // relative-key phrase. Clear that opening hint before it can collect
        // unrelated chords from the resumed progression.
        if (isLockedTonicFrame && sectionSeconds > 2.0)
        {
            double maximum=0;for(double value:chordSection)maximum=std::max(maximum,value);
            int count=0;for(double value:chordSection)if(value>0.30*maximum && value>0)++count;
            if(count<2)resetSectionTrackers();
        }


        if (outOfScaleRatio > 0.12 || novelTriad || sectionSeconds > 0.0)
        {
            if (outOfScaleRatio > 0.12 || novelTriad)
                sectionMismatchSeconds += hopSeconds;
            else if (isLockedTonicFrame)
                sectionMismatchSeconds = std::max (0.0, sectionMismatchSeconds - 1.2 * hopSeconds);

            if (sectionMismatchSeconds <= 0.0 && sectionSeconds < 1.5)
            {
                resetSectionTrackers();
            }
            else
            {
                sectionSeconds += hopSeconds;
                // Wait 2 hops (~0.17s = half an FFT window) before accumulating into the new section
                // so the 16384-sample Hann window no longer contains 75% of the old song's last chord!
                if (sectionSeconds >= 1.9 * hopSeconds)
                {
                    for (int i = 0; i < 12; ++i)
                    {
                        accSection[(size_t) i]     = accSection[(size_t) i]     * sectionDecay + normFrame[(size_t) i];
                        accBassSection[(size_t) i] = accBassSection[(size_t) i] * sectionDecay + normBass[(size_t) i];
                    }
                    for (int i = 0; i < 24; ++i)
                    {
                        chordSection[(size_t) i]   = chordSection[(size_t) i]   * sectionDecay + frameTriad[(size_t) i];
                        cadenceSection[(size_t) i] = cadenceSection[(size_t) i] * sectionDecay + frameCadence[(size_t) i];
                    }
                    sectionWeight = sectionWeight * sectionDecay + 1.0;

                    if (sectionAnchorWeight * hopSeconds < 0.75)
                    {
                        const double sw = (sectionAnchorWeight < 1.0) ? 0.65 : 1.0;
                        for (int i = 0; i < 12; ++i)
                        {
                            accSectionAnchor[(size_t) i]     += normFrame[(size_t) i] * sw;
                            accSectionAnchorBass[(size_t) i] += normBass[(size_t) i]  * sw;
                        }
                        sectionAnchorWeight += 1.0;
                    }
                }
            }
        }
    }

    evaluate();
}

void KeyAnalyzer::evaluate()
{
    const double hopSeconds = hopSize / sampleRate;
    const int currentLocked = decision.key();

    double effectiveAnchorStrength = 0.0;
    if (anchorWeight * hopSeconds > 0.10)
    {
        // Retain the opening cue through a relative-major/minor ambiguity.
        // Sustained conflicting evidence releases it earlier, so a ii-V-I
        // opening can resolve away from its first chord. A single passing
        // chord must not turn that prior on/off from one frame to the next.
        double anchorStart = 3.25;
        if (currentLocked < 0)
        {
            if (! initialAnchorReleased)
            {
                const auto opening = rankKey (accAnchor, accAnchorBass, {}, {}, {}, {}, 0.0);
                const auto unanchored = rankKey (acc, accBass, {}, {}, chordScore, cadenceScore, 0.0);
                double cadenceMax = 0.0;
                for (double v : cadenceScore) cadenceMax = std::max (cadenceMax, v);
                const bool resolvesElsewhere = cadenceMax > 0.0
                    && cadenceScore[(size_t) unanchored.best] > 0.25 * cadenceMax
                    && cadenceScore[(size_t) unanchored.best] > 1.2 * cadenceScore[(size_t) opening.best];
                if (opening.best == unanchored.best || relativePair (opening.best, unanchored.best))
                    initialAnchorConflictSeconds = 0.0;
                else if (unanchored.bestR - unanchored.secondR >= 0.06 && resolvesElsewhere)
                    initialAnchorConflictSeconds += hopSeconds;
                else
                    initialAnchorConflictSeconds = std::max (0.0, initialAnchorConflictSeconds - hopSeconds);
                if (initialAnchorConflictSeconds >= 1.25)
                {
                    initialAnchorReleased = true;
                    initialAnchorFadeStart = std::min (8.0, std::max (3.25, totalPitchedSeconds));
                }
            }
            anchorStart = initialAnchorFadeStart;
        }
        const double decayAfterFirstPhrase = (totalPitchedSeconds <= anchorStart)
            ? 1.0
            : std::exp (-(totalPitchedSeconds - anchorStart) / 1.8);
        effectiveAnchorStrength = 0.34 * decayAfterFirstPhrase;
    }

    auto slow = rankKey (acc, accBass, accAnchor, accAnchorBass, chordScore, cadenceScore, effectiveAnchorStrength, currentLocked, currentLocked < 0 ? 0.34 : 0.08);
    auto fast = rankKey (accFast, accBassFast, accSectionAnchor, accSectionAnchorBass, chordFast, cadenceFast, sectionWeight > 0.0 ? 0.34 : 0.0, -1, 0.34, currentLocked >= 0 ? &acc : nullptr, currentLocked);

    Ranked proposal=slow;
    if (currentLocked>=0)
    {
        proposal=Ranked {};
        double recentWeight=0.45;
        if(fast.best>=0 && slow.best>=0)
        {
            static constexpr bool majorScale[12]={true,false,true,false,true,true,false,true,false,true,false,true};
            const int oldFamily=currentLocked<12?currentLocked:(currentLocked%12+3)%12;
            const int newFamily=fast.best<12?fast.best:(fast.best%12+3)%12;
            int changedNotes=0;
            for(int pc=0;pc<12;++pc)
                if(majorScale[(pc-oldFamily+12)%12]!=majorScale[(pc-newFamily+12)%12])++changedNotes;
            if(changedNotes>=4)recentWeight=0.95;
        }
        for(int major=0;major<12;++major)
        {
            const int minor=12+(major+9)%12;
            const double family=(1.0-recentWeight)*std::max(slow.r[major],slow.r[minor])
                + recentWeight*std::max(fast.r[major],fast.r[minor]);
            const double contrast=(1.0-recentWeight)*(slow.r[major]-slow.r[minor])
                + recentWeight*(fast.r[major]-fast.r[minor]);
            proposal.r[major]=family-std::max(0.0,-contrast);
            proposal.r[minor]=family-std::max(0.0,contrast);
        }
        // A repeated diatonic loop can make the relative major correlate
        // better even while the established minor tonic keeps returning.
        // Preserve that mode prior until a different phrase supplies its own
        // bass-root opening and harmonic context. This does not change the
        // collection score or the decision policy's confirmation durations.
        const int relative = currentLocked < 12
            ? 12 + (currentLocked + 9) % 12 : (currentLocked % 12 + 3) % 12;
        double recentChordMax = 0.0, recentChromaMax = 0.0;
        for (double value : chordFast) recentChordMax = std::max (recentChordMax, value);
        for (double value : accFast) recentChromaMax = std::max (recentChromaMax, value);
        const int relativeRoot = relative % 12;
        // V-major -> i plus its raised seventh supplies independent minor
        // evidence outside the shared natural scale (e.g. E-G#-B -> Am).
        const bool harmonicMinorResolution = relative >= 12
            && recentChordMax > 0.0 && recentChromaMax > 0.0
            && chordFast[(size_t) relative] > 0.25 * recentChordMax
            && chordFast[(size_t) ((relativeRoot + 7) % 12)] > 0.12 * recentChordMax
            && accFast[(size_t) ((relativeRoot + 11) % 12)] > 0.08 * recentChromaMax
            && cadenceFast[(size_t) relative] > 1.20 * cadenceFast[(size_t) currentLocked];
        // Resolve a minor intro to relative major when the old bass root has
        // actually receded and the new I-IV-V phrase is present. The normal
        // six-second confirmation still rejects one passing III chord.
        const bool majorPhraseResolution = relative < 12 && recentChordMax > 0.0
            && accBassFast[(size_t) relativeRoot] > 0.5
            && accBassFast[(size_t) relativeRoot] > 4.0 * accBassFast[(size_t) (currentLocked % 12)]
            && chordFast[(size_t) relative] > 0.25 * recentChordMax
            && chordFast[(size_t) ((relativeRoot + 5) % 12)] > 0.08 * recentChordMax
            && chordFast[(size_t) ((relativeRoot + 7) % 12)] > 0.12 * recentChordMax;
        if (! harmonicMinorResolution && ! majorPhraseResolution && proposal.r[relative] > proposal.r[currentLocked])
            std::swap (proposal.r[relative], proposal.r[currentLocked]);

        // When the note collection stays the same, a genuinely new phrase
        // may establish its relative tonic. Require a real bass-root opening
        // and several different chords, not a single emphasized third/vi chord.
        if(sectionSeconds>=2.0 && sectionWeight>0.0)
        {
            const int nextRoot=relative%12;
            double maximum=0;for(double value:chordSection)maximum=std::max(maximum,value);
            int distinct=0;for(double value:chordSection)if(value>0.30*maximum && value>0)++distinct;
            if(distinct>=3 && accSectionAnchorBass[(size_t)nextRoot]>1.5*accSectionAnchorBass[(size_t)(currentLocked%12)]
                && accSectionAnchorBass[(size_t)nextRoot]>0.5)
            {
                const auto section=rankKey(accSection,accBassSection,accSectionAnchor,accSectionAnchorBass,
                    chordSection,cadenceSection,0.58,-1,0.58);
                const double contrast=section.r[relative]-section.r[currentLocked];
                if(contrast>=0.10)
                {
                    const double family=std::max(proposal.r[currentLocked],proposal.r[relative]);
                    proposal.r[relative]=family;
                    proposal.r[currentLocked]=family-std::min(contrast,0.6);
                }
            }
        }
        for(int code=0;code<24;++code)
        {
            const double score=proposal.r[code];
            if(score>proposal.bestR) {proposal.second=proposal.best;proposal.secondR=proposal.bestR;proposal.best=code;proposal.bestR=score;}
            else if(score>proposal.secondR) {proposal.second=code;proposal.secondR=score;}
        }
    }
    std::array<double,24> scores {};
    std::copy(std::begin(proposal.r),std::end(proposal.r),scores.begin());
    decision.update(scores,hopSeconds);
    // Do not replace acc/accFast with a short candidate's own history.

    double amax = 0.0;
    for (double v : accFast) amax = std::max (amax, v);
    for (int i = 0; i < 12; ++i)
        result.chroma[(size_t) i] = amax > 0.0 ? (float) (accFast[(size_t) i] / amax) : 0.0f;

    const double useRe = (accWeight < 25.0) ? tuneFastRe : tuneRe;
    const double useIm = (accWeight < 25.0) ? tuneFastIm : tuneIm;
    const double cents = (useRe == 0.0 && useIm == 0.0) ? 0.0 : std::atan2 (useIm, useRe) / kTwoPi * 100.0;
    result.tuningHz = (float) (440.0 * std::pow (2.0, cents / 1200.0));

    const double listened = accWeight * hopSeconds;
    const int locked = decision.key();
    result.key = toKey (locked); // Only KeyDecision can change the public key.
    const auto& displayRank = locked >= 0 ? slow : proposal;
    int alternative = -1;
    for (int code = 0; code < 24; ++code)
        if (code != locked && (alternative < 0 || displayRank.r[code] > displayRank.r[alternative])) alternative = code;
    result.second = toKey (alternative);
    double margin = locked >= 0 ? displayRank.r[locked] - displayRank.r[alternative]
                               : proposal.bestR - proposal.secondR;
    if (locked >= 0)
    {
        // Long-term history must not report high confidence in the old key
        // while current material clearly supports a different key. An ordinary
        // ambiguous diatonic chord is not evidence against the committed key.
        if (proposal.best != locked && proposal.bestR - proposal.secondR >= 0.06
            && proposal.bestR - proposal.r[locked] >= 0.10)
            margin = std::min (margin, 0.0);
    }
    const double warm = juce::jlimit (0.0, 1.0, listened / KeyDecision::initialSeconds);
    const double target = juce::jlimit (0.0, 1.0, margin / 0.12 * warm);
    const double a = std::exp (-hopSeconds / kConfSeconds);
    smoothConf = smoothConf * a + target * (1.0 - a);
    result.confidence = (float) smoothConf;
}

void KeyAnalyzer::rejectFrame (bool isSilent)
{
    const double hopSeconds = hopSize / sampleRate;
    unpitchedTime += hopSeconds;
    if (unpitchedTime >= 0.35 || (isSilent && silenceTime >= 0.30))
    {
        decision.interrupt();
    }
    const double confDecay = isSilent ? std::exp (-hopSeconds / kConfSeconds)
                                      : std::exp (-0.35 * hopSeconds / kConfSeconds);
    smoothConf *= confDecay;
    result.confidence = (float) smoothConf;
}
