// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
// Upgraded with zplane tONaRT (Auto-Key 2) multi-profile dictionary tables.

#include "KeyProfiles.h"

namespace KeyProfiles
{
    // Calibrated fundamental pitch-class templates (used after IterativeHSS overtone removal)
    const std::array<float, 12> majorProfile =
        { 0.920f, 0.050f, 0.460f, 0.060f, 0.680f, 0.440f, 0.070f, 0.660f, 0.070f, 0.380f, 0.055f, 0.410f };

    const std::array<float, 12> minorProfile =
        { 0.920f, 0.060f, 0.450f, 0.680f, 0.045f, 0.460f, 0.080f, 0.660f, 0.420f, 0.060f, 0.220f, 0.380f };

    // Natural minor (Aeolian / Pop-Ballad-EDM): strong tonic (0), b3 (3), 5 (7), 4 (5), b6 (8), and b7 (10).
    const std::array<float, 12> minorPopProfile =
        { 0.930f, 0.050f, 0.440f, 0.690f, 0.045f, 0.465f, 0.075f, 0.650f, 0.430f, 0.060f, 0.430f, 0.160f };

    // Exact zplane tONaRT symmetric Krumhansl-Kessler profiles (Auto-Key 2 RVA 0x575980):
    // Minor tonic (6.35) and fifth (5.19) are equalized with Major so power-chords/fifths do not bias Major.
    const std::array<float, 12> tonartKKMajor =
        { 6.35f, 2.23f, 3.48f, 2.33f, 4.38f, 4.09f, 2.52f, 5.19f, 2.39f, 3.66f, 2.29f, 2.88f };

    const std::array<float, 12> tonartKKMinorSym =
        { 6.35f, 2.59f, 3.52f, 5.38f, 2.51f, 3.53f, 2.45f, 5.19f, 3.98f, 2.60f, 3.34f, 3.17f };

    // Exact zplane tONaRT Temperley profiles (Auto-Key 2 RVA 0x5759e0)
    const std::array<float, 12> tonartTemperleyMajor =
        { 5.00f, 2.00f, 3.50f, 2.00f, 4.50f, 4.00f, 2.00f, 4.50f, 2.00f, 3.50f, 1.50f, 4.00f };

    const std::array<float, 12> tonartTemperleyMinor =
        { 5.00f, 2.00f, 3.50f, 4.50f, 2.00f, 4.00f, 2.00f, 4.50f, 3.50f, 2.00f, 1.50f, 4.00f };

    // Exact zplane tONaRT Diatonic-Gated Krumhansl-Kessler profiles (Auto-Key 2 RVA 0x575a40):
    // Chromatic out-of-scale degrees are zeroed out (0.0f) for L1-normalized Euclidean distance scoring.
    const std::array<float, 12> tonartDiatonicMajor =
        { 6.35f, 0.00f, 3.48f, 0.00f, 4.38f, 4.09f, 0.00f, 5.19f, 0.00f, 3.66f, 0.00f, 2.88f };

    const std::array<float, 12> tonartDiatonicMinor =
        { 6.33f, 0.00f, 3.52f, 5.38f, 0.00f, 3.53f, 0.00f, 4.75f, 3.98f, 0.00f, 3.34f, 3.17f };
}
