// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
#include "PluginProcessor.h"
#include "PluginEditor.h"
#include "AutoTuneHandoff.h"

KeyDetectorProcessor::KeyDetectorProcessor()
    : juce::AudioProcessor (BusesProperties()
        .withInput ("Input", juce::AudioChannelSet::stereo(), true)
        .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      juce::Thread ("AutoTuneHandoff")
{
    loadGlobalSettings();
    setHandoffStatus (juce::String::fromUTF8 ("Chờ dò tông"));
    startThread();
}

KeyDetectorProcessor::~KeyDetectorProcessor()
{
    signalThreadShouldExit();
    notify();
    stopThread (30000);   // never killed by force (a killed thread can freeze the DAW)
}

void KeyDetectorProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    const double sr = sampleRate > 0.0 ? sampleRate : 48000.0;
    analyzer.prepare (sr);
    songRestartGate.prepare (sr);
    audioSampleRate = sr;
    previousBlockSeconds = 0.0;
    lastAudioBlockMs.store (-10000.0);
    monoBuffer.setSize (1, samplesPerBlock);
    samplesPerPoint = juce::jmax (1, juce::roundToInt (sr / 100.0));
    wavePeak = 0.0f; waveCount = 0;
    encodedKey.store (-1); encodedSecond.store (-1); confidence.store (0.0f);
    outputGeneration.fetch_add (1);
}

bool KeyDetectorProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& channels = layouts.getMainOutputChannelSet();
    return (channels == juce::AudioChannelSet::mono() || channels == juce::AudioChannelSet::stereo())
        && layouts.getMainInputChannelSet() == channels;
}

void KeyDetectorProcessor::requestDetection()
{
    if (! licensing.isAllowed()) { setHandoffStatus(juce::String::fromUTF8("Cần kích hoạt bản quyền")); return; }
    resetRequested.store (true, std::memory_order_release);
    outputGeneration.fetch_add (1);
    manualSendRequested.store (false);
    setHandoffStatus (juce::String::fromUTF8 ("Đang dò tông..."));
    notify();
}

void KeyDetectorProcessor::sendHandoffNow()
{
    if (! licensing.isAllowed()) { setHandoffStatus(juce::String::fromUTF8("Cần kích hoạt bản quyền")); return; }
    manualSendRequested.store (true, std::memory_order_release);
    notify();
}

void KeyDetectorProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    midi.clear();
    if (resetRequested.exchange (false, std::memory_order_acq_rel))
    { analyzer.reset(); songRestartGate.reset(); }
    const int samples = buffer.getNumSamples(), channels = buffer.getNumChannels();
    if (samples <= 0 || channels <= 0) return;
    ensureAutomaticTrialRequested();
    // An analyzer always leaves the host's audio untouched. Unlicensed/expired
    // instances do no analysis and cannot write an Auto-Tune handoff.
    if (! licensing.isAllowed()) return;
    const double nowMs = juce::Time::getMillisecondCounterHiRes();
    const double prevMs = lastAudioBlockMs.exchange (nowMs, std::memory_order_acq_rel);
    const bool hold = holdKey.load (std::memory_order_relaxed);
    analyzer.setHold (hold);
    double missingSeconds = 0.0;
    if (prevMs > 0.0 && (nowMs - prevMs) > 900.0)
    {
        missingSeconds = std::max (0.0, (nowMs - prevMs) / 1000.0 - previousBlockSeconds);
        // Handle the discontinuity before analysing the first resumed block.
        analyzer.notifyTransportGap ((nowMs - prevMs) / 1000.0);
        if (nowMs - prevMs >= 2400.0) outputGeneration.fetch_add (1);
    }
    previousBlockSeconds = samples / audioSampleRate;
    if (songRestartGate.process (buffer.getArrayOfReadPointers(), channels, samples, hold, missingSeconds))
    {
        // Match DÒ TÔNG on the first audible block after the quiet interval.
        // The old handoff file stays intact until a new key is confirmed.
        encodedKey.store (-1); encodedSecond.store (-1); confidence.store (0.0f);
        outputGeneration.fetch_add (1);
        manualSendRequested.store (false);
        analyzer.reset();
        autoRestartNotice.store (true);
        notify();
    }
    monoBuffer.setSize (1, samples, false, false, true);
    monoBuffer.clear();
    for (int ch = 0; ch < channels; ++ch) monoBuffer.addFrom (0, 0, buffer, ch, 0, samples);
    monoBuffer.applyGain (1.0f / (float) channels);
    const auto* mono = monoBuffer.getReadPointer (0);
    if (channels >= 2) analyzer.processStereoBlock (buffer.getReadPointer (0), buffer.getReadPointer (1), samples);
    else analyzer.processBlock (mono, samples);
    for (int i = 0; i < samples; ++i)
    {
        wavePeak = juce::jmax (wavePeak, std::abs (mono[i]));
        if (++waveCount >= samplesPerPoint)
        {
            const int w = waveWrite.load (std::memory_order_relaxed);
            wave[(size_t) w].store (juce::jmin (1.0f, wavePeak), std::memory_order_relaxed);
            waveWrite.store ((w + 1) % waveSize, std::memory_order_release);
            wavePeak = 0.0f; waveCount = 0;
        }
    }
    const auto result = analyzer.detect();
    auto encode = [] (const Key& k) { return k.valid ? k.tonic + (k.mode == Mode::Major ? 0 : 12) : -1; };
    confidence.store (result.confidence);
    tuningHz.store (result.tuningHz);
    encodedSecond.store (encode (result.second));
    for (size_t i = 0; i < 12; ++i) chroma[i].store (result.chroma[i], std::memory_order_relaxed);
    encodedKey.store (encode (result.key), std::memory_order_release);
    // The input audio buffer passes through unchanged. File I/O is worker-only.
}

void KeyDetectorProcessor::run()
{
    while (! threadShouldExit())
    {
        const auto now = juce::Time::getCurrentTime().toMilliseconds();
        if (licensePollRequested.exchange(false) || now >= nextLicensePollMs)
        {
            licensing.poll(now);
            const bool enabled = licensing.isAllowed();
            if (enabled != lastWorkerLicenseAllowed)
            {
                resetRequested.store(true);encodedKey.store(-1);encodedSecond.store(-1);confidence.store(0);
                outputGeneration.fetch_add(1);manualSendRequested.store(false);
                setHandoffStatus(enabled ? juce::String::fromUTF8("Đang dò tông...") : juce::String::fromUTF8("Cần kích hoạt bản quyền"));
                lastWorkerLicenseAllowed = enabled;
            }
            nextLicensePollMs = now + 1000;
        }
        if (autoRestartNotice.exchange (false) && licensing.isAllowed())
            setHandoffStatus (juce::String::fromUTF8 ("Có nhạc lại · Đang dò tông mới..."));
        if (licensing.isAllowed()) pollHandoff();
        else manualSendRequested.store(false);
        wait (100);
    }
}

void KeyDetectorProcessor::activateLicense(const juce::String& text)
{
    licensing.requestActivation(text);licensePollRequested.store(true);notify();
}
void KeyDetectorProcessor::startLicenseTrial()
{
    licensing.requestTrial();licensePollRequested.store(true);notify();
}

void KeyDetectorProcessor::ensureAutomaticTrialRequested() noexcept
{
    // Host enumeration/prepare alone does not consume the trial. The first
    // editor or audio callback queues the request; all storage stays on worker.
    if (! automaticTrialRequested.exchange (true, std::memory_order_relaxed))
    {
        licensing.requestAutomaticTrial();
        licensePollRequested.store (true);
        notify();
    }
}

void KeyDetectorProcessor::pollHandoff()
{
    if (! licensing.isAllowed()) return;
    const double now = juce::Time::getMillisecondCounterHiRes();
    const bool manual = manualSendRequested.exchange (false, std::memory_order_acq_rel);
    const auto generation = outputGeneration.load();
    if (resetRequested.load (std::memory_order_acquire)) return;
    const int key = encodedKey.load (std::memory_order_acquire);
    const double evidence = confidence.load();
    const bool fresh = now - lastAudioBlockMs.load (std::memory_order_acquire) < 500.0;
    const bool ready = outputGate.ready (key, evidence, fresh, now, generation, manual);
    if (! ready)
    {
        if (manual && key < 0) setHandoffStatus (juce::String::fromUTF8 ("Chưa có tông để gửi"));
        return;
    }
    if (! manual && now < retryAfterMs) return;
    const auto target = getHandoffFile();
    if (target == juce::File())
    {
        setHandoffStatus (juce::String::fromUTF8 ("Kết nối chưa sẵn sàng"));
        retryAfterMs = now + 1500.0;
        return;
    }
    if (threadShouldExit() || generation != outputGeneration.load() || resetRequested.load()) return;
    std::string error;
    const bool ok = autokey::handoff::write (std::filesystem::u8path (target.getFullPathName().toStdString()),
                                           key, tuningHz.load(), error);
   #if JUCE_WINDOWS
    // Mirror to C:\Users\Admin\AppData\Roaming\Auto-Key\Auto-Key.handoff if that user folder exists
    const juce::File adminRoaming ("C:\\Users\\Admin\\AppData\\Roaming");
    if (adminRoaming.isDirectory())
    {
        const juce::File adminTarget = adminRoaming.getChildFile ("Auto-Key").getChildFile ("Auto-Key.handoff");
        if (adminTarget != target)
        {
            std::string dummyErr;
            autokey::handoff::write (std::filesystem::u8path (adminTarget.getFullPathName().toStdString()),
                                     key, tuningHz.load(), dummyErr);
        }
    }
   #endif
    if (ok)
    {
        outputGate.written (key);
        retryAfterMs = 0.0;
        const Key written { key % 12, key < 12 ? Mode::Major : Mode::Minor, true };
        setHandoffStatus (juce::String::fromUTF8 ("Đã cập nhật: ") + keyToString (written));
    }
    else
    {
        setHandoffStatus (juce::String::fromUTF8 ("Chưa thể cập nhật tông · Đang thử lại..."));
        retryAfterMs = now + 1500.0;
    }
}

juce::File KeyDetectorProcessor::getHandoffFile() const
{
    {
        // A folder chosen by hand is used only while it still exists (a settings file copied
        // from another machine / Windows user must not send the key to a dead path).
        const juce::ScopedLock sl (outputLock);
        if (handoffOverride.isNotEmpty() && juce::File (handoffOverride).getParentDirectory().isDirectory())
            return juce::File (handoffOverride);
    }
   #if JUCE_WINDOWS
    // %APPDATA%\Auto-Key\Auto-Key.handoff of the Windows user running the DAW, whatever the
    // user name is (C:\Users\<user>\AppData\Roaming\Auto-Key). The folder is created if missing.
    auto appdata = juce::SystemStats::getEnvironmentVariable ("APPDATA", {});
    if (appdata.isEmpty() || ! juce::File (appdata).isDirectory())
        appdata = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getFullPathName();   // Roaming AppData
    if (appdata.isNotEmpty()) return juce::File (appdata).getChildFile ("Auto-Key").getChildFile ("Auto-Key.handoff");
   #elif JUCE_MAC
    // Verified in Auto-Key 2.6.0.84 for macOS: the sender builds this path
    // under the current user's Music folder, not Application Support.
    const auto music = juce::File::getSpecialLocation (juce::File::userMusicDirectory);
    if (music != juce::File())
        return music.getChildFile ("Audio Music Apps").getChildFile ("Temp").getChildFile ("Auto-Key.handoff");
   #else
    auto appSupport = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory);
    if (appSupport != juce::File())
        return appSupport.getChildFile ("Auto-Key").getChildFile ("Auto-Key.handoff");
   #endif
    return {};
}

void KeyDetectorProcessor::setHandoffStatus (const juce::String& status)
{
    const juce::ScopedLock sl (outputLock);
    handoffStatus = status;
}
juce::String KeyDetectorProcessor::getHandoffStatus() const
{
    const juce::ScopedLock sl (outputLock); return handoffStatus;
}
void KeyDetectorProcessor::setHandoffDirectory (const juce::File& directory)
{
    { const juce::ScopedLock sl (outputLock); handoffOverride = directory.getChildFile ("Auto-Key.handoff").getFullPathName(); }
    outputGeneration.fetch_add (1); saveGlobalSettings(); notify();
}
void KeyDetectorProcessor::useDefaultHandoffPath()
{
    { const juce::ScopedLock sl (outputLock); handoffOverride.clear(); }
    outputGeneration.fetch_add (1); saveGlobalSettings(); notify();
}

juce::File KeyDetectorProcessor::getSettingsFile() const
{
    const auto directory = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory).getChildFile ("T Studio");
    directory.createDirectory();
    return directory.getChildFile ("T-AutoKey_Settings.xml");
}
void KeyDetectorProcessor::saveGlobalSettings()
{
    juce::XmlElement xml ("TAutoKeySettings");
    xml.setAttribute ("holdKey", holdKey.load());
    { const juce::ScopedLock sl (outputLock); xml.setAttribute ("handoffPath", handoffOverride); }
    xml.writeTo (getSettingsFile());
}
void KeyDetectorProcessor::loadGlobalSettings()
{
    if (auto xml = juce::XmlDocument::parse (getSettingsFile()))
        if (xml->hasTagName ("TAutoKeySettings"))
        {
            holdKey.store (xml->getBoolAttribute ("holdKey", false));
            const auto path = xml->getStringAttribute ("handoffPath", {});
            if (path.isNotEmpty() && juce::File::isAbsolutePath (path))
            {
               #if JUCE_MAC
                // Migrate only the previous guessed macOS default. Other
                // explicit user-selected folders continue to take priority.
                const auto legacy = juce::File::getSpecialLocation (juce::File::userApplicationDataDirectory)
                    .getChildFile ("Auto-Key").getChildFile ("Auto-Key.handoff");
                if (juce::File (path) != legacy) handoffOverride = path;
               #else
                handoffOverride = path;
               #endif
            }
        }
}
void KeyDetectorProcessor::getStateInformation (juce::MemoryBlock& destination)
{
    juce::XmlElement xml ("TAutoKeyState");
    xml.setAttribute ("holdKey", holdKey.load());
    copyXmlToBinary (xml, destination);
}
void KeyDetectorProcessor::setStateInformation (const void* data, int bytes)
{
    if (auto xml = getXmlFromBinary (data, bytes))
        if (xml->hasTagName ("TAutoKeyState"))
            holdKey.store (xml->getBoolAttribute ("holdKey", false));
    // Do not publish or send an old saved detection before hearing current audio.
}
KeyAnalyzer::Result KeyDetectorProcessor::getLatestResult() const
{
    KeyAnalyzer::Result result;
    if (resetRequested.load() || !licensing.isAllowed()) return result;
    const int key = encodedKey.load (std::memory_order_acquire), second = encodedSecond.load();
    if (key >= 0) result.key = Key { key % 12, key < 12 ? Mode::Major : Mode::Minor, true };
    if (second >= 0) result.second = Key { second % 12, second < 12 ? Mode::Major : Mode::Minor, true };
    result.confidence = confidence.load(); result.tuningHz = tuningHz.load();
    for (size_t i = 0; i < 12; ++i) result.chroma[i] = chroma[i].load (std::memory_order_relaxed);
    return result;
}
void KeyDetectorProcessor::copyWaveform (float* destination, int num) const
{
    num = juce::jmin (num, waveSize);
    const int end = waveWrite.load (std::memory_order_acquire);
    for (int i = 0; i < num; ++i) destination[i] = wave[(size_t) ((end - num + i + waveSize) % waveSize)].load (std::memory_order_relaxed);
}
juce::AudioProcessorEditor* KeyDetectorProcessor::createEditor()
{
    ensureAutomaticTrialRequested();
    return new KeyDetectorEditor (*this);
}
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new KeyDetectorProcessor(); }
