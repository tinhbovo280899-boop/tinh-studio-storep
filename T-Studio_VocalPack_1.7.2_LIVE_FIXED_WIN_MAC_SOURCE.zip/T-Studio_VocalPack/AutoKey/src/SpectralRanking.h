// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <algorithm>
#include <array>
#include <cmath>

namespace autokey::ranking
{
// Krumhansl correlations select a natural pitch collection. Secondary musical
// evidence selects its relative tonic; it cannot promote an unrelated scale.
// This is this project's policy, not a claim about a proprietary implementation.
inline std::array<double,24> combine (const std::array<double,24>& primary,
                                     const std::array<double,24>& secondary,
                                     const std::array<double,12>& chroma, bool matureContext = true, const std::array<double,24>* modePrimary = nullptr, int lockedCode = -1)
{
    std::array<double,24> out {};
    for(int major=0;major<12;++major)
    {
        const int minor=12+(major+9)%12;
        const double rootMajor=chroma[(std::size_t)major],rootMinor=chroma[(std::size_t)(minor%12)];
        const double fifthMajor=chroma[(std::size_t)((major+7)%12)],fifthMinor=chroma[(std::size_t)((minor%12+7)%12)];
        double contrast=secondary[(std::size_t)major]-secondary[(std::size_t)minor];
        const auto& mode=modePrimary?*modePrimary:primary;
        const double gap=mode[(std::size_t)major]-mode[(std::size_t)minor];
        const double requiredGap=(lockedCode==major||lockedCode==minor)?0.18:0.04;
        const bool credible=std::max(mode[(std::size_t)major],mode[(std::size_t)minor])>=0.65;
        if(matureContext && credible && gap>=requiredGap && rootMajor>1.02*rootMinor && fifthMajor>1.10*fifthMinor)
            contrast=std::max(contrast,gap);
        else if(matureContext && credible && gap<=-requiredGap && rootMinor>1.02*rootMajor && fifthMinor>1.10*fifthMajor)
            contrast=std::min(contrast,gap);
        // Fisher's monotonic transform puts strong correlation separations on
        // the decision policy's working score scale. It is not a probability.
        const double family=std::atanh(std::clamp(std::max(primary[(std::size_t)major],primary[(std::size_t)minor]),-0.995,0.995));
        const double separation=std::min(1.0,2.0*std::abs(contrast));
        out[(std::size_t)major]=family-(contrast<0?separation:0);
        out[(std::size_t)minor]=family-(contrast>=0?separation:0);
    }
    return out;
}
}
