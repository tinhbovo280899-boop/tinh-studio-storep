#include "TAutoTuneEditor.h"
#include "TStudioFonts.h"
#include <cmath>
#include <map>

namespace
{
    using juce::Colour;
    const Colour cBg (0xff0a0b0f), cPanelTop (0xff1b1e26), cPanelBot (0xff12141a);
    const Colour cGold (0xffe9c27a), cGoldDeep (0xffb98a3e), cGoldLight (0xffffe2a6);
    const Colour cCream (0xfff3efe8), cDim (0xff8f897f), cWell (0xff0c0d11), cInset (0xff07080b);
    const Colour cRose (0xfff0928a), cIce (0xff7cc7f0), cViolet (0xffb9a2f5), cAmber (0xfff0a35a);

    juce::String vn (const char* s) { return juce::String::fromUTF8 (s); }

    // Blurred drop shadows are the most expensive thing this UI draws. Each distinct shadow is
    // rendered once at the screen's physical resolution and reused on every repaint
    // (message thread only). The picture is identical to drawing it every time.
    std::map<juce::String, juce::Image>& shadowCache()
    {
        static auto& cache = *new std::map<juce::String, juce::Image>();   // never destroyed at DLL unload
        return cache;
    }
    float physicalScale (juce::Graphics& g)
    {
        return juce::jlimit (0.25f, 8.0f, g.getInternalContext().getPhysicalPixelScaleFactor());
    }
    void drawCachedShadow (juce::Graphics& g, const juce::String& tag, const juce::Path& shape, const juce::DropShadow& ds)
    {
        const float scale = physicalScale (g);
        const auto b = shape.getBounds();
        const auto area = b.getUnion (b.translated ((float) ds.offset.x, (float) ds.offset.y)).expanded ((float) ds.radius + 2.0f).getSmallestIntegerContainer();
        const auto key = tag + "|" + juce::String (b.getX(), 2) + "," + juce::String (b.getY(), 2) + "," + juce::String (b.getWidth(), 2) + ","
                       + juce::String (b.getHeight(), 2) + "|" + juce::String (ds.radius) + "," + juce::String (ds.offset.x) + "," + juce::String (ds.offset.y)
                       + "|" + juce::String::toHexString ((juce::int64) ds.colour.getARGB()) + "|" + juce::String (juce::roundToInt (scale * 100.0f));
        auto& cache = shadowCache();
        auto it = cache.find (key);
        if (it == cache.end())
        {
            if (cache.size() > 256) cache.clear();
            juce::Image img (juce::Image::ARGB, juce::jmax (1, (int) std::ceil ((float) area.getWidth() * scale)),
                             juce::jmax (1, (int) std::ceil ((float) area.getHeight() * scale)), true, juce::SoftwareImageType());
            {
                juce::Graphics ig (img);
                ig.addTransform (juce::AffineTransform::translation ((float) -area.getX(), (float) -area.getY()).scaled (scale));
                ds.drawForPath (ig, shape);
            }
            it = cache.emplace (key, img).first;
        }
        g.saveState();
        g.setOpacity (1.0f);   // the image carries its own alpha; ignore the current colour's alpha
        g.drawImage (it->second, area.toFloat());
        g.restoreState();
    }

    juce::Typeface::Ptr loadFace (const char* data, int size)
    {
        return juce::Typeface::createSystemTypefaceFor (data, (size_t) size);
    }
    juce::Typeface::Ptr faceSemi()  { static auto& f = *new juce::Typeface::Ptr (loadFace (TStudioFonts::InterSemiBold_otf,  TStudioFonts::InterSemiBold_otfSize)); return f; }
    juce::Typeface::Ptr faceBold()  { static auto& f = *new juce::Typeface::Ptr (loadFace (TStudioFonts::InterBold_otf,      TStudioFonts::InterBold_otfSize)); return f; }
    juce::Typeface::Ptr faceHeavy() { static auto& f = *new juce::Typeface::Ptr (loadFace (TStudioFonts::InterExtraBold_otf, TStudioFonts::InterExtraBold_otfSize)); return f; }

    juce::Font makeFont (juce::Typeface::Ptr face, float pointHeight, float kerning = 0.0f)
    {
        return juce::Font (juce::FontOptions (face).withPointHeight (pointHeight).withKerningFactor (kerning));
    }

    float textWidth (const juce::Font& f, const juce::String& s)
    {
        return juce::GlyphArrangement::getStringWidth (f, s);
    }

    void drawPanel (juce::Graphics& g, juce::Rectangle<float> r, float radius = 20.0f)
    {
        juce::DropShadow (juce::Colours::black.withAlpha (0.55f), 40, { 0, 18 }).drawForRectangle (g, r.reduced (6).toNearestInt());
        g.setGradientFill (juce::ColourGradient (cPanelTop, r.getX(), r.getY(), cPanelBot, r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle (r, radius);
        g.setColour (juce::Colours::white.withAlpha (0.07f));
        g.drawRoundedRectangle (r.reduced (0.5f), radius, 1.0f);
        g.setColour (juce::Colours::white.withAlpha (0.06f));
        g.drawLine (r.getX() + radius, r.getY() + 1.0f, r.getRight() - radius, r.getY() + 1.0f, 1.0f);
    }

    void drawLabel (juce::Graphics& g, const juce::String& text, float x, float y, Colour c = cDim, float size = 10.5f,
                    juce::Justification j = juce::Justification::centredLeft, float w = 300.0f)
    {
        g.setColour (c);
        g.setFont (tui::Fonts::label (size));
        g.drawText (text.toUpperCase(), juce::Rectangle<float> (x, y - 2.0f, w, size + 6.0f), j, false);
    }

    void drawInsetPill (juce::Graphics& g, juce::Rectangle<float> r, float radius)
    {
        g.setColour (cInset);
        g.fillRoundedRectangle (r, radius);
        g.setColour (juce::Colours::black.withAlpha (0.8f));
        g.drawRoundedRectangle (r.reduced (0.5f), radius, 1.0f);
        g.setColour (juce::Colours::white.withAlpha (0.05f));
        g.drawLine (r.getX() + radius, r.getBottom() + 0.5f, r.getRight() - radius, r.getBottom() + 0.5f, 1.0f);
    }

    juce::Path gearPath (juce::Point<float> c, float scale)
    {
        juce::Path gear;
        const int teeth = 8, steps = teeth * 4;
        const float ro = 9.2f * scale, rb = 7.0f * scale, ri = 3.3f * scale;
        for (int i = 0; i < steps; ++i)
        {
            const float a = juce::MathConstants<float>::twoPi * (float) i / (float) steps - 0.1963495f;
            const bool tip = (i % 4) == 1 || (i % 4) == 2;
            const float r = tip ? ro : rb;
            const juce::Point<float> p (c.x + r * std::cos (a), c.y + r * std::sin (a));
            if (i == 0) gear.startNewSubPath (p); else gear.lineTo (p);
        }
        gear.closeSubPath();
        gear.addEllipse (c.x - ri, c.y - ri, ri * 2.0f, ri * 2.0f);
        gear.setUsingNonZeroWinding (false);
        return gear;
    }

    // Static part of a knob (shadow, skirt, machined cap). Drawn into a cached image by drawRotarySlider.
    void drawKnobBody (juce::Graphics& g, float cx, float cy, float S, float skirtR, float capR, bool big)
    {
        juce::Path skirt;
        skirt.addEllipse (cx - skirtR, cy - skirtR, skirtR * 2.0f, skirtR * 2.0f);
        juce::DropShadow (juce::Colours::black.withAlpha (0.85f), juce::roundToInt (S * 0.14f), { 0, juce::roundToInt (S * 0.08f) }).drawForPath (g, skirt);
        g.setGradientFill (juce::ColourGradient (Colour (0xff3a3e48), cx - skirtR * 0.45f, cy - skirtR, Colour (0xff121419), cx + skirtR * 0.45f, cy + skirtR, false));
        g.fillPath (skirt);
        {
            juce::Path rim;
            rim.addCentredArc (cx, cy, skirtR - 0.8f, skirtR - 0.8f, 0.0f, -1.25f, 1.25f, true);
            g.setColour (juce::Colours::white.withAlpha (0.24f));
            g.strokePath (rim, juce::PathStrokeType (1.3f));
            juce::Path shade;
            shade.addCentredArc (cx, cy, skirtR - 1.5f, skirtR - 1.5f, 0.0f, 2.2f, 4.1f, true);
            g.setColour (juce::Colours::black.withAlpha (0.5f));
            g.strokePath (shade, juce::PathStrokeType (2.5f));
        }
        g.setColour (Colour (0xff23262d));
        g.fillEllipse (cx - capR, cy - capR, capR * 2.0f, capR * 2.0f);
        g.setColour (Colour (0xff2d3038));
        const float ringStep = big ? 2.6f : 2.3f;
        for (float rr = capR - 1.5f; rr > 2.0f; rr -= ringStep)
            g.drawEllipse (cx - rr, cy - rr, rr * 2.0f, rr * 2.0f, 1.0f);
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.17f), cx - capR * 0.25f, cy - capR * 0.45f,
                                                 juce::Colours::white.withAlpha (0.0f), cx + capR * 0.55f, cy + capR * 0.45f, true));
        g.fillEllipse (cx - capR, cy - capR, capR * 2.0f, capR * 2.0f);
        g.setColour (juce::Colours::black.withAlpha (0.6f));
        g.drawEllipse (cx - capR, cy - capR, capR * 2.0f, capR * 2.0f, 1.0f);
        {
            juce::Path capShade;
            capShade.addCentredArc (cx, cy, capR - 1.2f, capR - 1.2f, 0.0f, -1.3f, 1.3f, true);
            g.setColour (juce::Colours::black.withAlpha (0.45f));
            g.strokePath (capShade, juce::PathStrokeType (2.0f));
        }
    }

    // Note names follow the current key/scale (Eb minor shows Gb/Ab/Db, E major shows F#/G#/C#...).
    juce::String noteNameForDisplay (TAutoTuneProcessor& p, int midiOrPitchClass)
    {
        auto& s = p.getAPVTS();
        return TAutoTuneProcessor::noteNameInKey (midiOrPitchClass,
                                                  (int) s.getRawParameterValue (TAutoTuneParams::kKey)->load(),
                                                  (int) s.getRawParameterValue (TAutoTuneParams::kScale)->load());
    }

    juce::String formatDetuneHz (double cents) { return juce::String (440.0 * std::pow (2.0, cents / 1200.0), 1); }
}

//==============================================================================
namespace tui
{
juce::Font Fonts::semi (float h)  { return makeFont (faceSemi(), h); }
juce::Font Fonts::bold (float h)  { return makeFont (faceBold(), h); }
juce::Font Fonts::heavy (float h) { return makeFont (faceHeavy(), h); }
juce::Font Fonts::label (float h) { return makeFont (faceHeavy(), h, 0.12f); }

GoldLookAndFeel::GoldLookAndFeel()
{
    setColour (juce::PopupMenu::backgroundColourId, Colour (0xff15171d));
    setColour (juce::PopupMenu::textColourId, cCream);
    setColour (juce::PopupMenu::headerTextColourId, cGold);
    setColour (juce::PopupMenu::highlightedBackgroundColourId, cGold.withAlpha (0.22f));
    setColour (juce::PopupMenu::highlightedTextColourId, cCream);
    setColour (juce::TextButton::buttonColourId, Colour (0xff272b35));
    setColour (juce::TextButton::textColourOffId, cGold);
    setColour (juce::TextEditor::backgroundColourId, Colour (0xff11141a));
    setColour (juce::TextEditor::textColourId, cCream);
    setColour (juce::TextEditor::outlineColourId, juce::Colours::white.withAlpha (0.1f));
    setColour (juce::TextEditor::focusedOutlineColourId, cGold.withAlpha (0.6f));
    setColour (juce::Label::textColourId, cCream);
    setColour (juce::ScrollBar::thumbColourId, cGold.withAlpha (0.55f));
    setColour (juce::TooltipWindow::backgroundColourId, Colour (0xff15171d));
    setColour (juce::TooltipWindow::textColourId, cCream);
}

juce::Typeface::Ptr GoldLookAndFeel::getTypefaceForFont (const juce::Font& f)
{
    if (f.getTypefaceName() == juce::Font::getDefaultSansSerifFontName())
        return f.isBold() ? faceBold() : faceSemi();
    return LookAndFeel_V4::getTypefaceForFont (f);
}

juce::Font GoldLookAndFeel::getPopupMenuFont() { return Fonts::semi (14.0f); }

void GoldLookAndFeel::drawPopupMenuBackground (juce::Graphics& g, int width, int height)
{
    g.fillAll (findColour (juce::PopupMenu::backgroundColourId));
    g.setColour (cGold.withAlpha (0.35f));
    g.drawRect (0, 0, width, height, 1);
}

void GoldLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                        float start, float end, juce::Slider& slider)
{
    const auto arcColour = Colour ((juce::uint32) (juce::int64) slider.getProperties().getWithDefault ("arc", (juce::int64) cGold.getARGB()));
    const bool ticks = (bool) slider.getProperties().getWithDefault ("ticks", false);
    const bool enabled = slider.isEnabled();
    const float S = (float) juce::jmin (w, h);
    const float cx = (float) x + (float) w * 0.5f, cy = (float) y + (float) h * 0.5f;
    const bool big = S >= 120.0f;
    const float sw = big ? 6.0f : (S >= 60.0f ? 4.0f : 3.5f);
    const float outer = S * 0.5f;
    const float r = ticks ? outer - (big ? 13.0f : 10.0f) - sw * 0.5f : outer - sw * 0.5f - 1.5f;
    auto pointAt = [cx, cy] (float radius, float angle)
    { return juce::Point<float> (cx + radius * std::sin (angle), cy - radius * std::cos (angle)); };

    if (! enabled) g.beginTransparencyLayer (0.38f);

    if (ticks)
    {
        const int n = big ? 36 : 20;
        for (int i = 0; i <= n; ++i)
        {
            const float f = (float) i / (float) n;
            const float a = start + f * (end - start);
            const bool major = i % (n / 4) == 0;
            const float r1 = r + sw * 0.5f + 4.0f, r2 = r1 + (major ? (big ? 7.0f : 5.5f) : (big ? 4.5f : 3.5f));
            g.setColour (f <= pos + 0.0001f ? arcColour.withAlpha (0.9f) : Colour (0xff3a3d46));
            g.drawLine (juce::Line<float> (pointAt (r1, a), pointAt (r2, a)), major ? 2.0f : 1.3f);
        }
    }

    juce::Path track;
    track.addCentredArc (cx, cy, r, r, 0.0f, start, end, true);
    g.setColour (Colour (0xff06070a));
    g.strokePath (track, juce::PathStrokeType (sw + 3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    if (pos > 0.001f)
    {
        juce::Path value;
        value.addCentredArc (cx, cy, r, r, 0.0f, start, start + pos * (end - start), true);
        g.setColour (arcColour.withAlpha (0.14f));
        g.strokePath (value, juce::PathStrokeType (sw + 9.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour (arcColour.withAlpha (0.3f));
        g.strokePath (value, juce::PathStrokeType (sw + 4.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setGradientFill (juce::ColourGradient (arcColour.darker (0.45f), cx - r, cy + r, arcColour.brighter (0.25f), cx + r, cy - r, false));
        g.strokePath (value, juce::PathStrokeType (sw, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    // Raised knob body: drop shadow, gradient skirt, machined concentric cap.
    // The body never rotates, so it is rendered once per size into an image and reused.
    const float skirtR = r * 0.83f, capR = r * 0.64f;
    const float ext = skirtR + S * 0.14f + S * 0.08f + 4.0f;
    const juce::Rectangle<float> bodyArea (cx - ext, cy - ext, ext * 2.0f, ext * 2.0f);
    {
        const float scale = physicalScale (g);
        const auto key = "knob|" + juce::String (S, 2) + "|" + juce::String (r, 2) + "|" + juce::String (big ? 1 : 0) + "|" + juce::String (juce::roundToInt (scale * 100.0f));
        auto& cache = shadowCache();
        auto it = cache.find (key);
        if (it == cache.end())
        {
            if (cache.size() > 256) cache.clear();
            const int px = juce::jmax (1, (int) std::ceil (ext * 2.0f * scale));
            juce::Image img (juce::Image::ARGB, px, px, true, juce::SoftwareImageType());
            {
                juce::Graphics bg (img);
                bg.addTransform (juce::AffineTransform::scale (scale));
                drawKnobBody (bg, ext, ext, S, skirtR, capR, big);
            }
            it = cache.emplace (key, img).first;
        }
        g.saveState();
        g.setOpacity (1.0f);
        g.drawImage (it->second, bodyArea);
        g.restoreState();
    }

    const float angle = start + pos * (end - start);
    const auto dot = pointAt (capR * 0.66f, angle);
    const float dotR = big ? 5.0f : (S >= 60.0f ? 3.6f : 3.0f);
    g.setColour (arcColour.withAlpha (0.22f));
    g.fillEllipse (dot.x - dotR * 2.6f, dot.y - dotR * 2.6f, dotR * 5.2f, dotR * 5.2f);
    g.setColour (arcColour.withAlpha (0.45f));
    g.fillEllipse (dot.x - dotR * 1.6f, dot.y - dotR * 1.6f, dotR * 3.2f, dotR * 3.2f);
    g.setColour (Colour (0xfffff3d6));
    g.fillEllipse (dot.x - dotR, dot.y - dotR, dotR * 2.0f, dotR * 2.0f);

    if (! enabled) g.endTransparencyLayer();
}

//==============================================================================
Knob::Knob (juce::AudioProcessorValueTreeState& state, const juce::String& paramId, const juce::String& text,
            Style s, juce::Colour arc, std::function<juce::String (double)> fmt)
    : label (text), style (s), format (std::move (fmt))
{
    slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    slider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    slider.setRotaryParameters (juce::MathConstants<float>::pi * 1.25f, juce::MathConstants<float>::pi * 2.75f, true);
    slider.setMouseDragSensitivity (style == Style::Hero ? 320 : 220);
    slider.setVelocityBasedMode (false);
    slider.getProperties().set ("arc", (juce::int64) arc.getARGB());
    slider.getProperties().set ("ticks", style == Style::Hero || style == Style::Header);
    slider.onValueChange = [this] { repaint(); };
    addAndMakeVisible (slider);
    attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (state, paramId, slider);
    if (auto* p = state.getParameter (paramId))
        slider.setDoubleClickReturnValue (true, p->convertFrom0to1 (p->getDefaultValue()));
}

void Knob::setKnobEnabled (bool e)
{
    if (e == enabled) return;
    enabled = e;
    slider.setEnabled (e);
    repaint();
}

void Knob::resized()
{
    switch (style)
    {
        case Style::Hero:   slider.setBounds (65, 48, 190, 190); break;
        case Style::Header: slider.setBounds (12, 40, 76, 76); break;
        case Style::Side:   slider.setBounds (0, 2, 48, 48); break;
        case Style::Below:  slider.setBounds ((getWidth() - 50) / 2, 0, 50, 50); break;
    }
}

void Knob::paint (juce::Graphics& g)
{
    const auto valueColour = enabled ? cCream : cDim;
    const auto text = format (slider.getValue());
    if (style == Style::Hero)
    {
        drawLabel (g, label, 24.0f, 24.0f);
        const juce::Rectangle<float> pill (204.0f, 14.0f, 96.0f, 32.0f);
        drawInsetPill (g, pill, 16.0f);
        g.setColour (cGold);
        g.fillEllipse (pill.getX() + 16.0f, pill.getCentreY() - 3.0f, 6.0f, 6.0f);
        g.setColour (cGold.withAlpha (0.35f));
        g.fillEllipse (pill.getX() + 13.0f, pill.getCentreY() - 6.0f, 12.0f, 12.0f);
        g.setColour (valueColour);
        g.setFont (Fonts::heavy (14.0f));
        g.drawText (text, pill.withTrimmedLeft (22.0f), juce::Justification::centred, false);
    }
    else if (style == Style::Header)
    {
        drawLabel (g, label, 0.0f, 2.0f, cDim, 10.5f, juce::Justification::centred, (float) getWidth());
        g.setColour (valueColour);
        g.setFont (Fonts::heavy (17.0f));
        g.drawText (text, juce::Rectangle<float> (0.0f, 16.0f, (float) getWidth(), 24.0f), juce::Justification::centred, false);
    }
    else if (style == Style::Side)
    {
        drawLabel (g, label, 54.0f, 10.0f, cDim, 9.5f, juce::Justification::centredLeft, (float) getWidth() - 54.0f);
        g.setColour (valueColour);
        g.setFont (Fonts::heavy (14.0f));
        g.drawText (text, juce::Rectangle<float> (54.0f, 23.0f, (float) getWidth() - 54.0f, 20.0f), juce::Justification::centredLeft, false);
    }
    else
    {
        drawLabel (g, label, 0.0f, 56.0f, cDim, 9.5f, juce::Justification::centred, (float) getWidth());
        const juce::Rectangle<float> pill (6.0f, 74.0f, (float) getWidth() - 12.0f, 20.0f);
        drawInsetPill (g, pill, 6.0f);
        g.setColour (valueColour);
        g.setFont (Fonts::heavy (11.5f));
        g.drawText (text, pill, juce::Justification::centred, false);
    }
}

//==============================================================================
Segmented::Segmented (juce::StringArray o, float size) : options (std::move (o)), fontSize (size) {}

void Segmented::bind (juce::RangedAudioParameter& p, std::function<int (float)> toIndex, std::function<float (int)> toValue)
{
    indexToValue = std::move (toValue);
    attachment = std::make_unique<juce::ParameterAttachment> (p, [this, toIndex] (float v) { setSelected (toIndex (v)); }, nullptr);
    attachment->sendInitialUpdate();
}

void Segmented::setSelected (int i) noexcept
{
    if (i != selected) { selected = i; repaint(); }
}

void Segmented::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    const float radius = r.getHeight() * 0.5f;
    drawInsetPill (g, r, radius);
    auto inner = r.reduced (4.0f);
    const float w = inner.getWidth() / (float) juce::jmax (1, options.size());
    for (int i = 0; i < options.size(); ++i)
    {
        auto seg = juce::Rectangle<float> (inner.getX() + w * (float) i, inner.getY(), w, inner.getHeight());
        if (i == selected)
        {
            const float rr = seg.getHeight() * 0.5f;
            g.setColour (cGold.withAlpha (0.10f));
            g.fillRoundedRectangle (seg.expanded (2.0f), rr + 2.0f);
            g.setGradientFill (juce::ColourGradient (Colour (0xff3a3424), seg.getX(), seg.getY(), Colour (0xff221e15), seg.getX(), seg.getBottom(), false));
            g.fillRoundedRectangle (seg, rr);
            g.setColour (cGold.withAlpha (0.75f));
            g.drawRoundedRectangle (seg.reduced (0.6f), rr, 1.2f);
        }
        g.setColour (i == selected ? cCream : cDim);
        g.setFont (Fonts::bold (fontSize));
        g.drawText (options[i], seg, juce::Justification::centred, false);
    }
}

void Segmented::mouseUp (const juce::MouseEvent& e)
{
    if (! getLocalBounds().contains (e.getPosition()) || options.isEmpty()) return;
    const int i = juce::jlimit (0, options.size() - 1, (int) ((e.position.x - 4.0f) / ((float) getWidth() - 8.0f) * (float) options.size()));
    if (attachment != nullptr && indexToValue)
        attachment->setValueAsCompleteGesture (indexToValue (i));
    else
        setSelected (i);
    if (onSelect) onSelect (i);
}

//==============================================================================
Switch::Switch (juce::RangedAudioParameter& p)
    : attachment (p, [this] (float v) { on = v > 0.5f; repaint(); }, nullptr)
{
    attachment.sendInitialUpdate();
}

void Switch::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    drawInsetPill (g, r, r.getHeight() * 0.5f);
    const float d = r.getHeight() - 6.0f;
    const float x = on ? r.getRight() - 3.0f - d : r.getX() + 3.0f;
    if (on)
    {
        g.setColour (cGold.withAlpha (0.3f));
        g.fillEllipse (x - 3.0f, r.getY(), d + 6.0f, d + 6.0f);
        g.setGradientFill (juce::ColourGradient (Colour (0xffffe7b0), x, r.getY(), cGoldDeep, x, r.getBottom(), false));
    }
    else
        g.setGradientFill (juce::ColourGradient (Colour (0xff4a4e58), x, r.getY(), Colour (0xff262930), x, r.getBottom(), false));
    g.fillEllipse (x, r.getY() + 3.0f, d, d);
}

void Switch::mouseUp (const juce::MouseEvent& e)
{
    if (getLocalBounds().contains (e.getPosition()))
        attachment.setValueAsCompleteGesture (on ? 0.0f : 1.0f);
}

//==============================================================================
Field::Field (juce::String c) : caption (std::move (c)) {}

void Field::setValue (const juce::String& v)
{
    if (v != value) { value = v; repaint(); }
}

void Field::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    juce::DropShadow (juce::Colours::black.withAlpha (0.4f), 16, { 0, 6 }).drawForRectangle (g, r.reduced (4).toNearestInt());
    g.setGradientFill (juce::ColourGradient (Colour (0xff171a21), 0, r.getY(), Colour (0xff0f1116), 0, r.getBottom(), false));
    g.fillRoundedRectangle (r, 14.0f);
    g.setColour (highlighted ? cGold.withAlpha (0.4f) : juce::Colours::white.withAlpha (0.08f));
    g.drawRoundedRectangle (r, 14.0f, 1.0f);

    drawLabel (g, caption, 16.0f, 11.0f);
    g.setColour (cCream);
    auto valueFont = Fonts::bold (arrows ? 14.0f : 16.0f);
    g.setFont (valueFont);
    const float maxValueW = r.getWidth() - (arrows ? 76.0f : 48.0f) - (chip.isNotEmpty() ? 92.0f : 0.0f);
    g.drawText (value, juce::Rectangle<float> (16.0f, 25.0f, maxValueW, 22.0f), juce::Justification::centredLeft, true);

    if (chip.isNotEmpty())
    {
        const float vx = 16.0f + juce::jmin (maxValueW, textWidth (valueFont, value)) + 10.0f;
        const juce::Rectangle<float> c (vx, 27.0f, 84.0f, 20.0f);
        g.setColour (cGold.withAlpha (0.08f));
        g.fillRoundedRectangle (c, 10.0f);
        g.setColour (cGold.withAlpha (0.45f));
        g.drawRoundedRectangle (c.reduced (0.5f), 10.0f, 1.0f);
        g.setColour (cGold.withAlpha (0.35f));
        g.fillEllipse (c.getX() + 6.0f, c.getCentreY() - 6.0f, 12.0f, 12.0f);
        g.setColour (cGold);
        g.fillEllipse (c.getX() + 9.0f, c.getCentreY() - 3.0f, 6.0f, 6.0f);
        g.setFont (Fonts::label (9.0f));
        g.drawText (chip, c.withTrimmedLeft (18.0f), juce::Justification::centred, false);
    }

    g.setColour (cCream.withAlpha (0.85f));
    if (arrows)
    {
        g.setFont (Fonts::bold (16.0f));
        g.drawText (juce::String::fromUTF8 ("‹"), juce::Rectangle<float> (r.getRight() - 58.0f, 0, 26.0f, r.getHeight()), juce::Justification::centred, false);
        g.drawText (juce::String::fromUTF8 ("›"), juce::Rectangle<float> (r.getRight() - 32.0f, 0, 26.0f, r.getHeight()), juce::Justification::centred, false);
    }
    else
    {
        juce::Path chev;
        const float cx = r.getRight() - 22.0f, cy = r.getCentreY();
        chev.startNewSubPath (cx - 5.0f, cy - 2.5f);
        chev.lineTo (cx, cy + 2.5f);
        chev.lineTo (cx + 5.0f, cy - 2.5f);
        g.strokePath (chev, juce::PathStrokeType (1.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    if (progress >= 0.0f)
    {
        const auto bar = juce::Rectangle<float> (16.0f, r.getBottom() - 6.0f, r.getWidth() - 32.0f, 2.5f);
        g.setColour (cInset);
        g.fillRoundedRectangle (bar, 1.25f);
        g.setColour (cGold);
        g.fillRoundedRectangle (bar.withWidth (bar.getWidth() * juce::jlimit (0.0f, 1.0f, progress)), 1.25f);
    }
}

void Field::mouseUp (const juce::MouseEvent& e)
{
    if (! getLocalBounds().contains (e.getPosition())) return;
    if (arrows && e.position.x > (float) getWidth() - 60.0f)
    {
        if (e.position.x < (float) getWidth() - 32.0f) { if (onPrev) onPrev(); }
        else if (onNext) onNext();
        return;
    }
    if (onClick) onClick();
}

//==============================================================================
RoundButton::RoundButton (Icon i) : icon (i) {}

void RoundButton::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (7.0f);
    juce::Path circle;
    circle.addEllipse (r);
    const bool gold = icon == Icon::Power && lit;
    if (gold)
    {
        g.setGradientFill (juce::ColourGradient (cGold.withAlpha (0.35f), r.getCentreX(), r.getCentreY(), cGold.withAlpha (0.0f), r.getCentreX() + r.getWidth() * 0.5f + 7.0f, r.getCentreY(), true));
        g.fillEllipse (r.expanded (7.0f));
    }
    drawCachedShadow (g, "round", circle, juce::DropShadow (juce::Colours::black.withAlpha (0.6f), 14, { 0, 6 }));
    if (gold)
        g.setGradientFill (juce::ColourGradient (Colour (0xffffe7b0), r.getX() + r.getWidth() * 0.4f, r.getY() + r.getHeight() * 0.3f,
                                                 Colour (0xff9a7030), r.getRight(), r.getBottom(), true));
    else
        g.setGradientFill (juce::ColourGradient (Colour (0xff262a33), 0, r.getY(), Colour (0xff12141a), 0, r.getBottom(), false));
    g.fillPath (circle);
    g.setColour (gold ? juce::Colours::white.withAlpha (0.5f) : juce::Colours::white.withAlpha (0.09f));
    g.drawEllipse (r.reduced (0.5f), 1.0f);

    const auto c = r.getCentre();
    if (icon == Icon::Gear)
    {
        g.setColour (cCream);
        g.fillPath (gearPath (c, r.getWidth() / 42.0f));
    }
    else
    {
        g.setColour (gold ? Colour (0xff1c1406) : cGold);
        juce::Path p;
        const float rad = r.getWidth() * 0.19f;
        p.addCentredArc (c.x, c.y + 1.0f, rad, rad, 0.0f, 0.65f, juce::MathConstants<float>::twoPi - 0.65f, true);
        p.startNewSubPath (c.x, c.y - rad - 3.0f);
        p.lineTo (c.x, c.y);
        g.strokePath (p, juce::PathStrokeType (2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }
}

void RoundButton::mouseUp (const juce::MouseEvent& e)
{
    if (getLocalBounds().contains (e.getPosition()) && onClick) onClick();
}

//==============================================================================
void TextChip::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat().reduced (0.5f);
    g.setGradientFill (juce::ColourGradient (active ? Colour (0xff2c2717) : Colour (0xff20232b), 0, r.getY(),
                                             active ? Colour (0xff1a1710) : Colour (0xff15171d), 0, r.getBottom(), false));
    g.fillRoundedRectangle (r, r.getHeight() * 0.5f);
    g.setColour (active ? cGold.withAlpha (0.6f) : juce::Colours::white.withAlpha (0.08f));
    g.drawRoundedRectangle (r, r.getHeight() * 0.5f, 1.0f);
    g.setColour (active ? cGold : cDim);
    g.setFont (Fonts::label (10.5f));
    g.drawText (text.toUpperCase(), r, juce::Justification::centred, false);
}
} // namespace tui

//==============================================================================
// Transpose stepper bound to the transpose parameter.
class TransposeStepper final : public juce::Component
{
public:
    explicit TransposeStepper (juce::RangedAudioParameter& p)
        : attachment (p, [this] (float v) { value = juce::roundToInt (v); repaint(); }, nullptr)
    {
        attachment.sendInitialUpdate();
    }
    void paint (juce::Graphics& g) override
    {
        auto r = getLocalBounds().toFloat();
        drawInsetPill (g, r, r.getHeight() * 0.5f);
        g.setColour (cCream);
        g.setFont (tui::Fonts::heavy (14.0f));
        g.drawText ((value > 0 ? "+" : "") + juce::String (value), r, juce::Justification::centred, false);
        g.setColour (cGold);
        g.setFont (tui::Fonts::bold (16.0f));
        g.drawText (juce::String::fromUTF8 ("‹"), r.withWidth (30.0f), juce::Justification::centred, false);
        g.drawText (juce::String::fromUTF8 ("›"), r.withTrimmedLeft (r.getWidth() - 30.0f), juce::Justification::centred, false);
    }
    void mouseUp (const juce::MouseEvent& e) override
    {
        if (! getLocalBounds().contains (e.getPosition())) return;
        int next = value;
        if (e.position.x < (float) getWidth() / 3.0f) --next;
        else if (e.position.x > (float) getWidth() * 2.0f / 3.0f) ++next;
        else next = 0;
        attachment.setValueAsCompleteGesture ((float) juce::jlimit (-12, 12, next));
    }
private:
    juce::ParameterAttachment attachment;
    int value = 0;
};

//==============================================================================
TPitchView::TPitchView (TAutoTuneProcessor& p) : processor (p)
{
    input.fill (-1.0f);
    output.fill (-1.0f);
}

void TPitchView::tick()
{
    voiced = processor.isVoiced();
    const float det = processor.getDetectedMidiNote();
    const float cents = processor.getCentsCorrection();
    const float target = processor.getTargetMidiNote();
    const bool ok = voiced && det > 0.0f;
    input[(size_t) write] = ok ? det : -1.0f;
    output[(size_t) write] = ok ? det + cents / 100.0f : -1.0f;
    write = (write + 1) % historySize;
    if (ok && target > 0.0f)
    {
        centre += (target - centre) * 0.06f;
        shownTarget = target;
        shownCents = cents;
        shownDetected = det;
        silentTicks = 0;
        const float detune = processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kDetune)->load();
        shownHz = 440.0f * std::pow (2.0f, ((float) std::round (target) - 69.0f) / 12.0f) * std::pow (2.0f, detune / 1200.0f);
        // the note strip follows the singer: move it only when the note leaves the visible two octaves
        const int t = (int) std::round (target);
        if (t < stripLow || t > stripLow + 23)
            stripLow = juce::jlimit (24, 84, 12 * (int) std::round (((float) t - 12.0f) / 12.0f));
    }
    else
    {
        shownCents *= 0.85f;
        ++silentTicks;
    }
    pulse += 0.2f;
    if (pulse > juce::MathConstants<float>::twoPi * 100.0f) pulse = 0.0f;

    if (! tunerMode())
    {
        repaint();   // the graph scrolls every tick
        return;
    }
    // Tuner: repaint only what changed. While nobody sings only the small "listening" ring moves.
    juce::String sig;
    const bool licensed = processor.hasLicenseAccess();
    const bool showNote = licensed && shownTarget > 0.0f && silentTicks < 12;
    sig << (int) licensed << (int) showNote << (int) processor.getHoldMeter() << "|" << getWidth() << "x" << getHeight() << "|"
        << (int) processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kKey)->load() << ","
        << (int) processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kScale)->load() << ",";
    for (int i = 0; i < 12; ++i) sig << processor.getNoteState (i);
    if (showNote)
        sig << "|" << juce::roundToInt (shownTarget) << "|" << juce::roundToInt (shownDetected * 400.0f) << "|" << juce::roundToInt (shownHz * 10.0f);
    if (sig != shownSignature)
    {
        shownSignature = sig;
        repaint();
    }
    else if (licensed && ! showNote)
        repaint (juce::Rectangle<float> (tunerCx - 56.0f, tunerCy - 92.0f - 56.0f, 112.0f, 112.0f).getSmallestIntegerContainer());
}

void TPitchView::mouseUp (const juce::MouseEvent& e)
{
    // TUNER / GRAPH chips (top right)
    const float w = (float) getWidth();
    if (e.position.y >= 10.0f && e.position.y <= 40.0f && e.position.x >= w - 170.0f && e.position.x <= w - 16.0f)
    {
        setTunerMode (e.position.x < w - 93.0f);
        return;
    }
    const bool tuner = tunerMode();
    const bool onNote = tuner ? (e.position.getDistanceFrom ({ w * 0.5f, 170.0f }) < 110.0f)
                              : (e.position.x < 220.0f && e.position.y < 130.0f);
    if (onNote)
        processor.setHoldMeter (! processor.getHoldMeter());
}

bool TPitchView::tunerMode() const
{
    return (bool) processor.getAPVTS().state.getProperty ("tunerView", true);
}

void TPitchView::setTunerMode (bool t)
{
    processor.getAPVTS().state.setProperty ("tunerView", t, nullptr);
    repaint();
}

void TPitchView::paintViewChips (juce::Graphics& g, bool tuner)
{
    const float w = (float) getWidth();
    const juce::Rectangle<float> track (w - 168.0f, 12.0f, 150.0f, 26.0f);
    g.setColour (cWell);
    g.fillRoundedRectangle (track, 13.0f);
    g.setColour (juce::Colours::white.withAlpha (0.06f));
    g.drawRoundedRectangle (track.reduced (0.5f), 13.0f, 1.0f);
    const auto on = tuner ? juce::Rectangle<float> (w - 165.0f, 15.0f, 72.0f, 20.0f) : juce::Rectangle<float> (w - 93.0f, 15.0f, 72.0f, 20.0f);
    g.setGradientFill (juce::ColourGradient (Colour (0xff3a3222), 0, on.getY(), Colour (0xff221e17), 0, on.getBottom(), false));
    g.fillRoundedRectangle (on, 10.0f);
    g.setColour (cGold.withAlpha (0.75f));
    g.drawRoundedRectangle (on.reduced (0.5f), 10.0f, 1.0f);
    g.setFont (tui::Fonts::label (9.5f));
    g.setColour (tuner ? cGoldLight : cDim);
    g.drawText ("TUNER", juce::Rectangle<float> (w - 165.0f, 15.0f, 72.0f, 20.0f), juce::Justification::centred, false);
    g.setColour (tuner ? cDim : cGoldLight);
    g.drawText ("GRAPH", juce::Rectangle<float> (w - 93.0f, 15.0f, 72.0f, 20.0f), juce::Justification::centred, false);
}

namespace
{
    // Tuner geometry (logical units of the 744 x 388 pitch panel)
    constexpr float tCx = TPitchView::tunerCx, tCy = TPitchView::tunerCy, tR = 200.0f;
    constexpr float tSpan = juce::MathConstants<float>::pi * 0.40f;     // +/-100 ct -> +/-72 degrees
    float centsAngle (float ct) { return juce::jlimit (-100.0f, 100.0f, ct) / 100.0f * tSpan; }
    juce::Point<float> onArc (float angle, float r) { return { tCx + r * std::sin (angle), tCy - r * std::cos (angle) }; }

    // Inter has no music symbols, so flat / sharp are drawn as small paths
    void drawFlat (juce::Graphics& g, float x, float y, float h)
    {
        juce::Path p;
        p.startNewSubPath (x, y - h * 0.62f);
        p.lineTo (x, y + h * 0.38f);
        p.cubicTo (x + h * 0.55f, y + h * 0.10f, x + h * 0.55f, y - h * 0.28f, x, y - h * 0.02f);
        g.strokePath (p, juce::PathStrokeType (1.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }
    void drawSharp (juce::Graphics& g, float x, float y, float h)
    {
        juce::Path p;
        const float w = h * 0.55f;
        p.startNewSubPath (x + w * 0.30f, y - h * 0.50f); p.lineTo (x + w * 0.25f, y + h * 0.50f);
        p.startNewSubPath (x + w * 0.75f, y - h * 0.50f); p.lineTo (x + w * 0.70f, y + h * 0.50f);
        p.startNewSubPath (x, y - h * 0.12f); p.lineTo (x + w, y - h * 0.22f);
        p.startNewSubPath (x, y + h * 0.22f); p.lineTo (x + w, y + h * 0.12f);
        g.strokePath (p, juce::PathStrokeType (1.3f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }
    void drawTracked (juce::Graphics& g, const juce::String& s, float cx, float cy, float size, Colour c)
    {
        g.setColour (c);
        g.setFont (tui::Fonts::label (size));
        g.drawText (s, juce::Rectangle<float> (cx - 150.0f, cy - size, 300.0f, size * 2.0f), juce::Justification::centred, false);
    }
    bool isBlackKey (int pc) { return pc == 1 || pc == 3 || pc == 6 || pc == 8 || pc == 10; }
    constexpr float kStripX = 36.0f, kStripH = 44.0f;
    constexpr int kStripKeys = 24;
}

// Everything in the tuner that only changes with the size, key/scale or strip position.
juce::Image& TPitchView::tunerLayer (float scale)
{
    const int W = getWidth(), H = getHeight();
    juce::String key;
    key << W << "x" << H << "@" << juce::roundToInt (scale * 100.0f) << "|" << stripLow << "|"
        << (int) processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kKey)->load() << ","
        << (int) processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kScale)->load() << "|";
    for (int i = 0; i < 12; ++i) key << processor.getNoteState (i);
    key << (processor.getHoldMeter() ? "h" : "");
    if (key == layerKey && layer.isValid())
        return layer;

    layerKey = key;
    layer = juce::Image (juce::Image::ARGB, juce::jmax (1, juce::roundToInt ((float) W * scale)), juce::jmax (1, juce::roundToInt ((float) H * scale)), true, juce::SoftwareImageType());
    juce::Graphics g (layer);
    g.addTransform (juce::AffineTransform::scale (scale));

    // caption + view chips
    const bool hold = processor.getHoldMeter();
    g.setColour (hold ? cGold : cDim);
    g.setFont (tui::Fonts::label (10.5f));
    g.drawText (hold ? vn ("TUNER  \xc2\xb7  FREEZE") : juce::String ("TUNER"), juce::Rectangle<float> (22.0f, 14.0f, 260.0f, 20.0f), juce::Justification::centredLeft, false);
    paintViewChips (g, true);

    // arc track
    juce::Path track;
    track.addCentredArc (tCx, tCy, tR, tR, 0.0f, -tSpan, tSpan, true);
    g.setColour (Colour (0xff06070a));
    g.strokePath (track, juce::PathStrokeType (12.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    // ticks + labels (unlit; lit ticks are drawn live on top)
    for (int c = -100; c <= 100; c += 5)
    {
        const bool major = c % 50 == 0, mid = c % 25 == 0;
        const float a = centsAngle ((float) c);
        g.setColour (major ? Colour (0xff5b5a58) : Colour (0xff34363d));
        g.drawLine (juce::Line<float> (onArc (a, tR + 14.0f), onArc (a, tR + (major ? 28.0f : mid ? 23.0f : 19.0f))), major ? 2.2f : 1.3f);
        if (major)
        {
            const auto p = onArc (a, tR + 44.0f);
            g.setColour (c == 0 ? cGold : cDim);
            g.setFont (tui::Fonts::bold (11.0f));
            g.drawText ((c > 0 ? "+" : "") + juce::String (c), juce::Rectangle<float> (p.x - 30.0f, p.y - 8.0f, 60.0f, 16.0f), juce::Justification::centred, false);
        }
    }
    const auto z = onArc (0.0f, tR - 18.0f);
    g.setColour (cGold);
    g.fillEllipse (z.x - 3.0f, z.y - 3.0f, 6.0f, 6.0f);

    // THẤP ♭ / CAO ♯
    {
        const auto f = tui::Fonts::label (10.5f);
        const juce::String lo (vn ("THẤP")), hi ("CAO");
        const float lw = textWidth (f, lo) + 12.0f, hw = textWidth (f, hi) + 12.0f;
        const float ly = tCy + 14.0f;
        g.setFont (f);
        g.setColour (cDim);
        const float lx = tCx - tR - 6.0f - lw * 0.5f, hx = tCx + tR + 6.0f - hw * 0.5f;
        g.drawText (lo, juce::Rectangle<float> (lx, ly - 9.0f, lw, 18.0f), juce::Justification::centredLeft, false);
        drawFlat (g, lx + lw - 6.0f, ly, 10.0f);
        g.drawText (hi, juce::Rectangle<float> (hx, ly - 9.0f, hw, 18.0f), juce::Justification::centredLeft, false);
        drawSharp (g, hx + hw - 8.0f, ly, 10.0f);
    }

    // note strip (idle keys; the sung key is lit live)
    const float ky = (float) H - 62.0f, kw = (float) W - 2.0f * kStripX, step = kw / (float) kStripKeys;
    const juce::Rectangle<float> wellR (kStripX - 8.0f, ky - 8.0f, kw + 16.0f, kStripH + 16.0f);
    g.setColour (cWell);
    g.fillRoundedRectangle (wellR, 12.0f);
    g.setColour (juce::Colours::white.withAlpha (0.05f));
    g.drawRoundedRectangle (wellR.reduced (0.5f), 12.0f, 1.0f);
    for (int i = 0; i < kStripKeys; ++i)
    {
        const int m = stripLow + i, pc = m % 12;
        const bool black = isBlackKey (pc);
        const bool inScale = processor.getNoteState (pc) == TAutoTuneProcessor::kNoteActive;
        const juce::Rectangle<float> r (kStripX + (float) i * step + 1.5f, ky, step - 3.0f, kStripH);
        g.setColour (black ? Colour (0xff16181d) : (inScale ? Colour (0xff262931) : Colour (0xff17191e)));
        if (black && inScale) g.setColour (Colour (0xff262931));
        g.fillRoundedRectangle (r, 6.0f);
        g.setColour (inScale ? cGold.withAlpha (0.35f) : juce::Colours::white.withAlpha (0.05f));
        g.drawRoundedRectangle (r.reduced (0.5f), 6.0f, 1.0f);
        g.setColour (inScale ? cCream : Colour (0xff55524c));
        g.setFont (tui::Fonts::heavy (9.5f));
        g.drawText (noteNameForDisplay (processor, pc), juce::Rectangle<float> (r.getX(), ky + kStripH - 20.0f, r.getWidth(), 16.0f), juce::Justification::centred, false);
        if (pc == 0)
        {
            g.setColour (Colour (0xff55524c));
            g.setFont (tui::Fonts::bold (8.0f));
            g.drawText (juce::String (m / 12 - 1), juce::Rectangle<float> (r.getX(), ky + 4.0f, r.getWidth(), 14.0f), juce::Justification::centred, false);
        }
    }

    // soft dome glow, drawn live with a varying opacity
    glow = juce::Image (juce::Image::ARGB, juce::jmax (1, juce::roundToInt (460.0f * scale)), juce::jmax (1, juce::roundToInt ((float) (H - 110) * scale)), true, juce::SoftwareImageType());
    {
        juce::Graphics gg (glow);
        gg.addTransform (juce::AffineTransform::scale (scale));
        juce::ColourGradient dome (cGold, 230.0f, tCy - 40.0f - 40.0f, cGold.withAlpha (0.0f), 460.0f, tCy - 40.0f - 40.0f, true);
        dome.addColour (0.45, cGold.withAlpha (0.42f));   // smooth falloff, no visible rim
        dome.addColour (0.75, cGold.withAlpha (0.10f));
        gg.setGradientFill (dome);
        gg.fillRect (0.0f, 0.0f, 460.0f, (float) (H - 110));
    }
    return layer;
}

void TPitchView::paintTuner (juce::Graphics& g)
{
    const float W = (float) getWidth(), H = (float) getHeight();
    const float scale = physicalScale (g);
    auto& base = tunerLayer (scale);

    const bool licensed = processor.hasLicenseAccess();
    const bool showNote = licensed && shownTarget > 0.0f && silentTicks < 12;
    const int target = (int) std::round (shownTarget);
    const float dev = showNote ? juce::jlimit (-100.0f, 100.0f, (shownDetected - (float) target) * 100.0f) : 0.0f;
    const float tuneGlow = showNote ? juce::jmax (0.0f, 1.0f - std::abs (dev) / 12.0f) : 0.0f;
    const float pulse01 = (std::sin (pulse) + 1.0f) * 0.5f;

    g.saveState();
    g.setImageResamplingQuality (juce::Graphics::lowResamplingQuality);
    g.setOpacity (showNote ? 0.10f + 0.22f * tuneGlow : 0.07f);
    g.drawImage (glow, juce::Rectangle<float> (tCx - 230.0f, 40.0f, 460.0f, H - 110.0f));
    g.setOpacity (1.0f);
    g.drawImage (base, juce::Rectangle<float> (0.0f, 0.0f, W, H));
    g.restoreState();

    if (showNote)
    {
        // lit ticks
        g.setColour (cGold.withAlpha (0.95f));
        for (int c = -100; c <= 100; c += 5)
        {
            const bool lit = (dev >= 0.0f && c >= 0 && (float) c <= dev) || (dev < 0.0f && c <= 0 && (float) c >= dev);
            if (! lit) continue;
            const bool major = c % 50 == 0, mid = c % 25 == 0;
            const float a = centsAngle ((float) c);
            g.drawLine (juce::Line<float> (onArc (a, tR + 14.0f), onArc (a, tR + (major ? 28.0f : mid ? 23.0f : 19.0f))), major ? 2.2f : 1.3f);
        }
        // lit segment, with a cheap stroked glow instead of a blur
        const float av = centsAngle (dev);
        if (std::abs (av) > 0.002f)
        {
            juce::Path seg;
            seg.addCentredArc (tCx, tCy, tR, tR, 0.0f, juce::jmin (0.0f, av), juce::jmax (0.0f, av), true);
            g.setColour (cGold.withAlpha (0.10f));
            g.strokePath (seg, juce::PathStrokeType (20.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            g.setColour (cGold.withAlpha (0.18f));
            g.strokePath (seg, juce::PathStrokeType (13.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
            juce::ColourGradient grad (cGoldDeep, tCx - tR, 0.0f, cGoldDeep, tCx + tR, 0.0f, false);
            grad.addColour (0.5, cGoldLight);
            g.setGradientFill (grad);
            g.strokePath (seg, juce::PathStrokeType (8.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        }
        // pointer
        const auto p = onArc (av, tR);
        g.setGradientFill (juce::ColourGradient (Colour (0xffffe2a6).withAlpha (0.75f), p.x, p.y, Colour (0xffffe2a6).withAlpha (0.0f), p.x + 22.0f, p.y, true));
        g.fillEllipse (p.x - 22.0f, p.y - 22.0f, 44.0f, 44.0f);
        g.setColour (Colour (0xfffff7e6));
        g.fillEllipse (p.x - 6.5f, p.y - 6.5f, 13.0f, 13.0f);

        // note + octave
        const juce::String name (noteNameForDisplay (processor, target));
        const auto big = tui::Fonts::heavy (104.0f);
        const float nw = textWidth (big, name);
        const float base104 = tCy - 62.0f;
        g.setGradientFill (juce::ColourGradient (Colour (0xfffff7e6), 0.0f, tCy - 150.0f, cGold, 0.0f, tCy - 60.0f, false));
        g.setFont (big);
        g.drawSingleLineText (name, juce::roundToInt (tCx - 10.0f - nw * 0.5f), juce::roundToInt (base104));
        g.setColour (cGold);
        g.setFont (tui::Fonts::heavy (34.0f));
        g.drawText (juce::String (target / 12 - 1), juce::Rectangle<float> (tCx - 10.0f + nw * 0.5f + 6.0f, tCy - 130.0f - 20.0f, 60.0f, 40.0f), juce::Justification::centredLeft, false);

        // Hz · cents
        const int ct = juce::roundToInt (dev);
        const juce::String ctTxt = (ct > 0 ? juce::String ("+") : ct < 0 ? vn ("\xe2\x88\x92") : vn ("\xc2\xb1")) + juce::String (std::abs (ct)) + " ct";
        g.setColour (cDim);
        g.setFont (tui::Fonts::bold (12.5f));
        g.drawText (juce::String (shownHz, 1) + " Hz", juce::Rectangle<float> (tCx - 172.0f, tCy - 46.0f, 160.0f, 20.0f), juce::Justification::centredRight, false);
        g.drawText (vn ("\xc2\xb7"), juce::Rectangle<float> (tCx - 10.0f, tCy - 46.0f, 20.0f, 20.0f), juce::Justification::centred, false);
        g.setColour (std::abs (ct) <= 5 ? cGoldLight : cCream);
        g.setFont (tui::Fonts::heavy (12.5f));
        g.drawText (ctTxt, juce::Rectangle<float> (tCx + 12.0f, tCy - 46.0f, 160.0f, 20.0f), juce::Justification::centredLeft, false);
        if (tuneGlow > 0.6f)
            drawTracked (g, vn ("ĐÚNG TÔNG"), tCx, tCy - 12.0f, 9.5f, cGold);
    }
    else if (licensed)
    {
        const float r = 34.0f + pulse01 * 16.0f;
        g.setColour (cGold.withAlpha (0.45f - 0.3f * pulse01));
        g.drawEllipse (tCx - r, tCy - 92.0f - r, r * 2.0f, r * 2.0f, 2.5f);
        g.setColour (cGold.withAlpha (0.25f));
        g.drawEllipse (tCx - 30.0f, tCy - 122.0f, 60.0f, 60.0f, 1.5f);
        drawTracked (g, vn ("ĐANG NGHE"), tCx, tCy - 92.0f, 11.0f, cCream);
    }

    // note strip: light the sung key and slide the marker with the real pitch
    const float ky = H - 62.0f, kw = W - 2.0f * kStripX, step = kw / (float) kStripKeys;
    if (showNote)
    {
        const int i = target - stripLow;
        if (i >= 0 && i < kStripKeys)
        {
            const juce::Rectangle<float> r (kStripX + (float) i * step + 1.5f, ky, step - 3.0f, kStripH);
            g.setGradientFill (juce::ColourGradient (Colour (0xffffe7b0), 0.0f, ky, Colour (0xffa77a33), 0.0f, ky + kStripH, false));
            g.fillRoundedRectangle (r, 6.0f);
            g.setColour (cGoldLight);
            g.drawRoundedRectangle (r.reduced (0.5f), 6.0f, 1.0f);
            g.setColour (Colour (0xff1c1406));
            g.setFont (tui::Fonts::heavy (9.5f));
            g.drawText (noteNameForDisplay (processor, target), juce::Rectangle<float> (r.getX(), ky + kStripH - 20.0f, r.getWidth(), 16.0f), juce::Justification::centred, false);
            if (target % 12 == 0)
            {
                g.setFont (tui::Fonts::bold (8.0f));
                g.drawText (juce::String (target / 12 - 1), juce::Rectangle<float> (r.getX(), ky + 4.0f, r.getWidth(), 14.0f), juce::Justification::centred, false);
            }
        }
        const float pos = kStripX + (shownDetected - (float) stripLow + 0.5f) * step;
        if (pos > kStripX - 4.0f && pos < kStripX + kw + 4.0f)
        {
            g.setColour (Colour (0xffffe2a6).withAlpha (0.18f));
            g.fillRoundedRectangle (pos - 5.0f, ky - 15.0f, 10.0f, 28.0f, 5.0f);
            g.setColour (Colour (0xffffe2a6).withAlpha (0.30f));
            g.fillRoundedRectangle (pos - 3.0f, ky - 13.0f, 6.0f, 25.0f, 3.0f);
            g.setColour (Colour (0xfffff3d6));
            g.fillRoundedRectangle (pos - 1.5f, ky - 12.0f, 3.0f, 22.0f, 1.5f);
            juce::Path tri;
            tri.addTriangle (pos - 6.0f, ky - 14.0f, pos + 6.0f, ky - 14.0f, pos, ky - 6.0f);
            g.fillPath (tri);
        }
    }

    if (! licensed)
    {
        const auto s = processor.getLicenseSnapshot();
        const juce::Rectangle<float> area (14.0f, 46.0f, W - 28.0f, H - 60.0f);
        g.setColour (juce::Colours::black.withAlpha (0.62f));
        g.fillRoundedRectangle (area, 14.0f);
        g.setColour (cGold);
        g.setFont (tui::Fonts::heavy (22.0f));
        g.drawText (s.status.isNotEmpty() ? s.status : vn ("Chưa kích hoạt"), area.withTrimmedBottom (80.0f).withTrimmedTop (40.0f), juce::Justification::centred, false);
        g.setColour (cCream);
        g.setFont (tui::Fonts::semi (13.0f));
        g.drawText (vn ("Bấm biểu tượng ⚙ → Bản quyền & Kích hoạt. Âm thanh vẫn đi qua nguyên vẹn."),
                    area.withTrimmedTop (area.getHeight() * 0.5f + 10.0f).withHeight (24.0f), juce::Justification::centred, false);
    }
}

void TPitchView::paint (juce::Graphics& g)
{
    if (tunerMode()) paintTuner (g);
    else             paintGraph (g);
}

void TPitchView::paintGraph (juce::Graphics& g)
{
    const bool licensed = processor.hasLicenseAccess();
    const bool hold = processor.getHoldMeter();

    // Target note
    if (shownTarget > 0.0f)
    {
        const int midi = (int) std::round (shownTarget);
        const juce::String name (noteNameForDisplay (processor, midi));
        const juce::String octave (midi / 12 - 1);
        const auto big = tui::Fonts::heavy (76.0f), small = tui::Fonts::heavy (30.0f);
        const float nameW = textWidth (big, name);
        const float alpha = voiced ? 1.0f : 0.45f;
        g.setGradientFill (juce::ColourGradient (Colour (0xfffff7e6).withMultipliedAlpha (alpha), 0, 24.0f,
                                                 cGold.withMultipliedAlpha (alpha), 0, 100.0f, false));
        g.setFont (big);
        g.drawText (name, juce::Rectangle<float> (24.0f, 10.0f, nameW + 4.0f, 96.0f), juce::Justification::centredLeft, false);
        g.setFont (small);
        g.drawText (octave, juce::Rectangle<float> (28.0f + nameW, 20.0f, 60.0f, 40.0f), juce::Justification::centredLeft, false);
        g.setColour (cDim);
        g.setFont (tui::Fonts::semi (11.0f));
        g.drawText (juce::String (shownHz, 1) + " Hz", juce::Rectangle<float> (132.0f, 104.0f, 100.0f, 16.0f), juce::Justification::centredLeft, false);
    }
    else
    {
        g.setColour (cDim.withAlpha (0.5f));
        g.setFont (tui::Fonts::heavy (76.0f));
        g.drawText (juce::String::fromUTF8 ("—"), juce::Rectangle<float> (24.0f, 10.0f, 120.0f, 96.0f), juce::Justification::centredLeft, false);
    }
    drawLabel (g, hold ? "Target note · freeze" : "Target note", 28.0f, 106.0f, hold ? cGold : cDim);

    // Correction meter
    drawLabel (g, "Correction", 242.0f, 26.0f);
    g.setColour (cGold);
    g.setFont (tui::Fonts::heavy (20.0f));
    const float cents = juce::jlimit (-100.0f, 100.0f, shownCents);
    g.drawText ((cents >= 0.0f ? "+" : "") + juce::String (cents, 1) + " ct", juce::Rectangle<float> (400.0f, 14.0f, 160.0f, 28.0f), juce::Justification::centredRight, false);
    paintViewChips (g, false);
    const juce::Rectangle<float> bar (242.0f, 56.0f, 476.0f, 10.0f);
    drawInsetPill (g, bar, 5.0f);
    const float cx = bar.getCentreX(), vx = cx + cents / 100.0f * bar.getWidth() * 0.5f;
    if (std::abs (vx - cx) > 0.5f)
    {
        const auto fill = juce::Rectangle<float> (juce::jmin (cx, vx), bar.getY(), std::abs (vx - cx), bar.getHeight());
        g.setColour (cGold.withAlpha (0.35f));
        g.fillRoundedRectangle (fill.expanded (0.0f, 3.0f), 6.0f);
        g.setGradientFill (juce::ColourGradient (cGoldDeep, cx, 0, cGoldLight, vx, 0, false));
        g.fillRoundedRectangle (fill, 5.0f);
    }
    g.setColour (cGold.withAlpha (0.35f));
    g.fillEllipse (vx - 16.0f, bar.getCentreY() - 16.0f, 32.0f, 32.0f);
    g.setGradientFill (juce::ColourGradient (juce::Colours::white, vx - 3.0f, bar.getCentreY() - 4.0f, cGold, vx + 8.0f, bar.getCentreY() + 8.0f, true));
    g.fillEllipse (vx - 10.0f, bar.getCentreY() - 10.0f, 20.0f, 20.0f);
    for (int i = 0; i <= 20; ++i)
    {
        const float x = bar.getX() + bar.getWidth() * (float) i / 20.0f;
        const bool major = i % 5 == 0;
        g.setColour (i == 10 ? cCream : (major ? Colour (0xff4a4740) : Colour (0xff3a3832)));
        g.fillRect (x - 0.5f, bar.getBottom() + 4.0f, 1.0f, major ? 6.0f : 3.0f);
        if (major)
        {
            const int v = -100 + i * 10;
            g.setColour (i == 10 ? cCream : cDim);
            g.setFont (tui::Fonts::semi (10.0f));
            g.drawText ((v > 0 ? "+" : "") + juce::String (v), juce::Rectangle<float> (x - 22.0f, bar.getBottom() + 11.0f, 44.0f, 14.0f), juce::Justification::centred, false);
        }
    }

    // Pitch graph
    const juce::Rectangle<float> well (14.0f, 136.0f, 716.0f, 238.0f);
    g.setColour (cWell);
    g.fillRoundedRectangle (well, 14.0f);
    g.setGradientFill (juce::ColourGradient (juce::Colours::black.withAlpha (0.55f), 0, well.getY(), juce::Colours::transparentBlack, 0, well.getY() + 14.0f, false));
    g.fillRoundedRectangle (well.withHeight (16.0f), 14.0f);

    const int keyIdx = (int) processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kKey)->load();
    const int topNote = (int) std::round (centre) + 5;
    const float laneTop = well.getY() + 16.0f, laneBottom = well.getBottom() - 16.0f;
    const float laneStep = (laneBottom - laneTop) / 9.0f;
    auto yOf = [&] (float midi) { return laneTop + ((float) topNote - midi) * laneStep; };
    for (int n = 0; n < 10; ++n)
    {
        const int midi = topNote - n;
        const int pc = ((midi % 12) + 12) % 12;
        const bool inScale = processor.getNoteState (pc) == TAutoTuneProcessor::kNoteActive;
        const float y = laneTop + (float) n * laneStep;
        g.setColour (juce::Colours::white.withAlpha (inScale ? 0.06f : 0.025f));
        g.drawHorizontalLine ((int) std::round (y), well.getX() + 46.0f, well.getRight() - 10.0f);
        g.setColour (pc == keyIdx ? cGold : (inScale ? Colour (0xffc9c2b6) : Colour (0xff5d5951)));
        g.setFont (inScale ? tui::Fonts::heavy (10.5f) : tui::Fonts::semi (10.5f));
        g.drawText (noteNameForDisplay (processor, pc) + juce::String (midi / 12 - 1), juce::Rectangle<float> (well.getX() + 10.0f, y - 7.0f, 40.0f, 14.0f), juce::Justification::centredLeft, false);
    }

    g.saveState();
    g.reduceClipRegion (well.withTrimmedLeft (46.0f).reduced (0.0f, 4.0f).toNearestInt());
    const float x0 = well.getX() + 56.0f, x1 = well.getRight() - 30.0f;
    auto buildPath = [&] (const std::array<float, historySize>& data)
    {
        juce::Path p;
        bool drawing = false;
        for (int i = 0; i < historySize; ++i)
        {
            const float v = data[(size_t) ((write + i) % historySize)];
            const float x = x0 + (x1 - x0) * (float) i / (float) (historySize - 1);
            if (v <= 0.0f) { drawing = false; continue; }
            const float y = yOf (v);
            if (! drawing) { p.startNewSubPath (x, y); drawing = true; }
            else p.lineTo (x, y);
        }
        return p;
    };
    const auto inPath = buildPath (input), outPath = buildPath (output);
    g.setColour (Colour (0xff9aa3b5).withAlpha (0.55f));
    g.strokePath (inPath, juce::PathStrokeType (1.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour (cGold.withAlpha (0.18f));
    g.strokePath (outPath, juce::PathStrokeType (8.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour (cGold.withAlpha (0.35f));
    g.strokePath (outPath, juce::PathStrokeType (4.5f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    g.setColour (Colour (0xffffd98f));
    g.strokePath (outPath, juce::PathStrokeType (2.4f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    // Fade old history into the well on the left; newest sample sits at x1.
    g.setGradientFill (juce::ColourGradient (cWell, well.getX() + 46.0f, 0, cWell.withAlpha (0.0f), well.getX() + 140.0f, 0, false));
    g.fillRect (juce::Rectangle<float> (well.getX() + 46.0f, well.getY(), 94.0f, well.getHeight()));
    g.restoreState();

    juce::Path dash;
    dash.startNewSubPath (x1, well.getY() + 8.0f);
    dash.lineTo (x1, well.getBottom() - 8.0f);
    juce::Path dashed;
    const float pattern[] = { 3.0f, 4.0f };
    juce::PathStrokeType (1.0f).createDashedStroke (dashed, dash, pattern, 2);
    g.setColour (cGold.withAlpha (0.35f));
    g.fillPath (dashed);
    const float lastOut = output[(size_t) ((write + historySize - 1) % historySize)];
    if (lastOut > 0.0f)
    {
        const float y = juce::jlimit (well.getY() + 8.0f, well.getBottom() - 8.0f, yOf (lastOut));
        g.setColour (cGold.withAlpha (0.25f));
        g.fillEllipse (x1 - 11.0f, y - 11.0f, 22.0f, 22.0f);
        g.setColour (cGoldLight);
        g.fillEllipse (x1 - 5.0f, y - 5.0f, 10.0f, 10.0f);
    }

    // Legend
    g.setFont (tui::Fonts::label (10.0f));
    g.setColour (Colour (0xff9aa3b5));
    g.fillRect (536.0f, 151.0f, 16.0f, 2.0f);
    g.setColour (cDim);
    g.drawText ("INPUT", juce::Rectangle<float> (558.0f, 144.0f, 60.0f, 16.0f), juce::Justification::centredLeft, false);
    g.setColour (cGold);
    g.fillRect (620.0f, 150.5f, 16.0f, 3.0f);
    g.drawText ("OUTPUT", juce::Rectangle<float> (642.0f, 144.0f, 80.0f, 16.0f), juce::Justification::centredLeft, false);

    if (! licensed)
    {
        const auto s = processor.getLicenseSnapshot();
        g.setColour (juce::Colours::black.withAlpha (0.62f));
        g.fillRoundedRectangle (well, 14.0f);
        g.setColour (cGold);
        g.setFont (tui::Fonts::heavy (22.0f));
        g.drawText (s.status.isNotEmpty() ? s.status : vn ("Chưa kích hoạt"), well.withTrimmedBottom (60.0f).withTrimmedTop (40.0f), juce::Justification::centred, false);
        g.setColour (cCream);
        g.setFont (tui::Fonts::semi (13.0f));
        g.drawText (vn ("Bấm biểu tượng ⚙ → Bản quyền & Kích hoạt. Âm thanh vẫn đi qua nguyên vẹn."),
                    well.withTrimmedTop (128.0f).withHeight (24.0f), juce::Justification::centred, false);
    }
}

//==============================================================================
TScaleKeys::TScaleKeys (TAutoTuneProcessor& p) : processor (p) { lastStates.fill (-1); }

juce::Rectangle<float> TScaleKeys::keyRect (int pc) const
{
    static const int whiteIndex[12] = { 0, -1, 1, -1, 2, 3, -1, 4, -1, 5, -1, 6 };
    static const int blackAfter[12] = { -1, 0, -1, 1, -1, -1, 3, -1, 4, -1, 5, -1 };
    constexpr float W = 74.0f, H = 118.0f, gap = 8.0f;
    if (whiteIndex[pc] >= 0)
        return { (float) whiteIndex[pc] * (W + gap), 26.0f, W, H };
    return { (float) (blackAfter[pc] + 1) * (W + gap) - gap * 0.5f - 27.0f, 4.0f, 54.0f, 66.0f };
}

int TScaleKeys::hitTest (juce::Point<float> p) const
{
    for (int pc : { 1, 3, 6, 8, 10 })
        if (keyRect (pc).contains (p)) return pc;
    for (int pc : { 0, 2, 4, 5, 7, 9, 11 })
        if (keyRect (pc).contains (p)) return pc;
    return -1;
}

void TScaleKeys::tick()
{
    int now = -1;
    if (processor.isVoiced())
    {
        const float det = processor.getDetectedMidiNote() + processor.getCentsCorrection() / 100.0f;
        if (det > 0.0f) now = ((int) std::round (det) % 12 + 12) % 12;
    }
    bool changed = now != sung;
    sung = now;
    for (int i = 0; i < 12; ++i)
    {
        const int st = processor.getNoteState (i);
        if (st != lastStates[(size_t) i]) { lastStates[(size_t) i] = st; changed = true; }
    }
    const int key = (int) processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kKey)->load();
    if (key != lastKey) { lastKey = key; changed = true; }
    if (changed) repaint();
}

void TScaleKeys::paint (juce::Graphics& g)
{
    const int key = (int) processor.getAPVTS().getRawParameterValue (TAutoTuneParams::kKey)->load();
    auto drawKey = [&] (int pc, bool black)
    {
        const auto r = keyRect (pc);
        const int st = processor.getNoteState (pc);
        const bool active = st == TAutoTuneProcessor::kNoteActive;
        const bool bypassed = st == TAutoTuneProcessor::kNoteBypassed;
        const bool root = pc == key && active;
        const float radius = black ? 11.0f : 12.0f;
        juce::Path shape;
        shape.addRoundedRectangle (r, radius);
        if (root)
        {
            g.setColour (cGold.withAlpha (0.22f));
            g.fillRoundedRectangle (r.expanded (8.0f), radius + 8.0f);
        }
        if (pc == sung)
        {
            g.setColour (cGoldLight.withAlpha (0.35f));
            g.fillRoundedRectangle (r.expanded (4.0f), radius + 4.0f);
        }
        drawCachedShadow (g, "key" + juce::String (pc), shape, juce::DropShadow (juce::Colours::black.withAlpha (black ? 0.75f : 0.6f), black ? 18 : 16, { 0, black ? 12 : 10 }));
        if (root)
            g.setGradientFill (juce::ColourGradient (Colour (0xffffe7b0), r.getX(), r.getY(), Colour (0xffa77a33), r.getRight(), r.getBottom(), false));
        else if (black)
            g.setGradientFill (juce::ColourGradient (Colour (0xff30333c), 0, r.getY(), Colour (0xff16181d), 0, r.getBottom(), false));
        else if (active || bypassed)
            g.setGradientFill (juce::ColourGradient (Colour (0xff2c2f38), 0, r.getY(), Colour (0xff1a1c22), 0, r.getBottom(), false));
        else
            g.setGradientFill (juce::ColourGradient (Colour (0xff17191e), 0, r.getY(), Colour (0xff101115), 0, r.getBottom(), false));
        g.fillPath (shape);
        // bevel: light top edge, dark bottom lip
        g.setColour (juce::Colours::white.withAlpha (root ? 0.6f : (black ? 0.14f : 0.08f)));
        g.drawHorizontalLine ((int) r.getY() + 1, r.getX() + radius, r.getRight() - radius);
        g.setColour (juce::Colours::black.withAlpha (0.35f));
        g.fillRect (r.getX() + radius * 0.5f, r.getBottom() - 4.0f, r.getWidth() - radius, 3.0f);
        const auto border = root ? cGoldLight : bypassed ? cAmber.withAlpha (0.7f) : active ? cGold.withAlpha (black ? 0.6f : 0.55f)
                                                                                              : juce::Colours::white.withAlpha (black ? 0.10f : 0.06f);
        g.setColour (border);
        g.drawRoundedRectangle (r.reduced (0.5f), radius, root ? 1.2f : 1.0f);

        const auto textColour = root ? Colour (0xff1c1406) : bypassed ? cAmber : active ? cCream : (black ? Colour (0xff77736b) : Colour (0xff5d5951));
        g.setColour (textColour);
        g.setFont (tui::Fonts::heavy (black ? 13.0f : 15.0f));
        if (black)
            g.drawText (noteNameForDisplay (processor, pc), r, juce::Justification::centred, false);
        else
            g.drawText (noteNameForDisplay (processor, pc), r.withTrimmedTop (r.getHeight() - 34.0f).withTrimmedBottom (10.0f), juce::Justification::centred, false);
        if (root || bypassed)
        {
            g.setColour (root ? Colour (0xff3a2a0c) : cAmber);
            g.setFont (tui::Fonts::label (8.5f));
            const auto tag = root ? juce::String ("ROOT") : juce::String ("BYPASS");
            if (black) g.drawText (tag, r.withTrimmedTop (r.getHeight() - 18.0f), juce::Justification::centred, false);
            else g.drawText (tag, r.withTrimmedTop (r.getHeight() - 50.0f).withHeight (14.0f), juce::Justification::centred, false);
        }
    };
    for (int pc : { 0, 2, 4, 5, 7, 9, 11 }) drawKey (pc, false);
    for (int pc : { 1, 3, 6, 8, 10 }) drawKey (pc, true);
}

void TScaleKeys::mouseUp (const juce::MouseEvent& e)
{
    const int pc = hitTest (e.position);
    if (pc < 0) return;
    processor.cycleNoteState (pc, e.mods.isPopupMenu() || e.mods.isAltDown());
    tick();
    repaint();
}

//==============================================================================
class TAutoTuneEditor::Content final : public juce::Component
{
public:
    explicit Content (TAutoTuneProcessor& p)
        : proc (p), pitch (p), keys (p),
          retune (p.getAPVTS(), TAutoTuneParams::kRetuneSpeed, "Retune speed", tui::Knob::Style::Hero, cGold,
                  [] (double v) { return juce::String (juce::roundToInt (v)) + " ms"; }),
          humanize (p.getAPVTS(), TAutoTuneParams::kHumanize, "Humanize", tui::Knob::Style::Header, cRose,
                    [] (double v) { return juce::String (juce::roundToInt (v)); }),
          flex (p.getAPVTS(), TAutoTuneParams::kFlexTune, "Flex Tune", tui::Knob::Style::Header, cIce,
                [] (double v) { return juce::String (juce::roundToInt (v)); }),
          natVib (p.getAPVTS(), TAutoTuneParams::kNaturalVibrato, "Nat. Vibrato", tui::Knob::Style::Header, cViolet,
                  [] (double v) { return (v > 0.04 ? "+" : "") + juce::String (v, 1); }),
          formantKnob (p.getAPVTS(), TAutoTuneParams::kThroatLength, "Formant", tui::Knob::Style::Side, cGold,
                       [] (double v) { return juce::String (v / 100.0, 2); }),
          detune (p.getAPVTS(), TAutoTuneParams::kDetune, "Detune", tui::Knob::Style::Side, cGold,
                  [] (double v) { return formatDetuneHz (v); }),
          mix (p.getAPVTS(), TAutoTuneParams::kMix, "Mix", tui::Knob::Style::Side, cGold,
               [] (double v) { return juce::String (juce::roundToInt (v)) + "%"; }),
          tracking (p.getAPVTS(), TAutoTuneParams::kTracking, "Tracking", tui::Knob::Style::Side, cGold,
                    [] (double v) { return juce::String (juce::roundToInt (v)); }),
          vibRate (p.getAPVTS(), TAutoTuneParams::kVibratoRate, "Rate", tui::Knob::Style::Below, cGold, [] (double v) { return juce::String (v, 1) + " Hz"; }),
          vibDelay (p.getAPVTS(), TAutoTuneParams::kVibratoDelay, "Delay", tui::Knob::Style::Below, cGold, [] (double v) { return juce::String (juce::roundToInt (v)) + " ms"; }),
          vibOnset (p.getAPVTS(), TAutoTuneParams::kVibratoTrans, "Onset", tui::Knob::Style::Below, cGold, [] (double v) { return juce::String (juce::roundToInt (v)) + " ms"; }),
          vibVar (p.getAPVTS(), TAutoTuneParams::kVibratoVar, "Variation", tui::Knob::Style::Below, cGold, [] (double v) { return juce::String (juce::roundToInt (v)); }),
          vibPitch (p.getAPVTS(), TAutoTuneParams::kVibratoPitch, "Pitch", tui::Knob::Style::Below, cGold, [] (double v) { return juce::String (juce::roundToInt (v)) + " ct"; }),
          vibAmp (p.getAPVTS(), TAutoTuneParams::kVibratoAmp, "Amplitude", tui::Knob::Style::Below, cGold, [] (double v) { return juce::String (juce::roundToInt (v)); }),
          vibFormant (p.getAPVTS(), TAutoTuneParams::kVibratoFormant, "Formant", tui::Knob::Style::Below, cGold, [] (double v) { return juce::String (juce::roundToInt (v)); }),
          rangeField ("Vocal range"), keyField ("Key " + juce::String::fromUTF8 ("·") + " Scale"), presetField ("Preset"),
          gear (tui::RoundButton::Icon::Gear), power (tui::RoundButton::Icon::Power),
          tabScale ("Scale notes", nullptr), tabVibrato ("Vibrato", nullptr),
          scaleSet ({ "MAJOR", "MINOR", "ALL" }, 11.0f),
          vibShape ({ "OFF", "SINE", "SQUARE", "SAW" }, 11.0f),
          character ({ "Modern", "Classic" }), formantMode ({ "Off", "On" }),
          ratioLock (*p.getAPVTS().getParameter (TAutoTuneParams::kRatioLock)),
          ignoreVib (*p.getAPVTS().getParameter (TAutoTuneParams::kIgnoreVibrato)),
          transpose (*p.getAPVTS().getParameter (TAutoTuneParams::kTranspose))
    {
        for (auto* c : std::initializer_list<juce::Component*> { &pitch, &keys, &retune, &humanize, &flex, &natVib, &formantKnob, &detune, &mix, &tracking,
                                                                  &vibRate, &vibDelay, &vibOnset, &vibVar, &vibPitch, &vibAmp, &vibFormant,
                                                                  &rangeField, &keyField, &presetField, &gear, &power, &tabScale, &tabVibrato,
                                                                  &scaleSet, &vibShape, &character, &formantMode, &ratioLock, &ignoreVib, &transpose, &subtitle })
            addAndMakeVisible (c);
        presetField.arrows = true;
        subtitle.setFont (tui::Fonts::label (10.0f));
        subtitle.setColour (juce::Label::textColourId, cGold);
        subtitle.setBorderSize ({});
        subtitle.setInterceptsMouseClicks (false, false);

        auto& apvts = p.getAPVTS();
        character.bind (*apvts.getParameter (TAutoTuneParams::kClassicMode), [] (float v) { return v > 0.5f ? 1 : 0; }, [] (int i) { return (float) i; });
        formantMode.bind (*apvts.getParameter (TAutoTuneParams::kUseFormants), [] (float v) { return v > 0.5f ? 1 : 0; }, [] (int i) { return (float) i; });
        vibShape.bind (*apvts.getParameter (TAutoTuneParams::kVibratoShape), [] (float v) { return juce::roundToInt (v); }, [] (int i) { return (float) i; });

        pitch.setBounds (20, 90, 744, 388);
        retune.setBounds (780, 90, 320, 240);
        humanize.setBounds (792, 344, 100, 124);
        flex.setBounds (890, 344, 100, 124);
        natVib.setBounds (988, 344, 100, 124);

        rangeField.setBounds (300, 18, 206, 54);
        keyField.setBounds (518, 18, 244, 54);
        presetField.setBounds (774, 18, 196, 54);
        gear.setBounds (978, 14, 62, 62);
        power.setBounds (1040, 14, 62, 62);
        subtitle.setBounds (85, 49, 210, 16);

        tabScale.setBounds (40, 506, 116, 28);
        tabVibrato.setBounds (162, 506, 92, 28);
        scaleSet.setBounds (420, 505, 204, 30);
        vibShape.setBounds (300, 505, 324, 30);
        keys.setBounds (46, 540, 600, 150);
        const int vx = 40, vstep = 74;
        int i = 0;
        for (auto* k : { &vibRate, &vibDelay, &vibOnset, &vibVar, &vibPitch, &vibAmp, &vibFormant })
            k->setBounds (vx + vstep * i++, 552, vstep, 100);
        ignoreVib.setBounds (584, 600, 40, 22);

        formantKnob.setBounds (656, 540, 122, 52);
        detune.setBounds (782, 540, 128, 52);
        mix.setBounds (656, 602, 122, 52);
        tracking.setBounds (782, 602, 128, 52);
        transpose.setBounds (780, 658, 110, 30);

        character.setBounds (934, 534, 150, 36);
        formantMode.setBounds (934, 604, 150, 36);
        ratioLock.setBounds (1044, 660, 40, 22);
        setSize (TAutoTuneEditor::designW, TAutoTuneEditor::designH);
    }

    void paint (juce::Graphics& g) override
    {
        const float scale = juce::jmax (1.0f, (float) g.getInternalContext().getPhysicalPixelScaleFactor());
        const int pw = juce::roundToInt ((float) getWidth() * scale), ph = juce::roundToInt ((float) getHeight() * scale);
        if (background.isNull() || background.getWidth() != pw || background.getHeight() != ph || backgroundTab != showVibrato)
        {
            background = juce::Image (juce::Image::ARGB, pw, ph, true, juce::SoftwareImageType());
            juce::Graphics bg (background);
            bg.addTransform (juce::AffineTransform::scale (scale));
            paintStatic (bg);
            backgroundTab = showVibrato;
        }
        // The cached background is already at the screen's pixel size, so it maps ~1:1:
        // nearest-pixel drawing gives the same picture without the cost of resampling it
        // on every repaint of the live pitch display (30 times per second).
        g.setImageResamplingQuality (juce::Graphics::lowResamplingQuality);
        g.drawImage (background, getLocalBounds().toFloat());
    }

    void setVibratoTab (bool vib)
    {
        showVibrato = vib;
        tabScale.setActive (! vib);
        tabVibrato.setActive (vib);
        keys.setVisible (! vib);
        scaleSet.setVisible (! vib);
        vibShape.setVisible (vib);
        for (auto* k : { &vibRate, &vibDelay, &vibOnset, &vibVar, &vibPitch, &vibAmp, &vibFormant }) k->setVisible (vib);
        ignoreVib.setVisible (vib);
        repaint();
    }

    TAutoTuneProcessor& proc;
    TPitchView pitch;
    TScaleKeys keys;
    tui::Knob retune, humanize, flex, natVib, formantKnob, detune, mix, tracking;
    tui::Knob vibRate, vibDelay, vibOnset, vibVar, vibPitch, vibAmp, vibFormant;
    tui::Field rangeField, keyField, presetField;
    tui::RoundButton gear, power;
    tui::TextChip tabScale, tabVibrato;
    tui::Segmented scaleSet, vibShape, character, formantMode;
    tui::Switch ratioLock, ignoreVib;
    TransposeStepper transpose;
    juce::Label subtitle;
    bool showVibrato = false;

private:
    void paintStatic (juce::Graphics& g)
    {
        g.fillAll (cBg);
        g.setGradientFill (juce::ColourGradient (Colour (0xff1a1d26), 336.0f, -72.0f, cBg, 336.0f + 760.0f, -72.0f + 420.0f, true));
        g.fillRect (getLocalBounds());

        // Logo + wordmark (T in cream, hyphen in gold — same as T-AutoKey)
        const juce::Rectangle<float> logo (24.0f, 20.0f, 48.0f, 48.0f);
        g.setGradientFill (juce::ColourGradient (cGold.withAlpha (0.30f), logo.getCentreX(), logo.getCentreY(), cGold.withAlpha (0.0f), logo.getCentreX() + 40.0f, logo.getCentreY(), true));
        g.fillEllipse (logo.expanded (16.0f));
        g.setGradientFill (juce::ColourGradient (Colour (0xffffe7b0), logo.getX() + 17.0f, logo.getY() + 14.0f, Colour (0xff8a6428), logo.getRight(), logo.getBottom(), true));
        g.fillEllipse (logo);
        juce::Path wave;
        wave.startNewSubPath (34.0f, 45.0f);
        wave.lineTo (39.0f, 38.0f); wave.lineTo (44.0f, 51.0f); wave.lineTo (50.0f, 33.0f);
        wave.lineTo (55.0f, 48.0f); wave.lineTo (60.0f, 41.0f); wave.lineTo (63.0f, 43.0f);
        g.setColour (Colour (0xff1a1206));
        g.strokePath (wave, juce::PathStrokeType (2.6f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        const auto title = tui::Fonts::heavy (24.0f);
        g.setFont (title);
        float tx = 84.0f;
        for (auto [text, colour] : { std::pair<juce::String, Colour> { "T", cCream }, { "-", cGold }, { "AutoTune", cCream } })
        {
            g.setColour (colour);
            g.drawText (text, juce::Rectangle<float> (tx, 16.0f, 200.0f, 32.0f), juce::Justification::centredLeft, false);
            tx += textWidth (title, text) + 0.5f;
        }

        drawPanel (g, { 20.0f, 90.0f, 744.0f, 388.0f });
        drawPanel (g, { 780.0f, 90.0f, 320.0f, 388.0f });
        g.setColour (juce::Colours::white.withAlpha (0.07f));
        g.fillRect (808.0f, 332.0f, 264.0f, 1.0f);

        drawPanel (g, { 20.0f, 494.0f, 1080.0f, 206.0f });
        g.setColour (juce::Colours::white.withAlpha (0.07f));
        g.fillRect (640.0f, 514.0f, 1.0f, 166.0f);
        g.fillRect (916.0f, 514.0f, 1.0f, 166.0f);
        if (showVibrato)
        {
            drawLabel (g, "Ignore", 576.0f, 560.0f, cDim, 9.5f, juce::Justification::centred, 56.0f);
            drawLabel (g, "vibrato", 576.0f, 574.0f, cDim, 9.5f, juce::Justification::centred, 56.0f);
        }
        drawLabel (g, "Tone", 660.0f, 514.0f);
        drawLabel (g, "Transpose", 660.0f, 668.0f);
        drawLabel (g, "Character", 934.0f, 514.0f);
        drawLabel (g, "Formant", 934.0f, 584.0f);
        drawLabel (g, "Ratio lock", 934.0f, 666.0f);
    }

    juce::Image background;
    bool backgroundTab = false;
};

//==============================================================================
TAutoTuneEditor::TAutoTuneEditor (TAutoTuneProcessor& p)
    : juce::AudioProcessorEditor (&p), processorRef (p)
{
    setLookAndFeel (&lookAndFeel);
    content = std::make_unique<Content> (p);
    addAndMakeVisible (*content);

    auto& c = *content;
    c.rangeField.onClick = [this] { showRangeMenu(); };
    c.keyField.onClick = [this] { showKeyMenu(); };
    c.presetField.onClick = [this] { showPresetMenu(); };
    c.presetField.onPrev = [this] { applyPreset (currentPreset - 1); };
    c.presetField.onNext = [this] { applyPreset (currentPreset + 1); };
    c.gear.onClick = [this] { showSettingsMenu(); };
    c.power.onClick = [this] { setParam (TAutoTuneParams::kMasterBypass, getParam (TAutoTuneParams::kMasterBypass) > 0.5f ? 0.0f : 1.0f); };
    c.tabScale.onClick = [this] { setBottomTab (0); };
    c.tabVibrato.onClick = [this] { setBottomTab (1); };
    c.scaleSet.onSelect = [this] (int i)
    {
        setParam (TAutoTuneParams::kScale, (float) i);   // 0 Major, 1 Minor, 2 Chromatic
        processorRef.markKeyChangedByUser();
    };
    setBottomTab (0);

    setResizable (true, true);
    setResizeLimits (designW / 2, designH / 2, designW * 3 / 2, designH * 3 / 2);
    getConstrainer()->setFixedAspectRatio ((double) designW / (double) designH);
    {
        // v1.2.1: open a little smaller (80 % of the design, was 90 %) and never larger than the
        // screen's work area, so the DAW's plugin window can always be dragged by its title bar.
        juce::Rectangle<int> area (1280, 680);
        if (auto* d = juce::Desktop::getInstance().getDisplays().getPrimaryDisplay()) area = d->userArea;
        const float fit = juce::jmin ((float) (area.getWidth() - 40) / (float) designW, (float) (area.getHeight() - 140) / (float) designH);
        const float scale = juce::jlimit (0.5f, 0.8f, fit);
        setSize (juce::roundToInt ((float) designW * scale), juce::roundToInt ((float) designH * scale));
    }
    refreshHeader();
    startTimerHz (30);
}

TAutoTuneEditor::~TAutoTuneEditor()
{
    stopTimer();
    licensePanel.reset();
    licenseOverlay.reset();
    content.reset();
    setLookAndFeel (nullptr);
}

void TAutoTuneEditor::paint (juce::Graphics& g) { g.fillAll (cBg); }

void TAutoTuneEditor::resized()
{
    const float s = (float) getWidth() / (float) designW;
    content->setBounds (0, 0, designW, designH);
    content->setTransform (juce::AffineTransform::scale (s));
    if (licenseOverlay != nullptr)
    {
        licenseOverlay->setBounds (0, 0, designW, designH);
        licenseOverlay->setTransform (juce::AffineTransform::scale (s));
    }
}

void TAutoTuneEditor::setParam (const char* id, float plainValue)
{
    if (auto* param = processorRef.getAPVTS().getParameter (id))
    {
        param->beginChangeGesture();
        param->setValueNotifyingHost (param->convertTo0to1 (plainValue));
        param->endChangeGesture();
    }
}

float TAutoTuneEditor::getParam (const char* id) const
{
    return processorRef.getAPVTS().getRawParameterValue (id)->load();
}

void TAutoTuneEditor::setBottomTab (int tab)
{
    bottomTab = tab;
    content->setVibratoTab (tab == 1);
}

void TAutoTuneEditor::updateEnablement()
{
    const bool classic = getParam (TAutoTuneParams::kClassicMode) > 0.5f;
    const bool formants = getParam (TAutoTuneParams::kUseFormants) > 0.5f;
    content->flex.setKnobEnabled (! classic);
    content->formantKnob.setKnobEnabled (formants && ! classic);
    const bool vibOn = getParam (TAutoTuneParams::kVibratoShape) > 0.5f;
    for (auto* k : { &content->vibRate, &content->vibDelay, &content->vibOnset, &content->vibVar, &content->vibPitch, &content->vibAmp, &content->vibFormant })
        k->setKnobEnabled (vibOn);
}

void TAutoTuneEditor::refreshHeader()
{
    auto& c = *content;
    const auto inputNames = TAutoTuneProcessor::getInputTypeNames();
    const auto scaleNames = TAutoTuneProcessor::getScaleNames();
    const auto keyNames = TAutoTuneProcessor::getKeyNamesForScale (juce::jlimit (0, scaleNames.size() - 1, (int) getParam (TAutoTuneParams::kScale)));

    if (processorRef.isLearningInputType())
    {
        c.rangeField.setValue (vn ("Đang nghe giọng..."));
        c.rangeField.setProgress (processorRef.getLearnProgress());
    }
    else
    {
        c.rangeField.setValue (inputNames[juce::jlimit (0, inputNames.size() - 1, (int) getParam (TAutoTuneParams::kInputType))]);
        c.rangeField.setProgress (-1.0f);
    }

    const int key = juce::jlimit (0, 11, (int) getParam (TAutoTuneParams::kKey));
    const int scale = juce::jlimit (0, scaleNames.size() - 1, (int) getParam (TAutoTuneParams::kScale));
    if (processorRef.isDetectingAutoKey())
    {
        c.keyField.setValue (vn ("Đang dò tông..."));
        c.keyField.setProgress (processorRef.getAutoKeyProgress());
        c.keyField.setChip ({});
    }
    else
    {
        c.keyField.setValue (keyNames[key] + " " + scaleNames[scale]);
        c.keyField.setProgress (-1.0f);
        const bool linked = processorRef.isAutoKeySyncEnabled() && processorRef.isKeyFromAutoKey();
        c.keyField.setChip (linked ? "AUTO-KEY" : "");
        c.keyField.setHighlighted (linked);
    }
    c.scaleSet.setSelected (scale <= 2 ? scale : -1);

    static const char* const presetNames[] = { "Default", "T-Pain Hard 0ms", "Travis Dark Formant", "Modern Pop Vocal",
                                               "Natural Silk", "Classic AT5 Cher", "Soprano Air", "Low Male Sub",
                                               "Hyperpop +12", "Rich Vibrato", "Parallel 50% Mix", "Ratio-Locked Shift", "Live Smooth" };
    const auto liveValue = [this](const char* id, float value)
    {
        return std::abs(processorRef.getAPVTS().getRawParameterValue(id)->load() - value) < 0.01f;
    };
    const bool liveUnchanged = liveValue(TAutoTuneParams::kRetuneSpeed, 25.0f)
        && liveValue(TAutoTuneParams::kFlexTune, 15.0f)
        && liveValue(TAutoTuneParams::kHumanize, 35.0f)
        && liveValue(TAutoTuneParams::kNaturalVibrato, 0.0f)
        && liveValue(TAutoTuneParams::kMix, 100.0f)
        && liveValue(TAutoTuneParams::kUseFormants, 0.0f)
        && liveValue(TAutoTuneParams::kClassicMode, 0.0f)
        && liveValue(TAutoTuneParams::kTranspose, 0.0f);
    c.presetField.setValue (currentPreset == 12 && !liveUnchanged
        ? "Custom" : presetNames[((currentPreset % 13) + 13) % 13]);
    c.power.setLit (getParam (TAutoTuneParams::kMasterBypass) < 0.5f);

    const auto s = processorRef.getLicenseSnapshot();
    juce::String sub = "REAL-TIME PITCH CORRECTION";
    auto colour = cGold;
    if (! s.allowed) { sub = s.trialStarted ? vn ("HẾT HẠN DÙNG THỬ") : vn ("CHƯA KÍCH HOẠT"); colour = cRose; }
    else if (! s.activated && s.trialStarted) sub = vn ("DÙNG THỬ · CÒN ") + juce::String (s.daysLeft) + vn (" NGÀY");
    if (c.subtitle.getText() != sub) c.subtitle.setText (sub, juce::dontSendNotification);
    c.subtitle.setColour (juce::Label::textColourId, colour);
}

void TAutoTuneEditor::timerCallback()
{
    content->pitch.tick();
    content->keys.tick();
    refreshHeader();
    updateEnablement();
}

void TAutoTuneEditor::applyPreset (int presetIdx)
{
    struct PresetDef
    {
        int inputType, key, scale;
        float retune, flex, natVib, humanize;
        bool formant, classic, ratioLock;
        float throat, transpose, detune, tracking, mix;
        int vibShape;
        float vibRate, vibPitch;
    };
    static constexpr PresetDef kPresets[13] = {
        { 0, 0, 2,  20.0f,  0.0f,  0.0f,  0.0f, false, false, false, 100.0f,  0.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f,  0.0f },
        { 0, 3, 1,   0.0f,  0.0f, -6.0f,  0.0f, false, true,  false, 100.0f,  0.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f,  0.0f },
        { 0, 5, 1,   3.0f,  5.0f,  0.0f,  0.0f, true,  false, false, 128.0f,  0.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f,  0.0f },
        { 0, 0, 0,  15.0f, 22.0f,  0.0f, 25.0f, true,  false, false, 100.0f,  0.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f,  0.0f },
        { 0, 0, 2,  45.0f, 40.0f,  1.5f, 50.0f, true,  false, false, 100.0f,  0.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f,  0.0f },
        { 1, 0, 0,   0.0f,  0.0f, -9.0f,  0.0f, false, true,  false, 100.0f,  0.0f, 0.0f, 65.0f, 100.0f, 0, 5.5f,  0.0f },
        { 1, 7, 0,  12.0f, 15.0f,  0.0f, 20.0f, true,  false, false,  90.0f,  0.0f, 0.0f, 50.0f, 100.0f, 1, 5.8f, 18.0f },
        { 2, 2, 1,  18.0f, 12.0f,  0.0f, 30.0f, true,  false, false, 118.0f,  0.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f,  0.0f },
        { 1, 0, 0,   0.0f,  0.0f,  0.0f,  0.0f, true,  false, false,  74.0f, 12.0f, 0.0f, 55.0f, 100.0f, 0, 5.5f,  0.0f },
        { 0, 0, 2,  22.0f, 18.0f,  2.0f, 30.0f, true,  false, false, 100.0f,  0.0f, 0.0f, 50.0f, 100.0f, 1, 5.6f, 35.0f },
        { 0, 0, 2,   5.0f, 10.0f,  0.0f, 15.0f, true,  false, false, 100.0f,  0.0f, 0.0f, 50.0f,  50.0f, 0, 5.5f,  0.0f },
        { 0, 0, 2,  10.0f, 10.0f,  0.0f, 20.0f, true,  false, true,  100.0f,  5.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f,  0.0f },
        { 0, 0, 2,  25.0f, 15.0f,  0.0f, 35.0f, false, false, false, 100.0f, 0.0f, 0.0f, 50.0f, 100.0f, 0, 5.5f, 0.0f }
    };
    currentPreset = ((presetIdx % 13) + 13) % 13;
    const auto& pr = kPresets[currentPreset];
    // Keep the key/scale chosen by T-AutoKey while the link is active.
    const bool keepKey = processorRef.isAutoKeySyncEnabled() && processorRef.isKeyFromAutoKey();
    setParam (TAutoTuneParams::kInputType, (float) pr.inputType);
    if (! keepKey)
    {
        setParam (TAutoTuneParams::kKey, (float) pr.key);
        setParam (TAutoTuneParams::kScale, (float) pr.scale);
    }
    setParam (TAutoTuneParams::kRetuneSpeed, pr.retune);
    setParam (TAutoTuneParams::kFlexTune, pr.flex);
    setParam (TAutoTuneParams::kNaturalVibrato, pr.natVib);
    setParam (TAutoTuneParams::kHumanize, pr.humanize);
    setParam (TAutoTuneParams::kUseFormants, pr.formant ? 1.0f : 0.0f);
    setParam (TAutoTuneParams::kClassicMode, pr.classic ? 1.0f : 0.0f);
    setParam (TAutoTuneParams::kRatioLock, pr.ratioLock ? 1.0f : 0.0f);
    setParam (TAutoTuneParams::kThroatLength, pr.throat);
    setParam (TAutoTuneParams::kTranspose, pr.transpose);
    setParam (TAutoTuneParams::kDetune, pr.detune);
    setParam (TAutoTuneParams::kTracking, pr.tracking);
    setParam (TAutoTuneParams::kMix, pr.mix);
    setParam (TAutoTuneParams::kVibratoShape, (float) pr.vibShape);
    setParam (TAutoTuneParams::kVibratoRate, pr.vibRate);
    setParam (TAutoTuneParams::kVibratoPitch, pr.vibPitch);
    refreshHeader();
}

void TAutoTuneEditor::showPresetMenu()
{
    static const char* const names[] = { "Default", "T-Pain Hard 0ms", "Travis Dark Formant", "Modern Pop Vocal",
                                         "Natural Silk", "Classic AT5 Cher", "Soprano Air", "Low Male Sub",
                                         "Hyperpop +12", "Rich Vibrato", "Parallel 50% Mix", "Ratio-Locked Shift", "Live Smooth" };
    juce::PopupMenu menu;
    for (int i = 0; i < 13; ++i) menu.addItem (i + 1, names[i], true, i == currentPreset);
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&content->presetField),
                        [safe = juce::Component::SafePointer<TAutoTuneEditor> (this)] (int r) { if (safe != nullptr && r > 0) safe->applyPreset (r - 1); });
}

void TAutoTuneEditor::showRangeMenu()
{
    juce::PopupMenu menu;
    const auto names = TAutoTuneProcessor::getInputTypeNames();
    const int current = (int) getParam (TAutoTuneParams::kInputType);
    for (int i = 0; i < names.size(); ++i) menu.addItem (i + 1, names[i], true, i == current);
    menu.addSeparator();
    menu.addItem (50, vn ("Tự nhận giọng (Learn)..."));
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&content->rangeField),
                        [safe = juce::Component::SafePointer<TAutoTuneEditor> (this)] (int r)
                        {
                            if (safe == nullptr || r == 0) return;
                            if (r == 50) safe->processorRef.startInputTypeLearn();
                            else safe->setParam (TAutoTuneParams::kInputType, (float) (r - 1));
                        });
}

void TAutoTuneEditor::showKeyMenu()
{
    const auto scaleNames = TAutoTuneProcessor::getScaleNames();
    const int key = (int) getParam (TAutoTuneParams::kKey), scale = (int) getParam (TAutoTuneParams::kScale);
    const auto keyNames = TAutoTuneProcessor::getKeyNamesForScale (scale);
    juce::PopupMenu keys, scales, menu;
    for (int i = 0; i < 12; ++i) keys.addItem (100 + i, keyNames[i], true, i == key);
    for (int i = 0; i < scaleNames.size(); ++i) scales.addItem (200 + i, scaleNames[i], true, i == scale);
    menu.addSectionHeader (vn ("TÔNG"));
    menu.addSubMenu ("Key: " + keyNames[juce::jlimit (0, 11, key)], keys);
    menu.addSubMenu ("Scale: " + scaleNames[juce::jlimit (0, scaleNames.size() - 1, scale)], scales);
    menu.addSeparator();
    menu.addItem (301, vn ("Tự nhận tông từ T-AutoKey"), true, processorRef.isAutoKeySyncEnabled());
    menu.addItem (300, vn ("Nghe và dò tông (Auto Key)"));
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&content->keyField),
                        [safe = juce::Component::SafePointer<TAutoTuneEditor> (this)] (int r)
                        {
                            if (safe == nullptr || r == 0) return;
                            auto& p = safe->processorRef;
                            if (r >= 100 && r < 112) { safe->setParam (TAutoTuneParams::kKey, (float) (r - 100)); p.markKeyChangedByUser(); }
                            else if (r >= 200 && r < 300) { safe->setParam (TAutoTuneParams::kScale, (float) (r - 200)); p.markKeyChangedByUser(); }
                            else if (r == 300) p.startAutoKeyDetect();
                            else if (r == 301) p.setAutoKeySyncEnabled (! p.isAutoKeySyncEnabled());
                            safe->refreshHeader();
                        });
}

void TAutoTuneEditor::showSettingsMenu()
{
    juce::PopupMenu menu;
    menu.addItem (1, vn ("Bản quyền & Kích hoạt..."));
    menu.addItem (2, vn ("Tự nhận tông từ T-AutoKey"), true, processorRef.isAutoKeySyncEnabled());
    menu.addSeparator();
    menu.addItem (3, juce::String::fromUTF8 (tak::product::autoTuneName) + " " + tak::product::version + " · " + juce::String::fromUTF8 (tak::product::name), false, false);
    menu.showMenuAsync (juce::PopupMenu::Options().withTargetComponent (&content->gear),
                        [safe = juce::Component::SafePointer<TAutoTuneEditor> (this)] (int r)
                        {
                            if (safe == nullptr) return;
                            if (r == 1) safe->showLicensePanel();
                            else if (r == 2) safe->processorRef.setAutoKeySyncEnabled (! safe->processorRef.isAutoKeySyncEnabled());
                        });
}

void TAutoTuneEditor::showLicensePanel()
{
    struct Overlay final : juce::Component
    {
        void paint (juce::Graphics& g) override { g.fillAll (juce::Colours::black.withAlpha (0.62f)); }
    };
    auto safe = juce::Component::SafePointer<TAutoTuneEditor> (this);
    licenseOverlay = std::make_unique<Overlay>();
    licensePanel = std::make_unique<TLicensePanel> (
        [safe] { return safe ? safe->processorRef.getLicenseSnapshot() : tak::license::Snapshot {}; },
        [safe] (const juce::String& text) { if (safe) safe->processorRef.activateLicense (text); },
        [safe] { if (safe) safe->processorRef.startLicenseTrial(); },
        [safe] { juce::MessageManager::callAsync ([safe] { if (safe) { safe->licensePanel.reset(); safe->licenseOverlay.reset(); } }); });
    licenseOverlay->addAndMakeVisible (*licensePanel);
    licensePanel->setBounds (118, 100, 884, 520);
    addAndMakeVisible (*licenseOverlay);
    resized();
}
