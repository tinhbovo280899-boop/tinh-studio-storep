#pragma once
#include "TAutoTuneProcessor.h"
#include "licensing/LicensePanel.h"
#include <functional>
#include <memory>

// T-AutoTune editor: gold/black T Studio look, everything drawn in code
// (no bitmap skins). Design canvas is 1120 x 720 and scales with the window.
namespace tui
{
    struct Fonts
    {
        static juce::Font semi (float h);
        static juce::Font bold (float h);
        static juce::Font heavy (float h);
        static juce::Font label (float h = 10.5f);   // tracked uppercase labels
    };

    class GoldLookAndFeel final : public juce::LookAndFeel_V4
    {
    public:
        GoldLookAndFeel();
        void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                               float startAngle, float endAngle, juce::Slider&) override;
        void drawPopupMenuBackground (juce::Graphics&, int width, int height) override;
        juce::Font getPopupMenuFont() override;
        juce::Typeface::Ptr getTypefaceForFont (const juce::Font&) override;
    };

    // Rotary knob with its label/value drawn in one of three layouts.
    class Knob final : public juce::Component
    {
    public:
        enum class Style { Hero, Header, Side, Below };
        Knob (juce::AudioProcessorValueTreeState&, const juce::String& paramId, const juce::String& label,
              Style, juce::Colour arc, std::function<juce::String (double)> format);
        void paint (juce::Graphics&) override;
        void resized() override;
        void setKnobEnabled (bool);
        juce::Slider& getSlider() noexcept { return slider; }
        juce::String valueText() const { return format (slider.getValue()); }
    private:
        juce::Slider slider;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
        juce::String label;
        Style style;
        std::function<juce::String (double)> format;
        bool enabled = true;
    };

    // Pill-shaped segmented control, optionally bound to a parameter.
    class Segmented final : public juce::Component
    {
    public:
        explicit Segmented (juce::StringArray options, float fontSize = 13.0f);
        void bind (juce::RangedAudioParameter&, std::function<int (float)> toIndex, std::function<float (int)> toValue);
        std::function<void (int)> onSelect;
        void setSelected (int) noexcept;
        int  getSelected() const noexcept { return selected; }
        void paint (juce::Graphics&) override;
        void mouseUp (const juce::MouseEvent&) override;
    private:
        juce::StringArray options;
        float fontSize;
        int selected = -1;
        std::unique_ptr<juce::ParameterAttachment> attachment;
        std::function<float (int)> indexToValue;
    };

    class Switch final : public juce::Component
    {
    public:
        explicit Switch (juce::RangedAudioParameter&);
        void paint (juce::Graphics&) override;
        void mouseUp (const juce::MouseEvent&) override;
    private:
        bool on = false;
        juce::ParameterAttachment attachment;
    };

    // Header dropdown field (caption + value + chevron).
    class Field final : public juce::Component
    {
    public:
        Field (juce::String caption);
        std::function<void()> onClick, onPrev, onNext;
        void setValue (const juce::String&);
        void setChip (const juce::String& text) { if (chip != text) { chip = text; repaint(); } }
        void setProgress (float p) { if (std::abs (p - progress) > 0.001f) { progress = p; repaint(); } }
        void setHighlighted (bool h) { if (h != highlighted) { highlighted = h; repaint(); } }
        bool arrows = false;
        void paint (juce::Graphics&) override;
        void mouseUp (const juce::MouseEvent&) override;
    private:
        juce::String caption, value, chip;
        float progress = -1.0f;
        bool highlighted = false;
    };

    class RoundButton final : public juce::Component
    {
    public:
        enum class Icon { Gear, Power };
        explicit RoundButton (Icon);
        std::function<void()> onClick;
        void setLit (bool l) { if (l != lit) { lit = l; repaint(); } }
        void paint (juce::Graphics&) override;
        void mouseUp (const juce::MouseEvent&) override;
    private:
        Icon icon;
        bool lit = false;
    };

    class TextChip final : public juce::Component
    {
    public:
        TextChip (juce::String t, std::function<void()> click) : text (std::move (t)), onClick (std::move (click)) {}
        std::function<void()> onClick;
        void setText (const juce::String& t) { if (t != text) { text = t; repaint(); } }
        void setActive (bool a) { if (a != active) { active = a; repaint(); } }
        void paint (juce::Graphics&) override;
        void mouseUp (const juce::MouseEvent&) override { if (onClick) onClick(); }
    private:
        juce::String text;
        bool active = false;
    };
}

//==============================================================================
class TPitchView final : public juce::Component
{
public:
    explicit TPitchView (TAutoTuneProcessor&);
    static constexpr float tunerCx = 372.0f, tunerCy = 262.0f;   // arc centre
    void tick();                      // called by the editor timer (30 Hz)
    void paint (juce::Graphics&) override;
    void mouseUp (const juce::MouseEvent&) override;
private:
    // Two views: the gold tuner (arc + note strip, default) and the scrolling pitch graph.
    bool tunerMode() const;
    void setTunerMode (bool);
    void paintGraph (juce::Graphics&);
    void paintTuner (juce::Graphics&);
    void paintViewChips (juce::Graphics&, bool tuner);
    juce::Image& tunerLayer (float scale);   // everything static in the tuner, rendered once
    TAutoTuneProcessor& processor;
    static constexpr int historySize = 300;
    std::array<float, historySize> input {}, output {};
    int write = 0;
    float centre = 57.0f;             // smoothed vertical centre (MIDI)
    float shownTarget = -1.0f, shownCents = 0.0f, shownHz = 0.0f;
    float shownDetected = -1.0f;      // live pitch for the sliding strip marker
    int silentTicks = 1000;           // ticks since the voice stopped (keeps the note briefly, then "listening")
    float pulse = 0.0f;               // listening animation phase
    int stripLow = 48;                // first MIDI note of the 2-octave strip (follows the singer)
    bool voiced = false;
    juce::Image layer, glow;
    juce::String layerKey, shownSignature;
};

class TScaleKeys final : public juce::Component
{
public:
    explicit TScaleKeys (TAutoTuneProcessor&);
    void paint (juce::Graphics&) override;
    void mouseUp (const juce::MouseEvent&) override;
    void tick();
private:
    int hitTest (juce::Point<float>) const;
    juce::Rectangle<float> keyRect (int pitchClass) const;
    TAutoTuneProcessor& processor;
    int sung = -1;
    std::array<int, 12> lastStates {};
    int lastKey = -1;
};

//==============================================================================
class TAutoTuneEditor final : public juce::AudioProcessorEditor,
                              private juce::Timer
{
public:
    explicit TAutoTuneEditor (TAutoTuneProcessor&);
    ~TAutoTuneEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

    static constexpr int designW = 1120, designH = 720;

private:
    class Content;
    void timerCallback() override;
    void applyPreset (int index);
    void showKeyMenu();
    void showRangeMenu();
    void showPresetMenu();
    void showSettingsMenu();
    void showLicensePanel();
    void refreshHeader();
    void setBottomTab (int tab);
    void updateEnablement();
    void setParam (const char* id, float plainValue);
    float getParam (const char* id) const;

    TAutoTuneProcessor& processorRef;
    tui::GoldLookAndFeel lookAndFeel;
    std::unique_ptr<Content> content;
    std::unique_ptr<juce::Component> licenseOverlay;
    std::unique_ptr<TLicensePanel> licensePanel;
    int currentPreset = 12; // Live Smooth for a fresh instance; restored states keep their parameters.
    int bottomTab = 0;   // 0 = scale notes, 1 = vibrato

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TAutoTuneEditor)
};
