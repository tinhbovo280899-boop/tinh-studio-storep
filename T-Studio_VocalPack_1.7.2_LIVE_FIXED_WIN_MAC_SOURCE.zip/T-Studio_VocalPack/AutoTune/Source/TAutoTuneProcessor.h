#pragma once

#if __has_include(<JuceHeader.h>)
 #include <JuceHeader.h>
#else
 #include <juce_audio_basics/juce_audio_basics.h>
 #include <juce_audio_processors/juce_audio_processors.h>
 #include <juce_dsp/juce_dsp.h>
 #include <juce_gui_basics/juce_gui_basics.h>
 #include <juce_gui_extra/juce_gui_extra.h>
 #include <juce_cryptography/juce_cryptography.h>
#endif
#include <array>
#include <atomic>
#include <cmath>
#include <vector>
#include "AutoKeyHandoffReader.h"
#include "licensing/PluginLicense.h"

namespace TAutoTuneParams
{
    static constexpr const char* kInputType       = "input_type";       // Tag 10: 0=Soprano, 1=Alto/Tenor, 2=Low Male, 3=Instrument, 4=Bass Inst
    static constexpr const char* kKey             = "key";              // Tag 2:  0=C .. 11=B
    static constexpr const char* kScale           = "scale";            // Tag 1:  0=Major, 1=Minor, 2=Chromatic, ... (29 scales)
    static constexpr const char* kClassicMode     = "classic_mode";
    static constexpr const char* kUseFormants     = "use_formants";     // Tag 70: bool
    static constexpr const char* kThroatLength    = "throat_length";
    static constexpr const char* kTranspose       = "transpose";        // Tag 74: -12..+12 semitones (default 0)
    static constexpr const char* kDetune          = "detune";           // Tag 3:  -100..+100 cents (default 0 = 440.0 Hz)
    static constexpr const char* kTracking        = "tracking";         // Tag 9:  1..100 % (default 50)
    static constexpr const char* kMix             = "mix";
    static constexpr const char* kRatioLock       = "ratio_lock";
    static constexpr const char* kMasterBypass    = "master_bypass";    // Header Master Bypass

    static constexpr const char* kRetuneSpeed     = "retune_speed";     // Tag 4:  0..400 ms (default 20)
    static constexpr const char* kFlexTune        = "flex_tune";        // Tag 90: 0..100 (default 0)
    static constexpr const char* kNaturalVibrato  = "natural_vibrato";  // Tag 62: -12..+12 dB (default 0.0)
    static constexpr const char* kHumanize        = "humanize";         // Tag 61: 0..100 (default 0)

    static constexpr const char* kAdvancedView    = "advanced_view";    // Tag 33: bool
    static constexpr const char* kIgnoreVibrato   = "ignore_vibrato";   // Tag 44: bool

    static constexpr const char* kVibratoShape    = "vib_shape";        // Tag 5:  0=No Vibrato, 1=Sine Wave, 2=Square, 3=Sawtooth
    static constexpr const char* kVibratoRate     = "vib_rate";         // Tag 7:  0.1..10.0 Hz (default 5.5)
    static constexpr const char* kVibratoDelay    = "vib_delay";        // Tag 46: 0..1500 ms (default 500)
    static constexpr const char* kVibratoTrans    = "vib_transition";   // Tag 50: 0..1500 ms (default 500 = Onset Rate)
    static constexpr const char* kVibratoVar      = "vib_variation";    // Tag 49: 0..100 (default 30)
    static constexpr const char* kVibratoPitch    = "vib_pitch";        // Tag 6:  0..100 cents (default 0)
    static constexpr const char* kVibratoAmp      = "vib_amplitude";    // Tag 47: 0..100 (default 30)
    static constexpr const char* kVibratoFormant  = "vib_formant";      // Tag 48: 0..100 (default 70)
}

//==============================================================================
//   - Downsample_DSP: 6-stage biquad multi-rate front-end
//   - AT_DSPObject:
//       * Input Voice Type Band-Limiting Biquads + 30 Hz HPF
//       * 3-Stage Pitch Detector (immune to 2nd-harmonic / loud-singing octave jumps):
//           1) 8:1 Decimated Coarse Pitch Acquisition with 3-minima period-consistency check
//           2) Full-Rate Narrow Tracking Window Initializer [baseLag .. baseLag + 2*W - 1]
//           3) Locked Full-Rate Running Autocorrelation minimizing D(k) = 0.5*energy[k] - corr[k]
//              with +/-1 lag window sliding & parabolic sub-sample refinement
//       * Kelly-Lochbaum Vocal Tract Tube + Levinson-Durbin LPC Formant & Throat Modeling
//         with sample-by-sample LPC coefficient interpolation + Formant-Transpose Ratio Lock
//       * Continuous Upward-Shift Anti-Aliasing Biquads
//       * Relative-Offset Directional Phase-Locked TD-PSOLA Resynthesis
//==============================================================================
class TAutoTuneChannelDSP
{
public:
    static constexpr int kMaxLPCOrder  = 16;
    static constexpr int kRingSize     = 8192;
    static constexpr int kRingMask     = kRingSize - 1;
    static constexpr int kDecRingSize  = 512;
    static constexpr int kDecRingMask  = kDecRingSize - 1;
    static constexpr int kMaxDecLag    = 250;
    static constexpr int kMaxTrackWin  = 64;

    struct BiquadDF2
    {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
        double z1 = 0.0, z2 = 0.0;

        void reset() noexcept { z1 = z2 = 0.0; }

        void setLowpass(double fc, double sr, double q = 0.7071067811865475) noexcept
        {
            const double w0 = 2.0 * 3.14159265358979323846 * std::clamp(fc, 10.0, 0.49 * sr) / sr;
            const double cs = std::cos(w0);
            const double alpha = std::sin(w0) / (2.0 * q);
            const double norm = 1.0 / (1.0 + alpha);
            b0 = (0.5 * (1.0 - cs)) * norm;
            b1 = (1.0 - cs) * norm;
            b2 = b0;
            a1 = (-2.0 * cs) * norm;
            a2 = (1.0 - alpha) * norm;
        }

        void setHighpass(double fc, double sr, double q = 0.7071067811865475) noexcept
        {
            const double w0 = 2.0 * 3.14159265358979323846 * std::clamp(fc, 10.0, 0.49 * sr) / sr;
            const double cs = std::cos(w0);
            const double alpha = std::sin(w0) / (2.0 * q);
            const double norm = 1.0 / (1.0 + alpha);
            b0 = (0.5 * (1.0 + cs)) * norm;
            b1 = -(1.0 + cs) * norm;
            b2 = b0;
            a1 = (-2.0 * cs) * norm;
            a2 = (1.0 - alpha) * norm;
        }

        inline double process(double x) noexcept
        {
            const double w = x - a1 * z1 - a2 * z2;
            const double y = b0 * w + b1 * z1 + b2 * z2;
            z2 = z1;
            z1 = w;
            return y;
        }
    };

    void prepare(double newSampleRate);
    void reset();
    void updateVoiceTypeFilters(int voiceType);
    // Fixed neutral-path delay. Pitch-period splicing can use older samples;
    // this is the host compensation reference, not a zero-latency claim.
    static int liveLatencySamples(double sr) noexcept
    {
        return std::max(24, static_cast<int>(std::lround(std::max(8000.0, sr) * 0.002)));
    }

    float processSample(float inputSample,
                        int voiceType,
                        int keyIdx,
                        int scaleIdx,
                        const std::array<int, 12>& noteStates,
                        const std::array<int, 12>& noteCents,
                        bool classicMode,
                        bool useFormants,
                        double throatLengthPct,
                        bool ratioLock,
                        double transposeSemi,
                        double detuneCents,
                        double trackingVal,
                        double retuneSpeedMs,
                        double flexTuneVal,
                        double naturalVibDb,
                        double humanizeVal,
                        bool ignoreVibrato,
                        int vibShape,
                        double vibRateHz,
                        double vibDelayMs,
                        double vibTransMs,
                        double vibVarVal,
                        double vibPitchCents,
                        double vibAmpVal,
                        double vibFormantVal,
                        double wetDryMixPct,
                        int frozenMidiNote = -1,
                        bool bypass = false);

    float getDetectedMidiNote() const noexcept { return lastDetectedMidi; }
    float getTargetMidiNote()   const noexcept { return lastTargetMidi; }
    float getCentsCorrection()  const noexcept { return lastCentsCorrection; }
    bool  isCurrentlyVoiced()   const noexcept { return voicedState; }

private:
    int    acquireCoarsePeriod8x(double xFiltered, double trackingThreshold) noexcept;
    bool   initTrackingWindow(int newBaseLag) noexcept;
    double refineAndSlideTrackingWindow(int& bestIdx) noexcept;

    void   analyzeLPCAndThroat(double pitchPeriodSamples, double effectiveThroatRatio) noexcept;
    double inverseFilterLPC(double x, double alpha) noexcept;
    double synthesizeThroatLPC(double excitation, double alpha) noexcept;

    double readCubicHermite(const std::array<double, kRingSize>& buf, double readPos) const noexcept;
    double findBestSpliceDelay(const std::array<double, kRingSize>& buf,
                               double currentDelay,
                               double nominalTargetDelay,
                               double T0Full) const noexcept;

    double sampleRate = 48000.0;
    double analysisRate = 48000.0;
    int downsampleFactor = 1;
    int downsampleCounter = 0;

    std::array<BiquadDF2, 6> downsampleFilters;
    BiquadDF2 inputLP1, inputLP2, inputHP1;
    int currentVoiceType = -1;
    int trackHalfWin = 15;
    double minPeriodSamples = 32.0;
    double maxPeriodSamples = 1200.0;

    BiquadDF2 shiftLP1, shiftLP2;

    std::array<double, kRingSize> detectorRing {};
    int detWriteIdx = 0;

    std::array<double, kDecRingSize> decRing {};
    std::array<double, kMaxDecLag> decEnergy {};
    std::array<double, kMaxDecLag> decCorr {};
    int decWriteIdx = 0;
    int decSampleCount = 0;

    std::array<double, kMaxTrackWin> trackEnergy {};
    std::array<double, kMaxTrackWin> trackCorr {};
    int baseLag = 100;
    bool needAcquisition = true;

    int updateSubCounter = 0;
    double currentPeriodSamples = 200.0;
    double smoothedPeriodSamples = 200.0;
    double fastPitchMidi = 60.0;
    double slowPitchMidi = 60.0;
    bool voicedState = false;

    int lockedTargetNote = -1;
    int sustainedNoteFrames = 0;
    double smoothedPitchRatio = 1.0;
    double voicedBlend = 0.0;
    double resampleRatio = 1.0;
    double voiceSmoothCoeff = 0.0;
    double ratioSmoothCoeff = 0.0;
    double formantSmoothCoeff = 0.0;
    double nominalDelaySamples = 96.0;
    int quietSamples = 0;
    double correctedPitchCenter = 60.0, naturalVibratoOffset = 0.0;
    double naturalVibratoRatio = 1.0;
    double fastPitchCoeff = 0.0, slowPitchCoeff = 0.0;
    bool correctedPitchInitialised = false;

    double vibPhase = 0.0;
    double vibNoteOnsetSec = 0.0;
    uint32_t rngState = 0x12345678u;
    double targetVibAmpGain = 1.0, smoothedVibAmpGain = 1.0;
    double targetVibFormantRatio = 1.0, smoothedVibFormantRatio = 1.0;

    int lpcOrder = 12;
    int lpcSampleCounter = 0;
    static constexpr int kLPCFrameHop = 64;
    double preEmphasisPole = 0.96;
    double preEmpZ1 = 0.0;
    double deEmpZ1 = 0.0;
    std::array<double, 512> lpcAnalysisWin {};
    int lpcWinWriteIdx = 0;
    std::array<double, kMaxLPCOrder + 1> prevLpcA {};
    std::array<double, kMaxLPCOrder + 1> currLpcA {};
    std::array<double, kMaxLPCOrder + 1> prevLpcWarpedA {};
    std::array<double, kMaxLPCOrder + 1> currLpcWarpedA {};
    std::array<double, kMaxLPCOrder + 1> invFilterHist {};
    std::array<double, kMaxLPCOrder + 1> synFilterHist {};

    std::array<double, kRingSize> rawInputRing {};
    std::array<double, kRingSize> shiftedInputRing {};
    std::array<double, kRingSize> residualRing {};
    int psolaWriteIdx = 0;
    double relDelayA = 256.0;
    double relDelayB = 256.0;
    double crossfadeAlpha = 1.0;
    double crossfadeStep = 0.0;

    double smoothedWetMix = 1.0;
    double smoothedFormantMix = 0.0;
    double smoothedBypassMix = 0.0;
    double formantReferenceEnvelope = 0.0;
    int formantRecoverySamples = 0;

    float lastDetectedMidi = -1.0f;
    float lastTargetMidi = -1.0f;
    float lastCentsCorrection = 0.0f;
};

//==============================================================================
class TAutoTuneProcessor final : public juce::AudioProcessor,
                                 private juce::Timer
{
public:
    TAutoTuneProcessor();
    ~TAutoTuneProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Default"; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    bool syncFromAutoKeyHandoff(bool forceReload = false);
    void syncScaleToNotesIfNeeded() noexcept;

    enum NoteState { kNoteActive = 0, kNoteBypassed = 1, kNoteRemoved = 2 };

    int  getNoteState(int pitchClass12) const noexcept;
    void setNoteState(int pitchClass12, int state) noexcept;
    void cycleNoteState(int pitchClass12, bool editBypassMode) noexcept;
    int  getNoteCents(int pitchClass12) const noexcept;
    void setNoteCents(int pitchClass12, int cents) noexcept;
    void resetAllNoteCents() noexcept;

    void applyScalePresetToNotes(int keyIdx, int scaleIdx) noexcept;
    void setMajorNotes() noexcept;
    void setMinorNotes() noexcept;
    void setAllNotesActive() noexcept;
    void setAllNotesBypassed() noexcept;
    void setAllNotesRemoved() noexcept;

    float getDetectedMidiNote() const noexcept { return detectedMidiAtom.load(std::memory_order_relaxed); }
    float getTargetMidiNote()   const noexcept { return targetMidiAtom.load(std::memory_order_relaxed); }
    float getCentsCorrection()  const noexcept { return centsCorrectionAtom.load(std::memory_order_relaxed); }
    bool  isVoiced()            const noexcept { return voicedAtom.load(std::memory_order_relaxed); }
    void  setHoldMeter(bool hold) noexcept;
    bool  getHoldMeter() const noexcept        { return holdMeterAtom.load(std::memory_order_relaxed); }

    void  startInputTypeLearn() noexcept;
    bool  isLearningInputType() const noexcept { return learningInputTypeAtom.load(std::memory_order_relaxed); }
    float getLearnProgress() const noexcept    { return learnProgressAtom.load(std::memory_order_relaxed); }

    // Auto-Key Chroma Detector ("Auto Key" button)
    void  startAutoKeyDetect() noexcept;
    bool  isDetectingAutoKey() const noexcept  { return detectingAutoKeyAtom.load(std::memory_order_relaxed); }
    float getAutoKeyProgress() const noexcept  { return autoKeyProgressAtom.load(std::memory_order_relaxed); }

    void  triggerAuditionNote(int midiNote) noexcept;
    void  stopAuditionNote() noexcept;
    int   getAuditionMidiNote() const noexcept { return auditionMidiNoteAtom.load(std::memory_order_relaxed); }

    // Pack license (shared with T-AutoKey). Audio passes through untouched
    // while the plugin is not activated or the trial has ended.
    tak::license::Snapshot getLicenseSnapshot() const { return licensing.snapshot(); }
    void activateLicense(const juce::String& text);
    void startLicenseTrial();
    bool hasLicenseAccess() const noexcept { return licensing.isAllowed(); }
    void ensureAutomaticTrialRequested() noexcept;

    // T-AutoKey link: when enabled, key/scale follow the Auto-Key handoff file.
    void setAutoKeySyncEnabled(bool enabled) noexcept;
    bool isAutoKeySyncEnabled() const noexcept { return autoKeySyncAtom.load(std::memory_order_relaxed); }
    bool isKeyFromAutoKey() const noexcept     { return keyFromAutoKeyAtom.load(std::memory_order_relaxed); }
    void markKeyChangedByUser() noexcept       { keyFromAutoKeyAtom.store(false, std::memory_order_relaxed); }

    static juce::StringArray getScaleNames();
    static juce::StringArray getKeyNames();
    // Key names as musicians read them: minor-type scales use C# / G#, major-type scales Db / Ab
    // (Eb and Bb in both). Display only: the stored key index is unchanged.
    static bool isMinorFamilyScale (int scaleIdx) noexcept;
    static juce::StringArray getKeyNamesForScale (int scaleIdx);
    // Note name spelled for the current key (flat keys show Db/Eb/Gb/Ab/Bb, sharp keys C#/D#/F#/G#/A#).
    static juce::String noteNameInKey (int pitchClass, int keyIdx, int scaleIdx);
    static juce::StringArray getInputTypeNames();
    static juce::StringArray getVibratoShapeNames();

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

private:
    juce::AudioProcessorValueTreeState apvts;
    bool hostBypassActive = false; // Used only within the audio callback.
    void timerCallback() override;

    // One shared license worker per plugin file (see PluginLicense.h): no
    // per-instance thread that has to be stopped (or killed) on removal.
    tak::license::PluginLicense licensing;
    // Handoff key sync requested from the constructor / host calls; applied by
    // the message-thread timer so no host notification happens inside the
    // host's own constructor, prepareToPlay or setState call.
    std::atomic<int> pendingHandoffSync { 2 };
    std::atomic<bool> autoKeySyncAtom { true }, keyFromAutoKeyAtom { false };
    void initAutoKeySearchPaths();
    AutoKeyHandoffReader autoKeyHandoffReader;

    std::array<TAutoTuneChannelDSP, 2> channelDSP;
    std::array<std::atomic<int>, 12> noteStatesAtom;
    std::array<std::atomic<int>, 12> noteCentsAtom;
    int lastScaleIdx = -1;
    int lastKeyIdx   = -1;

    std::atomic<float> detectedMidiAtom    { -1.0f };
    std::atomic<float> targetMidiAtom      { -1.0f };
    std::atomic<float> centsCorrectionAtom { 0.0f };
    std::atomic<bool>  voicedAtom          { false };
    std::atomic<bool>  holdMeterAtom       { false };
    std::atomic<int>   frozenMidiNoteAtom  { -1 };

    // PitchStatisticsAnalyzer ("Learn..." Input Type) state
    std::atomic<bool>  learningInputTypeAtom { false };
    std::atomic<float> learnProgressAtom     { 0.0f };
    int   learnSamplesAccum = 0;
    int   learnTargetSamples = 144000;
    double learnPitchMidiSum = 0.0;
    double learnHighFreqEnergySum = 0.0;
    double learnTotalEnergySum = 0.0;
    int   learnVoicedCount = 0;

    // Auto-Key Chroma Detector state
    std::atomic<bool>  detectingAutoKeyAtom { false };
    std::atomic<float> autoKeyProgressAtom  { 0.0f };
    int   autoKeySamplesAccum = 0;
    std::array<double, 12> autoKeyChromaHist {};

    std::atomic<int>   auditionMidiNoteAtom { -1 };
    double auditionPhase = 0.0;
    double auditionEnv   = 0.0;
    double currentSampleRate = 48000.0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TAutoTuneProcessor)
};
