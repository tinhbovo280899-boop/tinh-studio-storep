#!/bin/bash
export PATH="/opt/homebrew/bin:/usr/local/bin:/Applications/CMake.app/Contents/bin:$PATH"
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
export TH_ARCHS="arm64"
export TH_SUFFIX="ARM64"
bash "$ROOT/tools/mac.sh" Build
TAK_RC=$?
if [[ -t 0 ]]; then printf "\nPress Return to close..."; read -r _tak_close; fi
exit "$TAK_RC"
