#pragma once

namespace AppBranding
{
    static constexpr const char* kAppDisplayName  = "Liquid Delays II";
    static constexpr const char* kBrandWord1      = "LIQUID";
    static constexpr const char* kBrandWord2      = "DELAYS II";
    static constexpr const char* kBrandSubtitle   = "NOMAD FACTORY RETRO TUBE DELAY";
    static constexpr const char* kSplashLine2     = "NOMAD FACTORY / NT STUDIO";
    static constexpr const char* kPublisher       = "Nomad Factory";
    static constexpr const char* kAppVersion      = "2.7.0";
    static constexpr const char* kExeName         = "Liquid Delays II.exe";
    static constexpr const char* kSetupName       = "Setup_Liquid_Delays_II";
    static constexpr const char* kLicenseBrand    = "LIQUIDDELAYS";
    static constexpr int         kTrialDays       = 7;
    static constexpr const char* kContactPhone    = "0329575243";
    static constexpr const char* kContactNote     = "Goi / Zalo de mua ban quyen, gia han hoac ho tro ky thuat.";
    static constexpr const char* kAppDataDirName  = "LiquidDelaysII";
}
