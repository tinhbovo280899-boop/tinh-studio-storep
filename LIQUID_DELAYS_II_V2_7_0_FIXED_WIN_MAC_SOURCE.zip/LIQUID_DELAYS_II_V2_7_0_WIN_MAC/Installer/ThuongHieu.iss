#define MyAppName "Liquid Delays II"
#define MyAppVersion "2.7.0"
#define MyAppPublisher "Nomad Factory"
#define MyAppExeName "Liquid Delays II.exe"
#define MySetupName "Setup_Liquid_Delays_II"
#define MyAppId "{{8A2F7B31-49C2-4D19-9A67-51B83E2F1041}"

#define MyVst3Name "Liquid Delays II"
