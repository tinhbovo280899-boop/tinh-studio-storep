#include "PluginEditor.h"
#include "params/ParameterIds.h"

namespace
{
    juce::String fmtDbTp (double v) { return juce::String (v, 1) + " dBTP"; }
    juce::String fmtLufs (float v)  { return v <= -99.0f ? juce::String::fromUTF8 ("\xe2\x80\x94") : juce::String (v, 1); }
}

//==============================================================================
void TLimiterHistory::tick()
{
    gr[(size_t) pos]  = std::abs (proc.getGainReductionDb());
    in[(size_t) pos]  = proc.getInputLevelDb();
    out[(size_t) pos] = proc.getOutputLevelDb();
    pos = (pos + 1) % N;
    repaint();
}

void TLimiterHistory::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (ntc::well); g.fillRoundedRectangle (r, 8.0f);
    auto plot = r.reduced (10.0f, 8.0f).withTrimmedLeft (24.0f).withTrimmedTop (16.0f);
    // level grid: 0 .. -36 dB
    g.setFont (ntc::font (ntc::W::Regular, 10.5f));
    for (int d = 0; d >= -36; d -= 6)
    {
        const float y = juce::jmap ((float) d, -36.0f, 0.0f, plot.getBottom(), plot.getY());
        g.setColour (ntc::line); g.drawHorizontalLine ((int) y, plot.getX(), plot.getRight());
        g.setColour (ntc::dim); g.drawText (juce::String (d), juce::Rectangle<float> (r.getX() + 2, y - 6, 28, 12), juce::Justification::centredRight);
    }
    auto xAt = [&] (int i) { return plot.getX() + plot.getWidth() * (float) i / (float) (N - 1); };
    auto yLvl = [&] (float db) { return juce::jmap (juce::jlimit (-36.0f, 0.0f, db), -36.0f, 0.0f, plot.getBottom(), plot.getY()); };
    juce::Path pin, pout, pgr;
    for (int i = 0; i < N; ++i)
    {
        const int k = (pos + i) % N;
        const float x = xAt (i);
        if (i == 0) { pin.startNewSubPath (x, plot.getBottom()); pgr.startNewSubPath (x, plot.getY()); }
        pin.lineTo (x, yLvl (in[(size_t) k]));
        if (i == 0) pout.startNewSubPath (x, yLvl (out[(size_t) k])); else pout.lineTo (x, yLvl (out[(size_t) k]));
        pgr.lineTo (x, plot.getY() + plot.getHeight() * juce::jlimit (0.0f, 1.0f, gr[(size_t) k] / 24.0f));   // GR drawn from the top, 0..24 dB
    }
    pin.lineTo (plot.getRight(), plot.getBottom()); pin.closeSubPath();
    pgr.lineTo (plot.getRight(), plot.getY()); pgr.closeSubPath();
    g.setColour (ntc::inCol.withAlpha (0.30f)); g.fillPath (pin);
    g.setColour (ntc::gold); g.strokePath (pout, juce::PathStrokeType (1.6f));
    g.setColour (ntc::coral.withAlpha (0.55f)); g.fillPath (pgr);
    g.setColour (ntc::coral); g.strokePath (pgr, juce::PathStrokeType (1.2f));
    // legend
    auto lg = juce::Rectangle<float> (r.getRight() - 330, r.getY() + 8, 320, 14);
    auto item = [&] (juce::Colour c, const juce::String& t, float x) {
        g.setColour (c); g.fillRoundedRectangle (lg.getX() + x, lg.getCentreY() - 2, 14, 4, 2);
        ntc::caps (g, t, { lg.getX() + x + 18, lg.getY(), 100, 14 }, ntc::text2, juce::Justification::centredLeft, 10.0f); };
    item (ntc::inCol, "Input", 0); item (ntc::gold, "Output", 96); item (ntc::coral, "Reduction", 196);
}

//==============================================================================
TLimiterReadout::TLimiterReadout (ApotheosisAudioProcessor& p) : proc (p)
{
    resetHolds.getProperties().set ("fontSize", 10.5);
    resetHolds.onClick = [this] { proc.resetTruePeakMaxHold(); proc.resetMaxGainReduction(); };
    addAndMakeVisible (resetHolds);
}

void TLimiterReadout::resized() { resetHolds.setBounds (getWidth() - 76, 8, 64, 24); }

void TLimiterReadout::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    g.setColour (ntc::well); g.fillRoundedRectangle (r, 8.0f);
    // big gain-reduction number
    ntc::caps (g, "Gain reduction", { r.getX() + 14, r.getY() + 10, 200, 14 }, ntc::dim);
    const float grDb = std::abs (proc.getGainReductionDb());
    const auto big = ntc::font (ntc::W::Bold, 40.0f);
    const juce::String grText = (grDb > 0.05f ? "-" : "") + juce::String (grDb, 1);
    g.setColour (grDb > 0.05f ? ntc::coral : ntc::text2); g.setFont (big);
    g.drawText (grText, juce::Rectangle<float> (r.getX() + 12, r.getY() + 24, 160, 46), juce::Justification::centredLeft);
    const float tw = juce::GlyphArrangement::getStringWidth (big, grText);
    g.setFont (ntc::font (ntc::W::Medium, 14.0f)); g.setColour (ntc::dim);
    g.drawText ("dB", juce::Rectangle<float> (r.getX() + 18 + tw, r.getY() + 44, 40, 20), juce::Justification::centredLeft);
    // GR bar
    auto bar = juce::Rectangle<float> (r.getX() + 14, r.getY() + 76, r.getWidth() - 28, 8);
    g.setColour (ntc::raised); g.fillRoundedRectangle (bar, 4.0f);
    g.setColour (ntc::coral); g.fillRoundedRectangle (bar.withWidth (bar.getWidth() * juce::jlimit (0.0f, 1.0f, grDb / 24.0f)), 4.0f);

    // loudness / peak table
    struct Row { const char* name; juce::String value; juce::Colour c; };
    const Row rows[] {
        { "Short-term LUFS", fmtLufs (proc.getShortTermLufs()), ntc::gold },
        { "Momentary LUFS",  fmtLufs (proc.getMomentaryLufs()), ntc::text },
        { "Integrated LUFS", fmtLufs (proc.getIntegratedLufs()), ntc::text },
        { "Loudness range",  juce::String (proc.getLoudnessRangeLu(), 1) + " LU", ntc::text },
        { "True peak max",   proc.getTruePeakMaxHoldDb() <= -99.0f ? juce::String::fromUTF8 ("\xe2\x80\x94") : juce::String (proc.getTruePeakMaxHoldDb(), 1) + " dBTP",
                             proc.getTruePeakMaxHoldDb() > -0.05f ? ntc::coral : ntc::text },
        { "Max reduction",   juce::String (std::abs (proc.getMaxGainReductionDb()), 1) + " dB", ntc::text },
    };
    float y = r.getY() + 96;
    for (const auto& row : rows)
    {
        g.setColour (ntc::line); g.drawHorizontalLine ((int) y, r.getX() + 14, r.getRight() - 14);
        ntc::caps (g, row.name, { r.getX() + 14, y + 4, 160, 16 }, ntc::dim, juce::Justification::centredLeft, 10.0f);
        g.setColour (row.c); g.setFont (ntc::font (ntc::W::Medium, 13.0f));
        g.drawText (row.value, juce::Rectangle<float> (r.getRight() - 120, y + 3, 106, 18), juce::Justification::centredRight);
        y += 23.0f;
    }
}

//==============================================================================
ApotheosisAudioProcessorEditor::ApotheosisAudioProcessorEditor (ApotheosisAudioProcessor& p)
    : AudioProcessorEditor (&p), proc (p), history (p), readout (p),
      kInput (p.apvts, ParamIDs::inputGain, "Input", true),
      kCeiling (p.apvts, ParamIDs::ceiling, "Ceiling", true),
      kRelease (p.apvts, ParamIDs::release, "Release", false),
      kAttack (p.apvts, ParamIDs::attack, "Attack", false),
      kLookahead (p.apvts, ParamIDs::lookahead, "Lookahead", false),
      kAutoRel (p.apvts, ParamIDs::autoRelease, "Auto release", false),
      kLink (p.apvts, ParamIDs::stereoLink, "Stereo link", false),
      kClip (p.apvts, ParamIDs::clipMix, "Clip mix", false),
      style (p.apvts, ParamIDs::limitStyle, { "CLASSIC", "TRANSP.", "PUNCHY", "BUS", "SAFE" }),
      curve (p.apvts, ParamIDs::releaseCurve, { "EXP", "LINEAR", "SMOOTH" }),
      oversampling (p.apvts, ParamIDs::oversampling, { "4x", "8x", "16x" }),
      osPhase (p.apvts, ParamIDs::osPhase, { "MIN", "LINEAR" }),
      dither (p.apvts, ParamIDs::dither, { "OFF", "16-BIT", "24-BIT" }),
      ditherShape (p.apvts, ParamIDs::ditherShape, { "FLAT", "SHAPED" }),
      noiseShaping (p.apvts, ParamIDs::noiseShaping, { "LEGACY", "WEIGHTED" })
{
    setLookAndFeel (&look);
    for (auto* c : std::initializer_list<juce::Component*> { &history, &readout, &presets, &prevPreset, &nextPreset,
                                                             &kInput, &kCeiling, &kRelease, &kAttack, &kLookahead, &kAutoRel, &kLink, &kClip,
                                                             &style, &curve, &oversampling, &osPhase, &dither, &ditherShape, &noiseShaping })
        addAndMakeVisible (c);
    const juce::String restartTip = "Applied when the host prepares the plugin again (reload the instance if needed); not a live control.";
    kLookahead.slider.setTooltip (restartTip);
    oversampling.setTooltip (restartTip);
    osPhase.setTooltip (restartTip);
    kInput.format = tkit::fmtDb; kCeiling.format = fmtDbTp;
    kRelease.format = tkit::fmtMs; kAttack.format = tkit::fmtMs; kLookahead.format = tkit::fmtMs;
    kAutoRel.format = tkit::fmtPct; kLink.format = tkit::fmtPct; kClip.format = tkit::fmtPct;
    for (auto* k : { &kInput, &kCeiling, &kRelease, &kAttack, &kLookahead, &kAutoRel, &kLink, &kClip }) k->refreshText();

    auto toggle = [&] (juce::TextButton& b, const char* text, const char* id, const char* tip) {
        b.setButtonText (text); b.setClickingTogglesState (true); b.setTooltip (tip); addAndMakeVisible (b);
        batts.add (new juce::AudioProcessorValueTreeState::ButtonAttachment (p.apvts, id, b)); };
    toggle (tpGuard, "TP GUARD", ParamIDs::tpGuard, "Measured true-peak correction after down-sampling");
    toggle (delta, "DELTA", ParamIDs::deltaListen, "Listen to what the limiter removes");
    toggle (unity, "UNITY", ParamIDs::unityGainMonitor, "Trim the output by the input gain for level-matched A/B");
    delta.getProperties().set ("accent", (juce::int64) ntc::coral.getARGB());

    presets.setTextWhenNothingSelected ("Presets");
    presets.onChange = [this] {
        const auto name = presets.getText();
        if (name.isNotEmpty() && name != proc.presetManager.getCurrentPresetName()) proc.presetManager.loadPreset (name);
    };
    prevPreset.onClick = [this] { proc.presetManager.previousPreset(); };
    nextPreset.onClick = [this] { proc.presetManager.nextPreset(); };
    refreshPresetList();

    setSize (W, H);
    timerCallback();
    startTimerHz (30);
}

ApotheosisAudioProcessorEditor::~ApotheosisAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel (nullptr);
}

void ApotheosisAudioProcessorEditor::refreshPresetList()
{
    presets.clear (juce::dontSendNotification);
    int id = 1;
    juce::String lastCat;
    bool factoryHeader = false, userHeader = false;
    for (const auto& e : proc.presetManager.getAllPresets())
    {
        if (e.isFactory && ! factoryHeader) { presets.addSectionHeading ("Factory"); factoryHeader = true; }
        if (! e.isFactory && ! userHeader) { presets.addSectionHeading ("User"); userHeader = true; }
        presets.addItem (e.name, id++);
    }
    juce::ignoreUnused (lastCat);
}

void ApotheosisAudioProcessorEditor::paint (juce::Graphics& g)
{
    tkit::paintHeader (g, getLocalBounds().toFloat(), tkit::Glyph::Limiter, "Limiter", "True-peak brickwall limiter");
    ntc::cardBg (g, { 14, 56, (float) W - 28, 252 });
    ntc::cardBg (g, { 14, 318, (float) W - 28, (float) H - 332 });
    auto label = [&] (const char* t, float x, float y, float w) { ntc::caps (g, t, { x, y, w, 14 }, ntc::dim, juce::Justification::centredLeft, 10.0f); };
    label ("Style", 28, 494, 200); label ("Release curve", 440, 494, 200); label ("Oversampling", 676, 494, 160); label ("OS filter", 842, 494, 130);
    label ("Dither", 28, 566, 200); label ("Dither shape", 262, 566, 160); label ("Noise shaping", 438, 566, 160); label ("Monitor / safety", 642, 566, 200);
    g.setColour (ntc::line); g.drawHorizontalLine (484, 28, (float) W - 28);
}

void ApotheosisAudioProcessorEditor::resized()
{
    prevPreset.setBounds (548, 16, 30, 28);
    presets.setBounds (582, 16, 300, 28);
    nextPreset.setBounds (886, 16, 30, 28);
    history.setBounds (24, 66, 640, 232);
    readout.setBounds (674, 66, W - 24 - 674, 232);
    // knob row
    const int x0 = 24, top = 328;
    kInput.setBounds (x0, top, 150, 150);
    kCeiling.setBounds (x0 + 150, top, 150, 150);
    const int sw = (W - 48 - 300) / 6;
    NTKnob* small[] { &kRelease, &kAttack, &kLookahead, &kAutoRel, &kLink, &kClip };
    for (int i = 0; i < 6; ++i) small[i]->setBounds (x0 + 300 + i * sw, top + 22, sw, 120);
    // choice rows
    style.setBounds (28, 512, 396, 28);
    curve.setBounds (440, 512, 220, 28);
    oversampling.setBounds (676, 512, 150, 28);
    osPhase.setBounds (842, 512, W - 28 - 842, 28);
    dither.setBounds (28, 584, 218, 28);
    ditherShape.setBounds (262, 584, 160, 28);
    noiseShaping.setBounds (438, 584, 188, 28);
    tpGuard.setBounds (642, 584, 106, 28); delta.setBounds (756, 584, 100, 28); unity.setBounds (864, 584, W - 28 - 864, 28);
}

void ApotheosisAudioProcessorEditor::timerCallback()
{
    history.tick();
    readout.repaint();
    const auto name = proc.presetManager.getCurrentPresetName();
    const bool dirty = proc.presetManager.isDirty();
    if (name != shownPreset || dirty != shownDirty)
    {
        shownPreset = name; shownDirty = dirty;
        if (presets.getNumItems() == 0) refreshPresetList();
        int found = 0;
        for (int i = 0; i < presets.getNumItems(); ++i) if (presets.getItemText (i) == name) found = presets.getItemId (i);
        if (found > 0) presets.setSelectedId (found, juce::dontSendNotification);
        else presets.setText (name, juce::dontSendNotification);
        if (dirty && name.isNotEmpty()) presets.setText (name + " *", juce::dontSendNotification);
    }
}
