#pragma once

#include "PluginProcessor.h"
#include "TKit.h"

// T-Limiter editor (T- suite look). Replaces the original photoreal GUI; the
// processor, DSP engine, parameters and preset system are unchanged.
class TLimiterHistory : public juce::Component
{
public:
    explicit TLimiterHistory (ApotheosisAudioProcessor& p) : proc (p) { gr.fill (0.0f); in.fill (-90.0f); out.fill (-90.0f); }
    void tick();
    void paint (juce::Graphics&) override;
private:
    static constexpr int N = 240;            // 8 s at 30 Hz
    ApotheosisAudioProcessor& proc;
    std::array<float, N> gr {}, in {}, out {};
    int pos = 0;
};

class TLimiterReadout : public juce::Component
{
public:
    explicit TLimiterReadout (ApotheosisAudioProcessor& p);
    void paint (juce::Graphics&) override;
    void resized() override;
private:
    ApotheosisAudioProcessor& proc;
    juce::TextButton resetHolds { "RESET" };
};

class ApotheosisAudioProcessorEditor final : public juce::AudioProcessorEditor, private juce::Timer
{
public:
    explicit ApotheosisAudioProcessorEditor (ApotheosisAudioProcessor&);
    ~ApotheosisAudioProcessorEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void refreshPresetList();

    static constexpr int W = 1000, H = 640;
    ApotheosisAudioProcessor& proc;
    tkit::TLook look;
    TLimiterHistory history;
    TLimiterReadout readout;
    juce::ComboBox presets;
    juce::TextButton prevPreset { "<" }, nextPreset { ">" };
    NTKnob kInput, kCeiling, kRelease, kAttack, kLookahead, kAutoRel, kLink, kClip;
    tkit::ChoiceButtons style, curve, oversampling, osPhase, dither, ditherShape, noiseShaping;
    juce::TextButton tpGuard, delta, unity;
    juce::OwnedArray<juce::AudioProcessorValueTreeState::ButtonAttachment> batts;
    juce::String shownPreset;
    bool shownDirty = false;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (ApotheosisAudioProcessorEditor)
};
