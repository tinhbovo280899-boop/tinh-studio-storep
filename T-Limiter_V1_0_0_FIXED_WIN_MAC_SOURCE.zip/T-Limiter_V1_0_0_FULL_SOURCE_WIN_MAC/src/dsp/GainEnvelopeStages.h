#pragma once

#include <algorithm>
#include <cmath>
#include <vector>

// v0.4.0 + Waves L3-LL Ultra PLM/ARC envelope stages:
//   1. BoxFilter: cascaded-box FIR lookahead attack smoother
//   2. DualStageRelease: L3-LL ARC program-dependent dual-release stage
//   3. L3PlmMultibandStage: Waves L3-LL Ultra 5-Band Peak Limiting Mixer (PLM)
//      with phase-compensated crossover at 80 Hz, 320 Hz, 1278 Hz, 5113 Hz
//      and per-band Priority, Separation, and Release laws from Presets/1000.xml.

//==============================================================================
class BoxFilter
{
public:
    void prepare (int maxLengthSamples)
    {
        capacity = std::max (2, maxLengthSamples + 1);
        buffer.assign (static_cast<size_t> (capacity), 1.0f);
        length = std::min (length, capacity - 1);
        resetTo (1.0f);
    }

    void setLength (int newLengthSamples) noexcept
    {
        const auto clamped = std::clamp (newLengthSamples, 1, capacity - 1);

        if (clamped == length)
            return;

        length = clamped;
        recomputeSumExactly();
    }

    int getLength() const noexcept { return length; }

    void resetTo (float value) noexcept
    {
        std::fill (buffer.begin(), buffer.end(), value);
        writePos = 0;
        runningSum = static_cast<double> (value) * static_cast<double> (length);
        samplesUntilResync = resyncIntervalSamples;
    }

    float process (float input) noexcept
    {
        buffer[static_cast<size_t> (writePos)] = input;
        runningSum += static_cast<double> (input);

        const auto outgoingIndex = (writePos - length + capacity) % capacity;
        runningSum -= static_cast<double> (buffer[static_cast<size_t> (outgoingIndex)]);

        writePos = (writePos + 1) % capacity;

        if (--samplesUntilResync <= 0)
            recomputeSumExactly();

        return static_cast<float> (runningSum / static_cast<double> (length));
    }

private:
    static constexpr int resyncIntervalSamples = 1 << 14;

    void recomputeSumExactly() noexcept
    {
        double sum = 0.0;

        for (int i = 0; i < length; ++i)
        {
            const auto index = (writePos - 1 - i + 2 * capacity) % capacity;
            sum += static_cast<double> (buffer[static_cast<size_t> (index)]);
        }

        runningSum = sum;
        samplesUntilResync = resyncIntervalSamples;
    }

    std::vector<float> buffer;
    int capacity = 2;
    int length = 1;
    int writePos = 0;
    double runningSum = 1.0;
    int samplesUntilResync = resyncIntervalSamples;
};

//==============================================================================
class DualStageRelease
{
public:
    static double coefficientForTau (double tauSeconds, double fsOs) noexcept
    {
        return 1.0 / (tauSeconds * fsOs + 1.0);
    }

    void setFastCoefficient (double newKFast) noexcept { kFast = newKFast; }
    void setSlowCoefficient (double newKSlow) noexcept { kSlow = newKSlow; }
    void setArcAmount (double newArc01) noexcept { arcAmount = std::clamp (newArc01, 0.0, 1.0); }

    void setFastCapDb (double capDb) noexcept
    {
        capLin = std::pow (10.0, -std::abs (capDb) / 20.0);
    }

    double getFastCapLinear() const noexcept { return capLin; }

    void seed (double gain) noexcept
    {
        const auto clamped = std::clamp (gain, 1.0e-6, 1.0);
        fastState = std::max (clamped, capLin);
        slowState = clamped / fastState;
    }

    float process (float smoothedGain) noexcept
    {
        const auto s = static_cast<double> (smoothedGain);
        const auto sTop = std::max (s, capLin);
        const auto sRest = s / std::max (sTop, 1.0e-12);

        // Waves L3-LL Ultra ARC crest-factor release law (Presets/1000.xml:
        // rel1 = 29.94 ms transient carrier, rel2 = 16.90..49.84 ms program carrier):
        // Accelerates fast transient recovery when slowState > fastState (high crest factor)
        // while damping inter-transient pumping on sustained low-crest material.
        double effectiveKFast = kFast;
        if (arcAmount > 0.0 && sTop > fastState)
        {
            const double crestSpread = std::max (0.0, slowState - fastState);
            const double arcBoost = 1.0 + arcAmount * 2.15 * crestSpread;
            effectiveKFast = std::min (1.0, kFast * arcBoost);
        }

        fastState += (sTop - fastState) * effectiveKFast;
        slowState += (sRest - slowState) * kSlow;

        return static_cast<float> (std::min (s, fastState * slowState));
    }

private:
    double kFast = 0.0;
    double kSlow = 0.0;
    double arcAmount = 0.0;
    double capLin = std::pow (10.0, -2.0 / 20.0);
    double fastState = 1.0;
    double slowState = 1.0;
};

//==============================================================================
// Waves L3-LL Ultra 5-Band Peak Limiting Mixer (PLM) Stage
// Crossover frequencies from L3-LL Ultra Presets/1000.xml & 1001.xml:
//   Fc1 = 80 Hz, Fc2 = 320 Hz, Fc3 = 1278 Hz, Fc4 = 5113 Hz (5 Bands)
// Uses complementary state-variable / one-pole Linkwitz-Riley splits so that
// sum_{b=0..4} band[b] == input identically (0.000 dB flat reconstruction
// when all band gains are 1.0f), while selectively attenuating individual
// bands whose energy exceeds their Priority threshold before broadband limiting.
class L3PlmMultibandStage
{
public:
    static constexpr int numBands = 5;
    static constexpr int numSplits = 4;
    static constexpr int maxCh = 2;

    struct ProfileSpec
    {
        // Per-band Priority offset in dB (from Presets/1000.xml)
        float priorityDb[numBands];
        // Per-band PLM RMS/crest time constant in ms (598.66, 503.04, 402.20, 298.46, 200.52)
        float crestTauMs[numBands];
        // Per-band ARC release time in ms (49.84, 39.85, 29.94, 24.24, 16.90)
        float releaseMs[numBands];
        // Inter-band separation factor (0 = wideband only, 1 = maximum multiband independence)
        float separation;
        // Maximum selective per-band attenuation (dB) before broadband PLM takes over
        float maxBandAttenDb;
    };

    static ProfileSpec profileForStyle (int styleIndex) noexcept
    {
        switch (styleIndex)
        {
            case 1: // Transparent -> L3-LL "Extreme Analog / Lavyne Mastering"
                return {
                    { +1.2f,  0.0f, +0.5f, +0.6f, +0.9f },
                    { 621.40f, 548.77f, 484.63f, 364.13f, 305.98f },
                    { 59.31f,  59.31f,  59.31f,  59.31f,  59.31f  },
                    0.42f, 4.5f
                };
            case 2: // Punchy -> L3-LL "Semi Separated / Track Slammer"
                return {
                    {  0.0f,  0.0f,  0.0f,  0.0f,  0.0f },
                    { 598.66f, 503.04f, 402.20f, 298.46f, 200.52f },
                    { 24.24f,  24.24f,  24.24f,  24.24f,  24.24f  },
                    0.55f, 6.0f
                };
            case 3: // Bus -> L3-LL "Cosy and Warm"
                return {
                    { +3.4f, +2.5f, +1.2f,  0.0f,  0.0f },
                    { 509.34f, 509.34f, 509.34f, 509.34f, 509.34f },
                    { 221.48f, 103.77f, 51.10f,  26.12f,  11.94f  },
                    0.48f, 5.0f
                };
            case 4: // Safe -> L3-LL "Lean and Mean"
                return {
                    { -3.0f, -2.0f,  0.0f,  0.0f,  0.0f },
                    { 767.60f, 637.04f, 509.34f, 377.97f, 253.93f },
                    { 221.48f, 103.77f, 51.10f,  26.12f,  11.94f  },
                    0.45f, 4.5f
                };
            case 0: // Classic -> L3-LL "Basic Profile" (80 / 320 / 1278 / 5113 Hz)
            default:
                return {
                    {  0.0f,  0.0f,  0.0f,  0.0f,  0.0f },
                    { 598.66f, 503.04f, 402.20f, 298.46f, 200.52f },
                    { 49.84f,  39.85f,  29.94f,  24.24f,  16.90f  },
                    0.38f, 4.0f
                };
        }
    }

    void prepare (double sampleRate) noexcept
    {
        fs = sampleRate > 0.0 ? sampleRate : 48000.0;
        // Exact crossover frequencies from L3-LL Ultra Presets/1000.xml:
        static constexpr double kCrossoverHz[numSplits] = { 80.0, 320.0, 1278.0, 5113.0 };
        for (int s = 0; s < numSplits; ++s)
        {
            const double fc = std::min (kCrossoverHz[s], fs * 0.45);
            const double g = std::tan (3.14159265358979323846 * fc / fs);
            splitG[s] = static_cast<float> (g / (1.0 + g));
        }
        // Fast 0.8 ms band attack for click-free inter-band priority ducking
        attackCoeff = static_cast<float> (std::exp (-1.0 / (0.0008 * fs)));
        reset();
    }

    void reset() noexcept
    {
        for (int c = 0; c < maxCh; ++c)
        {
            for (int s = 0; s < numSplits; ++s)
            {
                lpState1[c][s] = 0.0f;
                lpState2[c][s] = 0.0f;
            }
            for (int b = 0; b < numBands; ++b)
            {
                bandGain[c][b] = 1.0f;
                bandRmsEnv[c][b] = 0.0f;
            }
        }
    }

    // Processes one sample frame across channels in-place, returning the minimum
    // per-band PLM gain applied on this frame (1.0f when below threshold).
    float processFrame (float* frameSamples, int numChannels,
                        float targetCeilingLinear, float stereoLink01,
                        float releaseScale, int styleIndex) noexcept
    {
        const auto prof = profileForStyle (styleIndex);
        const float minBandGainFloor = std::pow (10.0f, -prof.maxBandAttenDb / 20.0f);

        float bands[maxCh][numBands];
        float bandPeaks[maxCh][numBands];

        const int chCount = std::min (numChannels, maxCh);

        // 1. Complementary 5-band crossover split (exact identity: sum(bands[c][0..4]) == frameSamples[c])
        for (int c = 0; c < chCount; ++c)
        {
            float rem = frameSamples[c];
            for (int s = 0; s < numSplits; ++s)
            {
                const float g = splitG[s];
                // 2-pole cascaded one-pole lowpass for 12 dB/oct slope with exact complementary highpass
                lpState1[c][s] += g * (rem - lpState1[c][s]);
                lpState2[c][s] += g * (lpState1[c][s] - lpState2[c][s]);
                const float low = lpState2[c][s];
                bands[c][s] = low;
                rem -= low;
            }
            bands[c][numBands - 1] = rem;

            for (int b = 0; b < numBands; ++b)
                bandPeaks[c][b] = std::abs (bands[c][b]);
        }

        // 2. Per-band Priority & PLM envelope update
        float minPlmGain = 1.0f;
        for (int b = 0; b < numBands; ++b)
        {
            const float prioGain = std::pow (10.0f, prof.priorityDb[b] / 20.0f);
            // Band threshold scaled by L3-LL Priority and per-band energy share (0.62 * ceiling * prio)
            const float bandThresh = std::max (1.0e-6f, targetCeilingLinear * 0.65f * prioGain);
            const float relSec = std::max (0.005f, prof.releaseMs[b] * 0.001f * releaseScale);
            const float relCoeff = static_cast<float> (std::exp (-1.0 / ( static_cast<double> (relSec) * fs)));
            const float rmsCoeff = static_cast<float> (std::exp (-1.0 / (0.001 * static_cast<double> (prof.crestTauMs[b]) * fs)));

            float linkedBandPeak = 0.0f;
            for (int c = 0; c < chCount; ++c)
                linkedBandPeak = std::max (linkedBandPeak, bandPeaks[c][b]);

            for (int c = 0; c < chCount; ++c)
            {
                const float pk = linkedBandPeak * stereoLink01 + bandPeaks[c][b] * (1.0f - stereoLink01);
                bandRmsEnv[c][b] = pk * pk + (bandRmsEnv[c][b] - pk * pk) * rmsCoeff;

                float desiredGain = 1.0f;
                if (pk > bandThresh)
                {
                    const float rawRatio = bandThresh / pk;
                    // Blend by profile's PLM separation factor and clamp to maxBandAttenDb
                    desiredGain = 1.0f - prof.separation * (1.0f - rawRatio);
                    desiredGain = std::max (minBandGainFloor, desiredGain);
                }

                if (desiredGain < bandGain[c][b])
                    bandGain[c][b] = desiredGain + (bandGain[c][b] - desiredGain) * attackCoeff;
                else
                    bandGain[c][b] = desiredGain + (bandGain[c][b] - desiredGain) * relCoeff;

                minPlmGain = std::min (minPlmGain, bandGain[c][b]);
            }
        }

        // 3. Recombine 5 bands (Peak Limiting Mixer summation)
        for (int c = 0; c < chCount; ++c)
        {
            float sum = 0.0f;
            for (int b = 0; b < numBands; ++b)
                sum += bands[c][b] * bandGain[c][b];
            frameSamples[c] = sum;
        }

        return minPlmGain;
    }

private:
    double fs = 48000.0;
    float splitG[numSplits] = { 0.005f, 0.02f, 0.08f, 0.28f };
    float attackCoeff = 0.9f;
    float lpState1[maxCh][numSplits] = {};
    float lpState2[maxCh][numSplits] = {};
    float bandGain[maxCh][numBands] = {};
    float bandRmsEnv[maxCh][numBands] = {};
};
