#include "dsp/TruePeakLimiterEngine.h"
#include <cmath>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <vector>
// Exit status does not depend on assert/NDEBUG. Optional argv[1] exports
// raw float32 mono streams for independent sinc reconstruction checks.
int main(int argc, char** argv)
{
    const std::filesystem::path output = argc > 1 ? argv[1] : "";
    if (!output.empty()) std::filesystem::create_directories(output);
    int failures = 0, cases = 0;
    for (int sr : {44100,48000,96000})
    for (int style=0;style<5;++style)
    for (int os=0;os<3;++os)
    for (int signal=0;signal<2;++signal)
    {
        TruePeakLimiterEngine e;
        e.setInputGainDb(12); e.setCeilingDb(-1); e.setLookaheadMs(1.5f);
        e.setReleaseMs(50); e.setLimitStyle(style); e.setOversamplingFactor(os);
        e.setTpGuard(true); e.setDitherMode(0); e.prepare({double(sr),128,2});
        juce::AudioBuffer<float> b(2,128);
        std::vector<float> rendered;
        const int n=sr/2; rendered.reserve(n);
        unsigned rng=0x12345678;
        float peak=0;
        for(int off=0;off<n;off+=128) {
            const int count=std::min(128,n-off);
            for(int i=0;i<count;++i) {
                const int at=off+i; const double t=double(at)/sr;
                rng=rng*1664525u+1013904223u;
                float x;
                if(signal==0) {
                    x=float(.8*std::sin(6.283185307179586*997*t)+.3*std::sin(6.283185307179586*61*t)+.25*std::sin(6.283185307179586*.237*at));
                    if(at%4096==0) x+=1.5f;
                } else {
                    x=float(.55*std::sin(6.283185307179586*.449*at)+.35*(double(rng)/4294967296.-.5));
                    if(at>n/3 && at<n/2) x=0; // release + transient restart
                }
                b.setSample(0,i,x); b.setSample(1,i,-x);
            }
            auto block=juce::dsp::AudioBlock<float>(b).getSubBlock(0,size_t(count));
            e.process(block);
            for(int i=0;i<count;++i) {
                const float x=b.getSample(0,i), right=b.getSample(1,i);
                if(!std::isfinite(x)||!std::isfinite(right)||std::abs(x+right)>1.e-5f) ++failures;
                peak=std::max(peak,std::max(std::abs(x),std::abs(right)));
                rendered.push_back(x);
            }
        }
        if(peak>std::pow(10.f,-1.f/20.f)+1.e-6f) ++failures;
        if(!output.empty()) {
            const auto name="output_"+std::to_string(sr)+"_"+std::to_string(style)+"_"+std::to_string(os)+"_"+std::to_string(signal)+".f32";
            std::ofstream f(output/name,std::ios::binary);
            f.write(reinterpret_cast<const char*>(rendered.data()),std::streamsize(rendered.size()*sizeof(float)));
            if(!f) return 2;
        }
        ++cases;
    }
    // Dither/noise-shaping must retain the sample ceiling, including
    // oversized host blocks (prepare 64, process 501) and mono layouts.
    for(int depth=0;depth<3;++depth) for(int shape=0;shape<2;++shape) {
        TruePeakLimiterEngine e; e.setInputGainDb(24); e.setCeilingDb(-1);
        e.setTpGuard(true); e.setDitherMode(depth); e.setNoiseShaping(shape);
        e.prepare({48000.,64,1});
        juce::AudioBuffer<float> b(1,501);
        for(int k=0;k<40;++k) {
            for(int i=0;i<501;++i) b.setSample(0,i,float(.8*std::sin(.21*(k*501+i))));
            auto block=juce::dsp::AudioBlock<float>(b); e.process(block);
            for(int i=0;i<501;++i) if(!std::isfinite(b.getSample(0,i)) || std::abs(b.getSample(0,i))>std::pow(10.f,-1.f/20.f)+1.e-6f) ++failures;
        }
        ++cases;
    }
    // Guard On/Off keeps exactly the same delayed quiet signal and latency.
    {
        TruePeakLimiterEngine off,on; off.setTpGuard(false);on.setTpGuard(true);
        off.prepare({48000.,128,2});on.prepare({48000.,128,2});
        if(off.getLatencySamples()!=on.getLatencySamples()) ++failures;
        juce::AudioBuffer<float> a(2,128),b(2,128);
        for(int k=0;k<50;++k) {
            if(k==25) { off.setTpGuard(true); on.setTpGuard(false); }
            for(int ch=0;ch<2;++ch) for(int i=0;i<128;++i) a.setSample(ch,i,float(.001*std::sin(.03*(k*128+i))));
            b.makeCopyOf(a); auto ba=juce::dsp::AudioBlock<float>(a),bb=juce::dsp::AudioBlock<float>(b);off.process(ba);on.process(bb);
            for(int ch=0;ch<2;++ch) for(int i=0;i<128;++i) if(std::abs(a.getSample(ch,i)-b.getSample(ch,i))>1.e-7f) ++failures;
        }
        ++cases;
    }
    std::printf("Output ceiling + finite/stereo: %d cases, %d failures\n",cases,failures);
    return failures ? 1 : 0;
}
