"""Independent 16x sinc reconstruction check (requires numpy and scipy).
Usage: python tests/verify_output_true_peaks.py path/to/TLimiterOutputCeilingTests
The C++ regression runner exports 90 streams; its other 7 checks run too.
"""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import numpy as np
from scipy.signal import resample_poly

if len(sys.argv) != 2:
    raise SystemExit(__doc__)
with tempfile.TemporaryDirectory(prefix="tlimiter-peaks-") as tmp:
    subprocess.run([str(Path(sys.argv[1]).resolve()), tmp], check=True)
    rows = []
    for file in sorted(Path(tmp).glob("output_*.f32")):
        signal = np.fromfile(file, dtype="<f4").astype(np.float64)
        reconstructed = resample_poly(signal, 16, 1, window=("kaiser", 12))
        peak = float(20 * np.log10(np.max(np.abs(reconstructed))))
        rows.append({"stream": file.stem, "peak_dbfs": peak})
    if len(rows) != 90:
        raise SystemExit(f"Expected 90 exported streams, received {len(rows)}")
    worst = max(rows, key=lambda row: row["peak_dbfs"])
    print(json.dumps({"streams": len(rows), "worst": worst}, indent=2))
    raise SystemExit(any(not np.isfinite(row["peak_dbfs"]) or row["peak_dbfs"] > -0.99 for row in rows))
