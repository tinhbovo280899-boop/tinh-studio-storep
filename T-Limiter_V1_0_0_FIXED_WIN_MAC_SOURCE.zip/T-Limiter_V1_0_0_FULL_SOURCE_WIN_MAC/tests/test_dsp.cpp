// T-Limiter host-wrapper checks (no external test framework). The original project's
// full Catch2 suite is not part of this package; these cover the essentials.
#include "PluginProcessor.h"
#include "params/ParameterIds.h"
#include <cstdio>
static int failures = 0;
#define CHECK(c) do { if (!(c)) { std::printf ("FAIL line %d: %s\n", __LINE__, #c); ++failures; } } while (0)
static const double SR = 48000.0, TAU = juce::MathConstants<double>::twoPi;
static void setP (juce::AudioProcessorValueTreeState& s, const juce::String& id, float v) { auto* q = s.getParameter (id); q->setValueNotifyingHost (q->convertTo0to1 (v)); }
int main()
{
    juce::ScopedJuceInitialiser_GUI init;
    {   ApotheosisAudioProcessor p; setP (p.apvts, ParamIDs::inputGain, 12.0f); setP (p.apvts, ParamIDs::ceiling, -1.0f);
        p.prepareToPlay (SR, 512);
        juce::AudioBuffer<float> b (2, 512); juce::MidiBuffer m; float peak = 0; const int L = p.getLatencySamples();
        for (int k = 0; k < 400; ++k)
        {
            for (int i = 0; i < 512; ++i) { const double t = (k * 512 + i) / SR; const float x = (float) (0.8 * std::sin (TAU * 997 * t) + 0.3 * std::sin (TAU * 61 * t));
                b.setSample (0, i, x); b.setSample (1, i, -x); }
            p.processBlock (b, m);
            if (k > 20) peak = std::max (peak, b.getMagnitude (0, 512));
        }
        const float peakDb = 20 * std::log10 (peak);
        std::printf ("+12 dB drive, ceiling -1 dBTP: sample peak %.2f dBFS, GR %.1f dB, latency %d samples\n", peakDb, p.getGainReductionDb(), L);
        CHECK (peakDb <= -0.99f); CHECK (std::abs (p.getGainReductionDb()) > 3.0f); }
    {   ApotheosisAudioProcessor p; const auto all = p.presetManager.getAllPresets();
        std::printf ("%d factory presets\n", (int) all.size()); CHECK (all.size() >= 11);
        CHECK (p.presetManager.loadPreset ("Punchy Master"));
        CHECK (std::abs (p.apvts.getRawParameterValue (ParamIDs::inputGain)->load() - 3.0f) < 0.01f);
        juce::MemoryBlock st; p.getStateInformation (st); ApotheosisAudioProcessor q; q.setStateInformation (st.getData(), (int) st.getSize());
        CHECK (std::abs (q.apvts.getRawParameterValue (ParamIDs::inputGain)->load() - 3.0f) < 0.01f);
        std::printf ("preset load + state save/restore OK\n"); }
    {   ApotheosisAudioProcessor p; p.prepareToPlay (SR, 256); std::unique_ptr<juce::AudioProcessorEditor> e (p.createEditor());
        CHECK (e != nullptr); std::printf ("editor opens (%dx%d)\n", e->getWidth(), e->getHeight()); }
    std::printf (failures ? "%d TEST(S) FAILED\n" : "ALL TESTS PASSED\n", failures);
    return failures ? 1 : 0;
}
