# T-Limiter — bản sửa 27/10/2026

Đây là mã nguồn, không phải VST3 Windows/macOS đã biên dịch.

## Đã sửa
- Guard giữ mẫu chờ đủ cửa sổ FIR 12 sample thay vì chỉ bù group delay 6 sample. Các ràng buộc gain được áp dụng cho cả cửa sổ chờ; release 5 ms và dự phòng tái dựng 0,2 dB.
- Guard đánh giá đủ 4 phase ở mọi sample rate; phần meter vẫn giữ rate policy ban đầu.
- Guard tôn trọng stereo link. Bật/tắt Guard không reset tầng multiband và không đổi độ trễ.
- Thêm clamp cuối ở sample domain cả khi Dither Off; đây là backstop, không phải thay thế cho xử lý intersample peak.
- Tooltip Lookahead/Oversampling/OS Filter giải thích cần host prepare lại. Giữ cách latch cấu hình, không cấp phát/rebuild oversampler trên audio thread.
- Sửa tìm gói JUCE cài sẵn theo đúng phiên bản ghim 8.0.12.
- Giữ nguyên ID, preset và giấy phép/notice AGPL; không thay tầng 5-band có sẵn.

## Độ trễ và âm thanh
Guard delay nay là 12 sample ở mọi rate, kể cả Guard Off, được tính trong latency báo host. So với bản cũ, tăng 6 sample ở 44,1/48/96 kHz và 12 sample ở các rate trước đây dùng guard delay 0. Khi Guard can thiệp, dự phòng 0,2 dB có thể làm đầu ra thấp hơn ceiling; cần nghe A/B trong workflow thực tế. Không có tuyên bố bảo đảm tuyệt đối mọi tín hiệu hoặc chống overshoot sau encode MP3/AAC.

## Kiểm thử DSP không cần GUI
Dùng JUCE cục bộ hoặc cơ chế tải sẵn có:

```sh
cmake -S . -B build-dsp -DCMAKE_BUILD_TYPE=Release -DTLIMITER_ENGINE_TESTS_ONLY=ON -DT_JUCE_PATH=/path/to/JUCE
cmake --build build-dsp --config Release
ctest --test-dir build-dsp -C Release --output-on-failure
```

TLimiterOutputCeilingTests kiểm tra 90 tổ hợp rate/style/oversampling/tín hiệu và 7 trường hợp bổ sung về dither/noise-shaping, mono, block lớn, độ trễ và bật/tắt Guard (97 tổng cộng).

Có thể chạy phép đo độc lập 16x (cần NumPy/SciPy):

```sh
python tests/verify_output_true_peaks.py /path/to/TLimiterOutputCeilingTests
```

Đây là regression trên tín hiệu tổng hợp, không phải chứng nhận meter/ITU. Kiểm thử wrapper, preset, state và editor cũ vẫn có trong BUILD_TESTING=ON khi build đầy đủ.

Đính chính báo cáo trước: gói gốc có tầng xử lý 5 băng trong GainEnvelopeStages.h; nhận định trước đó về việc không có multiband là sai. Chưa có phép đo chứng minh độ tương đương với Waves L3.
