# T-Limiter V1.0 — mã nguồn VST3

Limiter chặn đỉnh thật (true-peak) cho kênh tổng: Input, Ceiling (dBTP), Release, Attack, Lookahead, Auto Release, Stereo Link, Clip Mix; 5 kiểu (Classic, Transparent, Punchy, Bus, Safe); oversampling 4x/8x/16x; dither 16/24-bit; Delta, Unity, TP Guard; đo LUFS (momentary, short-term, integrated), LRA, true-peak max. 11 preset có sẵn + lưu preset riêng. Giao diện dòng T-: biểu đồ giảm âm theo thời gian, bảng đo loudness.

## Nguồn gốc và bản quyền — đọc trước khi bán

- Lấy từ **Apotheosis** của Yves Vogl (Basilica Audio), giấy phép **GNU AGPL v3** — xem `LICENSE_AGPL-3.0.txt`.
- AGPL **không cho phép bán bản đóng mã**. Nếu phát hành T-Limiter (bán hoặc tặng), anh phải phát hành theo AGPL v3, kèm (hoặc cho tải) toàn bộ mã nguồn kể cả phần anh sửa, giữ thông báo bản quyền gốc và ghi rõ đã sửa đổi. Muốn bán đóng mã thì phải xin giấy phép riêng từ tác giả, hoặc thay phần xử lý bằng code của mình.
- Đã sửa so với bản gốc (25/10/2026): đổi tên/mã plugin sang T-Limiter, thay giao diện ảnh 3D bằng giao diện dòng T- (`src/PluginEditor.*`), bỏ thanh preset tiếng Đức, chuyển sang build CMake kiểu T-Comp (JUCE 8.0.12, C++20), thư mục preset người dùng đổi sang "T Studio". Phần xử lý (`src/dsp/`), tham số và hệ preset giữ nguyên.
- Bộ test Catch2 đầy đủ của bản gốc không nằm trong gói này; `tests/test_dsp.cpp` kiểm tra phần chính (không vượt trần, preset, lưu/mở trạng thái, mở giao diện).

## Xuất VST3 trên Windows

Chạy `BUILD_RELEASE.bat` ngay trong thư mục này. Bản Release x64 nằm trong `_EXPORT/T-Limiter.vst3`.
Cần CMake 3.22+, Visual Studio với công cụ C++ và Windows SDK (giống T-Comp, T-EQ, T-Pitch).
Lần đầu, nếu chưa có JUCE 8 cục bộ, CMake tự tải JUCE 8.0.12. Nếu lỗi, xem `BUILD_ERROR.txt` và `BUILD_LOG.txt` cạnh script.

## Xuất VST3 trên macOS

```bash
chmod +x *.command
./BUILD_RELEASE.command
```

`1_BUILD_MAC_UNIVERSAL.command` build bản chạy cả arm64 và x86_64; `4_VERIFY_MAC_ARCH.command` kiểm tra kiến trúc đã xuất.

## Kiểm tra

`cmake -S . -B build_test -DBUILD_TESTING=ON` → `cmake --build build_test --config Release --target TLimiterDSPTests` → chạy `TLimiterDSPTests`.

## Tên và mã nhận dạng

Tên trong DAW / file: `T-Limiter` / `T-Limiter.vst3`. Hãng: T Studio (`PLUGIN_MANUFACTURER_CODE NtSt`), `PLUGIN_CODE Tlim`, `BUNDLE_ID com.tstudio.tlimiter`. Giao diện dùng chung bộ NTUI của dòng T- (`src/NTUI.*`, `src/TKit.h`, `src/TBrand.h`).
Đây là plugin mới với mã riêng, nên DAW coi là khác với bản gốc (project cũ dùng bản gốc sẽ không tự chuyển sang).

Bản sửa 27/10/2026 và hướng dẫn kiểm thử: xem `GHI_CHU_BAN_SUA.md`.
