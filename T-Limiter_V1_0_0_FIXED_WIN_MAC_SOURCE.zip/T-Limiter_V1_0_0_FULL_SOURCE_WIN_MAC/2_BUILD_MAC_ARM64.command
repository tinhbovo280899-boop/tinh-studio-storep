#!/bin/bash
set -u
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
LOG="$ROOT/BUILD_LOG_ARM64.txt"
ERRLOG="$ROOT/BUILD_ERROR_ARM64.txt"
EXPORT="$ROOT/_EXPORT_ARM64"
NAME="T-Limiter.vst3"
TARGET="TLimiter_VST3"
ARCHS="arm64"
BUILD="$ROOT/build_mac_ARM64"

pause_if_terminal() {
    if [[ -t 0 ]]; then
        printf '
Press Return to close this window...'
        read -r _unused
    fi
}
fail() {
    printf '
BUILD FAILED: %s
' "$1"
    if [[ -f "$LOG" ]]; then
        tail -n 140 "$LOG" > "$ERRLOG"
        cat "$ERRLOG"
    else
        printf '%s
' "$1" > "$ERRLOG"
    fi
    printf '
Full log: %s
Error log: %s
' "$LOG" "$ERRLOG"
    pause_if_terminal
    exit 1
}

[[ -f "$ROOT/CMakeLists.txt" ]] || fail 'CMakeLists.txt not found.'
command -v cmake >/dev/null 2>&1 || fail 'Install CMake 3.22 or newer.'
xcrun --find clang++ >/dev/null 2>&1 || fail 'Install Xcode Command Line Tools: xcode-select --install'
command -v lipo >/dev/null 2>&1 || fail 'lipo not found. Install Xcode Command Line Tools.'

JOBS="$(sysctl -n hw.ncpu 2>/dev/null || echo 2)"
[[ "$JOBS" =~ ^[0-9]+$ ]] || JOBS=2
(( JOBS > 4 )) && JOBS=4
(( JOBS < 1 )) && JOBS=1

: > "$LOG"
rm -f "$ERRLOG"
printf 'T-Limiter V1.0.0 - macOS VST3 (ARM64)
Architectures: %s

' "$ARCHS"

printf '[1/4] Configure...
'
rm -rf "$BUILD"
cmake -S "$ROOT" -B "$BUILD" -G 'Unix Makefiles'   -DCMAKE_BUILD_TYPE=Release   -DCMAKE_OSX_ARCHITECTURES="$ARCHS"   -DBUILD_TESTING=OFF   -DCMAKE_SUPPRESS_REGENERATION=ON >> "$LOG" 2>&1 || fail 'CMake configuration failed.'

printf '[2/4] Build...
'
cmake --build "$BUILD" --config Release --target "$TARGET" --parallel "$JOBS"   >> "$LOG" 2>&1 || fail 'Compilation failed.'

printf '[3/4] Export + ad-hoc sign...
'
VST_PATH="$(find "$BUILD" -type d -name "$NAME" -print -quit)"
[[ -n "$VST_PATH" && -d "$VST_PATH/Contents" ]] || fail "Cannot find $NAME in build folder."
STAGING="$ROOT/_EXPORT_ARM64.new"
rm -rf "$STAGING" "$EXPORT"
mkdir -p "$STAGING" || fail 'Cannot create export folder.'
ditto "$VST_PATH" "$STAGING/$NAME" >> "$LOG" 2>&1 || fail 'Cannot copy VST3 bundle.'
/usr/bin/codesign --force --deep --sign - "$STAGING/$NAME" >> "$LOG" 2>&1 || fail 'Ad-hoc codesign failed.'
mv "$STAGING" "$EXPORT" || fail 'Cannot finalize export folder.'

printf '[4/4] Verify architecture...
'
BIN="$(find "$EXPORT/$NAME/Contents/MacOS" -maxdepth 1 -type f -print -quit)"
[[ -n "$BIN" ]] || fail 'Cannot find VST3 Mach-O binary.'
ARCH_INFO="$(lipo -archs "$BIN" 2>>"$LOG" || true)"
printf 'Binary architectures: %s
' "$ARCH_INFO"

printf '
BUILD OK: %s/%s
' "$EXPORT" "$NAME"
open "$EXPORT" >/dev/null 2>&1 || true
pause_if_terminal
