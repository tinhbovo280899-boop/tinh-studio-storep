# Kiểm tra tác động âm thanh 31 VST — T-PANTHEON

Đọc BAO_CAO_CHUC_NANG_VI.md. Đây là báo cáo bổ sung, dữ liệu đo và mã harness; không phải bộ cài hoặc bản DSP đã sửa. Các phát hiện T-PANTHEON/HD mới chưa có trong bản vá 5 file đã gửi trước.

Trên FX Send/AUX hiện tại: dùng preset có hậu tố FX Send hoặc đặt lại Mix 100% sau khi chọn preset; chỉnh lượng vang bằng Send/Return. Hai preset FX Send không sửa các vấn đề DSP đang có.

31_VST_FUNCTIONS.csv là bảng theo plugin; 561_PARAMETER_PROBES.csv là số đo theo tham số, có ngữ cảnh phụ thuộc. Danh sách không đổi tiếng trong harness không tự động là danh sách lỗi. PANTHEON_MEASUREMENTS.png là đồ thị đo. WAV là impulse response float32 không chỉnh sửa, không phải vocal demo.

Kiểm tra trên nguồn Linux/JUCE 8.0.12 với trial QA allowed và kho thử riêng; chưa chạy binary Windows trong Cubase 15 hoặc nghe so vocal thật. Gói không chứa private key, keygen, SDK hoặc binary plugin.
