#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include "TPantheonProcessor.h"
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <numeric>

struct Settings { int type=0; float rt=2.03f, size=38, pre=12, bass=1.2f, damping=2080, diffusion=65, spread=83, regen=0, delay=14, mix=100, echo=-60, echoMs=0; };
static void set(TPantheonAudioProcessor& p,const char* id,float value){auto* q=p.getAPVTS().getParameter(id);if(!q)throw std::runtime_error(id);q->setValueNotifyingHost(q->convertTo0to1(value));}
static std::vector<float> render(double fs,Settings s,double seconds) {
    TPantheonAudioProcessor p;
    set(p,"reverbType",float(s.type));set(p,"rt60",s.rt);set(p,"roomSize",s.size);set(p,"preDelay",s.pre);
    set(p,"bassBoost",s.bass);set(p,"damping",s.damping);set(p,"diffusion",s.diffusion);set(p,"spread",s.spread);
    set(p,"regen",s.regen);set(p,"delay",s.delay);set(p,"mix",s.mix);
    set(p,"echoLevelL",s.echo);set(p,"echoLevelR",s.echo);set(p,"echoTimeL",s.echoMs);set(p,"echoTimeR",s.echoMs);
    p.setPlayConfigDetails(2,2,fs,256);p.prepareToPlay(fs,256);
    const int frames=int(fs*seconds);std::vector<float> result(size_t(frames)*2);
    juce::AudioBuffer<float> b(2,256);juce::MidiBuffer midi;
    for(int off=0;off<frames;off+=256){int n=std::min(256,frames-off);b.setSize(2,n,false,false,true);b.clear();
        if(off==0){b.setSample(0,0,.1f);b.setSample(1,0,.1f);}p.processBlock(b,midi);
        for(int i=0;i<n;++i)for(int c=0;c<2;++c)result[size_t(off+i)*2+c]=b.getSample(c,i);
    }p.releaseResources();return result;
}
static double delta(const std::vector<float>&a,const std::vector<float>&b){double e=0;for(size_t i=0;i<a.size();++i)e=std::max(e,std::abs(double(a[i])-b[i]));return e;}
static juce::var stats(const std::vector<float>&a,double fs){
    auto* o=new juce::DynamicObject;double energy=0,peak=0;int first=-1;
    std::vector<double> edc(a.size()/2+1,0);
    for(size_t i=0;i<a.size();++i){double v=a[i];if(!std::isfinite(v))throw std::runtime_error("nonfinite");energy+=v*v;peak=std::max(peak,std::abs(v));if(first<0&&std::abs(v)>1e-9)first=int(i/2);}
    for(size_t i=a.size()/2;i-->0;)edc[i]=edc[i+1]+double(a[i*2])*a[i*2]+double(a[i*2+1])*a[i*2+1];
    o->setProperty("energy",energy);o->setProperty("peak",peak);o->setProperty("first_wet_ms",first<0?-1:1000.*first/fs);
    for(int db:{5,25,35,60}){int at=-1;for(size_t i=0;i<edc.size();++i)if(edc[i]<=energy*std::pow(10.,-db/10.)){at=int(i);break;}o->setProperty("edc_minus"+juce::String(db)+"_seconds",at<0?-1:at/fs);}
    double t5=double(o->getProperty("edc_minus5_seconds")),t25=double(o->getProperty("edc_minus25_seconds"));
    o->setProperty("t20_extrapolated_rt60",t25>=t5?3.*(t25-t5):-1);
    double last=0;int n=int(fs*.2);for(size_t i=a.size()-size_t(n)*2;i<a.size();++i)last+=double(a[i])*a[i];
    o->setProperty("last_200ms_rms",std::sqrt(last/(2*n)));return juce::var(o);
}
int main(int argc,char**argv){try{
    juce::ScopedJuceInitialiser_GUI init;tak::license::PluginLicense proof;proof.ensureAutomaticTrial();
    for(int i=0;i<150&&!proof.isAllowed();++i)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
    if(!proof.isAllowed())throw std::runtime_error("QA trial unavailable");
    juce::Array<juce::var> rows;const std::filesystem::path out=argc>1?argv[1]:".";std::filesystem::create_directories(out);
    for(double fs:{44100.,48000.,96000.}){
        Settings defaults;auto base=render(fs,defaults,10.);
        for(int type=0;type<6;++type){Settings s;s.type=type;auto a=type==0?base:render(fs,s,10.);auto row=stats(a,fs);
            row.getDynamicObject()->setProperty("sample_rate",fs);row.getDynamicObject()->setProperty("case","type");
            row.getDynamicObject()->setProperty("type",type);row.getDynamicObject()->setProperty("max_difference_from_hall",delta(base,a));rows.add(row);
            if(fs==48000.){std::ofstream f(out/("type_"+std::to_string(type)+"_48000.f32"),std::ios::binary);f.write(reinterpret_cast<const char*>(a.data()),std::streamsize(a.size()*sizeof(float)));}
        }
        for(float bass:{1.f,1.2f})for(float rt:{.5f,2.f,5.f}){Settings s;s.rt=rt;s.bass=bass;auto a=render(fs,s,12.);auto row=stats(a,fs);
            row.getDynamicObject()->setProperty("sample_rate",fs);row.getDynamicObject()->setProperty("case","rt60");
            row.getDynamicObject()->setProperty("requested_rt60",rt);row.getDynamicObject()->setProperty("bass_boost",bass);rows.add(row);
        }
        for(float pre:{0.f,50.f,150.f}){Settings s;s.pre=pre;auto a=render(fs,s,3.);auto row=stats(a,fs);
            row.getDynamicObject()->setProperty("sample_rate",fs);row.getDynamicObject()->setProperty("case","predelay");
            row.getDynamicObject()->setProperty("requested_predelay_ms",pre);rows.add(row);}
        if(fs==48000.){
            for(float damping:{500.f,2080.f,8000.f,20000.f}){Settings s;s.damping=damping;auto a=render(fs,s,6.);auto row=stats(a,fs);
                row.getDynamicObject()->setProperty("sample_rate",fs);row.getDynamicObject()->setProperty("case","damping");
                row.getDynamicObject()->setProperty("requested_damping_hz",damping);rows.add(row);
                std::ofstream f(out/("damping_"+std::to_string(int(damping))+"_48000.f32"),std::ios::binary);f.write(reinterpret_cast<const char*>(a.data()),std::streamsize(a.size()*sizeof(float)));}
            for(float bass:{1.f,1.2f,1.5f,2.f,2.5f}){Settings s;s.bass=bass;auto a=render(fs,s,6.);auto row=stats(a,fs);
                row.getDynamicObject()->setProperty("sample_rate",fs);row.getDynamicObject()->setProperty("case","bass_boost");
                row.getDynamicObject()->setProperty("requested_bass_multiplier",bass);Settings reference;auto ref=render(fs,reference,6.);
                row.getDynamicObject()->setProperty("max_difference_from_bass_1_2",delta(ref,a));rows.add(row);}
        }
    }
    std::puts(juce::JSON::toString(juce::var(rows),false).toRawUTF8());return 0;
}catch(const std::exception&e){std::fprintf(stderr,"PROBE FAIL %s\n",e.what());return 1;}}
