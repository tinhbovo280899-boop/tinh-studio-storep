#include <juce_audio_utils/juce_audio_utils.h>
#include <juce_gui_extra/juce_gui_extra.h>
#include "licensing/PluginLicense.h"
#include <cstdio>
#include <random>
#include <stdexcept>

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter();
constexpr double fs=48000.;
constexpr int length=144000;
using Signal=std::vector<float>;
using Values=std::vector<std::pair<juce::String,float>>;
static juce::var object(){return juce::var(new juce::DynamicObject);}
static void put(juce::var&o,const char*key,juce::var value){o.getDynamicObject()->setProperty(key,value);}
static Signal input(){
    Signal x(length*2);std::mt19937 rng(1931);std::uniform_real_distribution<float> noise(-1,1);double phase=0;
    for(int i=0;i<length;++i){const double t=i/fs;phase+=2.*juce::MathConstants<double>::pi*(197.+9.*std::sin(7.*t))/fs;
        float n=noise(rng),a=0,b=0;
        if(t<.35){a=.012f*n;b=.009f*noise(rng);}
        else if(t<1.0|| (t>1.2&&t<1.8)){
            float envelope=t<1.0?.45f:.08f;
            a=envelope*float(.7*std::sin(phase)+.23*std::sin(2*phase)+.1*std::sin(3*phase))+.012f*n;
            b=.81f*a+.035f*float(std::sin(2.*juce::MathConstants<double>::pi*311.*t));
        }else if(t>=1.0&&t<=1.2){a=.18f*n;b=.13f*noise(rng);}
        x[i*2]=a;x[i*2+1]=b;
    }return x;
}
static void apply(juce::AudioProcessor&p,const Values&values){
    for(auto&item:values)for(auto*q:p.getParameters())if(auto*id=dynamic_cast<juce::AudioProcessorParameterWithID*>(q))if(id->paramID==item.first)q->setValueNotifyingHost(item.second);
}
static Values activeContext(juce::AudioProcessor&p){
    Values values;
    auto plain=[&](const juce::String&id,float v){for(auto*q:p.getParameters())
        if(auto*r=dynamic_cast<juce::RangedAudioParameter*>(q))if(r->paramID==id)values.emplace_back(id,r->convertTo0to1(v));};
    const auto name=p.getName();
    if(name=="T-RVox"){plain("comp",-18);plain("gate",-35);}
    if(name=="T-Vitamin"){for(int b=1;b<=5;++b)plain("b"+juce::String(b)+"Drive",40);}
    if(name=="T-Pitch"){plain("semis",4);plain("mode",2);}
    if(name=="T-BE"){for(int i=1;i<=4;++i)plain("v"+juce::String(i)+"_on",1);}
    if(name=="T-AutoTune"){plain("use_formants",1);plain("transpose",4);plain("scale",0);plain("vib_shape",1);plain("vib_pitch",35);plain("vib_delay",0);plain("vib_transition",100);}
    if(name=="T-Comp"){plain("style",0);plain("threshold",-30);plain("input",12);plain("drive",.9f);plain("hpf",1);}
    if(name=="T-Compander"){plain("C1_THRESH",-45);plain("C1_FLT_FREQ",200);}
    if(name=="T-PANTHEON"){plain("regen",45);plain("echoLevelL",-12);plain("echoLevelR",-12);}
    if(name=="T-LIQUID DELAY"){plain("overdrive",40);plain("lfoOn",1);plain("lfoDepth",60);}
    if(name=="T-HDelay"){plain("modDepth",40);plain("syncMode",2);}
    if(name=="T-RVerb")plain("eqLowGain",9);
    if(name=="T-Verb"){plain("loratio",.6f);plain("midratio",1.5f);plain("echoint",35);plain("dry",-6);}
    if(name=="T-Limiter"){plain("inputGain",18);plain("ceiling",-12);plain("dither",1);}
    if(name=="T-Lex224")plain("decay_opt_on",1);
    if(name=="T-Manny-EQ"){for(auto id:{"hfGain","hmfGain","lmfGain","lfGain"})plain(id,9);}
    if(name=="T-API550"){for(auto id:{"hfGain","hmfGain","lmfGain","lfGain"})plain(id,9);}
    if(name=="T-EQ"){for(int b=1;b<=8;++b){auto prefix="band"+juce::String(b);plain(prefix+"on",1);plain(prefix+"gain",9);plain(prefix+"dyn",1);plain(prefix+"dthr",-36);plain(prefix+"drange",12);}}
    return values;
}
static Signal render(const Signal&x,const Values&values,int&latency,int preset=-1){
    struct Tempo final:juce::AudioPlayHead {juce::Optional<PositionInfo> getPosition()const override{PositionInfo info;info.setBpm(90.);info.setIsPlaying(true);return info;}} tempo;
    std::unique_ptr<juce::AudioProcessor> p(createPluginFilter());
    p->setPlayHead(&tempo);
    if(preset>=0)p->setCurrentProgram(preset);
    apply(*p,values);p->setPlayConfigDetails(2,2,fs,256);p->prepareToPlay(fs,256);
    juce::AudioBuffer<float>b(2,256);juce::MidiBuffer midi;Signal out(length*2);
    for(int off=0;off<length;off+=256){int n=std::min(256,length-off);b.setSize(2,n,false,false,true);
        for(int c=0;c<2;++c)for(int i=0;i<n;++i)b.setSample(c,i,x[(off+i)*2+c]);
        p->processBlock(b,midi);for(int c=0;c<2;++c)for(int i=0;i<n;++i){float v=b.getSample(c,i);if(!std::isfinite(v))throw std::runtime_error("nonfinite output");out[(off+i)*2+c]=v;}}
    latency=p->getLatencySamples();p->releaseResources();return out;
}
static juce::var compare(const Signal&a,const Signal&b,int lag=0){
    double delta=0,energy=0,peak=0,output=0;
    for(int i=0;i<length;++i)for(int c=0;c<2;++c){const double x=a[i*2+c],y=i>=lag?b[(i-lag)*2+c]:0;double d=x-y;
        delta+=d*d;energy+=y*y;output+=x*x;peak=std::max(peak,std::abs(d));}
    auto r=object();put(r,"max_abs_difference",peak);put(r,"difference_rms",std::sqrt(delta/(2*length)));
    put(r,"difference_to_reference_db",10.*std::log10(std::max(1.e-30,delta)/std::max(1.e-30,energy)));
    put(r,"output_rms",std::sqrt(output/(2*length)));return r;
}
int main(){try{
    juce::ScopedJuceInitialiser_GUI init;tak::license::PluginLicense proof;proof.ensureAutomaticTrial();
    for(int i=0;i<150&&!proof.isAllowed();++i)juce::MessageManager::getInstance()->runDispatchLoopUntil(20);
    if(!proof.isAllowed())throw std::runtime_error("QA license not ready");
    std::unique_ptr<juce::AudioProcessor> info(createPluginFilter());auto result=object();put(result,"name",info->getName());put(result,"qa_license_allowed",proof.isAllowed());
    const auto x=input();int lag=0,otherLag=0;auto base=render(x,{},lag);auto repeat=render(x,{},otherLag);
    put(result,"reported_latency_samples",lag);put(result,"default_vs_aligned_dry",compare(base,x,lag));put(result,"default_repeat_variation",compare(base,repeat));
    const auto context=activeContext(*info);juce::Array<juce::var> contextRows;
    for(const auto&v:context){auto row=object();put(row,"id",v.first);put(row,"normalized",v.second);contextRows.add(row);}
    put(result,"dependency_context",juce::var(contextRows));
    juce::Array<juce::var> params;
    for(auto*q:info->getParameters()){
        auto*id=dynamic_cast<juce::AudioProcessorParameterWithID*>(q);if(!id)continue;
        auto row=object();put(row,"id",id->paramID);put(row,"name",q->getName(128));put(row,"default_normalized",q->getValue());put(row,"default_display",q->getCurrentValueAsText());
        put(row,"minimum_display",q->getText(0,128));put(row,"maximum_display",q->getText(1,128));
        auto low=render(x,{{id->paramID,0.f}},lag);auto high=render(x,{{id->paramID,1.f}},otherLag);
        auto comparison=compare(low,high);put(row,"endpoint_difference",comparison);put(row,"latency_low",lag);put(row,"latency_high",otherLag);
        if(double(comparison.getProperty("max_abs_difference",0))<1.e-7&&!context.empty()){
            auto a=context,b=context;
            if(info->getName()=="T-BE"&&id->paramID.endsWith("semitones")){a.emplace_back("follow_scale",0.f);b.emplace_back("follow_scale",0.f);}
            a.emplace_back(id->paramID,0.f);b.emplace_back(id->paramID,1.f);
            auto lo=render(x,a,lag);auto hi=render(x,b,otherLag);put(row,"active_context_difference",compare(lo,hi));
        }
        params.add(row);
    }
    put(result,"parameter_probe",juce::var(params));
    juce::Array<juce::var> presets;const int count=info->getNumPrograms();put(result,"factory_program_count",count);
    for(int i=1;i<std::min(count,6);++i){auto row=object();put(row,"index",i);put(row,"name",info->getProgramName(i));auto a=render(x,{},otherLag,i);put(row,"difference_from_default",compare(a,base));presets.add(row);}
    put(result,"preset_probe",juce::var(presets));std::puts(juce::JSON::toString(result,true).toRawUTF8());return 0;
}catch(const std::exception&e){std::fprintf(stderr,"FUNCTION FAIL %s\n",e.what());return 1;}}
