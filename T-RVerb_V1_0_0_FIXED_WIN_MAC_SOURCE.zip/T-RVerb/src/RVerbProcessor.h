#pragma once
#include "TProc.h"
#include "engine/rverb_engine.h"

namespace trverb
{
    inline tkit::P layout()
    {
        tkit::P l;
        juce::StringArray types;
        for (int i = 0; i < RVerbEngine::kNumReverbTypes; ++i)
            types.add (RVerbEngine::kReverbTypeNames[i]);

        l.add (tkit::ch ("reverbType", "Reverb Type", types, 0));
        l.add (tkit::fl ("preDelay",   "Pre-Delay",   -160.0f, 160.0f,  25.0f,  0.0f, "ms"));
        l.add (tkit::fl ("time",       "Reverb Time",    0.10f, 20.0f,   2.15f, 2.5f, "s"));
        l.add (tkit::fl ("size",       "Size",          50.0f, 160.0f, 100.0f,  0.0f, "%"));
        l.add (tkit::fl ("diffusion",  "Diffusion",      0.0f, 100.0f,  85.0f,  0.0f, "%"));
        l.add (tkit::fl ("decay",      "Decay Shape",    0.0f, 100.0f, 100.0f,  0.0f, "%"));
        l.add (tkit::fl ("erLevel",    "ER Level",     -40.0f,   0.0f,  -3.0f,  0.0f, "dB"));
        l.add (tkit::fl ("revLevel",   "Reverb Level", -40.0f,   0.0f,   0.0f,  0.0f, "dB"));

        // Damping controls (LF & HF RT60 Ratio + Cutoffs)
        l.add (tkit::fl ("lfCut",      "LF Damping Freq",  16.0f,  1600.0f,  328.0f, 250.0f, "Hz"));
        l.add (tkit::fl ("lfRatio",    "LF Time Ratio",     0.10f,    2.00f,   0.77f,  0.0f, "x"));
        l.add (tkit::fl ("hfCut",      "HF Damping Freq",1000.0f, 21000.0f, 4500.0f,4500.0f, "Hz"));
        l.add (tkit::fl ("hfRatio",    "HF Time Ratio",     0.10f,    2.00f,   0.49f,  0.0f, "x"));

        // Post-Reverb EQ Shelves
        l.add (tkit::fl ("eqLowFreq",  "Low Shelf Freq",   16.0f,  1600.0f,  203.0f, 200.0f, "Hz"));
        l.add (tkit::fl ("eqLowGain",  "Low Shelf Gain",  -24.0f,    12.0f,    0.0f,   0.0f, "dB"));
        l.add (tkit::fl ("eqHighFreq", "High Shelf Freq",1000.0f, 21000.0f, 2470.0f,3500.0f, "Hz"));
        l.add (tkit::fl ("eqHighGain", "High Shelf Gain", -24.0f,    12.0f,   -4.3f,   0.0f, "dB"));

        l.add (tkit::fl ("wetDry",     "Wet/Dry Mix",       0.0f,   100.0f,   35.0f,   0.0f, "%"));
        l.add (tkit::fl ("inGain",     "Input Gain",      -24.0f,     0.0f,    0.0f,   0.0f, "dB"));
        l.add (tkit::bo ("bypass",     "Bypass",          false));
        return l;
    }

    class Processor : public tkit::BaseProcessor
    {
    public:
        Processor() : BaseProcessor (layout(), "T-RVerb") {}
        juce::AudioProcessorEditor* createEditor() override;

        void loadFactoryPreset (int index)
        {
            if (index < 0 || index >= RVerbEngine::kNumPresets) return;
            const auto& s = RVerbEngine::kPresets[index].settings;
            auto setVal = [this] (const juce::String& id, float v) {
                if (auto* p = apvts.getParameter (id))
                    p->setValueNotifyingHost (p->convertTo0to1 (v));
            };
            setVal ("reverbType", (float) s.reverbType);
            setVal ("preDelay",   s.preDelayMs);
            setVal ("time",       s.timeSec);
            setVal ("size",       s.size * 100.0f);
            setVal ("diffusion",  s.diffusion);
            setVal ("decay",      s.decay);
            setVal ("erLevel",    s.erLevelDb);
            setVal ("revLevel",   s.revLevelDb);
            setVal ("lfCut",      s.lfCutHz);
            setVal ("lfRatio",    s.lfRatio);
            setVal ("hfCut",      s.hfCutHz);
            setVal ("hfRatio",    s.hfRatio);
            setVal ("eqLowFreq",  s.eqLowFreqHz);
            setVal ("eqLowGain",  s.eqLowGainDb);
            setVal ("eqHighFreq", s.eqHighFreqHz);
            setVal ("eqHighGain", s.eqHighGainDb);
            setVal ("wetDry",     s.wetDryPct);
            setVal ("inGain",     s.inGainDb);
            currentPreset = index;
        }

        void prepareToPlay (double sr, int block) override
        {
            fs = std::isfinite(sr) ? std::clamp(sr,8000.0,384000.0) : 48000.0;
            chunk = std::max (512, block);
            prepareBase (fs, block, 0);
            engine.prepare (fs, chunk);
            engine.setSettings (readSettings());
            for (auto& v : scratch) v.assign ((size_t) chunk, 0.0f);
        }

        void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
        {
            juce::ScopedNoDenormals nd;
            if(scratch[0].empty()){buffer.clear();return;}
            for(int ch=0;ch<buffer.getNumChannels();++ch){auto* x=buffer.getWritePointer(ch);for(int i=0;i<buffer.getNumSamples();++i)if(!std::isfinite(x[i]))x[i]=0;}
            if(getTotalNumInputChannels()==1 && buffer.getNumChannels()>1)buffer.copyFrom(1,0,buffer,0,0,buffer.getNumSamples());
            for (int c = std::max(2,getTotalNumInputChannels()); c < getTotalNumOutputChannels(); ++c)
                buffer.clear (c, 0, buffer.getNumSamples());
            engine.setSettings (readSettings());
            feedAnalyser (buffer);
            runWithBypass (buffer, [this] (juce::AudioBuffer<float>& b) { process (b); });
            analyserOutFeed (buffer);
        }

        void releaseResources() override { engine.reset(); }
        bool isBusesLayoutSupported(const BusesLayout& l) const override {
            const auto in=l.getMainInputChannelSet(),out=l.getMainOutputChannelSet();
            return (out==juce::AudioChannelSet::mono()||out==juce::AudioChannelSet::stereo())
                && (in==out||in==juce::AudioChannelSet::mono());
        }
        double getTailLengthSeconds() const override {
            const auto safe=[](float v,float fallback){return std::isfinite(v)?v:fallback;};
            const double time=std::clamp(double(safe(param("time"),2.15f)),.1,20.0);
            const double ratio=std::clamp(double(std::max(safe(param("lfRatio"),1),safe(param("hfRatio"),1))),.1,2.0);
            return .5+std::abs(safe(param("preDelay"),0))*.001+2*std::min(30.,time*std::max(1.,ratio));
        }
        int getNumPrograms() override { return RVerbEngine::kNumPresets; }
        int getCurrentProgram() override { return currentPreset.load(); }
        void setCurrentProgram(int i) override { loadFactoryPreset(i); }
        const juce::String getProgramName(int i) override {return i>=0&&i<RVerbEngine::kNumPresets?juce::String(RVerbEngine::kPresets[i].name):juce::String();}
        void getStateInformation(juce::MemoryBlock& data) override {
            auto state=apvts.copyState();state.setProperty("factoryPresetIndex",currentPreset.load(),nullptr);
            if(auto xml=state.createXml())copyXmlToBinary(*xml,data);
        }
        void setStateInformation(const void* data,int count) override {
            if(auto xml=getXmlFromBinary(data,count))if(xml->hasTagName(apvts.state.getType())){
                auto state=juce::ValueTree::fromXml(*xml);
                currentPreset.store(juce::jlimit(0,RVerbEngine::kNumPresets-1,int(state.getProperty("factoryPresetIndex",0))));
                apvts.replaceState(state);
            }
        }
        int getPresetIndex() const { return currentPreset.load(); }
        tkit::AnalyserFeed analyserOut;

    private:
        RVerbEngine::Settings readSettings() const
        {
            RVerbEngine::Settings s;
            const float type=param("reverbType");
            s.reverbType = std::isfinite(type)?juce::roundToInt(type):0;
            s.preDelayMs   = param ("preDelay");
            s.timeSec      = param ("time");
            s.size         = param ("size") * 0.01f;
            s.diffusion    = param ("diffusion");
            s.decay        = param ("decay");
            s.erLevelDb    = param ("erLevel");
            s.revLevelDb   = param ("revLevel");
            s.lfCutHz      = param ("lfCut");
            s.lfRatio      = param ("lfRatio");
            s.hfCutHz      = param ("hfCut");
            s.hfRatio      = param ("hfRatio");
            s.eqLowFreqHz  = param ("eqLowFreq");
            s.eqLowGainDb  = param ("eqLowGain");
            s.eqHighFreqHz = param ("eqHighFreq");
            s.eqHighGainDb = param ("eqHighGain");
            s.wetDryPct    = param ("wetDry");
            s.inGainDb     = param ("inGain");
            return s;
        }

        void process (juce::AudioBuffer<float>& b)
        {
            const int n = b.getNumSamples(), numCh = std::min (2, b.getNumChannels());
            if (numCh <= 0 || n <= 0) return;
            const float* inL = b.getReadPointer (0);
            const float* inR = numCh > 1 ? b.getReadPointer (1) : inL;
            std::copy (inL, inL + n, scratch[0].data());
            std::copy (inR, inR + n, scratch[1].data());
            float* outL = b.getWritePointer (0);
            float* outR = numCh > 1 ? b.getWritePointer (1) : scratch[2].data();
            engine.processStereo (scratch[0].data(), scratch[1].data(), outL, outR, n);
            if (numCh == 1) for (int i = 0; i < n; ++i) outL[i] = 0.5f * (outL[i] + outR[i]);
        }

        void analyserOutFeed (const juce::AudioBuffer<float>& b)
        {
            const int n = b.getNumSamples(), ch = std::min (2, b.getNumChannels());
            if ((int) monoOut.size() < n) return;
            for (int i = 0; i < n; ++i) { float s = 0; for (int c = 0; c < ch; ++c) s += b.getSample (c, i); monoOut[(size_t) i] = s / (float) std::max (1, ch); }
            analyserOut.push (monoOut.data(), n);
        }

        double fs = 48000.0;
        int chunk = 512;
        std::atomic<int> currentPreset { 0 };
        RVerbEngine engine;
        std::vector<float> scratch[3];
        std::vector<float> monoOut = std::vector<float> (1 << 15, 0.0f);
    };
}
