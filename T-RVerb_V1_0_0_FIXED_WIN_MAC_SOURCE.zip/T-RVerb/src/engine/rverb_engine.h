#pragma once
//------------------------------------------------------------------------
// rverb_engine.h — Waves Renaissance Reverb (RVerb.bundle) 12-Type
// Early Reflections + 6-Channel Decorrelated Allpass/FDN Tail Engine
// (extracted from RVerb.bundle ParamXML/1000.xml, Presets/1000.xml & RVerb.dll).
//
// Signal Architecture (RenVerb_Full_1Comb_6Chns_Native):
//   1. Pre-Delay (-160..+160 ms, negative delays dry+ER relative to tail
//      for reverse/early swell; positive delays reverb tail)
//   2. 12 Reverb Types (Hall 1, Hall 2, Room, Chamber, Church, Plate 1,
//      Plate 2, Reverse, Gated, Nonlinear, EchoVerb, ResoVerb) selecting:
//      - Matrix Type (Full Circle, Half Circle, NearMaxMix, StereoMax, Space)
//      - Delay Set (Prime, Power, Incommensurate)
//      - Routing (ER + Revb, ER tru Rvb, Taps + Revb, Taps tru Rvb)
//   3. Early Reflections Multi-Tap Decorrelator (12 stereo taps with
//      Dimensions, Distance, 1st Reflection, ER HF Cut & Absorption)
//   4. 6-Channel Decorrelated FDN + Cascaded Diffusion Allpass Network:
//      - Size (0.50..1.60), Diffusion (0..100%), Decorrelation (0..6)
//      - Dual-Band RT60 Damping (LF Ratio 0.1..2.0x below LF Cut 16..1600 Hz,
//        HF Ratio 0.1..2.0x above HF Cut 1000..21000 Hz)
//   5. Post-Reverb 2-Band EQ (LF Shelf 16..1600 Hz, -24..+12 dB;
//      HF Shelf 1000..21000 Hz, -24..+12 dB) + Wet/Dry Mix
//------------------------------------------------------------------------

#include <cmath>
#include <cstdint>
#include <vector>
#include <algorithm>
#include <array>

namespace trverb {

class RVerbEngine
{
public:
    static constexpr int kNumReverbTypes = 12;
    static constexpr int kNumFdnChannels = 6;
    static constexpr int kNumErTaps      = 12;

    enum ReverbType
    {
        kHall1 = 0,
        kHall2,
        kRoom,
        kChamber,
        kChurch,
        kPlate1,
        kPlate2,
        kReverse,
        kGated,
        kNonlinear,
        kEchoVerb,
        kResoVerb
    };

    static const char* const kReverbTypeNames[kNumReverbTypes];

    struct Settings
    {
        int   reverbType   = kHall1;   // 0..11
        float preDelayMs   = 25.0f;    // -160..+160 ms
        float timeSec      = 2.15f;    // 0.10..20.0 s (RT60)
        float size         = 1.00f;    // 0.50..1.60 (50..160%)
        float diffusion    = 85.0f;    // 0..100%
        float decay        = 100.0f;   // 0..100% (100% = linear exponential, <100% = gated/nonlin contour)
        float erLevelDb    = -3.0f;    // -40..0 dB
        float revLevelDb   = 0.0f;     // -40..0 dB
        float lfCutHz      = 328.0f;   // 16..1600 Hz (Damping LF crossover)
        float lfRatio      = 0.77f;    // 0.10..2.00x
        float hfCutHz      = 4500.0f;  // 1000..21000 Hz (Damping HF crossover)
        float hfRatio      = 0.49f;    // 0.10..2.00x
        float eqLowFreqHz  = 203.0f;   // 16..1600 Hz
        float eqLowGainDb  = 0.0f;     // -24..+12 dB
        float eqHighFreqHz = 2470.0f;  // 1000..21000 Hz
        float eqHighGainDb = -4.3f;    // -24..+12 dB
        float wetDryPct    = 35.0f;    // 0..100%
        float inGainDb     = 0.0f;     // -24..0 dB
    };

    struct PresetInfo
    {
        const char* name;
        Settings settings;
    };

    static constexpr int kNumPresets = 10;
    static const PresetInfo kPresets[kNumPresets];

    void prepare(double sampleRate, int maxBlockSize);
    void reset();
    void setSettings(const Settings& s);
    const Settings& getSettings() const { return current; }

    void processStereo(const float* inL, const float* inR,
                       float* outL, float* outR, int numSamples);

private:
    struct DelayLine
    {
        std::vector<float> buf;
        int mask = 0;
        int writePos = 0;

        void allocate(int maxSamples)
        {
            int p2 = 1024;
            while (p2 <= maxSamples + 16) p2 <<= 1;
            buf.assign(static_cast<size_t>(p2), 0.0f);
            mask = p2 - 1;
            writePos = 0;
        }
        void clear() { std::fill(buf.begin(), buf.end(), 0.0f); writePos = 0; }
        inline void push(float x) { if (buf.empty()) return; buf[static_cast<size_t>(writePos)] = std::isfinite(x) ? std::clamp(x, -1.0e6f, 1.0e6f) : 0.0f; writePos = (writePos + 1) & mask; }
        inline float read(int delaySamples) const
        {
            if (buf.empty()) return 0;
            delaySamples = std::clamp(delaySamples, 0, mask - 1);
            const int idx = (writePos - 1 - delaySamples) & mask;
            return buf[static_cast<size_t>(idx)];
        }
        inline float readFrac(float delaySamples) const
        {
            if (buf.empty()) return 0;
            delaySamples = std::isfinite(delaySamples) ? std::clamp(delaySamples, 0.0f, float(mask - 2)) : 0;
            const int d0 = static_cast<int>(delaySamples);
            const float frac = delaySamples - static_cast<float>(d0);
            const float s0 = buf[static_cast<size_t>((writePos - 1 - d0) & mask)];
            const float s1 = buf[static_cast<size_t>((writePos - 2 - d0) & mask)];
            return s0 + frac * (s1 - s0);
        }
    };

    struct AllpassStage
    {
        DelayLine dl;
        int delayLen = 128;
        float g = 0.65f;
        void init(int maxSamples, int len, float coeff) { dl.allocate(maxSamples); delayLen = len; g = coeff; }
        void clear() { dl.clear(); }
        inline float process(float x)
        {
            const float d = dl.read(delayLen);
            const float v = x - g * d;
            dl.push(v);
            return d + g * v;
        }
    };

    struct ShelfFilter
    {
        float ic1 = 0.0f, ic2 = 0.0f;
        float a1 = 1.0f, a2 = 0.0f, a3 = 0.0f, m0 = 1.0f, m1 = 0.0f, m2 = 0.0f;
        void reset() { ic1 = ic2 = 0.0f; }
        void setLowShelf(double sr, double fc, double gainDb)
        {
            fc = std::clamp(fc, 16.0, sr * 0.45);
            const double A = std::pow(10.0, gainDb / 40.0);
            const double g = std::tan(3.14159265358979323846 * fc / sr) / std::sqrt(A);
            const double k = 1.41421356;
            const double d = 1.0 + g * (g + k);
            a1 = static_cast<float>(1.0 / d);
            a2 = static_cast<float>(g * a1);
            a3 = static_cast<float>(g * a2);
            m0 = 1.0f;
            m1 = static_cast<float>(k * (A - 1.0));
            m2 = static_cast<float>(A * A - 1.0);
        }
        void setHighShelf(double sr, double fc, double gainDb)
        {
            fc = std::clamp(fc, 200.0, sr * 0.47);
            const double A = std::pow(10.0, gainDb / 40.0);
            const double g = std::tan(3.14159265358979323846 * fc / sr) * std::sqrt(A);
            const double k = 1.41421356;
            const double d = 1.0 + g * (g + k);
            a1 = static_cast<float>(1.0 / d);
            a2 = static_cast<float>(g * a1);
            a3 = static_cast<float>(g * a2);
            m0 = static_cast<float>(A * A);
            m1 = static_cast<float>(k * (1.0 - A) * A);
            m2 = static_cast<float>(1.0 - A * A);
        }
        inline float process(float v0)
        {
            const float v3 = v0 - ic2;
            const float v1 = a1 * ic1 + a2 * v3;
            const float v2 = ic2 + a2 * ic1 + a3 * v3;
            ic1 = 2.0f * v1 - ic1;
            ic2 = 2.0f * v2 - ic2;
            return m0 * v0 + m1 * v1 + m2 * v2;
        }
    };

    void updateCoeffs();

    double fs = 48000.0;
    Settings current;

    DelayLine preDelayL, preDelayR;
    DelayLine erDelayL, erDelayR;
    AllpassStage inputDiffL[2], inputDiffR[2];
    DelayLine fdnDelays[kNumFdnChannels];
    AllpassStage fdnAllpass[kNumFdnChannels];

    float fdnDelaySamples[kNumFdnChannels] = {};
    float fdnGainMid[kNumFdnChannels] = {};
    float fdnGainLf[kNumFdnChannels]  = {};
    float fdnGainHf[kNumFdnChannels]  = {};
    float fdnLpState[kNumFdnChannels] = {};
    float fdnHpState[kNumFdnChannels] = {};
    float lpAlpha = 0.3f;
    float hpAlpha = 0.02f;

    int erTapSamplesL[kNumErTaps] = {};
    int erTapSamplesR[kNumErTaps] = {};
    float erTapGains[kNumErTaps]  = {};
    float erLpStateL = 0.0f, erLpStateR = 0.0f;

    ShelfFilter eqLowL, eqLowR, eqHighL, eqHighR;
    double lfoPhase = 0.0;
    float gateEnv = 0.0f;
    bool prepared = false;
};

} // namespace trverb
