//------------------------------------------------------------------------
// rverb_engine.cpp — Waves Renaissance Reverb (RVerb.bundle) 12-Type
// Early Reflections + 6-Channel Decorrelated FDN/Allpass Tail Engine.
//------------------------------------------------------------------------

#include "rverb_engine.h"

namespace trverb {

const char* const RVerbEngine::kReverbTypeNames[RVerbEngine::kNumReverbTypes] = {
    "Hall 1", "Hall 2", "Room", "Chamber", "Church", "Plate 1",
    "Plate 2", "Reverse", "Gated", "Nonlinear", "EchoVerb", "ResoVerb"
};

// Factory presets extracted directly from RVerb.bundle/Contents/Resources/Presets/1000.xml
const RVerbEngine::PresetInfo RVerbEngine::kPresets[RVerbEngine::kNumPresets] = {
    { "PA Default Hall", {
        kHall1, 39.0f, 2.15f, 1.016f, 68.0f, 100.0f, -3.0f, 0.0f,
        328.0f, 0.43f, 9603.0f, 0.70f, 203.0f, 0.0f, 2470.0f, -11.5f, 35.0f, 0.0f
    }},
    { "Classic Plate", {
        kPlate1, 0.6f, 2.95f, 1.60f, 71.0f, 100.0f, -12.0f, 0.0f,
        328.0f, 0.43f, 2411.0f, 0.43f, 203.0f, 0.0f, 2432.7f, -4.3f, 32.0f, 0.0f
    }},
    { "Concert Hall", {
        kHall2, 18.0f, 3.40f, 1.471f, 70.0f, 100.0f, -9.0f, 0.0f,
        492.0f, 0.77f, 9721.0f, 0.49f, 499.0f, +1.4f, 1761.7f, -14.0f, 38.0f, 0.0f
    }},
    { "Dark Velvet Hall", {
        kChurch, 12.0f, 3.80f, 1.343f, 71.0f, 100.0f, -10.0f, 0.0f,
        545.0f, 1.37f, 1000.0f, 0.16f, 327.0f, +4.0f, 1000.0f, -18.0f, 35.0f, 0.0f
    }},
    { "Studio Room", {
        kRoom, 8.0f, 0.85f, 1.32f, 40.0f, 100.0f, -2.0f, -3.0f,
        32.0f, 0.12f, 2633.0f, 0.21f, 216.0f, +2.5f, 4870.3f, -3.4f, 28.0f, 0.0f
    }},
    { "Bright Vocal Plate", {
        kPlate2, 24.0f, 2.20f, 1.156f, 68.0f, 100.0f, -6.0f, 0.0f,
        421.0f, 0.74f, 2455.0f, 1.26f, 158.0f, -2.7f, 1745.7f, +2.7f, 30.0f, 0.0f
    }},
    { "Gated Drum Chamber", {
        kGated, 5.0f, 0.95f, 0.944f, 21.0f, 35.0f, -3.0f, 0.0f,
        468.0f, 1.00f, 2008.0f, 1.00f, 156.0f, 0.0f, 10021.2f, -12.0f, 40.0f, 0.0f
    }},
    { "Cathedral Space", {
        kChurch, 45.0f, 5.20f, 1.55f, 88.0f, 100.0f, -8.0f, 0.0f,
        280.0f, 0.90f, 6800.0f, 0.55f, 180.0f, +1.5f, 3600.0f, -6.0f, 42.0f, 0.0f
    }},
    { "Vocal Short - FX Send", {
        kRoom, 10.0f, 0.55f, 0.75f, 78.0f, 100.0f, -7.0f, -2.0f,
        250.0f, 0.80f, 5000.0f, 0.55f, 180.0f, -1.0f, 5000.0f, -3.0f, 100.0f, 0.0f
    }},
    { "Vocal Soft Plate - FX Send", {
        kPlate1, 16.0f, 0.85f, 0.85f, 82.0f, 100.0f, -9.0f, -1.0f,
        250.0f, 0.80f, 5000.0f, 0.60f, 180.0f, -1.0f, 5000.0f, -3.5f, 100.0f, 0.0f
    }}
};

namespace {
    // 3 Delay Sets from RVerb.dll ("Prime", "Power", "Incommens") in base samples @ 48 kHz
    constexpr int kBaseFdnPrime[6]     = { 1493, 1777, 2089, 2441, 2857, 3313 };
    constexpr int kBaseFdnPower[6]     = { 1361, 1663, 2029, 2473, 3011, 3671 };
    constexpr int kBaseFdnIncommens[6] = { 1277, 1609, 1993, 2381, 2909, 3529 };

    // 12 Early Reflection base tap times (ms) and alternating stereo weights
    constexpr float kErBaseMsL[12] = { 4.3f, 7.9f, 12.4f, 17.8f, 23.1f, 29.5f, 36.2f, 43.8f, 52.1f, 61.4f, 71.8f, 83.5f };
    constexpr float kErBaseMsR[12] = { 5.1f, 9.2f, 14.1f, 19.3f, 25.4f, 31.8f, 39.0f, 46.9f, 55.3f, 64.9f, 75.2f, 87.1f };
    constexpr float kErBaseGains[12] = { 0.84f, -0.76f, 0.69f, 0.63f, -0.57f, 0.52f, -0.47f, 0.42f, 0.37f, -0.33f, 0.29f, -0.25f };
}

void RVerbEngine::prepare(double sampleRate, int /*maxBlockSize*/)
{
    fs = std::isfinite(sampleRate) ? std::clamp(sampleRate, 8000.0, 384000.0) : 48000.0;
    prepared = true;
    const double scale = fs / 48000.0;

    const int maxPreSamples = static_cast<int>(0.25 * fs) + 64;
    preDelayL.allocate(maxPreSamples);
    preDelayR.allocate(maxPreSamples);

    const int maxErSamples = static_cast<int>(0.20 * fs) + 64;
    erDelayL.allocate(maxErSamples);
    erDelayR.allocate(maxErSamples);

    inputDiffL[0].init(static_cast<int>(1024 * scale), static_cast<int>(142 * scale), 0.65f);
    inputDiffL[1].init(static_cast<int>(1024 * scale), static_cast<int>(277 * scale), 0.62f);
    inputDiffR[0].init(static_cast<int>(1024 * scale), static_cast<int>(163 * scale), 0.65f);
    inputDiffR[1].init(static_cast<int>(1024 * scale), static_cast<int>(307 * scale), 0.62f);

    static constexpr int kApLengths[6] = { 211, 263, 317, 379, 439, 503 };
    for (int c = 0; c < kNumFdnChannels; ++c)
    {
        fdnDelays[c].allocate(static_cast<int>(8192 * scale) + 128);
        fdnAllpass[c].init(static_cast<int>(2048 * scale), static_cast<int>(kApLengths[c] * scale), 0.58f);
    }

    updateCoeffs();
    reset();
}

void RVerbEngine::reset()
{
    preDelayL.clear(); preDelayR.clear();
    erDelayL.clear();  erDelayR.clear();
    for (int i = 0; i < 2; ++i) { inputDiffL[i].clear(); inputDiffR[i].clear(); }
    for (int c = 0; c < kNumFdnChannels; ++c)
    {
        fdnDelays[c].clear();
        fdnAllpass[c].clear();
        fdnLpState[c] = 0.0f;
        fdnHpState[c] = 0.0f;
    }
    erLpStateL = erLpStateR = 0.0f;
    eqLowL.reset(); eqLowR.reset();
    eqHighL.reset(); eqHighR.reset();
    lfoPhase = 0.0;
    gateEnv = 0.0f;
}

void RVerbEngine::setSettings(const Settings& s)
{
    current = s;
    const Settings defaults;
    auto clean=[](float v,float lo,float hi,float fallback){return std::isfinite(v)?std::clamp(v,lo,hi):fallback;};
    current.reverbType=std::clamp(s.reverbType,0,kNumReverbTypes-1);
    current.preDelayMs=clean(s.preDelayMs,-160.0f,160.0f,defaults.preDelayMs);
    current.timeSec=clean(s.timeSec,0.10f,20.0f,defaults.timeSec);
    current.size=clean(s.size,0.50f,1.60f,defaults.size);
    current.diffusion=clean(s.diffusion,0.0f,100.0f,defaults.diffusion);
    current.decay=clean(s.decay,0.0f,100.0f,defaults.decay);
    current.erLevelDb=clean(s.erLevelDb,-40.0f,0.0f,defaults.erLevelDb);
    current.revLevelDb=clean(s.revLevelDb,-40.0f,0.0f,defaults.revLevelDb);
    current.lfCutHz=clean(s.lfCutHz,16.0f,1600.0f,defaults.lfCutHz);
    current.lfRatio=clean(s.lfRatio,0.10f,2.0f,defaults.lfRatio);
    current.hfCutHz=clean(s.hfCutHz,1000.0f,21000.0f,defaults.hfCutHz);
    current.hfRatio=clean(s.hfRatio,0.10f,2.0f,defaults.hfRatio);
    current.eqLowFreqHz=clean(s.eqLowFreqHz,16.0f,1600.0f,defaults.eqLowFreqHz);
    current.eqLowGainDb=clean(s.eqLowGainDb,-24.0f,12.0f,defaults.eqLowGainDb);
    current.eqHighFreqHz=clean(s.eqHighFreqHz,1000.0f,21000.0f,defaults.eqHighFreqHz);
    current.eqHighGainDb=clean(s.eqHighGainDb,-24.0f,12.0f,defaults.eqHighGainDb);
    current.wetDryPct=clean(s.wetDryPct,0.0f,100.0f,defaults.wetDryPct);
    current.inGainDb=clean(s.inGainDb,-24.0f,0.0f,defaults.inGainDb);
    if (prepared) updateCoeffs();
}

void RVerbEngine::updateCoeffs()
{
    const double scale = fs / 48000.0;
    const int type = std::clamp(current.reverbType, 0, kNumReverbTypes - 1);

    // Select delay set based on ReverbType (Prime for Halls/Chambers/Church,
    // Incommensurate for Plates, Power for Rooms/Echo/ResoVerb)
    const int* baseSet = kBaseFdnPrime;
    float typeSizeScale = 1.0f;
    float typeDiffScale = 1.0f;
    switch (type)
    {
        case kHall1:     baseSet = kBaseFdnPrime;     typeSizeScale = 1.05f; typeDiffScale = 0.95f; break;
        case kHall2:     baseSet = kBaseFdnPrime;     typeSizeScale = 1.18f; typeDiffScale = 1.00f; break;
        case kRoom:      baseSet = kBaseFdnPower;     typeSizeScale = 0.68f; typeDiffScale = 0.75f; break;
        case kChamber:   baseSet = kBaseFdnPrime;     typeSizeScale = 0.85f; typeDiffScale = 0.90f; break;
        case kChurch:    baseSet = kBaseFdnPrime;     typeSizeScale = 1.32f; typeDiffScale = 1.00f; break;
        case kPlate1:    baseSet = kBaseFdnIncommens; typeSizeScale = 0.92f; typeDiffScale = 1.05f; break;
        case kPlate2:    baseSet = kBaseFdnIncommens; typeSizeScale = 1.00f; typeDiffScale = 1.05f; break;
        case kReverse:   baseSet = kBaseFdnPower;     typeSizeScale = 0.95f; typeDiffScale = 0.85f; break;
        case kGated:     baseSet = kBaseFdnPower;     typeSizeScale = 0.80f; typeDiffScale = 0.80f; break;
        case kNonlinear: baseSet = kBaseFdnIncommens; typeSizeScale = 0.88f; typeDiffScale = 0.90f; break;
        case kEchoVerb:  baseSet = kBaseFdnPower;     typeSizeScale = 1.25f; typeDiffScale = 0.55f; break;
        case kResoVerb:  baseSet = kBaseFdnPrime;     typeSizeScale = 0.72f; typeDiffScale = 1.08f; break;
    }

    const float effSize = std::clamp(current.size * typeSizeScale, 0.35f, 2.20f);
    const float diff01  = std::clamp(current.diffusion * 0.01f * typeDiffScale, 0.0f, 1.0f);
    const float apG     = 0.15f + 0.52f * diff01;

    inputDiffL[0].g = inputDiffR[0].g = apG;
    inputDiffL[1].g = inputDiffR[1].g = apG * 0.94f;

    const double rt60Mid = std::clamp(static_cast<double>(current.timeSec), 0.10, 20.0);
    const double rt60Lf  = std::clamp(rt60Mid * std::clamp(current.lfRatio, 0.10f, 2.0f), 0.05, 30.0);
    const double rt60Hf  = std::clamp(rt60Mid * std::clamp(current.hfRatio, 0.10f, 2.0f), 0.05, 30.0);

    for (int c = 0; c < kNumFdnChannels; ++c)
    {
        const double dSamp = std::max(64.0, baseSet[c] * scale * effSize);
        fdnDelaySamples[c] = static_cast<float>(dSamp);
        fdnAllpass[c].g    = apG * 0.88f;

        const double loopSec = dSamp / fs;
        fdnGainMid[c] = static_cast<float>(std::pow(10.0, -3.0 * loopSec / rt60Mid));
        fdnGainLf[c]  = static_cast<float>(std::pow(10.0, -3.0 * loopSec / rt60Lf));
        fdnGainHf[c]  = static_cast<float>(std::pow(10.0, -3.0 * loopSec / rt60Hf));
    }

    // Damping crossover coefficients (LF Cut & HF Cut from RVerb ParamXML)
    const double fcLf = std::clamp(static_cast<double>(current.lfCutHz), 16.0, 1600.0);
    const double fcHf = std::clamp(static_cast<double>(current.hfCutHz), 1000.0, fs * 0.45);
    hpAlpha = static_cast<float>(1.0 - std::exp(-6.28318530718 * fcLf / fs));
    lpAlpha = static_cast<float>(1.0 - std::exp(-6.28318530718 * fcHf / fs));

    // Early Reflection tap times scaled by Size
    for (int t = 0; t < kNumErTaps; ++t)
    {
        erTapSamplesL[t] = std::max(1, static_cast<int>(kErBaseMsL[t] * 0.001 * fs * effSize));
        erTapSamplesR[t] = std::max(1, static_cast<int>(kErBaseMsR[t] * 0.001 * fs * effSize));
        // For Reverse mode, invert tap envelope so later taps are louder than early taps
        erTapGains[t] = (type == kReverse)
                      ? kErBaseGains[kNumErTaps - 1 - t]
                      : kErBaseGains[t];
    }

    // Post-reverb damping EQ shelves (LF Shelf + HF Shelf)
    eqLowL.setLowShelf(fs, current.eqLowFreqHz, current.eqLowGainDb);
    eqLowR.setLowShelf(fs, current.eqLowFreqHz, current.eqLowGainDb);
    eqHighL.setHighShelf(fs, current.eqHighFreqHz, current.eqHighGainDb);
    eqHighR.setHighShelf(fs, current.eqHighFreqHz, current.eqHighGainDb);
}

void RVerbEngine::processStereo(const float* inL, const float* inR,
                                float* outL, float* outR, int numSamples)
{
    if (numSamples <= 0 || !outL || !outR) return;
    if (!prepared || !inL) {std::fill_n(outL,numSamples,0);std::fill_n(outR,numSamples,0);return;}
    if (!inR) inR=inL;

    const float inGainLin  = std::pow(10.0f, current.inGainDb / 20.0f);
    const float erGainLin  = (current.erLevelDb <= -39.9f) ? 0.0f : std::pow(10.0f, current.erLevelDb / 20.0f);
    const float revGainLin = (current.revLevelDb <= -39.9f) ? 0.0f : std::pow(10.0f, current.revLevelDb / 20.0f);
    const float wetMix     = std::clamp(current.wetDryPct * 0.01f, 0.0f, 1.0f);
    const float dryMix     = 1.0f - wetMix;

    const int preDelaySamp = std::clamp(static_cast<int>(std::abs(current.preDelayMs) * 0.001 * fs),
                                        0, preDelayL.mask - 8);
    const double lfoInc = 6.28318530717958647692 * 0.65 / fs;
    const bool isGatedOrNonlin = (current.reverbType == kGated || current.reverbType == kNonlinear || current.decay < 95.0f);

    for (int i = 0; i < numSamples; ++i)
    {
        const float dryL = (std::isfinite(inL[i]) ? std::clamp(inL[i],-8.0f,8.0f) : 0.0f) * inGainLin;
        const float dryR = (std::isfinite(inR[i]) ? std::clamp(inR[i],-8.0f,8.0f) : 0.0f) * inGainLin;

        // 1. Pre-Delay
        preDelayL.push(dryL);
        preDelayR.push(dryR);
        const float delayedL = preDelayL.read(preDelaySamp);
        const float delayedR = preDelayR.read(preDelaySamp);
        // Positive: delay the wet input. Negative: delay dry/ER relative to the tail.
        const float pdL = current.preDelayMs < 0 ? dryL : delayedL;
        const float pdR = current.preDelayMs < 0 ? dryR : delayedR;
        const float erInL = current.preDelayMs < 0 ? delayedL : pdL;
        const float erInR = current.preDelayMs < 0 ? delayedR : pdR;

        // 2. 12-Tap Decorrelated Early Reflections (ER)
        erDelayL.push(erInL);
        erDelayR.push(erInR);
        float erL = 0.0f, erR = 0.0f;
        for (int t = 0; t < kNumErTaps; ++t)
        {
            const float g = erTapGains[t];
            erL += g * erDelayL.read(erTapSamplesL[t]);
            erR += g * erDelayR.read(erTapSamplesR[t]);
        }
        // Subtle ER absorption lowpass (~5.5 kHz)
        erLpStateL += 0.42f * (erL * 0.25f - erLpStateL);
        erLpStateR += 0.42f * (erR * 0.25f - erLpStateR);
        const float earlyL = erLpStateL * erGainLin;
        const float earlyR = erLpStateR * erGainLin;

        // 3. Input Diffusion Allpass Cascade (feeds FDN tail from input + ER)
        const float diffInL = inputDiffL[1].process(inputDiffL[0].process(pdL + erLpStateL * 0.35f));
        const float diffInR = inputDiffR[1].process(inputDiffR[0].process(pdR + erLpStateR * 0.35f));

        // 4. Read 6-Channel FDN Delay Lines with subtle chorus decorrelation modulation
        lfoPhase += lfoInc;
        if (lfoPhase >= 6.28318530717958647692) lfoPhase -= 6.28318530717958647692;
        const float modBase = static_cast<float>(std::sin(lfoPhase)) * 3.2f;

        float fdnOut[kNumFdnChannels];
        float fdnSum = 0.0f;
        for (int c = 0; c < kNumFdnChannels; ++c)
        {
            const float mod = (c & 1) ? -modBase : modBase;
            const float raw = fdnDelays[c].readFrac(fdnDelaySamples[c] + mod);

            // 3-Band Damping Filter inside FDN loop (LF Ratio, Mid RT60, HF Ratio)
            fdnLpState[c] += lpAlpha * (raw - fdnLpState[c]);
            fdnHpState[c] += hpAlpha * (raw - fdnHpState[c]);
            const float lowBand  = fdnHpState[c];
            const float highBand = raw - fdnLpState[c];
            const float midBand  = raw - lowBand - highBand;

            const float damped = lowBand * fdnGainLf[c]
                               + midBand * fdnGainMid[c]
                               + highBand * fdnGainHf[c];

            fdnOut[c] = fdnAllpass[c].process(damped);
            fdnSum += fdnOut[c];
        }

        // Householder 6x6 unitary feedback matrix (2/6 * sum - x_c)
        const float houseScale = (2.0f / static_cast<float>(kNumFdnChannels)) * fdnSum;
        for (int c = 0; c < kNumFdnChannels; ++c)
        {
            const float inj = (c & 1) ? diffInR : diffInL;
            fdnDelays[c].push(inj * 0.40f + (houseScale - fdnOut[c]));
        }

        // Decorrelated stereo matrix tap-out ("Full Circle / StereoMax")
        float tailL = (fdnOut[0] + fdnOut[2] - fdnOut[4] * 0.6f) * 0.55f;
        float tailR = (fdnOut[1] + fdnOut[3] - fdnOut[5] * 0.6f) * 0.55f;

        if (isGatedOrNonlin)
        {
            const float inAbs = std::max(std::abs(dryL), std::abs(dryR));
            gateEnv = (inAbs > gateEnv) ? (0.992f * gateEnv + 0.008f * inAbs) : (0.9994f * gateEnv);
            const float amount = (current.reverbType == kGated || current.reverbType == kNonlinear)
                ? 1.0f : std::clamp((95.0f-current.decay)/95.0f,0.0f,1.0f);
            const float gateGain = 1.0f + amount * (std::clamp(gateEnv * 18.0f, 0.15f, 1.0f) - 1.0f);
            tailL *= gateGain;
            tailR *= gateGain;
        }

        // 5. Post-Reverb 2-Band EQ (LF Shelf + HF Shelf) & ER + Reverb Mix
        const float wetRawL = earlyL + tailL * revGainLin;
        const float wetRawR = earlyR + tailR * revGainLin;
        const float wetEqL  = eqHighL.process(eqLowL.process(wetRawL));
        const float wetEqR  = eqHighR.process(eqLowR.process(wetRawR));

        outL[i] = (current.preDelayMs < 0 ? delayedL : dryL) * dryMix + wetEqL * wetMix;
        outR[i] = (current.preDelayMs < 0 ? delayedR : dryR) * dryMix + wetEqR * wetMix;
    }
}

} // namespace trverb
