#include "NTUI.h"
#include <cmath>

// ============================================================================
//  Font / ve chung
// ============================================================================
namespace ntc
{
   #if JUCE_WINDOWS
    static juce::String family() { return "Segoe UI"; }
    static juce::String styleFor (W w) { return w == W::Bold ? "Bold" : w == W::Medium ? "Semibold" : "Regular"; }
   #elif JUCE_MAC
    static juce::String family() { return "Helvetica Neue"; }
    static juce::String styleFor (W w) { return w == W::Bold ? "Bold" : w == W::Medium ? "Medium" : "Regular"; }
   #else
    static juce::String family() { return "Liberation Sans"; }
    static juce::String styleFor (W w) { return w == W::Regular ? "Regular" : "Bold"; }
   #endif

    juce::Font font (W w, float size)
    {
        return juce::Font (juce::FontOptions (family(), styleFor (w), std::max (10.5f, size)));
    }

    void caps (juce::Graphics& g, const juce::String& s, juce::Rectangle<float> r,
               juce::Colour c, juce::Justification j, float size)
    {
        g.setColour (c);
        g.setFont (font (W::Medium, size).withExtraKerningFactor (0.08f));
        g.drawText (s.toUpperCase(), r, j, false);
    }

    void cardBg (juce::Graphics& g, juce::Rectangle<float> r, float radius)
    {
        g.setColour (juce::Colours::black.withAlpha (0.35f));
        g.fillRoundedRectangle (r.translated (0.0f, 3.0f), radius);
        g.setGradientFill (juce::ColourGradient (cardTop, r.getX(), r.getY(), card, r.getX(), r.getBottom(), false));
        g.fillRoundedRectangle (r, radius);
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.09f), r.getX(), r.getY(),
                                                 juce::Colours::white.withAlpha (0.02f), r.getX(), r.getBottom(), false));
        g.drawRoundedRectangle (r.reduced (0.5f), radius, 1.0f);
    }

    static float toDb (float lin) { return lin > 1.0e-6f ? 20.0f * std::log10 (lin) : -90.0f; }
}

// ============================================================================
//  LookAndFeel
// ============================================================================
NTLook::NTLook()
{
    setColour (juce::Label::textColourId, ntc::text);
    setColour (juce::TooltipWindow::backgroundColourId, ntc::raised);
    setColour (juce::TooltipWindow::textColourId, ntc::text);
    setColour (juce::Slider::textBoxTextColourId, ntc::text);
    setColour (juce::Slider::textBoxBackgroundColourId, ntc::well);
    setColour (juce::Slider::textBoxOutlineColourId, ntc::line);
    setColour (juce::TextEditor::backgroundColourId, ntc::well);
    setColour (juce::TextEditor::highlightColourId, ntc::gold.withAlpha (0.3f));
    setColour (juce::CaretComponent::caretColourId, ntc::gold);
    setDefaultSansSerifTypefaceName (ntc::family());
}

// ---- Num xoay kieu NT TUNE: phan tinh ve 1 lan vao anh dem, phan dong nhe -----
namespace
{
    struct KnobGeom { float R, ringR, ringW, bodyR, faceR, dotR, tIn; bool big; int ticks; };

    KnobGeom knobGeom (float d)
    {
        KnobGeom k;
        k.R     = d * 0.5f;
        k.big   = d >= 80.0f;
        k.ticks = k.big ? 25 : 13;
        k.tIn   = k.R * 0.86f;
        k.ringW = juce::jlimit (2.4f, 4.0f, d * 0.045f);
        k.ringR = k.R * 0.76f;
        k.bodyR = k.ringR - k.ringW * 1.5f - juce::jmax (2.0f, d * 0.04f);
        k.faceR = k.bodyR * 0.82f;
        k.dotR  = juce::jlimit (2.0f, 4.5f, d * 0.035f);
        return k;
    }

    void drawTick (juce::Graphics& g, juce::Point<float> c, const KnobGeom& k, int i,
                   float a0, float a1, juce::Colour col)
    {
        const float t = (float) i / (float) (k.ticks - 1);
        const float a = a0 + t * (a1 - a0);
        const bool major = (i % (k.big ? 6 : 3)) == 0;
        const float r1 = major ? k.R * 0.99f : k.R * 0.94f;
        g.setColour (col.withMultipliedAlpha (major ? 1.0f : 0.65f));
        g.drawLine (juce::Line<float> (c.getPointOnCircumference (k.tIn, a), c.getPointOnCircumference (r1, a)),
                    major ? 1.4f : 1.0f);
    }

    juce::Image renderKnobStatic (float d, float scale, float a0, float a1)
    {
        const int px = juce::jmax (1, juce::roundToInt (d * scale));
        juce::Image img (juce::Image::ARGB, px, px, true);
        juce::Graphics g (img);
        g.addTransform (juce::AffineTransform::scale (scale));

        const auto k = knobGeom (d);
        const juce::Point<float> c (d * 0.5f, d * 0.5f);

        for (int i = 0; i < k.ticks; ++i)
            drawTick (g, c, k, i, a0, a1, juce::Colours::white.withAlpha ((i % (k.big ? 6 : 3)) == 0 ? 0.16f : 0.12f));

        juce::Path track;
        track.addCentredArc (c.x, c.y, k.ringR, k.ringR, 0.0f, a0, a1, true);
        g.setColour (ntc::bg.darker (0.5f));
        g.strokePath (track, juce::PathStrokeType (k.ringW + 2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour (juce::Colours::white.withAlpha (0.07f));
        g.strokePath (track, juce::PathStrokeType (k.ringW, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

        if (k.bodyR < 4.0f) return img;

        juce::Path body;
        body.addEllipse (c.x - k.bodyR, c.y - k.bodyR, k.bodyR * 2.0f, k.bodyR * 2.0f);
        juce::DropShadow (juce::Colours::black.withAlpha (0.75f), juce::roundToInt (juce::jlimit (4.0f, 20.0f, k.bodyR * 0.5f)),
                          { 0, juce::roundToInt (juce::jmax (1.0f, k.bodyR * 0.15f)) }).drawForPath (g, body);

        g.setGradientFill (juce::ColourGradient (ntc::raised.brighter (0.30f), c.x - k.bodyR * 0.6f, c.y - k.bodyR,
                                                 ntc::bg.darker (0.55f), c.x + k.bodyR * 0.4f, c.y + k.bodyR, false));
        g.fillPath (body);
        g.setGradientFill (juce::ColourGradient (juce::Colours::white.withAlpha (0.22f), c.x, c.y - k.bodyR,
                                                 juce::Colours::white.withAlpha (0.0f), c.x, c.y + k.bodyR * 0.2f, false));
        g.drawEllipse (c.x - k.bodyR + 0.5f, c.y - k.bodyR + 0.5f, k.bodyR * 2.0f - 1.0f, k.bodyR * 2.0f - 1.0f, 1.0f);

        g.setGradientFill (juce::ColourGradient (ntc::raised.brighter (0.06f), c.x, c.y - k.faceR,
                                                 ntc::raised.darker (0.35f), c.x, c.y + k.faceR, false));
        g.fillEllipse (c.x - k.faceR, c.y - k.faceR, k.faceR * 2.0f, k.faceR * 2.0f);
        const int rings = k.big ? 7 : 4;
        g.setColour (juce::Colours::white.withAlpha (0.025f));
        for (int i = 1; i <= rings; ++i)
        {
            const float rr = k.faceR * (float) i / (float) (rings + 1);
            g.drawEllipse (c.x - rr, c.y - rr, rr * 2.0f, rr * 2.0f, 0.8f);
        }
        g.setColour (juce::Colours::black.withAlpha (0.45f));
        g.drawEllipse (c.x - k.faceR, c.y - k.faceR, k.faceR * 2.0f, k.faceR * 2.0f, 1.0f);
        return img;
    }
}

void NTLook::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                          float start, float end, juce::Slider& s)
{
    const auto acc = juce::Colour ((juce::uint32) (juce::int64) s.getProperties().getWithDefault ("accent", (juce::int64) ntc::gold.getARGB()));
    const bool bipolar = (bool) s.getProperties().getWithDefault ("bipolar", false);

    auto bounds = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (1.0f);
    const float d = std::min (bounds.getWidth(), bounds.getHeight());
    if (d < 14.0f) return;

    const auto area  = bounds.withSizeKeepingCentre (d, d);
    const auto c     = area.getCentre();
    const float angle = start + pos * (end - start);
    const auto k     = knobGeom (d);

    // phan tinh tu bo dem (theo kich thuoc + do phan giai man hinh)
    const float scale = juce::jlimit (1.0f, 4.0f, g.getInternalContext().getPhysicalPixelScaleFactor());
    const juce::String key = juce::String (juce::roundToInt (d * 4.0f)) + "|" + juce::String (juce::roundToInt (scale * 100.0f));
    auto it = knobCache.find (key);
    if (it == knobCache.end())
    {
        if (knobCache.size() > 32) knobCache.clear();
        it = knobCache.emplace (key, renderKnobStatic (d, scale, start, end)).first;
    }
    g.drawImage (it->second, area, juce::RectanglePlacement::stretchToFit);

    // vach sang theo gia tri
    const float centreT = 0.5f;
    for (int i = 0; i < k.ticks; ++i)
    {
        const float t = (float) i / (float) (k.ticks - 1);
        const bool lit = bipolar ? ((pos >= centreT) ? (t >= centreT - 1.0e-4f && t <= pos + 1.0e-4f)
                                                     : (t <= centreT + 1.0e-4f && t >= pos - 1.0e-4f))
                                 : t <= pos + 1.0e-4f;
        if (lit) drawTick (g, c, k, i, start, end, acc.withAlpha (0.90f));
    }

    // cung gia tri + glow gia (khong blur)
    const float from = bipolar ? (start + end) * 0.5f : start;
    if (std::abs (angle - from) > 0.004f)
    {
        juce::Path value;
        value.addCentredArc (c.x, c.y, k.ringR, k.ringR, 0.0f, std::min (from, angle), std::max (from, angle), true);
        g.setColour (acc.withAlpha (0.10f));
        g.strokePath (value, juce::PathStrokeType (k.ringW * 3.2f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour (acc.withAlpha (0.18f));
        g.strokePath (value, juce::PathStrokeType (k.ringW * 2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        g.setColour (acc);
        g.strokePath (value, juce::PathStrokeType (k.ringW, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
    }

    // cham chi thi
    if (k.bodyR >= 4.0f)
    {
        const auto dp = c.getPointOnCircumference (k.faceR - k.dotR - std::max (3.0f, k.faceR * 0.14f), angle);
        g.setColour (acc.withAlpha (0.14f));
        g.fillEllipse (dp.x - k.dotR * 2.6f, dp.y - k.dotR * 2.6f, k.dotR * 5.2f, k.dotR * 5.2f);
        g.setColour (acc.withAlpha (0.28f));
        g.fillEllipse (dp.x - k.dotR * 1.7f, dp.y - k.dotR * 1.7f, k.dotR * 3.4f, k.dotR * 3.4f);
        g.setColour (acc.brighter (0.25f));
        g.fillEllipse (dp.x - k.dotR, dp.y - k.dotR, k.dotR * 2.0f, k.dotR * 2.0f);
    }
}

void NTLook::drawLinearSlider (juce::Graphics& g, int x, int y, int w, int h, float pos, float, float,
                                          juce::Slider::SliderStyle, juce::Slider& s)
{
    const auto accent = juce::Colour ((juce::uint32) (juce::int64) s.getProperties().getWithDefault ("accent", (juce::int64) ntc::gold.getARGB()));
    auto r = juce::Rectangle<float> ((float) x, (float) y + h * 0.5f - 2.5f, (float) w, 5.0f);
    g.setColour (ntc::well);
    g.fillRoundedRectangle (r, 2.5f);
    g.setColour (s.isEnabled() ? accent : ntc::dim);
    g.fillRoundedRectangle (r.withRight (pos), 2.5f);
    g.setColour (ntc::text);
    g.fillEllipse (pos - 6.5f, r.getCentreY() - 6.5f, 13.0f, 13.0f);
    g.setColour (juce::Colours::black.withAlpha (0.4f));
    g.drawEllipse (pos - 6.5f, r.getCentreY() - 6.5f, 13.0f, 13.0f, 1.0f);
}

void NTLook::drawButtonBackground (juce::Graphics& g, juce::Button& b, const juce::Colour&, bool over, bool down)
{
    if ((int) b.getProperties().getWithDefault ("chevron", 0) != 0)
    {
        if (over || down)
        {
            g.setColour (juce::Colours::white.withAlpha (down ? 0.10f : 0.06f));
            g.fillRoundedRectangle (b.getLocalBounds().toFloat(), 6.0f);
        }
        return;
    }

    auto r = b.getLocalBounds().toFloat().reduced (0.5f);
    const bool on = b.getToggleState();
    const auto accent = juce::Colour ((juce::uint32) (juce::int64) b.getProperties().getWithDefault ("accent", (juce::int64) ntc::gold.getARGB()));
    const float rad = std::min (r.getHeight() * 0.5f, 8.0f);

    if (on)
    {
        g.setColour (accent.withAlpha (0.16f));
        g.fillRoundedRectangle (r, rad);
        g.setColour (accent.withAlpha (0.85f));
        g.drawRoundedRectangle (r.reduced (0.5f), rad, 1.2f);
    }
    else
    {
        g.setColour (over ? ntc::raised.brighter (0.08f) : ntc::raised);
        g.fillRoundedRectangle (r, rad);
        g.setColour (ntc::lineStrong);
        g.drawRoundedRectangle (r.reduced (0.5f), rad, 1.0f);
    }
    if (down)
    {
        g.setColour (juce::Colours::black.withAlpha (0.15f));
        g.fillRoundedRectangle (r, rad);
    }
}

void NTLook::drawButtonText (juce::Graphics& g, juce::TextButton& b, bool, bool)
{
    const bool on = b.getToggleState();
    const auto accent = juce::Colour ((juce::uint32) (juce::int64) b.getProperties().getWithDefault ("accent", (juce::int64) ntc::gold.getARGB()));
    auto r = b.getLocalBounds().toFloat();

    if (const int chev = (int) b.getProperties().getWithDefault ("chevron", 0); chev != 0)
    {
        // 1 = mui ten len (dang mo -> bam de an), 2 = mui ten xuong (dang an -> bam de hien)
        const auto c = r.getCentre();
        juce::Path p;
        const float w = 7.0f, hh = 3.5f;
        if (chev == 1) { p.startNewSubPath (c.x - w, c.y + hh); p.lineTo (c.x, c.y - hh); p.lineTo (c.x + w, c.y + hh); }
        else           { p.startNewSubPath (c.x - w, c.y - hh); p.lineTo (c.x, c.y + hh); p.lineTo (c.x + w, c.y - hh); }
        g.setColour (b.isMouseOver() ? ntc::gold : ntc::text2);
        g.strokePath (p, juce::PathStrokeType (2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        return;
    }

    if ((bool) b.getProperties().getWithDefault ("power", false))
    {
        const float d = std::min (r.getWidth(), r.getHeight()) * 0.42f;
        auto c = juce::Rectangle<float> (d, d).withCentre (r.getCentre());
        juce::Path p;
        p.addCentredArc (c.getCentreX(), c.getCentreY(), d * 0.5f, d * 0.5f, 0.0f,
                         juce::degreesToRadians (35.0f), juce::degreesToRadians (325.0f), true);
        p.startNewSubPath (c.getCentreX(), c.getY() - d * 0.1f);
        p.lineTo (c.getCentreX(), c.getCentreY());
        // bypass BAT = dang tat hieu ung -> icon mo; tat bypass = dang chay -> sang
        g.setColour (on ? ntc::dim : ntc::gold);
        g.strokePath (p, juce::PathStrokeType (2.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));
        return;
    }

    const float fs = (float) b.getProperties().getWithDefault ("fontSize", 12.0);
    g.setFont (ntc::font (ntc::W::Bold, fs).withExtraKerningFactor (0.05f));
    g.setColour (on ? accent.brighter (0.2f) : ntc::text2);
    g.drawText (b.getButtonText(), r, juce::Justification::centred, false);
}

// ============================================================================
//  NTKnob
// ============================================================================
NTKnob::NTKnob (juce::AudioProcessorValueTreeState& apvts, const juce::String& paramId, const juce::String& nm,
                bool isBig, const juce::String& autoParamId)
    : name (nm), big (isBig)
{
    slider.setSliderStyle (juce::Slider::RotaryVerticalDrag);
    slider.setTextBoxStyle (juce::Slider::NoTextBox, false, 0, 0);
    slider.setRotaryParameters (juce::degreesToRadians (-135.0f), juce::degreesToRadians (135.0f), true);
    slider.getProperties().set ("big", big);
    slider.setMouseDragSensitivity (big ? 220 : 180);
    slider.setVelocityBasedMode (false);
    addAndMakeVisible (slider);

    att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, paramId, slider);
    if (auto* p = apvts.getParameter (paramId))
        slider.setDoubleClickReturnValue (true, p->convertFrom0to1 (p->getDefaultValue()));

    value.setJustificationType (juce::Justification::centred);
    value.setFont (ntc::font (ntc::W::Medium, big ? 13.5f : 11.5f));
    value.setColour (juce::Label::textColourId, ntc::text);
    value.setInterceptsMouseClicks (false, false);
    addAndMakeVisible (value);

    if (autoParamId.isNotEmpty())
    {
        autoButton = std::make_unique<juce::TextButton> ("AUTO");
        autoButton->setClickingTogglesState (true);
        autoButton->getProperties().set ("fontSize", 10.5);
        autoButton->setTooltip (juce::String::fromUTF8 ("AUTO: t\xe1\xbb\xb1 \xc4\x91\xe1\xbb\x99ng theo gi\xe1\xbb\x8dng h\xc3\xa1t"));
        addAndMakeVisible (*autoButton);
        autoAtt = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (apvts, autoParamId, *autoButton);
        autoButton->onStateChange = [this] { refreshText(); repaint(); };
    }

    slider.onValueChange = [this] { refreshText(); };
    refreshText();
}

void NTKnob::refreshText()
{
    juce::String t;
    if (overrideText && isAutoOn())  t = overrideText();
    else if (format)                  t = format (slider.getValue());
    else                              t = juce::String (slider.getValue(), 1);
    if (value.getText() != t) value.setText (t, juce::dontSendNotification);
    value.setColour (juce::Label::textColourId, isAutoOn() ? ntc::gold : ntc::text);
}

void NTKnob::resized()
{
    auto r = getLocalBounds();
    if (big)
    {
        auto top = r.removeFromTop (20);
        if (autoButton) autoButton->setBounds (top.withSizeKeepingCentre (46, 18));
        r.removeFromTop (18);                         // ten (ve trong paint)
        value.setBounds (r.removeFromBottom (20));
        slider.setBounds (r.withSizeKeepingCentre (std::min (r.getWidth(), r.getHeight()), std::min (r.getWidth(), r.getHeight())));
    }
    else
    {
        r.removeFromTop (16);
        value.setBounds (r.removeFromBottom (16));
        slider.setBounds (r.withSizeKeepingCentre (std::min (r.getWidth(), r.getHeight()), std::min (r.getWidth(), r.getHeight())));
    }
}

void NTKnob::paint (juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();
    if (big) ntc::caps (g, name, r.withY (20.0f).withHeight (16.0f), ntc::text2, juce::Justification::centred, 11.5f);
    else     ntc::caps (g, name, r.withHeight (14.0f), ntc::dim, juce::Justification::centred, 10.5f);
}

void NTKnob::rebind (juce::AudioProcessorValueTreeState& apvts, const juce::String& paramId)
{
    att.reset();
    att = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (apvts, paramId, slider);
    if (auto* p = apvts.getParameter (paramId))
        slider.setDoubleClickReturnValue (true, p->convertFrom0to1 (p->getDefaultValue()));
    refreshText();
}
