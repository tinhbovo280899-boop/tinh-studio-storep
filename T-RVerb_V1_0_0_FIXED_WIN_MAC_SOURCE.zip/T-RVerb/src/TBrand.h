#pragma once
#include <juce_gui_basics/juce_gui_basics.h>

namespace txbrand
{
    // "T-" brand: T in the text colour, the hyphen in the accent colour, then the
    // product suffix ("EQ", "Comp", "AutoKey", ...). Host/file name is "T-<suffix>".
    inline void draw (juce::Graphics& g, juce::Rectangle<float> area,
                      const juce::String& suffix, const juce::Font& mainFont,
                      juce::Colour textColour, juce::Colour accentColour)
    {
        juce::Graphics::ScopedSaveState saved (g);
        const float tWidth    = juce::GlyphArrangement::getStringWidth (mainFont, "T");
        const float dashWidth = juce::GlyphArrangement::getStringWidth (mainFont, "-");
        const float gap = mainFont.getHeight() * 0.03f;
        const float baseline = area.getY() + (area.getHeight() - mainFont.getHeight()) * 0.5f
                               + mainFont.getAscent();
        juce::GlyphArrangement textGlyphs, dashGlyphs;
        textGlyphs.addLineOfText (mainFont, "T", area.getX(), baseline);
        dashGlyphs.addLineOfText (mainFont, "-", area.getX() + tWidth + gap, baseline);
        textGlyphs.addLineOfText (mainFont, suffix, area.getX() + tWidth + dashWidth + 2.0f * gap, baseline);
        g.setColour (textColour);
        textGlyphs.draw (g);
        g.setColour (accentColour);
        dashGlyphs.draw (g);
    }
}
