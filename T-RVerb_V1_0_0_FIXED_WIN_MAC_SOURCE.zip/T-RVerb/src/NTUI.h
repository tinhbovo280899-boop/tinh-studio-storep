#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include <map>
#include <functional>

/* Bo giao dien dung chung dong NT (mau, font, num xoay, nut) - giong NT COMP. */
namespace ntc
{
    const juce::Colour bg        (0xff0b0c10);
    const juce::Colour card      (0xff13151b);
    const juce::Colour cardTop   (0xff181a21);
    const juce::Colour well      (0xff0d0e13);
    const juce::Colour raised    (0xff1d2028);
    const juce::Colour line      (0x16ffffff);
    const juce::Colour lineStrong(0x28ffffff);
    const juce::Colour text      (0xfff3efe8);
    const juce::Colour text2     (0xffc2bcb2);
    const juce::Colour dim       (0xff8f897f);
    const juce::Colour gold      (0xffe9c27a);
    const juce::Colour goldHot   (0xfff6d699);
    const juce::Colour coral     (0xffef6f5e);
    const juce::Colour ice       (0xff8cc8e8);
    const juce::Colour inCol     (0xff7d8796);

    enum class W { Regular, Medium, Bold };
    juce::Font font (W w, float size);
    void caps (juce::Graphics& g, const juce::String& s, juce::Rectangle<float> r,
               juce::Colour c = dim, juce::Justification j = juce::Justification::centredLeft, float size = 10.5f);
    void cardBg (juce::Graphics& g, juce::Rectangle<float> r, float radius = 12.0f);
}

//==============================================================================
class NTLook : public juce::LookAndFeel_V4
{
public:
    NTLook();
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float start, float end, juce::Slider&) override;
    void drawLinearSlider (juce::Graphics&, int x, int y, int w, int h, float pos, float minPos, float maxPos,
                           juce::Slider::SliderStyle, juce::Slider&) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&, bool over, bool down) override;
    void drawButtonText (juce::Graphics&, juce::TextButton&, bool over, bool down) override;
    juce::Font getLabelFont (juce::Label&) override { return ntc::font (ntc::W::Medium, 12.0f); }

    // bo dem phan tinh cua num (chi dung tren message thread)
    std::map<juce::String, juce::Image> knobCache;
};

//==============================================================================
/** Mot nut xoay + ten + gia tri (+ nut AUTO tuy chon). */
class NTKnob : public juce::Component
{
public:
    NTKnob (juce::AudioProcessorValueTreeState&, const juce::String& paramId, const juce::String& name,
            bool big, const juce::String& autoParamId = {});

    std::function<juce::String (double)> format;
    std::function<juce::String()> overrideText;   // vd "AUTO -21.4 dB" khi dang tu dong

    void resized() override;
    void paint (juce::Graphics&) override;
    void refreshText();
    bool isAutoOn() const { return autoButton != nullptr && autoButton->getToggleState(); }

    /** Gan lai num vao tham so khac (EQ: doi bang dang chon). */
    void rebind (juce::AudioProcessorValueTreeState&, const juce::String& paramId);
    void setName (const juce::String& n) { name = n; repaint(); }

    juce::Slider slider;

private:
    juce::String name;
    bool big;
    juce::Label value;
    std::unique_ptr<juce::TextButton> autoButton;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> att;
    std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> autoAtt;
};
