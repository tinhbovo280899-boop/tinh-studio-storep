#include "RVerbEditor.h"
juce::AudioProcessorEditor* trverb::Processor::createEditor() { return new Editor (*this); }
juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new trverb::Processor(); }
