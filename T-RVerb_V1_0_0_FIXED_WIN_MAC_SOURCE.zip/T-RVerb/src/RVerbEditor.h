#pragma once
#include "TKit.h"
#include "RVerbProcessor.h"

namespace trverb
{
    class Display : public juce::Component
    {
    public:
        explicit Display (Processor& p) : proc (p) {}
        void tick() { inSpec.update (proc.analyser, proc.getSampleRate()); outSpec.update (proc.analyserOut, proc.getSampleRate()); repaint(); }
        void paint (juce::Graphics& g) override
        {
            auto r = getLocalBounds().toFloat();
            tkit::drawFreqGrid (g, r, -84.0f, 0.0f, 12.0f);
            g.setColour (ntc::inCol.withAlpha (0.28f)); g.fillPath (tkit::spectrumPath (inSpec.db, r, -84.0f, 0.0f, true));
            g.setColour (ntc::gold); g.strokePath (tkit::spectrumPath (outSpec.db, r, -84.0f, 0.0f, false), juce::PathStrokeType (1.8f));
        }
    private:
        Processor& proc;
        tkit::SpectrumAnalyser inSpec, outSpec;
    };

    class Editor : public juce::AudioProcessorEditor, private juce::Timer
    {
    public:
        static constexpr int W = 940, H = 580;
        explicit Editor (Processor& p)
            : AudioProcessorEditor (p), proc (p), display (p),
              kTime (p.apvts, "time", "Reverb Time", true),
              kSize (p.apvts, "size", "Size", true),
              kPreDly (p.apvts, "preDelay", "Pre-Delay", false),
              kDiff (p.apvts, "diffusion", "Diffusion", false),
              kDecay (p.apvts, "decay", "Decay", false),
              kMix (p.apvts, "wetDry", "Wet/Dry", true),
              kLfRat (p.apvts, "lfRatio", "LF Ratio", false),
              kHfRat (p.apvts, "hfRatio", "HF Ratio", false),
              kLowG (p.apvts, "eqLowGain", "Low EQ", false),
              kHighG (p.apvts, "eqHighGain", "High EQ", false),
              kErLvl (p.apvts, "erLevel", "ER Level", false),
              kRevLvl (p.apvts, "revLevel", "Rev Level", false)
        {
            setLookAndFeel (&look);
            addAndMakeVisible (display);
            kTime.format  = [] (double v) { return juce::String (v, 2) + " s"; };
            kSize.format  = tkit::fmtPct;
            kPreDly.slider.setTooltip("Positive: wet predelay. Negative: delays dry and early reflections relative to the tail; this intentionally delays the dry signal.");
            kPreDly.format = tkit::fmtMs; kPreDly.slider.getProperties().set ("bipolar", true);
            kDiff.format  = tkit::fmtPct;
            kDecay.format = tkit::fmtPct;
            kMix.format   = tkit::fmtPct;
            kLfRat.format = [] (double v) { return juce::String (v, 2) + " x"; };
            kHfRat.format = [] (double v) { return juce::String (v, 2) + " x"; };
            kLowG.format  = tkit::fmtDb; kLowG.slider.getProperties().set ("bipolar", true);
            kHighG.format = tkit::fmtDb; kHighG.slider.getProperties().set ("bipolar", true);
            kErLvl.format = tkit::fmtDb;
            kRevLvl.format = tkit::fmtDb;

            for (auto* k : { &kTime, &kSize, &kPreDly, &kDiff, &kDecay, &kMix,
                             &kLfRat, &kHfRat, &kLowG, &kHighG, &kErLvl, &kRevLvl })
            {
                k->refreshText();
                addAndMakeVisible (k);
            }

            for (int i = 0; i < RVerbEngine::kNumReverbTypes; ++i)
                typeBox.addItem (RVerbEngine::kReverbTypeNames[i], i + 1);
            typeAtt = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (p.apvts, "reverbType", typeBox);
            addAndMakeVisible (typeBox);

            for (int i = 0; i < RVerbEngine::kNumPresets; ++i)
                presetBox.addItem (RVerbEngine::kPresets[i].name, i + 1);
            presetBox.setSelectedId (proc.getPresetIndex() + 1, juce::dontSendNotification);
            presetBox.onChange = [this] { proc.loadFactoryPreset (presetBox.getSelectedId() - 1); };
            addAndMakeVisible (presetBox);

            tkit::stylePower (bypass); addAndMakeVisible (bypass);
            batts.add (new juce::AudioProcessorValueTreeState::ButtonAttachment (p.apvts, "bypass", bypass));

            setSize (W, H);
            startTimerHz (30);
        }
        ~Editor() override { stopTimer(); setLookAndFeel (nullptr); }

        void paint (juce::Graphics& g) override
        {
            tkit::paintHeader (g, getLocalBounds().toFloat(), tkit::Glyph::Verb, "RVerb", "12-type renaissance reverberator");
            ntc::cardBg (g, { 14, 56, (float) W - 28, 200 });
            ntc::cardBg (g, { 14, 266, (float) W - 28, (float) H - 280 });
        }

        void resized() override
        {
            typeBox.setBounds (W - 490, 14, 160, 28);
            presetBox.setBounds (W - 316, 14, 236, 28);
            bypass.setBounds (W - 62, 12, 36, 36);
            display.setBounds (24, 64, W - 48, 184);

            const int colW = (W - 48) / 6;
            NTKnob* topRow[6] = { &kTime, &kSize, &kPreDly, &kDiff, &kDecay, &kMix };
            NTKnob* botRow[6] = { &kLfRat, &kHfRat, &kLowG, &kHighG, &kErLvl, &kRevLvl };
            for (int i = 0; i < 6; ++i)
            {
                topRow[i]->setBounds (24 + i * colW, 276, colW, 138);
                botRow[i]->setBounds (24 + i * colW, 422, colW, 132);
            }
        }

    private:
        void timerCallback() override { if(presetBox.getSelectedId()!=proc.getPresetIndex()+1)presetBox.setSelectedId(proc.getPresetIndex()+1,juce::dontSendNotification); display.tick(); }
        Processor& proc;
        tkit::TLook look;
        Display display;
        NTKnob kTime, kSize, kPreDly, kDiff, kDecay, kMix;
        NTKnob kLfRat, kHfRat, kLowG, kHighG, kErLvl, kRevLvl;
        juce::ComboBox typeBox, presetBox;
        std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> typeAtt;
        juce::TextButton bypass;
        juce::OwnedArray<juce::AudioProcessorValueTreeState::ButtonAttachment> batts;
    };
}
