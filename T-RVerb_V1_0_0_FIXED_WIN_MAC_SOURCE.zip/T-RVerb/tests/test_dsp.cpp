// T-RVerb DSP / host-wrapper verification suite
#include "RVerbProcessor.h"
#include <cstdio>
juce::AudioProcessorEditor* trverb::Processor::createEditor() { return nullptr; }

static int failures = 0;
#define CHECK(c) do { if (!(c)) { std::printf ("FAIL line %d: %s\n", __LINE__, #c); ++failures; } } while (0)

int main()
{
    juce::ScopedJuceInitialiser_GUI initialiseJuce;
    constexpr double SR = 48000.0;
    for (int t = 0; t < trverb::RVerbEngine::kNumReverbTypes; ++t)
    {
        trverb::RVerbEngine eng;
        eng.prepare (SR, 512);
        trverb::RVerbEngine::Settings s;
        s.reverbType = t;
        s.wetDryPct  = 100.0f;
        s.preDelayMs = 5.0f;
        eng.setSettings (s);

        // Impulse + short burst test
        std::vector<float> inL (12000, 0.0f), inR (12000, 0.0f), outL (12000, 0.0f), outR (12000, 0.0f);
        for (int i = 0; i < 400; ++i)
        {
            inL[(size_t) i] = 0.5f * std::sin (6.2831853 * 440.0 * i / SR);
            inR[(size_t) i] = 0.5f * std::cos (6.2831853 * 440.0 * i / SR);
        }
        eng.processStereo (inL.data(), inR.data(), outL.data(), outR.data(), (int) inL.size());

        float tailRms = 0.0f;
        bool finite = true;
        for (size_t i = 2000; i < outL.size(); ++i)
        {
            finite &= std::isfinite (outL[i]) && std::isfinite (outR[i]);
            tailRms += outL[i] * outL[i] + outR[i] * outR[i];
        }
        tailRms = std::sqrt (tailRms / (float) (2 * (outL.size() - 2000)));
        std::printf ("ReverbType %2d [%-10s]: tail RMS = %.5f\n", t, trverb::RVerbEngine::kReverbTypeNames[t], tailRms);
        CHECK (finite && tailRms > 1.0e-4f && tailRms < 1.0f);
    }
    {
        trverb::Processor p;
        p.setPlayConfigDetails(1,2,48000,128);p.prepareToPlay(48000,128);
        auto set=[&](const char* id,float v){auto* q=p.apvts.getParameter(id);q->setValueNotifyingHost(q->convertTo0to1(v));};
        set("wetDry",0);juce::AudioBuffer<float> b(2,8193);juce::MidiBuffer m;
        for(int i=0;i<b.getNumSamples();++i){b.setSample(0,i,.1f);b.setSample(1,i,.9f);}p.processBlock(b,m);
        for(int i=0;i<b.getNumSamples();++i){CHECK(std::abs(b.getSample(0,i)-.1f)<1e-6);CHECK(std::abs(b.getSample(1,i)-.1f)<1e-6);}
        CHECK(p.getTailLengthSeconds()>4);
        p.loadFactoryPreset(trverb::RVerbEngine::kNumPresets-1);juce::MemoryBlock state;p.getStateInformation(state);trverb::Processor q;q.setStateInformation(state.getData(),int(state.getSize()));
        CHECK(q.getPresetIndex()==p.getPresetIndex());CHECK(q.getNumPrograms()==10);CHECK(std::abs(q.param("wetDry")-100)<1e-6);
        p.releaseResources();p.prepareToPlay(48000,128);b.clear();p.processBlock(b,m);CHECK(b.getMagnitude(0,b.getNumSamples())==0);
    }
    std::printf (failures ? "%d TEST(S) FAILED\n" : "ALL T-RVERB TESTS PASSED\n", failures);
    return failures ? 1 : 0;
}
