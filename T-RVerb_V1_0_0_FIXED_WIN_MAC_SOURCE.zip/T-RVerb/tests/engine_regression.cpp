#include "engine/rverb_engine.h"
#include "reference/rverb_engine.h"
#include <cstdio>
#include <limits>
#include <vector>
static int failures=0;
#define CHECK(x) do{if(!(x)){std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;}}while(0)
int main(){
 for(double sr:{8000.,44100.,48000.,96000.,192000.})for(int type=0;type<12;++type){
  trverb::RVerbEngine e;e.prepare(sr,128);trverb::RVerbEngine::Settings s;s.reverbType=type;s.wetDryPct=100;e.setSettings(s);
  std::vector<float> l(128),r(128),ol(128),or_(128);double energy=0;
  for(int off=0;off<int(sr);off+=128){for(int n=0;n<128;++n){l[n]=off+n<400?float(.1*std::sin((off+n)*.2)):0;r[n]=l[n];}if(off==128)l[7]=std::numeric_limits<float>::quiet_NaN();if(off==256)r[9]=std::numeric_limits<float>::infinity();e.processStereo(l.data(),r.data(),ol.data(),or_.data(),128);for(int n=0;n<128;++n){CHECK(std::isfinite(ol[n])&&std::isfinite(or_[n]));energy+=double(ol[n])*ol[n]+double(or_[n])*or_[n];}}
  CHECK(energy>1e-10);e.reset();std::fill(l.begin(),l.end(),0);std::fill(r.begin(),r.end(),0);e.processStereo(l.data(),r.data(),ol.data(),or_.data(),128);for(float x:ol)CHECK(x==0);
 }
 // Unchanged valid positive-predelay configurations must retain the old sound.
 for(int type=0;type<12;++type){trverb::RVerbEngine a;reference_rverb::RVerbEngine b;a.prepare(48000,128);b.prepare(48000,128);trverb::RVerbEngine::Settings s;s.reverbType=type;s.wetDryPct=100;reference_rverb::RVerbEngine::Settings t;t.reverbType=type;t.wetDryPct=100;a.setSettings(s);b.setSettings(t);std::vector<float>x(48000),al(48000),ar(48000),bl(48000),br(48000);for(int i=0;i<48000;++i)x[i]=i<800?float(.1*std::sin(i*.2)):0;a.processStereo(x.data(),x.data(),al.data(),ar.data(),48000);b.processStereo(x.data(),x.data(),bl.data(),br.data(),48000);double error=0;for(int i=0;i<48000;++i)error=std::max({error,std::abs(double(al[i])-bl[i]),std::abs(double(ar[i])-br[i])});std::printf("Original comparison type%d error=%.9g\n",type,error);CHECK(error<1e-6);}
 {trverb::RVerbEngine e;e.prepare(48000,128);trverb::RVerbEngine::Settings s;s.preDelayMs=-30;s.wetDryPct=0;e.setSettings(s);std::vector<float>x(2400),l(2400),r(2400);x[0]=.2f;e.processStereo(x.data(),x.data(),l.data(),r.data(),2400);CHECK(l[0]==0&&std::abs(l[1440]-.2f)<1e-7);s.timeSec=std::numeric_limits<float>::infinity();s.hfRatio=std::numeric_limits<float>::quiet_NaN();e.setSettings(s);CHECK(std::isfinite(e.getSettings().timeSec)&&std::isfinite(e.getSettings().hfRatio));}
 {trverb::RVerbEngine e;e.prepare(std::numeric_limits<double>::infinity(),128);float in=0,l=1,r=1;e.processStereo(&in,&in,&l,&r,1);CHECK(std::isfinite(l)&&std::isfinite(r));}
 std::printf("Engine regression: %d failures\n",failures);return failures?1:0;
}
