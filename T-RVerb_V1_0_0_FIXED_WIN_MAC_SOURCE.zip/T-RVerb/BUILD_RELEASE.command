#!/bin/bash
set -u

ROOT="$(cd "$(dirname "$0")" && pwd -P)"
LOG="$ROOT/BUILD_LOG.txt"
ERRLOG="$ROOT/BUILD_ERROR.txt"
EXPORT="$ROOT/_EXPORT"
NAME="T-RVerb.vst3"
TARGET="TRVerb_VST3"

pause_if_terminal() {
    if [[ -t 0 ]]; then
        printf '\nPress Return to close this window...'
        read -r _unused
    fi
}

fail() {
    printf '\nBUILD FAILED: %s\n' "$1"
    if [[ -f "$LOG" ]]; then
        tail -n 120 "$LOG" > "$ERRLOG"
        cat "$ERRLOG"
    else
        printf '%s\n' "$1" > "$ERRLOG"
    fi
    printf '\nFull log: %s\nError log: %s\n' "$LOG" "$ERRLOG"
    pause_if_terminal
    exit 1
}

[[ -f "$ROOT/CMakeLists.txt" ]] || fail 'Put this file next to CMakeLists.txt in the T-RVerb source folder.'
command -v cmake >/dev/null 2>&1 || fail 'Install CMake 3.22 or newer.'
command -v make >/dev/null 2>&1 || fail 'Install Xcode Command Line Tools (xcode-select --install).'
xcrun --find clang++ >/dev/null 2>&1 || fail 'Install Xcode Command Line Tools (xcode-select --install).'

# sysctl reports the actual Apple Silicon hardware even when Terminal uses Rosetta.
if [[ "$(sysctl -n hw.optional.arm64 2>/dev/null)" == '1' ]]; then
    ARCH='arm64'
else
    ARCH='x86_64'
fi
BUILD="$ROOT/build_mac_$ARCH"

JOBS="$(sysctl -n hw.ncpu 2>/dev/null)"
[[ "$JOBS" =~ ^[0-9]+$ ]] || JOBS=2
(( JOBS > 4 )) && JOBS=4
(( JOBS < 1 )) && JOBS=1

: > "$LOG"
rm -f "$ERRLOG"
printf 'T-RVerb V1.0.0 - macOS VST3 Release (%s)\n\n' "$ARCH"

printf '[1/3] Configure (JUCE 8.0.12 downloads if needed)...\n'
printf '===== CONFIGURE =====\n' >> "$LOG"
if [[ -f "$BUILD/CMakeCache.txt" ]]; then
    cmake -S "$ROOT" -B "$BUILD" -DCMAKE_BUILD_TYPE=Release \
        -DCMAKE_OSX_ARCHITECTURES="$ARCH" -DBUILD_TESTING=ON \
        -DCMAKE_SUPPRESS_REGENERATION=ON >> "$LOG" 2>&1 || fail 'CMake configuration failed.'
else
    cmake -S "$ROOT" -B "$BUILD" -G 'Unix Makefiles' -DCMAKE_BUILD_TYPE=Release \
        -DCMAKE_OSX_ARCHITECTURES="$ARCH" -DBUILD_TESTING=ON \
        -DCMAKE_SUPPRESS_REGENERATION=ON >> "$LOG" 2>&1 || fail 'CMake configuration failed.'
fi

printf '[2/3] Compile VST3 Release (%s jobs)...\n' "$JOBS"
printf '===== BUILD =====\n' >> "$LOG"
cmake --build "$BUILD" --config Release --target "$TARGET" TRVerb_EngineRegression TRVerb_Tests --parallel "$JOBS" \
    >> "$LOG" 2>&1 || fail 'Compilation failed.'
ctest --test-dir "$BUILD" -C Release --output-on-failure >> "$LOG" 2>&1 || fail 'Regression tests failed.'


printf '[3/3] Copy VST3 to _EXPORT...\n'
VST_PATH="$(find "$BUILD" -type d -name "$NAME" -print -quit)"
[[ -n "$VST_PATH" && -d "$VST_PATH/Contents" ]] || fail "Cannot find the $NAME bundle in $BUILD."

STAGING="$ROOT/_EXPORT.new"
rm -rf "$STAGING"
mkdir -p "$STAGING" || fail 'Cannot create the export folder.'
ditto "$VST_PATH" "$STAGING/$NAME" >> "$LOG" 2>&1 || fail 'Cannot copy the VST3 bundle.'
[[ -d "$STAGING/$NAME/Contents" ]] || fail 'Copied VST3 bundle is incomplete.'
rm -rf "$EXPORT"
mv "$STAGING" "$EXPORT" || fail 'Cannot move the export into place.'

printf '\nBUILD OK: %s/%s\n' "$EXPORT" "$NAME"
open "$EXPORT" >/dev/null 2>&1 || true
pause_if_terminal
