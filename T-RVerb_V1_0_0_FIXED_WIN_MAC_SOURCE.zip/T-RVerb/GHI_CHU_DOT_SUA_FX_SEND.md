# T-RVerb — bản sửa và preset FX Send

- Chặn NaN/Inf ở input/settings trước vòng hồi tiếp. Giới hạn sample rate hợp lệ 8–384 kHz; rate lỗi dùng 48 kHz. Input quá biên được giới hạn ±8 để bảo vệ state, không thêm limiter vào output.
- Predelay dương giữ đường tín hiệu cũ. Predelay âm nay có ý nghĩa riêng: tail vào trước, dry và early reflections được trễ tương ứng. Đây là delay tạo hiệu ứng có chủ đích, không phải lookahead/giảm ASIO latency; không báo nó là processing latency để host bù mất hiệu ứng này. Khi âm, dry của plugin thực sự bị chậm; hát live nên bắt đầu từ predelay dương.
- Bổ sung mono→stereo, giữ dry hai kênh đúng; reset đuôi khi release; báo tail theo Time và damping ratio, tránh host cắt đuôi do báo 0 giây.
- Preset index dùng atomic, lưu/khôi phục cùng state; host thấy 10 programs. UI cập nhật lại preset khi host thay chương trình.
- Decay ở các kiểu thông thường chuyển liên tục từ contour cũ tới không contour; không còn chỉ là một ngưỡng bật/tắt ở 95%. Gated/Nonlinear giữ contour cũ để giữ chất tiếng.
- Thêm Vocal Short - FX Send (0,55 s) và Vocal Soft Plate - FX Send (0,85 s), Wet/Dry 100%. Giữ nguyên 8 preset gốc.
- CMake chỉ tạo AU trên macOS, có lựa chọn test engine không cần JUCE; helper Windows/macOS build và chạy regression trước khi xuất.

Các tên Reverse/Gated/Nonlinear vẫn là những biến thể ER/contour của engine hiện tại; chưa phải một thuật toán đảo toàn bộ đuôi/gated hold riêng đã đối chiếu với hãng. Không thay các mạng này trong đợt giữ chất tiếng cũ.

Preset/project cũ dùng predelay âm hoặc Decay dưới 95% ở kiểu thông thường có thể đổi âm theo các sửa lỗi trên; các cấu hình dương/default đã được đối chiếu với engine gốc.

## Build

Chạy BUILD_RELEASE.bat trên Windows (Visual Studio C++/CMake), hoặc BUILD_RELEASE.command trên macOS (Xcode Command Line Tools/CMake). Cần mạng ở lần đầu để tải JUCE 8.0.12 nếu chưa đặt JUCE cạnh source; có thể truyền T_JUCE_PATH trỏ mã nguồn JUCE hoặc JUCE_DIR trỏ bản cài JUCE 8.0.12. Plugin xuất trong _EXPORT. Giấy phép JUCE áp dụng cho việc sử dụng/phát hành JUCE.

## Phạm vi xác minh

ZIP là mã nguồn dành cho Windows/macOS, chưa phải plugin hoặc bộ cài Windows/macOS đã biên dịch. Kiểm thử native hiện thực hiện trên Linux; xem TEST_RESULTS_BATCH sau khi đóng gói. Chưa có bản vocal của anh để xác nhận cảm giác mềm/quyện. Không tuyên bố tương đương 1:1 thuật toán của hãng; các comment địa chỉ/nguồn tham khảo cũ không phải kết quả xác minh đó.

Giữ plugin ID, ID tham số và các preset cũ theo thứ tự ban đầu. Preset FX Send được thêm cuối danh sách; preset mới không tự áp lên project cũ. Sao lưu project/plugin trước khi thay bản để nghe A/B.
