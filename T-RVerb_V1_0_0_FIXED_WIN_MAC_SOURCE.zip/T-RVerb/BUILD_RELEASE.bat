@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0" || exit /b 2
title T-RVerb - Build VST3 Release x64

set "ROOT=%CD%"
set "BUILD=%ROOT%\build_win_x64"
set "EXPORT=%ROOT%\_EXPORT"
set "LOG=%ROOT%\BUILD_LOG.txt"
set "ERRLOG=%ROOT%\BUILD_ERROR.txt"
set "CMAKE_GENERATOR="
set "CMAKE_GENERATOR_PLATFORM="

if exist "%LOG%" del /q "%LOG%" >nul 2>nul
if exist "%ERRLOG%" del /q "%ERRLOG%" >nul 2>nul

echo ==========================================================
echo   T-RVerb V1.0.0 - BUILD VST3 RELEASE x64
echo ==========================================================
echo.

if not exist "%ROOT%\CMakeLists.txt" (
  echo [ERROR] Put this file next to CMakeLists.txt in the T-RVerb source folder.
  pause
  exit /b 2
)

where cmake >nul 2>nul
if errorlevel 1 (
  echo [ERROR] CMake was not found in PATH.
  pause
  exit /b 2
)

echo [1/3] Configure ^(JUCE 8.0.12 downloads if needed^)...
echo ===== CONFIGURE =====>>"%LOG%"
if exist "%BUILD%\CMakeCache.txt" (
  cmake -S "%ROOT%" -B "%BUILD%" -DBUILD_TESTING=ON -DCMAKE_SUPPRESS_REGENERATION=ON >>"%LOG%" 2>&1
) else (
  cmake -S "%ROOT%" -B "%BUILD%" -A x64 -DBUILD_TESTING=ON -DCMAKE_SUPPRESS_REGENERATION=ON >>"%LOG%" 2>&1
)
if errorlevel 1 goto :fail

echo [2/3] Compile T-RVerb VST3 Release...
echo ===== BUILD =====>>"%LOG%"
cmake --build "%BUILD%" --config Release --target TRVerb_VST3 TRVerb_EngineRegression TRVerb_Tests --parallel 4 >>"%LOG%" 2>&1
if errorlevel 1 goto :fail

ctest --test-dir "%BUILD%" -C Release --output-on-failure >>"%LOG%" 2>&1
if errorlevel 1 goto :fail

echo [3/3] Copy VST3 to _EXPORT...
set "VSTPATH="
for /f "delims=" %%D in ('dir /s /b /ad "%BUILD%\*.vst3" 2^>nul') do (
  if /i "%%~nxD"=="T-RVerb.vst3" if exist "%%D\Contents" (
    set "VSTPATH=%%D"
    goto :found
  )
)

:found
if not defined VSTPATH (
  echo [ERROR] T-RVerb.vst3 was not found inside "%BUILD%".>>"%LOG%"
  goto :fail
)
for %%D in ("%VSTPATH%") do set "VSTNAME=%%~nxD"
if exist "%EXPORT%" rmdir /s /q "%EXPORT%"
mkdir "%EXPORT%" >nul 2>nul
robocopy "%VSTPATH%" "%EXPORT%\%VSTNAME%" /E /NFL /NDL /NJH /NJS /NP >>"%LOG%" 2>&1
if errorlevel 8 goto :fail

echo.
echo BUILD OK: "%EXPORT%\%VSTNAME%"
explorer "%EXPORT%"
pause
exit /b 0

:fail
echo.
echo BUILD FAILED. Check "%LOG%".
set "NT_BUILD_LOG=%LOG%"
set "NT_BUILD_ERR=%ERRLOG%"
powershell -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path -LiteralPath $env:NT_BUILD_LOG) { $tail = Get-Content -LiteralPath $env:NT_BUILD_LOG -Tail 120; $tail | Set-Content -LiteralPath $env:NT_BUILD_ERR -Encoding UTF8; $tail }"
if exist "%ERRLOG%" start "" notepad "%ERRLOG%"
pause
exit /b 1
