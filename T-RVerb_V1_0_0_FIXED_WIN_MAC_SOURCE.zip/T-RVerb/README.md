> Bản sửa FX Send: xem **GHI_CHU_DOT_SUA_FX_SEND.md** để biết thay đổi, preset mới, cách build và giới hạn. Đây là ZIP mã nguồn.

# T-RVerb v1.0.0 — 12-Type Renaissance Reverb (Win/Mac)

Extracted DSP algorithm from **Waves Renaissance Reverb (`RVerb.bundle`)** (`ParamXML/1000.xml`, `Presets/1000.xml` & `RVerb.dll`), wrapped in the standard **T-Series** (`TKit` / `NTUI` / `TProc`) GUI and CMake build system.

## Build Instructions
- **Windows:** Run `BUILD_RELEASE.bat`
- **macOS:** Run `1_BUILD_MAC_UNIVERSAL.command`
