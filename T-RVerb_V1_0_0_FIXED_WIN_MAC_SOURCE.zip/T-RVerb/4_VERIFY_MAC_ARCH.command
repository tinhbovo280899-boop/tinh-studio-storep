#!/bin/bash
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
for d in "$ROOT"/_EXPORT_*/*.vst3; do
  [[ -d "$d" ]] || continue
  echo "==== $d"
  BIN="$(find "$d/Contents/MacOS" -maxdepth 1 -type f -print -quit)"
  if [[ -n "$BIN" ]]; then
    lipo -info "$BIN" 2>/dev/null || file "$BIN"
  fi
done
printf '\nPress Return to close...'; read -r _
