#!/bin/bash
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
export TH_ARCHS="arm64;x86_64"
export TH_SUFFIX="UNIVERSAL"
bash "$ROOT/tools/mac.sh" Build
TAK_RC=$?
if [[ -t 0 ]]; then printf "\nPress Return to close..."; read -r _tak_close; fi
exit "$TAK_RC"
