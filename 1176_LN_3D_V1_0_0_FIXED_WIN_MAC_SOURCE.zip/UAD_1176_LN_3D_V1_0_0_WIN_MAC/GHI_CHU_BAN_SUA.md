# 1176 LN 3D — bản sửa 27/10/2026

Đây là mã nguồn, không phải VST3 Windows/macOS đã biên dịch.

## Đã sửa
- Loại NaN/Inf khỏi đầu vào active trước detector và khôi phục detector nếu trạng thái không hữu hạn.
- Dùng giá trị hữu hạn dự phòng nếu input/output/attack/release hoặc sample rate không hợp lệ.
- Smoothing input/output gain tính theo thời gian; giữ hệ số 0,001 gốc tại 48 kHz, nhất quán ở 44,1/96 kHz.
- Giữ assert hoạt động ở Release bằng /UNDEBUG hoặc -UNDEBUG; regression mới báo lỗi biên dịch nếu assert bị tắt.
- Bổ sung kiểm thử NaN/Inf L/R, phục hồi nén, đầu ra đối chiếu với tín hiệu đã sanitize, smoothing theo sample rate và tham số không hợp lệ.
- Sửa tìm gói JUCE cài sẵn theo phiên bản ghim 8.0.12.

## Kiểm thử
BUILD_TESTING=ON tạo UAD1176LNDSPTests và UAD1176RobustnessTests. Chạy ctest --test-dir build-test -C Release --output-on-failure. Script build Windows/macOS cũ cũng chạy ctest và sẽ nhận cả hai test.

Giữ nguyên plugin/parameter ID, preset, ratio và luật saturation. Meter Off vẫn là bypass nguyên tín hiệu. Chưa thêm oversampling; không tuyên bố bit-exact hoặc tương đương âm thanh UAD/hardware. Audio chính vẫn là float, không chuyển thành double precision.
