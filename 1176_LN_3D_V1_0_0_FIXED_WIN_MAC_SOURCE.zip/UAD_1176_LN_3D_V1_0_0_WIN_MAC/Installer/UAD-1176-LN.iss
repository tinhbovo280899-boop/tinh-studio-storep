#if FileExists("generated\Config.iss")
  #include "generated\Config.iss"
#endif
#ifndef MyAppId
  #define MyAppId "{{E59B73C2-85D4-47A1-9E12-7B82D193B176}"
#endif
#ifndef MyName
  #define MyName "UAD 1176 LN"
#endif
#ifndef MyVersion
  #define MyVersion "1.0.0"
#endif
#ifndef MyPublisher
  #define MyPublisher "T Studio"
#endif
#ifndef MyBundle
  #define MyBundle "UAD 1176 LN.vst3"
#endif
#define ExportDir SourcePath + "\..\_EXPORT_WIN"

[Setup]
AppId={#MyAppId}
AppName={#MyName}
AppVersion={#MyVersion}
AppPublisher={#MyPublisher}
DefaultDirName={commonappdata}\{#MyPublisher}\{#MyName}
DisableDirPage=yes
DisableProgramGroupPage=yes
PrivilegesRequired=admin
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
CloseApplications=yes
RestartApplications=no
OutputDir=..\Output
OutputBaseFilename=Setup_{#MyName}_{#MyVersion}_Win64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayName={#MyName} VST3
LicenseFile=..\LICENSE

[Files]
Source: "{#ExportDir}\VST3\{#MyBundle}\*"; DestDir: "{commoncf64}\VST3\{#MyBundle}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "{#ExportDir}\HUONG_DAN_KHACH.txt"; DestDir: "{app}"; Flags: ignoreversion
Source: "{#ExportDir}\LICENSE.txt"; DestDir: "{app}"; Flags: ignoreversion

[Messages]
WelcomeLabel1=Chao mung den voi bo cai {#MyName} (3D Blackface - 64-Bit Unlocked)
WelcomeLabel2=Bo cai chep VST3 64-Bit vao thu muc plugin he thong.%n%nHay dong Cubase va cac DAW truoc khi cap nhat.
FinishedLabel=Da cai {#MyName}. Mo DAW va su dung ngay khong can kich hoat key.
