param([string]$SourceDirectory)
$ErrorActionPreference = 'Stop'
if ([string]::IsNullOrWhiteSpace($SourceDirectory)) { $SourceDirectory = Read-Host 'Nhap thu muc cha chua 4 du an, hoac thu muc cua mot du an' }
$SourceDirectory = $SourceDirectory.Trim().Trim('"')
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'PATCH_MANIFEST.json') -Raw | ConvertFrom-Json
$pending = @()
$matched = @()
foreach ($bundle in @($manifest.files.bundle | Select-Object -Unique)) {
    $root = Join-Path $SourceDirectory $bundle
    if (-not (Test-Path -LiteralPath (Join-Path $root 'CMakeLists.txt') -PathType Leaf)) {
        if ((Split-Path -Leaf $SourceDirectory) -eq $bundle -and (Test-Path -LiteralPath (Join-Path $SourceDirectory 'CMakeLists.txt') -PathType Leaf)) { $root = $SourceDirectory } else { continue }
    }
    $matched += $root
    foreach ($entry in @($manifest.files | Where-Object { $_.bundle -eq $bundle })) {
        $target = Join-Path $root $entry.path
        $source = Join-Path (Join-Path (Join-Path $PSScriptRoot 'Patch_Source') $bundle) $entry.path
        if (-not (Test-Path -LiteralPath $target -PathType Leaf)) { throw ('Thieu file: ' + $target) }
        $actual = (Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actual -eq $entry.after_sha256) { continue }
        if ($actual -ne $entry.before_sha256) { throw ('File khac ZIP goc; dung de tranh ghi de thay doi cua anh: ' + $target) }
        if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.after_sha256) { throw ('Ban va sai SHA256: ' + $source) }
        $backup = $target + '.before-license-autotune-fix'
        if (Test-Path -LiteralPath $backup) { throw ('Da co backup; kiem tra truoc: ' + $backup) }
        $pending += [pscustomobject]@{Target=$target; Source=$source; Backup=$backup; Expected=$entry.after_sha256}
    }
}
if ($matched.Count -eq 0) { throw 'Khong tim thay du an phu hop. Nhap dung thu muc da giai nen, khong nhap thu muc ban va.' }
foreach ($entry in $pending) {
    Copy-Item -LiteralPath $entry.Target -Destination $entry.Backup
    Copy-Item -LiteralPath $entry.Source -Destination $entry.Target -Force
    if ((Get-FileHash -LiteralPath $entry.Target -Algorithm SHA256).Hash.ToLowerInvariant() -ne $entry.Expected) { throw ('Kiem tra sau khi ghi that bai: ' + $entry.Target) }
}
Write-Host ('Da va/da co ban va cho ' + $matched.Count + ' du an; ghi ' + $pending.Count + ' file.')
Write-Host 'Can build lai bang script cua du an goc. Chua co VST3/binary Windows moi trong goi nay.'
