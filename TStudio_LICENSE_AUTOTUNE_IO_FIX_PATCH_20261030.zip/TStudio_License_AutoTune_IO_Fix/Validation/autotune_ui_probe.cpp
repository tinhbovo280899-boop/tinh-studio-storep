#include "TAutoTuneProcessor.h"
#include <filesystem>
#include <fstream>
#include <chrono>
#include <cstdio>
using Clock=std::chrono::steady_clock;
static double elapsed(Clock::time_point t){return std::chrono::duration<double,std::milli>(Clock::now()-t).count();}
int main(int argc,char**argv){
 if(argc!=2)return 2;namespace fs=std::filesystem;juce::ScopedJuceInitialiser_GUI init;
 const fs::path config=fs::absolute(argv[1]);const auto file=config/"Auto-Key/Auto-Key.handoff";fs::create_directories(file.parent_path());
 for(int megabytes:{0,64}){
  {std::ofstream out(file,std::ios::binary);out<<"<VALUE name=\"key\" val=\"C\"/><VALUE name=\"scale\" val=\"Major\"/>\n";const std::string spaces(1024*1024,' ');for(int n=0;n<megabytes;++n)out<<spaces;}
  std::printf("STAGE size_mb=%d constructor_begin\n",megabytes);std::fflush(stdout);
  auto t=Clock::now();auto p=std::make_unique<TAutoTuneProcessor>();const double construct=elapsed(t);std::printf("STAGE constructor_done_ms=%.3f\n",construct);std::fflush(stdout);
  t=Clock::now();p->prepareToPlay(48000,128);const double prepare=elapsed(t);std::printf("STAGE prepare_done_ms=%.3f dispatch_begin\n",prepare);std::fflush(stdout);
  t=Clock::now();juce::MessageManager::getInstance()->runDispatchLoopUntil(600);const double dispatch=elapsed(t);
  p->releaseResources();t=Clock::now();p.reset();const double close=elapsed(t);
  std::printf("AUTOTUNE size_mb=%d constructor_ms=%.3f prepare_ms=%.3f dispatch_600ms_actual_ms=%.3f destructor_ms=%.3f\n",megabytes,construct,prepare,dispatch,close);std::fflush(stdout);
 }
 fs::remove(file);
}
