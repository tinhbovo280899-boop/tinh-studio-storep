#include "AutoKeyHandoffReader.h"
#include "AutoTuneHandoff.h"
#include <filesystem>
#include <fstream>
#include <chrono>
#include <cstdio>
int main(int argc,char**argv){
 if(argc!=2)return 2;namespace fs=std::filesystem;const auto root=fs::absolute(argv[1]);fs::create_directories(root);fs::current_path(root);int checks=0;
 auto check=[&](bool v){++checks;if(!v){std::printf("CHECK %d FAILED\n",checks);throw checks;}};
 try{
 const auto current=root/"current/Auto-Key.handoff";const auto other=root/"C:/Users/Other/AppData/Roaming/Auto-Key/Auto-Key.handoff";std::string error;
 check(autokey::handoff::write(current,0,432,error));check(autokey::handoff::write(other,9,440,error));
 fs::last_write_time(current,fs::file_time_type::clock::now()-std::chrono::seconds(10));fs::last_write_time(other,fs::file_time_type::clock::now());
 AutoKeyHandoffReader reader;reader.addExtraSearchPath(current.string());auto data=reader.readBestAvailable();check(data.valid&&data.keyClass==0);check(data.hasReferencePitch&&std::abs(data.referencePitchHz-432)<.1f);
 for(const auto& p:reader.getCandidatePaths())check(p.string().find("C:/Users/Other")==std::string::npos);
 AutoKeyHandoffReader::HandoffData update;check(reader.pollForUpdate(update));check(!reader.pollForUpdate(update));reader.setAutoSyncEnabled(false);check(!reader.pollForUpdate(update,true)==false);check(!reader.pollForUpdate(update));
 for(int key=0;key<24;++key){check(autokey::handoff::write(current,key,key%2?440:432,error));const auto d=AutoKeyHandoffReader::parseFile(current);check(d.valid&&d.keyClass==key%12&&d.scaleIndex==(key>=12?1:0));}
 const auto limit=root/"limit.handoff";auto make=[&](std::size_t size){std::ofstream f(limit,std::ios::binary);const std::string head="<VALUE name=\"key\" val=\"C\"/><VALUE name=\"scale\" val=\"Major\"/>\n";f<<head;f<<std::string(size-head.size(),' ');};
 make(AutoKeyHandoffReader::kMaxHandoffBytes);check(AutoKeyHandoffReader::parseFile(limit).valid);
 make(AutoKeyHandoffReader::kMaxHandoffBytes+1);check(!AutoKeyHandoffReader::parseFile(limit).valid);check(!AutoKeyHandoffReader::parseContent(std::string(AutoKeyHandoffReader::kMaxHandoffBytes+1,' ')).valid);
 {std::ofstream f(limit,std::ios::trunc);}check(!AutoKeyHandoffReader::parseFile(limit).valid);check(!AutoKeyHandoffReader::parseFile(root/"missing.handoff").valid);
 std::printf("HANDOFF REGRESSION: %d checks passed; current-user priority, update/manual flags, 24 keys, pitch reference, size boundaries.\n",checks);return 0;
 }catch(...){return 1;}
}
