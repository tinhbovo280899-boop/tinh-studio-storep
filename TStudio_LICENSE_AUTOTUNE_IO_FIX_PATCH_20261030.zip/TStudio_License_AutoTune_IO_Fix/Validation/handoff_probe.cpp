#include "AutoKeyHandoffReader.h"
#include "AutoTuneHandoff.h"
#include <filesystem>
#include <fstream>
#include <chrono>
#include <cstdio>
int main(int argc,char**argv){
 if(argc!=2)return 2;namespace fs=std::filesystem;using Clock=std::chrono::steady_clock;
 const fs::path root=fs::absolute(argv[1]);fs::create_directories(root);fs::current_path(root);
 const auto current=root/"current-user"/"Auto-Key.handoff";
 const auto other=root/"C:/Users/OtherAccount/AppData/Roaming/Auto-Key/Auto-Key.handoff";
 std::string error;autokey::handoff::write(current,0,440,error);autokey::handoff::write(other,9,440,error);
 fs::last_write_time(current,fs::file_time_type::clock::now()-std::chrono::seconds(10));fs::last_write_time(other,fs::file_time_type::clock::now());
 AutoKeyHandoffReader reader;reader.addExtraSearchPath(current.string());
 const auto chosen=reader.readBestAvailable();
 std::printf("HANDOFF current_key=0 other_key=9 selected_key=%d selected_other_account=%d source=%s\n",chosen.keyClass,chosen.sourcePath=="C:/Users/OtherAccount/AppData/Roaming/Auto-Key/Auto-Key.handoff",chosen.sourcePath.c_str());
 for(const int megabytes:{0,16,64}){
  const auto large=root/("handoff-"+std::to_string(megabytes)+".txt");
  {std::ofstream out(large,std::ios::binary);out<<"<VALUE name=\"key\" val=\"C\"/><VALUE name=\"scale\" val=\"Major\"/>\n";const std::string spaces(1024*1024,' ');for(int n=0;n<megabytes;++n)out<<spaces;}
  auto t=Clock::now();const auto result=AutoKeyHandoffReader::parseFile(large);
  const double elapsed=std::chrono::duration<double,std::milli>(Clock::now()-t).count();
  std::printf("HANDOFF bytes=%llu parse_ms=%.3f valid=%d\n",(unsigned long long)fs::file_size(large),elapsed,result.valid);
 }
}
