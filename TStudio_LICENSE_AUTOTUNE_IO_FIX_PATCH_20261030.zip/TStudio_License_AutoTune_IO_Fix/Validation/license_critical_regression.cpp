#include "licensing/LicenseManager.h"
#include <cstdio>
#include <stdexcept>
int main(){
 using namespace tak::license;int checks=0;auto check=[&](bool ok,const char* msg){++checks;if(!ok)throw std::runtime_error(msg);};
 const auto root=juce::File::getSpecialLocation(juce::File::tempDirectory).getChildFile("tstudio-license-critical-"+juce::Uuid().toString());
 struct Cleanup{juce::File root;~Cleanup(){root.deleteRecursively();}} cleanup{root};
 try{
 const juce::int64 now=juce::Time::getCurrentTime().toMilliseconds();juce::String pub,priv,error;check(createKeyPair(pub,priv,error),"fixture key");
 Configuration cfg{"TVOCALPACK","TSTUDIO","T Studio",pub,7,now-86400000LL};const juce::StringArray ids{"A1B2-C3D4-E5F6","1122-3344-5566"};
 auto paths=StorePaths::under(root,"blocked");const auto blocker=root.getChildFile("not-a-directory");root.createDirectory();check(blocker.replaceWithText("fixture"),"blocker");paths.trialRecords.set(3,blocker.getChildFile("mirror.dat"));
 LicenseManager manager(cfg,paths,ids);manager.requestAutomaticTrial();manager.poll(now);check(manager.isAllowed(),"trial starts with optional mirror blocked");
 const auto initial=paths.trialRecords[0].loadFileAsString();
 for(int t=1;t<60;++t){manager.poll(now+t*1000);check(paths.trialRecords[0].loadFileAsString()==initial,"no busy rewriting before 60 s");check(manager.isAllowed(),"trial stays available");}
 blocker.deleteFile();blocker.createDirectory();manager.poll(now+60000);check(paths.trialRecords[3].existsAsFile(),"repair retries at 60 s");check(paths.trialRecords[0].loadFileAsString()!=initial,"seen time advances at 60 s");
 // Tamper detection/persistence must stay immediate inside the backoff interval.
 check(paths.trialRecords[1].replaceWithText("corrupt fixture"),"corrupt a trial mirror");manager.poll(now+61000);check(!manager.isAllowed()&&manager.snapshot().tampered,"tamper detected immediately");
 LicenseManager reopened(cfg,paths,ids);reopened.poll(now+62000);check(!reopened.isAllowed()&&reopened.snapshot().tampered,"tamper survives reopening immediately");
 // A valid key still activates without waiting for the repair interval.
 Claims claims{"Test owner","TVOCALPACK","TSTUDIO",now,now+86400000LL,ids};const auto token=sign(claims,priv,error);check(token.isNotEmpty(),"sign fixture key");manager.requestActivation(token);manager.poll(now+63000);check(manager.isAllowed()&&manager.snapshot().activated,"paid key activates immediately");check(paths.license.loadFileAsString()==token,"paid key stored exactly");
 // The I/O backoff must not delay expiration in memory.
 manager.poll(now+86400000LL);check(!manager.isAllowed(),"expiry still occurs at exact boundary");
 std::printf("LICENSE CRITICAL REGRESSION: %d checks passed; repair backoff, recovery, immediate sticky tamper, immediate activation, expiry.\n",checks);return 0;
 }catch(const std::exception&e){std::fprintf(stderr,"FAIL after %d: %s\n",checks,e.what());return 1;}
}
