#include "licensing/LicenseManager.h"
#include <filesystem>
#include <cstdio>
#include <fstream>
#include <stdexcept>
int main(int argc,char**argv){
 if(argc!=2)return 2;
 namespace fs=std::filesystem;using namespace tak::license;
 const fs::path root(argv[1]);fs::create_directories(root);
 const juce::int64 now=juce::Time::getCurrentTime().toMilliseconds();
 Configuration cfg{"TVOCALPACK","TSTUDIO","T Studio",{},7,now-86400000LL};
 const juce::StringArray ids{"A1B2-C3D4-E5F6","1122-3344-5566"};
 for(bool blocked:{false,true}){
  auto dir=juce::File(root.string()).getChildFile(blocked?"blocked-mirror":"healthy");
  auto paths=StorePaths::under(dir,"test");
  if(blocked){const auto parent=dir.getChildFile("a-file-not-a-folder");parent.getParentDirectory().createDirectory();parent.replaceWithText("fixture");paths.trialRecords.set(3,parent.getChildFile("mirror.dat"));}
  LicenseManager manager(cfg,paths,ids);manager.requestAutomaticTrial();manager.poll(now);
  int rewrites=0;auto before=paths.trialRecords[0].loadFileAsString();
  for(int second=1;second<=20;++second){manager.poll(now+second*1000);auto after=paths.trialRecords[0].loadFileAsString();if(after!=before)++rewrites;before=after;}
  std::printf("LICENSE blocked_mirror=%d polls=20 observed_primary_rewrites=%d allowed=%d days=%d\n",blocked,rewrites,manager.isAllowed(),manager.snapshot().daysLeft);
  if(!manager.isAllowed()||manager.snapshot().daysLeft!=7)return 1;
 }
}
