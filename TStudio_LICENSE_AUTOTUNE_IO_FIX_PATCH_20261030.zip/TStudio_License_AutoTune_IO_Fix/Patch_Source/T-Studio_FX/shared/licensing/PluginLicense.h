// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "ProductConfig.h"

namespace tak::license {
// Drop-in license for any T Studio plugin. Same store, key and trial as
// T-AutoKey/T-AutoTune: activating any one of them unlocks this plugin too.
// All file access happens on this worker thread; the audio thread only reads
// an atomic flag through isAllowed().
class PluginLicense : private juce::Thread {
public:
    PluginLicense() : juce::Thread("TStudioLicense") { startThread(); }
    ~PluginLicense() override { signalThreadShouldExit(); notify(); stopThread(3000); }
    bool isAllowed() const noexcept { return manager.isAllowed(); }
    Snapshot snapshot() const { return manager.snapshot(); }
    void activate(const juce::String& text) { manager.requestActivation(text); pollNow(); }
    void startTrial() { manager.requestTrial(); pollNow(); }
    // Host scanning alone never starts the trial: call from the editor and
    // from the first non-empty audio block.
    void ensureAutomaticTrial() noexcept {
        if (!automaticRequested.exchange(true, std::memory_order_relaxed)) { manager.requestAutomaticTrial(); pollRequested.store(true); }
    }
private:
    void pollNow() { pollRequested.store(true); notify(); }
    void run() override {
        double next = 0;
        while (!threadShouldExit()) {
            const auto now = juce::Time::getCurrentTime().toMilliseconds();
            const auto ticks = juce::Time::getMillisecondCounterHiRes();
            if (pollRequested.exchange(false) || ticks >= next) { manager.poll(now); next = ticks + 1000; }
            wait(100);
        }
    }
    LicenseManager manager { productConfiguration(), productStore() };
    std::atomic<bool> pollRequested { true }, automaticRequested { false };
};
}
