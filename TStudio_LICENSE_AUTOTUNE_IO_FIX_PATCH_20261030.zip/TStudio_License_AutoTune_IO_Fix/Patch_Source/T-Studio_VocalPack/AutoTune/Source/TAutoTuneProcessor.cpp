#include "TAutoTuneProcessor.h"
#include "TAutoTuneEditor.h"
#include <algorithm>
#include <cmath>

namespace
{
    static constexpr double kPi = 3.14159265358979323846;

    static const int kScaleMasks[29][12] = {
        {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1}, // 0: MAJOR
        {1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0}, // 1: MINOR
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, // 2: CHROMATIC
        {1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1}, // 3: HARMONIC MINOR
        {1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1}, // 4: MELODIC MINOR
        {1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0}, // 5: DORIAN
        {1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0}, // 6: PHRYGIAN
        {1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1}, // 7: LYDIAN
        {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0}, // 8: MIXOLYDIAN
        {1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0}, // 9: LOCRIAN
        {1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0}, // 10: PENTATONIC MAJOR
        {1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0}, // 11: PENTATONIC MINOR
        {1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0}, // 12: BLUES
        {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0}, // 13: WHOLE TONE
        {1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1}, // 14: OCTATONIC (W-H)
        {1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0}, // 15: OCTATONIC (H-W)
        {1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0}, // 16: PHRYGIAN DOMINANT
        {1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1}, // 17: HUNGARIAN MINOR
        {1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1}, // 18: DOUBLE HARMONIC (ARABIC)
        {1, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0}, // 19: IN SEN (JAPANESE)
        {1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0}, // 20: HIRAJOSHI
        {1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0}, // 21: HIJAZ
        {1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0}, // 22: LYDIAN DOMINANT
        {1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0}, // 23: ALTERED
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0}, // 24: MIXOLYDIAN b6
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1}, // 25: HARMONIC MAJOR
        {1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0}, // 26: BEBOP DOMINANT
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1}, // 27: BEBOP MAJOR
        {1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1}  // 28: RYUKYU (OKINAWAN)
    };
}

//==============================================================================
//==============================================================================
void TAutoTuneChannelDSP::prepare(double newSampleRate)
{
    sampleRate = std::max(8000.0, newSampleRate);

    if (sampleRate > 128000.0)
        downsampleFactor = 4;
    else if (sampleRate > 64000.0)
        downsampleFactor = 2;
    else
        downsampleFactor = 1;

    analysisRate = sampleRate / static_cast<double>(downsampleFactor);

    const double aaCutoff = 0.42 * analysisRate;
    static const double kStageQ[6] = { 0.5176, 0.7071, 1.9319, 0.5176, 0.7071, 1.9319 };
    for (int i = 0; i < 6; ++i)
    {
        downsampleFilters[static_cast<size_t>(i)].setLowpass(aaCutoff, sampleRate, kStageQ[i]);
        downsampleFilters[static_cast<size_t>(i)].reset();
    }

    lpcOrder = (sampleRate >= 88200.0) ? 16 : 12;
    preEmphasisPole = std::exp(-2.0 * kPi * 300.0 / sampleRate);

    currentVoiceType = -1;
    updateVoiceTypeFilters(1);
    reset();
}

void TAutoTuneChannelDSP::reset()
{
    for (auto& f : downsampleFilters)
        f.reset();

    inputLP1.reset();
    inputLP2.reset();
    inputHP1.reset();
    shiftLP1.reset();
    shiftLP2.reset();
    shiftLP1.setLowpass(0.49 * sampleRate, sampleRate, 0.7071067811865475);
    shiftLP2.setLowpass(0.49 * sampleRate, sampleRate, 0.7071067811865475);

    detectorRing.fill(0.0);
    detWriteIdx = 0;

    decRing.fill(0.0);
    decEnergy.fill(0.0);
    decCorr.fill(0.0);
    decWriteIdx = 0;
    decSampleCount = 0;

    trackEnergy.fill(0.0);
    trackCorr.fill(0.0);
    baseLag = 100;
    needAcquisition = true;
    voicedState = false;

    downsampleCounter = 0;
    updateSubCounter = 0;

    currentPeriodSamples = analysisRate / 200.0;
    smoothedPeriodSamples = currentPeriodSamples;
    fastPitchMidi = 60.0;
    slowPitchMidi = 60.0;
    lockedTargetNote = -1;
    sustainedNoteFrames = 0;
    smoothedPitchRatio = 1.0;

    vibPhase = 0.0;
    vibNoteOnsetSec = 0.0;

    preEmpZ1 = 0.0;
    deEmpZ1 = 0.0;
    lpcAnalysisWin.fill(0.0);
    lpcWinWriteIdx = 0;
    lpcSampleCounter = 0;
    prevLpcA.fill(0.0);
    currLpcA.fill(0.0);
    prevLpcWarpedA.fill(0.0);
    currLpcWarpedA.fill(0.0);
    prevLpcA[0] = 1.0;
    currLpcA[0] = 1.0;
    prevLpcWarpedA[0] = 1.0;
    currLpcWarpedA[0] = 1.0;
    invFilterHist.fill(0.0);
    synFilterHist.fill(0.0);

    rawInputRing.fill(0.0);
    residualRing.fill(0.0);
    psolaWriteIdx = 0;
    relDelayA = std::clamp(sampleRate * 0.0055, 64.0, 512.0);
    relDelayB = relDelayA;
    crossfadeAlpha = 1.0;
    crossfadeStep = 0.0;
    smoothedWetMix = 1.0;

    lastDetectedMidi = -1.0f;
    lastTargetMidi = -1.0f;
    lastCentsCorrection = 0.0f;
}

void TAutoTuneChannelDSP::updateVoiceTypeFilters(int voiceType)
{
    if (voiceType == currentVoiceType)
        return;

    currentVoiceType = voiceType;

    // Exact Input Voice Type cutoffs and tracking window half-width W ([rcx+0x1488])
    //   0 = SOPRANO    (fc1 = 600 Hz,  fc2 = 1200 Hz, W = 12..15)
    //   1 = ALTO/TENOR (fc1 = 400 Hz,  fc2 = 800 Hz,  W = 15)
    //   2 = LOW MALE   (fc1 = 300 Hz,  fc2 = 600 Hz,  W = 30)
    //   3 = INSTRUMENT (fc1 = 1000 Hz, fc2 = 2000 Hz, W = 12)
    //   4 = BASS INST  (fc1 = 200 Hz,  fc2 = 400 Hz,  W = 30)
    double lpCutoff1 = 400.0;
    trackHalfWin = 15;
    switch (voiceType)
    {
        case 0: // Soprano
            lpCutoff1 = 600.0;  trackHalfWin = 12;
            break;
        case 1: // Alto / Tenor
            lpCutoff1 = 400.0;  trackHalfWin = 15;
            break;
        case 2: // Low Male
            lpCutoff1 = 300.0;  trackHalfWin = 30;
            break;
        case 3: // Instrument
            lpCutoff1 = 1000.0; trackHalfWin = 12;
            break;
        case 4: // Bass Inst
        default:
            lpCutoff1 = 200.0;  trackHalfWin = 30;
            break;
    }

    const double lpCutoff2 = 2.0 * lpCutoff1;
    inputLP1.setLowpass(lpCutoff1, analysisRate, 0.7071067811865475);
    inputLP2.setLowpass(lpCutoff2, analysisRate, 0.7071067811865475);
    inputHP1.setHighpass(30.0,     analysisRate, 0.7071067811865475);

    minPeriodSamples = std::max(16.0, analysisRate / (lpCutoff2 * 0.95));
    maxPeriodSamples = std::min(1900.0, analysisRate / 45.0);
}

//==============================================================================
//==============================================================================
int TAutoTuneChannelDSP::acquireCoarsePeriod8x(double xFiltered, double trackingThreshold) noexcept
{
    const double x2 = xFiltered * xFiltered;
    decRing[static_cast<size_t>(decWriteIdx)] = xFiltered;

    for (int k = 1; k < kMaxDecLag; ++k)
    {
        const double xLag  = decRing[static_cast<size_t>((decWriteIdx - k) & kDecRingMask)];
        const double x2Lag = decRing[static_cast<size_t>((decWriteIdx - 2 * k) & kDecRingMask)];
        decEnergy[static_cast<size_t>(k)] = std::max(0.0, decEnergy[static_cast<size_t>(k)] + x2 - x2Lag * x2Lag);
        decCorr[static_cast<size_t>(k)]   += xFiltered * xLag - xLag * x2Lag;
    }

    decWriteIdx = (decWriteIdx + 1) & kDecRingMask;
    if (++decSampleCount < 32)
        return 0;

    // Exact periodic refresh of decEnergy & decCorr to eliminate floating-point drift
    if ((decSampleCount & 255) == 0)
    {
        for (int k = 1; k < kMaxDecLag; ++k)
        {
            double e = 0.0, c = 0.0;
            for (int m = 0; m < k; ++m)
            {
                const double s0 = decRing[static_cast<size_t>((decWriteIdx - 1 - m) & kDecRingMask)];
                const double s1 = decRing[static_cast<size_t>((decWriteIdx - 1 - m - k) & kDecRingMask)];
                e += s0 * s0 + s1 * s1;
                c += s0 * s1;
            }
            decEnergy[static_cast<size_t>(k)] = e;
            decCorr[static_cast<size_t>(k)]   = c;
        }
    }

    const int minK = std::max(2, static_cast<int>(std::floor(minPeriodSamples / 8.0)));
    const int maxK = std::min(kMaxDecLag - 2, static_cast<int>(std::ceil(maxPeriodSamples / 8.0)));

    if (decEnergy[static_cast<size_t>(minK)] < 1.0e-6)
        return 0;

    std::array<double, kMaxDecLag> normDiff {};
    normDiff.fill(1.0);
    for (int k = minK - 1; k <= maxK + 1; ++k)
    {
        const double e = decEnergy[static_cast<size_t>(k)];
        if (e > 1.0e-7)
            normDiff[static_cast<size_t>(k)] = (0.5 * e - decCorr[static_cast<size_t>(k)]) / e;
    }

    double minima[3] = { 0.0, 0.0, 0.0 };
    int numMinima = 0;

    int k = minK;
    while (k < maxK && normDiff[static_cast<size_t>(k)] > 0.35)
        ++k;

    for (; k < maxK && numMinima < 3; ++k)
    {
        const double ym1 = normDiff[static_cast<size_t>(k - 1)];
        const double y0  = normDiff[static_cast<size_t>(k)];
        const double yp1 = normDiff[static_cast<size_t>(k + 1)];

        if (y0 < ym1 && y0 <= yp1 && y0 < trackingThreshold)
        {
            const double denom = ym1 - 2.0 * y0 + yp1;
            double delta = 0.0;
            if (std::abs(denom) > 1.0e-9)
                delta = std::clamp(0.5 * (ym1 - yp1) / denom, -0.5, 0.5);

            const double interpVal = y0 - 0.25 * (ym1 - yp1) * delta;
            if (interpVal < trackingThreshold)
                minima[numMinima++] = (static_cast<double>(k) + delta) * 8.0;
        }
    }

    if (numMinima == 0)
        return 0;

    double estPeriod = 0.0;
    if (numMinima >= 3)
    {
        const double d1 = minima[0];
        const double d2 = minima[1] - minima[0];
        const double d3 = minima[2] - minima[1];
        if (std::abs(d1 - d2) < 0.12 * d1 && std::abs(d2 - d3) < 0.12 * d1)
            estPeriod = minima[2] / 3.0;
        else if (std::abs(d2 - d3) < 0.12 * d2)
            estPeriod = (d2 + d3) * 0.5;
        else if (std::abs(d1 - d2) < 0.12 * d1)
            estPeriod = minima[1] * 0.5;
    }
    else if (numMinima == 2)
    {
        const double d1 = minima[0];
        const double d2 = minima[1] - minima[0];
        if (std::abs(d1 - d2) < 0.12 * d1)
            estPeriod = minima[1] * 0.5;
    }
    else if (numMinima == 1 && minima[0] >= minPeriodSamples)
    {
        estPeriod = minima[0];
    }

    if (estPeriod < minPeriodSamples || estPeriod > maxPeriodSamples)
        return 0;

    const int newBaseLag = static_cast<int>(std::round(estPeriod)) - trackHalfWin;
    return std::max(4, newBaseLag);
}

//==============================================================================
//==============================================================================
bool TAutoTuneChannelDSP::initTrackingWindow(int newBaseLag) noexcept
{
    baseLag = std::max(4, newBaseLag);
    const int numBins = 2 * trackHalfWin;

    for (int k = 0; k < numBins; ++k)
    {
        const int tau = baseLag + k;
        double e = 0.0;
        double c = 0.0;
        for (int m = 0; m < 2 * tau; ++m)
        {
            const double s = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m) & kRingMask)];
            e += s * s;
        }
        for (int m = 0; m < tau; ++m)
        {
            const double s0 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m) & kRingMask)];
            const double s1 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m - tau) & kRingMask)];
            c += s0 * s1;
        }
        trackEnergy[static_cast<size_t>(k)] = e;
        trackCorr[static_cast<size_t>(k)]   = c;
    }

    if (trackEnergy[0] < 1.65e-5)
    {
        needAcquisition = true;
        return false;
    }

    updateSubCounter = 4;
    needAcquisition = false;
    return true;
}

//==============================================================================
//==============================================================================
double TAutoTuneChannelDSP::refineAndSlideTrackingWindow(int& bestIdx) noexcept
{
    const int W = trackHalfWin;
    const int numBins = 2 * W;

    if (bestIdx < W - 1 && baseLag > 4)
    {
        baseLag -= 1;
        bestIdx += 1;
        for (int i = numBins - 1; i >= 1; --i)
        {
            trackEnergy[static_cast<size_t>(i)] = trackEnergy[static_cast<size_t>(i - 1)];
            trackCorr[static_cast<size_t>(i)]   = trackCorr[static_cast<size_t>(i - 1)];
        }
        const int tau0 = baseLag;
        double e0 = 0.0, c0 = 0.0;
        for (int m = 0; m < 2 * tau0; ++m)
        {
            const double s = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m) & kRingMask)];
            e0 += s * s;
        }
        for (int m = 0; m < tau0; ++m)
        {
            const double s0 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m) & kRingMask)];
            const double s1 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m - tau0) & kRingMask)];
            c0 += s0 * s1;
        }
        trackEnergy[0] = e0;
        trackCorr[0]   = c0;
    }
    else if (bestIdx > W && (baseLag + numBins) < (kRingSize / 2 - 4))
    {
        baseLag += 1;
        bestIdx -= 1;
        for (int i = 0; i < numBins - 1; ++i)
        {
            trackEnergy[static_cast<size_t>(i)] = trackEnergy[static_cast<size_t>(i + 1)];
            trackCorr[static_cast<size_t>(i)]   = trackCorr[static_cast<size_t>(i + 1)];
        }
        const int tauLast = baseLag + numBins - 1;
        double eL = 0.0, cL = 0.0;
        for (int m = 0; m < 2 * tauLast; ++m)
        {
            const double s = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m) & kRingMask)];
            eL += s * s;
        }
        for (int m = 0; m < tauLast; ++m)
        {
            const double s0 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m) & kRingMask)];
            const double s1 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - m - tauLast) & kRingMask)];
            cL += s0 * s1;
        }
        trackEnergy[static_cast<size_t>(numBins - 1)] = eL;
        trackCorr[static_cast<size_t>(numBins - 1)]   = cL;
    }

    const int idx = std::clamp(bestIdx, 1, numBins - 2);
    const double ym1 = 0.5 * trackEnergy[static_cast<size_t>(idx - 1)] - trackCorr[static_cast<size_t>(idx - 1)];
    const double y0  = 0.5 * trackEnergy[static_cast<size_t>(idx)]     - trackCorr[static_cast<size_t>(idx)];
    const double yp1 = 0.5 * trackEnergy[static_cast<size_t>(idx + 1)] - trackCorr[static_cast<size_t>(idx + 1)];

    const double denom = ym1 - 2.0 * y0 + yp1;
    double delta = 0.0;
    if (std::abs(denom) > 1.0e-9)
        delta = std::clamp(0.5 * (ym1 - yp1) / denom, -0.5, 0.5);

    return static_cast<double>(baseLag + idx) + delta;
}

//==============================================================================
// Kelly-Lochbaum Vocal Tract Tube + Levinson-Durbin LPC Formant & Throat Modeling
//==============================================================================
void TAutoTuneChannelDSP::analyzeLPCAndThroat(double pitchPeriodSamples, double effectiveThroatRatio) noexcept
{
    prevLpcA = currLpcA;
    prevLpcWarpedA = currLpcWarpedA;

    const int N = 256;
    const int p = lpcOrder;
    std::array<double, 256> winSig {};

    for (int n = 0; n < N; ++n)
    {
        const int idx = (lpcWinWriteIdx - N + n + 512) & 511;
        const double w = 0.5 * (1.0 - std::cos(2.0 * kPi * static_cast<double>(n) / static_cast<double>(N - 1)));
        winSig[static_cast<size_t>(n)] = lpcAnalysisWin[static_cast<size_t>(idx)] * w;
    }

    std::array<double, kMaxLPCOrder + 1> R {};
    const double T0 = std::clamp(pitchPeriodSamples * downsampleFactor, 20.0, 1000.0);
    for (int k = 0; k <= p; ++k)
    {
        double sum = 0.0;
        for (int n = k; n < N; ++n)
            sum += winSig[static_cast<size_t>(n)] * winSig[static_cast<size_t>(n - k)];

        double lagWin = 1.0;
        if (k > 0)
        {
            const double x = (static_cast<double>(k) * kPi) / T0;
            const double sinc = std::sin(x) / x;
            lagWin = sinc * sinc;
        }
        R[static_cast<size_t>(k)] = sum * lagWin;
    }

    if (R[0] < 1.0e-8)
    {
        currLpcA.fill(0.0);
        currLpcWarpedA.fill(0.0);
        currLpcA[0] = 1.0;
        currLpcWarpedA[0] = 1.0;
        return;
    }

    // Diagonal loading for unconditionally stable all-pole synthesis
    R[0] *= 1.005;

    std::array<double, kMaxLPCOrder + 1> a {};
    std::array<double, kMaxLPCOrder + 1> aPrev {};
    std::array<double, kMaxLPCOrder + 1> kRefl {};
    a[0] = 1.0;
    double E = R[0];

    for (int i = 1; i <= p; ++i)
    {
        double acc = R[static_cast<size_t>(i)];
        for (int j = 1; j < i; ++j)
            acc += a[static_cast<size_t>(j)] * R[static_cast<size_t>(i - j)];

        double ki = -acc / std::max(E, 1.0e-12);
        ki = std::clamp(ki, -0.97, 0.97);
        kRefl[static_cast<size_t>(i)] = ki;

        aPrev = a;
        a[static_cast<size_t>(i)] = ki;
        for (int j = 1; j < i; ++j)
            a[static_cast<size_t>(j)] = aPrev[static_cast<size_t>(j)] + ki * aPrev[static_cast<size_t>(i - j)];

        E *= (1.0 - ki * ki);
        if (E <= 1.0e-12)
            break;
    }

    // Bandwidth expansion (gamma = 0.990^i) to prevent sharp formant ringing on loud vocals
    double gammaPow = 1.0;
    for (int i = 1; i <= p; ++i)
    {
        gammaPow *= 0.990;
        a[static_cast<size_t>(i)] *= gammaPow;
    }
    currLpcA = a;

    std::array<double, kMaxLPCOrder + 1> tubeArea {};
    tubeArea[0] = 1.0;
    for (int i = 1; i <= p; ++i)
    {
        const double ki = std::clamp(kRefl[static_cast<size_t>(i)], -0.97, 0.97);
        tubeArea[static_cast<size_t>(i)] = tubeArea[static_cast<size_t>(i - 1)] * ((1.0 - ki) / (1.0 + ki));
    }

    std::array<double, kMaxLPCOrder + 1> warpedArea {};
    warpedArea[0] = tubeArea[0];
    const double stretch = std::clamp(effectiveThroatRatio, 0.50, 1.90);

    for (int i = 1; i <= p; ++i)
    {
        const double srcPos = std::clamp(static_cast<double>(i) / stretch, 0.0, static_cast<double>(p));
        const int idx0 = static_cast<int>(std::floor(srcPos));
        const int idx1 = std::min(p, idx0 + 1);
        const double frac = srcPos - static_cast<double>(idx0);
        warpedArea[static_cast<size_t>(i)] =
            tubeArea[static_cast<size_t>(idx0)] * (1.0 - frac) + tubeArea[static_cast<size_t>(idx1)] * frac;
    }

    std::array<double, kMaxLPCOrder + 1> aWarped {};
    aWarped[0] = 1.0;

    for (int i = 1; i <= p; ++i)
    {
        const double Aprev = std::max(1.0e-9, warpedArea[static_cast<size_t>(i - 1)]);
        const double Acurr = std::max(1.0e-9, warpedArea[static_cast<size_t>(i)]);
        double kw = (Aprev - Acurr) / (Aprev + Acurr);
        kw = std::clamp(kw, -0.97, 0.97);

        aPrev = aWarped;
        aWarped[static_cast<size_t>(i)] = kw;
        for (int j = 1; j < i; ++j)
            aWarped[static_cast<size_t>(j)] = aPrev[static_cast<size_t>(j)] + kw * aPrev[static_cast<size_t>(i - j)];
    }

    gammaPow = 1.0;
    for (int i = 1; i <= p; ++i)
    {
        gammaPow *= 0.990;
        aWarped[static_cast<size_t>(i)] *= gammaPow;
    }
    currLpcWarpedA = aWarped;
}

double TAutoTuneChannelDSP::inverseFilterLPC(double x, double alpha) noexcept
{
    const double wPrev = 1.0 - alpha;
    double res = x;
    for (int i = 1; i <= lpcOrder; ++i)
    {
        const double ai = wPrev * prevLpcA[static_cast<size_t>(i)] + alpha * currLpcA[static_cast<size_t>(i)];
        res += ai * invFilterHist[static_cast<size_t>(i)];
    }

    for (int i = lpcOrder; i >= 2; --i)
        invFilterHist[static_cast<size_t>(i)] = invFilterHist[static_cast<size_t>(i - 1)];
    invFilterHist[1] = x;
    return res;
}

double TAutoTuneChannelDSP::synthesizeThroatLPC(double excitation, double alpha) noexcept
{
    const double wPrev = 1.0 - alpha;
    double y = excitation;
    for (int i = 1; i <= lpcOrder; ++i)
    {
        const double ai = wPrev * prevLpcWarpedA[static_cast<size_t>(i)] + alpha * currLpcWarpedA[static_cast<size_t>(i)];
        y -= ai * synFilterHist[static_cast<size_t>(i)];
    }

    if (!std::isfinite(y) || std::abs(y) > 4.0)
        y = std::clamp(excitation, -1.5, 1.5);

    for (int i = lpcOrder; i >= 2; --i)
        synFilterHist[static_cast<size_t>(i)] = synFilterHist[static_cast<size_t>(i - 1)];
    synFilterHist[1] = y;
    return y;
}

// C1-Continuous 4-Point Cubic Hermite (Catmull-Rom) Sub-Sample Interpolation
double TAutoTuneChannelDSP::readCubicHermite(const std::array<double, kRingSize>& buf, double readPos) const noexcept
{
    const int idx0 = static_cast<int>(std::floor(readPos));
    const double t = readPos - static_cast<double>(idx0);

    const double ym1 = buf[static_cast<size_t>((idx0 - 1) & kRingMask)];
    const double y0  = buf[static_cast<size_t>(idx0 & kRingMask)];
    const double y1  = buf[static_cast<size_t>((idx0 + 1) & kRingMask)];
    const double y2  = buf[static_cast<size_t>((idx0 + 2) & kRingMask)];

    const double c0 = y0;
    const double c1 = 0.5 * (y1 - ym1);
    const double c2 = ym1 - 2.5 * y0 + 2.0 * y1 - 0.5 * y2;
    const double c3 = 0.5 * (y2 - ym1) + 1.5 * (y0 - y1);

    return ((c3 * t + c2) * t + c1) * t + c0;
}

// Phase-Locked TD-PSOLA Splice Alignment around nominal +/- T0Full jump
double TAutoTuneChannelDSP::findBestSpliceDelay(const std::array<double, kRingSize>& buf,
                                                      double currentDelay,
                                                      double nominalTargetDelay,
                                                      double T0Full) const noexcept
{
    const int searchRange = std::clamp(static_cast<int>(0.08 * T0Full), 2, 16);
    const int matchLen = 16;
    double bestCandidate = nominalTargetDelay;
    double minErr = 1.0e18;

    const double curReadPos = static_cast<double>(psolaWriteIdx) - currentDelay;
    for (int offset = -searchRange; offset <= searchRange; ++offset)
    {
        const double candDelay = nominalTargetDelay + static_cast<double>(offset);
        if (candDelay < 24.0 || candDelay > static_cast<double>(kRingSize - 64))
            continue;
        const double candReadPos = static_cast<double>(psolaWriteIdx) - candDelay;
        double err = 0.0;
        for (int m = 0; m < matchLen; ++m)
        {
            const int iA = (static_cast<int>(std::floor(curReadPos))  + m) & kRingMask;
            const int iB = (static_cast<int>(std::floor(candReadPos)) + m) & kRingMask;
            const double d = buf[static_cast<size_t>(iA)] - buf[static_cast<size_t>(iB)];
            err += d * d;
        }
        if (err < minErr)
        {
            minErr = err;
            bestCandidate = candDelay;
        }
    }
    return bestCandidate;
}

//==============================================================================
//==============================================================================
float TAutoTuneChannelDSP::processSample(
    float inputSample,
    int voiceType,
    int keyIdx,
    int scaleIdx,
    const std::array<int, 12>& noteStates,
    const std::array<int, 12>& noteCents,
    bool classicMode,
    bool useFormants,
    double throatLengthPct,
    bool ratioLock,
    double transposeSemi,
    double detuneCents,
    double trackingVal,
    double retuneSpeedMs,
    double flexTuneVal,
    double naturalVibDb,
    double humanizeVal,
    bool ignoreVibrato,
    int vibShape,
    double vibRateHz,
    double vibDelayMs,
    double vibTransMs,
    double vibVarVal,
    double vibPitchCents,
    double vibAmpVal,
    double vibFormantVal,
    double wetDryMixPct,
    int frozenMidiNote)
{
    (void)keyIdx;
    (void)scaleIdx;
    updateVoiceTypeFilters(voiceType);
    const double xIn = static_cast<double>(inputSample);

    // -------------------------------------------------------------------------
    // -------------------------------------------------------------------------
    double xAA = xIn;
    if (downsampleFactor > 1)
    {
        for (auto& f : downsampleFilters)
            xAA = f.process(xAA);
    }

    double synVibFormantRatio = 1.0;
    double synVibAmpGain = 1.0;

    if (++downsampleCounter >= downsampleFactor)
    {
        downsampleCounter = 0;

        const double xFiltered = inputHP1.process(inputLP2.process(inputLP1.process(xAA)));
        detectorRing[static_cast<size_t>(detWriteIdx)] = xFiltered;

        const double trackingThresh = std::clamp(0.32 - 0.0022 * (100.0 - trackingVal), 0.08, 0.35);

        if (needAcquisition)
        {
            if ((detWriteIdx & 7) == 0)
            {
                const int coarseLag = acquireCoarsePeriod8x(xFiltered, trackingThresh);
                if (coarseLag > 0)
                    initTrackingWindow(coarseLag);
            }
        }
        else
        {
            const int numBins = 2 * trackHalfWin;
            const double xn2 = xFiltered * xFiltered;
            for (int k = 0; k < numBins; ++k)
            {
                const int tau = baseLag + k;
                const double xTau  = detectorRing[static_cast<size_t>((detWriteIdx - tau) & kRingMask)];
                const double x2Tau = detectorRing[static_cast<size_t>((detWriteIdx - 2 * tau) & kRingMask)];
                trackEnergy[static_cast<size_t>(k)] =
                    std::max(0.0, trackEnergy[static_cast<size_t>(k)] + xn2 - x2Tau * x2Tau);
                trackCorr[static_cast<size_t>(k)] += xFiltered * xTau - xTau * x2Tau;
            }

            if (++updateSubCounter >= 5)
            {
                updateSubCounter = 0;

                int bestIdx = 0;
                double minVal = 0.5 * trackEnergy[0] - trackCorr[0];
                for (int k = 1; k < numBins; ++k)
                {
                    const double val = 0.5 * trackEnergy[static_cast<size_t>(k)] - trackCorr[static_cast<size_t>(k)];
                    if (val < minVal)
                    {
                        minVal = val;
                        bestIdx = k;
                    }
                }

                const double bestEnergy = trackEnergy[static_cast<size_t>(bestIdx)];

                if (bestIdx == 0 || bestIdx == numBins - 1
                    || bestEnergy < 1.5e-5
                    || minVal > (2.0 * trackingThresh * bestEnergy))
                {
                    needAcquisition = true;
                    voicedState = false;
                    sustainedNoteFrames = 0;
                    smoothedPitchRatio = 0.92 * smoothedPitchRatio + 0.08 * 1.0;
                    lastCentsCorrection *= 0.85f;
                }
                else
                {
                    const double detectedPeriod = refineAndSlideTrackingWindow(bestIdx);
                    currentPeriodSamples = std::clamp(detectedPeriod, minPeriodSamples, maxPeriodSamples);
                    smoothedPeriodSamples = voicedState
                        ? (0.70 * smoothedPeriodSamples + 0.30 * currentPeriodSamples)
                        : currentPeriodSamples;

                    const double refA4Hz = 440.0 * std::pow(2.0, detuneCents / 1200.0);
                    const double detectedHz = analysisRate / smoothedPeriodSamples;
                    const double rawMidi = 69.0 + 12.0 * std::log2(std::max(20.0, detectedHz) / refA4Hz);

                    if (!voicedState)
                    {
                        fastPitchMidi = rawMidi;
                        slowPitchMidi = rawMidi;
                        voicedState = true;
                    }
                    else
                    {
                        fastPitchMidi = 0.65 * fastPitchMidi + 0.35 * rawMidi;
                        slowPitchMidi = 0.965 * slowPitchMidi + 0.035 * rawMidi;
                    }

                    lastDetectedMidi = static_cast<float>(fastPitchMidi);

                    const double pitchForTarget = ignoreVibrato ? slowPitchMidi : fastPitchMidi;

                    int bestMidiNote = static_cast<int>(std::round(pitchForTarget));
                    double minDist = 1.0e9;
                    bool bestIsBypassed = false;

                    if (frozenMidiNote >= 0)
                    {
                        bestMidiNote = frozenMidiNote;
                        bestIsBypassed = false;
                    }
                    else
                    {
                        const int baseMidi = static_cast<int>(std::floor(pitchForTarget)) - 12;
                        for (int m = baseMidi; m <= baseMidi + 24; ++m)
                        {
                            const int pc = ((m % 12) + 12) % 12;
                            const int st = noteStates[static_cast<size_t>(pc)];
                            if (st == TAutoTuneProcessor::kNoteRemoved)
                                continue;

                            const double noteWithMicroCents = static_cast<double>(m) + 0.01 * static_cast<double>(noteCents[static_cast<size_t>(pc)]);
                            double dist = std::abs(pitchForTarget - noteWithMicroCents);
                            if (m == lockedTargetNote)
                                dist -= 0.15;

                            if (dist < minDist)
                            {
                                minDist = dist;
                                bestMidiNote = m;
                                bestIsBypassed = (st == TAutoTuneProcessor::kNoteBypassed);
                            }
                        }
                    }

                    if (bestMidiNote == lockedTargetNote)
                        sustainedNoteFrames++;
                    else
                    {
                        lockedTargetNote = bestMidiNote;
                        sustainedNoteFrames = 0;
                        vibNoteOnsetSec = 0.0;
                    }

                    const int bestPc = ((bestMidiNote % 12) + 12) % 12;
                    const double microOffsetSemi = 0.01 * static_cast<double>(noteCents[static_cast<size_t>(bestPc)]);
                    const double exactNoteMidi = static_cast<double>(bestMidiNote) + microOffsetSemi;

                    double targetMidi = bestIsBypassed ? fastPitchMidi : exactNoteMidi;

                    if (!bestIsBypassed && !classicMode && flexTuneVal > 0.0 && frozenMidiNote < 0)
                    {
                        const double flexNorm = std::clamp(flexTuneVal / 100.0, 0.0, 1.0);
                        const double devSemi = fastPitchMidi - exactNoteMidi;
                        const double captureWidth = 0.15 + 0.85 * (1.0 - flexNorm);
                        const double pull = std::exp(-(devSemi * devSemi) / std::max(0.02, captureWidth * captureWidth));
                        const double effectivePull = pull * (1.0 - 0.75 * flexNorm);
                        targetMidi = fastPitchMidi + effectivePull * (exactNoteMidi - fastPitchMidi);
                    }

                    // Natural Vibrato scaling (-12..+12 dB)
                    if (frozenMidiNote < 0)
                    {
                        const double vibComponent = fastPitchMidi - slowPitchMidi;
                        const double natVibGain = std::pow(10.0, naturalVibDb / 20.0);
                        targetMidi += vibComponent * (natVibGain - 1.0);
                    }

                    const double activeTranspose = classicMode ? 0.0 : transposeSemi;

                    // Synthetic Vibrato LFO
                    double synVibSemi = 0.0;
                    const double dtControl = 5.0 / sampleRate;
                    vibNoteOnsetSec += dtControl;

                    if (vibShape > 0 && (vibPitchCents > 0.0 || vibAmpVal > 0.0 || vibFormantVal > 0.0))
                    {
                        const double delaySec = vibDelayMs * 0.001;
                        const double transSec = std::max(0.001, vibTransMs * 0.001);
                        double env = 0.0;
                        if (vibNoteOnsetSec > delaySec)
                            env = std::clamp((vibNoteOnsetSec - delaySec) / transSec, 0.0, 1.0);

                        rngState = rngState * 1664525u + 1013904223u;
                        const double randBipolar = (static_cast<double>(rngState & 0xFFFFu) / 32768.0) - 1.0;
                        const double instRate = std::max(0.1, vibRateHz * (1.0 + 0.0015 * vibVarVal * randBipolar));
                        vibPhase += instRate * dtControl;
                        vibPhase -= std::floor(vibPhase);

                        double lfo = 0.0;
                        if (vibShape == 1)
                            lfo = std::sin(2.0 * kPi * vibPhase);
                        else if (vibShape == 2)
                            lfo = (vibPhase < 0.5) ? 1.0 : -1.0;
                        else
                            lfo = 2.0 * vibPhase - 1.0;

                        synVibSemi = env * (vibPitchCents / 100.0) * lfo;
                        synVibFormantRatio = 1.0 + env * (vibFormantVal / 100.0) * 0.06 * lfo;
                        synVibAmpGain = 1.0 + env * (vibAmpVal / 100.0) * 0.18 * lfo;
                    }

                    const double finalTargetMidi = targetMidi + activeTranspose + synVibSemi;
                    const double rawTargetRatio = std::pow(2.0, (finalTargetMidi - fastPitchMidi) / 12.0);

                    const double fUpdate = sampleRate / 5.0;
                    const double retuneCoeff = (retuneSpeedMs <= 0.001)
                        ? 0.0
                        : std::pow(0.5, 1.0 / std::max(1.0, fUpdate * (retuneSpeedMs * 0.001)));

                    double smoothCoeff = retuneCoeff;
                    if (humanizeVal > 0.0)
                    {
                        const double humanizeExtraMs = (humanizeVal / 100.0) * 250.0;
                        const double humanizeCoeff = std::pow(
                            0.5, 1.0 / std::max(1.0, fUpdate * ((retuneSpeedMs + humanizeExtraMs) * 0.001)));
                        const int rampFrames = std::max(1, static_cast<int>((sampleRate * 0.4) / 5.0));
                        const double rampFrac = std::clamp(
                            static_cast<double>(sustainedNoteFrames) / static_cast<double>(rampFrames), 0.0, 1.0);
                        smoothCoeff = retuneCoeff + rampFrac * (humanizeCoeff - retuneCoeff);
                    }

                    smoothedPitchRatio = smoothCoeff * smoothedPitchRatio + (1.0 - smoothCoeff) * rawTargetRatio;
                    smoothedPitchRatio = std::clamp(smoothedPitchRatio, 0.5, 2.0);

                    lastTargetMidi = static_cast<float>(finalTargetMidi - activeTranspose);
                    lastCentsCorrection = static_cast<float>(
                        std::clamp(1200.0 * std::log2(smoothedPitchRatio) - activeTranspose * 100.0, -100.0, 100.0));

                    const double shiftCutoff = (smoothedPitchRatio > 1.0)
                        ? ((0.49 * sampleRate) / smoothedPitchRatio)
                        : (0.49 * sampleRate);
                    shiftLP1.setLowpass(shiftCutoff, sampleRate, 0.7071067811865475);
                    shiftLP2.setLowpass(shiftCutoff, sampleRate, 0.7071067811865475);
                }
            }
        }

        detWriteIdx = (detWriteIdx + 1) & kRingMask;
    }
    else if (needAcquisition)
    {
        if (++updateSubCounter >= 5)
        {
            updateSubCounter = 0;
            smoothedPitchRatio = 0.92 * smoothedPitchRatio + 0.08 * 1.0;
            lastCentsCorrection *= 0.85f;
        }
    }

    // -------------------------------------------------------------------------
    // 2. Pre-Emphasis & Sample-by-Sample Interpolated LPC / Throat Modeling
    // -------------------------------------------------------------------------
    const bool formantsActive = (!classicMode && useFormants);
    const double xPre = xIn - preEmphasisPole * preEmpZ1;
    preEmpZ1 = xIn;

    lpcAnalysisWin[static_cast<size_t>(lpcWinWriteIdx)] = xPre;
    lpcWinWriteIdx = (lpcWinWriteIdx + 1) & 511;

    if (formantsActive)
    {
        if (++lpcSampleCounter >= kLPCFrameHop)
        {
            lpcSampleCounter = 0;
            double userThroatRatio = (throatLengthPct / 100.0) * synVibFormantRatio;
            if (ratioLock && std::abs(transposeSemi) > 0.001)
                userThroatRatio *= std::pow(2.0, -transposeSemi / 24.0);
            analyzeLPCAndThroat(smoothedPeriodSamples, userThroatRatio);
        }
    }
    const double lpcAlpha = static_cast<double>(lpcSampleCounter) / static_cast<double>(kLPCFrameHop);

    // -------------------------------------------------------------------------
    // 3. Continuous Upward-Shift Anti-Aliasing Biquads
    // -------------------------------------------------------------------------
    const double xShiftFiltered = shiftLP2.process(shiftLP1.process(xIn));
    const double psolaInput = (smoothedPitchRatio > 1.0) ? xShiftFiltered : xIn;

    const double excitation = formantsActive ? inverseFilterLPC(xPre, lpcAlpha) : psolaInput;
    rawInputRing[static_cast<size_t>(psolaWriteIdx)] = psolaInput;
    residualRing[static_cast<size_t>(psolaWriteIdx)] = excitation;

    const double delayedDrySample = rawInputRing[static_cast<size_t>((psolaWriteIdx - 256) & kRingMask)];

    const auto& activeRing = formantsActive ? residualRing : rawInputRing;

    // -------------------------------------------------------------------------
    // 4. Relative-Offset Directional Phase-Locked TD-PSOLA Resynthesis
    // -------------------------------------------------------------------------
    const double T0Full = std::clamp(smoothedPeriodSamples * static_cast<double>(downsampleFactor), 32.0, 2048.0);
    const double step = voicedState ? smoothedPitchRatio : 1.0;
    const double deltaDelay = 1.0 - step;

    relDelayA += deltaDelay;
    relDelayB += deltaDelay;

    const double minDelay = 48.0;
    const double maxDelay = minDelay + 1.2 * T0Full;

    if (crossfadeAlpha >= 1.0)
    {
        if (step > 1.0 && relDelayA < minDelay)
        {
            relDelayB = relDelayA;
            double targetDelay = relDelayA + T0Full;
            while (targetDelay < minDelay)
                targetDelay += T0Full;
            relDelayA = findBestSpliceDelay(activeRing, relDelayB, targetDelay, T0Full);
            crossfadeAlpha = 0.0;
            crossfadeStep = 1.0 / std::max(24.0, 0.25 * T0Full);
        }
        else if (step < 1.0 && relDelayA > maxDelay)
        {
            relDelayB = relDelayA;
            double targetDelay = relDelayA - T0Full;
            while (targetDelay > maxDelay)
                targetDelay -= T0Full;
            relDelayA = findBestSpliceDelay(activeRing, relDelayB, targetDelay, T0Full);
            crossfadeAlpha = 0.0;
            crossfadeStep = 1.0 / std::max(24.0, 0.25 * T0Full);
        }
    }

    double readPosA = static_cast<double>(psolaWriteIdx) - relDelayA;
    while (readPosA < 0.0)
        readPosA += static_cast<double>(kRingSize);

    double resynthesized = readCubicHermite(activeRing, readPosA);

    if (crossfadeAlpha < 1.0)
    {
        double readPosB = static_cast<double>(psolaWriteIdx) - relDelayB;
        while (readPosB < 0.0)
            readPosB += static_cast<double>(kRingSize);

        const double sampleB = readCubicHermite(activeRing, readPosB);
        const double w = 0.5 * (1.0 - std::cos(kPi * crossfadeAlpha));
        resynthesized = w * resynthesized + (1.0 - w) * sampleB;

        crossfadeAlpha += crossfadeStep;
        if (crossfadeAlpha >= 1.0)
            crossfadeAlpha = 1.0;
    }

    psolaWriteIdx = (psolaWriteIdx + 1) & kRingMask;

    // -------------------------------------------------------------------------
    // 5. Throat-Warped LPC Synthesis Filter & Latency-Compensated Wet/Dry Mix
    // -------------------------------------------------------------------------
    double yWet = resynthesized;
    if (formantsActive)
    {
        const double lpcSyn = synthesizeThroatLPC(resynthesized, lpcAlpha);
        deEmpZ1 = lpcSyn + preEmphasisPole * deEmpZ1;
        yWet = deEmpZ1;
    }
    yWet *= synVibAmpGain;

    const double targetMix = std::clamp(wetDryMixPct * 0.01, 0.0, 1.0);
    smoothedWetMix = 0.9990 * smoothedWetMix + 0.0010 * targetMix;
    const double yOut = delayedDrySample * (1.0 - smoothedWetMix) + yWet * smoothedWetMix;

    return static_cast<float>(std::clamp(yOut, -4.0, 4.0));
}

//==============================================================================
//==============================================================================
juce::StringArray TAutoTuneProcessor::getInputTypeNames()
{
    return { "Alto/Tenor", "Soprano", "Low Male", "Instrument", "Bass Inst." };
}

juce::StringArray TAutoTuneProcessor::getKeyNames()
{
    return { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B" };
}

bool TAutoTuneProcessor::isMinorFamilyScale(int scaleIdx) noexcept
{
    switch (scaleIdx)
    {
        case 1: case 3: case 4: case 5: case 6: case 9: case 11: case 12: case 17: return true;
        default: return false;
    }
}

juce::StringArray TAutoTuneProcessor::getKeyNamesForScale(int scaleIdx)
{
    if (isMinorFamilyScale(scaleIdx))
        return { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B" };
    return { "C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B" };
}

juce::String TAutoTuneProcessor::noteNameInKey(int pitchClass, int keyIdx, int scaleIdx)
{
    static const char* const mixed[12] = { "C", "C#", "D", "Eb", "E", "F", "F#", "G", "G#", "A", "Bb", "B" };
    static const char* const flats[12] = { "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B" };
    static const char* const sharps[12] = { "C", "C#", "D", "D#", "E", "F", "F#", "G", "G#", "A", "A#", "B" };
    const int pc = ((pitchClass % 12) + 12) % 12;
    const int key = ((keyIdx % 12) + 12) % 12;
    const bool minor = isMinorFamilyScale(scaleIdx);
    const int relativeMajor = minor ? (key + 3) % 12 : key;
    // Key signatures: F Bb Eb Ab Db (and Gb = Eb minor) use flats; G D A E B F# use sharps.
    bool flat = false, sharp = false;
    switch (relativeMajor)
    {
        case 5: case 10: case 3: case 8: case 1: flat = true; break;
        case 6: flat = minor; sharp = ! minor; break;
        case 7: case 2: case 9: case 4: case 11: sharp = true; break;
        default: break;
    }
    if (scaleIdx == 2) flat = sharp = false; // chromatic: neutral names
    return flat ? flats[pc] : sharp ? sharps[pc] : mixed[pc];
}

juce::StringArray TAutoTuneProcessor::getScaleNames()
{
    return {
        "Major", "Minor", "Chromatic", "Harmonic Minor", "Melodic Minor",
        "Dorian", "Phrygian", "Lydian", "Mixolydian", "Locrian",
        "Pentatonic Major", "Pentatonic Minor", "Blues", "Whole Tone",
        "Octatonic (W-H)", "Octatonic (H-W)", "Phrygian Dominant",
        "Hungarian Minor", "Arabic", "In Sen", "Hirajoshi", "Hijaz",
        "Lydian Dominant", "Altered", "Mixolydian b6", "Harmonic Major",
        "Bebop Dominant", "Bebop Major", "Ryukyu"
    };
}

juce::StringArray TAutoTuneProcessor::getVibratoShapeNames()
{
    return { "No Vibrato", "Sine Wave", "Square", "Sawtooth" };
}

juce::AudioProcessorValueTreeState::ParameterLayout TAutoTuneProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kInputType, 1 }, "Input Type",
        getInputTypeNames(), 0)); // Default 0 = Alto/Tenor

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kKey, 1 }, "Key",
        getKeyNames(), 0)); // Default C

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kScale, 1 }, "Scale",
        getScaleNames(), 2)); // Default Chromatic

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kClassicMode, 1 }, "Classic", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kUseFormants, 1 }, "Formant", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kThroatLength, 1 }, "Formant Length",
        juce::NormalisableRange<float>(50.0f, 190.0f, 1.0f, 0.85f), 100.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kTranspose, 1 }, "Transpose",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 1.0f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kDetune, 1 }, "Detune",
        juce::NormalisableRange<float>(-100.0f, 100.0f, 1.0f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kTracking, 1 }, "Tracking",
        juce::NormalisableRange<float>(1.0f, 100.0f, 1.0f), 50.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kMix, 1 }, "Wet/Dry Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 100.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kRatioLock, 1 }, "Formant-Transpose Ratio Lock", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kMasterBypass, 1 }, "Master Bypass", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kRetuneSpeed, 1 }, "Retune Speed",
        juce::NormalisableRange<float>(0.0f, 400.0f, 1.0f, 0.38f), 20.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kFlexTune, 1 }, "Flex-Tune",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kNaturalVibrato, 1 }, "Natural Vibrato",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kHumanize, 1 }, "Humanize",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kAdvancedView, 1 }, "Advanced View", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kIgnoreVibrato, 1 }, "Ignore Vibrato", false));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kVibratoShape, 1 }, "Vibrato Shape",
        getVibratoShapeNames(), 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoRate, 1 }, "Vibrato Rate",
        juce::NormalisableRange<float>(0.1f, 10.0f, 0.1f), 5.5f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoDelay, 1 }, "Onset Delay",
        juce::NormalisableRange<float>(0.0f, 1500.0f, 1.0f), 500.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoTrans, 1 }, "Onset Rate",
        juce::NormalisableRange<float>(0.0f, 1500.0f, 1.0f), 500.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoVar, 1 }, "Variation",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 30.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoPitch, 1 }, "Vibrato Pitch",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoAmp, 1 }, "Vibrato Amplitude",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 30.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoFormant, 1 }, "Vibrato Formant",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 70.0f));

    return { params.begin(), params.end() };
}

TAutoTuneProcessor::TAutoTuneProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "TAutoTuneParams", createParameterLayout())
{
    for (int i = 0; i < 12; ++i)
    {
        noteStatesAtom[static_cast<size_t>(i)].store(kNoteActive, std::memory_order_relaxed);
        noteCentsAtom[static_cast<size_t>(i)].store(0, std::memory_order_relaxed);
    }
    applyScalePresetToNotes(0, 2);
    initAutoKeySearchPaths();
    syncFromAutoKeyHandoff(true);
    startTimer(250);
    licenseThread.startThread();
}

TAutoTuneProcessor::~TAutoTuneProcessor()
{
    stopTimer();
    licenseThread.signalThreadShouldExit();
    licenseThread.notify();
    licenseThread.stopThread(3000);
}

void TAutoTuneProcessor::LicenseThread::run()
{
    double nextPoll = 0;
    while (! threadShouldExit())
    {
        const auto now = juce::Time::getCurrentTime().toMilliseconds();
        const auto ticks = juce::Time::getMillisecondCounterHiRes();
        if (owner.licensePollRequested.exchange(false) || ticks >= nextPoll)
        {
            owner.licensing.poll(now);
            nextPoll = ticks + 1000;
        }
        wait(100);
    }
}

void TAutoTuneProcessor::activateLicense(const juce::String& text)
{
    licensing.requestActivation(text);
    licensePollRequested.store(true);
    licenseThread.notify();
}

void TAutoTuneProcessor::startLicenseTrial()
{
    licensing.requestTrial();
    licensePollRequested.store(true);
    licenseThread.notify();
}

void TAutoTuneProcessor::ensureAutomaticTrialRequested() noexcept
{
    // Host scanning alone does not start the trial; the first editor or audio
    // callback queues it. All file access stays on the license thread.
    if (! automaticTrialRequested.exchange(true, std::memory_order_relaxed))
    {
        licensing.requestAutomaticTrial();
        licensePollRequested.store(true);
    }
}

void TAutoTuneProcessor::setAutoKeySyncEnabled(bool enabled) noexcept
{
    autoKeySyncAtom.store(enabled, std::memory_order_relaxed);
    autoKeyHandoffReader.setAutoSyncEnabled(enabled);
    if (enabled)
        syncFromAutoKeyHandoff(true);
    else
        keyFromAutoKeyAtom.store(false, std::memory_order_relaxed);
}

void TAutoTuneProcessor::initAutoKeySearchPaths()
{
    const auto userAppData = juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory);
    if (userAppData != juce::File())
    {
        autoKeyHandoffReader.addExtraSearchPath(
            userAppData.getChildFile("Auto-Key").getChildFile("Auto-Key.handoff").getFullPathName().toStdString());
        autoKeyHandoffReader.addExtraSearchPath(
            userAppData.getSiblingFile("Roaming").getChildFile("Auto-Key").getChildFile("Auto-Key.handoff").getFullPathName().toStdString());
    }
    const auto userHome = juce::File::getSpecialLocation(juce::File::userHomeDirectory);
    if (userHome != juce::File())
    {
        autoKeyHandoffReader.addExtraSearchPath(
            userHome.getChildFile("AppData/Roaming/Auto-Key/Auto-Key.handoff").getFullPathName().toStdString());
        autoKeyHandoffReader.addExtraSearchPath(
            userHome.getChildFile("Music/Audio Music Apps/Temp/Auto-Key.handoff").getFullPathName().toStdString());
        autoKeyHandoffReader.addExtraSearchPath(
            userHome.getChildFile("Library/Application Support/Auto-Key/Auto-Key.handoff").getFullPathName().toStdString());
    }
}

bool TAutoTuneProcessor::syncFromAutoKeyHandoff(bool forceReload)
{
    AutoKeyHandoffReader::HandoffData data;
    if (!autoKeyHandoffReader.pollForUpdate(data, forceReload) || !data.valid)
        return false;

    if (auto* keyParam = apvts.getParameter(TAutoTuneParams::kKey))
    {
        const int curKey = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
        if (curKey != data.keyClass || forceReload)
            keyParam->setValueNotifyingHost(keyParam->convertTo0to1(static_cast<float>(data.keyClass)));
    }

    if (auto* scaleParam = apvts.getParameter(TAutoTuneParams::kScale))
    {
        const int curScale = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kScale)->load());
        if (curScale != data.scaleIndex || forceReload)
            scaleParam->setValueNotifyingHost(scaleParam->convertTo0to1(static_cast<float>(data.scaleIndex)));
    }

    if (data.hasReferencePitch)
    {
        const float detuneCents = std::clamp(1200.0f * std::log2(data.referencePitchHz / 440.0f), -100.0f, 100.0f);
        if (auto* detParam = apvts.getParameter(TAutoTuneParams::kDetune))
            detParam->setValueNotifyingHost(detParam->convertTo0to1(detuneCents));
    }

    applyScalePresetToNotes(data.keyClass, data.scaleIndex);
    keyFromAutoKeyAtom.store(true, std::memory_order_relaxed);
    return true;
}

void TAutoTuneProcessor::syncScaleToNotesIfNeeded() noexcept
{
    const int keyIdx   = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
    const int scaleIdx = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kScale)->load());
    if (keyIdx != lastKeyIdx || scaleIdx != lastScaleIdx)
        applyScalePresetToNotes(keyIdx, scaleIdx);
}

void TAutoTuneProcessor::timerCallback()
{
    syncFromAutoKeyHandoff(false);
    syncScaleToNotesIfNeeded();
}

int TAutoTuneProcessor::getNoteState(int pitchClass12) const noexcept
{
    const int idx = ((pitchClass12 % 12) + 12) % 12;
    return noteStatesAtom[static_cast<size_t>(idx)].load(std::memory_order_relaxed);
}

void TAutoTuneProcessor::setNoteState(int pitchClass12, int state) noexcept
{
    const int idx = ((pitchClass12 % 12) + 12) % 12;
    noteStatesAtom[static_cast<size_t>(idx)].store(std::clamp(state, 0, 2), std::memory_order_relaxed);
}

void TAutoTuneProcessor::cycleNoteState(int pitchClass12, bool editBypassMode) noexcept
{
    const int cur = getNoteState(pitchClass12);
    if (editBypassMode)
        setNoteState(pitchClass12, (cur == kNoteBypassed) ? kNoteActive : kNoteBypassed);
    else
        setNoteState(pitchClass12, (cur == kNoteRemoved) ? kNoteActive : kNoteRemoved);
}

int TAutoTuneProcessor::getNoteCents(int pitchClass12) const noexcept
{
    const int idx = ((pitchClass12 % 12) + 12) % 12;
    return noteCentsAtom[static_cast<size_t>(idx)].load(std::memory_order_relaxed);
}

void TAutoTuneProcessor::setNoteCents(int pitchClass12, int cents) noexcept
{
    const int idx = ((pitchClass12 % 12) + 12) % 12;
    noteCentsAtom[static_cast<size_t>(idx)].store(std::clamp(cents, -100, 100), std::memory_order_relaxed);
}

void TAutoTuneProcessor::resetAllNoteCents() noexcept
{
    for (int i = 0; i < 12; ++i)
        noteCentsAtom[static_cast<size_t>(i)].store(0, std::memory_order_relaxed);
}

void TAutoTuneProcessor::setHoldMeter(bool hold) noexcept
{
    holdMeterAtom.store(hold, std::memory_order_relaxed);
    if (hold)
    {
        const float t = targetMidiAtom.load(std::memory_order_relaxed);
        frozenMidiNoteAtom.store(t >= 0.0f ? static_cast<int>(std::round(t)) : 60, std::memory_order_relaxed);
    }
    else
    {
        frozenMidiNoteAtom.store(-1, std::memory_order_relaxed);
    }
}

void TAutoTuneProcessor::startInputTypeLearn() noexcept
{
    learnSamplesAccum = 0;
    learnTargetSamples = std::max(48000, static_cast<int>(currentSampleRate * 3.5));
    learnPitchMidiSum = 0.0;
    learnHighFreqEnergySum = 0.0;
    learnTotalEnergySum = 0.0;
    learnVoicedCount = 0;
    learnProgressAtom.store(0.0f, std::memory_order_relaxed);
    learningInputTypeAtom.store(true, std::memory_order_relaxed);
}

void TAutoTuneProcessor::startAutoKeyDetect() noexcept
{
    if (syncFromAutoKeyHandoff(true))
    {
        detectingAutoKeyAtom.store(false, std::memory_order_relaxed);
        autoKeyProgressAtom.store(1.0f, std::memory_order_relaxed);
        return;
    }
    autoKeySamplesAccum = 0;
    autoKeyChromaHist.fill(0.0);
    autoKeyProgressAtom.store(0.0f, std::memory_order_relaxed);
    detectingAutoKeyAtom.store(true, std::memory_order_relaxed);
}

void TAutoTuneProcessor::triggerAuditionNote(int midiNote) noexcept
{
    auditionMidiNoteAtom.store(std::clamp(midiNote, 24, 96), std::memory_order_relaxed);
}

void TAutoTuneProcessor::stopAuditionNote() noexcept
{
    auditionMidiNoteAtom.store(-1, std::memory_order_relaxed);
}

void TAutoTuneProcessor::applyScalePresetToNotes(int keyIdx, int scaleIdx) noexcept
{
    const int k = std::clamp(keyIdx, 0, 11);
    const int s = std::clamp(scaleIdx, 0, 28);
    lastKeyIdx = k;
    lastScaleIdx = s;

    for (int pc = 0; pc < 12; ++pc)
    {
        const int rel = ((pc - k) % 12 + 12) % 12;
        const bool active = (kScaleMasks[s][rel] != 0);
        setNoteState(pc, active ? kNoteActive : kNoteRemoved);
    }
}

void TAutoTuneProcessor::setMajorNotes() noexcept
{
    const int k = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
    applyScalePresetToNotes(k, 0);
}

void TAutoTuneProcessor::setMinorNotes() noexcept
{
    const int k = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
    applyScalePresetToNotes(k, 1);
}

void TAutoTuneProcessor::setAllNotesActive() noexcept
{
    for (int i = 0; i < 12; ++i)
        setNoteState(i, kNoteActive);
}

void TAutoTuneProcessor::setAllNotesBypassed() noexcept
{
    for (int i = 0; i < 12; ++i)
        setNoteState(i, kNoteBypassed);
}

void TAutoTuneProcessor::setAllNotesRemoved() noexcept
{
    for (int i = 0; i < 12; ++i)
        setNoteState(i, kNoteRemoved);
}

void TAutoTuneProcessor::prepareToPlay(double sampleRate, int)
{
    syncFromAutoKeyHandoff(false);
    currentSampleRate = sampleRate > 8000.0 ? sampleRate : 48000.0;
    for (auto& ch : channelDSP)
        ch.prepare(currentSampleRate);
}

void TAutoTuneProcessor::releaseResources() {}

bool TAutoTuneProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return out == layouts.getMainInputChannelSet();
}

void TAutoTuneProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;

    if (buffer.getNumSamples() > 0)
        ensureAutomaticTrialRequested();
    if (! licensing.isAllowed())
    {
        // Not activated / trial ended: leave the host audio untouched.
        voicedAtom.store(false, std::memory_order_relaxed);
        return;
    }

    const bool masterBypass = apvts.getRawParameterValue(TAutoTuneParams::kMasterBypass)->load() > 0.5f;
    if (masterBypass)
        return;

    // Map to internal DSP voiceType: 0=Soprano, 1=Alto/Tenor, 2=Low Male, 3=Instrument, 4=Bass Inst.
    const int uiInputType = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kInputType)->load());
    const int voiceType = (uiInputType == 0) ? 1 : (uiInputType == 1 ? 0 : uiInputType);

    const int keyIdx       = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
    const int scaleIdx     = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kScale)->load());
    const bool classicMode = apvts.getRawParameterValue(TAutoTuneParams::kClassicMode)->load() > 0.5f;
    const bool useFormants = apvts.getRawParameterValue(TAutoTuneParams::kUseFormants)->load() > 0.5f;
    const double throatLen = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kThroatLength)->load());
    const bool ratioLock   = apvts.getRawParameterValue(TAutoTuneParams::kRatioLock)->load() > 0.5f;
    const double transpose = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kTranspose)->load());
    const double detune    = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kDetune)->load());
    const double tracking  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kTracking)->load());
    const double wetDryMix = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kMix)->load());

    const double retuneMs  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kRetuneSpeed)->load());
    const double flexTune  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kFlexTune)->load());
    const double natVibDb  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kNaturalVibrato)->load());
    const double humanize  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kHumanize)->load());
    const bool ignoreVib   = apvts.getRawParameterValue(TAutoTuneParams::kIgnoreVibrato)->load() > 0.5f;

    const int vibShape     = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoShape)->load());
    const double vibRate   = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoRate)->load());
    const double vibDelay  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoDelay)->load());
    const double vibTrans  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoTrans)->load());
    const double vibVar    = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoVar)->load());
    const double vibPitch  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoPitch)->load());
    const double vibAmp    = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoAmp)->load());
    const double vibForm   = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoFormant)->load());

    if (keyIdx != lastKeyIdx || scaleIdx != lastScaleIdx)
        applyScalePresetToNotes(keyIdx, scaleIdx);

    for (const auto metadata : midiMessages)
    {
        const auto msg = metadata.getMessage();
        if (msg.isNoteOn())
            setNoteState(msg.getNoteNumber() % 12, kNoteActive);
    }

    std::array<int, 12> noteStatesLocal {};
    std::array<int, 12> noteCentsLocal {};
    for (int i = 0; i < 12; ++i)
    {
        noteStatesLocal[static_cast<size_t>(i)] = noteStatesAtom[static_cast<size_t>(i)].load(std::memory_order_relaxed);
        noteCentsLocal[static_cast<size_t>(i)]  = noteCentsAtom[static_cast<size_t>(i)].load(std::memory_order_relaxed);
    }

    const int numChannels = std::min(2, buffer.getNumChannels());
    const int numSamples  = buffer.getNumSamples();
    const int frozenNote  = holdMeterAtom.load(std::memory_order_relaxed)
                          ? frozenMidiNoteAtom.load(std::memory_order_relaxed)
                          : -1;

    double blockEnergy = 0.0;
    double blockDiffEnergy = 0.0;
    if (numChannels > 0 && numSamples > 0)
    {
        const float* in0 = buffer.getReadPointer(0);
        float prev = in0[0];
        for (int n = 0; n < numSamples; ++n)
        {
            const double s = static_cast<double>(in0[n]);
            blockEnergy += s * s;
            const double d = s - static_cast<double>(prev);
            blockDiffEnergy += d * d;
            prev = in0[n];
        }
    }
    const double blockRms = (numSamples > 0) ? std::sqrt(blockEnergy / static_cast<double>(numSamples)) : 0.0;

    for (int ch = 0; ch < numChannels; ++ch)
    {
        float* data = buffer.getWritePointer(ch);
        auto& dsp   = channelDSP[static_cast<size_t>(ch)];

        for (int n = 0; n < numSamples; ++n)
        {
            data[n] = dsp.processSample(
                data[n], voiceType, keyIdx, scaleIdx, noteStatesLocal, noteCentsLocal,
                classicMode, useFormants, throatLen, ratioLock, transpose, detune, tracking,
                retuneMs, flexTune, natVibDb, humanize, ignoreVib,
                vibShape, vibRate, vibDelay, vibTrans, vibVar, vibPitch, vibAmp, vibForm,
                wetDryMix, frozenNote);
        }
    }

    const int audNote = auditionMidiNoteAtom.load(std::memory_order_relaxed);
    if (audNote >= 0 || auditionEnv > 1.0e-4)
    {
        const double freq = 440.0 * std::pow(2.0, (static_cast<double>(audNote >= 0 ? audNote : 60) + detune * 0.01 - 69.0) / 12.0);
        const double phaseInc = freq / currentSampleRate;
        const double targetEnv = (audNote >= 0) ? 0.18 : 0.0;
        for (int n = 0; n < numSamples; ++n)
        {
            auditionEnv = 0.995 * auditionEnv + 0.005 * targetEnv;
            auditionPhase += phaseInc;
            auditionPhase -= std::floor(auditionPhase);
            const float tone = static_cast<float>(auditionEnv * (
                0.70 * std::sin(2.0 * kPi * auditionPhase) +
                0.22 * std::sin(4.0 * kPi * auditionPhase) +
                0.08 * std::sin(6.0 * kPi * auditionPhase)));
            for (int ch = 0; ch < numChannels; ++ch)
                buffer.getWritePointer(ch)[n] += tone;
        }
    }

    const bool isVoicedNow = channelDSP[0].isCurrentlyVoiced();
    const float detMidiNow = channelDSP[0].getDetectedMidiNote();

    if (learningInputTypeAtom.load(std::memory_order_relaxed))
    {
        if (blockRms > 0.003 && isVoicedNow && detMidiNow > 20.0f)
        {
            learnSamplesAccum += numSamples;
            learnPitchMidiSum += static_cast<double>(detMidiNow);
            learnHighFreqEnergySum += blockDiffEnergy;
            learnTotalEnergySum += blockEnergy;
            learnVoicedCount++;

            const float prog = std::clamp(static_cast<float>(learnSamplesAccum) / static_cast<float>(learnTargetSamples), 0.0f, 1.0f);
            learnProgressAtom.store(prog, std::memory_order_relaxed);

            if (learnSamplesAccum >= learnTargetSamples && learnVoicedCount > 0)
            {
                const double avgMidi = learnPitchMidiSum / static_cast<double>(learnVoicedCount);
                const double hfRatio = learnHighFreqEnergySum / std::max(1.0e-9, learnTotalEnergySum);
                int learnedIdx = 0;
                if (avgMidi < 43.0)
                    learnedIdx = (hfRatio < 0.04) ? 4 : 2; // Bass Inst. or Low Male
                else if (avgMidi < 53.0)
                    learnedIdx = 2; // Low Male
                else if (avgMidi <= 63.0)
                    learnedIdx = 0; // Alto/Tenor
                else
                    learnedIdx = (hfRatio > 0.25) ? 3 : 1; // Instrument or Soprano

                if (auto* param = apvts.getParameter(TAutoTuneParams::kInputType))
                    param->setValueNotifyingHost(param->convertTo0to1(static_cast<float>(learnedIdx)));

                learningInputTypeAtom.store(false, std::memory_order_relaxed);
                learnProgressAtom.store(1.0f, std::memory_order_relaxed);
            }
        }
    }

    // Auto-Key Chroma Detector ("Auto Key" button)
    if (detectingAutoKeyAtom.load(std::memory_order_relaxed))
    {
        if (blockRms > 0.003 && isVoicedNow && detMidiNow > 20.0f)
        {
            autoKeySamplesAccum += numSamples;
            const int pc = ((static_cast<int>(std::round(detMidiNow)) % 12) + 12) % 12;
            autoKeyChromaHist[static_cast<size_t>(pc)] += blockRms * static_cast<double>(numSamples);

            const int targetSamps = std::max(48000, static_cast<int>(currentSampleRate * 3.0));
            const float prog = std::clamp(static_cast<float>(autoKeySamplesAccum) / static_cast<float>(targetSamps), 0.0f, 1.0f);
            autoKeyProgressAtom.store(prog, std::memory_order_relaxed);

            if (autoKeySamplesAccum >= targetSamps)
            {
                static constexpr double kMajorProfile[12] = { 6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88 };
                static constexpr double kMinorProfile[12] = { 6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17 };
                int bestKey = 0;
                int bestScale = 0; // 0=Major, 1=Minor
                double bestScore = -1.0e18;
                for (int k = 0; k < 12; ++k)
                {
                    double scoreMaj = 0.0, scoreMin = 0.0;
                    for (int i = 0; i < 12; ++i)
                    {
                        const double w = autoKeyChromaHist[static_cast<size_t>((k + i) % 12)];
                        scoreMaj += w * kMajorProfile[i];
                        scoreMin += w * kMinorProfile[i];
                    }
                    if (scoreMaj > bestScore) { bestScore = scoreMaj; bestKey = k; bestScale = 0; }
                    if (scoreMin > bestScore) { bestScore = scoreMin; bestKey = k; bestScale = 1; }
                }
                if (auto* keyParam = apvts.getParameter(TAutoTuneParams::kKey))
                    keyParam->setValueNotifyingHost(keyParam->convertTo0to1(static_cast<float>(bestKey)));
                if (auto* scaleParam = apvts.getParameter(TAutoTuneParams::kScale))
                    scaleParam->setValueNotifyingHost(scaleParam->convertTo0to1(static_cast<float>(bestScale)));

                detectingAutoKeyAtom.store(false, std::memory_order_relaxed);
                autoKeyProgressAtom.store(1.0f, std::memory_order_relaxed);
                keyFromAutoKeyAtom.store(false, std::memory_order_relaxed);
            }
        }
    }

    if (!holdMeterAtom.load(std::memory_order_relaxed))
    {
        detectedMidiAtom.store(detMidiNow, std::memory_order_relaxed);
        targetMidiAtom.store(channelDSP[0].getTargetMidiNote(), std::memory_order_relaxed);
        centsCorrectionAtom.store(channelDSP[0].getCentsCorrection(), std::memory_order_relaxed);
        voicedAtom.store(isVoicedNow, std::memory_order_relaxed);
    }
}

juce::AudioProcessorEditor* TAutoTuneProcessor::createEditor()
{
    ensureAutomaticTrialRequested();
    return new TAutoTuneEditor(*this);
}

void TAutoTuneProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    for (int i = 0; i < 12; ++i)
    {
        state.setProperty("noteState_" + juce::String(i), getNoteState(i), nullptr);
        state.setProperty("noteCents_" + juce::String(i), getNoteCents(i), nullptr);
    }
    state.setProperty("autoKeySync", isAutoKeySyncEnabled(), nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void TAutoTuneProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
    {
        auto tree = juce::ValueTree::fromXml(*xmlState);
        apvts.replaceState(tree);
        lastKeyIdx   = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
        lastScaleIdx = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kScale)->load());
        for (int i = 0; i < 12; ++i)
        {
            const juce::String prop = "noteState_" + juce::String(i);
            if (tree.hasProperty(prop))
                setNoteState(i, static_cast<int>(tree.getProperty(prop)));
            const juce::String cprop = "noteCents_" + juce::String(i);
            if (tree.hasProperty(cprop))
                setNoteCents(i, static_cast<int>(tree.getProperty(cprop)));
        }
        if (tree.hasProperty("autoKeySync"))
        {
            const bool sync = static_cast<bool>(tree.getProperty("autoKeySync"));
            autoKeySyncAtom.store(sync, std::memory_order_relaxed);
            autoKeyHandoffReader.setAutoSyncEnabled(sync);
        }
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new TAutoTuneProcessor();
}


