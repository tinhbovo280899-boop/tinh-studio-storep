// SPDX-License-Identifier: AGPL-3.0-or-later
// Copyright (c) 2026 dkribeiro
#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <atomic>
#include "KeyAnalyzer.h"
#include "HandoffGate.h"
#include "SongRestartGate.h"
#include "licensing/LicenseManager.h"
#include "licensing/ProductConfig.h"

class KeyDetectorProcessor : public juce::AudioProcessor, private juce::Thread
{
public:
    KeyDetectorProcessor();
    ~KeyDetectorProcessor() override;
    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout&) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    void requestDetection();
    void sendHandoffNow();
    KeyAnalyzer::Result getLatestResult() const;
    static constexpr int waveSize = 400;
    void copyWaveform (float* dest, int num) const;
    std::atomic<bool> holdKey { false };
    juce::File getHandoffFile() const;
    juce::String getHandoffStatus() const;
    void setHandoffDirectory (const juce::File& directory);
    void useDefaultHandoffPath();
    void saveGlobalSettings();
    void loadGlobalSettings();
    tak::license::Snapshot getLicenseSnapshot() const { return licensing.snapshot(); }
    void activateLicense(const juce::String& text);
    void startLicenseTrial();
    bool hasLicenseAccess() const noexcept { return licensing.isAllowed(); }

private:
    void run() override;
    void ensureAutomaticTrialRequested() noexcept;
    void pollHandoff();
    void setHandoffStatus (const juce::String& status);
    juce::File getSettingsFile() const;
    KeyAnalyzer analyzer;
    SongRestartGate songRestartGate;
    tak::license::LicenseManager licensing {tak::license::productConfiguration(),tak::license::productStore(),{},tak::license::legacyAutoKeyLicenses()};
    std::atomic<bool> licensePollRequested {true};
    std::atomic<bool> automaticTrialRequested {false}, autoRestartNotice {false};
    bool lastWorkerLicenseAllowed = true;
    double nextLicensePollMs = 0;
    juce::AudioBuffer<float> monoBuffer;
    std::atomic<int> encodedKey { -1 }, encodedSecond { -1 };
    std::atomic<float> confidence { 0.0f }, tuningHz { 440.0f };
    std::array<std::atomic<float>, 12> chroma {};
    std::array<std::atomic<float>, waveSize> wave {};
    std::atomic<int> waveWrite { 0 };
    float wavePeak = 0.0f;
    int waveCount = 0, samplesPerPoint = 480;
    double audioSampleRate = 48000.0, previousBlockSeconds = 0.0; // Audio-thread owned.
    std::atomic<bool> resetRequested { false }, manualSendRequested { false };
    std::atomic<double> lastAudioBlockMs { -10000.0 };
    std::atomic<std::uint64_t> outputGeneration { 1 };
    mutable juce::CriticalSection outputLock;
    juce::String handoffOverride, handoffStatus;
    HandoffGate outputGate; // Worker-owned; no locking or disk access on audio thread.
    double retryAfterMs = 0.0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (KeyDetectorProcessor)
};
