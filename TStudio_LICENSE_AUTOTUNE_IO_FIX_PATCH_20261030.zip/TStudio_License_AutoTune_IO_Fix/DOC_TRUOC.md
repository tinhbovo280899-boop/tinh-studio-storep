# Bản vá check bản quyền và AutoTune — 30/10/2026

Áp dụng cho đúng bốn ZIP anh gửi: TStudio_Compressor_Bundle_1.2.0, T-Studio_FX, T-Studio_Plugins và T-Studio_VocalPack. Đây là bản vá mã nguồn, cần build lại trên Windows/macOS; không chứa VST3/EXE/PKG đã biên dịch. Người dùng hiện dùng Cubase 15 Windows, nhưng môi trường kiểm tra của lượt này là Linux.

## Cách bản quyền hiện hoạt động

- Kiểm tra offline: chữ ký RSA-2048/SHA-256, product/brand, mã máy và thời hạn. Không thấy HTTP/kiểm tra server trong các file licensing này.
- Mỗi instance có worker kiểm tra khoảng mỗi giây. File/registry/kiểm tra chữ ký trên worker; audio chỉ đọc cờ atomic isAllowed(). Snapshot giao diện có khoá ngắn để copy dữ liệu.
- TVOCALPACK / TSTUDIO là kho dùng chung. Một key pack và đợt thử 7 ngày dùng chung giữa các plugin; key T-AutoKey cũ chỉ mở AutoKey như trước.
- Các file config/public_key.txt trong cả bốn ZIP nguồn được gửi hiện trống. Nếu build mà chưa điền public key của anh thì key đã ký sẽ không xác minh được. Có thể binary trên máy anh đã được build với key đúng; mã nguồn không chứng minh được điều này. Bản vá không sửa key/config, không sinh cặp key mới và không reset ngày dùng thử.

## Lỗi đã tái hiện và sửa

1. **Ghi lại trial quá thường xuyên khi một mirror không ghi được.** Bản gốc viết lại mirror chính 20 lần trong 20 lần poll cách nhau một giây. Bản vá ghi nhớ cả lần ghi thất bại và chờ tới 60 giây trước khi thử sửa lại. Thay đổi quan trọng của trạng thái trial (bắt đầu/đã kích hoạt/đánh dấu sửa đổi) vẫn được ghi ngay. Việc phát hiện hết hạn và đổi quyền trong RAM không bị trì hoãn bởi backoff. Áp dụng LicenseManager giống nhau cho cả bốn gói.
2. **Lịch worker dùng giờ ngày tháng để quyết định lần kiểm tra tiếp theo.** Đổi sang Time::getMillisecondCounterHiRes() cho lịch định kỳ; vẫn dùng UTC thật khi xác minh ngày key/trial. Áp dụng PluginLicense của ba gói và worker AutoKey/AutoTune trong VocalPack. Không thay chính sách ngày tháng. Đây là kiểm tra mã nguồn/API, chưa chỉnh đồng hồ hệ thống Windows để kiểm nghiệm trực tiếp.
3. **T-AutoTune dò toàn bộ tài khoản Windows/macOS và chọn file mới nhất.** Bài thử đặt file C major của tài khoản hiện tại, file A major mới hơn của tài khoản khác: bản gốc chọn nhầm A. Bản vá chỉ dò tài khoản hiện tại và extra path đã cấu hình; ProgramData vẫn là fallback nếu không có file người dùng hợp lệ. Không còn quét C:/Users, D:/Users hay /Users.
4. **Đọc handoff không giới hạn, ngay trong constructor/prepare/timer UI.** Bản gốc nhận cả file 64 MB; constructor khoảng 473 ms, prepare khoảng 434 ms, vòng dispatch 600 ms không trả về trước timeout 15 giây. Bản vá giới hạn cả kiểm tra kích thước lẫn lần read tối đa 256 KiB, kể cả file tăng sau lúc stat. File quá lớn bị bỏ qua, không phân tích phần đầu như file hợp lệ. Với cùng fixture 64 MB, constructor ~0.6 ms, prepare ~0.02 ms, dispatch hoàn tất ~600 ms. Đây là fixture bất thường để chứng minh đường lỗi, chưa có file handoff thực tế từ máy anh.

## Kết quả kiểm tra

- Bộ chính sách bản quyền gốc giữ nguyên: **68/68** qua ở cả trước và sau vá.
- Hồi quy bổ sung **130 kiểm tra**: không ghi dồn trước 60 giây, mirror hồi phục ở 60 giây, phát hiện và lưu dấu sửa đổi ngay trong khoảng backoff, mở lại vẫn bị khoá, key hợp lệ kích hoạt ngay, hết hạn đúng mốc. AddressSanitizer/UBSan qua ở source cấp phép/test, dùng JUCE runtime không instrument; leak detection tắt.
- Handoff **66 kiểm tra**: tài khoản hiện tại, 24 key major/minor, reference pitch, force/manual và auto-sync, đúng biên 256 KiB, file rỗng/mất/quá lớn.
- **40 lượt tạo/xoá** trên AutoTune, AutoKey, T-1176, T-Verb, T-BE (8 mỗi con), với audio nền, state round trip, UI open/close và một số lần huỷ processor dưới MessageManagerLock: qua, không output NaN/Inf. Đây là năm đại diện cho bốn gói, không phải thử lại cả 23 con sau vá.
- DSP, Formant/Throat, parameter layout và processBlock AutoTune giữ nguyên từng byte; có SHA256 đối chiếu trong Validation/DSP_UNCHANGED.json. Không thay thuật toán pitch correction, preset, plugin IDs hay phiên bản sản phẩm của dự án gốc. Key/Scale có thể khác bản cũ nếu trước đó nó đã chọn nhầm file tài khoản khác.

## Giới hạn còn lại

Chưa tái hiện được lần Cubase 15 của anh treo và chưa chạy native Windows/macOS, ASIO hay unload/reload DLL trong Cubase. Không khẳng định đây là toàn bộ nguyên nhân.

Handoff vẫn được đọc trong constructor/prepare/timer, nhưng đã giới hạn dữ liệu và bỏ quét tài khoản. Chưa chuyển toàn bộ handoff I/O sang worker; một đường dẫn nhỏ nằm trên ổ/thiết bị không phản hồi vẫn có thể chặn lời gọi file của hệ điều hành.

stopThread(3000) của worker bản quyền và stopThread(2000) của T-BE vẫn giữ nguyên. Nếu I/O thực tế mắc lâu quá hạn, JUCE có đường cưỡng bức kết thúc thread; chưa có dump để xác nhận nhánh này trên máy anh.

Các đường Learn/Auto Key báo đổi tham số từ audio và biến dùng chung trong AutoTune chưa được refactor ở bản vá này. VST3 wrapper JUCE có cơ chế chuyển thông báo/cache; các thông báo đó chưa chứng minh trực tiếp deadlock Cubase. Không đổi DSP để sửa theo phỏng đoán.

## Áp dụng

1. Giải nén bốn ZIP dự án gốc. Đặt các thư mục TStudio_Compressor_Bundle, T-Studio_FX, T-Studio_Plugins, T-Studio_VocalPack cùng một thư mục cha nếu muốn áp dụng chung.
2. Chạy **1_AP_DUNG_BAN_VA_WINDOWS.bat**, nhập thư mục cha đó. Có thể nhập đường dẫn một dự án để chỉ vá dự án đó. Script chỉ nhận file có SHA256 gốc hoặc đã vá đúng; kiểm tra toàn bộ trước khi ghi và sao lưu .before-license-autotune-fix.
3. Dùng script build/installer của từng dự án. Điền đúng public key hiện có theo luồng build của anh. Các file key, ID, thời hạn và dữ liệu kích hoạt trên máy không bị bản vá chạm tới.
4. Cài VST3 vừa build, dùng Cubase Plug-in Manager quét lại, rồi thử thêm/xoá trên project thử. Đối chiếu binary thực tế nếu vẫn đơ bằng công cụ Windows_Diagnostics trong gói rà 23 VST đã gửi trước.

Bản vá menu T-EQ đã gửi trước là độc lập: gói này không ghi đè HwEditor.h hay CMakeLists.txt nên dùng được cùng nhau. Giữ các giấy phép/thông báo của dự án gốc khi build và phân phối.
