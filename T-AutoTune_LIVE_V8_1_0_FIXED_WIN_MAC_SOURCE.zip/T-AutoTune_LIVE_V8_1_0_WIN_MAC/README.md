# T-AutoTune — bản Live từ dự án 8.1.0

Bản nguồn rút gọn theo nhu cầu hát live. Xem **GHI_CHU_BAN_LIVE.md** về những tính năng bị bỏ, kết quả tái hiện lỗi và giới hạn. Tên/ID plugin trong host được giữ từ dự án cũ; chữ LIVE trên giao diện nhận diện bản sửa này. Không có tuyên bố thuật toán giống UAD hoặc Antares.

## Giao diện và âm thanh

Giữ Voice, Key, Scale, Retune, Flex-Tune, Humanize và Natural Vibrato. Menu Settings có thao tác thật. GRAPH, Classic, nhánh Formant/Throat cũ, Transpose và Synthetic Vibrato không hoạt động trong bản live. Gói không chứa private signing key.

## Windows

Cài Visual Studio với Desktop development with C++, CMake 3.22 trở lên. Giải nén vào thư mục mới, chạy 1_BUILD_WINDOWS.bat. Script build VST3 và hai executable kiểm thử, chạy ctest, rồi chép plugin vào XuatBan. Inno Setup cần cho 3_BUILD_VA_TAO_BO_CAI.bat. Script chưa được chạy native trên Windows trong đợt sửa này.

Có thể build trực tiếp bằng CMake:

```powershell
cmake -S . -B build-live -G "Visual Studio 17 2022" -A x64 -DBUILD_TESTING=ON
cmake --build build-live --config Release --target AutoTunePro_VST3 LiveDSPTests LiveProcessorTests
ctest --test-dir build-live -C Release --output-on-failure
```

Kết quả VST3: build-live/AutoTunePro_artefacts/Release/VST3/Auto-Tune Pro.vst3. Đây là tên gốc của target, không phải binary hãng.

## macOS

Cài Xcode Command Line Tools và CMake. Chạy MAC_1_BUILD_VA_TAO_BO_CAI.command để build Universal VST3/Standalone và kiểm thử. Việc ký ad-hoc phục vụ bản build nội bộ; chưa xác nhận Developer ID/notarization hoặc bộ cài trên máy Mac thực tế. Có thể build trực tiếp:

```sh
cmake -S . -B build-live -DCMAKE_BUILD_TYPE=Release -DCMAKE_OSX_ARCHITECTURES="arm64;x86_64" -DBUILD_TESTING=ON
cmake --build build-live --config Release --target AutoTunePro_VST3 LiveDSPTests LiveProcessorTests
ctest --test-dir build-live -C Release --output-on-failure
```

## DSP tests không cần JUCE hoặc GUI

```sh
cmake -S . -B build-dsp -DCMAKE_BUILD_TYPE=Release -DDSP_TESTS_ONLY=ON -DBUILD_TESTING=ON
cmake --build build-dsp --config Release
ctest --test-dir build-dsp -C Release --output-on-failure
```

Kiểm thử processor/UI cần desktop hoạt động. Trên Linux headless cần Xvfb và môi trường X11 có các atom của window manager. TEST_RESULTS ghi rõ môi trường thử của bản này.
