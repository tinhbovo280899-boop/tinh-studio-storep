#include "dsp/LivePitchDSP.h"
#include "BaselineDSP.h"
#include <cstdio>
#include <limits>
#include <memory>
#include <vector>
static int failures=0;
#define CHECK(x) do { if(!(x)){std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;} }while(0)
template<class D> float tick(D& dsp,float x,bool legacy=false,int voice=1,double srRetune=20){
    const std::array<int,12> notes{};
    return dsp.processSample(x,voice,0,2,notes,legacy,legacy,legacy?190:100,
        legacy?7:0,0,50,srRetune,0,0,0,false,legacy?3:0,5.5,0,0,30,legacy?80:0,30,70);
}
template<class D> float formant(D& dsp,float x,bool on){
    const std::array<int,12> notes{};
    return dsp.processSample(x,1,0,2,notes,false,on,100,0,0,50,20,0,0,0,false,0,5.5,500,500,30,0,30,70);
}
int main(){
    constexpr double pi=3.14159265358979323846;
    { // Reproduce the original formant switch spike and compare to the untouched raw path.
        auto old=std::make_unique<baseline::AntaresAutoTuneChannelDSP>();
        auto raw=std::make_unique<baseline::AntaresAutoTuneChannelDSP>();
        auto live=std::make_unique<AntaresAutoTuneChannelDSP>();
        old->prepare(48000);raw->prepare(48000);live->prepare(48000);
        double oldPeak=0,newPeak=0,maxError=0;
        for(int n=0;n<96000;++n){
            float x=float(.2*std::sin(2*pi*225*n/48000.0)*std::min(1.0,n/1200.0));
            const float a=formant(*old,x,n>=48000),b=formant(*live,x,n>=48000),c=formant(*raw,x,false);
            oldPeak=std::max(oldPeak,std::abs(double(a)));newPeak=std::max(newPeak,std::abs(double(b)));
            maxError=std::max(maxError,std::abs(double(b)-c));
        }
        CHECK(oldPeak>1);CHECK(newPeak<.21);CHECK(maxError<1e-7);
        std::printf("Original formant switch peak %.6f; live %.6f; raw-path max error %.9f\n",oldPeak,newPeak,maxError);
    }
    { // Old Classic/Formant/Throat/transpose/artificial-vibrato settings cannot reactivate retired paths.
        AntaresAutoTuneChannelDSP reference,legacy;reference.prepare(48000);legacy.prepare(48000);
        double maxError=0;
        for(int n=0;n<96000;++n){float x=float(.15*std::sin(2*pi*196*n/48000.0));
            const auto a=tick(reference,x),b=tick(legacy,x,n>24000);
            maxError=std::max(maxError,std::abs(double(a)-b));}
        CHECK(maxError==0);std::printf("Retired parameter toggles max difference %.9f\n",maxError);
    }
    for(double sr:{32000.,44100.,48000.,96000.})for(int voice:{0,1,2}){
        AntaresAutoTuneChannelDSP dsp;dsp.prepare(sr);double phase=0,peak=0;
        for(int n=0;n<int(sr*10);++n){double t=n/sr;
            const double hz=196*std::exp2(35*std::sin(2*pi*5.3*t)/1200);
            phase+=2*pi*hz/sr;
            float x=float(.1*(std::sin(phase)+.4*std::sin(2*phase)+.2*std::sin(4*phase)));
            const auto y=tick(dsp,x,(n/257)%2,voice,n%48000<24000?0:20);
            if(!std::isfinite(y)){CHECK(false);break;}
            peak=std::max(peak,std::abs(double(y)));
        }
        CHECK(peak<.25);std::printf("10s held vibrato sr %.0f voice %d peak %.6f\n",sr,voice,peak);
    }
    for(double sr:{44100.,48000.,96000.}){
        AntaresAutoTuneChannelDSP a,b;a.prepare(sr);b.prepare(sr);double error=0;
        for(int n=0;n<int(sr);++n){float x=float(.15*std::sin(2*pi*225*n/sr));
            const bool invalid=n==1000||n==2000;
            const float bad=n==1000?std::numeric_limits<float>::quiet_NaN():std::numeric_limits<float>::infinity();
            const float ya=tick(a,invalid?bad:x),yb=tick(b,invalid?0:x);
            CHECK(std::isfinite(ya));error=std::max(error,std::abs(double(ya)-yb));}
        CHECK(error==0);
    }
    AntaresAutoTuneChannelDSP finite;finite.prepare(std::numeric_limits<double>::quiet_NaN());
    for(int n=0;n<20000;++n)CHECK(std::isfinite(tick(finite,n%19?.1f:std::numeric_limits<float>::infinity())));
    std::printf("Live DSP regressions: %d failures\n",failures);return failures?1:0;
}
