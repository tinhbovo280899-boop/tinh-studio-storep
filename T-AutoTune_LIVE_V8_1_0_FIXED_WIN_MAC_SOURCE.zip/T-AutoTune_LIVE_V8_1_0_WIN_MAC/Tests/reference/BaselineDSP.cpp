#include "BaselineDSP.h"
namespace baseline {
namespace
{
    static constexpr double kPi = 3.14159265358979323846;

    // 29 Authentic Antares Auto-Tune Pro Scales (1 = Note Active in Scale, 0 = Removed)
    // Intervals relative to Root Key (0 = Root, 1 = m2, ..., 11 = M7)
    static const int kScaleMasks[29][12] = {
        {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1}, // 0: MAJOR
        {1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0}, // 1: MINOR
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, // 2: CHROMATIC
        {1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1}, // 3: HARMONIC MINOR
        {1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1}, // 4: MELODIC MINOR
        {1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0}, // 5: DORIAN
        {1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0}, // 6: PHRYGIAN
        {1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1}, // 7: LYDIAN
        {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0}, // 8: MIXOLYDIAN
        {1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0}, // 9: LOCRIAN
        {1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0}, // 10: PENTATONIC MAJOR
        {1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0}, // 11: PENTATONIC MINOR
        {1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0}, // 12: BLUES
        {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0}, // 13: WHOLE TONE
        {1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1}, // 14: OCTATONIC (W-H)
        {1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0}, // 15: OCTATONIC (H-W)
        {1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0}, // 16: PHRYGIAN DOMINANT
        {1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1}, // 17: HUNGARIAN MINOR
        {1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1}, // 18: DOUBLE HARMONIC (ARABIC)
        {1, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0}, // 19: IN SEN (JAPANESE)
        {1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0}, // 20: HIRAJOSHI
        {1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0}, // 21: HIJAZ
        {1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0}, // 22: LYDIAN DOMINANT
        {1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0}, // 23: ALTERED
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0}, // 24: MIXOLYDIAN b6
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1}, // 25: HARMONIC MAJOR
        {1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0}, // 26: BEBOP DOMINANT
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1}, // 27: BEBOP MAJOR
        {1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1}  // 28: RYUKYU (OKINAWAN)
    };
}

//==============================================================================
// AntaresAutoTuneChannelDSP Implementation (Decompiled from 0x1800b8d20..0x1800c6310)
//==============================================================================
void AntaresAutoTuneChannelDSP::prepare(double newSampleRate)
{
    sampleRate = std::max(8000.0, newSampleRate);

    // Downsample_DSP::SetSampleRate (0x1800b8e60..0x1800b9227):
    // Determine integer downsample factor so pitch analysis runs near 44.1/48 kHz
    if (sampleRate > 128000.0)
        downsampleFactor = 4;
    else if (sampleRate > 64000.0)
        downsampleFactor = 2;
    else
        downsampleFactor = 1;

    analysisRate = sampleRate / static_cast<double>(downsampleFactor);

    // 6-stage anti-aliasing biquad cascade before decimation (0x1800b8e60)
    const double aaCutoff = 0.42 * analysisRate;
    static const double kStageQ[6] = { 0.5176, 0.7071, 1.9319, 0.5176, 0.7071, 1.9319 };
    for (int i = 0; i < 6; ++i)
    {
        downsampleFilters[static_cast<size_t>(i)].setLowpass(aaCutoff, sampleRate, kStageQ[i]);
        downsampleFilters[static_cast<size_t>(i)].reset();
    }

    // LPC Order selection from AT_DSPObject::SetSampleRate (0x1800ba140)
    lpcOrder = (sampleRate >= 88200.0) ? 16 : 12;
    preEmphasisPole = std::exp(-2.0 * kPi * 300.0 / sampleRate);

    currentVoiceType = -1;
    updateVoiceTypeFilters(0);
    reset();
}

void AntaresAutoTuneChannelDSP::reset()
{
    for (auto& f : downsampleFilters)
        f.reset();

    inputLP1.reset();
    inputLP2.reset();
    inputHP1.reset();
    shiftLP1.reset();
    shiftLP2.reset();

    detectorRing.fill(0.0);
    runningEnergy.fill(0.0);
    runningCorr.fill(0.0);
    detWriteIdx = 0;
    downsampleCounter = 0;
    updateSubCounter = 0;

    currentPeriodSamples = analysisRate / 220.0;
    smoothedPeriodSamples = currentPeriodSamples;
    fastPitchMidi = 60.0;
    slowPitchMidi = 60.0;
    voicedState = false;
    lockedTargetNote = -1;
    sustainedNoteFrames = 0;
    smoothedPitchRatio = 1.0;

    vibPhase = 0.0;
    vibNoteOnsetSec = 0.0;

    preEmpZ1 = 0.0;
    deEmpZ1 = 0.0;
    lpcAnalysisWin.fill(0.0);
    lpcWinWriteIdx = 0;
    lpcFrameCounter = 0;
    lpcA.fill(0.0);
    lpcWarpedA.fill(0.0);
    lpcA[0] = 1.0;
    lpcWarpedA[0] = 1.0;
    invFilterHist.fill(0.0);
    synFilterHist.fill(0.0);

    rawInputRing.fill(0.0);
    residualRing.fill(0.0);
    psolaWriteIdx = 0;
    const double initDelay = std::clamp(sampleRate * 0.008, 64.0, 1024.0);
    readPtrA = static_cast<double>(kRingSize) - initDelay;
    readPtrB = readPtrA;
    crossfadeAlpha = 0.0;
    crossfadeStep = 0.0;
    crossfadingToB = false;

    lastDetectedMidi = -1.0f;
    lastTargetMidi = -1.0f;
    lastCentsCorrection = 0.0f;
}

void AntaresAutoTuneChannelDSP::updateVoiceTypeFilters(int voiceType)
{
    if (voiceType == currentVoiceType)
        return;

    currentVoiceType = voiceType;

    // Exact Input Voice Type cutoffs from 0x1800c5760 & 0x1800c59b0:
    //   0 = SOPRANO    (600..1200 Hz filter, fundamental range 175..1050 Hz)
    //   1 = ALTO/TENOR (400..800 Hz filter,  fundamental range 110..700 Hz)
    //   2 = LOW MALE   (300..600 Hz filter,  fundamental range 75..450 Hz)
    //   3 = INSTRUMENT (1000..2000 Hz filter, fundamental range 65..1200 Hz)
    //   4 = BASS INST  (200..400 Hz filter,  fundamental range 35..260 Hz)
    double lpCutoff1 = 600.0, lpCutoff2 = 1200.0, hpCutoff = 120.0;
    double fMinHz = 175.0, fMaxHz = 1050.0;

    switch (voiceType)
    {
        case 0: // Soprano
            lpCutoff1 = 600.0;  lpCutoff2 = 1200.0; hpCutoff = 150.0;
            fMinHz = 170.0;     fMaxHz = 1050.0;
            break;
        case 1: // Alto / Tenor
            lpCutoff1 = 400.0;  lpCutoff2 = 800.0;  hpCutoff = 95.0;
            fMinHz = 105.0;     fMaxHz = 700.0;
            break;
        case 2: // Low Male
            lpCutoff1 = 300.0;  lpCutoff2 = 600.0;  hpCutoff = 65.0;
            fMinHz = 70.0;      fMaxHz = 450.0;
            break;
        case 3: // Instrument
            lpCutoff1 = 1000.0; lpCutoff2 = 2000.0; hpCutoff = 55.0;
            fMinHz = 65.0;      fMaxHz = 1200.0;
            break;
        case 4: // Bass Inst
        default:
            lpCutoff1 = 200.0;  lpCutoff2 = 400.0;  hpCutoff = 30.0;
            fMinHz = 35.0;      fMaxHz = 260.0;
            break;
    }

    inputLP1.setLowpass(lpCutoff1, analysisRate, 0.7071067811865475);
    inputLP2.setLowpass(lpCutoff2, analysisRate, 0.7071067811865475);
    inputHP1.setHighpass(hpCutoff, analysisRate, 0.7071067811865475);

    minPeriodSamples = std::clamp(analysisRate / fMaxHz, 12.0, 1024.0);
    maxPeriodSamples = std::clamp(analysisRate / fMinHz, minPeriodSamples + 16.0, 1800.0);

    // Populate logarithmically-spaced + dense integer candidate lag table for running autocorrelation
    numActiveLags = 0;
    const int minLagInt = std::max(8, static_cast<int>( std::floor(minPeriodSamples)));
    const int maxLagInt = std::min((kRingSize / 2) - 4, static_cast<int>(std::ceil(maxPeriodSamples)));
    const double ratio = std::pow(static_cast<double>(maxLagInt) / static_cast<double>(minLagInt),
                                  1.0 / static_cast<double>(kNumLagBins - 1));
    int prevLag = -1;
    for (int i = 0; i < kNumLagBins; ++i)
    {
        int lag = static_cast<int>(std::round(minLagInt * std::pow(ratio, static_cast<double>(i))));
        if (lag <= prevLag)
            lag = prevLag + 1;
        if (lag > maxLagInt)
            break;
        lagTable[static_cast<size_t>(numActiveLags++)] = lag;
        prevLag = lag;
    }
    runningEnergy.fill(0.0);
    runningCorr.fill(0.0);
}

//==============================================================================
// Kelly-Lochbaum Vocal Tract Tube + Levinson-Durbin LPC Formant & Throat Modeling
// Reconstructed from 0x1800ba4a0 .. 0x1800bb880
//==============================================================================
void AntaresAutoTuneChannelDSP::analyzeLPCAndThroat(double pitchPeriodSamples, double effectiveThroatRatio)
{
    const int N = 256;
    const int p = lpcOrder;
    std::array<double, 256> winSig {};

    // Extract latest 256 pre-emphasized samples with Hann window
    for (int n = 0; n < N; ++n)
    {
        const int idx = (lpcWinWriteIdx - N + n + 512) & 511;
        const double w = 0.5 * (1.0 - std::cos(2.0 * kPi * static_cast<double>(n) / static_cast<double>(N - 1)));
        winSig[static_cast<size_t>(n)] = lpcAnalysisWin[static_cast<size_t>(idx)] * w;
    }

    // Compute autocorrelation R[0..p] with Antares sinc^2(k * pi / T0) pitch-harmonic lag window (0x1800ba580)
    std::array<double, kMaxLPCOrder + 1> R {};
    const double T0 = std::clamp(pitchPeriodSamples * downsampleFactor, 20.0, 1000.0);
    for (int k = 0; k <= p; ++k)
    {
        double sum = 0.0;
        for (int n = k; n < N; ++n)
            sum += winSig[static_cast<size_t>(n)] * winSig[static_cast<size_t>(n - k)];

        double lagWin = 1.0;
        if (k > 0)
        {
            const double x = (static_cast<double>(k) * kPi) / T0;
            const double sinc = std::sin(x) / x;
            lagWin = sinc * sinc;
        }
        R[static_cast<size_t>(k)] = sum * lagWin;
    }

    if (R[0] < 1.0e-9)
    {
        lpcA.fill(0.0);
        lpcWarpedA.fill(0.0);
        lpcA[0] = 1.0;
        lpcWarpedA[0] = 1.0;
        return;
    }

    // White-noise diagonal loading for guaranteed all-pole stability
    R[0] *= 1.002;

    // Levinson-Durbin recursion (0x1800ba6a0..0x1800ba980) -> reflection coefficients k_refl[1..p] & LPC a[1..p]
    std::array<double, kMaxLPCOrder + 1> a {};
    std::array<double, kMaxLPCOrder + 1> aPrev {};
    std::array<double, kMaxLPCOrder + 1> kRefl {};
    a[0] = 1.0;
    double E = R[0];

    for (int i = 1; i <= p; ++i)
    {
        double acc = R[static_cast<size_t>(i)];
        for (int j = 1; j < i; ++j)
            acc += a[static_cast<size_t>(j)] * R[static_cast<size_t>(i - j)];

        double ki = -acc / std::max(E, 1.0e-12);
        ki = std::clamp(ki, -0.985, 0.985);
        kRefl[static_cast<size_t>(i)] = ki;

        aPrev = a;
        a[static_cast<size_t>(i)] = ki;
        for (int j = 1; j < i; ++j)
            a[static_cast<size_t>(j)] = aPrev[static_cast<size_t>(j)] + ki * aPrev[static_cast<size_t>(i - j)];

        E *= (1.0 - ki * ki);
        if (E <= 1.0e-12)
            break;
    }

    lpcA = a;

    // Kelly-Lochbaum Vocal Tract Cross-Sectional Tube Area Function A[0..p] (0x1800ba990..0x1800baa80):
    //   A[i] = A[i-1] * (1.0 - k[i]) / (1.0 + k[i])
    std::array<double, kMaxLPCOrder + 1> tubeArea {};
    tubeArea[0] = 1.0;
    for (int i = 1; i <= p; ++i)
    {
        const double ki = std::clamp(kRefl[static_cast<size_t>(i)], -0.98, 0.98);
        tubeArea[static_cast<size_t>(i)] = tubeArea[static_cast<size_t>(i - 1)] * ((1.0 - ki) / (1.0 + ki));
    }

    // Linear resampling of the vocal tract area function by Throat Length (0x1800baaa0..0x1800bad80)
    // throatRatio = 1.0 -> unwarped; < 1.0 -> shorter throat; > 1.0 -> longer throat
    std::array<double, kMaxLPCOrder + 1> warpedArea {};
    warpedArea[0] = tubeArea[0];
    const double stretch = std::clamp(effectiveThroatRatio, 0.50, 1.90);

    for (int i = 1; i <= p; ++i)
    {
        const double srcPos = std::clamp(static_cast<double>(i) / stretch, 0.0, static_cast<double>(p));
        const int idx0 = static_cast<int>(std::floor(srcPos));
        const int idx1 = std::min(p, idx0 + 1);
        const double frac = srcPos - static_cast<double>(idx0);
        warpedArea[static_cast<size_t>(i)] =
            tubeArea[static_cast<size_t>(idx0)] * (1.0 - frac) + tubeArea[static_cast<size_t>(idx1)] * frac;
    }

    // Convert warped tube areas back to warped PARCOR reflection coefficients k_warped[1..p]
    // and step-up to warped LPC synthesis filter coefficients a_warped[1..p] (0x1800bada0..0x1800bb100)
    std::array<double, kMaxLPCOrder + 1> aWarped {};
    aWarped[0] = 1.0;

    for (int i = 1; i <= p; ++i)
    {
        const double Aprev = std::max(1.0e-9, warpedArea[static_cast<size_t>(i - 1)]);
        const double Acurr = std::max(1.0e-9, warpedArea[static_cast<size_t>(i)]);
        double kw = (Aprev - Acurr) / (Aprev + Acurr);
        kw = std::clamp(kw, -0.98, 0.98);

        aPrev = aWarped;
        aWarped[static_cast<size_t>(i)] = kw;
        for (int j = 1; j < i; ++j)
            aWarped[static_cast<size_t>(j)] = aPrev[static_cast<size_t>(j)] + kw * aPrev[static_cast<size_t>(i - j)];
    }

    lpcWarpedA = aWarped;
}

// Inverse LPC Filter A(z) extracting glottal excitation residual (0x1800bb1d0)
double AntaresAutoTuneChannelDSP::inverseFilterLPC(double x) noexcept
{
    double res = x;
    for (int i = 1; i <= lpcOrder; ++i)
        res += lpcA[static_cast<size_t>(i)] * invFilterHist[static_cast<size_t>(i)];

    for (int i = lpcOrder; i >= 2; --i)
        invFilterHist[static_cast<size_t>(i)] = invFilterHist[static_cast<size_t>(i - 1)];
    invFilterHist[1] = x;
    return res;
}

// All-Pole Throat-Warped LPC Synthesis Filter 1 / A_warped(z) (0x1800bb440)
double AntaresAutoTuneChannelDSP::synthesizeThroatLPC(double excitation) noexcept
{
    double y = excitation;
    for (int i = 1; i <= lpcOrder; ++i)
        y -= lpcWarpedA[static_cast<size_t>(i)] * synFilterHist[static_cast<size_t>(i)];

    if (!std::isfinite(y) || std::abs(y) > 8.0)
        y = std::clamp(excitation, -2.0, 2.0);

    for (int i = lpcOrder; i >= 2; --i)
        synFilterHist[static_cast<size_t>(i)] = synFilterHist[static_cast<size_t>(i - 1)];
    synFilterHist[1] = y;
    return y;
}

// 3-Point Parabolic Sub-Sample Interpolation from 0x1800c2d50 & 0x1800c3195:
//   c1 = 0.5 * (y[+1] - y[-1])
//   c2 = 0.5 * (y[+1] + y[-1]) - y[0]
//   out = (c2 * frac + c1) * frac + y[0]
double AntaresAutoTuneChannelDSP::readParabolic(const std::array<double, kRingSize>& buf, double readPos) const noexcept
{
    int idx0 = static_cast<int>(std::floor(readPos));
    double frac = readPos - static_cast<double>(idx0);
    if (frac > 0.5)
    {
        idx0 += 1;
        frac -= 1.0; // center fractional offset in [-0.5, +0.5] as in 0x1800c2d40
    }
    const double ym1 = buf[static_cast<size_t>((idx0 - 1) & kRingMask)];
    const double y0  = buf[static_cast<size_t>(idx0 & kRingMask)];
    const double yp1 = buf[static_cast<size_t>((idx0 + 1) & kRingMask)];

    const double c1 = 0.5 * (yp1 - ym1);
    const double c2 = 0.5 * (yp1 + ym1) - y0;
    return (c2 * frac + c1) * frac + y0;
}

//==============================================================================
// Per-Sample Processing Loop (AT_DSPObject::ProcessBlock 0x1800c11b0..0x1800c3720)
//==============================================================================
float AntaresAutoTuneChannelDSP::processSample(
    float inputSample,
    int voiceType,
    int keyIdx,
    int scaleIdx,
    const std::array<int, 12>& noteStates,
    bool classicMode,
    bool useFormants,
    double throatLengthPct,
    double transposeSemi,
    double detuneCents,
    double trackingVal,
    double retuneSpeedMs,
    double flexTuneVal,
    double naturalVibDb,
    double humanizeVal,
    bool ignoreVibrato,
    int vibShape,
    double vibRateHz,
    double vibDelayMs,
    double vibTransMs,
    double vibVarVal,
    double vibPitchCents,
    double vibAmpVal,
    double vibFormantVal)
{
    (void)keyIdx; (void)scaleIdx;
    updateVoiceTypeFilters(voiceType);
    const double xIn = static_cast<double>(inputSample);

    // -------------------------------------------------------------------------
    // 1. Downsample_DSP Anti-Aliasing Front-End (0x1800b9230) & Voice Type Bandpass
    // -------------------------------------------------------------------------
    double xAA = xIn;
    if (downsampleFactor > 1)
    {
        for (auto& f : downsampleFilters)
            xAA = f.process(xAA);
    }

    if (++downsampleCounter >= downsampleFactor)
    {
        downsampleCounter = 0;

        // Input Voice Type band-limiting filter (0x1800c2000)
        const double xFiltered = inputHP1.process(inputLP2.process(inputLP1.process(xAA)));
        detectorRing[static_cast<size_t>(detWriteIdx)] = xFiltered;

        // Running sliding-window autocorrelation update across candidate lags (0x1800c2020..0x1800c21f0):
        //   energy[k] += x[n]^2 - x[n - 2*tau]^2
        //   corr[k]   += x[n]*x[n - tau] - x[n - tau]*x[n - 2*tau]
        const double xn = xFiltered;
        const double xn2 = xn * xn;
        for (int k = 0; k < numActiveLags; ++k)
        {
            const int tau = lagTable[static_cast<size_t>(k)];
            const double xTau  = detectorRing[static_cast<size_t>((detWriteIdx - tau) & kRingMask)];
            const double x2Tau = detectorRing[static_cast<size_t>((detWriteIdx - 2 * tau) & kRingMask)];

            runningEnergy[static_cast<size_t>(k)] =
                std::max(0.0, runningEnergy[static_cast<size_t>(k)] + xn2 - x2Tau * x2Tau);
            runningCorr[static_cast<size_t>(k)] += xn * xTau - xTau * x2Tau;
        }

        detWriteIdx = (detWriteIdx + 1) & kRingMask;
    }

    // -------------------------------------------------------------------------
    // 2. Pre-Emphasis & LPC Analysis Buffer Update (0x1800ba420..0x1800bb1d0)
    // -------------------------------------------------------------------------
    const bool formantsActive = (!classicMode && useFormants);
    const double xPre = xIn - preEmphasisPole * preEmpZ1;
    preEmpZ1 = xIn;

    lpcAnalysisWin[static_cast<size_t>(lpcWinWriteIdx)] = xPre;
    lpcWinWriteIdx = (lpcWinWriteIdx + 1) & 511;

    // -------------------------------------------------------------------------
    // 3. 5-Sample Control & Pitch-Tracking Frame Update (f_update = sr / 5.0, 0x1800c2280)
    // -------------------------------------------------------------------------
    if (++updateSubCounter >= 5)
    {
        updateSubCounter = 0;

        // Tracking threshold from Tracking_ID (1..100, default 50):
        // Higher Tracking value relaxes correlation threshold for breathier signals; lower requires stricter periodicity
        const double corrThreshold = std::clamp(0.88 - 0.0055 * trackingVal, 0.25, 0.85);

        // Search running autocorrelation for fundamental period T0 (0x1800c4cc0..0x1800c510c)
        int bestBin = -1;
        double maxGlobalEnergy = 0.0;

        for (int k = 0; k < numActiveLags; ++k)
            maxGlobalEnergy = std::max(maxGlobalEnergy, runningEnergy[static_cast<size_t>(k)]);

        if (maxGlobalEnergy > 1.0e-7)
        {
            // Find global maximum normalized correlation first
            double globalPeak = 0.0;
            for (int k = 1; k < numActiveLags - 1; ++k)
            {
                const double e = runningEnergy[static_cast<size_t>(k)];
                if (e <= 1.0e-9)
                    continue;
                const double nc = runningCorr[static_cast<size_t>(k)] / (0.5 * e + 1.0e-9);
                if (nc > globalPeak)
                    globalPeak = nc;
            }

            // Classic Mode vs Evo Mode peak selection:
            // Select first local peak >= (evo ? 0.86 : 0.82) * globalPeak to avoid sub-harmonic octave errors
            const double octaveGuard = classicMode ? 0.82 : 0.86;
            for (int k = 1; k < numActiveLags - 1; ++k)
            {
                const double eCurr = std::max(1.0e-9, runningEnergy[static_cast<size_t>(k)]);
                const double ePrev = std::max(1.0e-9, runningEnergy[static_cast<size_t>(k - 1)]);
                const double eNext = std::max(1.0e-9, runningEnergy[static_cast<size_t>(k + 1)]);

                const double ncCurr = runningCorr[static_cast<size_t>(k)] / (0.5 * eCurr);
                const double ncPrev = runningCorr[static_cast<size_t>(k - 1)] / (0.5 * ePrev);
                const double ncNext = runningCorr[static_cast<size_t>(k + 1)] / (0.5 * eNext);

                if (ncCurr >= ncPrev && ncCurr >= ncNext && ncCurr >= corrThreshold && ncCurr >= octaveGuard * globalPeak)
                {
                    bestBin = k;
                    break;
                }
            }
        }

        if (bestBin > 0 && bestBin < numActiveLags - 1)
        {
            // Parabolic sub-sample lag refinement (0x1800c4ee0)
            const int tau0 = lagTable[static_cast<size_t>(bestBin)];
            // Evaluate exact lags tau0 - 1, tau0, tau0 + 1 in detectorRing for sub-sample precision
            double cMinus = 0.0, cZero = 0.0, cPlus = 0.0;
            const int winLen = std::min(2 * tau0, 512);
            for (int i = 0; i < winLen; ++i)
            {
                const double s0 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - i) & kRingMask)];
                cMinus += s0 * detectorRing[static_cast<size_t>((detWriteIdx - 1 - i - (tau0 - 1)) & kRingMask)];
                cZero  += s0 * detectorRing[static_cast<size_t>((detWriteIdx - 1 - i - tau0) & kRingMask)];
                cPlus  += s0 * detectorRing[static_cast<size_t>((detWriteIdx - 1 - i - (tau0 + 1)) & kRingMask)];
            }
            const double denom = cMinus - 2.0 * cZero + cPlus;
            double delta = 0.0;
            if (std::abs(denom) > 1.0e-9)
                delta = std::clamp(0.5 * (cMinus - cPlus) / denom, -0.5, 0.5);

            const double detectedPeriod = std::clamp(static_cast<double>(tau0) + delta, minPeriodSamples, maxPeriodSamples);
            currentPeriodSamples = detectedPeriod;
            smoothedPeriodSamples = 0.75 * smoothedPeriodSamples + 0.25 * detectedPeriod;

            // Convert detected period to MIDI note relative to Detune reference (default 440.0 Hz)
            const double refA4Hz = 440.0 * std::pow(2.0, detuneCents / 1200.0);
            const double detectedHz = analysisRate / smoothedPeriodSamples;
            const double rawMidi = 69.0 + 12.0 * std::log2(std::max(20.0, detectedHz) / refA4Hz);

            if (!voicedState)
            {
                fastPitchMidi = rawMidi;
                slowPitchMidi = rawMidi;
                voicedState = true;
            }
            else
            {
                fastPitchMidi = 0.65 * fastPitchMidi + 0.35 * rawMidi;
                // Slow LPF tracks average center pitch (used by Ignore Vibrato & Natural Vibrato separation)
                slowPitchMidi = 0.965 * slowPitchMidi + 0.035 * rawMidi;
            }

            lastDetectedMidi = static_cast<float>(fastPitchMidi);

            // -----------------------------------------------------------------
            // 4. Scale Quantization, Note Bypass/Remove & Flex-Tune Hysteresis (0x1800c3730..0x1800c3e64)
            // -----------------------------------------------------------------
            const double pitchForTarget = ignoreVibrato ? slowPitchMidi : fastPitchMidi;

            // Find nearest active/bypassed note in 12-tone scale
            int bestMidiNote = static_cast<int>(std::round(pitchForTarget));
            double minDist = 1.0e9;
            bool bestIsBypassed = false;

            const int baseMidi = static_cast<int>(std::floor(pitchForTarget)) - 12;
            for (int m = baseMidi; m <= baseMidi + 24; ++m)
            {
                const int pc = ((m % 12) + 12) % 12;
                const int st = noteStates[static_cast<size_t>(pc)];
                if (st == TAutoTuneProcessor::kNoteRemoved)
                    continue; // Removed notes are skipped during quantization!

                double dist = std::abs(pitchForTarget - static_cast<double>(m));
                // Note hysteresis: favor currently locked target note by 15 cents (0x1800c39a0)
                if (m == lockedTargetNote)
                    dist -= 0.15;

                if (dist < minDist)
                {
                    minDist = dist;
                    bestMidiNote = m;
                    bestIsBypassed = (st == TAutoTuneProcessor::kNoteBypassed);
                }
            }

            if (bestMidiNote == lockedTargetNote)
                sustainedNoteFrames++;
            else
            {
                lockedTargetNote = bestMidiNote;
                sustainedNoteFrames = 0;
                vibNoteOnsetSec = 0.0;
            }

            // Target MIDI note after Flex-Tune and Natural Vibrato
            double targetMidi = bestIsBypassed ? fastPitchMidi : static_cast<double>(bestMidiNote);

            if (!bestIsBypassed && !classicMode && flexTuneVal > 0.0)
            {
                // Flex-Tune (SolidTune_ID tag 90): expressive attraction zone around scale note
                const double flexNorm = std::clamp(flexTuneVal / 100.0, 0.0, 1.0);
                const double devSemi = fastPitchMidi - static_cast<double>(bestMidiNote);
                const double captureWidth = 0.15 + 0.85 * (1.0 - flexNorm);
                const double pull = std::exp(-(devSemi * devSemi) / std::max(0.02, captureWidth * captureWidth));
                const double effectivePull = pull * (1.0 - 0.75 * flexNorm);
                targetMidi = fastPitchMidi + effectivePull * (static_cast<double>(bestMidiNote) - fastPitchMidi);
            }

            // Natural Vibrato scaling (-12..+12 dB, tag 62, 0x1800c3cf0):
            // Extracts high-frequency vibrato component (fastPitchMidi - slowPitchMidi) and scales by 10^(dB/20)
            const double vibComponent = fastPitchMidi - slowPitchMidi;
            const double natVibGain = std::pow(10.0, naturalVibDb / 20.0);
            targetMidi += vibComponent * (natVibGain - 1.0);

            // Transpose (-12..+12 semitones, disabled in Classic Mode)
            const double activeTranspose = classicMode ? 0.0 : transposeSemi;

            // Synthetic Vibrato LFO (Shape, Rate, Delay, Transition, Variation, Pitch, Amplitude, Formant)
            double synVibSemi = 0.0;
            double synVibFormantRatio = 1.0;
            (void)vibAmpVal;
            const double dtControl = 5.0 / sampleRate;
            vibNoteOnsetSec += dtControl;

            if (vibShape > 0 && vibPitchCents > 0.0)
            {
                const double delaySec = vibDelayMs * 0.001;
                const double transSec = std::max(0.001, vibTransMs * 0.001);
                double env = 0.0;
                if (vibNoteOnsetSec > delaySec)
                    env = std::clamp((vibNoteOnsetSec - delaySec) / transSec, 0.0, 1.0);

                // Subtle random rate variation from VibratoVariation_ID
                rngState = rngState * 1664525u + 1013904223u;
                const double randBipolar = (static_cast<double>(rngState & 0xFFFFu) / 32768.0) - 1.0;
                const double instRate = std::max(0.1, vibRateHz * (1.0 + 0.0015 * vibVarVal * randBipolar));
                vibPhase += instRate * dtControl;
                vibPhase -= std::floor(vibPhase);

                double lfo = 0.0;
                if (vibShape == 1) // Sine Wave
                    lfo = std::sin(2.0 * kPi * vibPhase);
                else if (vibShape == 2) // Square
                    lfo = (vibPhase < 0.5) ? 1.0 : -1.0;
                else // Sawtooth
                    lfo = 2.0 * vibPhase - 1.0;

                synVibSemi = env * (vibPitchCents / 100.0) * lfo;
                synVibFormantRatio = 1.0 + env * (vibFormantVal / 100.0) * 0.06 * lfo;
            }

            const double finalTargetMidi = targetMidi + activeTranspose + synVibSemi;
            const double rawTargetRatio = std::pow(2.0, (finalTargetMidi - fastPitchMidi) / 12.0);

            // -----------------------------------------------------------------
            // 5. Exact Decompiled Retune Speed & Humanize Smoothing (0x1800c5460..0x1800c55cd & 0x1800c22f1..0x1800c23d6)
            //   f_update = sampleRate / 5.0
            //   retuneCoeff   = (retuneSpeedMs <= 0.0) ? 0.0 : pow(0.5, 1.0 / (f_update * (retuneSpeedMs / 1000.0)))
            //   humanizeCoeff = pow(0.5, 1.0 / (f_update * ((retuneSpeedMs + humanizeExtraMs) / 1000.0)))
            //   Linear ramp over int((sampleRate * 0.4) / 5.0) frames (400 ms sustained note)
            // -----------------------------------------------------------------
            const double fUpdate = sampleRate / 5.0;
            const double retuneCoeff = (retuneSpeedMs <= 0.001)
                ? 0.0
                : std::pow(0.5, 1.0 / std::max(1.0, fUpdate * (retuneSpeedMs * 0.001)));

            double smoothCoeff = retuneCoeff;
            if (humanizeVal > 0.0)
            {
                const double humanizeExtraMs = (humanizeVal / 100.0) * 250.0;
                const double humanizeCoeff = std::pow(
                    0.5, 1.0 / std::max(1.0, fUpdate * ((retuneSpeedMs + humanizeExtraMs) * 0.001)));
                const int rampFrames = std::max(1, static_cast<int>((sampleRate * 0.4) / 5.0));
                const double rampFrac = std::clamp(
                    static_cast<double>(sustainedNoteFrames) / static_cast<double>(rampFrames), 0.0, 1.0);
                smoothCoeff = retuneCoeff + rampFrac * (humanizeCoeff - retuneCoeff);
            }

            smoothedPitchRatio = smoothCoeff * smoothedPitchRatio + (1.0 - smoothCoeff) * rawTargetRatio;
            smoothedPitchRatio = std::clamp(smoothedPitchRatio, 0.25, 4.0);

            lastTargetMidi = static_cast<float>(finalTargetMidi - activeTranspose);
            lastCentsCorrection = static_cast<float>(
                std::clamp(1200.0 * std::log2(smoothedPitchRatio) - activeTranspose * 100.0, -50.0, 50.0));

            // Update upward-shift anti-aliasing filters (0x1800c242b: cutoff = 0.49 * sr / pitchRatio)
            if (smoothedPitchRatio > 1.01)
            {
                const double shiftCutoff = (0.49 * sampleRate) / smoothedPitchRatio;
                shiftLP1.setLowpass(shiftCutoff, sampleRate, 0.7071067811865475);
                shiftLP2.setLowpass(shiftCutoff, sampleRate, 0.7071067811865475);
            }

            // Update LPC & Kelly-Lochbaum vocal tract model every 32 control frames (~3.6 ms)
            if (formantsActive && (++lpcFrameCounter >= 6))
            {
                lpcFrameCounter = 0;
                const double userThroatRatio = (throatLengthPct / 100.0) * synVibFormantRatio;
                analyzeLPCAndThroat(smoothedPeriodSamples, userThroatRatio);
            }
        }
        else
        {
            // Unvoiced / consonant / silence: relax pitch ratio smoothly toward 1.0
            voicedState = false;
            sustainedNoteFrames = 0;
            smoothedPitchRatio = 0.92 * smoothedPitchRatio + 0.08 * 1.0;
            lastCentsCorrection *= 0.85f;
        }
    }

    // -------------------------------------------------------------------------
    // 6. LPC Inverse Filtering & Dual-Pointer Parabolic TD-PSOLA Resynthesis (0x1800c28e0..0x1800c3218)
    // -------------------------------------------------------------------------
    double psolaInput = xIn;
    if (smoothedPitchRatio > 1.01)
        psolaInput = shiftLP2.process(shiftLP1.process(psolaInput));

    const double excitation = formantsActive ? inverseFilterLPC(xPre) : psolaInput;
    rawInputRing[static_cast<size_t>(psolaWriteIdx)] = psolaInput;
    residualRing[static_cast<size_t>(psolaWriteIdx)] = excitation;

    const auto& activeRing = formantsActive ? residualRing : rawInputRing;

    // Full-rate pitch period T0 in samples
    const double T0Full = std::clamp(smoothedPeriodSamples * static_cast<double>(downsampleFactor), 24.0, 2048.0);
    const double minDelay = std::max(32.0, 0.6 * T0Full);
    const double maxDelay = std::min(static_cast<double>(kRingSize - 64), minDelay + 2.2 * T0Full);

    // Distance of active read pointer behind write pointer
    const double activePtr = crossfadingToB ? readPtrB : readPtrA;
    double delaySamples = static_cast<double>(psolaWriteIdx) - activePtr;
    while (delaySamples < 0.0)
        delaySamples += static_cast<double>(kRingSize);
    while (delaySamples >= static_cast<double>(kRingSize))
        delaySamples -= static_cast<double>(kRingSize);

    // Trigger pitch-synchronous splice of 1 pitch period T0 when read pointer drifts outside [minDelay, maxDelay]
    // and no crossfade is currently active (0x1800c2df0..0x1800c3040)
    if (crossfadeStep <= 0.0 && (delaySamples < minDelay || delaySamples > maxDelay))
    {
        double newDelay = delaySamples;
        while (newDelay < minDelay)
            newDelay += T0Full;
        while (newDelay > maxDelay)
            newDelay -= T0Full;

        double targetPtr = static_cast<double>(psolaWriteIdx) - newDelay;
        while (targetPtr < 0.0)
            targetPtr += static_cast<double>(kRingSize);

        readPtrB = targetPtr;
        crossfadeAlpha = 0.0;
        // 20% pitch-period crossfade step (0x1800c301c: step = 1.0 / (0.20 * T0))
        crossfadeStep = 1.0 / std::max(16.0, 0.20 * T0Full);
        crossfadingToB = true;
    }

    // Read primary pointer A and (if splicing) secondary pointer B with 3-point parabolic interpolation
    double resynthesized = readParabolic(activeRing, readPtrA);
    if (crossfadingToB)
    {
        const double sampleB = readParabolic(activeRing, readPtrB);
        crossfadeAlpha += crossfadeStep;
        if (crossfadeAlpha >= 1.0)
        {
            resynthesized = sampleB;
            readPtrA = readPtrB;
            crossfadeAlpha = 0.0;
            crossfadeStep = 0.0;
            crossfadingToB = false;
        }
        else
        {
            // Smooth equal-power / raised-cosine splice blend
            const double w = 0.5 * (1.0 - std::cos(kPi * crossfadeAlpha));
            resynthesized = (1.0 - w) * resynthesized + w * sampleB;
        }
    }

    // Advance read pointers by smoothedPitchRatio and wrap modulo kRingSize
    const double step = voicedState ? smoothedPitchRatio : 1.0;
    readPtrA += step;
    if (readPtrA >= static_cast<double>(kRingSize))
        readPtrA -= static_cast<double>(kRingSize);

    if (crossfadingToB)
    {
        readPtrB += step;
        if (readPtrB >= static_cast<double>(kRingSize))
            readPtrB -= static_cast<double>(kRingSize);
    }

    psolaWriteIdx = (psolaWriteIdx + 1) & kRingMask;

    // -------------------------------------------------------------------------
    // 7. Throat-Warped LPC Synthesis Filter 1/A_warped(z) & De-Emphasis (0x1800bb440 & 0x1800ba470)
    // -------------------------------------------------------------------------
    double yOut = resynthesized;
    if (formantsActive)
    {
        const double lpcSyn = synthesizeThroatLPC(resynthesized);
        // De-emphasis filter: y[n] = x[n] + pole * y[n-1] (0x1800ba470)
        deEmpZ1 = lpcSyn + preEmphasisPole * deEmpZ1;
        yOut = deEmpZ1;
    }

    return static_cast<float>(std::clamp(yOut, -4.0, 4.0));
}


}
