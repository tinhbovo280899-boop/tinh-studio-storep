#if defined(USE_BASELINE)
#include "reference/BaselineDSP.h"
using ProbeDSP=baseline::AntaresAutoTuneChannelDSP;
#else
#include "dsp/LivePitchDSP.h"
using ProbeDSP=AntaresAutoTuneChannelDSP;
#endif
#include <algorithm>
#include <chrono>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <iterator>
#include <vector>

int main(int argc,char** argv) {
    if(argc<2)return 2;
    std::cout<<"signal,formant,retune,voice,input_peak,output_peak_after_1s,max_step_after_1s,samples_above_1_after_1s,clamped_samples_after_1s,first_over_1_s,nonfinite,cpu_fraction_one_channel\n";
    for(int f=1;f<argc;++f) {
        std::ifstream input(argv[f],std::ios::binary|std::ios::ate);
        if(!input)return 3;
        const auto bytes=input.tellg();input.seekg(0);
        std::vector<float> x(static_cast<size_t>(bytes)/sizeof(float));
        input.read(reinterpret_cast<char*>(x.data()),bytes);
        if(!input)return 4;
        for(bool formant:{false,true})for(double retune:{0.0,20.0}) {
            ProbeDSP dsp;dsp.prepare(48000);
            const std::array<int,12> notes{};
            double inputPeak=0,peak=0,maxStep=0,first=-1,previous=0;
            int over=0,clamped=0,nonfinite=0;
            const auto started=std::chrono::steady_clock::now();
            for(size_t n=0;n<x.size();++n) {
                const float y=dsp.processSample(x[n],1,0,2,notes,false,formant,100,
                    0,0,50,retune,0,0,0,false,0,5.5,500,500,30,0,30,70);
                inputPeak=std::max(inputPeak,std::abs(static_cast<double>(x[n])));
                if(!std::isfinite(y))++nonfinite;
                else if(n>48000) {
                    peak=std::max(peak,std::abs(static_cast<double>(y)));
                    maxStep=std::max(maxStep,std::abs(y-previous));
                    if(std::abs(y)>1.0) {++over;if(first<0)first=n/48000.0;}
                    clamped+=std::abs(y)>=3.9999;
                }
                previous=y;
            }
            double runtime=std::chrono::duration<double>(std::chrono::steady_clock::now()-started).count();
            std::cout<<std::setprecision(8)<<argv[f]<<','<<formant<<','<<retune<<",1,"<<inputPeak<<','<<peak<<','<<maxStep<<','<<over<<','<<clamped<<','<<first<<','<<nonfinite<<','<<runtime/(x.size()/48000.0)<<'\n';
        }
    }
}
