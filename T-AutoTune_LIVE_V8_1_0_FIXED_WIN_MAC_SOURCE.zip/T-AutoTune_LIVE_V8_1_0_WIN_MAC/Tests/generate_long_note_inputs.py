"""Deterministic synthetic sustained-note fixtures for LongNoteProbe (requires NumPy)."""
import numpy as np

sr = 48000
n = sr * 20
t = np.arange(n) / sr
rng = np.random.default_rng(2107)
for base, depth, label in [(220, 35, "vibrato_220"), (110, 45, "breathy_110"), (440, 65, "vibrato_440")]:
    hz = base * np.exp2((depth * np.sin(2 * np.pi * 5.3 * t) + 12 * np.sin(2 * np.pi * .17 * t)) / 1200)
    phase = 2 * np.pi * np.cumsum(hz) / sr
    y = np.zeros(n)
    for harmonic in range(1, 41):
        frequency = harmonic * base
        weight = (0.1 + 3 * np.exp(-.5 * ((frequency - 650) / 120)**2)
                  + 2 * np.exp(-.5 * ((frequency - 1200) / 180)**2)
                  + np.exp(-.5 * ((frequency - 2500) / 220)**2)) / harmonic
        y += weight * np.sin(harmonic * phase + .06 * harmonic * np.sin(2 * np.pi * .11 * t))
    y /= np.max(np.abs(y))
    envelope = .6 + .4 * np.sin(2 * np.pi * .29 * t + .5)**2
    if label.startswith("breathy"):
        envelope *= np.exp(-t / 10)
        y += rng.normal(0, 1, n) * (.01 + .08 * (t / 20)**3)
    else:
        y += rng.normal(0, .005, n)
    fade = np.minimum(1, t / .05) * np.minimum(1, (20 - t) / .05)
    y *= envelope * fade
    y *= .2 / np.max(np.abs(y))
    y.astype("<f4").tofile(label + ".f32")
