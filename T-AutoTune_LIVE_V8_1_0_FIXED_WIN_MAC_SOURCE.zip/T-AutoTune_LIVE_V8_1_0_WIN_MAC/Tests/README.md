# Reproduce measurements

LiveDSPTests checks the legacy Formant spike against the unmodified engine under reference/, compares the live result to the original Formant-Off path, tests retired settings, held vibrato, sample rates and invalid input. The reference engine is test-only and is not linked into the plugin.

LiveProcessorTests checks normal isolated trial verification, retired host parameters, custom-note state, key/scale updates, meters, GUI hit testing and opening/dismissing the Settings popup.

For Linux headless GUI tests, start Xvfb, then run:

```sh
DISPLAY=:99 python Tests/run_headless_gui.py ctest --test-dir build-live -C Release --output-on-failure
```

The helper initializes X11 atoms absent on a bare Xvfb server and keeps its X connection open during the test; it does not suppress X errors. A normal desktop/window manager does not need this helper.

Optional independent 20-second probes require NumPy to generate fixtures. From the source root, generate them in a separate writable directory with Tests/generate_long_note_inputs.py. Build these two executables, then run them from the directory containing the three .f32 inputs:

```sh
c++ -std=c++17 -O2 -ISource -ITests Tests/LongNoteProbe.cpp Source/dsp/LivePitchDSP.cpp -o live-long
c++ -std=c++17 -O2 -DUSE_BASELINE -ITests -ITests/reference Tests/LongNoteProbe.cpp Tests/reference/BaselineDSP.cpp -o original-long
./live-long vibrato_220.f32 breathy_110.f32 vibrato_440.f32
./original-long vibrato_220.f32 breathy_110.f32 vibrato_440.f32
```

Generated fixtures are not included in the ZIP. CSV results in TEST_RESULTS contain measurements after the first second; full_signal_metrics.json contains original startup/switch metrics at 48 kHz. CPU figures were measured on the cloud machine and do not establish CPU load on the user's host.
