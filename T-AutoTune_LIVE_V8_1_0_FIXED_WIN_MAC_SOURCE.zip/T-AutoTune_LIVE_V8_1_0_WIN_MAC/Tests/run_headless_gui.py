from pathlib import Path
import ctypes, os, re, subprocess, sys
lib=ctypes.CDLL('libX11.so.6')
lib.XOpenDisplay.argtypes=[ctypes.c_char_p];lib.XOpenDisplay.restype=ctypes.c_void_p
lib.XInternAtom.argtypes=[ctypes.c_void_p,ctypes.c_char_p,ctypes.c_int];lib.XInternAtom.restype=ctypes.c_ulong
lib.XSync.argtypes=[ctypes.c_void_p,ctypes.c_int];lib.XCloseDisplay.argtypes=[ctypes.c_void_p]
display=lib.XOpenDisplay(os.environ.get('DISPLAY','').encode())
if not display: raise SystemExit('No X11 test display')
source=Path(__file__).resolve().parent.parent/'ThirdParty/JUCE/modules/juce_gui_basics/native'
names=set()
for p in source.glob('juce_X*'):
 if p.is_file(): names.update(re.findall(r'"([A-Za-z_][A-Za-z0-9_]+)"',p.read_text(errors='replace')))
for name in names: lib.XInternAtom(display,name.encode(),0)
lib.XSync(display,0)
try:
 result=subprocess.run(sys.argv[1:])
finally: lib.XCloseDisplay(display)
raise SystemExit(result.returncode)
