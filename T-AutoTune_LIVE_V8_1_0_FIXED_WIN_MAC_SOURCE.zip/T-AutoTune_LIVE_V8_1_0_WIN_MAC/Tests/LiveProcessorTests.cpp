#include "TAutoTuneProcessor.h"
#include "TAutoTuneEditor.h"
#include <cstdio>
static int failures=0;
#define CHECK(x) do { if(!(x)){std::printf("FAIL %d: %s\n",__LINE__,#x);++failures;} }while(0)
static void set(TAutoTuneProcessor& p,const char* id,float value){auto* v=p.getAPVTS().getParameter(id);CHECK(v);if(v)v->setValueNotifyingHost(v->convertTo0to1(value));}
int main(){
    juce::ScopedJuceInitialiser_GUI gui;
    const auto root=juce::File::getSpecialLocation(juce::File::tempDirectory).getNonexistentChildFile("live-tune-tests","",false);
    CHECK(root.createDirectory().wasOk());
    struct Cleanup{juce::File f;~Cleanup(){f.deleteRecursively();}}cleanup{root};
    const auto paths=tak::license::StorePaths::under(root,"test-live-p");
    TAutoTuneProcessor p(paths),q(tak::license::StorePaths::under(root,"test-live-q"));
    p.setPlayConfigDetails(1,1,48000,64);q.setPlayConfigDetails(1,1,48000,64);
    p.prepareToPlay(48000,64);q.prepareToPlay(48000,64);
    for(int i=0;i<200&&(!p.getLicenseManager().snapshot().trialStarted||!q.getLicenseManager().snapshot().trialStarted);++i)juce::Thread::sleep(10);
    CHECK(p.getLicenseManager().isAllowed());CHECK(p.getLicenseManager().snapshot().trialStarted);
    CHECK(q.getLicenseManager().isAllowed());CHECK(q.getLicenseManager().snapshot().trialStarted);
    set(q,TAutoTuneParams::kClassicMode,1);set(q,TAutoTuneParams::kUseFormants,1);
    set(q,TAutoTuneParams::kVibratoShape,3);set(q,TAutoTuneParams::kVibratoPitch,90);set(q,TAutoTuneParams::kTranspose,7);
    juce::AudioBuffer<float>a(1,64),b(1,64);juce::MidiBuffer midi;double error=0;
    for(int k=0;k<1500;++k){for(int n=0;n<64;++n){float x=.15f*std::sin(float((k*64+n)*.029));a.setSample(0,n,x);b.setSample(0,n,x);}
        p.processBlock(a,midi);q.processBlock(b,midi);
        for(int n=0;n<64;++n){CHECK(std::isfinite(b.getSample(0,n)));error=std::max(error,std::abs(double(a.getSample(0,n))-b.getSample(0,n)));}}
    CHECK(error==0);CHECK(p.consumeInputPeak()>.14f);CHECK(p.consumeOutputPeak()>0);
    p.setNoteState(1,TAutoTuneProcessor::kNoteBypassed);p.setNoteState(4,TAutoTuneProcessor::kNoteRemoved);
    juce::MemoryBlock state;p.getStateInformation(state);q.setStateInformation(state.getData(),int(state.getSize()));
    b.clear();q.processBlock(b,midi);CHECK(q.getNoteState(1)==TAutoTuneProcessor::kNoteBypassed);CHECK(q.getNoteState(4)==TAutoTuneProcessor::kNoteRemoved);
    set(q,TAutoTuneParams::kKey,2);set(q,TAutoTuneParams::kScale,0);q.processBlock(b,midi);
    CHECK(q.getNoteState(2)==TAutoTuneProcessor::kNoteActive);CHECK(q.getNoteState(3)==TAutoTuneProcessor::kNoteRemoved);
    set(q,TAutoTuneParams::kKey,0);set(q,TAutoTuneParams::kScale,2);q.processBlock(b,midi);CHECK(q.getNoteState(3)==TAutoTuneProcessor::kNoteActive);
    std::unique_ptr<juce::AudioProcessorEditor> editor(p.createEditor());editor->addToDesktop(0);editor->setVisible(true);
    auto* settings=dynamic_cast<juce::Button*>(editor->findChildWithID("settings"));CHECK(settings!=nullptr);
    CHECK(editor->findChildWithID("classic")==nullptr);CHECK(editor->findChildWithID("formant")==nullptr);
    if(auto out=std::unique_ptr<juce::FileOutputStream>(juce::File::getCurrentWorkingDirectory().getChildFile("live-ui.png").createOutputStream())){
        juce::PNGImageFormat format;format.writeImageToStream(editor->createComponentSnapshot(editor->getLocalBounds()),*out);
    }
    if(settings){CHECK(settings->isShowing());CHECK(settings->isEnabled());
        CHECK(editor->getComponentAt(settings->getBounds().getCentre())==settings);
        CHECK(bool(settings->onClick));settings->onClick();
        CHECK(juce::PopupMenu::dismissAllActiveMenus());
        juce::MessageManager::getInstance()->runDispatchLoopUntil(20);}
    editor->setVisible(false);editor->removeFromDesktop();editor.reset();p.releaseResources();q.releaseResources();
    std::printf("Live processor, legacy state, levels, scale changes, settings menu: %d failures; legacy-state output error %.9f\n",failures,error);
    return failures?1:0;
}
