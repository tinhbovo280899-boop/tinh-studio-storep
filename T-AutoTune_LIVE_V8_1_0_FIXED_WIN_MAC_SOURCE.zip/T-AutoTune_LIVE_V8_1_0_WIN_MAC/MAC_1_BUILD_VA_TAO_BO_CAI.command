#!/bin/bash
# =====================================================================================================
#  MAC_1_BUILD_VA_TAO_BO_CAI.command  -  Auto-Tune Pro (VST3 + Standalone)
#  Build UNIVERSAL (chay ca Mac chip Apple M lan Mac Intel, macOS 10.15 tro len) + ky ad-hoc + tao bo cai .pkg
#  Cach dung: bam dup file nay (lan dau: chuot phai > Open). Can: Xcode Command Line Tools + CMake 3.22+.
#  Ket qua: _EXPORT_MAC/ (app / VST3 da build)  va  Output/<Ten>_<phien ban>_mac.pkg (gui cho khach).
#  Doi thuong hieu: chay 0_DOI_THUONG_HIEU.bat tren may Windows TRUOC, roi chep ca thu muc nay sang Mac.
# =====================================================================================================
set -u
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
cd "$ROOT" || exit 1
TARGETS=(AutoTunePro_VST3 AutoTunePro_Standalone LiveDSPTests LiveProcessorTests)
BUILD="$ROOT/build_mac_universal"
EXPORT="$ROOT/_EXPORT_MAC"
LOG="$ROOT/BUILD_LOG_MAC.txt"
ERRLOG="$ROOT/BUILD_ERROR_MAC.txt"
ARCHS="arm64;x86_64"

pause_if_terminal() { if [[ -t 0 ]]; then printf '\nBam Return de dong cua so...'; read -r _unused; fi; }
fail() {
    printf '\nLOI: %s\n' "$1"
    if [[ -f "$LOG" ]]; then tail -n 150 "$LOG" > "$ERRLOG"; tail -n 40 "$LOG"; else printf '%s\n' "$1" > "$ERRLOG"; fi
    printf '\nNhat ky day du: %s\nGui file loi nay cho ky thuat: %s\n' "$LOG" "$ERRLOG"
    pause_if_terminal; exit 1
}
json_get() { sed -n "s/.*\"$1\"[[:space:]]*:[[:space:]]*\"\([^\"]*\)\".*/\1/p" "$ROOT/ThuongHieu.json" | head -n 1; }

# ---- 0. kiem tra cong cu ------------------------------------------------------------------------
[[ -f "$ROOT/CMakeLists.txt" ]] || fail "Khong thay CMakeLists.txt - de file nay canh CMakeLists.txt."
CMAKE="$(command -v cmake || true)"
for c in /opt/homebrew/bin/cmake /usr/local/bin/cmake /Applications/CMake.app/Contents/bin/cmake; do
    [[ -z "$CMAKE" && -x "$c" ]] && CMAKE="$c"
done
[[ -n "$CMAKE" ]] || fail "Chua co CMake. Cai: tai CMake tai https://cmake.org/download (keo vao Applications) hoac: brew install cmake"
xcrun --find clang++ >/dev/null 2>&1 || fail "Chua co Xcode Command Line Tools. Mo Terminal go: xcode-select --install"
command -v lipo >/dev/null 2>&1 || fail "Thieu lipo (Xcode Command Line Tools)."

APP_NAME="$(json_get appDisplayName)"; VERSION="$(json_get appVersion)"; BRAND="$(json_get licenseBrand)"
[[ -n "$APP_NAME" ]] || APP_NAME="App"; [[ -n "$VERSION" ]] || VERSION="1.0.0"
BRAND_ID="$(printf '%s' "${BRAND:-app}" | tr '[:upper:]' '[:lower:]' | tr -cd 'a-z0-9')"
SAFE_NAME="$(printf '%s' "$APP_NAME" | tr ' ' '_' | tr -cd 'A-Za-z0-9_.-')"
JOBS="$(sysctl -n hw.ncpu 2>/dev/null || echo 4)"; [[ "$JOBS" =~ ^[0-9]+$ ]] || JOBS=4

: > "$LOG"; rm -f "$ERRLOG"
printf '%s %s - macOS UNIVERSAL (arm64 + x86_64)\n\n' "$APP_NAME" "$VERSION"

# ---- 1. configure ------------------------------------------------------------------------------
printf '[1/5] Cau hinh (lan dau hoi lau)...\n'
"$CMAKE" -S "$ROOT" -B "$BUILD" -G 'Unix Makefiles' -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON \
    -DCMAKE_OSX_ARCHITECTURES="$ARCHS" -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15 \
    >> "$LOG" 2>&1 || fail "Cau hinh CMake that bai."

# ---- 2. build ----------------------------------------------------------------------------------
printf '[2/5] Build (%s luong) - may phut...\n' "$JOBS"
for t in "${TARGETS[@]}"; do
    printf '      - %s\n' "$t"
    "$CMAKE" --build "$BUILD" --config Release --target "$t" --parallel "$JOBS" >> "$LOG" 2>&1 || fail "Build $t that bai."
done

"$(dirname "$CMAKE")/ctest" --test-dir "$BUILD" -C Release --output-on-failure >> "$LOG" 2>&1 || fail "Kiem thu that bai."

# ---- 3. gom ket qua + ky ad-hoc ----------------------------------------------------------------
printf '[3/5] Gom ket qua + ky ad-hoc...\n'
rm -rf "$EXPORT"; mkdir -p "$EXPORT/apps" "$EXPORT/vst3" || fail "Khong tao duoc thu muc _EXPORT_MAC."
while IFS= read -r -d '' b; do
    n="$(basename "$b")"
    case "$n" in *Keygen*|juceaide*) continue ;; esac
    case "$b" in *_artefacts/Release/*) ;; *) continue ;; esac
    if [[ "$n" == *.vst3 ]]; then ditto "$b" "$EXPORT/vst3/$n"; else ditto "$b" "$EXPORT/apps/$n"; fi
done < <(find "$BUILD" \( -name '*.app' -o -name '*.vst3' \) -type d -prune -print0)
APPS=("$EXPORT"/apps/*.app); VSTS=("$EXPORT"/vst3/*.vst3)
[[ -e "${APPS[0]}" || -e "${VSTS[0]}" ]] || fail "Khong tim thay app / VST3 sau khi build."
for b in "$EXPORT"/apps/*.app "$EXPORT"/vst3/*.vst3; do
    [[ -e "$b" ]] || continue
    /usr/bin/codesign --force --deep --sign - "$b" >> "$LOG" 2>&1 || fail "Ky ad-hoc that bai: $b"
done

# ---- 4. kiem tra chip --------------------------------------------------------------------------
printf '[4/5] Kiem tra chip (phai co ca arm64 va x86_64)...\n'
for b in "$EXPORT"/apps/*.app "$EXPORT"/vst3/*.vst3; do
    [[ -e "$b" ]] || continue
    bin="$(find "$b/Contents/MacOS" -maxdepth 1 -type f -print -quit)"
    archs="$(lipo -archs "$bin" 2>/dev/null)"
    printf '      %-40s %s\n' "$(basename "$b")" "$archs"
    [[ "$archs" == *arm64* && "$archs" == *x86_64* ]] || fail "$(basename "$b") khong du 2 chip (arm64 + x86_64)."
done

# ---- 5. bo cai .pkg ----------------------------------------------------------------------------
printf '[5/5] Tao bo cai .pkg...\n'
WORK="$BUILD/pkgwork"; rm -rf "$WORK"; mkdir -p "$WORK" "$ROOT/Output"
PARTS=()
make_part() {   # $1 = thu muc nguon, $2 = noi cai, $3 = ten phan
    local src="$1" dest="$2" part="$3"
    local plist="$WORK/$part.plist"
    pkgbuild --analyze --root "$src" "$plist" >> "$LOG" 2>&1 || fail "pkgbuild --analyze that bai ($part)."
    local i=0
    while /usr/libexec/PlistBuddy -c "Print :$i" "$plist" >/dev/null 2>&1; do
        /usr/libexec/PlistBuddy -c "Set :$i:BundleIsRelocatable false" "$plist" >> "$LOG" 2>&1
        /usr/libexec/PlistBuddy -c "Set :$i:BundleOverwriteAction upgrade" "$plist" >> "$LOG" 2>&1
        i=$((i + 1))
    done
    pkgbuild --root "$src" --component-plist "$plist" --install-location "$dest" \
        --identifier "com.dcaudio.$BRAND_ID.mac.$part" --version "$VERSION" "$WORK/$part.pkg" >> "$LOG" 2>&1 \
        || fail "pkgbuild that bai ($part)."
    PARTS+=(--package "$WORK/$part.pkg")
}
[[ -e "${APPS[0]}" ]] && make_part "$EXPORT/apps" "/Applications" "apps"
[[ -e "${VSTS[0]}" ]] && make_part "$EXPORT/vst3" "/Library/Audio/Plug-Ins/VST3" "vst3"
OUT="$ROOT/Output/${SAFE_NAME}_${VERSION}_mac.pkg"
rm -f "$OUT"
productbuild "${PARTS[@]}" "$OUT" >> "$LOG" 2>&1 \
    || fail "productbuild that bai."

printf '\nXONG!\n  Bo cai gui khach : %s\n  App / VST3       : %s\n' "$OUT" "$EXPORT"
printf '\nKhach mo .pkg lan dau bi chan ("khong xac dinh nha phat trien"): Cai dat he thong > Quyen rieng tu & Bao mat\n'
printf '> keo xuong bam "Van mo" (Open Anyway). Xem HUONG_DAN_MAC.txt.\n'
open "$ROOT/Output" >/dev/null 2>&1 || true
pause_if_terminal
