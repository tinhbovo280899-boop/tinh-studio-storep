# Bản Live 8.1.0 — 27/10/2026

Đây là bản mã nguồn được rút gọn cho nhu cầu hát live, chưa phải plugin Windows/macOS đã biên dịch.

## Sửa gì và bỏ gì

- Loại nhánh LPC Formant/Throat cũ khỏi đường âm thanh. Nhánh đó đã tái hiện xung tăng mức khi bật giữa nốt và tăng mức bất thường ở nốt ngân trầm có hơi. Bản này không còn chức năng bảo toàn/đổi formant; đây là việc loại tính năng lỗi khỏi bản live, không phải một thuật toán Formant mới. Dịch cao độ nhiều vẫn có thể làm thay đổi màu giọng.
- Cố định đường chỉnh cao độ thường (Classic Off). Bỏ Synthetic Vibrato và Transpose khỏi engine live. Giữ Retune, Flex-Tune, Humanize và Natural Vibrato. Chất âm của các preset cũ dùng những chức năng bị bỏ sẽ thay đổi tương ứng.
- GRAPH trước đây chỉ xuất hiện trong ảnh nền, chưa có engine Graph/ARA hoạt động. Giao diện mới bỏ các mục này và giao diện Advanced cũ.
- Vẽ giao diện 760×450 với bốn nút chính, Voice/Key/Scale, meter cao độ và mức vào/ra, báo CLIP. Settings là nút thật, mở menu Tracking, chuẩn A4, tooltips, kích hoạt bản quyền và thông tin.
- Default mới: Alto/Tenor, Chromatic, Retune 20 ms, Flex 12, Humanize 35, Natural Vibrato 0 dB. Đây là điểm bắt đầu để nghe thử; không có cam kết hợp với mọi giọng hát. Preset/session được khôi phục vẫn lấy các thông số đã lưu.
- Giữ các parameter ID cũ để dữ liệu có thể được đọc. Classic, Formant, Throat, Transpose, Synthetic Vibrato và Advanced View cũ không còn tác động trong bản live, dù host có thể còn liệt kê tham số cũ trong generic parameter view.
- Note mask chuyển sang một atomic 24-bit; các biến theo dõi Key/Scale chỉ được cập nhật trên audio thread.
- Chặn NaN/Inf đầu vào và bảo vệ trạng thái filter. Kẹp cuối ±1 là lớp bảo vệ mức cuối cùng; không phải bộ limiter true-peak và không phải nguyên nhân khiến phép so sánh tín hiệu nhỏ hết xung.
- Loại skin bitmap, model ONNX và script ARA không dùng. Giữ JUCE đi kèm để build.

## Kết quả đo

Trường hợp bật Formant giữa sine 225 Hz: bản gốc peak 4,0; bản live peak 0,2, so sánh với raw pitch path của bản gốc sai khác tối đa 0 trên bài thử này.

Bài ngân 20 giây, 110 Hz có hơi, input peak 0,2, Retune 20 ms: bản gốc Formant On peak 1,1407294 và 71 mẫu vượt 1 sau giây đầu; bản live peak 0,16833146, không vượt 1. Bật/tắt legacy Formant không đổi kết quả bản live.

Có test đối chiếu bản gốc trong Tests/reference; mã cũ này chỉ được biên dịch vào executable kiểm thử, không được link vào plugin. Có thêm các bài giữ nốt/rung 10 giây ở 32/44,1/48/96 kHz, thử loại giọng, invalid sample, state/preset và mở menu Settings. Xem TEST_RESULTS để biết kết quả cuối cùng.

## Giới hạn và cách nghe thử

Đã build/kiểm thử trên Linux; chưa có máy Windows/macOS để xác nhận native MSVC/Xcode, DAW hoặc bộ cài. Giữ các plugin ID và product/license ID cũ; nếu build và thay plugin hiện tại thì nên dùng phiên thử riêng trước khi thay trong các project đang làm. Public key và logic xác minh bản quyền không đổi; ba PRIVATE_KEY.txt trong gói gốc không nằm trong bản giao hàng.

Engine dịch cao độ vẫn dùng con trỏ đọc trễ biến thiên. Chưa thêm chế độ Low Latency mới hoặc định nghĩa lại latency cố định báo host; không tuyên bố zero latency hoặc độ trễ thấp hơn bản gốc. Tổng độ trễ monitoring còn phụ thuộc buffer và audio interface.

Đây là engine kế thừa từ dự án người dùng, không phải thuật toán UAD/Antares đã được xác nhận tương đương. Chưa nghe bản thu thực tế để xác nhận cảm giác ấm/mượt hoặc hết mọi kiểu tiếng nổ trên máy người dùng.

Khi so sánh, chỉ bật một Auto-Tune trên kênh MIC, dùng cùng đoạn hát/cùng mức và tắt reverb/delay để nghe lỗi rõ. Nếu vẫn có tiếng nổ, cần kiểm tra thêm mức vào, buffer/underrun và các plugin khác trong chuỗi.

Các tiện ích đổi thương hiệu/keygen cũ chưa được làm lại trong đợt audio/UI này. Build Windows không còn tự gọi Sync thương hiệu để tránh ghi đè identity/header đã kiểm tra. Không dùng các tiện ích đó để tự thay public key nếu cần tương thích key hiện tại.
