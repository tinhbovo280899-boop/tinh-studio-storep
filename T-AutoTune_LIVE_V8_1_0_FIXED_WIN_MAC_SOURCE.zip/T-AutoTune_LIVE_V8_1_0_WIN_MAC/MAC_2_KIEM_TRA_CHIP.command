#!/bin/bash
# MAC_2_KIEM_TRA_CHIP.command - xem app / VST3 trong _EXPORT_MAC co du 2 chip (arm64 = Apple M, x86_64 = Intel) khong.
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
found=0
for b in "$ROOT"/_EXPORT_MAC/apps/*.app "$ROOT"/_EXPORT_MAC/vst3/*.vst3; do
    [[ -e "$b" ]] || continue
    found=1
    bin="$(find "$b/Contents/MacOS" -maxdepth 1 -type f -print -quit)"
    printf '%-42s %s\n' "$(basename "$b")" "$(lipo -archs "$bin" 2>/dev/null)"
    codesign -v "$b" >/dev/null 2>&1 && echo "    chu ky: OK" || echo "    chu ky: LOI (chay lai MAC_1)"
done
[[ $found == 1 ]] || echo "Chua co _EXPORT_MAC - chay MAC_1_BUILD_VA_TAO_BO_CAI.command truoc."
printf '\nBam Return de dong...'; read -r _
