#!/bin/bash
set -eu
printf '%s\n' 'Ban LIVE khong tich hop Auto-Key; chon Key/Scale tren giao dien.' 'Ban quyen: Settings > License / activation.'
if [[ -t 0 ]]; then read -r -p 'Bam Return de dong...' live_reply; fi
