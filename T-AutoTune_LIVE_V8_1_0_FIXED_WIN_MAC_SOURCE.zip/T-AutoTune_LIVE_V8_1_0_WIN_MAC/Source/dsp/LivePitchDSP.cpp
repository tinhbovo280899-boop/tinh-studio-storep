#include "LivePitchDSP.h"
namespace { constexpr double kPi = 3.14159265358979323846; }
void AntaresAutoTuneChannelDSP::prepare(double newSampleRate)
{
    sampleRate = std::isfinite(newSampleRate) ? std::clamp(newSampleRate, 8000.0, 384000.0) : 44100.0;

    // Downsample_DSP::SetSampleRate (legacy implementation):
    // Determine integer downsample factor so pitch analysis runs near 44.1/48 kHz
    if (sampleRate > 128000.0)
        downsampleFactor = 4;
    else if (sampleRate > 64000.0)
        downsampleFactor = 2;
    else
        downsampleFactor = 1;

    analysisRate = sampleRate / static_cast<double>(downsampleFactor);

    // 6-stage anti-aliasing biquad cascade before decimation (legacy implementation)
    const double aaCutoff = 0.42 * analysisRate;
    static const double kStageQ[6] = { 0.5176, 0.7071, 1.9319, 0.5176, 0.7071, 1.9319 };
    for (int i = 0; i < 6; ++i)
    {
        downsampleFilters[static_cast<size_t>(i)].setLowpass(aaCutoff, sampleRate, kStageQ[i]);
        downsampleFilters[static_cast<size_t>(i)].reset();
    }

    currentVoiceType = -1;
    updateVoiceTypeFilters(0);
    reset();
}

void AntaresAutoTuneChannelDSP::reset()
{
    for (auto& f : downsampleFilters)
        f.reset();

    inputLP1.reset();
    inputLP2.reset();
    inputHP1.reset();
    shiftLP1.reset();
    shiftLP2.reset();

    detectorRing.fill(0.0);
    runningEnergy.fill(0.0);
    runningCorr.fill(0.0);
    detWriteIdx = 0;
    downsampleCounter = 0;
    updateSubCounter = 0;

    currentPeriodSamples = analysisRate / 220.0;
    smoothedPeriodSamples = currentPeriodSamples;
    fastPitchMidi = 60.0;
    slowPitchMidi = 60.0;
    voicedState = false;
    lockedTargetNote = -1;
    sustainedNoteFrames = 0;
    smoothedPitchRatio = 1.0;

    rawInputRing.fill(0.0);
    psolaWriteIdx = 0;
    const double initDelay = std::clamp(sampleRate * 0.008, 64.0, 1024.0);
    readPtrA = static_cast<double>(kRingSize) - initDelay;
    readPtrB = readPtrA;
    crossfadeAlpha = 0.0;
    crossfadeStep = 0.0;
    crossfadingToB = false;

    lastDetectedMidi = -1.0f;
    lastTargetMidi = -1.0f;
    lastCentsCorrection = 0.0f;
}

void AntaresAutoTuneChannelDSP::updateVoiceTypeFilters(int voiceType)
{
    if (voiceType == currentVoiceType)
        return;

    currentVoiceType = voiceType;

    // Exact Input Voice Type cutoffs from legacy implementation & legacy implementation:
    //   0 = SOPRANO    (600..1200 Hz filter, fundamental range 175..1050 Hz)
    //   1 = ALTO/TENOR (400..800 Hz filter,  fundamental range 110..700 Hz)
    //   2 = LOW MALE   (300..600 Hz filter,  fundamental range 75..450 Hz)
    //   3 = INSTRUMENT (1000..2000 Hz filter, fundamental range 65..1200 Hz)
    //   4 = BASS INST  (200..400 Hz filter,  fundamental range 35..260 Hz)
    double lpCutoff1 = 600.0, lpCutoff2 = 1200.0, hpCutoff = 120.0;
    double fMinHz = 175.0, fMaxHz = 1050.0;

    switch (voiceType)
    {
        case 0: // Soprano
            lpCutoff1 = 600.0;  lpCutoff2 = 1200.0; hpCutoff = 150.0;
            fMinHz = 170.0;     fMaxHz = 1050.0;
            break;
        case 1: // Alto / Tenor
            lpCutoff1 = 400.0;  lpCutoff2 = 800.0;  hpCutoff = 95.0;
            fMinHz = 105.0;     fMaxHz = 700.0;
            break;
        case 2: // Low Male
            lpCutoff1 = 300.0;  lpCutoff2 = 600.0;  hpCutoff = 65.0;
            fMinHz = 70.0;      fMaxHz = 450.0;
            break;
        case 3: // Instrument
            lpCutoff1 = 1000.0; lpCutoff2 = 2000.0; hpCutoff = 55.0;
            fMinHz = 65.0;      fMaxHz = 1200.0;
            break;
        case 4: // Bass Inst
        default:
            lpCutoff1 = 200.0;  lpCutoff2 = 400.0;  hpCutoff = 30.0;
            fMinHz = 35.0;      fMaxHz = 260.0;
            break;
    }

    inputLP1.setLowpass(lpCutoff1, analysisRate, 0.7071067811865475);
    inputLP2.setLowpass(lpCutoff2, analysisRate, 0.7071067811865475);
    inputHP1.setHighpass(hpCutoff, analysisRate, 0.7071067811865475);

    minPeriodSamples = std::clamp(analysisRate / fMaxHz, 12.0, 1024.0);
    maxPeriodSamples = std::clamp(analysisRate / fMinHz, minPeriodSamples + 16.0, 1800.0);

    // Populate logarithmically-spaced + dense integer candidate lag table for running autocorrelation
    numActiveLags = 0;
    const int minLagInt = std::max(8, static_cast<int>( std::floor(minPeriodSamples)));
    const int maxLagInt = std::min((kRingSize / 2) - 4, static_cast<int>(std::ceil(maxPeriodSamples)));
    const double ratio = std::pow(static_cast<double>(maxLagInt) / static_cast<double>(minLagInt),
                                  1.0 / static_cast<double>(kNumLagBins - 1));
    int prevLag = -1;
    for (int i = 0; i < kNumLagBins; ++i)
    {
        int lag = static_cast<int>(std::round(minLagInt * std::pow(ratio, static_cast<double>(i))));
        if (lag <= prevLag)
            lag = prevLag + 1;
        if (lag > maxLagInt)
            break;
        lagTable[static_cast<size_t>(numActiveLags++)] = lag;
        prevLag = lag;
    }
    runningEnergy.fill(0.0);
    runningCorr.fill(0.0);
}

// 3-Point Parabolic Sub-Sample Interpolation from legacy implementation & legacy implementation:
//   c1 = 0.5 * (y[+1] - y[-1])
//   c2 = 0.5 * (y[+1] + y[-1]) - y[0]
//   out = (c2 * frac + c1) * frac + y[0]
double AntaresAutoTuneChannelDSP::readParabolic(const std::array<double, kRingSize>& buf, double readPos) const noexcept
{
    int idx0 = static_cast<int>(std::floor(readPos));
    double frac = readPos - static_cast<double>(idx0);
    if (frac > 0.5)
    {
        idx0 += 1;
        frac -= 1.0; // center fractional offset in [-0.5, +0.5] as in legacy implementation
    }
    const double ym1 = buf[static_cast<size_t>((idx0 - 1) & kRingMask)];
    const double y0  = buf[static_cast<size_t>(idx0 & kRingMask)];
    const double yp1 = buf[static_cast<size_t>((idx0 + 1) & kRingMask)];

    const double c1 = 0.5 * (yp1 - ym1);
    const double c2 = 0.5 * (yp1 + ym1) - y0;
    return (c2 * frac + c1) * frac + y0;
}

//==============================================================================
// Per-Sample Processing Loop (AT_DSPObject::ProcessBlock legacy implementation)
//==============================================================================
float AntaresAutoTuneChannelDSP::processSample(
    float inputSample,
    int voiceType,
    int keyIdx,
    int scaleIdx,
    const std::array<int, 12>& noteStates,
    bool classicMode,
    bool useFormants,
    double throatLengthPct,
    double transposeSemi,
    double detuneCents,
    double trackingVal,
    double retuneSpeedMs,
    double flexTuneVal,
    double naturalVibDb,
    double humanizeVal,
    bool ignoreVibrato,
    int vibShape,
    double vibRateHz,
    double vibDelayMs,
    double vibTransMs,
    double vibVarVal,
    double vibPitchCents,
    double vibAmpVal,
    double vibFormantVal)
{
    (void)keyIdx; (void)scaleIdx;
    (void)classicMode; (void)useFormants; (void)throatLengthPct; (void)transposeSemi;
    (void)vibShape; (void)vibRateHz; (void)vibDelayMs; (void)vibTransMs;
    (void)vibVarVal; (void)vibPitchCents; (void)vibAmpVal; (void)vibFormantVal;
    auto finiteParam = [](double v, double lo, double hi, double fallback) {
        return std::isfinite(v) ? std::clamp(v, lo, hi) : fallback;
    };
    detuneCents = finiteParam(detuneCents, -100.0, 100.0, 0.0);
    trackingVal = finiteParam(trackingVal, 1.0, 100.0, 50.0);
    retuneSpeedMs = finiteParam(retuneSpeedMs, 0.0, 400.0, 20.0);
    flexTuneVal = finiteParam(flexTuneVal, 0.0, 100.0, 0.0);
    naturalVibDb = finiteParam(naturalVibDb, -12.0, 12.0, 0.0);
    humanizeVal = finiteParam(humanizeVal, 0.0, 100.0, 0.0);
    updateVoiceTypeFilters(std::clamp(voiceType, 0, 4));
    const double xIn = std::isfinite(inputSample) ? std::clamp(static_cast<double>(inputSample), -4.0, 4.0) : 0.0;

    // -------------------------------------------------------------------------
    // 1. Downsample_DSP Anti-Aliasing Front-End (legacy implementation) & Voice Type Bandpass
    // -------------------------------------------------------------------------
    double xAA = xIn;
    if (downsampleFactor > 1)
    {
        for (auto& f : downsampleFilters)
            xAA = f.process(xAA);
    }

    if (++downsampleCounter >= downsampleFactor)
    {
        downsampleCounter = 0;

        // Input Voice Type band-limiting filter (legacy implementation)
        const double xFiltered = inputHP1.process(inputLP2.process(inputLP1.process(xAA)));
        detectorRing[static_cast<size_t>(detWriteIdx)] = xFiltered;

        // Running sliding-window autocorrelation update across candidate lags (legacy implementation):
        //   energy[k] += x[n]^2 - x[n - 2*tau]^2
        //   corr[k]   += x[n]*x[n - tau] - x[n - tau]*x[n - 2*tau]
        const double xn = xFiltered;
        const double xn2 = xn * xn;
        for (int k = 0; k < numActiveLags; ++k)
        {
            const int tau = lagTable[static_cast<size_t>(k)];
            const double xTau  = detectorRing[static_cast<size_t>((detWriteIdx - tau) & kRingMask)];
            const double x2Tau = detectorRing[static_cast<size_t>((detWriteIdx - 2 * tau) & kRingMask)];

            runningEnergy[static_cast<size_t>(k)] =
                std::max(0.0, runningEnergy[static_cast<size_t>(k)] + xn2 - x2Tau * x2Tau);
            runningCorr[static_cast<size_t>(k)] += xn * xTau - xTau * x2Tau;
        }

        detWriteIdx = (detWriteIdx + 1) & kRingMask;
    }

    // -------------------------------------------------------------------------
    // 3. 5-Sample Control & Pitch-Tracking Frame Update (f_update = sr / 5.0, legacy implementation)
    // -------------------------------------------------------------------------
    if (++updateSubCounter >= 5)
    {
        updateSubCounter = 0;

        // Tracking threshold from Tracking_ID (1..100, default 50):
        // Higher Tracking value relaxes correlation threshold for breathier signals; lower requires stricter periodicity
        const double corrThreshold = std::clamp(0.88 - 0.0055 * trackingVal, 0.25, 0.85);

        // Search running autocorrelation for fundamental period T0 (legacy implementation)
        int bestBin = -1;
        double maxGlobalEnergy = 0.0;

        for (int k = 0; k < numActiveLags; ++k)
            maxGlobalEnergy = std::max(maxGlobalEnergy, runningEnergy[static_cast<size_t>(k)]);

        if (maxGlobalEnergy > 1.0e-7)
        {
            // Find global maximum normalized correlation first
            double globalPeak = 0.0;
            for (int k = 1; k < numActiveLags - 1; ++k)
            {
                const double e = runningEnergy[static_cast<size_t>(k)];
                if (e <= 1.0e-9)
                    continue;
                const double nc = runningCorr[static_cast<size_t>(k)] / (0.5 * e + 1.0e-9);
                if (nc > globalPeak)
                    globalPeak = nc;
            }

            // Detector peak selection:
            // Select first local peak >= (evo ? 0.86 : 0.82) * globalPeak to avoid sub-harmonic octave errors
            const double octaveGuard = 0.86;
            for (int k = 1; k < numActiveLags - 1; ++k)
            {
                const double eCurr = std::max(1.0e-9, runningEnergy[static_cast<size_t>(k)]);
                const double ePrev = std::max(1.0e-9, runningEnergy[static_cast<size_t>(k - 1)]);
                const double eNext = std::max(1.0e-9, runningEnergy[static_cast<size_t>(k + 1)]);

                const double ncCurr = runningCorr[static_cast<size_t>(k)] / (0.5 * eCurr);
                const double ncPrev = runningCorr[static_cast<size_t>(k - 1)] / (0.5 * ePrev);
                const double ncNext = runningCorr[static_cast<size_t>(k + 1)] / (0.5 * eNext);

                if (ncCurr >= ncPrev && ncCurr >= ncNext && ncCurr >= corrThreshold && ncCurr >= octaveGuard * globalPeak)
                {
                    bestBin = k;
                    break;
                }
            }
        }

        if (bestBin > 0 && bestBin < numActiveLags - 1)
        {
            // Parabolic sub-sample lag refinement (legacy implementation)
            const int tau0 = lagTable[static_cast<size_t>(bestBin)];
            // Evaluate exact lags tau0 - 1, tau0, tau0 + 1 in detectorRing for sub-sample precision
            double cMinus = 0.0, cZero = 0.0, cPlus = 0.0;
            const int winLen = std::min(2 * tau0, 512);
            for (int i = 0; i < winLen; ++i)
            {
                const double s0 = detectorRing[static_cast<size_t>((detWriteIdx - 1 - i) & kRingMask)];
                cMinus += s0 * detectorRing[static_cast<size_t>((detWriteIdx - 1 - i - (tau0 - 1)) & kRingMask)];
                cZero  += s0 * detectorRing[static_cast<size_t>((detWriteIdx - 1 - i - tau0) & kRingMask)];
                cPlus  += s0 * detectorRing[static_cast<size_t>((detWriteIdx - 1 - i - (tau0 + 1)) & kRingMask)];
            }
            const double denom = cMinus - 2.0 * cZero + cPlus;
            double delta = 0.0;
            if (std::abs(denom) > 1.0e-9)
                delta = std::clamp(0.5 * (cMinus - cPlus) / denom, -0.5, 0.5);

            const double detectedPeriod = std::clamp(static_cast<double>(tau0) + delta, minPeriodSamples, maxPeriodSamples);
            currentPeriodSamples = detectedPeriod;
            smoothedPeriodSamples = 0.75 * smoothedPeriodSamples + 0.25 * detectedPeriod;

            // Convert detected period to MIDI note relative to Detune reference (default 440.0 Hz)
            const double refA4Hz = 440.0 * std::pow(2.0, detuneCents / 1200.0);
            const double detectedHz = analysisRate / smoothedPeriodSamples;
            const double rawMidi = 69.0 + 12.0 * std::log2(std::max(20.0, detectedHz) / refA4Hz);

            if (!voicedState)
            {
                fastPitchMidi = rawMidi;
                slowPitchMidi = rawMidi;
                voicedState = true;
            }
            else
            {
                fastPitchMidi = 0.65 * fastPitchMidi + 0.35 * rawMidi;
                // Slow LPF tracks average center pitch (used by Ignore Vibrato & Natural Vibrato separation)
                slowPitchMidi = 0.965 * slowPitchMidi + 0.035 * rawMidi;
            }

            lastDetectedMidi = static_cast<float>(fastPitchMidi);

            // -----------------------------------------------------------------
            // 4. Scale Quantization, Note Bypass/Remove & Flex-Tune Hysteresis (legacy implementation)
            // -----------------------------------------------------------------
            const double pitchForTarget = ignoreVibrato ? slowPitchMidi : fastPitchMidi;

            // Find nearest active/bypassed note in 12-tone scale
            int bestMidiNote = static_cast<int>(std::round(pitchForTarget));
            double minDist = 1.0e9;
            bool bestIsBypassed = false;

            const int baseMidi = static_cast<int>(std::floor(pitchForTarget)) - 12;
            for (int m = baseMidi; m <= baseMidi + 24; ++m)
            {
                const int pc = ((m % 12) + 12) % 12;
                const int st = noteStates[static_cast<size_t>(pc)];
                if (st == kNoteRemoved)
                    continue; // Removed notes are skipped during quantization!

                double dist = std::abs(pitchForTarget - static_cast<double>(m));
                // Note hysteresis: favor currently locked target note by 15 cents (legacy implementation)
                if (m == lockedTargetNote)
                    dist -= 0.15;

                if (dist < minDist)
                {
                    minDist = dist;
                    bestMidiNote = m;
                    bestIsBypassed = (st == kNoteBypassed);
                }
            }

            if (bestMidiNote == lockedTargetNote)
                sustainedNoteFrames++;
            else
            {
                lockedTargetNote = bestMidiNote;
                sustainedNoteFrames = 0;
            }

            // Target MIDI note after Flex-Tune and Natural Vibrato
            double targetMidi = bestIsBypassed ? fastPitchMidi : static_cast<double>(bestMidiNote);

            if (!bestIsBypassed && flexTuneVal > 0.0)
            {
                // Flex-Tune (SolidTune_ID tag 90): expressive attraction zone around scale note
                const double flexNorm = std::clamp(flexTuneVal / 100.0, 0.0, 1.0);
                const double devSemi = fastPitchMidi - static_cast<double>(bestMidiNote);
                const double captureWidth = 0.15 + 0.85 * (1.0 - flexNorm);
                const double pull = std::exp(-(devSemi * devSemi) / std::max(0.02, captureWidth * captureWidth));
                const double effectivePull = pull * (1.0 - 0.75 * flexNorm);
                targetMidi = fastPitchMidi + effectivePull * (static_cast<double>(bestMidiNote) - fastPitchMidi);
            }

            // Natural Vibrato scaling (-12..+12 dB, tag 62, legacy implementation):
            // Extracts high-frequency vibrato component (fastPitchMidi - slowPitchMidi) and scales by 10^(dB/20)
            const double vibComponent = fastPitchMidi - slowPitchMidi;
            const double natVibGain = std::pow(10.0, naturalVibDb / 20.0);
            targetMidi += vibComponent * (natVibGain - 1.0);

            const double activeTranspose = 0.0;
            const double finalTargetMidi = targetMidi;
            const double rawTargetRatio = std::pow(2.0, (finalTargetMidi - fastPitchMidi) / 12.0);

            // -----------------------------------------------------------------
            // 5. Legacy Retune Speed & Humanize Smoothing (legacy implementation & legacy implementation)
            //   f_update = sampleRate / 5.0
            //   retuneCoeff   = (retuneSpeedMs <= 0.0) ? 0.0 : pow(0.5, 1.0 / (f_update * (retuneSpeedMs / 1000.0)))
            //   humanizeCoeff = pow(0.5, 1.0 / (f_update * ((retuneSpeedMs + humanizeExtraMs) / 1000.0)))
            //   Linear ramp over int((sampleRate * 0.4) / 5.0) frames (400 ms sustained note)
            // -----------------------------------------------------------------
            const double fUpdate = sampleRate / 5.0;
            const double retuneCoeff = (retuneSpeedMs <= 0.001)
                ? 0.0
                : std::pow(0.5, 1.0 / std::max(1.0, fUpdate * (retuneSpeedMs * 0.001)));

            double smoothCoeff = retuneCoeff;
            if (humanizeVal > 0.0)
            {
                const double humanizeExtraMs = (humanizeVal / 100.0) * 250.0;
                const double humanizeCoeff = std::pow(
                    0.5, 1.0 / std::max(1.0, fUpdate * ((retuneSpeedMs + humanizeExtraMs) * 0.001)));
                const int rampFrames = std::max(1, static_cast<int>((sampleRate * 0.4) / 5.0));
                const double rampFrac = std::clamp(
                    static_cast<double>(sustainedNoteFrames) / static_cast<double>(rampFrames), 0.0, 1.0);
                smoothCoeff = retuneCoeff + rampFrac * (humanizeCoeff - retuneCoeff);
            }

            smoothedPitchRatio = smoothCoeff * smoothedPitchRatio + (1.0 - smoothCoeff) * rawTargetRatio;
            smoothedPitchRatio = std::clamp(smoothedPitchRatio, 0.25, 4.0);

            lastTargetMidi = static_cast<float>(finalTargetMidi - activeTranspose);
            lastCentsCorrection = static_cast<float>(
                std::clamp(1200.0 * std::log2(smoothedPitchRatio) - activeTranspose * 100.0, -50.0, 50.0));

            // Update upward-shift anti-aliasing filters (legacy implementation: cutoff = 0.49 * sr / pitchRatio)
            if (smoothedPitchRatio > 1.01)
            {
                const double shiftCutoff = (0.49 * sampleRate) / smoothedPitchRatio;
                shiftLP1.setLowpass(shiftCutoff, sampleRate, 0.7071067811865475);
                shiftLP2.setLowpass(shiftCutoff, sampleRate, 0.7071067811865475);
            }

        }
        else
        {
            // Unvoiced / consonant / silence: relax pitch ratio smoothly toward 1.0
            voicedState = false;
            sustainedNoteFrames = 0;
            smoothedPitchRatio = 0.92 * smoothedPitchRatio + 0.08 * 1.0;
            lastCentsCorrection *= 0.85f;
        }
    }

    // -------------------------------------------------------------------------
    // 6. LPC Inverse Filtering & Dual-Pointer Parabolic TD-PSOLA Resynthesis (legacy implementation)
    // -------------------------------------------------------------------------
    double psolaInput = xIn;
    if (smoothedPitchRatio > 1.01)
        psolaInput = shiftLP2.process(shiftLP1.process(psolaInput));

    rawInputRing[static_cast<size_t>(psolaWriteIdx)] = psolaInput;
    const auto& activeRing = rawInputRing;

    // Full-rate pitch period T0 in samples
    const double T0Full = std::clamp(smoothedPeriodSamples * static_cast<double>(downsampleFactor), 24.0, 2048.0);
    const double minDelay = std::max(32.0, 0.6 * T0Full);
    const double maxDelay = std::min(static_cast<double>(kRingSize - 64), minDelay + 2.2 * T0Full);

    // Distance of active read pointer behind write pointer
    const double activePtr = crossfadingToB ? readPtrB : readPtrA;
    double delaySamples = static_cast<double>(psolaWriteIdx) - activePtr;
    while (delaySamples < 0.0)
        delaySamples += static_cast<double>(kRingSize);
    while (delaySamples >= static_cast<double>(kRingSize))
        delaySamples -= static_cast<double>(kRingSize);

    // Trigger pitch-synchronous splice of 1 pitch period T0 when read pointer drifts outside [minDelay, maxDelay]
    // and no crossfade is currently active (legacy implementation)
    if (crossfadeStep <= 0.0 && (delaySamples < minDelay || delaySamples > maxDelay))
    {
        double newDelay = delaySamples;
        while (newDelay < minDelay)
            newDelay += T0Full;
        while (newDelay > maxDelay)
            newDelay -= T0Full;

        double targetPtr = static_cast<double>(psolaWriteIdx) - newDelay;
        while (targetPtr < 0.0)
            targetPtr += static_cast<double>(kRingSize);

        readPtrB = targetPtr;
        crossfadeAlpha = 0.0;
        // 20% pitch-period crossfade step (legacy implementation: step = 1.0 / (0.20 * T0))
        crossfadeStep = 1.0 / std::max(16.0, 0.20 * T0Full);
        crossfadingToB = true;
    }

    // Read primary pointer A and (if splicing) secondary pointer B with 3-point parabolic interpolation
    double resynthesized = readParabolic(activeRing, readPtrA);
    if (crossfadingToB)
    {
        const double sampleB = readParabolic(activeRing, readPtrB);
        crossfadeAlpha += crossfadeStep;
        if (crossfadeAlpha >= 1.0)
        {
            resynthesized = sampleB;
            readPtrA = readPtrB;
            crossfadeAlpha = 0.0;
            crossfadeStep = 0.0;
            crossfadingToB = false;
        }
        else
        {
            // Smooth equal-power / raised-cosine splice blend
            const double w = 0.5 * (1.0 - std::cos(kPi * crossfadeAlpha));
            resynthesized = (1.0 - w) * resynthesized + w * sampleB;
        }
    }

    // Advance read pointers by smoothedPitchRatio and wrap modulo kRingSize
    const double step = voicedState ? smoothedPitchRatio : 1.0;
    readPtrA += step;
    if (readPtrA >= static_cast<double>(kRingSize))
        readPtrA -= static_cast<double>(kRingSize);

    if (crossfadingToB)
    {
        readPtrB += step;
        if (readPtrB >= static_cast<double>(kRingSize))
            readPtrB -= static_cast<double>(kRingSize);
    }

    psolaWriteIdx = (psolaWriteIdx + 1) & kRingMask;

    // Finite full-scale backstop. Normal level inputs retain the raw pitch path.
    return std::isfinite(resynthesized)
        ? static_cast<float>(std::clamp(resynthesized, -1.0, 1.0)) : 0.0f;
}

