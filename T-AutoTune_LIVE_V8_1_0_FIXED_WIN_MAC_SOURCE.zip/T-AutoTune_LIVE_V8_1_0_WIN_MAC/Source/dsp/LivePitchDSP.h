#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
class AntaresAutoTuneChannelDSP
{
public:
    enum NoteState { kNoteActive=0, kNoteBypassed=1, kNoteRemoved=2 };
    static constexpr int kMaxLPCOrder  = 16;
    static constexpr int kRingSize     = 8192;
    static constexpr int kRingMask     = kRingSize - 1;
    static constexpr int kNumLagBins   = 96;

    struct BiquadDF2
    {
        double b0 = 1.0, b1 = 0.0, b2 = 0.0;
        double a1 = 0.0, a2 = 0.0;
        double z1 = 0.0, z2 = 0.0;

        void reset() noexcept { z1 = z2 = 0.0; }

        void setLowpass(double fc, double sr, double q = 0.7071067811865475) noexcept
        {
            const double w0 = 2.0 * 3.14159265358979323846 * std::clamp(fc, 10.0, 0.49 * sr) / sr;
            const double cs = std::cos(w0);
            const double alpha = std::sin(w0) / (2.0 * q);
            const double norm = 1.0 / (1.0 + alpha);
            b0 = (0.5 * (1.0 - cs)) * norm;
            b1 = (1.0 - cs) * norm;
            b2 = b0;
            a1 = (-2.0 * cs) * norm;
            a2 = (1.0 - alpha) * norm;
        }

        void setHighpass(double fc, double sr, double q = 0.7071067811865475) noexcept
        {
            const double w0 = 2.0 * 3.14159265358979323846 * std::clamp(fc, 10.0, 0.49 * sr) / sr;
            const double cs = std::cos(w0);
            const double alpha = std::sin(w0) / (2.0 * q);
            const double norm = 1.0 / (1.0 + alpha);
            b0 = (0.5 * (1.0 + cs)) * norm;
            b1 = -(1.0 + cs) * norm;
            b2 = b0;
            a1 = (-2.0 * cs) * norm;
            a2 = (1.0 - alpha) * norm;
        }

        inline double process(double x) noexcept
        {
            if (!std::isfinite(x)) x = 0.0;
            const double w = x - a1 * z1 - a2 * z2;
            const double y = b0 * w + b1 * z1 + b2 * z2;
            if (!std::isfinite(w) || !std::isfinite(y)) { reset(); return 0.0; }
            z2 = z1;
            z1 = w;
            return y;
        }
    };

    void prepare(double newSampleRate);
    void reset();

    void updateVoiceTypeFilters(int voiceType);
    float processSample(float inputSample,
                        int voiceType,
                        int keyIdx,
                        int scaleIdx,
                        const std::array<int, 12>& noteStates,
                        bool classicMode,
                        bool useFormants,
                        double throatLengthPct,
                        double transposeSemi,
                        double detuneCents,
                        double trackingVal,
                        double retuneSpeedMs,
                        double flexTuneVal,
                        double naturalVibDb,
                        double humanizeVal,
                        bool ignoreVibrato,
                        int vibShape,
                        double vibRateHz,
                        double vibDelayMs,
                        double vibTransMs,
                        double vibVarVal,
                        double vibPitchCents,
                        double vibAmpVal,
                        double vibFormantVal);

    float getDetectedMidiNote() const noexcept { return lastDetectedMidi; }
    float getTargetMidiNote()   const noexcept { return lastTargetMidi; }
    float getCentsCorrection()  const noexcept { return lastCentsCorrection; }
    bool  isCurrentlyVoiced()   const noexcept { return voicedState; }

private:
    double readParabolic(const std::array<double, kRingSize>& buf, double readPos) const noexcept;

    double sampleRate = 44100.0;
    double analysisRate = 44100.0;
    int downsampleFactor = 1;
    int downsampleCounter = 0;

    // Downsample_DSP 6-stage anti-aliasing biquad cascade (legacy implementation)
    std::array<BiquadDF2, 6> downsampleFilters;

    // Input Voice Type band-limiting biquads (legacy implementation & legacy implementation)
    BiquadDF2 inputLP1, inputLP2, inputHP1;
    int currentVoiceType = -1;
    double minPeriodSamples = 40.0;
    double maxPeriodSamples = 600.0;

    // Upward pitch-shift anti-aliasing biquads (legacy implementation)
    BiquadDF2 shiftLP1, shiftLP2;

    // Classic Mode & Evo Mode running autocorrelation state (legacy implementation)
    std::array<double, kRingSize> detectorRing {};
    std::array<int, kNumLagBins> lagTable {};
    std::array<double, kNumLagBins> runningEnergy {};
    std::array<double, kNumLagBins> runningCorr {};
    int numActiveLags = 0;
    int detWriteIdx = 0;

    // 5-sample control update counter (f_update = sampleRate / 5.0, legacy implementation)
    int updateSubCounter = 0;
    double currentPeriodSamples = 150.0;
    double smoothedPeriodSamples = 150.0;
    double fastPitchMidi = 60.0;
    double slowPitchMidi = 60.0;
    bool voicedState = false;

    // Note hysteresis, Retune Speed & Humanize ramp (legacy implementation)
    int lockedTargetNote = -1;
    int sustainedNoteFrames = 0;
    double smoothedPitchRatio = 1.0;

    // Dual-pointer parabolic TD-PSOLA resynthesis (legacy implementation)
    std::array<double, kRingSize> rawInputRing {};
    int psolaWriteIdx = 0;
    double readPtrA = 0.0;
    double readPtrB = 0.0;
    double crossfadeAlpha = 0.0;
    double crossfadeStep = 0.0;
    bool crossfadingToB = false;

    float lastDetectedMidi = -1.0f;
    float lastTargetMidi = -1.0f;
    float lastCentsCorrection = 0.0f;
};

