#pragma once

#include <JuceHeader.h>
#include <array>
#include <atomic>
#include <cmath>
#include <vector>
#include "licensing/LicenseManager.h"
#include "dsp/LivePitchDSP.h"

namespace TAutoTuneParams
{
    static constexpr const char* kInputType       = "input_type";       // Tag 10: 0=Soprano, 1=Alto/Tenor, 2=Low Male, 3=Instrument, 4=Bass Inst
    static constexpr const char* kKey             = "key";              // Tag 2:  0=C .. 11=B
    static constexpr const char* kScale           = "scale";            // Tag 1:  0=Major, 1=Minor, 2=Chromatic, ... (29 scales)
    static constexpr const char* kClassicMode     = "classic_mode";     // Tag 11: bool (false=Evo, true=Classic AT5)
    static constexpr const char* kUseFormants     = "use_formants";     // Tag 70: bool
    static constexpr const char* kThroatLength    = "throat_length";    // Tag 71: 50..190 % (default 100)
    static constexpr const char* kTranspose       = "transpose";        // Tag 74: -12..+12 semitones (default 0)
    static constexpr const char* kDetune          = "detune";           // Tag 3:  -100..+100 cents (default 0 = 440.0 Hz)
    static constexpr const char* kTracking        = "tracking";         // Tag 9:  1..100 (default 50)

    static constexpr const char* kRetuneSpeed     = "retune_speed";     // Tag 4:  0..400 ms (default 20)
    static constexpr const char* kFlexTune        = "flex_tune";        // Tag 90: 0..100 (default 0)
    static constexpr const char* kNaturalVibrato  = "natural_vibrato";  // Tag 62: -12..+12 dB (default 0.0)
    static constexpr const char* kHumanize        = "humanize";         // Tag 61: 0..100 (default 0)

    static constexpr const char* kAdvancedView    = "advanced_view";    // Tag 33: bool (false=Basic, true=Advanced)
    static constexpr const char* kIgnoreVibrato   = "ignore_vibrato";   // Tag 44: bool

    static constexpr const char* kVibratoShape    = "vib_shape";        // Tag 5:  0=No Vibrato, 1=Sine Wave, 2=Square, 3=Sawtooth
    static constexpr const char* kVibratoRate     = "vib_rate";         // Tag 7:  0.1..10.0 Hz (default 5.5)
    static constexpr const char* kVibratoDelay    = "vib_delay";        // Tag 46: 0..1500 ms (default 500)
    static constexpr const char* kVibratoTrans    = "vib_transition";   // Tag 50: 0..1500 ms (default 500)
    static constexpr const char* kVibratoVar      = "vib_variation";    // Tag 49: 0..100 (default 30)
    static constexpr const char* kVibratoPitch    = "vib_pitch";        // Tag 6:  0..100 cents (default 18)
    static constexpr const char* kVibratoAmp      = "vib_amplitude";    // Tag 47: 0..100 (default 30)
    static constexpr const char* kVibratoFormant  = "vib_formant";      // Tag 48: 0..100 (default 70)
}

// Live pitch engine. Legacy flags remain accepted but are inactive in this revision.
//==============================================================================
class TAutoTuneProcessor final : public juce::AudioProcessor, private juce::Thread
{
public:
    TAutoTuneProcessor();
    explicit TAutoTuneProcessor(tak::license::StorePaths paths);
    ~TAutoTuneProcessor() override;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Auto-Tune Pro"; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Default"; }
    void changeProgramName(int, const juce::String&) override {}

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    tak::license::LicenseManager& getLicenseManager() noexcept { return licenseManager; }

    // Scale & Note State Management (0 = Active/Blue, 1 = Bypassed/Orange, 2 = Removed/Black)
    enum NoteState { kNoteActive = 0, kNoteBypassed = 1, kNoteRemoved = 2 };

    int  getNoteState(int pitchClass12) const noexcept;
    void setNoteState(int pitchClass12, int state) noexcept;
    void cycleNoteState(int pitchClass12, bool editBypassMode) noexcept;
    void applyScalePresetToNotes(int keyIdx, int scaleIdx) noexcept;
    void setMajorNotes() noexcept;
    void setMinorNotes() noexcept;
    void setAllNotesActive() noexcept;
    void setAllNotesBypassed() noexcept;
    void setAllNotesRemoved() noexcept;

    float consumeInputPeak() noexcept { return inputPeakAtom.exchange(0.0f); }
    float consumeOutputPeak() noexcept { return outputPeakAtom.exchange(0.0f); }
    bool consumeClipped() noexcept { return clippedAtom.exchange(false); }

    // UI Metering Getters
    float getDetectedMidiNote() const noexcept { return detectedMidiAtom.load(std::memory_order_relaxed); }
    float getTargetMidiNote()   const noexcept { return targetMidiAtom.load(std::memory_order_relaxed); }
    float getCentsCorrection()  const noexcept { return centsCorrectionAtom.load(std::memory_order_relaxed); }
    bool  isVoiced()            const noexcept { return voicedAtom.load(std::memory_order_relaxed); }
    void  setHoldMeter(bool hold) noexcept     { holdMeterAtom.store(hold, std::memory_order_relaxed); }
    bool  getHoldMeter() const noexcept        { return holdMeterAtom.load(std::memory_order_relaxed); }

    static juce::StringArray getScaleNames();
    static juce::StringArray getKeyNames();
    static juce::StringArray getInputTypeNames();
    static juce::StringArray getVibratoShapeNames();

    // Nonlinear Retune Speed mapping matching Antares knob (0..100 normalized -> 0..400 ms, midpoint 20..50 ms)
    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();

private:
    void run() override;

    juce::AudioProcessorValueTreeState apvts;
    tak::license::LicenseManager licenseManager;

    std::array<AntaresAutoTuneChannelDSP, 2> channelDSP;
    std::atomic<uint32_t> noteStateBits { 0 };
    std::atomic<bool> restoringState { false }, restoredNotesPending { false };
    int lastScaleIdx = -1;
    int lastKeyIdx   = -1;

    std::atomic<float> inputPeakAtom { 0 }, outputPeakAtom { 0 };
    std::atomic<bool> clippedAtom { false };
    std::atomic<float> detectedMidiAtom    { -1.0f };
    std::atomic<float> targetMidiAtom      { -1.0f };
    std::atomic<float> centsCorrectionAtom { 0.0f };
    std::atomic<bool>  voicedAtom          { false };
    std::atomic<bool>  holdMeterAtom       { false };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TAutoTuneProcessor)
};
