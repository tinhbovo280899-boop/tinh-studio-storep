#include "TAutoTuneProcessor.h"
#include "TAutoTuneEditor.h"
#include "licensing/ProductConfig.h"
#include <algorithm>
#include <cmath>

namespace
{
    static constexpr double kPi = 3.14159265358979323846;

    // 29 Authentic Antares Auto-Tune Pro Scales (1 = Note Active in Scale, 0 = Removed)
    // Intervals relative to Root Key (0 = Root, 1 = m2, ..., 11 = M7)
    static const int kScaleMasks[29][12] = {
        {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1}, // 0: MAJOR
        {1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 1, 0}, // 1: MINOR
        {1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1}, // 2: CHROMATIC
        {1, 0, 1, 1, 0, 1, 0, 1, 1, 0, 0, 1}, // 3: HARMONIC MINOR
        {1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0, 1}, // 4: MELODIC MINOR
        {1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 1, 0}, // 5: DORIAN
        {1, 1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0}, // 6: PHRYGIAN
        {1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1}, // 7: LYDIAN
        {1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 1, 0}, // 8: MIXOLYDIAN
        {1, 1, 0, 1, 0, 1, 1, 0, 1, 0, 1, 0}, // 9: LOCRIAN
        {1, 0, 1, 0, 1, 0, 0, 1, 0, 1, 0, 0}, // 10: PENTATONIC MAJOR
        {1, 0, 0, 1, 0, 1, 0, 1, 0, 0, 1, 0}, // 11: PENTATONIC MINOR
        {1, 0, 0, 1, 0, 1, 1, 1, 0, 0, 1, 0}, // 12: BLUES
        {1, 0, 1, 0, 1, 0, 1, 0, 1, 0, 1, 0}, // 13: WHOLE TONE
        {1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0, 1}, // 14: OCTATONIC (W-H)
        {1, 1, 0, 1, 1, 0, 1, 1, 0, 1, 1, 0}, // 15: OCTATONIC (H-W)
        {1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 1, 0}, // 16: PHRYGIAN DOMINANT
        {1, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 1}, // 17: HUNGARIAN MINOR
        {1, 1, 0, 0, 1, 1, 0, 1, 1, 0, 0, 1}, // 18: DOUBLE HARMONIC (ARABIC)
        {1, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0}, // 19: IN SEN (JAPANESE)
        {1, 0, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0}, // 20: HIRAJOSHI
        {1, 1, 0, 0, 1, 0, 0, 1, 1, 0, 1, 0}, // 21: HIJAZ
        {1, 0, 1, 0, 1, 0, 1, 1, 0, 1, 1, 0}, // 22: LYDIAN DOMINANT
        {1, 1, 0, 1, 1, 0, 1, 0, 1, 0, 1, 0}, // 23: ALTERED
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 1, 0}, // 24: MIXOLYDIAN b6
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 0, 0, 1}, // 25: HARMONIC MAJOR
        {1, 0, 1, 0, 1, 1, 1, 1, 0, 1, 1, 0}, // 26: BEBOP DOMINANT
        {1, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 1}, // 27: BEBOP MAJOR
        {1, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1}  // 28: RYUKYU (OKINAWAN)
    };
}

//==============================================================================
// AntaresAutoTuneChannelDSP Implementation (Decompiled from legacy implementation)
//==============================================================================
//==============================================================================
// TAutoTuneProcessor Implementation
//==============================================================================
juce::StringArray TAutoTuneProcessor::getInputTypeNames()
{
    return { "SOPRANO", "ALTO/TENOR", "LOW MALE", "INSTRUMENT", "BASS INST" };
}

juce::StringArray TAutoTuneProcessor::getKeyNames()
{
    return { "C", "Db", "D", "Eb", "E", "F", "Gb", "G", "Ab", "A", "Bb", "B" };
}

juce::StringArray TAutoTuneProcessor::getScaleNames()
{
    return {
        "MAJOR", "MINOR", "CHROMATIC", "HARMONIC MINOR", "MELODIC MINOR",
        "DORIAN", "PHRYGIAN", "LYDIAN", "MIXOLYDIAN", "LOCRIAN",
        "PENTATONIC MAJOR", "PENTATONIC MINOR", "BLUES", "WHOLE TONE",
        "OCTATONIC (W-H)", "OCTATONIC (H-W)", "PHRYGIAN DOMINANT",
        "HUNGARIAN MINOR", "ARABIC", "IN SEN", "HIRAJOSHI", "HIJAZ",
        "LYDIAN DOMINANT", "ALTERED", "MIXOLYDIAN b6", "HARMONIC MAJOR",
        "BEBOP DOMINANT", "BEBOP MAJOR", "RYUKYU"
    };
}

juce::StringArray TAutoTuneProcessor::getVibratoShapeNames()
{
    return { "(NO VIBRATO)", "SINE WAVE", "SQUARE", "SAWTOOTH" };
}

juce::AudioProcessorValueTreeState::ParameterLayout TAutoTuneProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kInputType, 1 }, "Input Type",
        getInputTypeNames(), 1)); // Alto/Tenor default for this live revision

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kKey, 1 }, "Key",
        getKeyNames(), 0)); // Default: C

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kScale, 1 }, "Scale",
        getScaleNames(), 2)); // Default: CHROMATIC (matches XML default-value="2.0")

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kClassicMode, 1 }, "Classic Mode", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kUseFormants, 1 }, "Formant", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kThroatLength, 1 }, "Throat Length",
        juce::NormalisableRange<float>(50.0f, 190.0f, 1.0f, 0.85f), 100.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kTranspose, 1 }, "Transpose",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 1.0f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kDetune, 1 }, "Detune",
        juce::NormalisableRange<float>(-100.0f, 100.0f, 0.01f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kTracking, 1 }, "Tracking",
        juce::NormalisableRange<float>(1.0f, 100.0f, 1.0f), 50.0f));

    // Retune Speed: 0..400 ms with skew 0.38 so 20 ms sits at ~10 o'clock as on original Auto-Tune Pro
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kRetuneSpeed, 1 }, "Retune Speed",
        juce::NormalisableRange<float>(0.0f, 400.0f, 1.0f, 0.38f), 20.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kFlexTune, 1 }, "Flex-Tune",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 12.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kNaturalVibrato, 1 }, "Natural Vibrato",
        juce::NormalisableRange<float>(-12.0f, 12.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kHumanize, 1 }, "Humanize",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 35.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kAdvancedView, 1 }, "Advanced View", false));

    params.push_back(std::make_unique<juce::AudioParameterBool>(
        juce::ParameterID { TAutoTuneParams::kIgnoreVibrato, 1 }, "Ignore Vibrato", false));

    params.push_back(std::make_unique<juce::AudioParameterChoice>(
        juce::ParameterID { TAutoTuneParams::kVibratoShape, 1 }, "Vibrato Shape",
        getVibratoShapeNames(), 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoRate, 1 }, "Vibrato Rate",
        juce::NormalisableRange<float>(0.1f, 10.0f, 0.1f), 5.5f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoDelay, 1 }, "Onset Delay",
        juce::NormalisableRange<float>(0.0f, 1500.0f, 1.0f), 500.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoTrans, 1 }, "Onset Rate",
        juce::NormalisableRange<float>(0.0f, 1500.0f, 1.0f), 500.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoVar, 1 }, "Variation",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 30.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoPitch, 1 }, "Vibrato Pitch",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoAmp, 1 }, "Vibrato Amplitude",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 30.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        juce::ParameterID { TAutoTuneParams::kVibratoFormant, 1 }, "Vibrato Formant",
        juce::NormalisableRange<float>(0.0f, 100.0f, 1.0f), 70.0f));

    return { params.begin(), params.end() };
}

TAutoTuneProcessor::TAutoTuneProcessor()
    : TAutoTuneProcessor(tak::license::StorePaths::forProduct(tak::license::productConfiguration())) {}

TAutoTuneProcessor::TAutoTuneProcessor(tak::license::StorePaths paths)
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      juce::Thread("AutoTunePro License"),
      apvts(*this, nullptr, "AutoTuneProParams", createParameterLayout()),
      licenseManager(tak::license::productConfiguration(), std::move(paths))
{
    applyScalePresetToNotes(0, 2);
    startThread();
}

TAutoTuneProcessor::~TAutoTuneProcessor()
{
    // Join before the manager is destroyed; polling may access files and locks.
    signalThreadShouldExit();
    notify();
    stopThread(-1);
}

void TAutoTuneProcessor::run()
{
    while (!threadShouldExit())
    {
        licenseManager.poll();
        wait(1000);
    }
}

int TAutoTuneProcessor::getNoteState(int pitchClass12) const noexcept
{
    const int pc = ((pitchClass12 % 12) + 12) % 12;
    return int((noteStateBits.load(std::memory_order_acquire) >> (2 * pc)) & 3u);
}

void TAutoTuneProcessor::setNoteState(int pitchClass12, int state) noexcept
{
    const int pc = ((pitchClass12 % 12) + 12) % 12;
    const auto mask = uint32_t(3u << (2 * pc));
    const auto value = uint32_t(std::clamp(state, 0, 2)) << (2 * pc);
    auto bits = noteStateBits.load(std::memory_order_relaxed);
    while (!noteStateBits.compare_exchange_weak(bits, (bits & ~mask) | value, std::memory_order_release, std::memory_order_relaxed)) {}
}

void TAutoTuneProcessor::cycleNoteState(int pitchClass12, bool editBypassMode) noexcept
{
    const int cur = getNoteState(pitchClass12);
    setNoteState(pitchClass12, editBypassMode ? (cur == kNoteBypassed ? kNoteActive : kNoteBypassed)
                                            : (cur == kNoteRemoved ? kNoteActive : kNoteRemoved));
}

void TAutoTuneProcessor::applyScalePresetToNotes(int keyIdx, int scaleIdx) noexcept
{
    const int key = std::clamp(keyIdx, 0, 11), scale = std::clamp(scaleIdx, 0, 28);
    uint32_t bits = 0;
    for (int pc = 0; pc < 12; ++pc) {
        const int relative = ((pc - key) % 12 + 12) % 12;
        bits |= uint32_t(kScaleMasks[scale][relative] ? kNoteActive : kNoteRemoved) << (2 * pc);
    }
    noteStateBits.store(bits, std::memory_order_release);
}

void TAutoTuneProcessor::setMajorNotes() noexcept
{
    const int k = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
    applyScalePresetToNotes(k, 0);
}

void TAutoTuneProcessor::setMinorNotes() noexcept
{
    const int k = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
    applyScalePresetToNotes(k, 1);
}

void TAutoTuneProcessor::setAllNotesActive() noexcept { noteStateBits.store(0u, std::memory_order_release); }
void TAutoTuneProcessor::setAllNotesBypassed() noexcept { noteStateBits.store(0x555555u, std::memory_order_release); }
void TAutoTuneProcessor::setAllNotesRemoved() noexcept { noteStateBits.store(0xaaaaaau, std::memory_order_release); }

void TAutoTuneProcessor::prepareToPlay(double sampleRate, int)
{
    for (auto& ch : channelDSP)
        ch.prepare(sampleRate);
}

void TAutoTuneProcessor::releaseResources() {}

bool TAutoTuneProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return out == layouts.getMainInputChannelSet();
}

void TAutoTuneProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midiMessages)
{
    juce::ScopedNoDenormals noDenormals;

    if (!licenseManager.isAllowed())
    {
        buffer.clear();
        return;
    }

    const int voiceType    = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kInputType)->load());
    const int keyIdx       = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load());
    const int scaleIdx     = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kScale)->load());
    const bool classicMode = apvts.getRawParameterValue(TAutoTuneParams::kClassicMode)->load() > 0.5f;
    const bool useFormants = apvts.getRawParameterValue(TAutoTuneParams::kUseFormants)->load() > 0.5f;
    const double throatLen = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kThroatLength)->load());
    const double transpose = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kTranspose)->load());
    const double detune    = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kDetune)->load());
    const double tracking  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kTracking)->load());

    const double retuneMs  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kRetuneSpeed)->load());
    const double flexTune  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kFlexTune)->load());
    const double natVibDb  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kNaturalVibrato)->load());
    const double humanize  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kHumanize)->load());
    const bool ignoreVib   = apvts.getRawParameterValue(TAutoTuneParams::kIgnoreVibrato)->load() > 0.5f;

    const int vibShape     = static_cast<int>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoShape)->load());
    const double vibRate   = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoRate)->load());
    const double vibDelay  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoDelay)->load());
    const double vibTrans  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoTrans)->load());
    const double vibVar    = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoVar)->load());
    const double vibPitch  = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoPitch)->load());
    const double vibAmp    = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoAmp)->load());
    const double vibForm   = static_cast<double>(apvts.getRawParameterValue(TAutoTuneParams::kVibratoFormant)->load());

    if (!restoringState.load(std::memory_order_acquire)) {
        if (restoredNotesPending.exchange(false)) {
            lastKeyIdx = keyIdx;
            lastScaleIdx = scaleIdx;
        } else if (keyIdx != lastKeyIdx || scaleIdx != lastScaleIdx) {
            applyScalePresetToNotes(keyIdx, scaleIdx);
            lastKeyIdx = keyIdx;
            lastScaleIdx = scaleIdx;
        }
    }

    // Optional MIDI note input for scale learning
    for (const auto metadata : midiMessages)
    {
        const auto msg = metadata.getMessage();
        if (msg.isNoteOn())
            setNoteState(msg.getNoteNumber() % 12, kNoteActive);
    }

    std::array<int, 12> noteStatesLocal {};
    const auto noteBits = noteStateBits.load(std::memory_order_acquire);
    for (int i = 0; i < 12; ++i)
        noteStatesLocal[static_cast<size_t>(i)] = int((noteBits >> (2 * i)) & 3u);

    const int numChannels = std::min(2, buffer.getNumChannels());
    const int numSamples  = buffer.getNumSamples();

    float blockInputPeak = 0.0f, blockOutputPeak = 0.0f;
    for (int ch = 0; ch < numChannels; ++ch)
    {
        float* data = buffer.getWritePointer(ch);
        auto& dsp   = channelDSP[static_cast<size_t>(ch)];

        for (int n = 0; n < numSamples; ++n)
        {
            if (std::isfinite(data[n])) blockInputPeak = std::max(blockInputPeak, std::abs(data[n]));
            data[n] = dsp.processSample(
                data[n], voiceType, keyIdx, scaleIdx, noteStatesLocal,
                classicMode, useFormants, throatLen, transpose, detune, tracking,
                retuneMs, flexTune, natVibDb, humanize, ignoreVib,
                vibShape, vibRate, vibDelay, vibTrans, vibVar, vibPitch, vibAmp, vibForm);
            blockOutputPeak = std::max(blockOutputPeak, std::abs(data[n]));
        }
    }

    auto publishPeak = [](std::atomic<float>& dest, float value) {
        auto old = dest.load(std::memory_order_relaxed);
        while (old < value && !dest.compare_exchange_weak(old, value, std::memory_order_relaxed)) {}
    };
    publishPeak(inputPeakAtom, blockInputPeak);
    publishPeak(outputPeakAtom, blockOutputPeak);
    if (blockInputPeak >= 1.0f || blockOutputPeak >= 1.0f) clippedAtom.store(true);

    if (!holdMeterAtom.load(std::memory_order_relaxed))
    {
        detectedMidiAtom.store(channelDSP[0].getDetectedMidiNote(), std::memory_order_relaxed);
        targetMidiAtom.store(channelDSP[0].getTargetMidiNote(), std::memory_order_relaxed);
        centsCorrectionAtom.store(channelDSP[0].getCentsCorrection(), std::memory_order_relaxed);
        voicedAtom.store(channelDSP[0].isCurrentlyVoiced(), std::memory_order_relaxed);
    }
}

juce::AudioProcessorEditor* TAutoTuneProcessor::createEditor()
{
    return new TAutoTuneEditor(*this);
}

void TAutoTuneProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    const auto noteBits = noteStateBits.load(std::memory_order_acquire);
    for (int i = 0; i < 12; ++i)
        state.setProperty("noteState_" + juce::String(i), int((noteBits >> (2*i)) & 3u), nullptr);
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void TAutoTuneProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
    {
        auto tree = juce::ValueTree::fromXml(*xmlState);
        restoringState.store(true, std::memory_order_release);
        apvts.replaceState(tree);
        applyScalePresetToNotes(int(apvts.getRawParameterValue(TAutoTuneParams::kKey)->load()),
                                int(apvts.getRawParameterValue(TAutoTuneParams::kScale)->load()));
        auto bits = noteStateBits.load(std::memory_order_acquire);
        for (int i = 0; i < 12; ++i) {
            const juce::String prop = "noteState_" + juce::String(i);
            if (tree.hasProperty(prop)) {
                const auto value = uint32_t(std::clamp(int(tree.getProperty(prop)), 0, 2));
                bits = (bits & ~(3u << (2*i))) | (value << (2*i));
            }
        }
        noteStateBits.store(bits, std::memory_order_release);
        restoredNotesPending.store(true, std::memory_order_release);
        restoringState.store(false, std::memory_order_release);
    }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new TAutoTuneProcessor();
}
