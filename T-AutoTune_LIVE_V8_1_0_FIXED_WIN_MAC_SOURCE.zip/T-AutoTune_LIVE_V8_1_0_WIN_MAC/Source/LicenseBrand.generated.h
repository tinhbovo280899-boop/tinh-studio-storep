#pragma once

namespace LicenseBrandConfig
{
    static constexpr const char* kAppDisplayName  = "Auto-Tune Pro";
    static constexpr const char* kBrandWord1      = "AUTO-TUNE";
    static constexpr const char* kBrandWord2      = "PRO";
    static constexpr const char* kBrandSubtitle   = "ANTARES EVO & CLASSIC PITCH + THROAT MODELING";
    static constexpr const char* kSplashLine2     = "ANTARES AUDIO TECHNOLOGIES / NT STUDIO";
    static constexpr const char* kPublisher       = "Antares Audio Technologies";
    static constexpr const char* kAppVersion      = "8.1.0";
    static constexpr const char* kExeName         = "Auto-Tune Pro.exe";
    static constexpr const char* kSetupName       = "Setup_Auto_Tune_Pro";
    static constexpr const char* kLicenseBrand    = "AUTOTUNEPRO";
    static constexpr int         kTrialDays       = 7;
    static constexpr const char* kContactPhone    = "0329575243";
    static constexpr const char* kContactNote     = "Goi / Zalo de mua ban quyen, gia han hoac ho tro ky thuat.";
    static constexpr const char* kAppDataDirName  = "AutoTunePro";
}
