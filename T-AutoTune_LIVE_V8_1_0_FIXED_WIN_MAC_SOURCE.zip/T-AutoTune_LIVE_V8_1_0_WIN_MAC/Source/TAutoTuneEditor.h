#pragma once
#include <JuceHeader.h>
#include "TAutoTuneProcessor.h"
#include "licensing/LicensePanel.h"

class LiveLookAndFeel final : public juce::LookAndFeel_V4 {
public:
    LiveLookAndFeel();
    void drawRotarySlider(juce::Graphics&,int,int,int,int,float,float,float,juce::Slider&) override;
};
class TAutoTuneEditor final : public juce::AudioProcessorEditor, private juce::Timer {
public:
    explicit TAutoTuneEditor(TAutoTuneProcessor&);
    ~TAutoTuneEditor() override;
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override;
    void openSettings();
    void setParameter(const char*,float);
    void updateTooltips();
    TAutoTuneProcessor& processorRef;
    LiveLookAndFeel look;
    juce::ComboBox voice,key,scale;
    std::array<juce::Slider,4> knobs;
    using ComboAtt=juce::AudioProcessorValueTreeState::ComboBoxAttachment;
    using SliderAtt=juce::AudioProcessorValueTreeState::SliderAttachment;
    std::array<std::unique_ptr<ComboAtt>,3> comboAttachments;
    std::array<std::unique_ptr<SliderAtt>,4> knobAttachments;
    juce::TextButton settings{"SETTINGS"},hold{"HOLD"};
    juce::TooltipWindow tooltips{this,500};
    std::unique_ptr<AutoKeyLicensePanel> licensePanel;
    bool licenseOpenedByUser=false,showTooltips=true;
    float inputPeak=0,outputPeak=0;
    int clipTicks=0;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TAutoTuneEditor)
};
