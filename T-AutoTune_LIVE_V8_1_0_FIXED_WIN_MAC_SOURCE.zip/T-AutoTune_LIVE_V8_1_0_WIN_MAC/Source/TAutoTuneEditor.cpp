#include "TAutoTuneEditor.h"

namespace {
const juce::Colour cyan{65,205,220},background{20,24,29},panel{31,37,44};
const char* ids[]={TAutoTuneParams::kRetuneSpeed,TAutoTuneParams::kFlexTune,
                   TAutoTuneParams::kHumanize,TAutoTuneParams::kNaturalVibrato};
const char* names[]={"RETUNE","FLEX-TUNE","HUMANIZE","NATURAL VIBRATO"};
}
LiveLookAndFeel::LiveLookAndFeel(){
    setColour(juce::Slider::textBoxTextColourId,juce::Colours::white);
    setColour(juce::Slider::textBoxBackgroundColourId,panel);
    setColour(juce::Slider::textBoxOutlineColourId,juce::Colours::transparentBlack);
    setColour(juce::ComboBox::backgroundColourId,panel);
    setColour(juce::ComboBox::textColourId,juce::Colours::white);
    setColour(juce::TextButton::buttonColourId,panel);
    setColour(juce::TextButton::buttonOnColourId,cyan.darker(.6f));
}
void LiveLookAndFeel::drawRotarySlider(juce::Graphics& g,int x,int y,int w,int h,float pos,float start,float end,juce::Slider&){
    auto b=juce::Rectangle<float>(float(x),float(y),float(w),float(h)).reduced(10);
    const float size=std::min(b.getWidth(),b.getHeight());
    b=juce::Rectangle<float>(size,size).withCentre(b.getCentre());
    g.setColour(juce::Colours::black.withAlpha(.5f));g.fillEllipse(b.translated(0,4));
    g.setGradientFill(juce::ColourGradient(juce::Colour(76,85,95),b.getTopLeft(),juce::Colour(30,35,42),b.getBottomRight(),false));g.fillEllipse(b);
    g.setColour(juce::Colour(90,102,115));g.drawEllipse(b,1);
    const float angle=start+pos*(end-start),radius=size*.43f;
    juce::Path track;track.addCentredArc(b.getCentreX(),b.getCentreY(),radius,radius,0,start,end,true);
    g.setColour(juce::Colour(12,17,22));g.strokePath(track,juce::PathStrokeType(4));
    juce::Path value;value.addCentredArc(b.getCentreX(),b.getCentreY(),radius,radius,0,start,angle,true);
    g.setColour(cyan);g.strokePath(value,juce::PathStrokeType(4));
    const auto c=b.getCentre();
    g.drawLine(c.x+std::sin(angle)*radius*.62f,c.y-std::cos(angle)*radius*.62f,
               c.x+std::sin(angle)*radius*.9f,c.y-std::cos(angle)*radius*.9f,3);
}
TAutoTuneEditor::TAutoTuneEditor(TAutoTuneProcessor& p):AudioProcessorEditor(&p),processorRef(p){
    setLookAndFeel(&look);
    auto& state=p.getAPVTS();
    auto combo=[this](juce::ComboBox& box,const juce::StringArray& values,const char* id){
        box.addItemList(values,1);box.setComponentID(id);addAndMakeVisible(box);
    };
    combo(voice,p.getInputTypeNames(),"voice");combo(key,p.getKeyNames(),"key");combo(scale,p.getScaleNames(),"scale");
    comboAttachments[0]=std::make_unique<ComboAtt>(state,TAutoTuneParams::kInputType,voice);
    comboAttachments[1]=std::make_unique<ComboAtt>(state,TAutoTuneParams::kKey,key);
    comboAttachments[2]=std::make_unique<ComboAtt>(state,TAutoTuneParams::kScale,scale);
    for(size_t i=0;i<knobs.size();++i){
        auto& k=knobs[i];k.setComponentID(ids[i]);k.setName(names[i]);
        k.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
        k.setTextBoxStyle(juce::Slider::TextBoxBelow,false,100,26);
        k.setRotaryParameters(juce::MathConstants<float>::pi*1.25f,juce::MathConstants<float>::pi*2.75f,true);
        addAndMakeVisible(k);knobAttachments[i]=std::make_unique<SliderAtt>(state,ids[i],k);
    }
    knobs[0].setTextValueSuffix(" ms");knobs[3].setTextValueSuffix(" dB");
    settings.setComponentID("settings");addAndMakeVisible(settings);settings.onClick=[this]{openSettings();};
    hold.setComponentID("hold");hold.setClickingTogglesState(true);addAndMakeVisible(hold);
    hold.onClick=[this]{processorRef.setHoldMeter(hold.getToggleState());};
    licensePanel=std::make_unique<AutoKeyLicensePanel>(
        [this]{return processorRef.getLicenseManager().snapshot();},
        [this](const juce::String& token){processorRef.getLicenseManager().requestActivation(token);},
        [this]{processorRef.getLicenseManager().requestTrial();},
        [this]{licenseOpenedByUser=false;licensePanel->setVisible(false);});
    addChildComponent(*licensePanel);
    updateTooltips();setSize(760,450);startTimerHz(30);
}
TAutoTuneEditor::~TAutoTuneEditor(){stopTimer();juce::PopupMenu::dismissAllActiveMenus();setLookAndFeel(nullptr);}
void TAutoTuneEditor::setParameter(const char* id,float value){
    if(auto* p=processorRef.getAPVTS().getParameter(id)){
        p->beginChangeGesture();p->setValueNotifyingHost(p->convertTo0to1(value));p->endChangeGesture();
    }
}
void TAutoTuneEditor::openSettings(){
    auto& state=processorRef.getAPVTS();
    const float track=state.getRawParameterValue(TAutoTuneParams::kTracking)->load();
    const float detune=state.getRawParameterValue(TAutoTuneParams::kDetune)->load();
    juce::PopupMenu menu,tracking,reference;
    menu.addSectionHeader("LIVE SETTINGS");
    for(int value:{25,50,75})tracking.addItem(100+value,juce::String(value),true,std::abs(track-value)<.5f);
    menu.addSubMenu("Tracking",tracking);
    for(int hz:{432,440,442}){
        const double cents=1200.0*std::log2(double(hz)/440.0);
        reference.addItem(hz,juce::String(hz)+" Hz",true,std::abs(detune-cents)<.6);
    }
    menu.addSubMenu("Pitch reference (A4)",reference);
    menu.addItem(10,"Tooltips",true,showTooltips);
    menu.addSeparator();menu.addItem(11,"License / activation");menu.addItem(12,"About this live version");
    menu.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&settings),
        [safe=juce::Component::SafePointer<TAutoTuneEditor>(this)](int result){
        if(!safe)return;
        if(result==125||result==150||result==175)safe->setParameter(TAutoTuneParams::kTracking,float(result-100));
        else if(result==432||result==440||result==442)safe->setParameter(TAutoTuneParams::kDetune,float(1200*std::log2(double(result)/440)));
        else if(result==10){safe->showTooltips=!safe->showTooltips;safe->updateTooltips();}
        else if(result==11){safe->licenseOpenedByUser=true;safe->licensePanel->setVisible(true);safe->licensePanel->toFront(false);}
        else if(result==12)juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::InfoIcon,"Live pitch",
            "Retune, Flex-Tune, Humanize and Natural Vibrato.\nLegacy Graph, Classic, Formant/Throat and synthetic vibrato are inactive.\nPitch shifting uses a variable delay; total monitoring latency also depends on the audio interface and host buffer.");
    });
}
void TAutoTuneEditor::updateTooltips(){
    const char* tips[]={"Correction speed. Lower values give a stronger tuning effect.",
        "Allows expressive pitch movement around the selected scale.","Slows correction on held notes.",
        "Adjusts the natural vibrato component; does not generate artificial vibrato."};
    for(size_t i=0;i<knobs.size();++i)knobs[i].setTooltip(showTooltips?tips[i]:"");
    settings.setTooltip(showTooltips?"Tracking, pitch reference, tooltips and activation":"");
}
void TAutoTuneEditor::resized(){
    voice.setBounds(24,90,185,30);key.setBounds(225,90,100,30);scale.setBounds(341,90,240,30);
    settings.setBounds(getWidth()-135,24,110,30);hold.setBounds(650,145,85,24);
    for(size_t i=0;i<knobs.size();++i)knobs[i].setBounds(20+int(i)*185,265,165,142);
    if(licensePanel)licensePanel->setBounds(getLocalBounds());
}
void TAutoTuneEditor::paint(juce::Graphics& g){
    g.fillAll(background);g.setColour(panel);g.fillRoundedRectangle(14,134,float(getWidth()-28),100,10);
    auto font=[&g](float size,bool bold=false){g.setFont(juce::Font(juce::FontOptions(size,bold?juce::Font::bold:juce::Font::plain)));};
    g.setColour(cyan);font(23,true);g.drawText("T-AUTO TUNE",24,18,280,30,juce::Justification::centredLeft);
    g.setColour(juce::Colours::lightgrey);font(12);g.drawText("LIVE",26,49,180,20,juce::Justification::centredLeft);
    const char* labels[]={"VOICE","KEY","SCALE"};const int xs[]={24,225,341};
    for(int i=0;i<3;++i)g.drawText(labels[i],xs[i],69,130,18,juce::Justification::centredLeft);
    const float target=processorRef.getTargetMidiNote();
    const auto note=processorRef.isVoiced()&&std::isfinite(target)&&target>=0
        ? juce::MidiMessage::getMidiNoteName(juce::roundToInt(target),true,true,4):juce::String("--");
    g.setColour(cyan);font(36,true);g.drawText(note,32,145,125,50,juce::Justification::centred);
    font(12);g.setColour(juce::Colours::lightgrey);g.drawText("PITCH CORRECTION",187,149,250,18,juce::Justification::centredLeft);
    auto meter=juce::Rectangle<float>(190,185,410,7);
    g.setColour(juce::Colour(12,17,22));g.fillRoundedRectangle(meter,3);
    const float cents=std::clamp(processorRef.getCentsCorrection(),-50.0f,50.0f);
    const float cx=meter.getCentreX(),tip=cx+cents/50.0f*meter.getWidth()*.5f;
    g.setColour(cyan);g.fillRect(juce::Rectangle<float>(std::min(cx,tip),185,std::max(2.0f,std::abs(tip-cx)),7));
    g.setColour(juce::Colours::grey);g.drawText("-50                     0                     +50 cents",190,200,410,16,juce::Justification::centred);
    for(size_t i=0;i<knobs.size();++i){g.setColour(juce::Colours::lightgrey);font(12,true);g.drawText(names[i],20+int(i)*185,242,165,20,juce::Justification::centred);}
    auto db=[](float v){return v>0?juce::String(juce::Decibels::gainToDecibels(v,-90.0f),1):juce::String("-inf");};
    font(12);g.setColour(clipTicks>0?juce::Colours::orangered:juce::Colours::lightgrey);
    g.drawText("IN  "+db(inputPeak)+" dBFS     OUT  "+db(outputPeak)+" dBFS"+(clipTicks>0?"     CLIP":""),24,418,700,20,juce::Justification::centredLeft);
}
void TAutoTuneEditor::timerCallback(){
    inputPeak=std::max(processorRef.consumeInputPeak(),inputPeak*.86f);
    outputPeak=std::max(processorRef.consumeOutputPeak(),outputPeak*.86f);
    if(processorRef.consumeClipped())clipTicks=45;else if(clipTicks>0)--clipTicks;
    const bool visible=!processorRef.getLicenseManager().isAllowed()||licenseOpenedByUser;
    if(licensePanel->isVisible()!=visible){licensePanel->setVisible(visible);if(visible)licensePanel->toFront(false);}
    repaint();
}
