@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo.
echo ===========================================
echo  SINH KHOA VA KEY BAN QUYEN T-MELODYNE
echo  (Chay truc tiep bang PowerShell - KHONG CAN C++)
echo ===========================================
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\sinh_key.ps1" -Root "%~dp0."
set RC=%errorlevel%
echo.
if %RC%==0 (
    echo [OK] Thuc hien thanh cong!
) else (
    echo [LOI] Co loi xay ra trong qua trinh sinh key.
)
pause
exit /b %RC%
