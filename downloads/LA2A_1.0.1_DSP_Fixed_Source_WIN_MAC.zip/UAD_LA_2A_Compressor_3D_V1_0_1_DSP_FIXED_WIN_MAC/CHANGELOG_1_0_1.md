# Thay đổi 1.0.1

Sửa các lỗi được xác nhận trong gói 1.0.0 đã cung cấp. Giữ các ID plugin, ID tham số, giao diện, 10 preset và cấu trúc bộ cài; version tăng lên 1.0.1.

- Power: fade tuyến tính 5 ms; tiếp tục cập nhật detector, bộ nhớ nén và bộ lọc khi tắt. Host bypass cũng dùng đường xử lý này. Chưa đánh giá mọi cách Cubase suspend plugin khi bypass.
- Gain, Peak Reduction, Emphasis và độ dốc Compress/Limit: làm mượt với cùng hằng số thời gian ở các sample rate. Reset/prepare lấy giá trị target hiện hành.
- Hệ số envelope chuyển từ phép nhân tỷ lệ sample rate gần đúng sang ánh xạ cực bộ lọc, giữ hằng số thời gian tham chiếu 44,1 kHz. Emphasis dùng cực quanh 120 Hz.
- Output: RMS power follower 120 ms theo từng mẫu; GR follower 120 ms không chặn hệ số ở sample rate cao. Output meter phản ánh cả dry khi Power off. Mức thấp nhất hiển thị từ DSP là -100 dBFS.
- Saturation: thay `x/(1+0.25*(t*x)^2)` bằng `x/sqrt(1+0.5*(t*x)^2)`. Hai hàm khớp tới hệ số bậc ba ở mức nhỏ; hàm mới không foldback khi quá tải và vẫn đối xứng. Đây là mô hình tạo màu tĩnh, chưa mô phỏng vật lý đèn/biến áp.
- Nội suy 4x polyphase FIR, chạy hàm saturation rồi lọc/decimate. Mỗi FIR 129 tap, cửa sổ Kaiser beta=8,6, cutoff bằng Nyquist của host. Lịch sử cố định, không cấp phát trong audio callback. Drive và Gain được delay tương ứng để gần khớp group delay của FIR.
- Độ trễ 32 mẫu khai báo cho host; dry có delay cùng độ trễ. Tail FIR tối đa 64 mẫu. Bandwidth gần phẳng tới 18 kHz ở 44,1/48 kHz; ở 44,1 kHz, phép đo 20 kHz cho suy hao khoảng 0,885 dB của tầng colour.
- Alias: phép thử sine 10 kHz, peak 0,95, drive 1,2, Fs=48 kHz cho thành phần alias 18 kHz giảm khoảng 83,5 dB so với cùng hàm mới chạy 1x. Đây là một phép thử cụ thể, không phải mức giảm cho mọi tín hiệu hay so sánh với UAD gốc.
- Build: sửa thiếu đầu vòng lặp chép runtime trong windows.ps1; tìm thêm runtime GNU cạnh compiler đã chọn. mac.sh không gọi find trên thư mục cmake không tồn tại. CMake tách chế độ DSP-only khỏi phụ thuộc JUCE/GUI.
- Test dùng kiểm tra tường minh thay assert, nên Release/NDEBUG vẫn kiểm tra thật. Có test audio/meter theo buffer, sample rate, bypass memory/fade, latency/tail, mono/stereo, overload, phổ alias và passband; test PowerShell dùng native command mock và file fixture.

Phần nén có thể nghe hơi khác do ánh xạ hệ số chính xác hơn và tầng tạo màu mới. Gain không bị giới hạn ở 0 dBFS; hãy cân bằng mức ra và dùng limiter riêng nếu cần trần an toàn. Oversampling cố định 4x tăng CPU so với 1.0.0. Chưa kết luận độ giống thuật toán hoặc chất âm với DLL UAD gốc.
