# T-Verb 1.0.2 — Shutdown / Vocal presets — Windows / macOS

Giao diện tím vòng tròn theo mẫu đã chọn, giữ tên điều khiển quen thuộc của bản cũ. Đây là mã nguồn để build VST3 / Standalone, không phải plugin đã biên dịch sẵn.

## Giao diện mới

- Bốn điểm quanh vòng tròn: `room size`, `room width`, `diffusion`, `density`.
- `decay` ở giữa: hiển thị giây với ba chữ số thập phân, ví dụ `3.506 s`.
- `time design`: `predelay`, `attack`, `spread`.
- `damping / frequency display`: `lo ratio`, `mid ratio`, `hi ratio`, hai tần số chia dải.
- `eq`: `lo cut`, `hi cut`.
- `echo`: `intensity`, `size`; intensity vẫn chỉnh liên tục 0–100%, không bị đổi thành công tắc.
- `misc`: `modulation`, `quality`.
- `level`: `dry`, `wet` độc lập, có nút bật/tắt riêng.
- Chọn đủ 13 room types, 20 preset tiếng Việt (16 gốc + 4 preset Vocal/FX Send/Insert) (mặc định chuẩn Vang Dài: Decay 3.506s, Predelay 70ms, Attack 7%, Spread 10%, Size 40m, Width 160°, Diffusion 70%, Density 80%, Lo Cut 120Hz, Hi Cut 9819Hz, Dry -oo dB, Wet +0.84 dB), chạy cố định 64-Bit Double Precision, lưu/nạp preset và bypass.
- Kéo góc dưới bên phải để thu phóng từ 800 × 500 đến 1920 × 1200; các thành phần co giãn cùng nhau. Mặc định 1120 × 700.

## Cách chỉnh

- Kéo điểm sáng, núm xoay hoặc thanh trượt để đổi thông số. Với decay, kéo trên vùng nhãn/số giữa vòng tròn.
- Giữ Shift khi kéo để chỉnh chậm và chính xác hơn.
- Nhấp đúp vào con số để nhập giá trị; có thể nhập `11.5 kHz` cho tần số.
- Nhấp chuột phải trên nút/điểm chỉnh để về giá trị mặc định của tham số.
- Trên đồ thị: kéo các chấm lên/xuống để chỉnh tỷ lệ damping; kéo đường đứng sang trái/phải để chỉnh tần số chia dải. Các ô số bên dưới cũng nhập trực tiếp được.
- Nút hình đĩa mềm lưu `.tverb`; nút hình thư mục nạp `.tverb`/`.xml`.
- Các vòng và hình phòng là nền trang trí. Đường damping/EQ được tính theo thông số, không phải máy đo FFT.

Đơn vị: decay = s; predelay và echo size = ms; room size = mtr; room width = độ; damping ratio = x; dry/wet = dB; tần số = Hz/kHz.

## Build trên Mac

Dùng CMake 3.22+ và Xcode Command Line Tools. Đặt JUCE 8 trong thư mục `JUCE` cạnh mã nguồn hoặc cho phép CMake tải bản đã ghim.

- `1_BUILD_MAC_UNIVERSAL.command`: build cho cả Apple Silicon và Intel → `_EXPORT_MAC_UNIVERSAL/VST3/T-Verb.vst3`.
- `2_BUILD_MAC_ARM64.command`: Apple Silicon → `_EXPORT_MAC_ARM64/VST3/T-Verb.vst3`.
- `3_BUILD_MAC_INTEL.command`: Intel → `_EXPORT_MAC_INTEL/VST3/T-Verb.vst3`.
- `BUILD_RELEASE.command`: mặc định Universal → `_EXPORT_MAC_UNIVERSAL/VST3/T-Verb.vst3`.

Nếu file `.command` chưa chạy được, mở Terminal trong thư mục đã giải nén:

```bash
chmod +x ./*.command
./1_BUILD_MAC_UNIVERSAL.command
```

## Build trên Windows

Cần Visual Studio/Build Tools 2019 trở lên có Desktop development with C++ và CMake. Script tự tìm bản MSVC x64 mà CMake hỗ trợ; VS 2026 cần CMake 4.2+. Chạy `BUILD_RELEASE.bat`. Kết quả trong `_EXPORT_WIN/VST3/T-Verb.vst3`. Xem `TU_TIM_CPP_WINDOWS.md` nếu trước đó gặp lỗi không tìm thấy Visual Studio 2022.

## Mã nguồn

- `src/VerbEditor.h`: bố cục Orbit, các điều khiển và đồ thị tương tác.
- `src/OrbitValues.h`: định dạng giá trị và phép đổi tọa độ đồ thị.
- `resources/OrbitSkin.png`: nền đã bỏ toàn bộ chữ/số/nút; mọi giá trị và điều khiển được vẽ bằng code.
- `resources/OrbitSerif.ttf`: font nhúng để đồng nhất chữ; giấy phép đi kèm `FONT_LICENSE.txt`.
- `tests/test_ui_values.cpp`: kiểm tra đơn vị hiển thị và phép đổi tọa độ tương tác.

Bản 1.0.1 sửa bộ lọc damping, resampler/dry, chuyển EQ, cấp phát audio và metadata đuôi vang. Giữ ID/thang tham số, giá trị factory preset, định dạng state và cặp khóa bản quyền. Xem `SUA_LOI_1_0_1.md` để biết lịch sử sửa DSP; `SUA_LOI_1_0_2.md` ghi thay đổi shutdown và preset vocal.

## Kiểm tra DSP không cần JUCE GUI

Dùng CMake 3.22+ và compiler C++17, chạy từ thư mục dự án:

```bash
cmake -S . -B build_engine -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON -DTVERB_ENGINE_TESTS_ONLY=ON
cmake --build build_engine --config Release --parallel 2
ctest --test-dir build_engine -C Release --output-on-failure
```

Gồm 183 kiểm tra cơ bản + 134 kiểm tra mở rộng (317 phép kiểm tra DSP), cùng kiểm tra cấp phát khi xử lý ổn định, đổi quality/tham số và block vượt kích thước đã chuẩn bị. Các bài test tạo dữ liệu đo trong thư mục build, không trong `src`.

## Kiểm tra processor, state, bản quyền và đơn vị hiển thị

Cần đầy đủ công cụ và các thư viện hệ thống cho JUCE trên nền tảng đang build:

```bash
cmake -S . -B build_test -DCMAKE_BUILD_TYPE=Release -DBUILD_TESTING=ON
cmake --build build_test --config Release --parallel 2 --target TVerbEngineAuditTests TVerbEngineExtendedTests TVerbRealtimeAllocationTests TVerbDSPTests TVerbLicenseTests TVerbUIValueTests
ctest --test-dir build_test -C Release --output-on-failure
```

Test processor dùng thư mục trial tạm, kiểm tra bản quyền thật, không bỏ qua kiểm tra license và không thay dữ liệu kích hoạt đã cài. Kiểm tra Windows/macOS trong Cubase/DAW vẫn cần làm trên máy đích. File ZIP này là mã nguồn dành cho chủ dự án, không phải bộ cài VST3 Windows/macOS đã biên dịch.

## Bản 1.0.2

Đã thêm test tạo/hủy processor khi giữ UI lock và chặn hiệu chỉnh host sau release. Xem `SUA_LOI_1_0_2.md`. Dùng FX Send: xem `HUONG_DAN_FX_SEND_VOCAL.md`. Chưa xác nhận hết lỗi treo trên Cubase/Windows/macOS; cần thử lại trên máy đích.
