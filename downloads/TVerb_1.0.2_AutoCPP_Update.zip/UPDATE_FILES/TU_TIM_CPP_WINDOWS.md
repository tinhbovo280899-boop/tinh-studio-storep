# Cập nhật Auto C++ cho T-Verb 1.0.2

Các file BAT vẫn dùng như trước. `tools/windows.ps1` không còn ép generator `Visual Studio 17 2022`.

- Tìm Visual Studio/Build Tools đã cài bằng `vswhere`, yêu cầu workload MSVC C++ x64/x86. Kiểm tra file compiler x64 thực sự tồn tại.
- Chọn bản mới nhất từ VS 2019 trở lên mà CMake hiện tại hỗ trợ, gồm VS 2019/2022/2026; không yêu cầu cài riêng VS 2022 khi đã có bản khác phù hợp.
- Chỉ định đúng instance VS, kể cả bản Build Tools hoặc cài ở đường dẫn khác mặc định.
- Nếu đang ở môi trường x64 Developer Command Prompt và có MSVC, có thể dùng Ninja Multi-Config hoặc NMake thay generator Visual Studio.
- Kiểm tra cache build. Khi generator, instance, compiler, kiến trúc hoặc đường dẫn nguồn thay đổi, dùng một thư mục build song song có hậu tố `_auto_...`; giữ nguyên thư mục cũ. Bước keygen và bước plugin đều dùng đúng đường dẫn đã chọn.
- Ghi lại thư mục build plugin thành công để thao tác xuất file riêng sau đó tìm đúng receipt. Kiểm tra checksum/source và chặn private key vẫn được giữ.
- Nếu chỉ có VS 2026 nhưng CMake quá cũ, báo cần CMake 4.2+. Nếu không có MSVC phù hợp, báo cần workload C++, MSVC x64/x86 và Windows 10/11 SDK; script không tự cài phần mềm.

Phạm vi là bộ compiler MSVC hỗ trợ dự án. Không nhận một trình soạn thảo hoặc một bản C++ không có compiler/SDK làm bộ build hợp lệ; chưa thêm đường build MinGW chưa được kiểm chứng.

## Cách cập nhật

1. Giải nén `TVerb_1.0.2_AutoCPP_Update.zip`.
2. Chép **nội dung** trong `UPDATE_FILES` đè vào thư mục nguồn gốc chứa `CMakeLists.txt`. Gói này gồm cả các sửa 1.0.2 trước đó.
3. Chạy lại `4_BUILD_VA_TAO_BO_CAI.bat` hoặc file BAT đã dùng. Không cần xóa thư mục build cũ và không cần sinh lại cặp khóa chỉ để đổi compiler.

Các dòng đầu log cho biết compiler, generator và thư mục build được chọn. Nếu máy chưa có bộ C++/SDK thì vẫn phải cài bổ sung; tự tìm không thay thế việc cài compiler.

## Kiểm chứng

Đã chạy PowerShell với 41 kiểm tra mô phỏng metadata/file VS và đường gọi Configure/Keygen thật trong script: nhiều bản VS, Build Tools, thiếu compiler, bản cài chưa hoàn tất, CMake không hỗ trợ VS 2026, cache cũ, đường dẫn có dấu cách và môi trường MSVC x64 có Ninja/NMake. Bộ test bảo vệ xuất file cũng đạt.

Thử nghiệm thực hiện bằng PowerShell trên Linux, không chạy MSVC hoặc installer Windows. Chưa xác nhận tự nhận toolchain trên chính máy người dùng. Xem `VALIDATION/windows_toolchain_tests.txt` và `VALIDATION/windows_export_guard_tests.txt`. Không đổi DSP, preset, cặp khóa hay thời hạn trial bảy ngày.
