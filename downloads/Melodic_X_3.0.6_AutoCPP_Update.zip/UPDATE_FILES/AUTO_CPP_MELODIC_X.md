# Melodic X 3.0.6 — cập nhật tự tìm C++ Windows

Gói này sửa riêng phần chọn compiler trong script Windows anh đã gửi. Không phải bộ mã nguồn Melodic X đầy đủ hoặc bản VST3 đã biên dịch.

## Áp dụng

Giải nén ZIP, chép nội dung trong `UPDATE_FILES` vào thư mục dự án Melodic X, nơi có `CMakeLists.txt`, đồng ý thay `tools/windows.ps1`. Phải chép cả file mới `tools/windows_toolchain.ps1`. Giữ nguyên các file và thư mục khác. Sau đó dùng file BAT như trước.

## Phần đã sửa

- Không ép `Visual Studio 17 2022`.
- Dùng `vswhere` tìm Visual Studio/Build Tools có MSVC x64, kiểm tra file compiler thật, chọn phiên bản mà CMake hỗ trợ (2019/2022/2026).
- Chỉ định đúng instance Visual Studio, kể cả cài ngoài vị trí mặc định.
- Có thể dùng Ninja/NMake khi đã mở môi trường MSVC x64 Developer Command Prompt phù hợp.
- Nếu cache khác generator, compiler, kiến trúc, instance hoặc đường dẫn nguồn, dùng thư mục build song song, giữ nguyên thư mục cũ.
- Bước build và tìm executable Keygen đều dùng đúng thư mục đã chọn. Giữ tên target `MelodicXKeygen`, `MelodicX_VST3` và tên executable Melodic X của script đã gửi.
- Truyền thêm option `MELODICX_BUILD_PLUGIN` tương ứng với option quan sát được trong CMakeLists; vẫn giữ các flag TAK cũ để tương thích với phần cấu hình chưa có trong gói gửi.
- Nếu chỉ có VS 2026 nhưng CMake không hỗ trợ, báo cần CMake 4.2+. Nếu thiếu compiler thì báo rõ cần MSVC C++ x64/x86 và Windows SDK. Không tự cài phần mềm.

Không đổi DSP, cấu hình bản quyền, keygen, mã bộ cài hay nội dung `mac.sh` đã gửi. Script Mac vốn dùng `xcrun --find clang++`; chỉ kiểm tra cú pháp file đó trong lần này.

## Kết quả kiểm tra

42 kiểm tra PowerShell đạt trên Linux với metadata/file VS mô phỏng, gồm cả việc gọi Configure/Keygen trong script Melodic X. Bộ kiểm tra checksum, stale source, extra file và ngăn private key lọt vào gói xuất cũng đạt, dùng payload giả. Không biên dịch hoặc chạy compiler Windows, DSP Melodic X, keygen thật, installer hay DAW.

## Lỗi cấu hình khác vẫn còn

`CMakeLists.txt` anh xác nhận là toàn bộ file chỉ có 544 byte: khai báo project, C++17, macOS, `add_subdirectory(JUCE)` và option `MELODICX_BUILD_PLUGIN`. Không có phần tạo target `MelodicX_VST3`, `MelodicXKeygen` hoặc các target test mà script yêu cầu. Vì vậy tự tìm được C++ chưa đồng nghĩa build ra plugin được. Gói này không thay CMakeLists.txt và chưa giải quyết việc thiếu target.

Cần các file mã nguồn thực tế để viết phần CMake còn thiếu cho đúng. Có thể nén lại dự án nhưng bỏ `JUCE`, `runtime`, các thư mục `build...`, `_EXPORT...` và `Output` để gửi gói nhỏ; giữ các file source, CMake, tools, resource và installer còn lại. Không cần gửi private key.
