param([ValidateSet('InitKeys','Build','Export','Installer','All','Check','Config','Menu')][string]$Action='Menu')
$ErrorActionPreference='Stop'
$Root=(Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location -LiteralPath $Root
$Config=Get-Content -LiteralPath (Join-Path $Root 'ThuongHieu.json') -Raw -Encoding UTF8 | ConvertFrom-Json
foreach($name in @('licenseBrand','productId')) { if([string]$Config.$name -notmatch '^[A-Za-z0-9_-]{1,64}$'){throw "Invalid $name in ThuongHieu.json"} }
if([string]$Config.productName -match '[\\/:*?"<>|\r\n]' -or [string]::IsNullOrWhiteSpace([string]$Config.productName)){throw 'Invalid productName'}
if([string]$Config.appVersion -notmatch '^\d+\.\d+\.\d+$'){throw 'Use a three-part appVersion'}
$Build=Join-Path $Root 'build_win_x64'
$KeyBuild=Join-Path $Root 'build_keygen_win_x64'
$Export=Join-Path $Root '_EXPORT_WIN'
$StoreName=[string]$Config.productId+'-'+[string]$Config.licenseBrand
$BundleName=[string]$Config.productName+'.vst3'
$LogDir=Join-Path $Root 'build_logs';New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$Log=Join-Path $LogDir ('WINDOWS_'+$Action+'_'+(Get-Date -Format 'yyyyMMdd_HHmmss')+'.txt')
function Say([string]$Text){Write-Host $Text;Add-Content -LiteralPath $Log -Value $Text -Encoding UTF8}
function Run([string]$Exe,[string[]]$Arguments){
    Say ('> '+$Exe+' '+($Arguments -join ' '))
    $old=$ErrorActionPreference;$ErrorActionPreference='Continue'
    try { & $Exe @Arguments 2>&1 | ForEach-Object {Say ([string]$_)};$rc=$LASTEXITCODE } finally {$ErrorActionPreference=$old}
    if($rc -ne 0){throw "Command failed ($rc). See $Log"}
}
function Tool([string]$Name){$c=Get-Command $Name -ErrorAction SilentlyContinue;if(-not $c){throw "Install $Name and add it to PATH"};return $c.Source}
. (Join-Path $PSScriptRoot 'windows_toolchain.ps1')
$MelodicXToolchain=$null
function PrepareWindowsBuild {
    if($script:MelodicXToolchain){return}
    $script:MelodicXToolchain=Find-MelodicXWindowsToolchain (Tool 'cmake.exe')
    $script:Build=Resolve-MelodicXBuildDirectory $Build $script:MelodicXToolchain $Root
    $script:KeyBuild=Resolve-MelodicXBuildDirectory $KeyBuild $script:MelodicXToolchain $Root
    Say ('C++ compiler: '+$script:MelodicXToolchain.Compiler)
    Say ('CMake generator: '+$script:MelodicXToolchain.Generator)
    Say ('Plugin build directory: '+$script:Build)
    Say ('Keygen build directory: '+$script:KeyBuild)
}
function Configure([string]$Directory,[bool]$Plugin,[bool]$Keygen,[bool]$Tests){
    $cmakeArguments=New-MelodicXConfigureArguments $Root $Directory $script:MelodicXToolchain $Plugin $Keygen $Tests
    if($env:TXKEY_JUCE_PATH){$cmakeArguments+=('-DTXKEY_JUCE_PATH='+$env:TXKEY_JUCE_PATH)}
    Run (Tool 'cmake.exe') $cmakeArguments
}
function PublicKeyReady {
    $file=Join-Path $Root 'config\public_key.txt';$text=[IO.File]::ReadAllText($file).Trim()
    if($text.Length -ne 518 -or $text -notmatch '^10001,[89a-fA-F][0-9a-fA-F]+[13579bBdDfF]$'){throw 'No valid RSA-2048 public key configured. Run 1_SINH_KEY.bat first.'}
}
function SourceHash {
    $paths=@((Join-Path $Root 'CMakeLists.txt'),(Join-Path $Root 'ThuongHieu.json'),(Join-Path $Root 'config\public_key.txt'),(Join-Path $Root 'Installer\Melodic-X.iss'),(Join-Path $Root 'HUONG_DAN_KHACH.txt'),(Join-Path $Root 'LICENSE'))
    foreach($folder in @('src','keygen','cmake','tests','tools')){$paths+=@(Get-ChildItem -LiteralPath (Join-Path $Root $folder) -Recurse -File | ForEach-Object {$_.FullName})}
    $rows=@($paths|Sort-Object -Unique|ForEach-Object { $_.Substring($Root.Length+1).Replace('\','/')+':'+(Get-FileHash -LiteralPath $_ -Algorithm SHA256).Hash })
    $sha=[Security.Cryptography.SHA256]::Create();try{return ([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(($rows -join "`n"))))).Replace('-','')}finally{$sha.Dispose()}
}
function FileList([string]$Folder){
    return @(Get-ChildItem -LiteralPath $Folder -Recurse -File | Sort-Object FullName | ForEach-Object { @{path=$_.FullName.Substring($Folder.Length+1).Replace('\','/');sha256=(Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash} })
}
function CheckFiles([string]$Folder,$Files){
    foreach($item in $Files){$p=Join-Path $Folder $item.path;if(-not(Test-Path -LiteralPath $p -PathType Leaf) -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne $item.sha256){throw "Missing/modified output: $($item.path)"}}
    if(@(Get-ChildItem -LiteralPath $Folder -Recurse -File).Count -ne @($Files).Count){throw 'Output contains unexpected files'}
}
function GuardCustomerFiles([string]$Folder){
    $bad=@(Get-ChildItem -LiteralPath $Folder -Recurse -Force | Where-Object {$_.Name -match '(?i)PRIVATE_KEY|KhoaBanQuyen|Keygen|\.taklic$'})
    if($bad.Count){throw 'Customer output contains owner keys, keygen or an activation file'}
    $private=Join-Path $Root ('KhoaBanQuyen\'+$StoreName+'\PRIVATE_KEY.txt')
    if(Test-Path -LiteralPath $private){
        $secret=[IO.File]::ReadAllText($private).Trim()
        foreach($f in Get-ChildItem -LiteralPath $Folder -Recurse -File){if($secret.Length -gt 100 -and [Text.Encoding]::ASCII.GetString([IO.File]::ReadAllBytes($f.FullName)).Contains($secret)){throw 'Private key material found in customer output'}}
    }
}
function InitKeys {
    PrepareWindowsBuild
    Say '[1] Build owner Keygen and initialize/reuse RSA keys'
    Configure $KeyBuild $false $true $false
    Run (Tool 'cmake.exe') @('--build',$KeyBuild,'--config','Release','--target','MelodicXKeygen','--parallel','2')
    $exe=Join-Path $KeyBuild 'MelodicXKeygen_artefacts\Release\Melodic X-Keygen.exe'
    if(-not(Test-Path -LiteralPath $exe)){throw 'Keygen executable is missing'}
    Run $exe @('--init',$Root)
    $owner=Join-Path $Root 'KEYGEN';New-Item -ItemType Directory -Force -Path $owner|Out-Null
    Copy-Item -LiteralPath $exe -Destination (Join-Path $owner 'Melodic X-Keygen.exe') -Force
    PublicKeyReady
    Say 'KEYGEN ready. Back up KhoaBanQuyen and KEYGEN. Keep them for the owner only.'
}
function ExportFiles {
    PublicKeyReady
    if(-not $script:MelodicXToolchain){
        $record=Join-Path $Root 'build_logs/last_windows_build.txt'
        if(Test-Path -LiteralPath $record -PathType Leaf){
            $saved=[IO.File]::ReadAllText($record).Trim()
            $local=ConvertTo-MelodicXComparablePath ([IO.Path]::GetFullPath($saved))
            $prefix=(ConvertTo-MelodicXComparablePath ([IO.Path]::GetFullPath($Root)))+'/'
            if($local.StartsWith($prefix) -and (Test-Path -LiteralPath (Join-Path $saved 'tak-build.json'))){$script:Build=$saved}
        }
    }
    $receiptFile=Join-Path $Build 'tak-build.json'
    if(-not(Test-Path -LiteralPath $receiptFile)){throw 'Build first with 2_BUILD_VA_XUAT_FILE.bat'}
    $receipt=Get-Content -LiteralPath $receiptFile -Raw -Encoding UTF8|ConvertFrom-Json
    if($receipt.sourceHash -ne (SourceHash)){throw 'Source/public key changed after build. Build again.'}
    CheckFiles $receipt.bundle $receipt.files
    $stage=$Export+'.new';if(Test-Path -LiteralPath $stage){Remove-Item -LiteralPath $stage -Recurse -Force}
    New-Item -ItemType Directory -Force -Path (Join-Path $stage 'VST3')|Out-Null
    Copy-Item -LiteralPath $receipt.bundle -Destination (Join-Path $stage ('VST3\'+$BundleName)) -Recurse
    Copy-Item -LiteralPath (Join-Path $Root 'HUONG_DAN_KHACH.txt') -Destination $stage
    Copy-Item -LiteralPath (Join-Path $Root 'LICENSE') -Destination (Join-Path $stage 'LICENSE.txt')
    GuardCustomerFiles $stage
    $manifest=@{product=[string]$Config.productId;brand=[string]$Config.licenseBrand;version=[string]$Config.appVersion;platform='Windows x64';sourceHash=(SourceHash);files=(FileList $stage)}
    $manifest|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $stage 'manifest.json') -Encoding UTF8
    if(Test-Path -LiteralPath $Export){Remove-Item -LiteralPath $Export -Recurse -Force};Move-Item -LiteralPath $stage -Destination $Export
    Say ('EXPORT OK: '+$Export)
}
function BuildRelease {
    PrepareWindowsBuild
    $pubFile=Join-Path $Root 'config\public_key.txt'; if(-not (Test-Path -LiteralPath $pubFile) -or ([IO.File]::ReadAllText($pubFile).Trim().Length -ne 518)){InitKeys}
    PublicKeyReady;Say '[2] Build VST3 x64 and run regression tests'
    Configure $Build $true $false $true
    Run (Tool 'cmake.exe') @('--build',$Build,'--config','Release','--target','MelodicX_VST3','MelodicXLicenseTests','MelodicXDSPTests','MelodicXUIValueTests','--parallel','2')
    Run (Tool 'ctest.exe') @('--test-dir',$Build,'-C','Release','--output-on-failure')
    $bundle=Join-Path $Build ('MelodicX_artefacts\Release\VST3\'+$BundleName)
    $binaryDir=Join-Path $bundle 'Contents\x86_64-win'
    if(-not(Test-Path -LiteralPath $binaryDir) -or @(Get-ChildItem -LiteralPath $binaryDir -File -Filter '*.vst3').Count -ne 1){throw 'Complete Windows VST3 bundle is missing'}
    @{sourceHash=(SourceHash);bundle=$bundle;files=(FileList $bundle)}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Build 'tak-build.json') -Encoding UTF8
    [IO.File]::WriteAllText((Join-Path $LogDir 'last_windows_build.txt'),$Build)
    ExportFiles
}
function VerifyExport {
    PublicKeyReady;$file=Join-Path $Export 'manifest.json';if(-not(Test-Path -LiteralPath $file)){throw 'No verified export. Build first.'}
    $m=Get-Content -LiteralPath $file -Raw -Encoding UTF8|ConvertFrom-Json
    if($m.sourceHash -ne (SourceHash) -or $m.product -ne $Config.productId -or $m.brand -ne $Config.licenseBrand){throw 'Export is stale. Build again.'}
    foreach($item in $m.files){$p=Join-Path $Export $item.path;if(-not(Test-Path -LiteralPath $p -PathType Leaf) -or (Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash -ne $item.sha256){throw "Export mismatch: $($item.path)"}}
    if(@(Get-ChildItem -LiteralPath $Export -Recurse -File).Count -ne @($m.files).Count+1){throw 'Unexpected export files'}
    GuardCustomerFiles $Export;Say 'EXPORT CHECK PASSED'
}
function Installer {
    VerifyExport;Say '[3] Create Windows Setup.exe with Inno Setup'
    $cmd=Get-Command ISCC.exe -ErrorAction SilentlyContinue;$iscc=if($cmd){$cmd.Source}else{$null}
    foreach($base in @(${env:ProgramFiles(x86)},$env:ProgramFiles,(Join-Path $env:LOCALAPPDATA 'Programs'))){if($base){foreach($v in @('Inno Setup 6','Inno Setup 7')){$candidate=Join-Path $base ($v+'\ISCC.exe');if(-not $iscc -and(Test-Path -LiteralPath $candidate)){$iscc=$candidate}}}}
    if(-not $iscc){throw 'Install Inno Setup 6.3 or newer, then run the installer step again.'}
    $gen=Join-Path $Root 'Installer\generated';New-Item -ItemType Directory -Force -Path $gen|Out-Null
    function IssValue([string]$s){return $s.Replace('"','""')}
    $md5=[Security.Cryptography.MD5]::Create();try{$hex=([BitConverter]::ToString($md5.ComputeHash([Text.Encoding]::UTF8.GetBytes($StoreName)))).Replace('-','')}finally{$md5.Dispose()}
    $guid=$hex.Substring(0,8)+'-'+$hex.Substring(8,4)+'-'+$hex.Substring(12,4)+'-'+$hex.Substring(16,4)+'-'+$hex.Substring(20,12)
    $lines=New-Object 'System.Collections.Generic.List[string]'
    $lines.Add('#define MyAppId "{{'+$guid+'}"')
    $lines.Add('#define MyName "'+(IssValue $Config.productName)+'"')
    $lines.Add('#define MyPublisher "'+(IssValue $Config.publisher)+'"')
    $lines.Add('#define MyVersion "'+(IssValue $Config.appVersion)+'"')
    $lines.Add('#define MyBundle "'+(IssValue $BundleName)+'"')
    [IO.File]::WriteAllText((Join-Path $gen 'Config.iss'),($lines -join "`r`n"),[Text.UTF8Encoding]::new($true))
    Run $iscc @((Join-Path $Root 'Installer\Melodic-X.iss'))
    Say ('INSTALLER OK: '+(Join-Path $Root 'Output'))
}
function Menu {
    Write-Host 'Melodic X - OWNER BUILD TOOLS'
    Write-Host '1. Sinh key / tao Keygen cho chu so huu'
    Write-Host '2. Build VST3 + xuat file giao khach'
    Write-Host '3. Tao bo cai Setup.exe tu ban xuat da kiem tra'
    Write-Host '4. Lam tat ca (1 -> 2 -> 3)'
    Write-Host '5. Kiem tra goi xuat'
    Write-Host '6. Mo ThuongHieu.json'
    switch(Read-Host 'Chon muc'){'1'{InitKeys}'2'{BuildRelease}'3'{Installer}'4'{InitKeys;BuildRelease;Installer}'5'{VerifyExport}'6'{Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $Root 'ThuongHieu.json')+'"')}default{Write-Host 'Khong thay doi gi.'}}
}
try {
    switch($Action){'InitKeys'{InitKeys}'Build'{BuildRelease}'Export'{ExportFiles}'Installer'{Installer}'All'{InitKeys;BuildRelease;Installer}'Check'{VerifyExport}'Config'{Start-Process notepad.exe -ArgumentList ('"'+(Join-Path $Root 'ThuongHieu.json')+'"')}'Menu'{Menu}}
}catch{Say ('ERROR: '+$_.Exception.Message);exit 1}
