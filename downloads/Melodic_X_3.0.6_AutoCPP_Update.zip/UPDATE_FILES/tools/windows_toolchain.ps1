# Windows PowerShell 5.1-compatible discovery. No installation or global PATH changes.
function Invoke-MelodicXDiscoveryQuery([string]$Exe,[string[]]$Arguments) {
    $previousEncoding=[Console]::OutputEncoding
    try {
        [Console]::OutputEncoding=[Text.UTF8Encoding]::new($false)
        $text=(& $Exe @Arguments 2>&1 | Out-String)
        $result=$LASTEXITCODE
    } finally {[Console]::OutputEncoding=$previousEncoding}
    if($result -ne 0){throw "Discovery command failed ($result): $Exe $($Arguments -join ' ')`n$text"}
    return $text
}
function Find-MelodicXVsWhere {
    $command=Get-Command vswhere.exe -ErrorAction SilentlyContinue
    if($command){return $command.Source}
    foreach($base in @(${env:ProgramFiles(x86)},$env:ProgramFiles)) {
        if(-not $base){continue}
        $candidate=Join-Path $base 'Microsoft Visual Studio/Installer/vswhere.exe'
        if(Test-Path -LiteralPath $candidate -PathType Leaf){return $candidate}
    }
    return $null
}
function Select-MelodicXVisualStudio($Instances,[string[]]$Generators) {
    foreach($instance in @($Instances | Sort-Object {[version]$_.installationVersion} -Descending)) {
        if(($null -ne $instance.isComplete -and -not $instance.isComplete) -or
           $instance.isRebootRequired){continue}
        $major=([version]$instance.installationVersion).Major
        if($major -lt 16){continue} # JUCE in this project requires VS 2019 or newer.
        $generator=@($Generators | Where-Object {$_ -match ('^Visual Studio '+$major+' ')})
        if($generator.Count -eq 0){continue}
        $versionFile=Join-Path $instance.installationPath 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt'
        if(-not(Test-Path -LiteralPath $versionFile -PathType Leaf)){continue}
        $version=[IO.File]::ReadAllText($versionFile).Trim()
        if($version -notmatch '^\d+\.\d+\.\d+(\.\d+)?$'){continue}
        $compiler=$null
        foreach($hostTools in @('Hostx64','Hostarm64','Hostx86')) {
            $candidate=Join-Path $instance.installationPath ('VC/Tools/MSVC/'+$version+'/bin/'+$hostTools+'/x64/cl.exe')
            if(Test-Path -LiteralPath $candidate -PathType Leaf){$compiler=$candidate;break}
        }
        if(-not $compiler){continue}
        return [pscustomobject]@{Generator=$generator[0];Instance=[string]$instance.installationPath;
            Version=[string]$instance.installationVersion;Compiler=$compiler;VisualStudio=$true}
    }
    return $null
}
function Find-MelodicXWindowsToolchain([string]$CMake) {
    $capabilities=Invoke-MelodicXDiscoveryQuery $CMake @('-E','capabilities') | ConvertFrom-Json
    $generators=@($capabilities.generators | ForEach-Object {$_.name})
    $instances=@();$vswhere=Find-MelodicXVsWhere
    if($vswhere) {
        # -products * includes Build Tools; -requires excludes C#/empty VS installs.
        $json=Invoke-MelodicXDiscoveryQuery $vswhere @('-all','-prerelease','-products','*',
            '-requires','Microsoft.VisualStudio.Component.VC.Tools.x86.x64','-format','json','-utf8')
        $instances=@($json | ConvertFrom-Json)
        $selected=Select-MelodicXVisualStudio $instances $generators
        if($selected){return $selected}
    }
    # A configured x64 developer shell may provide MSVC without vswhere.
    # Do not guess an x86 compiler into a plugin intended for Cubase x64.
    $cl=Get-Command cl.exe -ErrorAction SilentlyContinue
    if($cl -and ($env:VSCMD_ARG_TGT_ARCH -eq 'x64' -or $cl.Source -match '[/\\]Host[^/\\]+[/\\]x64[/\\]cl\.exe$')) {
        $ninja=Get-Command ninja.exe -ErrorAction SilentlyContinue
        if($ninja -and $generators -contains 'Ninja Multi-Config') {
            return [pscustomobject]@{Generator='Ninja Multi-Config';Instance='';Version='developer shell';
                Compiler=$cl.Source;VisualStudio=$false;MakeProgram=$ninja.Source}
        }
        $nmake=Get-Command nmake.exe -ErrorAction SilentlyContinue
        if($nmake -and $generators -contains 'NMake Makefiles') {
            return [pscustomobject]@{Generator='NMake Makefiles';Instance='';Version='developer shell';
                Compiler=$cl.Source;VisualStudio=$false;MakeProgram=$nmake.Source}
        }
    }
    $usable2026=Select-MelodicXVisualStudio $instances @('Visual Studio 18 2026')
    if($usable2026 -and -not @($generators | Where-Object {$_ -match '^Visual Studio 18 '}).Count) {
        throw 'Found Visual Studio 2026, but this CMake cannot use it. Update CMake to 4.2 or newer, then run this build again.'
    }
    throw ('Khong tim thay MSVC C++ x64 phu hop. Can Visual Studio/Build Tools 2019, 2022 hoac 2026 '+
        'voi workload Desktop development with C++, cong cu MSVC x64/x86 va Windows 10/11 SDK. '+
        'Neu vua cai, hoan tat/cap nhat bo cai roi mo lai file BAT. Khong can cai rieng VS 2022 neu da co ban khac phu hop.')
}
function ConvertTo-MelodicXComparablePath([string]$Path) {
    return $Path.Replace('\','/').TrimEnd('/').ToLowerInvariant()
}
function Test-MelodicXCompatibleBuild([string]$Directory,$Toolchain,[string]$Source) {
    $cache=Join-Path $Directory 'CMakeCache.txt'
    if(-not(Test-Path -LiteralPath $cache -PathType Leaf)){return $true}
    $entries=@{}
    foreach($line in [IO.File]::ReadAllLines($cache)) {
        if($line -match '^(CMAKE_GENERATOR|CMAKE_GENERATOR_INSTANCE|CMAKE_GENERATOR_PLATFORM|CMAKE_HOME_DIRECTORY|CMAKE_CXX_COMPILER):[^=]+=(.*)$') {
            $entries[$matches[1]]=$matches[2]
        }
    }
    if($entries.CMAKE_GENERATOR -and $entries.CMAKE_GENERATOR -ne $Toolchain.Generator){return $false}
    if($entries.CMAKE_HOME_DIRECTORY -and
       (ConvertTo-MelodicXComparablePath $entries.CMAKE_HOME_DIRECTORY) -ne (ConvertTo-MelodicXComparablePath $Source)){return $false}
    if($entries.CMAKE_CXX_COMPILER -and $Toolchain.Compiler -and
       (ConvertTo-MelodicXComparablePath $entries.CMAKE_CXX_COMPILER) -ne (ConvertTo-MelodicXComparablePath $Toolchain.Compiler)){return $false}
    if($Toolchain.VisualStudio) {
        if($entries.CMAKE_GENERATOR_PLATFORM -and $entries.CMAKE_GENERATOR_PLATFORM -ne 'x64'){return $false}
        if($entries.CMAKE_GENERATOR_INSTANCE -and
           (ConvertTo-MelodicXComparablePath $entries.CMAKE_GENERATOR_INSTANCE) -ne (ConvertTo-MelodicXComparablePath $Toolchain.Instance)){return $false}
    }
    return $true
}
function Resolve-MelodicXBuildDirectory([string]$Directory,$Toolchain,[string]$Source) {
    if(Test-MelodicXCompatibleBuild $Directory $Toolchain $Source){return $Directory}
    $sha=[Security.Cryptography.SHA256]::Create()
    try {$digest=([BitConverter]::ToString($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes(
        $Toolchain.Generator+'|'+$Toolchain.Instance+'|'+$Source)))).Replace('-','').Substring(0,10).ToLowerInvariant()}
    finally {$sha.Dispose()}
    $candidate=$Directory+'_auto_'+$digest
    for($n=0;-not(Test-MelodicXCompatibleBuild $candidate $Toolchain $Source);++$n){$candidate=$Directory+'_auto_'+$digest+'_'+($n+1)}
    return $candidate
}
function New-MelodicXConfigureArguments([string]$Source,[string]$Directory,$Toolchain,[bool]$Plugin,[bool]$Keygen,[bool]$Tests) {
    $arguments=@('-S',$Source,'-B',$Directory,'-G',$Toolchain.Generator)
    if($Toolchain.VisualStudio){$arguments+=@('-A','x64',('-DCMAKE_GENERATOR_INSTANCE='+$Toolchain.Instance))}
    else {$arguments+=@('-DCMAKE_BUILD_TYPE=Release',('-DCMAKE_MAKE_PROGRAM='+$Toolchain.MakeProgram))}
    $arguments+=@(('-DMELODICX_BUILD_PLUGIN='+@('OFF','ON')[[int]$Plugin]),
        ('-DTAK_BUILD_PLUGIN='+@('OFF','ON')[[int]$Plugin]),
        ('-DTAK_BUILD_KEYGEN='+@('OFF','ON')[[int]$Keygen]),('-DBUILD_TESTING='+@('OFF','ON')[[int]$Tests]))
    return $arguments
}
