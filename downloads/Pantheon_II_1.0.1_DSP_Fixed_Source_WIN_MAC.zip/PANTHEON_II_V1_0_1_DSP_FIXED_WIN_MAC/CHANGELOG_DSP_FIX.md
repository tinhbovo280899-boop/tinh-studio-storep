# Pantheon II 1.0.1

- Giữ topology sáu nhánh và ma trận output của gói nguồn, thay bộ nhớ bằng các bank cố định cấp phát trong prepare. Thay đổi Size/Spread/Time không di chuyển vùng nhớ đang phát âm.
- Bộ nhớ lọc tách khỏi tap không gian. Gain feedback tính theo thời gian vòng lặp và RT60, luôn dưới unity; Bass Boost là tỷ lệ thời gian decay ở tần số thấp (x), không tăng gain không giới hạn trong vòng lặp.
- Đưa dB/Hz/ms vật lý từ APVTS vào DSP, sửa Level -36..+6 dB, Input -24..+12 dB, Damping, Bass Frequency và Echo Time.
- Pre-delay độc lập áp dụng cho toàn đường wet. Delay là thời gian của nhánh Regen; Echo Time là delay riêng của echo sau khuếch tán đầu vào.
- Áp dụng đủ mọi bước thay đổi Echo Time; bỏ ngưỡng làm mất các bước nhỏ. Tap và hệ số/gain thay đổi mượt trong khoảng 30 ms.
- Host bypass fade 5 ms và vẫn chạy tank; reset/prepare xóa trạng thái. Tail phụ thuộc RT60, bass decay, pre-delay/echo và Regen.
- RT60 là thời gian decay danh nghĩa của tank; damping và tỷ lệ bass làm decay khác nhau theo tần số. Chưa hiệu chuẩn tương đương plugin Lexicon gốc.

Xem README và VALIDATION cho cách build, dữ liệu đo và giới hạn kiểm tra.
