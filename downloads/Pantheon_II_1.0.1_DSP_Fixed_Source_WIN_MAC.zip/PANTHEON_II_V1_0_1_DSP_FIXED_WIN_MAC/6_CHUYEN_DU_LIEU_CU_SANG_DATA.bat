@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
echo Chuyen bai da luu va cau hinh cu vao Data canh EXE.
echo Cac file Data bi thay the se duoc sao luu trong Data\Backups.
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Data\Tools\chuyen_du_lieu_cu.ps1" -DataDirectory "%~dp0Data"
set "DCTC_RC=%errorlevel%"
pause
exit /b %DCTC_RC%
