﻿param([string]$Source=(Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference='Stop'
$checks=0
function Assert([bool]$Condition,[string]$Message){$script:checks++;if(-not $Condition){throw $Message}}
function MustReject([scriptblock]$Work,[string]$Pattern){
    $message='';try{& $Work | Out-Null}catch{$message=$_.Exception.Message}
    Assert ($message -match $Pattern) ('Expected error matching '+$Pattern+', got: '+$message)
}
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('melodicx-toolchain-'+[guid]::NewGuid().ToString('N'))
try {
    . (Join-Path $Source 'tools/windows_toolchain.ps1')
    foreach($file in @('tools/phat_hanh.ps1','tools/windows_toolchain.ps1')) {
        $tokens=$null;$errors=$null
        [void][System.Management.Automation.Language.Parser]::ParseFile((Join-Path $Source $file),[ref]$tokens,[ref]$errors)
        Assert ($errors.Count -eq 0) ('Syntax: '+$file)
    }
    function FixtureVS([int]$Major,[string]$Version,[bool]$Complete=$true,[bool]$Compiler=$true) {
        $path=Join-Path $fixture ('Visual Studio '+$Major+' '+$Version)
        $versionFile=Join-Path $path 'VC/Auxiliary/Build/Microsoft.VCToolsVersion.default.txt'
        New-Item -ItemType Directory -Force -Path (Split-Path $versionFile)|Out-Null
        [IO.File]::WriteAllText($versionFile,'14.44.35207')
        if($Compiler){
            $cl=Join-Path $path 'VC/Tools/MSVC/14.44.35207/bin/Hostx64/x64/cl.exe'
            New-Item -ItemType Directory -Force -Path (Split-Path $cl)|Out-Null
            [IO.File]::WriteAllText($cl,'fixture: not executed')
        }
        return [pscustomobject]@{installationPath=$path;installationVersion=$Version;isComplete=$Complete;isRebootRequired=$false}
    }
    $vs19=FixtureVS 16 '16.11.0.0'
    $vs22=FixtureVS 17 '17.14.0.0'
    $vs26=FixtureVS 18 '18.0.0.0'
    $generators=@('Visual Studio 16 2019','Visual Studio 17 2022','Visual Studio 18 2026')
    $chosen=Select-AudioFxVisualStudio @($vs22,$vs26,$vs19) $generators
    Assert ($chosen.Generator -eq 'Visual Studio 18 2026') 'Newest supported installed C++'
    Assert ($chosen.Instance -eq $vs26.installationPath) 'Pin exact VS instance'
    Assert (Test-Path -LiteralPath $chosen.Compiler) 'Check actual x64 compiler'
    $chosen=Select-AudioFxVisualStudio @($vs26,$vs22,$vs19) $generators[0..1]
    Assert ($chosen.Generator -eq 'Visual Studio 17 2022') 'Older CMake uses supported installed VS'
    Assert ((Select-AudioFxVisualStudio @($vs19) $generators).Generator -eq 'Visual Studio 16 2019') 'VS 2019 is usable'
    Assert ($null -eq (Select-AudioFxVisualStudio @() $generators)) 'Empty detection is not a compiler'
    $broken=FixtureVS 18 '18.1.0.0' $true $false
    $incomplete=FixtureVS 18 '18.2.0.0' $false
    Assert ((Select-AudioFxVisualStudio @($broken,$incomplete,$vs22) $generators).Instance -eq $vs22.installationPath) 'Skip missing compiler/incomplete install'
    $reboot=FixtureVS 18 '18.3.0.0';$reboot.isRebootRequired=$true
    Assert ($null -eq (Select-AudioFxVisualStudio @($reboot) $generators)) 'Skip pending reboot'
    $buildTools=FixtureVS 18 '18.4.0.0';$buildTools|Add-Member -NotePropertyName isLaunchable -NotePropertyValue $false
    Assert ((Select-AudioFxVisualStudio @($buildTools) $generators).Instance -eq $buildTools.installationPath) 'Build Tools need not launch an IDE'

    $project=Join-Path $fixture 'project with spaces'
    $build=Join-Path $project 'build_keygen_win_x64'
    New-Item -ItemType Directory -Force -Path $build|Out-Null
    $toolchain=Select-AudioFxVisualStudio @($vs26) $generators
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain $project) -eq $build) 'Fresh build keeps expected path'
    $cache=Join-Path $build 'CMakeCache.txt'
    [IO.File]::WriteAllText($cache,"CMAKE_GENERATOR:INTERNAL=Visual Studio 17 2022`nCMAKE_HOME_DIRECTORY:INTERNAL=$project`n")
    $old=[IO.File]::ReadAllBytes($cache)
    $resolved=Resolve-AudioFxBuildDirectory $build $toolchain $project
    Assert ($resolved -ne $build) 'Generator change uses sibling build'
    Assert ($resolved -eq (Resolve-AudioFxBuildDirectory $build $toolchain $project)) 'New build path is repeatable'
    Assert ([Convert]::ToBase64String($old) -eq [Convert]::ToBase64String([IO.File]::ReadAllBytes($cache))) 'Old cache not overwritten/deleted'
    [IO.File]::WriteAllText($cache,"CMAKE_GENERATOR:INTERNAL=Visual Studio 18 2026`nCMAKE_GENERATOR_PLATFORM:INTERNAL=x64`nCMAKE_GENERATOR_INSTANCE:INTERNAL=$($vs26.installationPath)`nCMAKE_HOME_DIRECTORY:INTERNAL=$project`n")
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain $project) -eq $build) 'Matching cache reused'
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain ($project+'-moved')) -ne $build) 'Moved source uses new build'
    [IO.File]::AppendAllText($cache,"CMAKE_GENERATOR_INSTANCE:INTERNAL=$($vs22.installationPath)`n")
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain $project) -ne $build) 'Changed VS instance isolated'
    [IO.File]::WriteAllText($cache,"CMAKE_GENERATOR:INTERNAL=Visual Studio 18 2026`nCMAKE_GENERATOR_PLATFORM:INTERNAL=Win32`n")
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain $project) -ne $build) 'Reject x86 cache for x64 plugin'
    [IO.File]::WriteAllText($cache,"CMAKE_GENERATOR:INTERNAL=Visual Studio 18 2026`nCMAKE_GENERATOR_PLATFORM:INTERNAL=x64`n")
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain $project) -eq $build) 'Failed initial configure without instance can recover'
    [IO.File]::AppendAllText($cache,"CMAKE_CXX_COMPILER:FILEPATH=$($toolchain.Compiler)`n")
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain $project) -eq $build) 'Matching cached compiler reused'
    [IO.File]::AppendAllText($cache,"CMAKE_CXX_COMPILER:FILEPATH=old/compiler/cl.exe`n")
    Assert ((Resolve-AudioFxBuildDirectory $build $toolchain $project) -ne $build) 'Changed compiler/toolset uses new build'

    $arguments=New-AudioFxConfigureArguments $project $resolved $toolchain $false $true $false
    Assert ($arguments -contains '-DAUDIOFX_BUILD_PLUGIN=OFF') 'Melodic X plugin option disabled for owner keygen'
    Assert ($arguments -contains 'Visual Studio 18 2026') 'Generator argument detected'
    Assert ($arguments -contains ('-DCMAKE_GENERATOR_INSTANCE='+$vs26.installationPath)) 'Instance path with spaces stays one argument'
    Assert ($arguments -contains '-A' -and $arguments -contains 'x64') 'x64 platform explicit'
    Assert ($arguments -contains '-DTAK_BUILD_KEYGEN=ON' -and $arguments -contains '-DTAK_BUILD_PLUGIN=OFF' -and $arguments -contains '-DBUILD_TESTING=OFF') 'Requested build targets retained'
    $ninja=[pscustomobject]@{Generator='Ninja Multi-Config';VisualStudio=$false;MakeProgram='Ninja with spaces/ninja.exe'}
    $arguments=New-AudioFxConfigureArguments $project $resolved $ninja $true $false $true
    Assert (-not($arguments -contains '-A')) 'No Visual Studio platform switch for Ninja'
    Assert ($arguments -contains '-DCMAKE_BUILD_TYPE=Release' -and $arguments -contains '-DCMAKE_MAKE_PROGRAM=Ninja with spaces/ninja.exe') 'Developer shell build flags'

    # Exercise discovery queries without needing or pretending to execute VS on Linux.
    $script:MockGenerators=$generators;$script:MockInstances=@($vs26,$vs22)
    $script:MockCommands=@{}
    $script:queries=@()
    function Find-AudioFxVsWhere {return 'vswhere-mock'}
    function Get-Command([string]$Name,[string]$ErrorAction){return $script:MockCommands[$Name]}
    function Invoke-AudioFxDiscoveryQuery([string]$Exe,[string[]]$Arguments){
        $script:queries+=,([pscustomobject]@{Exe=$Exe;Arguments=$Arguments})
        if($Exe -eq 'cmake-mock'){return (@{generators=@($script:MockGenerators|ForEach-Object {@{name=$_}})}|ConvertTo-Json -Depth 5)}
        return (ConvertTo-Json -InputObject $script:MockInstances -Depth 5)
    }
    Assert ((Find-AudioFxWindowsToolchain 'cmake-mock').Generator -eq 'Visual Studio 18 2026') 'CMake/vswhere query path'
    Assert ($script:queries[1].Arguments -contains 'Microsoft.VisualStudio.Component.VC.Tools.x86.x64') 'Require installed C++ workload'
    Assert ($script:queries[1].Arguments -contains '*') 'Include Build Tools products'
    $script:MockGenerators=$generators[0..1];$script:MockInstances=@($vs26)
    MustReject {Find-AudioFxWindowsToolchain 'cmake-mock'} 'CMake to 4.2'
    $script:MockInstances=@()
    MustReject {Find-AudioFxWindowsToolchain 'cmake-mock'} 'Khong tim thay MSVC'
    $script:MockCommands['cl.exe']=[pscustomobject]@{Source=(Select-AudioFxVisualStudio @($vs22) $generators).Compiler}
    $script:MockCommands['ninja.exe']=[pscustomobject]@{Source='ninja with spaces/ninja.exe'}
    $script:MockGenerators=@('Ninja Multi-Config','NMake Makefiles')
    Assert ((Find-AudioFxWindowsToolchain 'cmake-mock').Generator -eq 'Ninja Multi-Config') 'Configured x64 developer shell with Ninja'
    $script:MockCommands.Remove('ninja.exe')
    $script:MockCommands['nmake.exe']=[pscustomobject]@{Source='nmake.exe'}
    Assert ((Find-AudioFxWindowsToolchain 'cmake-mock').Generator -eq 'NMake Makefiles') 'Configured x64 developer shell with NMake'

    Write-Host "WINDOWS TOOLCHAIN CHECKS PASSED: $checks checks (mock installed VS/CMake)."
}finally{if(Test-Path -LiteralPath $fixture){Remove-Item -LiteralPath $fixture -Recurse -Force}}
