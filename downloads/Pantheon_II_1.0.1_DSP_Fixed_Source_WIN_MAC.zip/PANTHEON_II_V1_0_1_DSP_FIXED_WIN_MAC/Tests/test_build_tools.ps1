﻿param([string]$Source=(Split-Path $PSScriptRoot -Parent))
$ErrorActionPreference='Stop';$checks=0
function Assert([bool]$b,[string]$why){$script:checks++;if(-not $b){throw $why}}
function Reject([scriptblock]$code){$bad=$false;try{& $code|Out-Null}catch{$bad=$true};Assert $bad 'Expected stale/modified export rejection'}
$fixture=Join-Path ([IO.Path]::GetTempPath()) ('audiofx-tools-'+[guid]::NewGuid().ToString('N'))
try {
    . (Join-Path $Source 'tools/windows_toolchain.ps1')
    foreach($file in @('tools/phat_hanh.ps1','tools/thuong_hieu.ps1','tools/sinh_key.ps1')){
        $tokens=$null;$errors=$null;$ast=[System.Management.Automation.Language.Parser]::ParseFile((Join-Path $Source $file),[ref]$tokens,[ref]$errors)
        Assert ($errors.Count -eq 0) ('Parse '+$file)
        foreach($s in $ast.EndBlock.Statements){if($s -is [System.Management.Automation.Language.FunctionDefinitionAst]){Invoke-Expression $s.Extent.Text}}
    }
    New-Item -ItemType Directory -Force -Path $fixture|Out-Null
    foreach($dir in @('Source','Source/licensing','Tests','tools','Installer')){New-Item -ItemType Directory -Force -Path (Join-Path $fixture $dir)|Out-Null}
    foreach($file in @('CMakeLists.txt','ThuongHieu.json','DongGoi.iss','HUONG_DAN_KHACH.txt','Source/AppBranding.h','Source/LicenseBrand.generated.h','Source/licensing/LicenseBrand.generated.h','Installer/ThuongHieu.iss')){
        Copy-Item -LiteralPath (Join-Path $Source $file) -Destination (Join-Path $fixture $file)
    }
    . (Join-Path $Source 'tools/brand_names.ps1')
    $Root=$fixture;$Config=Get-Content -LiteralPath (Join-Path $Root 'ThuongHieu.json') -Raw -Encoding UTF8|ConvertFrom-Json
    $configPath=Join-Path $Root 'ThuongHieu.json'
    $utf8NoBom=[Text.UTF8Encoding]::new($false);$utf8Bom=[Text.UTF8Encoding]::new($true);$encoding=$utf8NoBom;$utf8=$utf8NoBom
    $before=[regex]::Match([IO.File]::ReadAllText((Join-Path $Root 'Source/licensing/LicenseBrand.generated.h')),'publicKey\s*=\s*"([^"]*)"').Groups[1].Value
    $beforeId=[regex]::Match([IO.File]::ReadAllText((Join-Path $Root 'Source/licensing/LicenseBrand.generated.h')),'productId\s*=\s*"([^"]*)"').Groups[1].Value
    SaveBrand $Config $Root $configPath|Out-Null
    $after=[IO.File]::ReadAllText((Join-Path $Root 'Source/licensing/LicenseBrand.generated.h'))
    Assert ([regex]::Match($after,'publicKey\s*=\s*"([^"]*)"').Groups[1].Value -eq $before) 'Brand sync preserves existing public key'
    Assert ([regex]::Match($after,'productId\s*=\s*"([^"]*)"').Groups[1].Value -eq $beforeId) 'Brand sync preserves product identity'
    Assert ([IO.File]::ReadAllText((Join-Path $Root 'Source/AppBranding.h')).Contains('namespace AppBranding')) 'Correct application namespace after sync'
    $Target='PantheonII';$BundleName='PantheonII.vst3';$Export=Join-Path $Root 'XuatBan';$Receipt=Join-Path $Root 'build-receipt.json';$log=Join-Path $Root 'test.log';$utf8=[Text.UTF8Encoding]::new($false)
    $build=Join-Path $Root 'build_win_x64'
    $binary=Join-Path $build ($Target+'_artefacts/Release/VST3/'+$BundleName+'/Contents/x86_64-win/'+$BundleName)
    New-Item -ItemType Directory -Force -Path (Split-Path $binary)|Out-Null;[IO.File]::WriteAllText($binary,'fixture only, not a real binary')
    $mockTools=Join-Path $Root 'mock tools';New-Item -ItemType Directory -Force -Path $mockTools|Out-Null
    function Tool([string]$name){return (Join-Path $mockTools $name)}
    function Find-AudioFxWindowsToolchain([string]$cmake){return [pscustomobject]@{Generator='Visual Studio 18 2026';VisualStudio=$true;Instance=(Join-Path $Root 'VS instance');Compiler=(Join-Path $Root 'VS instance/cl.exe')}}
    $script:calls=@();function Run([string]$Exe,[string[]]$Arguments){$script:calls+=,([pscustomobject]@{Exe=$Exe;Arguments=$Arguments})}
    BuildPluginVST3
    Assert ($script:calls.Count -eq 3) 'Configure, build, CTest run'
    Assert ($script:calls[0].Arguments -contains 'Visual Studio 18 2026') 'Detected generator used'
    Assert ($script:calls[1].Arguments -contains ($Target+'_VST3')) 'Correct plugin target'
    Assert ($script:calls[1].Arguments -contains ($Target+'DSPTests')) 'Regression target built'
    Assert ($script:calls[1].Arguments -contains ($Target+'OwnerKeygen')) 'Owner keygen target built'
    Assert ((Split-Path $script:calls[2].Exe -Leaf) -eq 'ctest.exe') 'CTest before receipt/export'
    Assert (Test-Path -LiteralPath $Receipt) 'Receipt written'
    VerifyStaging
    $extra=Join-Path $Export 'PRIVATE_KEY.txt';[IO.File]::WriteAllText($extra,'test fixture only');Reject {VerifyStaging};Remove-Item -LiteralPath $extra
    $exportBinary=Join-Path $Export ($BundleName+'/Contents/x86_64-win/'+$BundleName)
    [IO.File]::WriteAllText($exportBinary,'changed');Reject {VerifyStaging}
    BuildPluginVST3;VerifyStaging
    [IO.File]::AppendAllText((Join-Path $Root 'Source/AppBranding.h'),'// changed');Reject {VerifyStaging}
    Write-Host "BUILD/BRANDING/EXPORT CHECKS PASSED: $checks checks (native commands mocked; real files/hashes)."
}finally{if(Test-Path -LiteralPath $fixture){Remove-Item -LiteralPath $fixture -Recurse -Force}}
