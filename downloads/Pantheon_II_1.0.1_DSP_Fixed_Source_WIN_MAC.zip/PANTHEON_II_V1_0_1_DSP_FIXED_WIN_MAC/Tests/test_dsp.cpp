#include "TPantheonDSP.h"
#include <cstdlib>
#include <iostream>
#include <vector>

static void check(bool ok,const char* reason){if(!ok){std::cerr<<"FAIL: "<<reason<<'\n';std::exit(1);}}
static tpantheon::PhoenixChamber make(int sr=48000,int mode=2,float rt=.7f,float bass=1,float pre=0,float echo=-60,float echoTime=0,float mix=100,float level=0,float input=0)
{
    tpantheon::PhoenixChamber d;d.setParameters(mode,40,rt,60,6800,bass,450,86,0,0,pre,mix,level,echo,echoTime,-60,0,input);d.prepare(sr);return d;
}
static std::vector<float> render(tpantheon::PhoenixChamber& d,int n)
{
    std::vector<float> audio(std::size_t(n),0);
    for(int i=0;i<n;++i){float l=0,r=0;d.processStereoSample(i==0?.1f:0,0,l,r);audio[std::size_t(i)]=l;check(std::isfinite(l)&&std::isfinite(r),"finite stereo output");}
    return audio;
}
static void levelAndInput()
{
    for(float level:{-36.f,-35.9f,-18.f,0.f,6.f})
    {
        auto d=make(48000,2,.7f,1,0,-60,0,0,level);float l=0,r=0;d.processStereoSample(.1f,.1f,l,r);
        const double actual=20*std::log10(l/.1);check(std::abs(actual-level)<.001,"physical dB mapping, including minimum Level");
    }
    auto a=make(48000,2,.7f,1,0,-60,0,100,0,7),b=make(48000,2,.7f,1,0,-60,0,100,0,12);
    auto x=render(a,48000),y=render(b,48000);double err=0,power=0;const double ratio=std::pow(10.0,5/20.0);
    for(std::size_t i=0;i<x.size();++i){double e=y[i]-ratio*x[i];err+=e*e;power+=double(y[i])*y[i];}
    check(power>0&&std::sqrt(err/power)<1e-5,"input gain +7 to +12 dB must add 5 dB, not clip at +6 dB");
    std::cout<<"PASS Level -36..+6 dB and Input +12 dB\n";
}
static void timing()
{
    auto a=make(),b=make(48000,2,.7f,1,250);auto x=render(a,144000),y=render(b,144000);
    double maxError=0,energy=0;
    for(std::size_t i=0;i<y.size();++i){const float expected=i>=12000?x[i-12000]:0;maxError=std::max(maxError,double(std::abs(y[i]-expected)));energy+=double(y[i])*y[i];}
    check(energy>1e-8&&maxError<1e-6,"250 ms pre-delay must shift the entire wet output by 12000 samples at 48 kHz");
    auto noEcho=make(),zero=make(48000,2,.7f,1,0,0,0),sixty=make(48000,2,.7f,1,0,0,60);
    auto dryTank=render(noEcho,96000),z=render(zero,96000),t=render(sixty,96000);maxError=0;energy=0;
    for(std::size_t i=0;i<t.size();++i){const double actual=t[i]-dryTank[i],expected=i>=2880?z[i-2880]-dryTank[i-2880]:0;maxError=std::max(maxError,std::abs(actual-expected));energy+=actual*actual;}
    check(energy>1e-8&&maxError<1e-6,"Echo Time 60 ms must add 2880 samples, not 120 ms");
    auto slow=make(48000,2,.7f,1,0,0),fast=make(48000,2,.7f,1,0,0);
    for(int ms=1;ms<=60;++ms)slow.setParameters(2,40,.7f,60,6800,1,450,86,0,0,0,100,0,0,float(ms),-60,0,0);
    fast.setParameters(2,40,.7f,60,6800,1,450,86,0,0,0,100,0,0,60,-60,0,0);slow.reset();fast.reset();
    check(render(slow,96000)==render(fast,96000),"small Echo Time automation steps must accumulate to the same final setting");
    std::cout<<"PASS pre-delay, echo milliseconds and 1 ms automation steps\n";
}
static void decayAndRates()
{
    for(int sr:{44100,48000,96000,192000})for(int type=0;type<6;++type)
    {
        auto d=make(sr,type,.7f,2.5f);double early=0,late=0,peak=0;
        for(int i=0;i<8*sr;++i){float l=0,r=0;d.processStereoSample(i==0?.1f:0,0,l,r);check(std::isfinite(l)&&std::isfinite(r),"finite tank output");peak=std::max(peak,double(std::abs(l)));if(i<sr)early+=double(l)*l;if(i>=7*sr)late+=double(l)*l;}
        check(early>0&&peak<.2&&std::sqrt(late/sr)<1e-7,"all six modes must decay without self-oscillation at maximum Bass Boost");
    }
    // Longest RT60 and bass multiplier, plus maximum input regen and times.
    auto d=make(48000,0,5,2.5f,250,0,600);
    d.setParameters(0,76,5,100,20000,2.5f,2500,100,100,250,250,100,0,0,600,0,600,0);d.reset();
    check(d.getTailSeconds()>25,"tail must cover bass decay, pre-delay, regen and echoes");
    double early=0,late=0;
    for(int i=0;i<40*48000;++i){float l=0,r=0;d.processStereoSample(i==0?.01f:0,0,l,r);check(std::isfinite(l)&&std::abs(l)<1,"maximum controls must stay finite and bounded after a quiet impulse");if(i<48000)early+=double(l)*l;if(i>=39*48000)late+=double(l)*l;}
    check(early>0&&late<early*1e-5,"maximum RT60/Bass/Regen must still decay");
    std::cout<<"PASS 6 modes at 44.1/48/96/192 kHz and maximum-parameter 40 second tail\n";
}
static void automationAndReset()
{
    auto d=make();
    for(int block=0;block<200;++block)
    {
        const bool high=block%2;
        d.setParameters(block%6,high?76:4,high?5:.1f,high?100:0,high?20000:500,high?2.5f:.1f,high?2500:60,
            high?100:0,high?100:0,high?250:0,high?250:0,100,0,high?0:-60,high?600:0,high?0:-60,high?600:0,0);
        for(int i=0;i<257;++i){float l=0,r=0;d.processStereoSample(.02f*std::sin(float(block*257+i)*.07f),0,l,r);check(std::isfinite(l)&&std::isfinite(r),"automation through all geometry extremes");}
    }
    d.reset();for(int i=0;i<48000;++i){float l=0,r=0;d.processStereoSample(0,0,l,r);check(l==0&&r==0,"reset and subsequent silence must remain exact zero");}
    std::cout<<"PASS geometry automation and reset\n";
}
int main(){levelAndInput();timing();decayAndRates();automationAndReset();std::cout<<"ALL PANTHEON DSP CHECKS PASSED (Release checks enabled).\n";}
