@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\phat_hanh.ps1" -Root "%~dp0." -Mode Installer
set "DCTC_RC=%errorlevel%"
echo.
if not "%DCTC_RC%"=="0" echo [LOI] Xem NHAT_KY_INSTALLER.txt trong thu muc nay.
pause
exit /b %DCTC_RC%
