@echo off
setlocal DisableDelayedExpansion
chcp 65001 >nul
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\thuong_hieu.ps1" -Root "%~dp0."
set "DCTC_RC=%errorlevel%"
pause
exit /b %DCTC_RC%
