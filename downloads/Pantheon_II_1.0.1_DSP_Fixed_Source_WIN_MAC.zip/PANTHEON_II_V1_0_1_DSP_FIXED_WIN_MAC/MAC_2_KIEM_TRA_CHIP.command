#!/bin/bash
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
bash "$ROOT/tools/mac.sh" Check
status=$?
if [[ -t 0 ]];then printf "\nPress Return to close...";read -r _close;fi
exit "$status"
