@echo off
setlocal DisableDelayedExpansion
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\sinh_key.ps1" -Root "%~dp0."
set "OWNER_RC=%errorlevel%"
pause
exit /b %OWNER_RC%
