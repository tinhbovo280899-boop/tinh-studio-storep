#include "TPantheonProcessor.h"
#include "TPantheonEditor.h"

namespace tpantheon
{

// Exact 35 Factory Presets extracted from unpacked PantheonII.dll (0x51078..0x51a08)
// Ordered with Short Vocal / Room / Plate / Ambience presets first for instant vocal mixing!
static const std::vector<PantheonPreset> kPresets = {
    { "01. Lead Vocal Room (Vang Ngan Vocal Chuan)", 2, {{ 0.4f, 0.5385f, 0.3526f, 0.60f, 0.6566f, 0.00f,  0.1887f, 0.86f, 0.28f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.45f,   0.1033f, 0.45f   }} },
    { "02. Vocal Plate (Lexicon Short Plate)",       3, {{ 0.6f, 0.3750f, 0.2382f, 1.00f, 0.7303f, 0.075f, 0.4042f, 1.00f, 0.25f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.35f,   0.1600f, 0.35f   }} },
    { "03. Hit Vocal (Vang Ngan Day Giong)",         5, {{ 1.0f, 1.0000f, 0.1804f, 0.24f, 0.8040f, 0.00f,  0.1816f, 1.00f, 0.30f, 0.0083f, 0.4934f, 1.0f, 1.0f, 0.55f,   0.0575f, 0.55f   }} },
    { "04. Vocal Spread (Mo Rong Stereo Vocal)",     5, {{ 1.0f, 1.0000f, 0.1404f, 0.30f, 0.7940f, 0.10f,  0.3198f, 0.55f, 0.30f, 0.0092f, 0.3334f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "05. Vocal Slap (Slapback Chamber)",           5, {{ 1.0f, 1.0000f, 0.1804f, 0.32f, 0.8040f, 0.525f, 0.1711f, 1.00f, 0.28f, 0.0083f, 0.4934f, 1.0f, 1.0f, 0.60f,   0.0575f, 0.60f   }} },
    { "06. Wide Vox (Vang Ngan Stereo Rong)",        5, {{ 1.0f, 0.3889f, 0.2604f, 0.04f, 1.0000f, 0.30f,  1.0000f, 0.17f, 0.32f, 0.0083f, 0.00f,   1.0f, 1.0f, 0.45f,   0.0125f, 0.45f   }} },
    { "07. Small Plate (Plate Ngan Sach)",           3, {{ 0.6f, 0.3125f, 0.1782f, 0.48f, 0.7603f, 0.25f,  0.8472f, 1.00f, 0.32f, 0.0233f, 0.00f,   1.0f, 1.0f, 0.35f,   0.1600f, 0.35f   }} },
    { "08. Small Chamber (Buong Vang Ngan)",         1, {{ 0.2f, 0.0333f, 0.3190f, 0.00f, 0.6878f, 0.80f,  0.3900f, 0.80f, 0.30f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "09. Bright Ambience (Khong Gian Sang)",       4, {{ 0.8f, 0.1250f, 0.3470f, 1.00f, 0.7545f, 0.00f,  0.1917f, 0.25f, 0.30f, 0.0233f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "10. Slight Ambience (Ambience Sieu Ngan)",    4, {{ 0.8f, 0.2500f, 0.2870f, 1.00f, 0.7545f, 0.40f,  0.8468f, 0.25f, 0.28f, 0.0233f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "11. Mid Ambience (Khong Gian Trung)",         4, {{ 0.8f, 1.0000f, 0.0400f, 1.00f, 0.1945f, 0.00f,  0.1716f, 0.25f, 0.34f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.50f,   0.0480f, 0.50f   }} },
    { "12. Small Room (Phong Thu Nho)",              2, {{ 0.4f, 0.2308f, 0.3526f, 0.00f, 0.5066f, 0.25f,  0.3198f, 0.61f, 0.32f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "13. Medium Room (Phong Vua Am Ap)",           2, {{ 0.4f, 0.4615f, 0.3426f, 0.60f, 0.5066f, 0.25f,  0.3198f, 0.86f, 0.34f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "14. Large Room (Phong Lon)",                  2, {{ 0.4f, 0.5385f, 0.3726f, 0.60f, 0.6566f, 0.25f,  0.3198f, 0.86f, 0.36f, 0.1333f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "15. Tiled Room (Phong Gach Sang)",            2, {{ 0.4f, 0.2308f, 0.3426f, 0.30f, 0.7166f, 0.075f, 0.2063f, 0.30f, 0.23f, 0.0167f, 0.3333f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "16. Guitar Room (Phong Acoustic/Guitar)",     2, {{ 0.4f, 0.2308f, 0.3526f, 0.00f, 0.5466f, 0.25f,  0.3299f, 0.47f, 0.35f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "17. Medium Plate (Plate Trung Binh)",         3, {{ 0.6f, 0.3750f, 0.2882f, 0.79f, 0.7303f, 0.30f,  0.8190f, 1.00f, 0.34f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.45f,   0.1600f, 0.45f   }} },
    { "18. Large Plate (Plate Dai Muot)",            5, {{ 1.0f, 0.3333f, 0.3504f, 0.79f, 0.7240f, 0.30f,  0.8150f, 1.00f, 0.325f,0.0083f, 0.00f,   1.0f, 1.0f, 0.45f,   0.0167f, 0.45f   }} },
    { "19. Soft Chamber (Buong Vang Mem)",           1, {{ 0.2f, 0.7000f, 0.4290f, 0.22f, 0.5178f, 0.40f,  0.2826f, 0.65f, 0.35f, 0.0367f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "20. Wide Chamber (Buong Vang Rong)",          1, {{ 0.2f, 0.4667f, 0.3190f, 1.00f, 0.6378f, 0.48f,  0.3598f, 0.52f, 0.38f, 0.2033f, 0.3300f, 1.0f, 1.0f, 0.40f,   0.0800f, 0.40f   }} },
    { "21. Double Chamber (Buong Vang Kep)",         1, {{ 0.2f, 0.0333f, 0.3190f, 0.00f, 0.6878f, 0.80f,  0.3900f, 0.80f, 0.35f, 0.0267f, 0.00f,   1.0f, 1.0f, 0.40f,   0.8167f, 0.40f   }} },
    { "22. Large Chamber (Buong Vang Lon)",          1, {{ 0.2f, 0.3000f, 0.4490f, 0.16f, 0.6578f, 0.80f,  0.3599f, 0.85f, 0.36f, 0.0967f, 0.2309f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "23. Snare Chamber (Vang Ngan Snare/Drum)",    5, {{ 1.0f, 1.0000f, 0.1304f, 1.00f, 0.5840f, 0.525f, 0.1711f, 1.00f, 0.34f, 0.0083f, 0.2774f, 1.0f, 1.0f, 0.50f,   0.0000f, 0.50f   }} },
    { "24. Nonlinear 120ms (Vang Ngan Gate 120ms)",  5, {{ 1.0f, 0.1528f, 0.2600f, 0.00f, 0.7240f, 0.25f,  0.2922f, 0.76f, 0.32f, 0.0000f, 0.00f,   1.0f, 1.0f, 0.40f,   0.1000f, 0.40f   }} },
    { "25. Nonlinear 200ms (Vang Ngan Gate 200ms)",  5, {{ 1.0f, 0.3889f, 0.0500f, 0.00f, 0.7240f, 0.25f,  0.2922f, 0.68f, 0.32f, 0.0000f, 0.00f,   1.0f, 1.0f, 0.40f,   0.1667f, 0.40f   }} },
    { "26. Vocal Hall (Sanh Vocal Ballad)",          0, {{ 0.0f, 0.0000f, 0.2988f, 0.28f, 0.7679f, 0.45f,  0.3197f, 0.22f, 0.34f, 0.0092f, 0.00f,   1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "27. Small Hall (Sanh Nho)",                   0, {{ 0.0f, 0.0536f, 0.3088f, 0.65f, 0.5679f, 0.30f,  0.2397f, 0.52f, 0.34f, 0.0108f, 0.2847f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "28. Medium Hall (Sanh Vua)",                  0, {{ 0.0f, 0.1607f, 0.3288f, 0.81f, 0.5179f, 0.30f,  0.2399f, 0.60f, 0.35f, 0.0108f, 0.4600f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "29. Large Hall (Dai Sanh Lon)",               0, {{ 0.0f, 0.3214f, 0.3188f, 0.83f, 0.4679f, 0.30f,  0.2598f, 0.65f, 0.36f, 0.0117f, 0.4947f, 1.0f, 1.0f, 0.00f,   0.0000f, 0.00f   }} },
    { "30. Choir Hall (Sanh Hop Xuong)",             0, {{ 0.0f, 0.3571f, 0.2788f, 0.24f, 0.4379f, 0.375f, 0.2999f, 0.13f, 0.38f, 0.0333f, 0.2600f, 1.0f, 1.0f, 0.40f,   0.0167f, 0.40f   }} },
    { "31. Concert Hall (Hoa Nhac Giao Huong)",      0, {{ 0.0f, 0.8036f, 0.2888f, 0.15f, 0.7179f, 0.50f,  0.2899f, 1.00f, 0.38f, 0.0092f, 0.4800f, 1.0f, 1.0f, 0.45f,   0.0008f, 0.45f   }} },
    { "32. Echo Hall (Sanh Vang + Echo)",            0, {{ 0.0f, 0.8036f, 0.1888f, 0.60f, 0.4879f, 0.575f, 0.1689f, 0.87f, 0.38f, 0.0125f, 0.4500f, 1.0f, 1.0f, 0.45f,   0.5708f, 0.45f   }} },
    { "33. Deep Blue Hall (Sanh Sau Tham)",          0, {{ 0.0f, 0.3214f, 0.3488f, 0.95f, 0.6579f, 1.00f,  0.2120f, 0.70f, 0.40f, 0.0083f, 0.5347f, 1.0f, 1.0f, 0.40f,   0.0608f, 0.40f   }} },
    { "34. Stadium PA Echo (San Van Dong)",          5, {{ 1.0f, 0.2361f, 0.0000f, 1.00f, 0.7240f, 0.25f,  0.2922f, 1.00f, 0.42f, 0.1667f, 0.7372f, 1.0f, 1.0f, 0.55f,   0.0000f, 0.55f   }} }
};

} // namespace tpantheon

const std::vector<tpantheon::PantheonPreset>& TPantheonAudioProcessor::getFactoryPresets()
{
    return tpantheon::kPresets;
}

juce::AudioProcessorValueTreeState::ParameterLayout TPantheonAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    // 6 Reverb Types from PantheonII.dll (0x040342..0x040370)
    juce::StringArray reverbTypes { "Hall", "Chamber", "Room", "Plate", "Ambience", "Custom" };
    params.push_back(std::make_unique<juce::AudioParameterChoice>("reverbType", "Reverb Type", reverbTypes, 2));

    // 16 Core PhoenixChamber Parameters (0x10012360)
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "roomSize", "Room Size", juce::NormalisableRange<float>(4.0f, 76.0f, 0.5f), 20.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "rt60", "RT60", juce::NormalisableRange<float>(0.10f, 5.0f, 0.01f, 0.5f), 0.85f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "spread", "Spread", juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 60.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "damping", "Damping", juce::NormalisableRange<float>(500.0f, 20000.0f, 10.0f, 0.4f), 6800.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "bassBoost", "Bass Boost", juce::NormalisableRange<float>(0.1f, 2.5f, 0.05f), 1.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "bassFreq", "Bass Frequency", juce::NormalisableRange<float>(60.0f, 2500.0f, 5.0f, 0.45f), 450.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "diffusion", "Diffusion", juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 86.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "regen", "Regen", juce::NormalisableRange<float>(0.0f, 100.0f, 0.5f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "delay", "Delay", juce::NormalisableRange<float>(0.0f, 250.0f, 0.5f), 8.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "preDelay", "Pre-delay", juce::NormalisableRange<float>(0.0f, 250.0f, 0.5f), 12.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "mix", "Mix", juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 28.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "level", "Level", juce::NormalisableRange<float>(-36.0f, 6.0f, 0.1f), 0.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoLevelL", "Echo Level Left", juce::NormalisableRange<float>(-60.0f, 0.0f, 0.5f), -18.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoTimeL", "Echo Time Left", juce::NormalisableRange<float>(0.0f, 600.0f, 1.0f), 45.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoLevelR", "Echo Level Right", juce::NormalisableRange<float>(-60.0f, 0.0f, 0.5f), -18.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "echoTimeR", "Echo Time Right", juce::NormalisableRange<float>(0.0f, 600.0f, 1.0f), 65.0f));
    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "inputLevel", "Input Level", juce::NormalisableRange<float>(-24.0f, 12.0f, 0.1f), 0.0f));

    return { params.begin(), params.end() };
}

TPantheonAudioProcessor::TPantheonAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "TPantheonParameters", createParameterLayout()),
      licenseManager(tak::license::productConfiguration(),
                     tak::license::StorePaths::forProduct(tak::license::productConfiguration()),
                     {}, true)
{
    refreshLicenseState();
    setCurrentProgram(0);
}

void TPantheonAudioProcessor::refreshLicenseState()
{
    licenseManager.poll();
    pluginUnlocked.store(licenseManager.isAllowed(), std::memory_order_relaxed);
}

void TPantheonAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    juce::ignoreUnused(samplesPerBlock);
    updateDSPParameters();
    chamber.prepare(sampleRate);
    activeMix = 1.0f;
}

void TPantheonAudioProcessor::releaseResources()
{
    reset();
}

void TPantheonAudioProcessor::reset()
{
    chamber.reset();
    meterOutL.store(0); meterOutR.store(0);
}

bool TPantheonAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    const auto in  = layouts.getMainInputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return in == out || in == juce::AudioChannelSet::mono();
}

int TPantheonAudioProcessor::getNumPrograms()
{
    return static_cast<int>(tpantheon::kPresets.size());
}

const juce::String TPantheonAudioProcessor::getProgramName(int index)
{
    if (index >= 0 && index < static_cast<int>(tpantheon::kPresets.size()))
        return juce::String::fromUTF8(tpantheon::kPresets[static_cast<size_t>(index)].name);
    return {};
}

void TPantheonAudioProcessor::changeProgramName(int, const juce::String&) {}

void TPantheonAudioProcessor::setCurrentProgram(int index)
{
    if (index < 0 || index >= static_cast<int>(tpantheon::kPresets.size()))
        return;
    currentPresetIndex = index;
    const auto& p = tpantheon::kPresets[static_cast<size_t>(index)];

    auto setNorm = [this](const char* id, float normVal)
    {
        if (auto* param = apvts.getParameter(id))
            param->setValueNotifyingHost(juce::jlimit(0.0f, 1.0f, normVal));
    };

    if (auto* typeParam = apvts.getParameter("reverbType"))
        typeParam->setValueNotifyingHost(typeParam->convertTo0to1(static_cast<float>(p.reverbType)));

    setNorm("roomSize",   p.normVals[1]);
    setNorm("rt60",       p.normVals[2]);
    setNorm("spread",     p.normVals[3]);
    setNorm("damping",    p.normVals[4]);
    setNorm("bassBoost",  p.normVals[5]);
    setNorm("bassFreq",   p.normVals[6]);
    setNorm("diffusion",  p.normVals[7]);
    setNorm("mix",        p.normVals[8]);
    setNorm("preDelay",   p.normVals[9]);
    setNorm("delay",      p.normVals[10]);
    setNorm("level",      p.normVals[11] * 0.85f);
    setNorm("inputLevel", 0.6667f);
    setNorm("echoLevelL", p.normVals[13]);
    setNorm("echoTimeL",  p.normVals[14]);
    setNorm("echoLevelR", p.normVals[15]);
    setNorm("echoTimeR",  juce::jlimit(0.0f, 1.0f, p.normVals[14] * 1.25f));
    setNorm("regen", 0.0f);
}

void TPantheonAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    processAudioBlock(buffer, false);
}

void TPantheonAudioProcessor::processBlockBypassed(juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    processAudioBlock(buffer, true);
}

double TPantheonAudioProcessor::getTailLengthSeconds() const
{
    const auto value = [this](const char* id){return double(apvts.getRawParameterValue(id)->load());};
    const double regen = .85 * value("regen") * .01;
    const double repeat = regen > 1e-6 ? std::max(.001, value("delay")*.001) * std::ceil(std::log(1e-6)/std::log(regen)) : 0;
    return .1 + value("preDelay")*.001 + std::max(value("echoTimeL"),value("echoTimeR"))*.001
        + repeat + 2*value("rt60")*std::max(1.0,value("bassBoost"));
}

void TPantheonAudioProcessor::updateDSPParameters()
{
    const auto value = [this](const char* id){return apvts.getRawParameterValue(id)->load();};
    chamber.setParameters(int(value("reverbType")),value("roomSize"),value("rt60"),value("spread"),
        value("damping"),value("bassBoost"),value("bassFreq"),value("diffusion"),value("regen"),
        value("delay"),value("preDelay"),value("mix"),value("level"),value("echoLevelL"),
        value("echoTimeL"),value("echoLevelR"),value("echoTimeR"),value("inputLevel"));
}

void TPantheonAudioProcessor::processAudioBlock(juce::AudioBuffer<float>& buffer, bool hostBypassed)
{
    juce::ScopedNoDenormals noDenormals;
    const int numChannels = buffer.getNumChannels();
    const int numSamples  = buffer.getNumSamples();

    for (int i = getTotalNumInputChannels(); i < getTotalNumOutputChannels(); ++i)
        buffer.clear(i, 0, numSamples);

    if (numSamples <= 0 || numChannels <= 0)
        return;

    if (!licenseManager.isAllowed())
    {
        buffer.clear();
        meterOutL.store(0.0f);
        meterOutR.store(0.0f);
        return;
    }

    updateDSPParameters();

    float* chL = buffer.getWritePointer(0);
    float* chR = (numChannels > 1) ? buffer.getWritePointer(1) : chL;

    float peakL = 0.0f, peakR = 0.0f;
    const bool monoInput = getTotalNumInputChannels() == 1;
    const float fadeStep = float(1.0 / (.005 * std::max(8000.0, getSampleRate())));
    for (int i = 0; i < numSamples; ++i)
    {
        const float inL = chL[i];
        const float inR = (!monoInput && numChannels > 1) ? chR[i] : inL;
        float outL = 0.0f, outR = 0.0f;

        chamber.processStereoSample(inL, inR, outL, outR);

        outL = juce::jlimit(-1.2f, 1.2f, outL);
        outR = juce::jlimit(-1.2f, 1.2f, outR);
        activeMix += juce::jlimit(-fadeStep, fadeStep, (hostBypassed ? 0.0f : 1.0f) - activeMix);
        outL = (1-activeMix)*inL + activeMix*outL;
        outR = (1-activeMix)*inR + activeMix*outR;
        chL[i] = outL;
        if (numChannels > 1)
            chR[i] = outR;

        peakL = std::max(peakL, std::fabs(outL));
        peakR = std::max(peakR, std::fabs(outR));
    }

    meterOutL.store(peakL, std::memory_order_relaxed);
    meterOutR.store(peakR, std::memory_order_relaxed);
}

juce::AudioProcessorEditor* TPantheonAudioProcessor::createEditor()
{
    return new TPantheonAudioProcessorEditor(*this);
}

void TPantheonAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void TPantheonAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new TPantheonAudioProcessor();
}
