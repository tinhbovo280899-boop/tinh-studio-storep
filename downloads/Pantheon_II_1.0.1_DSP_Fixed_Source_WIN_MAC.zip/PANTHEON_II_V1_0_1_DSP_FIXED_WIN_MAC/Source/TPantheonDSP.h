#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <vector>

namespace tpantheon
{
struct TapDescriptor
{
    int prevTap;
    int tapIdx;
    int baseLen;
    uint32_t scaleFlag;
};

static constexpr std::array<TapDescriptor, 88> kPhoenixTapTable = {{
    {  0,  0,    0, 1 }, {  0, 80,   38, 1 },
    {  1,  1,    0, 1 }, {  1, 81,   89, 1 },
    {  2,  2,    0, 1 }, {  2, 82,   45, 1 },
    {  3,  3,    0, 1 }, {  3, 83,   74, 1 },
    {  4,  4,    0, 0 }, {  4, 22, 2395, 0 }, {  4, 23, 1273, 0 }, {  4, 24,    1, 0 },
    {  4, 25,  853, 0 }, {  4, 26,  293, 0 }, {  4, 27,    1, 0 }, {  4, 28,    1, 0 }, {  4, 29, 1400, 0 },
    {  5,  5,    0, 0 }, {  5, 30, 4497, 0 }, {  5, 31, 2197, 0 }, {  5, 32,  871, 0 },
    {  5, 33,    1, 0 }, {  5, 34,  301, 0 }, {  5, 35,    1, 0 }, {  5, 36,    1, 0 }, {  5, 37, 1400, 0 },
    {  6,  6,    0, 1 }, {  6, 38,   76, 1 }, {  6, 39,  194, 1 }, {  6, 40,  508, 1 }, {  6, 41,  627, 1 }, {  6, 42,  721, 1 },
    {  7,  7,    0, 1 }, {  7, 43,   76, 1 }, {  7, 44,  268, 1 }, {  7, 45,  507, 1 }, {  7, 46,  621, 1 }, {  7, 47,  622, 1 },
    {  8,  8,    0, 1 }, {  8, 48,  198, 1 }, {  8, 49,  345, 1 }, {  8, 50,  435, 1 }, {  8, 51,  520, 1 }, {  8, 52,  543, 1 },
    {  9,  9,    0, 1 }, {  9, 53,   21, 1 }, {  9, 54,  205, 1 }, {  9, 55,  395, 1 }, {  9, 56,  579, 1 }, {  9, 57,  793, 1 }, {  9, 58,  855, 1 },
    { 10, 10,    0, 1 }, { 10, 59,   23, 1 }, { 10, 60,  288, 1 }, { 10, 61,  454, 1 }, { 10, 62,  624, 1 },
    { 11, 11,    0, 1 }, { 11, 63,   47, 1 }, { 11, 64,   58, 1 }, { 11, 65,  326, 1 }, { 11, 66,  422, 1 },
    { 12, 12,    0, 1 }, { 12, 67,   33, 1 }, { 12, 68,  129, 1 },
    { 13, 13,    0, 1 }, { 13, 69,  166, 1 }, { 13, 70,  228, 1 },
    { 14, 14,    0, 1 }, { 14, 71,   61, 1 }, { 14, 72,  185, 1 },
    { 15, 15,    0, 1 }, { 15, 73,   59, 1 }, { 15, 74,  269, 1 },
    { 16, 16,    0, 1 }, { 16, 75,  148, 1 }, { 16, 76,  226, 1 },
    { 17, 17,    0, 1 }, { 17, 77,  110, 1 }, { 17, 78,  206, 1 }, { 17, 79,  428, 1 },
    { 18, 18,    0, 0 }, { 18, 84,    1, 0 },
    { 20, 20,    0, 0 }, { 20, 86,    1, 0 },
    { 19, 19,    0, 0 }, { 19, 85,    1, 0 },
    { 21, 21,    0, 0 }, { 21, 87,    1, 0 }
}};


// Uses the supplied six-branch tank/output topology with fixed memory banks.
// Geometry never relocates live delay histories. This is not a validated
// recreation of a proprietary Lexicon implementation.
class PhoenixChamber
{
public:
    void prepare(double sampleRate)
    {
        sr = std::max(8000.0, sampleRate);
        smoothing = -std::expm1(-1.0 / (.030 * sr));
        initFixedGains();
        std::array<int,18> capacity {};
        for (const auto& td : kPhoenixTapTable)
        {
            if (td.prevTap >= 18 || td.baseLen == 0) continue;
            const double maxDelay = (td.tapIdx == 27 || td.tapIdx == 28 || td.tapIdx == 35 || td.tapIdx == 36)
                ? .6 * sr : (td.baseLen + (td.scaleFlag ? 0.0 : 89.6)) * sr / 44100.0;
            capacity[std::size_t(td.prevTap)] = std::max(capacity[std::size_t(td.prevTap)],int(std::ceil(maxDelay))+4);
        }
        int total=0;
        for (int i=0;i<18;++i) { bank[std::size_t(i)]=total; bankCapacity[std::size_t(i)]=std::max(8,capacity[std::size_t(i)]);total+=bankCapacity[std::size_t(i)]; }
        int size=65536;while(size<total+8) size*=2;
        mask=size-1;delayBuf.assign(std::size_t(size),0.0f);
        preSize=int(std::ceil(.25*sr))+4;
        for(auto& b:preBuffer)b.assign(std::size_t(preSize),0.0f);
        prepared=true;updateTargets();reset();
    }
    void reset() noexcept
    {
        std::fill(delayBuf.begin(),delayBuf.end(),0.0f);
        for(auto& b:preBuffer)std::fill(b.begin(),b.end(),0.0f);
        lowMemory.fill(0.0);dampMemory.fill(0.0);writePos=prePos=0;
        current=target;tapDelay=targetTapDelay;
    }
    // Physical units, exactly matching the public controls. Bass Boost is a
    // low-frequency decay-time multiplier, not an unchecked gain in the loop.
    void setParameters(int type,float roomMeters,float rt60Seconds,float spreadPct,
        float dampingHz,float bassDecayRatio,float bassHz,float diffusionPct,float regenPct,
        float delayMs,float preDelayMs,float mixPct,float levelDb,float echoDbL,
        float echoMsL,float echoDbR,float echoMsR,float inputDb) noexcept
    {
        std::array<float,18> next {{float(std::clamp(type,0,5)),std::clamp(roomMeters,4.f,76.f),std::clamp(rt60Seconds,.1f,5.f),
            std::clamp(spreadPct,0.f,100.f),std::clamp(dampingHz,500.f,20000.f),std::clamp(bassDecayRatio,.1f,2.5f),
            std::clamp(bassHz,60.f,2500.f),std::clamp(diffusionPct,0.f,100.f),std::clamp(regenPct,0.f,100.f),
            std::clamp(delayMs,0.f,250.f),std::clamp(preDelayMs,0.f,250.f),std::clamp(mixPct,0.f,100.f),std::clamp(levelDb,-36.f,6.f),
            std::clamp(echoDbL,-60.f,0.f),std::clamp(echoMsL,0.f,600.f),std::clamp(echoDbR,-60.f,0.f),std::clamp(echoMsR,0.f,600.f),std::clamp(inputDb,-24.f,12.f)}};
        if(next==parameters)return;
        parameters=next;if(prepared)updateTargets();
    }
    double getTailSeconds() const noexcept
    {
        const double regen=.85*parameters[8]*.01;
        const double repeat=regen>1e-6 ? std::max(.001,parameters[9]*.001)*std::ceil(std::log(1e-6)/std::log(regen)) : 0.0;
        return .1+parameters[10]*.001+std::max(parameters[14],parameters[16])*.001+repeat+2.0*parameters[2]*std::max(1.f,parameters[5]);
    }
    void processStereoSample(float inL,float inR,float& outL,float& outR) noexcept
    {
        for(std::size_t i=0;i<current.size();++i)advance(current[i],target[i]);
        for(const auto& td:kPhoenixTapTable)if(td.prevTap<18 && td.baseLen!=0)advance(tapDelay[std::size_t(td.tapIdx)],targetTapDelay[std::size_t(td.tapIdx)]);
        const float inputGain=float(current[Input]),wetGain=float(current[Mix]),dryGain=1-wetGain;
        const float levelGain=float(current[Level]),echoGainL=float(current[EchoL]),echoGainR=float(current[EchoR]),regenGain=float(current[Regen]);
        g[5]=g[11]=regenGain;g[43]=g[45]=float(current[Diffusion])*.75f;g[44]=g[46]=float(current[Diffusion])*.65625f;
        preBuffer[0][std::size_t(prePos)]=inL;preBuffer[1][std::size_t(prePos)]=inR;
        const float preL=readPre(0,current[Pre]),preR=readPre(1,current[Pre]);
        if(++prePos==preSize)prePos=0;
        const int wp=writePos;
        auto rd=[this,wp](int tap) noexcept {
            const double d=tapDelay[std::size_t(tap)];const int whole=int(d);const float fraction=float(d-whole);
            const int start=bank[std::size_t(tapBank[std::size_t(tap)])];
            const float a=delayBuf[std::size_t((wp+start+whole)&mask)],b=delayBuf[std::size_t((wp+start+whole+1)&mask)];
            return a+fraction*(b-a);
        };
        auto wr=[this,wp](int writeTap,float value) noexcept {
            if(std::abs(value)<1e-18f)value=0;
            delayBuf[std::size_t((wp+bank[std::size_t(writeTap)])&mask)]=value;
        };
        // 1. Left Input Diffusion Chain
        float sL = preL * inputGain * (1.0f - regenGain);
        float ap0_del = rd(80);
        float ap0_in  = sL - ap0_del * g[43] + rd(27) * g[5];
        wr(0, ap0_in);
        float ap0_out = ap0_in * g[43] + ap0_del;

        float ap1_del = rd(81);
        float ap1_in  = ap0_out - ap1_del * g[44];
        wr(1, ap1_in);
        float ap1_out = ap1_in * g[44] + ap1_del;
        wr(4, ap1_out);

        // 2. Right Input Diffusion Chain
        float sR = preR * inputGain * (1.0f - regenGain);
        float ap2_del = rd(82);
        float ap2_in  = sR - ap2_del * g[45] + rd(35) * g[11];
        wr(2, ap2_in);
        float ap2_out = ap2_in * g[45] + ap2_del;

        float ap3_del = rd(83);
        float ap3_in  = ap2_out - ap3_del * g[46];
        wr(3, ap3_in);
        float ap3_out = ap3_in * g[46] + ap3_del;
        wr(5, ap3_out);

        // 3. Tank Branch A
        float sumA = rd(25) * g[4] + rd(22) * g[1] + decay(0, rd(52));
        const float bassA_out = sumA;

        float tankApA_del = rd(74);
        float tankApA_in  = bassA_out - tankApA_del * g[35];
        wr(15, tankApA_in);
        float tankApA_out = tankApA_in * g[35] + tankApA_del;
        wr(9, tankApA_out);

        // 4. Tank Branch B
        float sumB = rd(23) * g[2] + decay(1, rd(58));
        float tankApB_del = rd(76);
        float tankApB_in  = sumB + tankApB_del * g[35];
        wr(16, tankApB_in);
        float tankApB_out = tankApB_del - tankApB_in * g[35];
        wr(10, tankApB_out);

        // 5. Tank Branch C
        float sumC = rd(24) * g[3] - decay(2, rd(62));
        float tankApC_del = rd(79);
        float tankApC_in  = sumC - tankApC_del * g[35];
        wr(17, tankApC_in);
        float tankApC_out = tankApC_in * g[35] + tankApC_del;
        wr(11, tankApC_out);

        // 6. Tank Branch D
        float sumD = rd(30) * g[7] + rd(33) * g[10] + decay(3, rd(66));
        const float bassD_out = sumD;

        float tankApD_del = rd(68);
        float tankApD_in  = bassD_out + tankApD_del * g[35];
        wr(12, tankApD_in);
        float tankApD_out = tankApD_del - tankApD_in * g[35];
        wr(6, tankApD_out);

        // 7. Tank Branch E
        float sumE = rd(31) * g[8] + decay(4, rd(42));
        float tankApE_del = rd(70);
        float tankApE_in  = sumE - tankApE_del * g[35];
        wr(13, tankApE_in);
        float tankApE_out = tankApE_in * g[35] + tankApE_del;
        wr(7, tankApE_out);

        // 8. Tank Branch F
        float sumF = rd(32) * g[9] + decay(5, rd(47));
        float tankApF_del = rd(72);
        float tankApF_in  = sumF + tankApF_del * g[35];
        wr(14, tankApF_in);
        float tankApF_out = tankApF_del - tankApF_in * g[35];
        wr(8, tankApF_out);

        // 9. Left Output Multi-Tap Accumulation
        float accumL = rd(53) * g[24]
                     + rd(55) * g[26]
                     + rd(57) * g[28]
                     + rd(51) * g[23]
                     + rd(49) * g[21]
                     + rd(71) * g[38]
                     + rd(59) * g[29]
                     + rd(61) * g[31]
                     + rd(45) * g[18]
                     + rd(43) * g[16]
                     + rd(78) * g[42]
                     + rd(64) * g[33]
                     + rd(41) * g[15]
                     + rd(39) * g[13]
                     + rd(63) * g[36]
                     + rd(26) * g[0];
        float wetL = accumL * g[34] + rd(28) * echoGainL;
        outL = (inL * dryGain + wetL * wetGain) * levelGain;

        // 10. Right Output Multi-Tap Accumulation
        float accumR = rd(73) * g[39]
                     + rd(54) * g[25]
                     + rd(56) * g[27]
                     + rd(50) * g[22]
                     + rd(48) * g[20]
                     + rd(75) * g[40]
                     + rd(60) * g[30]
                     + rd(46) * g[19]
                     + rd(44) * g[17]
                     + rd(77) * g[41]
                     + rd(59) * g[32]
                     + rd(67) * g[37]
                     + rd(65) * g[34]
                     + rd(40) * g[14]
                     + rd(38) * g[12]
                     + rd(34) * g[6];
        float wetR = accumR * g[34] + rd(36) * echoGainR;
        outR = (inR * dryGain + wetR * wetGain) * levelGain;

        writePos = (wp - 1) & mask;
    }
private:
    enum {Pre,Mix,Level,EchoL,EchoR,Input,Regen,Diffusion,HighDecay,LowDecay,Damping,Bass,Count};
    void advance(double& value,double dest) const noexcept
    {
        value += smoothing*(dest-value);if(std::abs(dest-value)<1e-10)value=dest;
    }
    float readPre(int channel,double d) const noexcept
    {
        double index=prePos-d;if(index<0)index+=preSize;
        const int i=int(index),j=(i+1)%preSize;const float f=float(index-i);
        const auto& b=preBuffer[std::size_t(channel)];return b[std::size_t(i)]+f*(b[std::size_t(j)]-b[std::size_t(i)]);
    }
    float decay(int branch,float x) noexcept
    {
        auto& low=lowMemory[std::size_t(branch)];auto& damp=dampMemory[std::size_t(branch)];
        low+=current[Bass]*(double(x)-low);
        const double shelf=current[HighDecay]*x+(current[LowDecay]-current[HighDecay])*low;
        damp+=current[Damping]*(shelf-damp);
        if(std::abs(low)<1e-20)low=0;
        if(std::abs(damp)<1e-20)damp=0;
        return float(damp);
    }
    void updateTargets() noexcept
    {
        constexpr double modeSize[6]={1,.72,.55,.62,.35,1};
        const double size=(1+18*std::clamp(double((parameters[1]-4)/72)*modeSize[int(parameters[0])],.05,1.0))/19;
        for(const auto& td:kPhoenixTapTable)
        {
            if(td.prevTap>=18 || td.baseLen==0)continue;
            double d=0;
            if(td.tapIdx==27 || td.tapIdx==35)d=parameters[9]*sr*.001;
            else if(td.tapIdx==28)d=parameters[14]*sr*.001;
            else if(td.tapIdx==36)d=parameters[16]*sr*.001;
            else d=(td.scaleFlag ? td.baseLen*size : td.baseLen+parameters[3]*.896)*sr/44100;
            const bool echo=td.tapIdx==28 || td.tapIdx==36;
            targetTapDelay[std::size_t(td.tapIdx)]=std::clamp(d,echo?0.0:1.0,double(bankCapacity[std::size_t(td.prevTap)]-3));
            tapBank[std::size_t(td.tapIdx)]=td.prevTap;
        }
        // One round trip traverses six lines and six tank allpasses.
        double loop=0;for(int t:{52,58,62,66,42,47,74,76,79,68,70,72})loop+=targetTapDelay[std::size_t(t)];
        const double hop=loop/(6*sr),ln001=std::log(.001);
        target[HighDecay]=std::exp(ln001*hop/parameters[2]);
        target[LowDecay]=std::exp(ln001*hop/(parameters[2]*parameters[5]));
        target[Damping]=-std::expm1(-6.283185307179586*std::min(double(parameters[4]),sr*.45)/sr);
        target[Bass]=-std::expm1(-6.283185307179586*std::min(double(parameters[6]),sr*.45)/sr);
        target[Pre]=parameters[10]*sr*.001;target[Mix]=parameters[11]*.01;
        target[Level]=std::pow(10.0,parameters[12]/20.0);target[Input]=std::pow(10.0,parameters[17]/20.0);
        target[EchoL]=parameters[13]<=-60?0:std::pow(10.0,parameters[13]/20.0);
        target[EchoR]=parameters[15]<=-60?0:std::pow(10.0,parameters[15]/20.0);
        target[Regen]=.85*parameters[8]*.01;target[Diffusion]=parameters[7]*.01;
    }
    void initFixedGains() noexcept
    {
        g.fill(0.0f);
        g[0]  =  0.9375f;  g[1]  =  0.9375f;  g[2]  =  0.9375f;  g[3]  =  0.9375f;
        g[4]  =  0.0f;     g[5]  =  0.0f;   g[6]  =  0.9375f;  g[7]  =  0.9375f;
        g[8]  =  0.9375f;  g[9]  =  0.9375f;  g[10] =  0.0f;     g[11] =  0.0f;
        g[12] =  0.4375f;  g[13] = -0.375f;   g[14] =  0.375f;   g[15] =  0.5f;
        g[16] = -0.4375f;  g[17] = -0.375f;   g[18] = -0.375f;   g[19] =  0.5f;
        g[20] = -0.4375f;  g[21] =  0.375f;   g[22] = -0.375f;   g[23] =  0.5f;
        g[24] = -0.4375f;  g[25] = -0.4375f;  g[26] =  0.375f;   g[27] =  0.375f;
        g[28] = -0.5f;     g[29] =  0.375f;   g[30] =  0.375f;   g[31] = -0.4375f;
        g[32] = -0.375f;   g[33] =  0.0f;     g[34] =  0.40f;    g[35] =  0.5f;
        g[36] = -0.5f;     g[37] =  0.5f;     g[38] = -0.5f;     g[39] =  0.5f;
        g[40] =  0.5f;     g[41] =  0.5f;     g[42] =  0.5f;     g[43] =  0.75f;
        g[44] =  0.65625f; g[45] =  0.75f;    g[46] =  0.65625f; g[47] =  1.0f;
    }


    double sr=44100,smoothing=.001;
    bool prepared=false;
    int mask=0,writePos=0,preSize=0,prePos=0;
    std::vector<float> delayBuf;
    std::array<std::vector<float>,2> preBuffer;
    std::array<int,18> bank {},bankCapacity {};
    std::array<int,96> tapBank {};
    std::array<double,96> tapDelay {},targetTapDelay {};
    std::array<double,Count> current {},target {};
    std::array<double,6> lowMemory {},dampMemory {};
    std::array<float,48> g {};
    std::array<float,18> parameters {{2,20,.85f,60,6800,1,450,86,0,8,12,28,0,-18,45,-18,65,0}};
};
struct PantheonPreset
{
    const char* name;
    int reverbType; // 0=Hall, 1=Chamber, 2=Room, 3=Plate, 4=Ambience, 5=Custom
    std::array<float, 16> normVals; // supplied factory values; converted by the processor parameter ranges
};

} // namespace tpantheon


