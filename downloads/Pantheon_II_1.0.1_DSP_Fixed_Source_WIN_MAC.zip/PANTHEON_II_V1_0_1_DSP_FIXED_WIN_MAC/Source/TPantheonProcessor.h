#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <array>
#include <vector>
#include <atomic>
#include "AppBranding.h"
#include "licensing/LicenseManager.h"
#include "licensing/ProductConfig.h"

#include "TPantheonDSP.h"

class TPantheonAudioProcessor : public juce::AudioProcessor
{
public:
    TPantheonAudioProcessor();
    ~TPantheonAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void reset() override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return AppBranding::kAppDisplayName; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentPresetIndex; }
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    tak::license::LicenseManager& getLicenseManager() noexcept { return licenseManager; }
    bool isPluginUnlocked() const noexcept { return pluginUnlocked.load(std::memory_order_relaxed); }
    void refreshLicenseState();

    float getOutputLevelL() const noexcept { return meterOutL.load(std::memory_order_relaxed); }
    float getOutputLevelR() const noexcept { return meterOutR.load(std::memory_order_relaxed); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    static const std::vector<tpantheon::PantheonPreset>& getFactoryPresets();

private:
    void updateDSPParameters();
    void processAudioBlock(juce::AudioBuffer<float>&, bool hostBypassed);
    float activeMix = 1.0f;
    juce::AudioProcessorValueTreeState apvts;
    tak::license::LicenseManager licenseManager;
    std::atomic<bool> pluginUnlocked { true };

    tpantheon::PhoenixChamber chamber;
    int currentPresetIndex = 0;
    std::atomic<float> meterOutL { 0.0f }, meterOutR { 0.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TPantheonAudioProcessor)
};
