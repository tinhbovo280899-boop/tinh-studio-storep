// SPDX-License-Identifier: AGPL-3.0-or-later
#include "LicensePanel.h"
#include "ProductConfig.h"
namespace {juce::String vn(const char* s){return juce::String::fromUTF8(s);}}

AutoKeyLicensePanel::AutoKeyLicensePanel(Read r,std::function<void(const juce::String&)> a,std::function<void()> t,std::function<void()> c)
    :read(std::move(r)),activate(std::move(a)),trial(std::move(t)) {
    addAndMakeVisible(content);
    auto addLabel=[&](juce::Label& l,const juce::String& text,float size){l.setText(text,juce::dontSendNotification);l.setFont(juce::Font(juce::FontOptions(size)));l.setColour(juce::Label::textColourId,juce::Colour(0xfff6e6ef));content.addAndMakeVisible(l);};
    addLabel(title,vn("BẢN QUYỀN · ")+juce::String::fromUTF8(tak::product::name),20);
    addLabel(status,{},13);addLabel(machineTitle,vn("MÃ MÁY / PHIẾU KÍCH HOẠT"),11);addLabel(keyTitle,vn("DÁN KEY HOẶC NHẬP FILE .taklic"),11);
    addLabel(details,{},11);details.setJustificationType(juce::Justification::topLeft);
    addLabel(contact,juce::String::fromUTF8(tak::product::contactNote),11);
    for(auto* editor:{&request,&key}){editor->setMultiLine(true);editor->setReturnKeyStartsNewLine(true);editor->setFont(juce::Font(juce::FontOptions(11)));editor->setColour(juce::TextEditor::backgroundColourId,juce::Colour(0xff18121e));editor->setColour(juce::TextEditor::textColourId,juce::Colour(0xfff6e6ef));editor->setColour(juce::TextEditor::outlineColourId,juce::Colour(0xff574052));content.addAndMakeVisible(editor);}
    request.setReadOnly(true);key.setTextToShowWhenEmpty(vn("Dán mã bản quyền được cấp cho máy này..."),juce::Colour(0xff938290));
    auto button=[&](juce::TextButton& b,const juce::String& text){b.setButtonText(text);b.setColour(juce::TextButton::buttonColourId,juce::Colour(0xff2a1c2b));b.setColour(juce::TextButton::textColourOffId,juce::Colour(0xffffbc9c));content.addAndMakeVisible(b);};
    button(closeButton,"X");closeButton.onClick=std::move(c);
    button(copyRequest,vn("CHÉP MÃ MÁY"));copyRequest.onClick=[this]{juce::SystemClipboard::copyTextToClipboard(request.getText());};
    button(saveRequest,vn("XUẤT PHIẾU .txt"));saveRequest.onClick=[this]{exportRequest();};
    button(importKey,vn("NHẬP FILE .taklic"));importKey.onClick=[this]{chooseLicense();};
    button(activateButton,vn("KÍCH HOẠT KEY"));activateButton.onClick=[this]{activate(key.getText());};
    setSize(680,400);timerCallback();startTimerHz(4);
}
void AutoKeyLicensePanel::timerCallback(){
    const auto s=read();status.setText(s.status+(s.owner.isNotEmpty()?" · "+s.owner:juce::String()),juce::dontSendNotification);
    details.setText(s.details,juce::dontSendNotification);
    if(request.getText()!=s.request)request.setText(s.request,false);
    copyRequest.setEnabled(s.fingerprint.isNotEmpty());saveRequest.setEnabled(s.fingerprint.isNotEmpty());
}
void AutoKeyLicensePanel::paint(juce::Graphics& g){
    g.fillAll(juce::Colour(0xd8120d17));
    auto box = getLocalBounds().toFloat().reduced(16.0f);
    g.setColour(juce::Colour(0xff211923));
    g.fillRoundedRectangle(box, 14.0f);
    g.setColour(juce::Colour(0xffffbc9c));
    g.drawRoundedRectangle(box, 14.0f, 1.5f);
    g.fillRect(28.0f, 12.0f, (float)getWidth() - 56.0f, 2.0f);
}
void AutoKeyLicensePanel::resized(){
    content.setBounds(0,0,680,400);content.setTransform(juce::AffineTransform::scale(getWidth()/680.f,getHeight()/400.f));
    title.setBounds(28,20,580,30);closeButton.setBounds(618,20,35,30);status.setBounds(28,52,624,25);
    machineTitle.setBounds(28,80,260,18);keyTitle.setBounds(304,80,348,18);request.setBounds(28,102,260,112);key.setBounds(304,102,348,112);
    copyRequest.setBounds(28,224,124,34);saveRequest.setBounds(160,224,128,34);importKey.setBounds(304,224,166,34);activateButton.setBounds(480,224,172,34);
    details.setBounds(28,270,624,78);contact.setBounds(28,354,624,26);
}
void AutoKeyLicensePanel::chooseLicense(){
    chooser=std::make_unique<juce::FileChooser>(vn("Chọn file bản quyền Melodic-X"),juce::File::getSpecialLocation(juce::File::userDocumentsDirectory),"*.taklic;*.txt");
    chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles,[safe=juce::Component::SafePointer<AutoKeyLicensePanel>(this)](const juce::FileChooser& c){if(!safe)return;const auto f=c.getResult();if(f.existsAsFile()&&f.getSize()<=32768)safe->key.setText(f.loadFileAsString(),false);});
}
void AutoKeyLicensePanel::exportRequest(){
    chooser=std::make_unique<juce::FileChooser>(vn("Xuất phiếu mã máy để gửi người bán"),juce::File::getSpecialLocation(juce::File::userDocumentsDirectory).getChildFile("Melodic-X_MaMay.txt"),"*.txt");
    chooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles|juce::FileBrowserComponent::warnAboutOverwriting,[safe=juce::Component::SafePointer<AutoKeyLicensePanel>(this)](const juce::FileChooser& c){if(!safe)return;const auto f=c.getResult();if(f==juce::File())return;juce::String error;if(!tak::license::atomicWrite(f,safe->request.getText(),error))safe->details.setText(vn("Không xuất được phiếu: ")+error,juce::dontSendNotification);});
}
