// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include <juce_gui_extra/juce_gui_extra.h>
#include "LicenseManager.h"
#include <functional>

class AutoKeyLicensePanel : public juce::Component,private juce::Timer {
public:
    using Read=std::function<tak::license::Snapshot()>;
    AutoKeyLicensePanel(Read,std::function<void(const juce::String&)>,std::function<void()>,std::function<void()> close);
    ~AutoKeyLicensePanel() override {stopTimer(); chooser.reset();}
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void timerCallback() override;
    void chooseLicense();
    void exportRequest();
    Read read;
    std::function<void(const juce::String&)> activate;
    std::function<void()> trial;
    juce::Component content;
    juce::Label title,status,machineTitle,keyTitle,details,contact;
    juce::TextEditor request,key;
    juce::TextButton closeButton,copyRequest,saveRequest,importKey,activateButton;
    std::unique_ptr<juce::FileChooser> chooser;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(AutoKeyLicensePanel)
};
