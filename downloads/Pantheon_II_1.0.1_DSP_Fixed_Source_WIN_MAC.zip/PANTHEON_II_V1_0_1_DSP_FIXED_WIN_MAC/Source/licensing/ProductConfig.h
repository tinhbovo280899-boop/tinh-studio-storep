// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "LicenseCodec.h"
#include "LicenseBrand.generated.h"
namespace tak::license {
inline Configuration productConfiguration() {
    return {product::productId,product::brandId,juce::String::fromUTF8(product::name),product::publicKey,product::trialDays};
}
}
