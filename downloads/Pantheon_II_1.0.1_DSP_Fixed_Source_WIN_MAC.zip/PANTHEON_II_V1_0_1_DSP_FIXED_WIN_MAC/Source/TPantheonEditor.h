#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "TPantheonProcessor.h"
#include "licensing/LicensePanel.h"

class TPantheonLookAndFeel : public juce::LookAndFeel_V4
{
public:
    TPantheonLookAndFeel();
    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider& slider) override;
};

class TPantheonAcousticDisplay : public juce::Component
{
public:
    explicit TPantheonAcousticDisplay(TPantheonAudioProcessor& p) : processor(p) {}
    void paint(juce::Graphics& g) override;

private:
    TPantheonAudioProcessor& processor;
};

class TPantheonAudioProcessorEditor : public juce::AudioProcessorEditor,
                                      private juce::Timer
{
public:
    explicit TPantheonAudioProcessorEditor(TPantheonAudioProcessor&);
    ~TPantheonAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void updateLicenseBadge();
    void setupKnob(juce::Slider& s, juce::Label& l, const juce::String& name,
                   const juce::String& suffix, juce::Colour accentCol);

    TPantheonAudioProcessor& audioProcessor;
    TPantheonLookAndFeel customLookAndFeel;
    TPantheonAcousticDisplay acousticDisplay;
    juce::Image pantheonBgImage, pantheonLogoImage;

    // Header controls
    juce::ComboBox presetBox;
    juce::ComboBox reverbTypeBox;
    juce::TextButton licenseBtn { juce::String::fromUTF8("Dùng thử 7 ngày") };

    // 16 Rotary Knobs matching Lexicon Pantheon II
    juce::Slider roomSizeSlider, rt60Slider, preDelaySlider, spreadSlider, diffusionSlider, regenSlider;
    juce::Label  roomSizeLabel,  rt60Label,  preDelayLabel,  spreadLabel,  diffusionLabel,  regenLabel;

    juce::Slider dampingSlider, bassBoostSlider, bassFreqSlider, delaySlider;
    juce::Label  dampingLabel,  bassBoostLabel,  bassFreqLabel,  delayLabel;

    juce::Slider echoTimeLSlider, echoLevelLSlider, echoTimeRSlider, echoLevelRSlider;
    juce::Label  echoTimeLLabel,  echoLevelLLabel,  echoTimeRLabel,  echoLevelRLabel;

    juce::Slider inputLevelSlider, levelSlider, mixSlider;
    juce::Label  inputLevelLabel,  levelLabel,  mixLabel;

    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ComboAttachment  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<ComboAttachment>  reverbTypeAtt;
    std::unique_ptr<SliderAttachment> roomSizeAtt, rt60Att, preDelayAtt, spreadAtt, diffusionAtt, regenAtt;
    std::unique_ptr<SliderAttachment> dampingAtt, bassBoostAtt, bassFreqAtt, delayAtt;
    std::unique_ptr<SliderAttachment> echoTimeLAtt, echoLevelLAtt, echoTimeRAtt, echoLevelRAtt;
    std::unique_ptr<SliderAttachment> inputLevelAtt, levelAtt, mixAtt;

    AutoKeyLicensePanel licenseOverlay;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TPantheonAudioProcessorEditor)
};
