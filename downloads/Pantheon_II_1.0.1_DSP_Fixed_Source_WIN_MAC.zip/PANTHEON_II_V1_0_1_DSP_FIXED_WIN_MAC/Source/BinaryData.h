#pragma once
#include <cstddef>
namespace BinaryData {
    extern const char* pantheon_bg_png;
    const int pantheon_bg_pngSize = 141339;
    extern const char* pantheon_fader_png;
    const int pantheon_fader_pngSize = 3721;
    extern const char* pantheon_logo_png;
    const int pantheon_logo_pngSize = 11483;
}
