#pragma once

namespace AppBranding
{
    static constexpr const char* kAppDisplayName  = "PantheonII";
    static constexpr const char* kBrandWord1      = "PANTHEON";
    static constexpr const char* kBrandWord2      = "II";
    static constexpr const char* kBrandSubtitle   = "LEXICON PHOENIX CHAMBER & SHORT VOCAL REVERB";
    static constexpr const char* kSplashLine2     = "LEXICON / NT STUDIO";
    static constexpr const char* kPublisher       = "Lexicon";
    static constexpr const char* kAppVersion      = "1.0.1";
    static constexpr const char* kExeName         = "PantheonII.exe";
    static constexpr const char* kSetupName       = "Setup_PantheonII";
    static constexpr const char* kLicenseBrand    = "PANTHEONII";
    static constexpr int         kTrialDays       = 7;
    static constexpr const char* kContactPhone    = "0329575243";
    static constexpr const char* kContactNote     = "Goi / Zalo de mua ban quyen, gia han hoac ho tro ky thuat.";
    static constexpr const char* kAppDataDirName  = "PantheonII";
}
