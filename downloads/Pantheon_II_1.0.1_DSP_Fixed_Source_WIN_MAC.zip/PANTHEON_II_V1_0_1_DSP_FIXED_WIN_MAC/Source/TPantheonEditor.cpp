#include "TPantheonEditor.h"
#include "BinaryData.h"

TPantheonLookAndFeel::TPantheonLookAndFeel()
{
    setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xfff0e6ff));
    setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff100d1e));
    setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0xff382c5c));
    setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff141026));
    setColour(juce::ComboBox::textColourId, juce::Colour(0xfff4edff));
    setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff4a3b78));
    setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff141026));
    setColour(juce::PopupMenu::textColourId, juce::Colour(0xfff4edff));
    setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff7b3fe4));
}

void TPantheonLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                            float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                                            juce::Slider& slider)
{
    const float radius = static_cast<float>(juce::jmin(width / 2, height / 2)) - 5.0f;
    const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
    const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
    const float rx = centreX - radius;
    const float ry = centreY - radius;
    const float rw = radius * 2.0f;
    const float angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);

    g.setColour(juce::Colour(0xaa000000));
    g.fillEllipse(rx + 1.5f, ry + 2.5f, rw, rw);

    juce::ColourGradient bodyGrad(juce::Colour(0xff2c2448), centreX, ry,
                                  juce::Colour(0xff100c1c), centreX, ry + rw, false);
    g.setGradientFill(bodyGrad);
    g.fillEllipse(rx, ry, rw, rw);

    g.setColour(juce::Colour(0xff524280));
    g.drawEllipse(rx, ry, rw, rw, 1.4f);

    const float innerR = radius * 0.73f;
    juce::ColourGradient capGrad(juce::Colour(0xff211a38), centreX - innerR * 0.3f, centreY - innerR * 0.3f,
                                 juce::Colour(0xff0b0814), centreX + innerR * 0.5f, centreY + innerR * 0.5f, true);
    g.setGradientFill(capGrad);
    g.fillEllipse(centreX - innerR, centreY - innerR, innerR * 2.0f, innerR * 2.0f);

    juce::Path bgArc;
    bgArc.addCentredArc(centreX, centreY, radius + 2.2f, radius + 2.2f, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
    g.setColour(juce::Colour(0xff231b3a));
    g.strokePath(bgArc, juce::PathStrokeType(2.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Colour accent = slider.findColour(juce::Slider::rotarySliderFillColourId);
    if (accent.isTransparent())
        accent = juce::Colour(0xffa855f7);

    juce::Path valArc;
    valArc.addCentredArc(centreX, centreY, radius + 2.2f, radius + 2.2f, 0.0f, rotaryStartAngle, angle, true);
    g.setColour(accent);
    g.strokePath(valArc, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    juce::Path p;
    p.addRoundedRectangle(-1.4f, -innerR, 2.8f, innerR * 0.82f, 1.2f);
    g.setColour(accent.brighter(0.5f));
    g.fillPath(p, juce::AffineTransform::rotation(angle).translated(centreX, centreY));
}

void TPantheonAcousticDisplay::paint(juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();

    juce::ColourGradient bg(juce::Colour(0xff0b0818), r.getX(), r.getY(),
                            juce::Colour(0xff181132), r.getX(), r.getBottom(), false);
    g.setGradientFill(bg);
    g.fillRoundedRectangle(r, 8.0f);

    g.setColour(juce::Colour(0xff4c3880));
    g.drawRoundedRectangle(r.reduced(0.5f), 8.0f, 1.5f);

    // Perspective acoustic grid lines
    g.setColour(juce::Colour(0x229d75ff));
    for (int i = 1; i < 8; ++i)
    {
        float x = r.getX() + r.getWidth() * (static_cast<float>(i) / 8.0f);
        g.drawVerticalLine(static_cast<int>(x), r.getY() + 4.0f, r.getBottom() - 4.0f);
    }
    for (int j = 1; j < 4; ++j)
    {
        float y = r.getY() + r.getHeight() * (static_cast<float>(j) / 4.0f);
        g.drawHorizontalLine(static_cast<int>(y), r.getX() + 4.0f, r.getRight() - 4.0f);
    }

    auto& apvts = processor.getAPVTS();
    const int   revType   = static_cast<int>(apvts.getRawParameterValue("reverbType")->load());
    const float roomSize  = apvts.getRawParameterValue("roomSize")->load();
    const float rt60      = apvts.getRawParameterValue("rt60")->load();
    const float preDelay  = apvts.getRawParameterValue("preDelay")->load();
    const float damping   = apvts.getRawParameterValue("damping")->load();
    const float diffusion = apvts.getRawParameterValue("diffusion")->load();
    const float spread    = apvts.getRawParameterValue("spread")->load();
    const float echoTimeL = apvts.getRawParameterValue("echoTimeL")->load();
    const float echoTimeR = apvts.getRawParameterValue("echoTimeR")->load();
    const float echoLvlL  = apvts.getRawParameterValue("echoLevelL")->load();
    const float echoLvlR  = apvts.getRawParameterValue("echoLevelR")->load();

    static const char* kTypeNames[6] = { "HALL", "CHAMBER", "ROOM", "PLATE", "AMBIENCE", "CUSTOM" };
    const char* typeName = kTypeNames[juce::jlimit(0, 5, revType)];

    const float baseY = r.getBottom() - 16.0f;
    const float maxH  = r.getHeight() - 38.0f;
    const float startX = r.getX() + 20.0f + (preDelay / 250.0f) * 85.0f;
    const float tailW  = juce::jlimit(80.0f, r.getWidth() - (startX - r.getX()) - 24.0f,
                                      (rt60 / 5.0f) * (r.getWidth() * 0.78f) + (roomSize / 76.0f) * 90.0f);

    // 1. Draw RT60 Reverb Tail Envelope
    juce::Path envPath;
    envPath.startNewSubPath(startX, baseY);
    const int N = 80;
    for (int i = 0; i <= N; ++i)
    {
        float t = static_cast<float>(i) / static_cast<float>(N);
        float x = startX + t * tailW;
        float attack = std::min(1.0f, t * (6.0f + (diffusion * 0.06f)));
        float decay  = std::exp(-t * (4.2f - (damping / 20000.0f) * 1.4f));
        float ripple = 1.0f + 0.08f * (spread * 0.01f) * std::sin(t * 38.0f);
        float h = juce::jlimit(0.0f, 1.0f, attack * decay * ripple) * maxH;
        envPath.lineTo(x, baseY - h);
    }
    envPath.lineTo(startX + tailW, baseY);
    envPath.closeSubPath();

    juce::ColourGradient tailGrad(juce::Colour(0x88c084fc), startX, baseY - maxH,
                                  juce::Colour(0x183b0764), startX + tailW, baseY, false);
    g.setGradientFill(tailGrad);
    g.fillPath(envPath);

    g.setColour(juce::Colour(0xffd8b4fe));
    g.strokePath(envPath, juce::PathStrokeType(1.8f));

    // 2. Draw Early Reflections & Left/Right Echo Spikes
    for (int er = 0; er < 12; ++er)
    {
        float frac = static_cast<float>(er) / 12.0f;
        float x = startX + frac * tailW * 0.55f;
        float amp = std::exp(-frac * 2.4f) * (0.45f + 0.45f * (diffusion * 0.01f));
        float barH = amp * maxH * 0.85f;
        g.setColour((er % 2 == 0) ? juce::Colour(0xcc38bdf8) : juce::Colour(0xccf472b6));
        g.drawVerticalLine(static_cast<int>(x), baseY - barH, baseY);
    }

    if (echoLvlL > -58.0f)
    {
        float ex = r.getX() + 24.0f + (echoTimeL / 600.0f) * (r.getWidth() - 48.0f);
        float eh = ((echoLvlL + 60.0f) / 60.0f) * maxH * 0.8f;
        g.setColour(juce::Colour(0xff00f5d4));
        g.fillRoundedRectangle(ex - 2.5f, baseY - eh, 5.0f, eh, 2.0f);
    }
    if (echoLvlR > -58.0f)
    {
        float ex = r.getX() + 24.0f + (echoTimeR / 600.0f) * (r.getWidth() - 48.0f);
        float eh = ((echoLvlR + 60.0f) / 60.0f) * maxH * 0.8f;
        g.setColour(juce::Colour(0xffffb703));
        g.fillRoundedRectangle(ex - 2.5f, baseY - eh, 5.0f, eh, 2.0f);
    }

    // 3. HUD Text Overlay (matching PantheonII.dll format strings at 0x040d47..0x040d8c)
    g.setFont(juce::Font(juce::FontOptions(11.5f, juce::Font::bold)));
    g.setColour(juce::Colour(0xffe9d5ff));
    g.drawText(juce::String::formatted("Reverb Type: %s  |  Room Size: %.0f m  |  RT60: %.2f s",
                                       typeName, roomSize, rt60),
               static_cast<int>(r.getX()) + 12, static_cast<int>(r.getY()) + 5, 430, 16,
               juce::Justification::centredLeft);

    g.setColour(juce::Colour(0xff7dd3fc));
    g.drawText(juce::String::formatted("Pre-Delay: %.0f ms  |  Damping: %.0f Hz  |  Diffusion: %.0f%%",
                                       preDelay, damping, diffusion),
               static_cast<int>(r.getRight()) - 380, static_cast<int>(r.getY()) + 5, 368, 16,
               juce::Justification::centredRight);
}

TPantheonAudioProcessorEditor::TPantheonAudioProcessorEditor(TPantheonAudioProcessor& p)
    : AudioProcessorEditor(&p),
      audioProcessor(p),
      acousticDisplay(p),
      licenseOverlay(
          [this]() { return audioProcessor.getLicenseManager().snapshot(); },
          [this](const juce::String& k) { audioProcessor.getLicenseManager().requestActivation(k); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { audioProcessor.getLicenseManager().requestTrial(); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { licenseOverlay.setVisible(false); updateLicenseBadge(); repaint(); }
      )
{
    setLookAndFeel(&customLookAndFeel);
    pantheonBgImage   = juce::ImageCache::getFromMemory(BinaryData::pantheon_bg_png,   BinaryData::pantheon_bg_pngSize);
    pantheonLogoImage = juce::ImageCache::getFromMemory(BinaryData::pantheon_logo_png, BinaryData::pantheon_logo_pngSize);

    addAndMakeVisible(acousticDisplay);

    // Preset selector
    const auto& presets = TPantheonAudioProcessor::getFactoryPresets();
    for (int i = 0; i < static_cast<int>(presets.size()); ++i)
        presetBox.addItem(juce::String::fromUTF8(presets[static_cast<size_t>(i)].name), i + 1);
    presetBox.setSelectedId(audioProcessor.getCurrentProgram() + 1, juce::dontSendNotification);
    presetBox.onChange = [this]
    {
        int idx = presetBox.getSelectedId() - 1;
        if (idx >= 0)
            audioProcessor.setCurrentProgram(idx);
    };
    addAndMakeVisible(presetBox);

    // Reverb Type selector
    reverbTypeBox.addItemList({ "Hall", "Chamber", "Room", "Plate", "Ambience", "Custom" }, 1);
    addAndMakeVisible(reverbTypeBox);
    reverbTypeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "reverbType", reverbTypeBox);

    // License button
    licenseBtn.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff231842));
    licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff7affc6));
    licenseBtn.onClick = [this]
    {
        audioProcessor.refreshLicenseState();
        licenseOverlay.setVisible(!licenseOverlay.isVisible());
        if (licenseOverlay.isVisible())
            licenseOverlay.toFront(true);
        resized();
    };
    addAndMakeVisible(licenseBtn);

    const juce::Colour colSpace(0xffc084fc);
    const juce::Colour colTone(0xff38bdf8);
    const juce::Colour colEcho(0xfffbbf24);
    const juce::Colour colMix(0xfff472b6);

    setupKnob(roomSizeSlider,   roomSizeLabel,   "ROOM SIZE",   " m",   colSpace);
    setupKnob(rt60Slider,       rt60Label,       "RT60 DECAY",  " s",   colSpace);
    setupKnob(preDelaySlider,   preDelayLabel,   "PRE-DELAY",   " ms",  colSpace);
    setupKnob(spreadSlider,     spreadLabel,     "SPREAD",      " %",   colSpace);
    setupKnob(diffusionSlider,  diffusionLabel,  "DIFFUSION",   " %",   colSpace);
    setupKnob(regenSlider,      regenLabel,      "REGEN",       " %",   colSpace);

    setupKnob(dampingSlider,    dampingLabel,    "DAMPING",     " Hz",  colTone);
    setupKnob(bassBoostSlider,  bassBoostLabel,  "BASS BOOST",  " x",   colTone);
    setupKnob(bassFreqSlider,   bassFreqLabel,   "BASS FREQ",   " Hz",  colTone);
    setupKnob(delaySlider,      delayLabel,      "TANK DELAY",  " ms",  colTone);

    setupKnob(echoTimeLSlider,  echoTimeLLabel,  "ECHO TIME L", " ms",  colEcho);
    setupKnob(echoLevelLSlider, echoLevelLLabel, "ECHO LVL L",  " dB",  colEcho);
    setupKnob(echoTimeRSlider,  echoTimeRLabel,  "ECHO TIME R", " ms",  colEcho);
    setupKnob(echoLevelRSlider, echoLevelRLabel, "ECHO LVL R",  " dB",  colEcho);

    setupKnob(inputLevelSlider, inputLevelLabel, "INPUT",       " dB",  colMix);
    setupKnob(levelSlider,      levelLabel,      "OUTPUT LVL",  " dB",  colMix);
    setupKnob(mixSlider,        mixLabel,        "DRY / WET",   " %",   colMix);

    auto& apvts = audioProcessor.getAPVTS();
    roomSizeAtt   = std::make_unique<SliderAttachment>(apvts, "roomSize",   roomSizeSlider);
    rt60Att       = std::make_unique<SliderAttachment>(apvts, "rt60",       rt60Slider);
    preDelayAtt   = std::make_unique<SliderAttachment>(apvts, "preDelay",   preDelaySlider);
    spreadAtt     = std::make_unique<SliderAttachment>(apvts, "spread",     spreadSlider);
    diffusionAtt  = std::make_unique<SliderAttachment>(apvts, "diffusion",  diffusionSlider);
    regenAtt      = std::make_unique<SliderAttachment>(apvts, "regen",      regenSlider);

    dampingAtt    = std::make_unique<SliderAttachment>(apvts, "damping",    dampingSlider);
    bassBoostAtt  = std::make_unique<SliderAttachment>(apvts, "bassBoost",  bassBoostSlider);
    bassFreqAtt   = std::make_unique<SliderAttachment>(apvts, "bassFreq",   bassFreqSlider);
    delayAtt      = std::make_unique<SliderAttachment>(apvts, "delay",      delaySlider);

    echoTimeLAtt  = std::make_unique<SliderAttachment>(apvts, "echoTimeL",  echoTimeLSlider);
    echoLevelLAtt = std::make_unique<SliderAttachment>(apvts, "echoLevelL", echoLevelLSlider);
    echoTimeRAtt  = std::make_unique<SliderAttachment>(apvts, "echoTimeR",  echoTimeRSlider);
    echoLevelRAtt = std::make_unique<SliderAttachment>(apvts, "echoLevelR", echoLevelRSlider);

    inputLevelAtt = std::make_unique<SliderAttachment>(apvts, "inputLevel", inputLevelSlider);
    levelAtt      = std::make_unique<SliderAttachment>(apvts, "level",      levelSlider);
    mixAtt        = std::make_unique<SliderAttachment>(apvts, "mix",        mixSlider);

    addChildComponent(licenseOverlay);
    if (!audioProcessor.isPluginUnlocked())
        licenseOverlay.setVisible(true);

    updateLicenseBadge();
    setSize(860, 560);
    startTimerHz(30);
}

TPantheonAudioProcessorEditor::~TPantheonAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
}

void TPantheonAudioProcessorEditor::setupKnob(juce::Slider& s, juce::Label& l, const juce::String& name,
                                              const juce::String& suffix, juce::Colour accentCol)
{
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 68, 17);
    s.setColour(juce::Slider::rotarySliderFillColourId, accentCol);
    if (suffix.isNotEmpty())
        s.setTextValueSuffix(suffix);
    addAndMakeVisible(s);

    l.setText(name, juce::dontSendNotification);
    l.setJustificationType(juce::Justification::centred);
    l.setColour(juce::Label::textColourId, juce::Colour(0xffd6c7f7));
    l.setFont(juce::Font(juce::FontOptions(10.8f, juce::Font::bold)));
    addAndMakeVisible(l);
}

void TPantheonAudioProcessorEditor::updateLicenseBadge()
{
    const auto snap = audioProcessor.getLicenseManager().snapshot();
    if (snap.activated)
    {
        licenseBtn.setButtonText(juce::String::fromUTF8("Đã kích hoạt vĩnh viễn"));
        licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff5effb8));
    }
    else if (snap.allowed)
    {
        licenseBtn.setButtonText(juce::String::fromUTF8("Dùng thử (còn ") + juce::String(snap.daysLeft) + juce::String::fromUTF8(" ngày)"));
        licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffffd166));
    }
    else
    {
        licenseBtn.setButtonText(juce::String::fromUTF8("Hết hạn dùng thử - Nhập Key"));
        licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffff5c77));
    }
}

void TPantheonAudioProcessorEditor::timerCallback()
{
    updateLicenseBadge();
    acousticDisplay.repaint();
}

void TPantheonAudioProcessorEditor::paint(juce::Graphics& g)
{
    auto bounds = getLocalBounds().toFloat();

    juce::ColourGradient chassis(juce::Colour(0xff120d24), 0.0f, 0.0f,
                                 juce::Colour(0xff080512), 0.0f, bounds.getHeight(), false);
    g.setGradientFill(chassis);
    g.fillRect(bounds);

    if (pantheonBgImage.isValid())
    {
        g.setOpacity(0.12f);
        g.drawImageWithin(pantheonBgImage, 0, 0, getWidth(), getHeight(), juce::RectanglePlacement::stretchToFit);
        g.setOpacity(1.0f);
    }

    // Header Bar
    juce::Rectangle<float> headerRect(10.0f, 8.0f, bounds.getWidth() - 20.0f, 44.0f);
    g.setColour(juce::Colour(0xff191233));
    g.fillRoundedRectangle(headerRect, 7.0f);
    g.setColour(juce::Colour(0xff4a3880));
    g.drawRoundedRectangle(headerRect, 7.0f, 1.2f);

    g.setColour(juce::Colour(0xffd8b4fe));
    g.setFont(juce::Font(juce::FontOptions(20.0f, juce::Font::bold)));
    g.drawText("PANTHEON II", 22, 12, 180, 24, juce::Justification::centredLeft);

    g.setColour(juce::Colour(0xffa78bfa));
    g.setFont(juce::Font(juce::FontOptions(10.5f, juce::Font::bold)));
    g.drawText("PANTHEON II by lexicon  |  NT STUDIO x64", 22, 32, 340, 16, juce::Justification::centredLeft);

    auto drawCard = [&](juce::Rectangle<float> rect, const juce::String& title, juce::Colour accent)
    {
        g.setColour(juce::Colour(0xcc130e26));
        g.fillRoundedRectangle(rect, 8.0f);
        g.setColour(juce::Colour(0xff3b2d66));
        g.drawRoundedRectangle(rect, 8.0f, 1.2f);

        juce::Rectangle<float> banner(rect.getX(), rect.getY(), rect.getWidth(), 24.0f);
        g.setColour(accent.withAlpha(0.18f));
        g.fillRoundedRectangle(banner, 8.0f);
        g.setColour(accent);
        g.setFont(juce::Font(juce::FontOptions(11.5f, juce::Font::bold)));
        g.drawText(title, banner.reduced(10.0f, 0.0f).toNearestInt(), juce::Justification::centredLeft);
    };

    drawCard({ 12.0f, 202.0f, 556.0f, 168.0f }, "PHOENIX CHAMBER ACOUSTIC CORE (ROOM / PLATE / SHORT VERB)", juce::Colour(0xffc084fc));
    drawCard({ 576.0f, 202.0f, 272.0f, 168.0f }, "HIGH DAMPING & BASS MULTIPLIER",                             juce::Colour(0xff38bdf8));
    drawCard({ 12.0f, 378.0f, 444.0f, 170.0f }, "STEREO EARLY ECHO REFLECTIONS (LEFT / RIGHT)",               juce::Colour(0xfffbbf24));
    drawCard({ 464.0f, 378.0f, 384.0f, 170.0f }, "INPUT, OUTPUT LEVEL & DRY / WET MIX",                        juce::Colour(0xfff472b6));
}

void TPantheonAudioProcessorEditor::resized()
{
    presetBox.setBounds(340, 16, 235, 28);
    reverbTypeBox.setBounds(583, 16, 112, 28);
    licenseBtn.setBounds(703, 16, 138, 28);

    acousticDisplay.setBounds(12, 58, getWidth() - 24, 136);

    // Row 1 Left: 6 Space & Decay Knobs (12, 202, 556, 168)
    juce::Slider* row1LeftSliders[6] = { &roomSizeSlider, &rt60Slider, &preDelaySlider, &spreadSlider, &diffusionSlider, &regenSlider };
    juce::Label*  row1LeftLabels[6]  = { &roomSizeLabel,  &rt60Label,  &preDelayLabel,  &spreadLabel,  &diffusionLabel,  &regenLabel };
    for (int i = 0; i < 6; ++i)
    {
        int x = 20 + i * 90;
        row1LeftLabels[i]->setBounds(x, 232, 86, 16);
        row1LeftSliders[i]->setBounds(x, 248, 86, 112);
    }

    // Row 1 Right: Damping, Bass Boost, Bass Freq (576, 202, 272, 168)
    juce::Slider* row1RightSliders[3] = { &dampingSlider, &bassBoostSlider, &bassFreqSlider };
    juce::Label*  row1RightLabels[3]  = { &dampingLabel,  &bassBoostLabel,  &bassFreqLabel };
    for (int i = 0; i < 3; ++i)
    {
        int x = 584 + i * 86;
        row1RightLabels[i]->setBounds(x, 232, 84, 16);
        row1RightSliders[i]->setBounds(x, 248, 84, 112);
    }

    // Row 2 Left: Echo Reflections + Tank Delay (12, 378, 444, 170)
    juce::Slider* row2LeftSliders[5] = { &delaySlider, &echoTimeLSlider, &echoLevelLSlider, &echoTimeRSlider, &echoLevelRSlider };
    juce::Label*  row2LeftLabels[5]  = { &delayLabel,  &echoTimeLLabel,  &echoLevelLLabel,  &echoTimeRLabel,  &echoLevelRLabel };
    for (int i = 0; i < 5; ++i)
    {
        int x = 20 + i * 86;
        row2LeftLabels[i]->setBounds(x, 408, 84, 16);
        row2LeftSliders[i]->setBounds(x, 424, 84, 114);
    }

    // Row 2 Right: Input, Output Level, Mix (464, 378, 384, 170)
    juce::Slider* row2RightSliders[3] = { &inputLevelSlider, &levelSlider, &mixSlider };
    juce::Label*  row2RightLabels[3]  = { &inputLevelLabel,  &levelLabel,  &mixLabel };
    for (int i = 0; i < 3; ++i)
    {
        int x = 482 + i * 120;
        row2RightLabels[i]->setBounds(x, 408, 108, 16);
        row2RightSliders[i]->setBounds(x, 424, 108, 114);
    }

    licenseOverlay.setBounds(getLocalBounds());
}
