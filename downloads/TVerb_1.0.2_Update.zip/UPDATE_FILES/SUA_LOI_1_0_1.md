# T-Verb 1.0.1 — Ghi chú sửa lỗi và kiểm chứng

Ngày: 27/10/2026. Đây là ZIP **mã nguồn dành cho chủ dự án**, gồm JUCE và các script build Windows/macOS như bản gốc. Không phải bộ cài VST3 Windows/macOS đã biên dịch.

## Các lỗi đã sửa

1. **Damping/comb:** tính đầu ra DF2 bằng trạng thái cũ trước khi cập nhật hai trạng thái trễ. Sửa nguyên nhân gây tự tăng đuôi vang, biên độ cực lớn và Inf/NaN trong các trường hợp Ultra/decay dài đã tái hiện. Không thêm limiter để che lỗi hồi tiếp.
2. **Resampler:** giữ đúng bốn mẫu lịch sử cả khi một callback chỉ có 0–3 mẫu DSP. Không bỏ qua FIFO output và đường dry khi chưa tạo mẫu DSP mới. Đã kiểm tra block 1/7/64/511/512 và chuỗi block thay đổi, gồm block lớn hơn kích thước đã chuẩn bị.
3. **EQ:** giữ tiến độ crossfade qua nhiều callback để hoàn tất đủ 30 samples, thay vì kết thúc sớm ở callback đầu tiên.
4. **Bộ nhớ/audio callback:** cấp phát trước buffer dry, buffer làm việc cho quality cao nhất, scratch mono và các stage reflection. Xử lý block vượt kích thước bằng các đoạn nhỏ, không tăng vector ngay khi chạy audio. Bỏ mutex của engine; DSP có một luồng sở hữu, các thao tác prepare/setter/process/suspend phải được host/processor tuần tự hóa. UI không đọc/ghi engine trực tiếp.
5. **Quality và tần số:** áp dụng lại giá trị damping/EQ yêu cầu sau khi đổi quality, tránh giữ mãi tần số từng bị giới hạn bởi quality thấp.
6. **Metadata tail:** processor báo thời gian đuôi theo decay, ratio và predelay, có khoảng dự phòng, thay vì luôn trả về 0 giây.
7. **Đồng bộ host/state:** phản hồi các điều chỉnh crossover và chế độ 64-bit cố định về APVTS trên message thread. Audio thread chỉ ghi dữ liệu atomic; worker gửi thông báo. Không gọi `setValueNotifyingHost` từ audio thread và không ghi đè các chỉnh sửa mới hơn bằng một thông báo cũ.
8. **Test:** sửa trường hợp predelay không tìm thấy tín hiệu vẫn có thể vượt qua kiểm tra; tăng thời lượng test preset/quality; bổ sung kiểm tra năng lượng, peak, tail metadata và lưu/nạp state.

Factory preset được chuyển sang `src/FactoryPresets.h` để processor và regression test dùng chung một bảng; giữ nguyên các tên và giá trị. ID/thang tham số, cấu trúc state, giao diện, product ID, brand ID, public key và private key được giữ nguyên. Phiên bản sản phẩm tăng từ 1.0.0 lên 1.0.1.

## Kết quả đã chạy

Môi trường: Linux x86-64, GCC 14.2, JUCE trong ZIP. Kết quả thuộc bản nguồn này:

- **305/305 phép kiểm tra DSP đạt:** 183 cơ bản + 122 mở rộng. Gồm 13 room types, ba quality, 44,1/48/96 kHz, 16 factory presets, đuôi vang dài, các đầu mút tham số, resampling và chuỗi block thay đổi.
- **6/6 bộ test CTest đạt:** EngineAudit, EngineExtended, RealtimeAllocation, License, DSP processor, UIValue.
- **3/3 bộ test engine đạt với AddressSanitizer và UndefinedBehaviorSanitizer.** Không có chẩn đoán lỗi bộ nhớ/UB trong các lượt đã chạy.
- **0 lần cấp phát heap** trong phép đo 50 callback sau warm-up; cũng đo được 0 khi đổi các đầu mút tham số/quality và xử lý block lớn hơn dự kiến. Đây là đo engine, không phải chứng nhận deadline realtime cho toàn bộ DAW.
- Build được **VST3 Linux** và nạp module bằng `dlopen`: `ModuleEntry`, `GetPluginFactory`, `ModuleExit` đều thành công. Binary Linux chỉ dùng kiểm tra tại môi trường phát triển, không đóng kèm trong ZIP cho Windows/macOS.
- Test bản quyền đạt 22 kiểm tra. Test processor dùng trial thật trong thư mục tạm để không đụng dữ liệu kích hoạt của người phát triển; không thêm đường bỏ qua bản quyền trong plugin.
- Script shell macOS qua kiểm tra cú pháp `bash -n`; chưa chạy build/installer macOS hoặc Windows.

Xem log ở `VALIDATION/`. Cách chạy lại nằm trong `README.md`.

## Còn cần kiểm tra trên máy của anh

Chưa có bằng chứng build hoặc chạy binary Windows/macOS, Cubase/DAW, native GUI, audio device, bộ cài, ký code/notarization hoặc CPU deadline trên máy đích. Cần build bằng script tương ứng rồi thử nghe, automation, bypass và mở lại session trong DAW trước khi phát hành cho khách.

Đổi quality vẫn khởi tạo lại các buffer DSP và đuôi vang theo thiết kế hiện có; chưa cam kết chuyển quality không gián đoạn âm thanh. Không coi các phép kiểm tra đã đạt là xác nhận chất âm giống 100% một plugin tham chiếu, vì không có bản tham chiếu để so sánh.

## Build để anh dùng thử

**Windows:** cần Visual Studio với Desktop development with C++ và CMake 3.22+. Chạy `2_BUILD_VA_XUAT_FILE.bat` hoặc `BUILD_RELEASE.bat`. Muốn tạo bộ cài, dùng `3_TAO_BO_CAI_WINDOWS.bat` sau khi build thành công.

**macOS:** cần Xcode Command Line Tools và CMake 3.22+. Dùng `1_BUILD_MAC_UNIVERSAL.command` để build Intel + Apple Silicon, hoặc script ARM64/Intel tương ứng. Nếu file command chưa có quyền chạy, làm theo hướng dẫn chmod trong README.

Các script xuất file kiểm tra manifest và ngăn đưa keygen/private key vào output dành cho khách. ZIP nguồn này giữ `KhoaBanQuyen` như gói anh đã gửi, vì vậy chỉ giữ cho chủ dự án; không gửi nguyên ZIP nguồn này cho khách. Không tạo lại cặp khóa chỉ để thử bản sửa, vì sẽ ảnh hưởng khóa kích hoạt đang dùng.
