// T-Verb DSP checks (100% ArtsAcoustic Reverb 25-parameter engine + 13 room types + 16 presets).
#include "VerbProcessor.h"
#include <cstdio>
#include <thread>
#include <chrono>
juce::AudioProcessorEditor* tverb::Processor::createEditor() { return nullptr; }

static int failures = 0;
#define CHECK(c) do { if (!(c)) { std::printf ("FAIL line %d: %s\n", __LINE__, #c); ++failures; } } while (0)
static void setP (tverb::Processor& p, const juce::String& id, float v)
{ auto* q = p.apvts.getParameter (id); CHECK(q != nullptr); if (q) q->setValueNotifyingHost (q->convertTo0to1 (v)); }
static const double SR = 48000.0;

// Use the real license/trial manager, isolated from the developer's installed
// activation and home directory. No license checks are bypassed by these tests.
struct TestStore {
    juce::File folder = juce::File::getSpecialLocation(juce::File::tempDirectory)
        .getChildFile("tverb-processor-tests-"+juce::Uuid().toString());
    int instance = 0;
    ~TestStore() { folder.deleteRecursively(); }
    tak::license::StorePaths next() {
        return tak::license::StorePaths::under(folder, "instance-"+juce::String(instance++));
    }
};
static TestStore testStore;
struct TestProcessor : tverb::Processor {
    TestProcessor() : tverb::Processor(testStore.next()) {}
};

static void run (tverb::Processor& p, std::vector<float>& l, std::vector<float>& r)
{
    juce::AudioBuffer<float> b (2, 512); juce::MidiBuffer m;
    for (size_t s = 0; s < l.size(); s += 512)
    {
        const int n = (int) std::min<size_t> (512, l.size() - s); b.setSize (2, n, false, false, true);
        for (int i = 0; i < n; ++i) { b.setSample (0, i, l[s + i]); b.setSample (1, i, r[s + i]); }
        p.processBlock (b, m);
        for (int i = 0; i < n; ++i) { l[s + i] = b.getSample (0, i); r[s + i] = b.getSample (1, i); }
    }
}

static void wetOnly (tverb::Processor& p)
{
    setP (p, "dryon", 0.0f);
    setP (p, "weton", 1.0f);
    setP (p, "wet",   0.0f);
    setP (p, "loratio",  1.0f);
    setP (p, "midratio", 1.0f);
    setP (p, "hiratio",  1.0f);
    setP (p, "locut",    20.0f);
    setP (p, "hicut",    20000.0f);
    setP (p, "echoint",  0.0f);
    setP (p, "mod",      0.0f);
}

static int runShutdownTests()
{
    juce::AudioBuffer<float> b(2,64);juce::MidiBuffer midi;
    double worstMs=0;
    for(int n=0;n<60;++n)
    {
        auto p=std::make_unique<TestProcessor>();p->prepareToPlay(SR,64);
        setP(*p,"crosslo",5500);setP(*p,"bitdepth",0);b.clear();p->processBlock(b,midi);
        p->releaseResources();
        CHECK(!p->canNotifyHost());
        // Deferred corrections must not notify/re-enter the host after release.
        if(n==0) {
            const auto before=p->param("bitdepth");
            juce::MessageManager::getInstance()->runDispatchLoopUntil(100);
            CHECK(p->param("bitdepth")==before);
        }
        const auto start=std::chrono::steady_clock::now();
        if(n%2==0) p.reset();
        else {
            std::atomic<bool> done{false};
            std::thread closer([&]{
                const juce::MessageManagerLock lock;
                p.reset();done.store(true,std::memory_order_release);
            });
            while(!done.load(std::memory_order_acquire))
                juce::MessageManager::getInstance()->runDispatchLoopUntil(5);
            closer.join();
        }
        const double ms=std::chrono::duration<double,std::milli>(std::chrono::steady_clock::now()-start).count();
        worstMs=std::max(worstMs,ms);
        CHECK(ms<1500);
    }
    std::printf("60 processor shutdowns, alternating message-thread and UI-locked worker destruction; slowest %.1f ms\n",worstMs);
    std::printf(failures?"%d SHUTDOWN CHECK(S) FAILED\n":"ALL SHUTDOWN CHECKS PASSED\n",failures);
    return failures?1:0;
}

int main(int argc,char** argv)
{
    juce::ScopedJuceInitialiser_GUI init;
    if(argc>1 && juce::String(argv[1])=="--shutdown")return runShutdownTests();

    // 1. Test all 13 ArtsAcoustic Room Types & Decay scaling
    for (int type = 0; type < 13; ++type)
    {
        TestProcessor p;
        wetOnly (p);
        setP (p, "type", (float) type);
        setP (p, "decay", 2.0f);
        p.prepareToPlay (SR, 512);
        std::vector<float> l ((size_t) (SR * 0.5), 0.0f), r = l;
        l[64] = r[64] = 1.0f;
        run (p, l, r);
        double energy = 0.0;
        for (size_t i = 0; i < l.size(); ++i)
            energy += l[i] * l[i] + r[i] * r[i];
        std::printf ("Room Type %2d (%-9s): energy = %.6f\n", type, tverb::getAARTypeNames()[type].toRawUTF8(), energy);
        CHECK (std::isfinite (energy) && energy > 1e-5);
    }

    // 2. Test Pre-delay accuracy
    {
        TestProcessor p;
        wetOnly (p);
        setP (p, "predelay", 80.0f);
        p.prepareToPlay (SR, 512);
        std::vector<float> l ((size_t) SR, 0.0f), r = l;
        l[500] = r[500] = 1.0f;
        run (p, l, r);
        size_t first = l.size();
        for (size_t i = 501; i < l.size(); ++i)
            if (std::abs (l[i]) > 1e-4f || std::abs (r[i]) > 1e-4f) { first = i; break; }
        CHECK (first < l.size());
        double delayMs = (static_cast<double>(first) - 500) * 1000.0 / SR;
        std::printf ("Pre-delay 80 ms -> first wet output at %.1f ms\n", delayMs);
        CHECK (delayMs >= 75.0 && delayMs <= 90.0);
    }

    // 3. Quality and legacy bitdepth state: this product deliberately uses the
    // double engine for both saved bitdepth values (not two precision modes).
    for (int bd : { 0, 1 })
    {
        for (int q : { 0, 1, 2 })
        {
            TestProcessor p;
            wetOnly (p);
            setP (p, "bitdepth", (float) bd);
            setP (p, "quality",  (float) q);
            p.prepareToPlay (SR, 512);
            CHECK (p.getReverbEngine()->get_bitDepth() == ArtsAcoustic::kBitDepth_64BitDouble);
            std::vector<float> l ((size_t)SR, 0.0f), r = l;
            l[32] = r[32] = 0.8f;
            run (p, l, r);
            double e = 0.0, peak = 0.0;
            for (size_t i = 0; i < l.size(); ++i) {
                e += double(l[i]) * l[i] + double(r[i]) * r[i];
                peak = std::max({peak,double(std::abs(l[i])),double(std::abs(r[i]))});
            }
            std::printf ("Saved BitDepth=%d (64-bit engine) Quality=%d -> energy=%.6f peak=%.6f\n", bd, q, e, peak);
            CHECK (std::isfinite (e) && e > 1e-6 && peak < 10.0);
        }
    }

    // 4. Test all 16 Factory Presets
    {
        for (int pr = 0; pr < (int)tverb::getFactoryPresets().size(); ++pr)
        {
            TestProcessor p;
            p.setCurrentProgram (pr);
            p.prepareToPlay (SR, 512);
            std::vector<float> l ((size_t)(SR * 2), 0.0f), r = l;
            l[16] = r[16] = 0.5f;
            run (p, l, r);
            bool ok = true; double energy = 0;
            for (size_t i = 0; i < l.size(); ++i) {
                ok &= std::isfinite (l[i]) && std::isfinite (r[i]);
                energy += double(l[i])*l[i]+double(r[i])*r[i];
            }
            CHECK (ok && energy > 1e-10);
        }
    }

    // 5. Tail metadata and deferred host corrections, including state round trip.
    {
        TestProcessor p;
        p.prepareToPlay(SR, 512);
        CHECK(p.getTailLengthSeconds() > p.param("decay"));
        setP(p,"crosslo",5500);
        setP(p,"bitdepth",0);
        std::vector<float> l(512,0),r=l;run(p,l,r);
        for (int attempt = 0; attempt < 20; ++attempt) {
            juce::MessageManager::getInstance()->runDispatchLoopUntil(50);
            if(p.param("crosshi") >= p.param("crosslo")*1.049f && p.param("bitdepth") > .5f) break;
        }
        CHECK(p.param("crosshi") >= p.param("crosslo")*1.049f);
        CHECK(p.param("bitdepth") > .5f);
        juce::MemoryBlock state;p.getStateInformation(state);
        TestProcessor restored;restored.setStateInformation(state.getData(),(int)state.getSize());
        CHECK(std::abs(restored.param("crosshi")-p.param("crosshi")) < .1f);
        CHECK(std::abs(restored.param("crosslo")-p.param("crosslo")) < .1f);
        setP(p,"decay",45.2f);setP(p,"loratio",5.f);
        CHECK(p.getTailLengthSeconds() >= 45.2*5);
    }

    std::printf (failures ? "%d TEST(S) FAILED\n" : "ALL TESTS PASSED\n", failures);
    return failures ? 1 : 0;
}
