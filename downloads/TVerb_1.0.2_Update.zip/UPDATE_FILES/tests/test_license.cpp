// SPDX-License-Identifier: AGPL-3.0-or-later
#include "licensing/LicenseCodec.h"
#include "licensing/LicenseManager.h"
#include <cstdio>
#include <stdexcept>

static int checks=0;
static void check(bool ok,const char* what){++checks;if(!ok)throw std::runtime_error(what);}
int main(){try{
 using namespace tak::license;
 juce::String pub,priv,error;check(createKeyPair(pub,priv,error),"RSA generation");
 check(pub.startsWith("10001,"),"RSA exponent must be 65537");
 Configuration cfg{"TVERB","TSTUDIO","T-Verb",pub,7};
 const juce::StringArray ids{"A1B2-C3D4-E5F6","1122-3344-5566","7788-99AA-BBCC"};
 constexpr juce::int64 now=1700000000000LL,day=86400000LL;
 Claims c{"Khách thử Nguyễn Tình","TVERB","TSTUDIO",now,now+30*day,ids};
 const auto token=sign(c,priv,error);check(token.startsWith("TAK1."),"Token format");
 auto v=verify(token,cfg,ids,now);check(v.valid&&v.claims.owner==c.owner,"Valid UTF-8 owner");
 check(verify(token,cfg,{ids[0],ids[1]},now).valid,"Two of three identifiers");
 check(!verify(token,cfg,{ids[0],"AAAA-BBBB-CCCC"},now).valid,"One of three is rejected");
 auto other=cfg;other.productId="TAUTOKEY";check(!verify(token,other,ids,now).valid,"Other product rejected");
 other=cfg;other.brandId="OTHER";check(!verify(token,other,ids,now).valid,"Other brand rejected");
 other=cfg;other.publicKey=priv;check(!verify(token,other,ids,now).valid,"Private key cannot serve as the public verifier");
 check(!verify(token,cfg,ids,now+30*day).valid,"Expiry boundary");
 check(!verify(token,cfg,ids,now-2*day).valid,"Future issue rejected");
 c.expiresMs=0;const auto forever=sign(c,priv,error);check(verify(forever,cfg,ids,now+3650*day).valid,"Perpetual license");
 check(parseRequest(requestText(cfg,ids),cfg,error)==ids,"Export/import request");

 const auto folder=juce::File::getSpecialLocation(juce::File::tempDirectory).getChildFile("tverb-license-test-"+juce::Uuid().toString());
 struct Cleanup{juce::File folder;~Cleanup(){folder.deleteRecursively();}} cleanup{folder};
 {
  // Test default automatic 7-day trial WITHOUT clicking any trial button!
  const auto paths=StorePaths::under(folder.getChildFile("auto-trial"),cfg.productId);
  LicenseManager manager(cfg,paths,ids); // autoStartTrial = true by default
  check(manager.isAllowed(),"Fresh instance allows audio immediately");
  manager.poll(now);
  check(manager.isAllowed()&&manager.snapshot().trialStarted&&manager.snapshot().daysLeft==7,"Automatic 7-day trial starts on first poll without button click");
  manager.poll(now+6*day);check(manager.isAllowed()&&manager.snapshot().daysLeft==1,"Trial day six");
  manager.poll(now+7*day);check(!manager.isAllowed(),"Trial expires after 7 days");
  paths.trial.deleteFile();LicenseManager reopened(cfg,paths,ids);reopened.poll(now+7*day);check(!reopened.isAllowed(),"Backup prevents a single-file trial reset");
  reopened.poll(now+2*day);check(!reopened.isAllowed(),"Large clock rollback rejected");
 }
 {
  const auto paths=StorePaths::under(folder.getChildFile("cancelled"),cfg.productId);
  LicenseManager manager(cfg,paths,ids);std::atomic<bool> cancelled{true};
  manager.poll(now,&cancelled);
  check(!paths.trial.existsAsFile(),"Shutdown cancellation avoids starting new filesystem work");
  cancelled=false;manager.poll(now,&cancelled);
  check(manager.snapshot().trialStarted&&manager.snapshot().daysLeft==7,"Normal polling still starts trial automatically after cancellation clears");
 }
 {
  // Test activation and expiry
  const auto paths=StorePaths::under(folder.getChildFile("activated"),cfg.productId);
  LicenseManager manager(cfg,paths,ids);manager.poll(now);manager.requestActivation(token);manager.poll(now);
  check(manager.isAllowed()&&manager.snapshot().activated,"Activation enables product");
  check(paths.license.loadFileAsString()==token,"Activation persists exact token");
  manager.poll(now+31*day);check(!manager.isAllowed(),"Activated license expiry");
 }
 std::printf("T-VERB LICENSE TESTS PASSED: %d checks (RSA-2048, auto 7-day trial, activation, expiry)\n",checks);return 0;
}catch(const std::exception& e){std::fprintf(stderr,"LICENSE TEST FAILURE: %s\n",e.what());return 1;}}
