#!/bin/bash
set -eu
ROOT="$(cd "$(dirname "$0")/.." && pwd -P)"
ACTION="${1:-Menu}"
ARCHS="${TH_ARCHS:-arm64;x86_64}"
SUFFIX="${TH_SUFFIX:-UNIVERSAL}"
[[ "$SUFFIX" =~ ^[A-Z0-9_]+$ ]] || { echo 'Invalid TH_SUFFIX'; exit 1; }
case "$ARCHS" in arm64|x86_64|'arm64;x86_64'|'x86_64;arm64');;*)echo 'Invalid TH_ARCHS';exit 1;;esac
BUILD="$ROOT/build_mac_$SUFFIX"
KEYBUILD="$ROOT/build_keygen_mac_$SUFFIX"
EXPORT="$ROOT/_EXPORT_MAC_$SUFFIX"
mkdir -p "$ROOT/build_logs"
LOG="$ROOT/build_logs/MAC_${ACTION}_${SUFFIX}_$(date +%Y%m%d_%H%M%S).txt"
fail(){ printf '\nERROR: %s\nLog: %s\n' "$1" "$LOG"; exit 1; }
run(){ printf '> %s\n' "$*" | tee -a "$LOG"; "$@" >>"$LOG" 2>&1 || { tail -n 35 "$LOG"; fail 'Command failed'; }; }
json(){ /usr/bin/osascript -l JavaScript -e 'function run(a){ObjC.import("Foundation");var s=$.NSString.stringWithContentsOfFileEncodingError(a[0],$.NSUTF8StringEncoding,null);return String(JSON.parse(ObjC.unwrap(s))[a[1]]);}' "$ROOT/ThuongHieu.json" "$1"; }
NAME="$(json productName)";VERSION="$(json appVersion)";PRODUCT="$(json productId)";BRAND="$(json licenseBrand)"
[[ "$NAME" != *'/'* && "$NAME" != *':'* && "$NAME" != *$'\n'* && -n "$NAME" ]] || fail 'Invalid productName'
[[ "$PRODUCT" =~ ^[A-Za-z0-9_-]+$ && "$BRAND" =~ ^[A-Za-z0-9_-]+$ ]] || fail 'Invalid productId/licenseBrand'
[[ "$VERSION" =~ ^[0-9]+\.[0-9]+\.[0-9]+$ ]] || fail 'Use a three-part appVersion'
STORE="$PRODUCT-$BRAND";BUNDLE_NAME="$NAME.vst3"
CMAKE="$(command -v cmake || true)"
for c in /opt/homebrew/bin/cmake /usr/local/bin/cmake /Applications/CMake.app/Contents/bin/cmake; do if [[ -z "$CMAKE" && -x "$c" ]]; then CMAKE="$c"; fi; done
find_tools(){ [[ -n "$CMAKE" ]] || fail 'Install CMake 3.22 or newer'; xcrun --find clang++ >/dev/null 2>&1 || fail 'Install Xcode Command Line Tools'; }
public_ready(){
    local key
    key="$(tr -d '\r\n' < "$ROOT/config/public_key.txt")"
    [[ "${#key}" -eq 518 && "$key" =~ ^10001,[89a-fA-F][0-9a-fA-F]+[13579bBdDfF]$ ]] || fail 'Run MAC_1_SINH_KEY.command first (RSA-2048 public key required)'
}
configure(){
    local folder="$1" plugin="$2" keygen="$3" tests="$4"
    local options=()
    [[ -n "${TXKEY_JUCE_PATH:-}" ]] && options+=("-DTXKEY_JUCE_PATH=$TXKEY_JUCE_PATH")
    run "$CMAKE" -S "$ROOT" -B "$folder" -G 'Unix Makefiles' -DCMAKE_BUILD_TYPE=Release \
        "-DCMAKE_OSX_ARCHITECTURES=$ARCHS" -DCMAKE_OSX_DEPLOYMENT_TARGET=10.15 \
        "-DTAK_BUILD_PLUGIN=$plugin" "-DTAK_BUILD_KEYGEN=$keygen" "-DBUILD_TESTING=$tests" "${options[@]}"
}
source_hash(){
    {
        printf '%s\n' "$ROOT/CMakeLists.txt" "$ROOT/ThuongHieu.json" "$ROOT/config/public_key.txt" "$ROOT/Installer/T-Verb.iss" "$ROOT/HUONG_DAN_KHACH.txt" "$ROOT/LICENSE"
        find "$ROOT/src" "$ROOT/keygen" "$ROOT/cmake" "$ROOT/tests" "$ROOT/tools" -type f ! -name .DS_Store ! -name '._*'
    } | LC_ALL=C sort -u | while IFS= read -r f; do
        printf '%s:%s\n' "${f#$ROOT/}" "$(/usr/bin/shasum -a 256 "$f" | cut -d ' ' -f 1)"
    done | /usr/bin/shasum -a 256 | cut -d ' ' -f 1
}
manifest(){
    local folder="$1" output="$2"
    (cd "$folder";find . -type f ! -name "$(basename "$output")" | LC_ALL=C sort | while IFS= read -r f; do /usr/bin/shasum -a 256 "$f"; done) >"$output"
}
verify_manifest(){
    local folder="$1" file="$2"
    (cd "$folder";/usr/bin/shasum -a 256 -c "$file") >>"$LOG" 2>&1 || fail 'Export file hashes changed'
    local listed actual
    listed="$(wc -l < "$file" | tr -d ' ')";actual="$(find "$folder" -type f | wc -l | tr -d ' ')"
    # The manifest itself is inside an export, but outside the original build bundle.
    [[ "$file" == "$folder/"* ]] && listed=$((listed + 1))
    [[ "$listed" -eq "$actual" ]] || fail 'Unexpected files in output'
}
guard_customer(){
    local folder="$1" private="$ROOT/KhoaBanQuyen/$STORE/PRIVATE_KEY.txt"
    if find "$folder" \( -iname '*PRIVATE_KEY*' -o -iname '*Keygen*' -o -iname '*KhoaBanQuyen*' -o -iname '*.taklic' \) -print | grep -q .; then fail 'Owner files or activation keys are present in customer output'; fi
    if [[ -s "$private" ]]; then
        while IFS= read -r -d '' f; do
            if LC_ALL=C grep -a -F -f "$private" "$f" >/dev/null 2>&1; then fail 'Private key material found in customer output'; fi
        done < <(find "$folder" -type f -print0)
    fi
}
bundle_executable(){ /usr/libexec/PlistBuddy -c 'Print :CFBundleExecutable' "$1/Contents/Info.plist"; }
verify_arch(){
    local bundle="$1" executable
    executable="$(bundle_executable "$bundle")"
    for arch in ${ARCHS//;/ }; do lipo -verify_arch "$arch" "$bundle/Contents/MacOS/$executable" >>"$LOG" 2>&1 || fail "Missing architecture $arch"; done
}
init_keys(){
    find_tools;configure "$KEYBUILD" OFF ON OFF
    run "$CMAKE" --build "$KEYBUILD" --target TVerbKeygen --parallel "${TAK_JOBS:-2}"
    local app="$KEYBUILD/TVerbKeygen_artefacts/Release/T-Verb-Keygen.app"
    [[ -d "$app" ]] || fail 'Owner Keygen.app is missing'
    run "$app/Contents/MacOS/$(bundle_executable "$app")" --init "$ROOT"
    mkdir -p "$ROOT/KEYGEN";ditto "$app" "$ROOT/KEYGEN/T-Verb-Keygen.app"
    run /usr/bin/codesign --force --sign - "$ROOT/KEYGEN/T-Verb-Keygen.app"
    public_ready
    printf '\nKEYGEN ready. Back up KhoaBanQuyen and KEYGEN; keep them for the owner only.\n'
}
export_files(){
    public_ready
    [[ -f "$BUILD/source.sha256" && -f "$BUILD/bundle.sha256" ]] || fail 'Build before exporting'
    [[ "$(cat "$BUILD/source.sha256")" == "$(source_hash)" ]] || fail 'Source/public key changed; build again'
    local bundle="$BUILD/TVerb_artefacts/Release/VST3/$BUNDLE_NAME" stage="$EXPORT.new"
    verify_manifest "$bundle" "$BUILD/bundle.sha256"
    rm -rf "$stage";mkdir -p "$stage/VST3";ditto "$bundle" "$stage/VST3/$BUNDLE_NAME"
    if [[ -n "${TAK_APP_SIGN_ID:-}" ]]; then
        run /usr/bin/codesign --force --options runtime --timestamp --sign "$TAK_APP_SIGN_ID" "$stage/VST3/$BUNDLE_NAME"
    else run /usr/bin/codesign --force --sign - "$stage/VST3/$BUNDLE_NAME"; fi
    run /usr/bin/codesign --verify --strict "$stage/VST3/$BUNDLE_NAME"
    verify_arch "$stage/VST3/$BUNDLE_NAME"
    cp "$ROOT/HUONG_DAN_KHACH.txt" "$stage/";cp "$ROOT/LICENSE" "$stage/LICENSE.txt"
    printf '%s\n' "$(source_hash)" > "$stage/source.sha256";printf '%s\n' "$ARCHS" > "$stage/architectures.txt"
    guard_customer "$stage";manifest "$stage" "$stage/manifest.sha256"
    rm -rf "$EXPORT";mv "$stage" "$EXPORT"
    printf '\nEXPORT OK: %s\n' "$EXPORT"
}
build_release(){
    find_tools;
    local k="$(tr -d '\r\n' < "$ROOT/config/public_key.txt" 2>/dev/null || true)"
    [[ "${#k}" -eq 518 ]] || init_keys
    public_ready;configure "$BUILD" ON OFF ON
    run "$CMAKE" --build "$BUILD" --target TVerb_VST3 TVerbLicenseTests TVerbDSPTests TVerbUIValueTests TVerbEngineAuditTests TVerbEngineExtendedTests TVerbRealtimeAllocationTests --parallel "${TAK_JOBS:-2}"
    run "$(dirname "$CMAKE")/ctest" --test-dir "$BUILD" --output-on-failure
    local bundle="$BUILD/TVerb_artefacts/Release/VST3/$BUNDLE_NAME"
    [[ -d "$bundle/Contents/MacOS" ]] || fail 'Complete VST3 bundle is missing'
    verify_arch "$bundle"
    printf '%s\n' "$(source_hash)" > "$BUILD/source.sha256";manifest "$bundle" "$BUILD/bundle.sha256"
    export_files
}
verify_export(){
    public_ready
    [[ -f "$EXPORT/manifest.sha256" && -f "$EXPORT/source.sha256" ]] || fail 'No verified export'
    [[ "$(cat "$EXPORT/source.sha256")" == "$(source_hash)" ]] || fail 'Export is stale; rebuild'
    verify_manifest "$EXPORT" "$EXPORT/manifest.sha256";guard_customer "$EXPORT";verify_arch "$EXPORT/VST3/$BUNDLE_NAME"
    run /usr/bin/codesign --verify --strict "$EXPORT/VST3/$BUNDLE_NAME"
    printf 'EXPORT CHECK PASSED\n'
}
make_installer(){
    verify_export
    local work="$BUILD/pkgwork" plist="$BUILD/pkgwork/components.plist" output id safe
    rm -rf "$work";mkdir -p "$work" "$ROOT/Output"
    id="$(printf '%s.%s' "$BRAND" "$PRODUCT" | tr '[:upper:]_' '[:lower:]-')"
    safe="$(printf '%s' "$NAME" | tr ' ' '_' | tr -cd 'A-Za-z0-9_.-')";[[ -n "$safe" ]] || safe=T-Verb
    run pkgbuild --analyze --root "$EXPORT/VST3" "$plist"
    local i=0
    while /usr/libexec/PlistBuddy -c "Print :$i" "$plist" >/dev/null 2>&1; do
        /usr/libexec/PlistBuddy -c "Set :$i:BundleIsRelocatable false" "$plist"
        /usr/libexec/PlistBuddy -c "Set :$i:BundleOverwriteAction upgrade" "$plist"
        i=$((i+1))
    done
    run pkgbuild --root "$EXPORT/VST3" --component-plist "$plist" --install-location /Library/Audio/Plug-Ins/VST3 --identifier "com.tstudio.$id.vst3" --version "$VERSION" "$work/component.pkg"
    output="$ROOT/Output/${safe}_${VERSION}_Mac_${SUFFIX}.pkg"
    rm -f "$output"
    if [[ -n "${TAK_INSTALLER_SIGN_ID:-}" ]]; then run productbuild --sign "$TAK_INSTALLER_SIGN_ID" --package "$work/component.pkg" "$output";
    else run productbuild --package "$work/component.pkg" "$output"; fi
    if [[ -n "${TAK_INSTALLER_SIGN_ID:-}" ]]; then run pkgutil --check-signature "$output";
    else pkgutil --check-signature "$output" >>"$LOG" 2>&1 || true; fi
    printf '\nINSTALLER OK: %s\n' "$output"
}
menu(){
    printf '\nT-Verb - OWNER BUILD TOOLS (%s)\n1. Sinh khoa + tao Keygen.app\n2. Build VST3 + xuat file\n3. Tao bo cai .pkg\n4. Lam tat ca (1 -> 2 -> 3)\n5. Kiem tra goi xuat\n6. Mo ThuongHieu.json\n' "$SUFFIX"
    local choice;read -r -p 'Chon muc: ' choice
    case "$choice" in 1)init_keys;;2)build_release;;3)make_installer;;4)init_keys;build_release;make_installer;;5)verify_export;;6)open -e "$ROOT/ThuongHieu.json";;*)printf 'Khong thay doi gi.\n';;esac
}
case "$ACTION" in InitKeys)init_keys;;Build)build_release;;Export)export_files;;Installer)make_installer;;All)init_keys;build_release;make_installer;;Check)verify_export;;Config)open -e "$ROOT/ThuongHieu.json";;Menu)menu;;*)fail 'Unknown action';;esac
