# Thử vang vocal bằng FX Send trong Cubase

1. Tạo **FX Channel stereo**, đặt T-Verb trên FX đó. Kiểm tra FX return và đường ra Stereo Out không bị chuyển mono. Không kéo pan lệch để thay cho độ rộng reverb.
2. Giữ tiếng vocal trực tiếp ở track gốc. Trên plugin FX Send, dùng dry -∞ và wet 0 dB; điều chỉnh lượng vang bằng send từ vocal và fader return.
3. Chọn `Vocal Quyện - FX Send` để thử độ bám giọng. Chọn `Oang Rộng - FX Send` để thử không gian lớn và đuôi dài hơn.
4. Khởi đầu send khoảng -18 dB rồi tăng theo bài/vocal; so ở âm lượng tương đương, không chỉ tăng wet để nghe có vẻ hay hơn. Đây là mức gợi ý, không phải chuẩn cố định.
5. Nếu vang còn tách giọng, thử predelay 20–35 ms. Nếu bị che chữ, giảm send hoặc decay trước; nếu đục, chỉnh low-cut khoảng 130–180 Hz theo chất giọng. Thử nghe stereo và mono để kiểm tra độ rõ/lệch pha.

Hai preset Send mới là điểm khởi đầu, chưa được nghe cùng bản vocal thực tế của anh. Nếu khách nói thiếu quyện/rộng, cần so routing, mức send, predelay và bản thu trước khi quyết định thay thuật toán. Các preset `Insert` dành cho chèn trực tiếp, có giữ dry 0 dB; không dùng lẫn để đánh giá lượng vang trên FX Send.
