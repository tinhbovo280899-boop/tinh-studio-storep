# T-Verb 1.0.2 — Đóng plugin và preset vocal

Ngày 27/10/2026. Bản nguồn này tiếp tục các sửa DSP của 1.0.1. Người dùng báo đang dùng FX Send, cảm thấy vang chưa quyện/rộng và Cubase treo khi thoát. Chưa có bản thu, crash dump hoặc môi trường Cubase/Windows/macOS để tái hiện trực tiếp; không tuyên bố đã xác nhận hết treo trong Cubase.

## Đóng plugin

- Luồng kiểm tra bản quyền chỉ xử lý bản quyền/file; không còn gửi cập nhật giao diện/host. Như vậy destructor chờ luồng bản quyền không phụ thuộc việc message thread đang bận đóng host.
- Dùng timer trên message thread cho các hiệu chỉnh tham số. Sau `releaseResources` hoặc khi bắt đầu hủy processor, không gửi các hiệu chỉnh này về host nữa.
- Khi hủy, dừng timer, đặt cờ thoát, đánh thức và chờ worker kết thúc hợp tác. Không còn cưỡng bức giết worker sau 2 giây — hành động đó có thể để lại khóa đang giữ. LicenseManager kiểm tra cờ dừng giữa các bước đọc/ghi/xác minh.
- Khi hủy control, bỏ callback và bỏ nội dung số đang nhập trước khi tháo parameter attachment; không ghi một giá trị mới khi host đang đóng.

Các thay đổi loại bỏ những đường chờ/callback không an toàn đã tìm thấy. I/O hệ điều hành bị kẹt vẫn không thể bảo đảm ngắt ngay; không bỏ chờ rồi để luồng tiếp tục chạy trong DLL đã unload. Cần thử lại trên Cubase thực tế để kết luận nguyên nhân và hiệu quả.

## Tiếng vang và preset

Giữ nguyên thuật toán âm thanh đã sửa ở 1.0.1, toàn bộ 16 preset gốc, ID tham số và mặc định cũ. Thêm bốn preset ở cuối danh sách:

| Preset | Cách dùng | Decay | Predelay | Dry | Wet |
|---|---|---:|---:|---:|---:|
| Vocal Quyện - FX Send | FX Channel stereo | 2,5 s | 25 ms | -∞ | 0 dB |
| Oang Rộng - FX Send | FX Channel stereo | 3,8 s | 35 ms | -∞ | 0 dB |
| Vocal Quyện - Insert | Insert trực tiếp | 2,5 s | 25 ms | 0 dB | -15 dB |
| Oang Rộng - Insert | Insert trực tiếp | 3,8 s | 35 ms | 0 dB | -12 dB |

Đây là điểm khởi đầu để nghe thử, không phải chất âm đã được nghe/chốt theo vocal của khách. Mặc định cũ có predelay 70 ms; lượng vang vào muộn hơn có thể làm người nghe cảm thấy tách giọng. Tăng decay chỉ làm đuôi dài hơn, không tự bảo đảm rộng hoặc quyện hơn.

Phép thử xung mono qua engine stereo tại 48 kHz xác nhận có hai kênh khác nhau. Tương quan L/R của đuôi sau 150 ms ở preset mặc định khoảng -0,00235, không giống hai kênh bị trùng mono. Mẫu vang đầu có ý nghĩa xuất hiện khoảng 70,23 ms ở mặc định, 25,27 ms ở Vocal Quyện Send và 35,35 ms ở Oang Rộng Send. Đây là số đo engine, không đo được đường routing/monitoring hay chất âm chủ quan trong Cubase. Xem `VALIDATION/stereo_measurements.csv`.

Xem `HUONG_DAN_FX_SEND_VOCAL.md` để thử đúng routing và cân mức.

## Sinh key, trial, build và bộ cài

Giữ nguyên mã sinh key, cặp public/private key, brand/product ID và công cụ xuất/bộ cài. Không cần sinh lại khóa cho bản này. `trialDays=7` vẫn bật tự động từ lần đầu plugin kiểm tra bản quyền; không cần khách bấm nút dùng thử. Test dùng manager thật để xác nhận bắt đầu trial, ngày thứ sáu, hết bảy ngày, kích hoạt và hết hạn key.

## Kiểm chứng

- 317 phép kiểm tra DSP đạt: 183 cơ bản + 134 mở rộng, gồm 20 preset ở ba sample rates.
- 7/7 bộ CTest đạt trên Linux, gồm bài test shutdown mới.
- 60 lần tạo/hủy processor luân phiên trên message thread và thread khác đang giữ UI lock: đạt; lượt này thời gian hủy chậm nhất 9,5 ms. Kiểm tra cả trường hợp đang có hiệu chỉnh tham số chờ xử lý và không gửi hiệu chỉnh sau release.
- 24 kiểm tra license đạt, vẫn tự trial bảy ngày mà không bấm nút. Thêm kiểm tra cờ hủy tránh tạo I/O mới khi shutdown.
- Engine không cấp phát heap trong các lượt đo xử lý ổn định, đổi tham số/quality và block lớn hơn dự kiến.
- Build được VST3 Linux. Không build/xác nhận VST3 hoặc bộ cài Windows/macOS và không chạy Cubase ở môi trường này.

File ZIP là mã nguồn cho chủ dự án, có giữ khóa riêng như bản gốc. Không gửi nguyên ZIP này cho khách; dùng output build/installer. Trên máy đích, đóng Cubase hoàn toàn, build/cài bản 1.0.2, thử mở project, đóng cửa sổ plugin, lưu project rồi thoát Cubase nhiều lần. Nếu còn treo, cần phiên bản Cubase, hệ điều hành và dump/log lúc treo để tiếp tục xác định đúng luồng bị chặn.
