// SPDX-License-Identifier: AGPL-3.0-or-later
#include "LicenseManager.h"
#include <cmath>

namespace tak::license {
StorePaths StorePaths::under(const juce::File& root,const juce::String& productId) {
    const auto product=root.getChildFile(productId);
    return {product.getChildFile("license.taklic"),product.getChildFile("trial-state.json"),root.getChildFile("TrialState").getChildFile(productId+".json"),product.getChildFile("last-seen.txt")};
}
StorePaths StorePaths::forProduct(const Configuration& config) {
    auto root=juce::File::getSpecialLocation(juce::File::userApplicationDataDirectory);
   #if JUCE_MAC
    root=root.getChildFile("Application Support");
   #endif
    return under(root.getChildFile("T Studio").getChildFile("Licenses"),config.productId+"-"+config.brandId);
}
LicenseManager::LicenseManager(Configuration c,StorePaths p,juce::StringArray ids,bool autoStartTrial)
    :config(std::move(c)),paths(std::move(p)),machines(std::move(ids)),
     allowed(autoStartTrial && config.trialDays > 0),autoTrial(autoStartTrial) {
    state.allowed = allowed.load();
    state.status=juce::String::fromUTF8("Đang kiểm tra bản quyền...");
}
void LicenseManager::requestActivation(const juce::String& token) {
    const juce::ScopedLock sl(lock);pendingActivation=token.substring(0,32769);
}
Snapshot LicenseManager::snapshot() const {const juce::ScopedLock sl(lock);return state;}
void LicenseManager::publish(Snapshot s) {
    allowed.store(s.allowed,std::memory_order_release);const juce::ScopedLock sl(lock);state=std::move(s);
}
LicenseManager::Trial LicenseManager::readTrial() const {
    Trial result;
    for(const auto& file:{paths.trial,paths.trialBackup}){
        if(!file.existsAsFile())continue;result.exists=true;
        if(file.getSize()>2048)continue;
        const auto value=juce::JSON::parse(file.loadFileAsString());auto* obj=value.getDynamicObject();if(!obj)continue;
        auto first=obj->getProperty("first"),last=obj->getProperty("last");
        if(!(first.isInt()||first.isInt64())||!(last.isInt()||last.isInt64()))continue;
        const auto f=juce::int64(first),l=juce::int64(last);if(f<=0||l<f)continue;
        result.first=result.valid?std::min(result.first,f):f;result.last=std::max(result.last,l);result.valid=true;
    }
    return result;
}
bool LicenseManager::writeTrial(const Trial& t,juce::String& error) {
    auto* obj=new juce::DynamicObject;obj->setProperty("first",t.first);obj->setProperty("last",t.last);
    const auto text=juce::JSON::toString(juce::var(obj),true);
    if(!atomicWrite(paths.trial,text,error))return false;
    return atomicWrite(paths.trialBackup,text,error);
}
void LicenseManager::poll(juce::int64 now,const std::atomic<bool>* cancel) {
    const auto stopping=[cancel]{return cancel&&cancel->load(std::memory_order_acquire);};
    if(stopping())return;
    if(machines.isEmpty())machines=machineHashes();
    if(stopping())return;
    Snapshot next;next.fingerprint=machines.joinIntoString("\n");next.request=requestText(config,machines);
    auto trial=readTrial();
    if(stopping())return;
    if(trial.valid)maxObservedMs=std::max(maxObservedMs,trial.last);
    if(paths.lastSeen.existsAsFile()&&paths.lastSeen.getSize()<64){const auto s=paths.lastSeen.loadFileAsString().trim();if(s.isNotEmpty()&&s.containsOnly("0123456789"))maxObservedMs=std::max(maxObservedMs,s.getLargeIntValue());}
    if(now<=0||now+86400000LL<maxObservedMs){next.status=juce::String::fromUTF8("Kiểm tra lại ngày giờ của máy");next.details="System clock is behind the last recorded time.";publish(next);return;}
    maxObservedMs=std::max(maxObservedMs,now);const auto effectiveNow=maxObservedMs;
    juce::String incoming;{const juce::ScopedLock sl(lock);incoming.swapWith(pendingActivation);}
    if(incoming.isNotEmpty()){
        const auto checked=verify(incoming,config,machines,effectiveNow);
        if(stopping())return;
        if(!checked.valid)lastAction=juce::String::fromUTF8("Key không hợp lệ: ")+checked.error;
        else {juce::String error;if(atomicWrite(paths.license,incoming.trim(),error,true))lastAction=juce::String::fromUTF8("Đã kích hoạt thành công.");else lastAction=juce::String::fromUTF8("Không lưu được key: ")+error;}
    }
    const auto activationHistory=paths.license.getSiblingFile("activated-once.txt");
    Verification verified;
    if(paths.license.existsAsFile()&&paths.license.getSize()<=32768)verified=verify(paths.license.loadFileAsString(),config,machines,effectiveNow);
    if(stopping())return;

    // Automatic 7-day trial on first launch (without needing customer to click "Start Trial")
    const bool wantTrial = trialRequested.exchange(false) || (autoTrial && !verified.valid && !trial.exists && !activationHistory.existsAsFile() && !paths.license.existsAsFile() && config.trialDays > 0 && !machines.isEmpty());
    if(wantTrial){
        if(stopping())return;
        if(config.trialDays<=0)lastAction=juce::String::fromUTF8("Sản phẩm này không có thời gian dùng thử.");
        else if(activationHistory.existsAsFile()||paths.license.existsAsFile())lastAction=juce::String::fromUTF8("Máy đã dùng key; nhập key mới để gia hạn.");
        else if(trial.exists&&!trial.valid)lastAction=juce::String::fromUTF8("Dữ liệu dùng thử không hợp lệ; liên hệ hỗ trợ.");
        else if(!trial.valid){
            Trial started;started.exists=started.valid=true;started.first=started.last=effectiveNow;juce::String error;
            if(writeTrial(started,error)){trial=started;if(lastAction.isEmpty())lastAction=juce::String::fromUTF8("Đã tự động kích hoạt dùng thử ")+juce::String(config.trialDays)+juce::String::fromUTF8(" ngày.");lastPersistMs=effectiveNow;}
            else lastAction=juce::String::fromUTF8("Không lưu được ngày dùng thử: ")+error;
        }
    }

    if(stopping())return;
    if(verified.valid){
        if(!activationHistory.existsAsFile()){juce::String ignored;atomicWrite(activationHistory,"1",ignored);}
        next.allowed=next.activated=true;next.owner=verified.claims.owner;next.perpetual=verified.claims.expiresMs==0;
        next.daysLeft=next.perpetual?0:int(std::ceil((verified.claims.expiresMs-effectiveNow)/86400000.0));
        next.status=next.perpetual?juce::String::fromUTF8("Đã kích hoạt · Vĩnh viễn"):juce::String::fromUTF8("Đã kích hoạt · Còn ")+juce::String(next.daysLeft)+juce::String::fromUTF8(" ngày");
    }else if(trial.valid&&config.trialDays>0){
        next.trialStarted=true;
        next.daysLeft=std::max(0,int(std::ceil(config.trialDays-(effectiveNow-trial.first)/86400000.0)));
        next.allowed=next.daysLeft>0;
        next.status=next.allowed?juce::String::fromUTF8("Dùng thử · Còn ")+juce::String(next.daysLeft)+juce::String::fromUTF8(" ngày"):juce::String::fromUTF8("Đã hết thời gian dùng thử 7 ngày · Vui lòng nhập key");
    }else next.status=juce::String::fromUTF8("Chưa kích hoạt · Vui lòng nhập key bản quyền");
    next.trialAvailable=config.trialDays>0&&!trial.exists&&!activationHistory.existsAsFile()&&!paths.license.existsAsFile();
    if(machines.isEmpty()){next.allowed=false;next.status=juce::String::fromUTF8("Không đọc được mã máy");}
    if(next.allowed&&effectiveNow-lastPersistMs>=60000){
        if(stopping())return;
        juce::String error;atomicWrite(paths.lastSeen,juce::String(effectiveNow),error);
        if(trial.valid){trial.last=effectiveNow;writeTrial(trial,error);}lastPersistMs=effectiveNow;
    }
    next.details=lastAction;if(next.details.isEmpty()&&verified.error.isNotEmpty())next.details=verified.error;
    next.details+=juce::String::fromUTF8("\nTệp bản quyền: ")+paths.license.getFullPathName();
    if(!stopping())publish(std::move(next));
}
}
