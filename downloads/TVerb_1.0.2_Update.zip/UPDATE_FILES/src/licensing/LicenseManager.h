// SPDX-License-Identifier: AGPL-3.0-or-later
#pragma once
#include "LicenseCodec.h"
#include <atomic>

namespace tak::license {
struct StorePaths {
    juce::File license,trial,trialBackup,lastSeen;
    static StorePaths forProduct(const Configuration&);
    static StorePaths under(const juce::File&,const juce::String& productId);
};
struct Snapshot {
    bool allowed=false,activated=false,perpetual=false,trialStarted=false,trialAvailable=false;
    int daysLeft=0;
    juce::String status,details,owner,fingerprint,request;
};
// Construct without opening files. poll() and destruction are worker-side;
// the audio callback only reads isAllowed(), an atomic boolean.
// By default, autoStartTrial=true so customers immediately get the 7-day trial
// without needing to click any "Start Trial" button.
class LicenseManager {
public:
    LicenseManager(Configuration,StorePaths,juce::StringArray testMachines={},bool autoStartTrial=true);
    void poll(juce::int64 nowMs=juce::Time::getCurrentTime().toMilliseconds(),
              const std::atomic<bool>* cancel=nullptr);
    bool isAllowed() const noexcept {return allowed.load(std::memory_order_acquire);}
    void requestActivation(const juce::String&);
    void requestTrial() noexcept {trialRequested.store(true);}
    Snapshot snapshot() const;
private:
    struct Trial {bool exists=false,valid=false;juce::int64 first=0,last=0;};
    Trial readTrial() const;
    bool writeTrial(const Trial&,juce::String&);
    void publish(Snapshot);
    Configuration config;StorePaths paths;juce::StringArray machines;
    std::atomic<bool> allowed{true},trialRequested{false};
    bool autoTrial=true;
    mutable juce::CriticalSection lock;
    juce::String pendingActivation,lastAction;
    Snapshot state;
    juce::int64 maxObservedMs=0,lastPersistMs=0;
};
}
