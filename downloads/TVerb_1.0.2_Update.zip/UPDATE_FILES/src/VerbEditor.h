#pragma once
#include "VerbProcessor.h"
#include "OrbitValues.h"
#include <juce_gui_extra/juce_gui_extra.h>
#include "TVerbAssets.h"
#include "licensing/LicensePanel.h"

namespace tverb
{
namespace orbit
{
    inline juce::Colour ink()   { return juce::Colour (0xfff6e6ef); }
    inline juce::Colour muted() { return juce::Colour (0xffc6a5be); }
    inline juce::Colour peach() { return juce::Colour (0xffffbc9c); }
    inline juce::Colour lilac() { return juce::Colour (0xffaa87cd); }
    inline juce::Colour blue()  { return juce::Colour (0xff9dcbea); }
    inline juce::Colour line()  { return juce::Colour (0xff574052); }
    inline juce::Colour panel() { return juce::Colour (0xff211923); }

    // IMPORTANT: Never store a static juce::Typeface::Ptr at function/file scope in a VST3 DLL!
    // Static Typeface destructors run during DLL_PROCESS_DETACH after JUCE's DirectWrite/CoreText
    // factory has already shut down, causing Cubase to deadlock/freeze on exit.
    inline juce::Font font (float height, bool serif = true)
    {
       #if JUCE_WINDOWS
        const char* family = serif ? "Georgia" : "Segoe UI";
       #elif JUCE_MAC
        const char* family = serif ? "Times New Roman" : "Helvetica Neue";
       #else
        const char* family = serif ? "DejaVu Serif" : "DejaVu Sans";
       #endif
        return juce::Font (juce::FontOptions (family, height, juce::Font::plain));
    }

    inline void text (juce::Graphics& g, const juce::String& s,
                      juce::Rectangle<float> r, float size,
                      juce::Colour c = ink(), int align = juce::Justification::centred,
                      bool serif = true)
    {
        g.setColour (c);
        g.setFont (font (size, serif));
        g.drawText (s, r, align, true);
    }

    class Look : public juce::LookAndFeel_V4
    {
    public:
        Look()
        {
            setColour (juce::PopupMenu::backgroundColourId, juce::Colour (0xff251a2a));
            setColour (juce::PopupMenu::textColourId, ink());
            setColour (juce::PopupMenu::highlightedBackgroundColourId, juce::Colour (0xff624357));
            setColour (juce::PopupMenu::highlightedTextColourId, ink());
            setColour (juce::ComboBox::backgroundColourId, juce::Colour (0xff251b29));
            setColour (juce::ComboBox::textColourId, ink());
            setColour (juce::ComboBox::outlineColourId, line());
            setColour (juce::ComboBox::arrowColourId, muted());
            setColour (juce::TextEditor::backgroundColourId, juce::Colour (0xff2b1d30));
            setColour (juce::TextEditor::textColourId, ink());
            setColour (juce::TextEditor::outlineColourId, peach());
            setColour (juce::TextButton::buttonColourId, juce::Colour (0xff2a1c2b));
            setColour (juce::TextButton::textColourOffId, muted());
        }
        juce::Font getComboBoxFont (juce::ComboBox&) override { return font (23.0f); }
        juce::Font getPopupMenuFont() override { return font (19.0f); }
        juce::Font getTextButtonFont (juce::TextButton&, int h) override
        { return font (juce::jmin (23.0f, (float) h * 0.5f), false); }
        void drawButtonText (juce::Graphics& g, juce::TextButton& b, bool over, bool down) override
        {
            const auto id = b.getComponentID();
            if (id != "save-preset" && id != "load-preset")
            { juce::LookAndFeel_V4::drawButtonText (g,b,over,down); return; }
            auto r = b.getLocalBounds().toFloat().reduced (18,12);
            juce::Path icon;
            if (id == "save-preset")
            {
                icon.addRoundedRectangle (r,2);
                icon.addRectangle (r.getX()+5,r.getY(),r.getWidth()-10,r.getHeight()*0.42f);
                icon.addRectangle (r.getX()+5,r.getCentreY()+2,r.getWidth()-10,r.getHeight()*0.36f);
            }
            else
            {
                icon.startNewSubPath (r.getX(),r.getBottom());
                icon.lineTo (r.getX(),r.getY());
                icon.lineTo (r.getCentreX()-3,r.getY());
                icon.lineTo (r.getCentreX()+1,r.getY()+5);
                icon.lineTo (r.getRight(),r.getY()+5);
                icon.lineTo (r.getRight(),r.getBottom());
                icon.closeSubPath();
                icon.startNewSubPath (r.getX()+1,r.getY()+10);
                icon.lineTo (r.getRight()-1,r.getY()+10);
            }
            g.setColour (over || down ? peach() : muted());
            g.strokePath (icon,juce::PathStrokeType (1.7f));
        }
    };

    // ParameterAttachment marshals host automation to the message thread and
    // brackets each edit with host begin/end gestures. No UI state lives in DSP.
    class Control : public juce::Component, public juce::SettableTooltipClient
    {
    public:
        enum Style { rotary, horizontal, node, decay, readout };
        Control (Processor& p, const char* id, const char* title, Style s,
                 juce::Colour c = peach())
            : processor(p), param (*p.apvts.getParameter (id)), paramId (id), caption (title), style (s), accent (c)
        {
            setComponentID (id);
            setName (caption.isNotEmpty() ? caption : param.getName(40));
            setTooltip (caption + ": drag to adjust; Shift = fine. Double-click the value to type.");
            setMouseCursor (juce::MouseCursor::UpDownResizeCursor);
            addAndMakeVisible (valueLabel);
            valueLabel.setJustificationType (juce::Justification::centred);
            valueLabel.setColour (juce::Label::textColourId, accent);
            valueLabel.setColour (juce::Label::backgroundColourId, juce::Colours::transparentBlack);
            valueLabel.setColour (juce::Label::outlineColourId, juce::Colours::transparentBlack);
            valueLabel.setEditable (false, true, false);
            valueLabel.setTooltip ("Double-click to enter a value. Right-click the control to reset.");
            valueLabel.onEditorShow = [this]
            {
                valueLabel.getCurrentTextEditor()->setText (juce::String (value, 3), false);
                valueLabel.getCurrentTextEditor()->selectAll();
            };
            valueLabel.onTextChange = [this]
            {
                auto s = valueLabel.getText().trim();
                if (s.containsAnyOf ("0123456789"))
                {
                    float entered = s.getFloatValue();
                    if (s.containsIgnoreCase ("khz")) entered *= 1000.0f;
                    const auto r = param.getNormalisableRange();
                    attachment->setValueAsCompleteGesture (juce::jlimit (r.start, r.end, entered));
                }
                updateLabel();
            };
            attachment = std::make_unique<juce::ParameterAttachment> (
                param, [this] (float v) { value = v; updateLabel(); repaint(); }, nullptr);
            attachment->sendInitialUpdate();
        }
        ~Control() override
        {
            // Discard in-progress text edits and callbacks before detaching the
            // parameter. Never commit a new value while the host is tearing down.
            valueLabel.onTextChange = nullptr;
            valueLabel.onEditorShow = nullptr;
            valueLabel.hideEditor(true);
            if (dragging && processor.canNotifyHost()) attachment->endGesture();
            attachment.reset();
        }
        void configureNode (juce::Point<float> point, float titleY, float valueY)
        { anchor = point; labelY = titleY; numberY = valueY; resized(); }
        void setMuted (bool m) { if (m != mutedState) { mutedState = m; updateLabel(); repaint(); } }
        void resized() override
        {
            const int w = getWidth(), h = getHeight();
            if (style == node) valueLabel.setBounds (0, (int) numberY, w, 34);
            else if (style == decay) valueLabel.setBounds (0, 34, w, h - 36);
            else if (style == horizontal) valueLabel.setBounds (w - 136, 0, 134, 34);
            else if (style == readout) valueLabel.setBounds (0, caption.isEmpty() ? 0 : 27, w, caption.isEmpty() ? h : h - 27);
            else valueLabel.setBounds (0, h - 37, w, 34);
            valueLabel.setFont (font (style == decay ? 57.0f : (style == readout ? (caption.isEmpty() ? 19.0f : 26.0f) : 25.0f)));
        }
        void paint (juce::Graphics& g) override
        {
            const auto r = getLocalBounds().toFloat();
            const auto active = mutedState ? muted() : accent;
            if (style == node)
            {
                text (g, caption, {0, labelY, r.getWidth(), 30}, 23);
                g.setColour (active.withAlpha (isMouseOver() ? 0.18f : 0.08f));
                g.fillEllipse (anchor.x - 27, anchor.y - 27, 54, 54);
                g.setGradientFill (juce::ColourGradient (ink(), anchor.x - 8, anchor.y - 9,
                                                        active, anchor.x + 12, anchor.y + 17, false));
                g.fillEllipse (anchor.x - 14, anchor.y - 14, 28, 28);
                g.setColour (active.brighter (0.2f));
                g.drawEllipse (anchor.x - 15, anchor.y - 15, 30, 30, 1.5f);
                return;
            }
            if (style == decay)
            {
                text (g, caption, r.withHeight (34), 26);
                return;
            }
            if (style == readout)
            {
                text (g, caption, r.withHeight (27), 22);
                return;
            }
            if (style == horizontal)
            {
                text (g, caption, {0, 0, r.getWidth() - 140, 34}, 23, ink(),
                      juce::Justification::centredLeft);
                const float x0 = 8, x1 = r.getWidth() - 8, y = 55;
                g.setColour (juce::Colour (0xff100e16)); g.fillRoundedRectangle (x0, y - 4, x1 - x0, 8, 4);
                g.setColour (line()); g.drawRoundedRectangle (x0, y - 4, x1 - x0, 8, 4, 1);
                const float x = x0 + param.convertTo0to1 (value) * (x1 - x0);
                g.setGradientFill (juce::ColourGradient (lilac(), x0, y, active, x1, y, false));
                g.fillRoundedRectangle (x0, y - 4, juce::jmax (4.0f, x - x0), 8, 4);
                g.setColour (active); g.fillEllipse (x - 10, y - 10, 20, 20);
                g.setColour (ink().withAlpha (0.8f)); g.drawEllipse (x - 10, y - 10, 20, 20, 1);
                for (int i = 0; i <= 10; ++i)
                {
                    g.setColour (line());
                    const float tx = x0 + (x1 - x0) * i / 10.0f;
                    g.drawVerticalLine ((int) tx, y + 13, y + (i % 5 == 0 ? 24 : 19));
                }
                return;
            }
            text (g, caption, r.withHeight (30), 23);
            const float radius = juce::jmin (r.getWidth() * 0.30f, (r.getHeight() - 76) * 0.5f);
            const juce::Point<float> centre (r.getCentreX(), 40 + radius);
            const float start = -2.4f, end = 2.4f, a = start + (end - start) * param.convertTo0to1 (value);
            juce::Path track, arc;
            track.addCentredArc (centre.x, centre.y, radius + 8, radius + 8, 0, start, end, true);
            arc.addCentredArc (centre.x, centre.y, radius + 8, radius + 8, 0, start, a, true);
            g.setColour (line()); g.strokePath (track, juce::PathStrokeType (2));
            g.setColour (active.withAlpha (0.12f)); g.strokePath (arc, juce::PathStrokeType (12));
            g.setColour (active); g.strokePath (arc, juce::PathStrokeType (4, juce::PathStrokeType::curved,
                                                                           juce::PathStrokeType::rounded));
            g.setGradientFill (juce::ColourGradient (juce::Colour (0xff403048), centre.x - radius, centre.y - radius,
                                                     juce::Colour (0xff18121e), centre.x + radius, centre.y + radius, false));
            g.fillEllipse (centre.x - radius, centre.y - radius, radius * 2, radius * 2);
            g.setColour (active.withAlpha (0.65f));
            auto p1 = centre.getPointOnCircumference (radius * 0.65f, a);
            auto p2 = centre.getPointOnCircumference (radius * 0.88f, a);
            g.drawLine ({ p1, p2 }, 3);
        }
        void mouseDown (const juce::MouseEvent& e) override
        {
            if (e.mods.isPopupMenu())
            {
                attachment->setValueAsCompleteGesture (param.convertFrom0to1 (param.getDefaultValue()));
                return;
            }
            dragging = true;
            startNorm = param.convertTo0to1 (value);
            attachment->beginGesture();
            if (style == horizontal) mouseDrag (e);
        }
        void mouseDrag (const juce::MouseEvent& e) override
        {
            if (! dragging) return;
            const float fine = e.mods.isShiftDown() ? 0.1f : 1.0f;
            float n = startNorm + (float) (e.getDistanceFromDragStartX() - e.getDistanceFromDragStartY()) * fine / 260.0f;
            if (style == horizontal)
            {
                n = e.mods.isShiftDown() ? startNorm + e.getDistanceFromDragStartX() * 0.1f / (getWidth() - 16)
                                         : (e.position.x - 8) / (getWidth() - 16);
            }
            attachment->setValueAsPartOfGesture (param.convertFrom0to1 (juce::jlimit (0.0f, 1.0f, n)));
        }
        void mouseUp (const juce::MouseEvent&) override
        {
            if (dragging) { attachment->endGesture(); dragging = false; }
        }
        void mouseWheelMove (const juce::MouseEvent& e, const juce::MouseWheelDetails& w) override
        {
            if (valueLabel.isBeingEdited()) return;
            float n = param.convertTo0to1 (value) + (w.deltaY != 0 ? w.deltaY : w.deltaX)
                       * (w.isReversed ? -1.0f : 1.0f) * (e.mods.isShiftDown() ? 0.01f : 0.08f);
            attachment->setValueAsCompleteGesture (param.convertFrom0to1 (juce::jlimit (0.0f, 1.0f, n)));
        }
    private:
        void updateLabel()
        {
            if (! valueLabel.isBeingEdited())
                valueLabel.setText (mutedState ? "muted" : display (paramId, value), juce::dontSendNotification);
        }
        Processor& processor;
        juce::RangedAudioParameter& param;
        juce::String paramId, caption;
        Style style;
        juce::Colour accent;
        juce::Label valueLabel;
        float value = 0, startNorm = 0, labelY = 0, numberY = 30;
        juce::Point<float> anchor { 100, 70 };
        bool dragging = false, mutedState = false;
        std::unique_ptr<juce::ParameterAttachment> attachment;
    };

    // Interactive three-band damping plot. Ratios are time multipliers, not dB.
    // The quiet lower curve is a parameter-derived EQ response, never a fake FFT.
    class FrequencyDisplay : public juce::Component, public juce::SettableTooltipClient
    {
    public:
        explicit FrequencyDisplay (Processor& p) : proc (p)
        {
            setComponentID ("frequency-display");
            setTooltip ("Drag the three dots up/down for damping ratios; drag the crossover lines left/right.");
        }
        static float freqToNorm (float f) { return orbit::freqToNorm(f); }
        static float normToFreq (float n) { return orbit::normToFreq(n); }
        static float ratioToNorm (float r) { return orbit::ratioToNorm(r); }
        static float normToRatio (float n) { return orbit::normToRatio(n); }
        juce::Rectangle<float> plot() const { return getLocalBounds().toFloat().withTrimmedTop (5).withTrimmedBottom (35).reduced (13, 0); }
        void paint (juce::Graphics& g) override
        {
            auto r = plot();
            auto x = [&] (float f) { return r.getX() + r.getWidth() * freqToNorm (f); };
            auto y = [&] (float v) { return r.getBottom() - r.getHeight() * ratioToNorm (v); };
            for (float f : {20.0f,50.0f,100.0f,200.0f,500.0f,1000.0f,2000.0f,5000.0f,10000.0f,20000.0f})
            { g.setColour (line().withAlpha (0.36f)); g.drawVerticalLine ((int) x(f), r.getY(), r.getBottom()); }
            for (float v : {0.1f,0.5f,1.0f,2.0f,5.0f})
            {
                g.setColour (line().withAlpha (v == 1.0f ? 0.55f : 0.25f));
                g.drawHorizontalLine ((int) y(v), r.getX(), r.getRight());
            }
            const float lo = x (proc.param ("crosslo")), hi = x (proc.param ("crosshi"));
            const float ny[3] = { y(proc.param ("loratio")), y(proc.param ("midratio")), y(proc.param ("hiratio")) };
            const float nx[3] = { (r.getX()+lo)*0.5f, (lo+hi)*0.5f, (hi+r.getRight())*0.5f };
            const juce::Colour colours[3] = { blue(), ink(), peach() };
            juce::Path curve, fill;
            curve.startNewSubPath (r.getX(), ny[0]);
            curve.lineTo (nx[0], ny[0]);
            curve.cubicTo (lo, ny[0], lo, ny[1], nx[1], ny[1]);
            curve.cubicTo (hi, ny[1], hi, ny[2], nx[2], ny[2]);
            curve.lineTo (r.getRight(), ny[2]);
            fill = curve; fill.lineTo (r.getRight(), r.getBottom()); fill.lineTo (r.getX(), r.getBottom()); fill.closeSubPath();
            g.setGradientFill (juce::ColourGradient (peach().withAlpha (0.15f), r.getRight(), r.getY(),
                                                     lilac().withAlpha (0.02f), r.getX(), r.getBottom(), false));
            g.fillPath (fill);
            g.setGradientFill (juce::ColourGradient (blue(), r.getX(), r.getY(), peach(), r.getRight(), r.getY(), false));
            g.strokePath (curve, juce::PathStrokeType (2));
            // Plot the actual UI EQ approximation on a fixed -48..0 dB scale.
            juce::Path eq, eqFill;
            for (int i = 0; i <= 180; ++i)
            {
                const float f = normToFreq ((float)i / 180);
                double m2 = 1;
                if (proc.param ("locut") > 21)
                {
                    const double z = proc.param ("locut") / f, z2 = z*z;
                    m2 /= 1 + 4.25*z2 + z2*z2;
                }
                if (proc.param ("hicut") < 19999)
                {
                    const double z = f / proc.param ("hicut"), z2 = z*z;
                    m2 /= 1 + 4.25*z2 + z2*z2;
                }
                const float db = (float) (10 * std::log10 (juce::jmax (1.e-10, m2)));
                const float px = r.getX() + r.getWidth() * i / 180.0f;
                const float py = r.getBottom() - juce::jlimit (0.0f, 1.0f, (db+48)/48) * r.getHeight() * 0.32f;
                if (i == 0) eq.startNewSubPath (px,py); else eq.lineTo (px,py);
            }
            eqFill = eq; eqFill.lineTo (r.getRight(),r.getBottom()); eqFill.lineTo (r.getX(),r.getBottom()); eqFill.closeSubPath();
            g.setColour (lilac().withAlpha (0.10f)); g.fillPath (eqFill);
            g.setColour (lilac().withAlpha (0.40f)); g.strokePath (eq, juce::PathStrokeType (1));
            const float dash[2] = { 3, 4 };
            for (float cx : {lo,hi})
            {
                g.setColour (ink().withAlpha (0.4f));
                g.drawDashedLine (juce::Line<float> (cx,r.getY(),cx,r.getBottom()), dash, 2);
            }
            for (int i = 0; i < 3; ++i)
            {
                g.setColour (colours[i].withAlpha (0.13f)); g.fillEllipse (nx[i]-13,ny[i]-13,26,26);
                g.setColour (colours[i]); g.fillEllipse (nx[i]-6,ny[i]-6,12,12);
            }
            for (float f : {20.0f,100.0f,1000.0f,10000.0f,20000.0f})
            {
                const auto s = f >= 1000 ? juce::String ((int)(f/1000))+"k" : juce::String ((int)f);
                text (g,s,{x(f)-22,r.getBottom()+6,44,23},16,muted(),juce::Justification::centred,false);
            }
            text (g,"ratio (x)",{r.getX()+2,r.getY()+3,80,18},13,muted().withAlpha (0.8f),
                  juce::Justification::centredLeft,false);
        }
        int zone (juce::Point<float> pt) const
        {
            const auto r = plot();
            const float lo = r.getX()+r.getWidth()*freqToNorm (proc.param ("crosslo"));
            const float hi = r.getX()+r.getWidth()*freqToNorm (proc.param ("crosshi"));
            if (std::abs(pt.x-lo) < 10) return 3;
            if (std::abs(pt.x-hi) < 10) return 4;
            return pt.x < lo ? 0 : (pt.x < hi ? 1 : 2);
        }
        void mouseMove (const juce::MouseEvent& e) override
        { setMouseCursor (zone(e.position) >= 3 ? juce::MouseCursor::LeftRightResizeCursor : juce::MouseCursor::UpDownResizeCursor); }
        void mouseDown (const juce::MouseEvent& e) override
        {
            const char* ids[] = { "loratio", "midratio", "hiratio", "crosslo", "crosshi" };
            active = proc.apvts.getParameter (ids[zone(e.position)]);
            if (e.mods.isPopupMenu())
            {
                active->beginChangeGesture(); active->setValueNotifyingHost (active->getDefaultValue());
                active->endChangeGesture(); active = nullptr; repaint(); return;
            }
            startValue = active->convertFrom0to1 (active->getValue());
            active->beginChangeGesture(); mouseDrag (e);
        }
        void mouseDrag (const juce::MouseEvent& e) override
        {
            if (! active) return;
            const auto r = plot();
            float v = 0;
            if (active->getParameterID().startsWith ("cross"))
            {
                v = normToFreq ((e.position.x-r.getX())/r.getWidth());
                if (active->getParameterID() == "crosslo")
                    v = juce::jmin (v, proc.param ("crosshi"));
                else v = juce::jmax (v, proc.param ("crosslo"));
                const auto range = active->getNormalisableRange();
                v = juce::jlimit (range.start,range.end,v);
            }
            else v = normToRatio ((r.getBottom()-e.position.y)/r.getHeight());
            if (e.mods.isShiftDown()) v = startValue + (v-startValue)*0.1f;
            active->setValueNotifyingHost (active->convertTo0to1 (v)); repaint();
        }
        void mouseUp (const juce::MouseEvent&) override { finishGesture(); }
        ~FrequencyDisplay() override { finishGesture(); }
    private:
        void finishGesture() { if (active) { active->endChangeGesture(); active=nullptr; } }
        Processor& proc;
        juce::RangedAudioParameter* active = nullptr;
        float startValue = 0;
    };

    class Surface : public juce::Component, private juce::Timer
    {
    public:
        static constexpr int W = 1600, H = 1000;
        explicit Surface (Processor& p) : proc (p), frequency (p), tooltip (this, 700)
        {
            setSize (W,H);
            setOpaque (true);
            setLookAndFeel (&look);
            skin = juce::ImageFileFormat::loadFrom (TVerbAssets::OrbitSkin_png, TVerbAssets::OrbitSkin_pngSize);
            auto add = [this] (const char* id, const char* title, Control::Style style,
                              juce::Rectangle<int> r, juce::Colour c = peach()) -> Control&
            {
                auto item = std::make_unique<Control> (proc,id,title,style,c);
                item->setBounds (r); addAndMakeVisible (*item);
                auto& result = *item; controls.push_back (std::move (item)); return result;
            };
            add ("size","room size",Control::node,{60,112,210,115}).configureNode ({135,75},0,31);
            add ("width","room width",Control::node,{550,112,190,115}).configureNode ({70,75},0,31);
            add ("diffusion","diffusion",Control::node,{50,514,210,103}).configureNode ({145,20},29,59);
            add ("density","density",Control::node,{550,514,190,103}).configureNode ({70,20},29,59);
            add ("decay","decay",Control::decay,{242,317,330,119});
            add ("predelay","predelay",Control::rotary,{106,650,150,166});
            add ("attack","attack",Control::rotary,{330,650,150,166});
            add ("spread","spread",Control::rotary,{551,650,150,166});
            add ("loratio","lo ratio",Control::readout,{865,207,150,66},blue());
            add ("midratio","mid ratio",Control::readout,{1111,207,150,66},ink());
            add ("hiratio","hi ratio",Control::readout,{1357,207,150,66});
            add ("crosslo","",Control::readout,{972,446,145,62},muted());
            add ("crosshi","",Control::readout,{1264,446,145,62},muted());
            add ("locut","lo cut",Control::horizontal,{807,518,344,80},lilac());
            add ("hicut","hi cut",Control::horizontal,{1214,518,344,80});
            add ("echoint","intensity",Control::rotary,{794,681,164,139},lilac());
            add ("echosize","size",Control::rotary,{951,681,164,139});
            add ("mod","modulation",Control::rotary,{1179,681,164,139},lilac());
            add ("dry","dry",Control::horizontal,{165,883,515,84},lilac());
            add ("wet","wet",Control::horizontal,{964,883,515,84});
            addAndMakeVisible (frequency); frequency.setBounds (793,267,774,211);
            makeCombo (type, "type", {955,108,205,48}, getAARTypeNames(), "Room type");
            makeCombo (quality, "quality", {1381,739,180,47}, {"lo","normal","ultra"}, "Reverb quality");
            typeAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (proc.apvts,"type",type);
            qualityAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ComboBoxAttachment> (proc.apvts,"quality",quality);
            makeButton (preset,juce::String::fromUTF8 ("Mặc Định (Vang Dài Chuẩn)"),{705,18,435,50},[this]{showPresets();});
            makeButton (prev,juce::String::fromUTF8 ("‹"),{655,18,48,50},[this]{stepPreset(-1);});
            makeButton (next,juce::String::fromUTF8 ("›"),{1142,18,48,50},[this]{stepPreset(1);});
            makeButton (save,"S",{1227,19,63,48},[this]{savePreset();}); save.setTooltip ("Save preset (.tverb)");
            makeButton (load,"L",{1314,19,63,48},[this]{loadPreset();}); load.setTooltip ("Load preset (.tverb / .xml)");
            save.setComponentID("save-preset"); load.setComponentID("load-preset");
            makeButton (dryOn,"",{74,909,31,31},[]{}); dryOn.setClickingTogglesState (true);
            makeButton (wetOn,"",{873,909,31,31},[]{}); wetOn.setClickingTogglesState (true);
            dryOn.setTooltip ("Enable / mute dry"); wetOn.setTooltip ("Enable / mute wet");
            dryAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (proc.apvts,"dryon",dryOn);
            wetAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (proc.apvts,"weton",wetOn);
            makeButton (licenseBtn,juce::String::fromUTF8 ("BẢN QUYỀN"),{1390,19,146,48},[this]{showLicensePanel();});
            licenseBtn.setTooltip (juce::String::fromUTF8 ("Xem trạng thái dùng thử 7 ngày / Kích hoạt key bản quyền"));
            makeButton (bypass,"ON",{1547,21,38,43},[]{}); bypass.setClickingTogglesState (true);
            bypass.setTooltip ("Bypass");
            bypassAttachment = std::make_unique<juce::AudioProcessorValueTreeState::ButtonAttachment> (proc.apvts,"bypass",bypass);
            startTimerHz (24);
            timerCallback();
        }
        ~Surface() override
        {
            stopTimer();
            juce::PopupMenu::dismissAllActiveMenus();
            licensePanel.reset();
            chooser.reset();
            typeAttachment.reset();
            qualityAttachment.reset();
            dryAttachment.reset();
            wetAttachment.reset();
            bypassAttachment.reset();
            for (auto& c : controls) c->setLookAndFeel (nullptr);
            controls.clear();
            setLookAndFeel (nullptr);
        }
        void paint (juce::Graphics& g) override
        {
            g.fillAll (juce::Colour (0xff18121d));
            g.drawImage (skin,{0,0,(float)W,(float)H});
            g.setGradientFill (juce::ColourGradient (peach(),30,30,lilac(),227,60,false));
            g.setFont (font (64)); g.drawText ("T-Verb",juce::Rectangle<float>(34,4,212,72),juce::Justification::centredLeft);
            juce::Path wave;
            for (int i=0;i<96;++i)
            {
                float x=250+i*0.9f;
                float y=45+std::sin(i*0.66f)*std::exp(-i*0.044f)*20;
                if(i==0) wave.startNewSubPath(x,y); else wave.lineTo(x,y);
            }
            g.setColour (peach().withAlpha (0.7f)); g.strokePath(wave,juce::PathStrokeType(1.5f));
            text(g,"S P A T I A L   R E V E R B",{352,36,263,29},14,muted(),juce::Justification::centredLeft,false);
            section(g,"r o o m   d e s i g n",49,89,330);
            section(g,"t i m e   d e s i g n",49,627,300);
            section(g,"d a m p i n g  /  f r e q u e n c y   d i s p l a y",807,179,740);
            section(g,"e q",800,495,100);
            section(g,"e c h o",807,631,300);
            section(g,"m i s c",1190,631,300);
            section(g,"l e v e l",49,850,120);
            text(g,"Type",{817,109,125,47},25,ink(),juce::Justification::centredLeft);
            text(g,"quality",{1384,695,173,29},22);
            g.setColour (line().withAlpha (0.6f)); g.drawVerticalLine (1165,687,814);
            g.drawVerticalLine (805,874,964);
            text(g,"right-click: reset  /  Shift: fine",{77,972,580,18},12,muted().withAlpha(0.65f),
                 juce::Justification::centredLeft,false);
            // Only the narrow room glow responds to signal level; no background
            // image decoding or allocations occur on the audio callback.
            const float level=juce::jlimit(0.0f,1.0f,std::max(proc.vuOutL.load(),proc.vuOutR.load())*2);
            g.setColour (peach().withAlpha(level*0.10f));
            g.drawEllipse (99,79,613,550,2.0f);
        }
        Control* control (const juce::String& id) const
        {
            for(auto& c:controls) if(c->getComponentID()==id) return c.get();
            return nullptr;
        }
    private:
        static void section (juce::Graphics& g,const juce::String& name,float x,float y,float w)
        { text(g,name,{x,y,w,24},17,muted(),juce::Justification::centredLeft); }
        void makeCombo (juce::ComboBox& c,const char* id,juce::Rectangle<int> r,
                        const juce::StringArray& choices,const juce::String& tip)
        {
            c.addItemList(choices,1); c.setComponentID(id); c.setBounds(r); c.setTooltip(tip); addAndMakeVisible(c);
        }
        void makeButton(juce::TextButton& b,const juce::String& title,juce::Rectangle<int> r,std::function<void()> fn)
        {
            b.setButtonText(title); b.setBounds(r); b.onClick=std::move(fn); addAndMakeVisible(b);
        }
        void timerCallback() override
        {
            const auto name=loadedName.isNotEmpty() ? loadedName : proc.getProgramName(proc.getCurrentProgram());
            if(preset.getButtonText()!=name) preset.setButtonText(name);
            control("dry")->setMuted(proc.param("dryon")<0.5f);
            control("wet")->setMuted(proc.param("weton")<0.5f);
            const auto plot = frequency.plot();
            auto crossX = [&] (const char* id)
            {
                return juce::jlimit(803,1413,juce::roundToInt(frequency.getX()+plot.getX()
                    +plot.getWidth()*FrequencyDisplay::freqToNorm(proc.param(id)))-72);
            };
            int lx=crossX("crosslo"), hx=crossX("crosshi");
            if(hx-lx<146) { lx=juce::jmax(803,lx-(146-hx+lx)/2); hx=juce::jmin(1413,lx+146); lx=hx-146; }
            control("crosslo")->setBounds(lx,474,145,26);
            control("crosshi")->setBounds(hx,474,145,26);
            dryOn.setButtonText (proc.param("dryon")>0.5f ? juce::String::fromUTF8("●") : juce::String::fromUTF8("○"));
            wetOn.setButtonText (proc.param("weton")>0.5f ? juce::String::fromUTF8("●") : juce::String::fromUTF8("○"));
            bypass.setButtonText(proc.param("bypass")>0.5f?"OFF":"ON");
            const auto licSnap = proc.getLicenseSnapshot();
            licenseBtn.setTooltip (licSnap.status);
            const auto wantLicText = proc.hasLicenseAccess()
                ? juce::String::fromUTF8 ("BẢN QUYỀN")
                : juce::String::fromUTF8 ("NHẬP KEY");
            if (licenseBtn.getButtonText() != wantLicText)
                licenseBtn.setButtonText (wantLicText);
            frequency.repaint(); repaint(96,77,620,556);
        }
        void showLicensePanel()
        {
            auto safe = juce::Component::SafePointer<Surface> (this);
            licensePanel = std::make_unique<AutoKeyLicensePanel> (
                [safe] { return safe ? safe->proc.getLicenseSnapshot() : tak::license::Snapshot{}; },
                [safe] (const juce::String& text) { if (safe) safe->proc.activateLicense (text); },
                [safe] { if (safe) safe->proc.startLicenseTrial(); },
                [safe] { juce::MessageManager::callAsync ([safe] { if (safe) safe->licensePanel.reset(); }); });
            addAndMakeVisible (*licensePanel);
            licensePanel->setBounds (460, 220, 680, 400);
            licensePanel->toFront (false);
        }
        void stepPreset(int d)
        {
            loadedName.clear();
            proc.setCurrentProgram((proc.getCurrentProgram()+proc.getNumPrograms()+d)%proc.getNumPrograms());
            timerCallback();
        }
        void showPresets()
        {
            juce::PopupMenu m;
            for(int i=0;i<proc.getNumPrograms();++i)
                m.addItem(i+1,proc.getProgramName(i),true,i==proc.getCurrentProgram());
            m.showMenuAsync(juce::PopupMenu::Options().withTargetComponent(&preset),
                [safe=juce::Component::SafePointer<Surface>(this)](int result)
                {
                    if(safe && result>0) { safe->loadedName.clear(); safe->proc.setCurrentProgram(result-1); safe->timerCallback(); }
                });
        }
        void savePreset()
        {
            chooser=std::make_unique<juce::FileChooser>("Save T-Verb preset",juce::File(),"*.tverb");
            chooser->launchAsync(juce::FileBrowserComponent::saveMode|juce::FileBrowserComponent::canSelectFiles
                                 |juce::FileBrowserComponent::warnAboutOverwriting,
                [safe=juce::Component::SafePointer<Surface>(this)](const juce::FileChooser& fc)
                {
                    if(!safe || fc.getResult()==juce::File()) return;
                    const auto file=fc.getResult().withFileExtension(".tverb");
                    if(auto xml=safe->proc.apvts.copyState().createXml())
                    {
                        if(xml->writeTo(file)) safe->loadedName=file.getFileNameWithoutExtension();
                        else juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                                                                   "T-Verb","Could not save the preset.");
                    }
                });
        }
        void loadPreset()
        {
            chooser=std::make_unique<juce::FileChooser>("Load T-Verb preset",juce::File(),"*.tverb;*.xml");
            chooser->launchAsync(juce::FileBrowserComponent::openMode|juce::FileBrowserComponent::canSelectFiles,
                [safe=juce::Component::SafePointer<Surface>(this)](const juce::FileChooser& fc)
                {
                    if(!safe || !fc.getResult().existsAsFile()) return;
                    const auto file=fc.getResult();
                    if(auto xml=juce::XmlDocument::parse(file))
                    {
                        const auto state=juce::ValueTree::fromXml(*xml);
                        if(state.isValid() && state.hasType(safe->proc.apvts.state.getType()))
                        { safe->proc.apvts.replaceState(state); safe->loadedName=file.getFileNameWithoutExtension(); return; }
                    }
                    juce::AlertWindow::showMessageBoxAsync(juce::MessageBoxIconType::WarningIcon,
                                                          "T-Verb","This is not a valid T-Verb preset.");
                });
        }
        Processor& proc;
        Look look;
        juce::Image skin;
        FrequencyDisplay frequency;
        std::vector<std::unique_ptr<Control>> controls;
        juce::ComboBox type,quality;
        juce::TextButton preset,prev,next,save,load,dryOn,wetOn,licenseBtn,bypass;
        std::unique_ptr<juce::AudioProcessorValueTreeState::ComboBoxAttachment> typeAttachment,qualityAttachment;
        std::unique_ptr<juce::AudioProcessorValueTreeState::ButtonAttachment> dryAttachment,wetAttachment,bypassAttachment;
        std::unique_ptr<juce::FileChooser> chooser;
        std::unique_ptr<AutoKeyLicensePanel> licensePanel;
        juce::TooltipWindow tooltip;
        juce::String loadedName;
    };
}

class Editor : public juce::AudioProcessorEditor
{
public:
    explicit Editor(Processor& p) : AudioProcessorEditor(p), surface(p)
    {
        addAndMakeVisible(surface);
        setResizable(true,true);
        getConstrainer()->setFixedAspectRatio(1.6);
        setResizeLimits(800,500,1920,1200);
        setSize(1120,700);
    }
    void resized() override
    {
        surface.setBounds(0,0,orbit::Surface::W,orbit::Surface::H);
        surface.setTransform(juce::AffineTransform::scale((float)getWidth()/orbit::Surface::W,
                                                          (float)getHeight()/orbit::Surface::H));
        for(int i=0;i<getNumChildComponents();++i)
            if(auto* corner=dynamic_cast<juce::ResizableCornerComponent*>(getChildComponent(i))) corner->toFront(false);
    }
private:
    orbit::Surface surface;
};
}
