#pragma once
#include "TProc.h"
#include "FactoryPresets.h"
#include "ArtsAcousticTables.h"
#include "ArtsAcousticSubComponents.h"
#include "ArtsAcousticReverbDSP.h"
#include "ArtsAcousticParameters.h"
#include "licensing/LicenseManager.h"
#include "licensing/ProductConfig.h"

namespace tverb
{
    // Exact 13 ArtsAcoustic Reverb Room Type names (0x50eb .. 0x52c8)
    inline juce::StringArray getAARTypeNames()
    {
        return {
            "smooth", "small", "large", "medium", "strong",
            "fast", "open", "wide", "slap back", "dense",
            "impact", "light", "resonate"
        };
    }

    // Helper to build a NormalisableRange using ArtsAcoustic's exact non-linear scaling curves
    inline juce::NormalisableRange<float> makeSquareRange (float minVal, float maxVal)
    {
        return juce::NormalisableRange<float> (
            minVal, maxVal,
            [] (float s, float e, float norm) { return ArtsAcoustic::AARScaling::SquareFromNorm (norm, s, e); },
            [] (float s, float e, float val)  { return ArtsAcoustic::AARScaling::SquareToNorm (val, s, e); },
            [] (float s, float e, float val)  { return juce::jlimit (s, e, val); });
    }

    inline juce::NormalisableRange<float> makePowRange (float minVal, float maxVal, float exp = 2.0f)
    {
        return juce::NormalisableRange<float> (
            minVal, maxVal,
            [exp] (float s, float e, float norm) { return ArtsAcoustic::AARScaling::PowFromNorm (norm, s, e, exp); },
            [exp] (float s, float e, float val)  { return ArtsAcoustic::AARScaling::PowToNorm (val, s, e, exp); },
            [] (float s, float e, float val)     { return juce::jlimit (s, e, val); });
    }

    inline juce::NormalisableRange<float> makeRatioRange (float minVal = 0.05f, float maxVal = 5.0f)
    {
        return juce::NormalisableRange<float> (
            minVal, maxVal,
            [] (float s, float e, float norm) { return ArtsAcoustic::AARScaling::RatioFromNorm (norm, s, e); },
            [] (float s, float e, float val)  { return ArtsAcoustic::AARScaling::RatioToNorm (val, s, e); },
            [] (float s, float e, float val)  { return juce::jlimit (s, e, val); });
    }

    inline juce::NormalisableRange<float> makeDbSquareGainRange()
    {
        return juce::NormalisableRange<float> (
            -96.0f, 6.0f,
            [] (float s, float e, float norm)
            {
                float lin = ArtsAcoustic::AARScaling::SquareFromNorm (
                    norm, ArtsAcoustic::AARScaling::kMinGainLinear, ArtsAcoustic::AARScaling::kMaxGainLinear);
                return juce::jlimit (s, e, ArtsAcoustic::AARScaling::LinearGainToDb (lin));
            },
            [] (float /*s*/, float /*e*/, float db)
            {
                float lin = ArtsAcoustic::AARScaling::DbToLinearGain (db);
                return ArtsAcoustic::AARScaling::SquareToNorm (
                    lin, ArtsAcoustic::AARScaling::kMinGainLinear, ArtsAcoustic::AARScaling::kMaxGainLinear);
            },
            [] (float s, float e, float val) { return juce::jlimit (s, e, val); });
    }

    // Complete 25-parameter layout decompiled from DIR_vst::InitPresets (0x49da .. 0x7793)
    inline tkit::P layout()
    {
        tkit::P l;

        auto addCustomFloat = [&] (const char* id, const char* name, juce::NormalisableRange<float> range, float def, const char* unit)
        {
            l.add (std::make_unique<juce::AudioParameterFloat> (
                juce::ParameterID { id, 1 }, name, range, def,
                juce::AudioParameterFloatAttributes().withLabel (unit)));
        };

        // Tag 0 & 1: DryLevel & WetLevel (-96 dB .. +6 dB via CVstScalingSquare on linear gain)
        // Default matched to ArtsAcoustic Reverb VANG DAI reference: dry = -oo dB (-96.0f), wet = +0.84 dB
        addCustomFloat ("dry",       "DryLevel",     makeDbSquareGainRange(),             -96.0f,   "dB");
        addCustomFloat ("wet",       "WetLevel",     makeDbSquareGainRange(),              0.84f,   "dB");

        // Tag 2: Rev Type (13 room types)
        l.add (tkit::ch ("type",     "Rev Type",     getAARTypeNames(),                    0));

        // Tag 3..9: Time & Room Design (Default matched to ArtsAcoustic Reverb screenshot: 3.506s, 40m, 70%, 80%, 7%, 10%, 70ms)
        addCustomFloat ("decay",     "Decay",        makePowRange (0.2f, 45.2f, 2.0f),     3.506f,  "s");
        addCustomFloat ("size",      "Room Size",    makePowRange (2.0f, 62.0f, 2.0f),     40.0f,   "mtr");
        l.add (tkit::fl ("diffusion","Diffusion",    0.0f, 100.0f,                         70.0f,   0.0f, "%"));
        l.add (tkit::fl ("density",  "Density",      0.0f, 100.0f,                         80.0f,   0.0f, "%"));
        l.add (tkit::fl ("attack",   "Attack",       0.0f, 100.0f,                         7.0f,    0.0f, "%"));
        l.add (tkit::fl ("spread",   "Spread",       0.0f, 100.0f,                         10.0f,   0.0f, "%"));
        addCustomFloat ("predelay",  "Predelay",     makeSquareRange (0.0f, 1000.0f),      70.0f,   "ms");

        // Tag 10..14: 3-Band Damping Ratios & Crossover Frequencies
        addCustomFloat ("hiratio",   "Hi Ratio",     makeRatioRange (0.05f, 5.0f),         0.6f,    "x");
        addCustomFloat ("midratio",  "Mid Ratio",    makeRatioRange (0.05f, 5.0f),         1.0f,    "x");
        addCustomFloat ("loratio",   "Lo Ratio",     makeRatioRange (0.05f, 5.0f),         1.0f,    "x");
        addCustomFloat ("crosslo",   "Cross Lo-Mid", makeSquareRange (20.0f, 5500.0f),     800.0f,  "Hz");
        addCustomFloat ("crosshi",   "Cross Mid-Hi", makeSquareRange (200.0f, 16000.0f),   4000.0f, "Hz");

        // Tag 15..18: Room Width, Modulation, Echo
        l.add (tkit::fl ("width",    "Room Width",   -180.0f, 180.0f,                      160.0f,  0.0f, "deg"));
        l.add (tkit::fl ("mod",      "Modulation",   0.0f, 100.0f,                         10.0f,   0.0f, "%"));
        l.add (tkit::fl ("echoint",  "Echo Int",     0.0f, 100.0f,                         0.0f,    0.0f, "%"));
        l.add (tkit::fl ("echosize", "Echo Size",    50.0f, 750.0f,                        400.0f,  0.0f, "ms"));

        // Tag 19..20: Post-EQ Lo Cut & Hi Cut (120 Hz & 9819 Hz matching reference screenshot)
        addCustomFloat ("locut",     "Lo Cut",       makeSquareRange (20.0f, 10000.0f),    120.0f,  "Hz");
        addCustomFloat ("hicut",     "Hi Cut",       makeSquareRange (200.0f, 20000.0f),   9819.0f, "Hz");

        // Tag 21..24: Quality, Dry/Wet Enable, BitDepth (Locked to 64-Bit default)
        l.add (tkit::ch ("quality",  "Quality",      { "lo", "normal", "ultra" },          1));
        l.add (tkit::bo ("dryon",    "DryLevel Enable", true));
        l.add (tkit::bo ("weton",    "WetLevel Enable", true));
        l.add (tkit::ch ("bitdepth", "BitDepth",     { "32 Bit", "64 Bit" },               1));

        // Host Bypass
        l.add (tkit::bo ("bypass",   "Bypass",       false));
        return l;
    }

    /** 100% Decompiled ArtsAcoustic Reverb (AAR) Dual-Precision 64-Bit / 32-Bit Engine
        wrapped inside T-Verb's JUCE VST3 / Standalone AudioProcessor. */
    class Processor : public tkit::BaseProcessor, private juce::Thread, private juce::Timer
    {
    public:
        static constexpr const char* kParamIDs[ArtsAcoustic::kNumVstParameters] = {
            "dry", "wet", "type", "decay", "size", "diffusion", "density",
            "attack", "spread", "predelay", "hiratio", "midratio", "loratio",
            "crosslo", "crosshi", "width", "mod", "echoint", "echosize",
            "locut", "hicut", "quality", "dryon", "weton", "bitdepth"
        };

        explicit Processor (tak::license::StorePaths licensePaths =
            tak::license::StorePaths::forProduct(tak::license::productConfiguration()))
            : BaseProcessor (layout(), "T-Verb"), juce::Thread ("T-Verb License"),
              licensing(tak::license::productConfiguration(), std::move(licensePaths))
        {
            for (int i = 0; i < ArtsAcoustic::kNumVstParameters; ++i)
            {
                paramPtrs[i] = apvts.getParameter (kParamIDs[i]);
                lastNorm[i]  = -1.0f;
                parameterCorrections[static_cast<size_t>(i)].store(0, std::memory_order_relaxed);
            }
            syncParametersToEngine (true);
            startThread();
            startTimer(50);
        }

        ~Processor() override
        {
            shuttingDown.store(true, std::memory_order_release);
            processingActive.store(false, std::memory_order_release);
            stopTimer();
            signalThreadShouldExit();
            notify();
            // The worker never calls the UI/host and observes shuttingDown
            // between I/O/verification steps. Join cooperatively: forcibly
            // killing it can leave filesystem/JUCE locks held during DLL unload.
            stopThread (-1);
        }

        juce::AudioProcessorEditor* createEditor() override;

        void prepareToPlay (double sr, int block) override
        {
            prepareBase (sr, block);
            fs = (sr > 8000.0) ? sr : 44100.0;
            preparedBlockSize = std::max (512, block);
            scratchR.resize (static_cast<size_t>(preparedBlockSize));
            aarWrapper.setSampleRateAndBlockSize ((float) fs, preparedBlockSize);
            syncParametersToEngine (true);
            vuInL.store (0.0f);
            vuInR.store (0.0f);
            vuOutL.store (0.0f);
            vuOutR.store (0.0f);
            processingActive.store(true, std::memory_order_release);
        }

        void releaseResources() override
        {
            processingActive.store(false, std::memory_order_release);
            aarWrapper.suspend();
        }

        bool canNotifyHost() const noexcept
        {
            return !shuttingDown.load(std::memory_order_acquire)
                && processingActive.load(std::memory_order_acquire);
        }

        double getTailLengthSeconds() const override
        {
            // Allow two RT60 intervals plus predelay and reflection/echo build-up.
            // APVTS values are atomic, so the host can query this off the audio thread.
            const double ratio = std::max({double(param("loratio")),
                double(param("midratio")), double(param("hiratio"))});
            return 2.0 + 0.001 * param("predelay") + 2.0 * param("decay") * ratio;
        }

        void processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&) override
        {
            juce::ScopedNoDenormals nd;
            for (int c = getTotalNumInputChannels(); c < getTotalNumOutputChannels(); ++c)
                buffer.clear (c, 0, buffer.getNumSamples());

            syncParametersToEngine (false);

            if (! licensing.isAllowed())
            {
                // When 7-day automatic trial has expired and no key is activated:
                // If dry is muted (-oo dB on a Send FX track), output silence; otherwise pass dry input.
                if (param ("dryon") < 0.5f || param ("dry") <= -95.5f)
                    buffer.clear();
                vuInL.store (0.0f); vuInR.store (0.0f);
                vuOutL.store (0.0f); vuOutR.store (0.0f);
                return;
            }

            runWithBypass (buffer, [this] (juce::AudioBuffer<float>& b) { processAAR (b); });
            meterOut.update (buffer.getMagnitude (0, buffer.getNumSamples()), buffer.getNumSamples(), fs);
        }

        // Program / Factory Preset support
        int getNumPrograms() override { return (int) getFactoryPresets().size(); }
        int getCurrentProgram() override { return currentPresetIndex; }
        const juce::String getProgramName (int index) override
        {
            const auto& p = getFactoryPresets();
            if (index >= 0 && index < (int) p.size())
                return juce::String::fromUTF8 (p[(size_t) index].name);
            return juce::String::fromUTF8 ("Mặc Định (Vang Dài Chuẩn)");
        }
        void setCurrentProgram (int index) override
        {
            const auto& presets = getFactoryPresets();
            if (index < 0 || index >= (int) presets.size()) return;
            currentPresetIndex = index;
            const auto& pr = presets[(size_t) index];

            auto setVal = [this] (const char* id, float plainVal)
            {
                if (auto* p = apvts.getParameter (id))
                    p->setValueNotifyingHost (p->convertTo0to1 (plainVal));
            };

            setVal ("type",      (float) pr.type);
            setVal ("decay",     pr.decay);
            setVal ("predelay",  pr.predelay);
            setVal ("attack",    pr.attack);
            setVal ("spread",    pr.spread);
            setVal ("size",      pr.size);
            setVal ("width",     pr.width);
            setVal ("diffusion", pr.diffusion);
            setVal ("density",   pr.density);
            setVal ("dry",       pr.dryDb);
            setVal ("wet",       pr.wetDb);
            setVal ("dryon",     pr.dryOn ? 1.0f : 0.0f);
            setVal ("weton",     pr.wetOn ? 1.0f : 0.0f);
            setVal ("locut",     pr.loCut);
            setVal ("hicut",     pr.hiCut);
            setVal ("crosslo",   pr.crossLo);
            setVal ("crosshi",   pr.crossHi);
            setVal ("loratio",   pr.loRatio);
            setVal ("midratio",  pr.midRatio);
            setVal ("hiratio",   pr.hiRatio);
            setVal ("echoint",   pr.echoInt);
            setVal ("echosize",  pr.echoSize);
            setVal ("mod",       pr.mod);
            setVal ("quality",   (float) pr.quality);
        }

        // Access to underlying ArtsAcoustic engine for CReverbDisplay & CFreqDisplay
        ArtsAcoustic::CReverbBase* getReverbEngine() const { return aarWrapper.getReverbEngine(); }
        ArtsAcoustic::ArtsAcousticPluginWrapper& getWrapper() { return aarWrapper; }

        // License & Automatic 7-Day Trial access
        tak::license::Snapshot getLicenseSnapshot() const { return licensing.snapshot(); }
        bool hasLicenseAccess() const noexcept { return licensing.isAllowed(); }
        void activateLicense (const juce::String& text)
        {
            if (shuttingDown.load(std::memory_order_acquire)) return;
            licensing.requestActivation (text);
            licensePollRequested.store (true);
            notify();
        }
        void startLicenseTrial()
        {
            if (shuttingDown.load(std::memory_order_acquire)) return;
            licensing.requestTrial();
            licensePollRequested.store (true);
            notify();
        }

        // Stereo VU levels (0.0 .. 1.0 linear peak with original DIR_vst::DoVUInput/Output decay)
        std::atomic<float> vuInL { 0.0f }, vuInR { 0.0f };
        std::atomic<float> vuOutL { 0.0f }, vuOutR { 0.0f };

    private:
        void run() override
        {
            while (! threadShouldExit())
            {
                const auto now = juce::Time::getCurrentTime().toMilliseconds();
                if (licensePollRequested.exchange (false) || now >= nextLicensePollMs)
                {
                    licensing.poll (now, &shuttingDown);
                    nextLicensePollMs = now + 1000;
                }
                // Do not post messages or call host APIs from this worker.
                // Destruction may be waiting here while holding the UI lock.
                if (threadShouldExit() || shuttingDown.load(std::memory_order_acquire)) break;
                wait (200);
            }
        }
        void syncParametersToEngine (bool force) noexcept
        {
            // Never call setValueNotifyingHost from the audio thread or constructor/destructor,
            // as notifying the VST3 host off the message thread deadlocks Cubase on shutdown.
            for (int i = 0; i < ArtsAcoustic::kNumVstParameters; ++i)
            {
                if (! paramPtrs[i]) continue;
                float norm = paramPtrs[i]->getValue();
                if (force || std::fabs (norm - lastNorm[i]) > 1e-6f)
                {
                    lastNorm[i] = norm;
                    aarWrapper.setParameter (i, norm);
                }
            }
            for (int i : { ArtsAcoustic::kParam_CrossLoMid, ArtsAcoustic::kParam_CrossMidHi,
                           ArtsAcoustic::kParam_BitDepth })
            {
                const float requested = paramPtrs[i]->getValue();
                const float effective = aarWrapper.getParameter(i);
                if (std::fabs(requested - effective) > 1e-6f)
                {
                    uint32_t a = 0, b = 0;
                    std::memcpy(&a, &requested, sizeof(a));
                    std::memcpy(&b, &effective, sizeof(b));
                    parameterCorrections[static_cast<size_t>(i)].store(
                        (uint64_t(a) << 32) | b, std::memory_order_release);
                }
            }
        }

        void timerCallback() override
        {
            if (!canNotifyHost()) return;
            for (int i : { ArtsAcoustic::kParam_CrossLoMid, ArtsAcoustic::kParam_CrossMidHi,
                           ArtsAcoustic::kParam_BitDepth })
            {
                const auto packed = parameterCorrections[static_cast<size_t>(i)].exchange(0);
                if (packed == 0) continue;
                const uint32_t a = static_cast<uint32_t>(packed >> 32), b = static_cast<uint32_t>(packed);
                float expected = 0, effective = 0;
                std::memcpy(&expected, &a, sizeof(expected));
                std::memcpy(&effective, &b, sizeof(effective));
                // Do not overwrite newer user edits/automation with an old correction.
                if (canNotifyHost() && std::fabs(paramPtrs[i]->getValue() - expected) <= 1e-6f)
                    paramPtrs[i]->setValueNotifyingHost(effective);
            }
        }

        // Exact decompiled VU ballistics from DIR_vst::DoVUInput (0x9e32) & DoVUOutput (0x9eea)
        static void updateStereoVU (const float* L, const float* R, int n, double sampleRate,
                                    std::atomic<float>& stateL, std::atomic<float>& stateR) noexcept
        {
            const float decayCoeff = (float) (1.0 - 9.0 / std::max (8000.0, sampleRate));
            float envL = stateL.load (std::memory_order_relaxed);
            float envR = stateR.load (std::memory_order_relaxed);
            for (int i = 0; i < n; ++i)
            {
                float aL = std::fabs (L[i]);
                envL = (aL > envL) ? aL : (envL * decayCoeff);
                float aR = std::fabs (R[i]);
                envR = (aR > envR) ? aR : (envR * decayCoeff);
            }
            if (envL < 1e-4f) envL = 0.0f;
            if (envR < 1e-4f) envR = 0.0f;
            stateL.store (std::min (1.0f, envL), std::memory_order_relaxed);
            stateR.store (std::min (1.0f, envR), std::memory_order_relaxed);
        }

        void processAAR (juce::AudioBuffer<float>& b)
        {
            const int n = b.getNumSamples();
            const int numCh = b.getNumChannels();
            if (n <= 0 || numCh <= 0) return;

            if (n > preparedBlockSize)
            {
                for (int start = 0; start < n; start += preparedBlockSize)
                {
                    juce::AudioBuffer<float> chunk (b.getArrayOfWritePointers(), numCh,
                        start, std::min(preparedBlockSize, n - start));
                    processAAR(chunk);
                }
                return;
            }

            float* L = b.getWritePointer (0);
            float* R = (numCh > 1) ? b.getWritePointer (1) : scratchR.data();
            if (numCh == 1)
                std::memcpy (R, L, (size_t) n * sizeof (float));

            updateStereoVU (L, R, n, fs, vuInL, vuInR);

            float* ioPtrs[2] = { L, R };
            aarWrapper.processReplacing (ioPtrs, ioPtrs, n);

            updateStereoVU (L, R, n, fs, vuOutL, vuOutR);
        }

        double fs = 44100.0;
        ArtsAcoustic::ArtsAcousticPluginWrapper aarWrapper { 44100.0f, 512 };
        juce::RangedAudioParameter* paramPtrs[ArtsAcoustic::kNumVstParameters] {};
        float lastNorm[ArtsAcoustic::kNumVstParameters] {};
        std::vector<float> scratchR;
        int preparedBlockSize = 512;
        std::array<std::atomic<uint64_t>, ArtsAcoustic::kNumVstParameters> parameterCorrections {};
        int currentPresetIndex = 0;
        tak::license::LicenseManager licensing;
        std::atomic<bool> licensePollRequested { true };
        std::atomic<bool> shuttingDown { false }, processingActive { false };
        juce::int64 nextLicensePollMs = 0;
    };
}
