#pragma once
#include <vector>

namespace tverb
{
    struct FactoryPreset
    {
        const char* name;
        int   type;
        float decay, predelay, attack, spread;
        float size, width, diffusion, density;
        float dryDb, wetDb;
        bool  dryOn, wetOn;
        float loCut, hiCut;
        float crossLo, crossHi, loRatio, midRatio, hiRatio;
        float echoInt, echoSize;
        float mod;
        int   quality;
    };

    inline const std::vector<FactoryPreset>& getFactoryPresets()
    {
        static const std::vector<FactoryPreset> presets = {
            // Name                                    Type  Decay   Pre    Att   Spr   Size  Width  Diff  Dens  DryDb   WetDb  DryOn WetOn LoCut  HiCut    CrossLo CrossHi LoR   MidR  HiR   EchoI EchoS  Mod   Qual
            { "Mặc Định (Vang Dài Chuẩn)",             0,    3.506f, 70.0f, 7.0f, 10.0f,40.0f,160.0f,70.0f,80.0f,-96.0f, 0.84f, true, true, 120.0f,9819.0f, 800.0f, 4000.0f,1.00f,1.00f,0.60f,0.0f, 400.0f,10.0f,1 },
            { "Vang Trữ Tình - Bolero Ngọt",           2,    3.600f, 65.0f, 8.0f, 15.0f,44.0f,165.0f,75.0f,82.0f,-96.0f, 0.84f, true, true, 115.0f,10200.0f,750.0f, 4000.0f,1.00f,1.00f,0.65f,0.0f, 380.0f,12.0f,1 },
            { "Vang Bay Nhạc Trẻ - Ballad",            0,    3.200f, 55.0f, 5.0f, 12.0f,42.0f,165.0f,78.0f,85.0f,-96.0f, 0.80f, true, true, 130.0f,11500.0f,800.0f, 4200.0f,0.95f,1.00f,0.70f,0.0f, 400.0f,14.0f,1 },
            { "Khán Phòng Lớn (Oang & Rộng)",          2,    4.100f, 75.0f, 10.0f,20.0f,50.0f,175.0f,80.0f,86.0f,-96.0f, 0.84f, true, true, 100.0f,10500.0f,800.0f, 4000.0f,1.05f,1.00f,0.65f,0.0f, 420.0f,12.0f,1 },
            { "Vang Sân Khấu Live - Đám Cưới",         2,    3.400f, 60.0f, 8.0f, 18.0f,46.0f,170.0f,76.0f,84.0f,-96.0f, 1.00f, true, true, 125.0f,9800.0f, 750.0f, 3800.0f,0.95f,1.00f,0.62f,25.0f,360.0f,15.0f,1 },
            { "Vang Phòng Thu Ấm Áp (Plate)",          5,    2.400f, 35.0f, 0.0f, 10.0f,35.0f,160.0f,85.0f,88.0f,-96.0f, 0.50f, true, true, 130.0f,12500.0f,800.0f, 4500.0f,0.92f,1.00f,0.72f,0.0f, 320.0f,10.0f,1 },
            { "Vang Ngắn Làm Dày Giọng (Room)",        3,    1.650f, 25.0f, 4.0f, 12.0f,28.0f,150.0f,75.0f,82.0f,-96.0f, 0.00f, true, true, 140.0f,11000.0f,800.0f, 4000.0f,0.90f,1.00f,0.65f,0.0f, 300.0f,8.0f, 1 },
            { "Vang Sáng Tơi - Giọng Nữ Cao",          11,   3.300f, 60.0f, 8.0f, 16.0f,42.0f,170.0f,78.0f,80.0f,-96.0f, 0.84f, true, true, 135.0f,14500.0f,850.0f, 4800.0f,0.90f,1.00f,0.85f,0.0f, 380.0f,16.0f,1 },
            { "Vang Trầm Ấm - Giọng Nam Trung",        0,    3.450f, 70.0f, 7.0f, 10.0f,40.0f,160.0f,72.0f,82.0f,-96.0f, 0.84f, true, true, 110.0f,9500.0f, 800.0f, 3800.0f,1.02f,1.00f,0.58f,0.0f, 400.0f,10.0f,1 },
            { "Không Gian Mở Mênh Mông (Open)",        6,    4.500f, 65.0f, 20.0f,30.0f,52.0f,180.0f,80.0f,84.0f,-96.0f, 0.84f, true, true, 95.0f, 12000.0f,750.0f, 4200.0f,1.05f,1.00f,0.68f,12.0f,420.0f,20.0f,1 },
            { "Vang Stereo Siêu Rộng (Wide)",          7,    4.800f, 60.0f, 15.0f,25.0f,56.0f,180.0f,84.0f,88.0f,-96.0f, 0.84f, true, true, 100.0f,11800.0f,700.0f, 4000.0f,1.05f,1.00f,0.64f,0.0f, 440.0f,22.0f,1 },
            { "Phòng Gỗ Acoustic - Guitar/Piano",      1,    1.400f, 15.0f, 0.0f, 12.0f,22.0f,145.0f,68.0f,76.0f,-96.0f,-1.50f, true, true, 100.0f,10500.0f,650.0f, 3500.0f,0.92f,1.00f,0.60f,0.0f, 260.0f,8.0f, 1 },
            { "Vang Dội Nhịp Cổ Điển (Slapback)",      8,    1.200f, 65.0f, 0.0f, 18.0f,24.0f,140.0f,55.0f,70.0f,-96.0f,-1.00f, true, true, 120.0f,8800.0f, 750.0f, 3400.0f,0.88f,1.00f,0.55f,40.0f,190.0f,8.0f, 1 },
            { "Thánh Đường Ngân Dài (Cathedral)",      9,    6.200f, 45.0f, 18.0f,28.0f,58.0f,175.0f,90.0f,94.0f,-96.0f, 0.50f, true, true, 80.0f, 10200.0f,650.0f, 3600.0f,0.95f,1.00f,0.55f,0.0f, 480.0f,20.0f,1 },
            { "Vang Trống & Bộ Gõ (Drum Plate)",       4,    1.350f, 10.0f, 5.0f, 14.0f,30.0f,160.0f,84.0f,92.0f,-96.0f,-1.00f, true, true, 90.0f, 13500.0f,850.0f, 4800.0f,0.95f,1.00f,0.78f,0.0f, 300.0f,8.0f, 1 },
            { "Ngân Vang Huyền Ảo (Shimmer)",          12,   7.500f, 55.0f, 30.0f,45.0f,60.0f,180.0f,88.0f,92.0f,-96.0f, 0.84f, true, true, 90.0f, 14500.0f,700.0f, 4600.0f,1.05f,1.00f,0.80f,20.0f,460.0f,35.0f,1 },
            // Optional starting points. Original preset indices and defaults stay unchanged.
            { "Vocal Quyện - FX Send",                0,    2.500f, 25.0f, 3.0f, 24.0f,42.0f,170.0f,84.0f,90.0f,-96.0f, 0.00f, true, true, 150.0f,9500.0f, 750.0f, 4000.0f,0.85f,1.00f,0.70f,0.0f, 350.0f,14.0f,1 },
            { "Oang Rộng - FX Send",                  2,    3.800f, 35.0f, 7.0f, 28.0f,50.0f,175.0f,80.0f,90.0f,-96.0f, 0.00f, true, true, 130.0f,10500.0f,750.0f, 4000.0f,0.95f,1.00f,0.72f,0.0f, 400.0f,18.0f,1 },
            { "Vocal Quyện - Insert",                 0,    2.500f, 25.0f, 3.0f, 24.0f,42.0f,170.0f,84.0f,90.0f, 0.0f,-15.00f, true, true, 150.0f,9500.0f, 750.0f, 4000.0f,0.85f,1.00f,0.70f,0.0f, 350.0f,14.0f,1 },
            { "Oang Rộng - Insert",                   2,    3.800f, 35.0f, 7.0f, 28.0f,50.0f,175.0f,80.0f,90.0f, 0.0f,-12.00f, true, true, 130.0f,10500.0f,750.0f, 4000.0f,0.95f,1.00f,0.72f,0.0f, 400.0f,18.0f,1 }
        };
        return presets;
    }

}
