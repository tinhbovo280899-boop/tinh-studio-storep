# Liquid Delays II 2.7.1

- Overdrive hết offset trên input bằng 0; thêm DC blocker 5 Hz cho phần tạo màu, envelope tách L/R và tính theo sample rate. Bỏ nhánh lookahead 4 mẫu không được bù của phần drive cũ.
- LFO/filter dùng nhịp điều khiển 64 mẫu và nội suy hệ số; audio không phụ thuộc buffer khi thông số và lịch sự kiện giống nhau.
- Chuẩn hóa gain cực đại của filter/drive bên trong feedback để hạn chế tự dao động. Khi tăng resonance/drive, các lần lặp có thể nhẹ hơn bản cũ.
- Bypass tiếp tục cập nhật các bộ đệm và fade 5 ms; thay FX Mode/InLoop qua fade ngắn. Bổ sung host bypass và reset.
- Delay smoothing giữ cùng thời gian giữa các sample rate; các điều khiển gain/mix/enable được làm mượt. Đồng hồ có release theo mẫu.
- Tail khai báo theo delay/feedback hiện hành và phần dư lọc; không còn cố định 4 giây. Feedback lớn và delay dài có thể cho tail rất dài.

Xem README và VALIDATION cho cách build, dữ liệu đo và giới hạn kiểm tra.
