# Liquid Delays II 2.7.1 — bản sửa DSP

Mã nguồn C++17/JUCE 8 kèm bộ build Windows x64 và macOS Universal. Đây là bản sửa từ ZIP anh cung cấp; chưa có phép A/B chứng minh tương đương plugin thương mại gốc. ZIP không chứa binary Windows/macOS đã build sẵn.

Các sửa đổi chính:

- Overdrive hết offset trên input bằng 0; thêm DC blocker 5 Hz cho phần tạo màu, envelope tách L/R và tính theo sample rate. Bỏ nhánh lookahead 4 mẫu không được bù của phần drive cũ.
- LFO/filter dùng nhịp điều khiển 64 mẫu và nội suy hệ số; audio không phụ thuộc buffer khi thông số và lịch sự kiện giống nhau.
- Chuẩn hóa gain cực đại của filter/drive bên trong feedback để hạn chế tự dao động. Khi tăng resonance/drive, các lần lặp có thể nhẹ hơn bản cũ.
- Bypass tiếp tục cập nhật các bộ đệm và fade 5 ms; thay FX Mode/InLoop qua fade ngắn. Bổ sung host bypass và reset.
- Delay smoothing giữ cùng thời gian giữa các sample rate; các điều khiển gain/mix/enable được làm mượt. Đồng hồ có release theo mẫu.
- Tail khai báo theo delay/feedback hiện hành và phần dư lọc; không còn cố định 4 giây. Feedback lớn và delay dài có thể cho tail rất dài.

- Sửa dry mono input sang stereo output để cả L/R nhận tín hiệu mono. Giữ ID plugin, ID tham số, product/brand ID và public key hiện tại.
- Sửa script build/đóng gói: tự chọn Visual Studio/Build Tools 2019/2022/2026 phù hợp CMake, không ép VS 2022 hay Ninja. Script Mac dùng đúng target plugin.
- Build không gọi synchroniser thương hiệu cũ. Bộ đổi thương hiệu nay sinh đúng namespace AppBranding và giữ public key cho cùng thương hiệu.
- Owner Keygen dùng đúng codec TAK1/RSA-2048 của plugin, thay công cụ chữ ký rút gọn không tương thích. Logic xác minh key và dùng thử của plugin được giữ; mặc định tự bắt đầu dùng thử 7 ngày.

## Windows

1. Giải nén vào thư mục mới. Có CMake 3.22+, Visual Studio/Build Tools với Desktop development with C++ và Windows SDK. VS 2026 cần CMake hỗ trợ generator của nó (4.2+).
2. Chạy **3_BUILD_VA_TAO_BO_CAI.bat** để build VST3, DSP tests, owner Keygen, chạy kiểm tra, xuất bundle và tạo Setup.exe. Cần Inno Setup 6.3+ cho bước tạo bộ cài.
3. Chỉ build: **1_BUILD_WINDOWS.bat**. Bundle khách nằm trong `XuatBan`, bộ cài trong `Output`.
4. **4_KIEM_TRA_GOI.bat** kiểm tra source/bundle theo receipt và checksum; không thay cho bước build. Nếu lỗi, gửi `NHAT_KY_*.txt` mới nhất.

## macOS

Có Xcode Command Line Tools và CMake. Chạy **MAC_1_BUILD_VA_TAO_BO_CAI.command** để build VST3 Universal arm64+x86_64, DSP tests, owner Keygen và tạo `.pkg`. Các `.command` cần quyền chạy; có thể dùng `chmod +x *.command tools/mac.sh`. Cửa sổ `.command` có thể cần chuột phải → Open ở lần đầu.

`MAC_2_KIEM_TRA_CHIP.command` kiểm tra export/chữ ký/kiến trúc. Lệnh `MAC_3_KIEM_TRA_AUTO_KEY.command` giữ tên cũ nhưng nay chạy kiểm tra DSP, không còn đọc file Auto-Tune không liên quan. VST3 ở `_EXPORT_MAC/vst3`; bộ cài ở `Output`. Chữ ký mặc định là ad-hoc, không phải notarization thương mại.

## Key và dữ liệu chủ dự án

**File khóa riêng đã được loại khỏi ZIP tải về.** Bản gốc của anh vẫn có các khóa đó. Muốn tiếp tục dùng key cũ, giữ đúng private key khớp public key đang biên dịch; không tạo cặp mới chỉ để cập nhật DSP.

Sau khi build, Windows dùng **SINH_KEY.bat**, Mac dùng **MAC_SINH_KEY.command**. Chọn sinh file `.taklic` từ phiếu mã máy của khách, tên người dùng và số ngày (0 = vĩnh viễn). Công cụ xác minh chữ ký với public key đã biên dịch trước khi ghi file khách.

Chọn tạo cặp khóa mới là một thao tác riêng, chỉ thực hiện khi chủ chủ động chọn. Nó cập nhật public header và yêu cầu build lại; không dùng thao tác này thay cho việc phục hồi khóa cũ đã cấp cho khách. Owner utility ở `build_*/OwnerTools/Release`; chỉ gửi bundle/Setup/PKG trong thư mục export/Output cho khách.

## Kiểm tra và thay đổi chất tiếng

DSP tests chạy cả trong Release/NDEBUG. Có thể kiểm tra không cần JUCE/GUI:

```sh
cmake -S . -B build_dsp -DTAK_BUILD_PLUGIN=OFF -DBUILD_TESTING=ON -DCMAKE_BUILD_TYPE=Release
cmake --build build_dsp --config Release
ctest --test-dir build_dsp -C Release --output-on-failure
```

Đã kiểm tra DSP, processor mono/stereo/bypass/buffer và build VST3 trên Linux; xem `VALIDATION`. Chưa build hoặc chạy native Windows/macOS/Cubase. Bản này thay đổi đường xử lý và mức ra so với bản cũ; cân bằng lại gain/send khi nghe so sánh. Chưa có đánh giá nghe trên vocal của anh.
