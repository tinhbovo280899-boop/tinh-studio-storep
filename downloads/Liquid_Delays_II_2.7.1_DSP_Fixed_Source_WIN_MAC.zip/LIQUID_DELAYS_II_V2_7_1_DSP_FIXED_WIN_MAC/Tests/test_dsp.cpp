#include "TDelayDSP.h"
#include <cstdlib>
#include <iostream>

static void check(bool ok,const char* why){if(!ok){std::cerr<<"FAIL: "<<why<<'\n';std::exit(1);}}
static void drive()
{
    for(int sr:{8000,44100,48000,96000,192000})for(float amount:{0.f,.18f,.5f,1.f})
    {
        tdelay::COverdrive d;d.setDrive(amount);d.prepare(sr);
        for(int i=0;i<sr;++i){d.advance();check(d.processSample(0,0)==0&&d.processSample(1,0)==0,"Overdrive must never generate a signal from initial silence");}
        for(int i=0;i<sr;++i){d.advance();const float x=.5f*float(std::sin(tdelay::twoPi*440*i/sr));const float l=d.processSample(0,x),r=d.processSample(1,x);check(l==r&&std::isfinite(l),"drive must be stereo symmetric for identical signals");}
        for(int i=0;i<sr;++i){d.advance();d.processSample(0,0);d.processSample(1,0);}
        check(std::abs(d.processSample(0,0))<1e-8,"Overdrive/DC memory must settle back to silence");
    }
    std::cout<<"PASS zero-input/DC, stereo symmetry and sample rates\n";
}
static void delay()
{
    double minTau=100,maxTau=0;
    for(int sr:{44100,48000,96000,192000})
    {
        tdelay::CDelayLine d;d.prepare(sr);d.setTargetDelayMs(0,250);d.snapToTarget();d.setTargetDelayMs(0,500);
        for(int i=0;i<sr/50;++i){d.readSample(0,0);d.writeSample(0,0);}
        const double actual=d.getSmoothedDelayMs(0),tau=-20/std::log((500-actual)/250);
        minTau=std::min(minTau,tau);maxTau=std::max(maxTau,tau);
        d.setTargetDelayMs(0,100);d.snapToTarget();d.reset();int first=-1;
        for(int i=0;i<sr/2;++i){const float y=d.readSample(0,0);d.writeSample(0,i==0?.1f:0);if(std::abs(y)>1e-5f&&first<0)first=i;check(std::isfinite(y),"finite fractional delay");}
        check(first==sr/10,"100 ms impulse delay must use physical milliseconds");
        // Exercise circular wrap and maximum reads without changing capacity.
        d.setTargetDelayMs(0,15000);d.snapToTarget();
        for(int i=0;i<17*sr;++i){const float y=d.readSample(0,i%2?.1f:-.1f);d.writeSample(0,i%101==0?.01f:0);check(std::isfinite(y),"maximum delay and ring wrap");}
    }
    check(maxTau-minTau<1e-6,"delay smoothing time must match across sample rates");
    std::cout<<"PASS exact delay times, circular wrap and sample-rate-independent smoothing\n";
}
static void filters()
{
    for(int sr:{8000,44100,48000,96000,192000})for(bool highPass:{false,true})for(float resonance:{0.f,50.f,100.f})
    {
        tdelay::CPassFilters f;f.prepare(sr);f.setCoefficients(1200,resonance,highPass,0);double inPower=0,outPower=0;
        for(int i=0;i<sr;++i){f.advance();const float x=.01f*float(std::sin(tdelay::twoPi*1200*i/sr));const float y=f.processSample(0,x,1);check(std::isfinite(y),"HD/base filters must remain finite");if(i>sr/2){inPower+=double(x)*x;outPower+=double(y)*y;}}
        check(std::sqrt(outPower/inPower)<=f.getPeakGainBound()*1.01,"filter gain bound must cover its output");
        for(int block=0;block<100;++block){f.setCoefficients(block%2?22:sr*.48,resonance,highPass,64);for(int i=0;i<64;++i){f.advance();check(std::isfinite(f.processSample(0,.01f,1)),"filter coefficient transitions remain finite");}}
    }
    tdelay::CBrickWallLimiter limiter;limiter.prepare(48000);
    for(float x:{-10.f,-1.f,0.f,1.f,10.f})check(std::abs(limiter.processSample(0,x,true))<=.9951f,"sample-peak limiter bound");
    std::cout<<"PASS resonant/HD filters, gain bounds, coefficient changes and limiter\n";
}
int main(){drive();delay();filters();std::cout<<"ALL LIQUID DSP CHECKS PASSED (Release checks enabled).\n";}
