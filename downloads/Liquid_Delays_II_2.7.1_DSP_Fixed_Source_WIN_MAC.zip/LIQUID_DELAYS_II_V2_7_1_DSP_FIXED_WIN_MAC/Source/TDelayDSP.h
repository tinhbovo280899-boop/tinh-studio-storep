#pragma once
#include <algorithm>
#include <array>
#include <vector>
#include <cmath>
#include <cstdint>

namespace tdelay
{
constexpr double pi=3.14159265358979323846, twoPi=2*pi;
template<class T> T limit(T lo,T hi,T x) noexcept {return std::clamp(x,lo,hi);}


// Adapted from the supplied project; proprietary equivalence is unverified.
struct SyncDivisionInfo
{
    const char* label;
    double wholeBarRatio; // fraction of a 4/4 bar (4 beats)
};

static constexpr std::array<SyncDivisionInfo, 22> kSyncDivisions = {{
    { "1/32 Bar",  1.0 / 32.0 },
    { "1/16 Bar",  1.0 / 16.0 },
    { "1/8T Bar",  1.0 / 12.0 },
    { "1/16D Bar", 3.0 / 32.0 },
    { "1/8 Bar",   1.0 / 8.0  },
    { "1/4T Bar",  1.0 / 6.0  },
    { "1/8D Bar",  3.0 / 16.0 },
    { "1/4 Bar",   1.0 / 4.0  },
    { "1/2T Bar",  1.0 / 3.0  },
    { "1/4D Bar",  3.0 / 8.0  },
    { "1/2 Bar",   1.0 / 2.0  },
    { "1/2D Bar",  3.0 / 4.0  },
    { "1 Bar",     1.0        },
    { "2T Bar",    4.0 / 3.0  },
    { "1D Bar",    1.5        },
    { "2 bars",    2.0        },
    { "4T bars",   8.0 / 3.0  },
    { "3 bars",    3.0        },
    { "4 bars",    4.0        },
    { "5 bars",    5.0        },
    { "6 bars",    6.0        },
    { "7 bars",    7.0        }
}};

// Adapted from the supplied project; proprietary equivalence is unverified.
class CBrickWallLimiter
{
public:
    void prepare(double sampleRate)
    {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        // Release coefficient from 0x10002390: 1.0 - pow(10, -1 / (releaseMs * sr * 0.001))
        releaseCoeff = 1.0 - std::pow(10.0, -1.0 / (50.0 * sr * 0.001));
        reset();
    }

    void reset()
    {
        envL = 1.0f;
        envR = 1.0f;
    }

    inline float processSample(int ch, float x, bool enabled) noexcept
    {
        if (!enabled)
            return x;
        float& env = (ch == 0) ? envL : envR;
        const float absX = std::fabs(x);
        const float threshold = 0.98855f; // -0.1 dBFS ceiling
        if (absX > env)
            env = absX;
        else
            env += static_cast<float>(releaseCoeff) * (absX - env);
        if (env < threshold)
            env = threshold;
        float out = x * (threshold / env);
        return limit(-0.995f, 0.995f, out);
    }

private:
    double sr = 44100.0;
    double releaseCoeff = 0.001;
    float envL = 1.0f, envR = 1.0f;
};

// Adapted from the supplied project; proprietary equivalence is unverified.
class COverdrive
{
public:
    void prepare(double sampleRate) noexcept
    {
        const double sr=std::max(8000.0,sampleRate);
        envCoeff=-std::expm1(-1.0/(.025*sr));
        driveCoeff=-std::expm1(-1.0/(.020*sr));
        dcPole=std::exp(-twoPi*5.0/sr);reset();
    }
    void reset() noexcept
    {
        env.fill(0);dcInput.fill(0);dcOutput.fill(0);drive=targetDrive;updateDrive();
    }
    void setDrive(float value) noexcept {targetDrive=limit(0.f,1.f,value);}
    void advance() noexcept
    {
        if(drive!=targetDrive){drive+=driveCoeff*(targetDrive-drive);if(std::abs(targetDrive-drive)<1e-9)drive=targetDrive;updateDrive();}
    }
    double getFeedbackGainBound() const noexcept
    {
        return std::max(1.0,(1-drive)+drive*driveScale*makeup*.72);
    }
    float processSample(int ch,float x) noexcept
    {
        const auto c=std::size_t(ch);const double ax=std::abs(double(x));
        env[c]=ax>env[c]?ax:env[c]+envCoeff*(ax-env[c]);
        const double gain=threshold/std::max(threshold,env[c]);
        // Monotonic biased tanh; exactly zero at zero, without a delayed dry
        // blend. A normalised 5 Hz DC blocker removes rectification offset.
        const double shaped=(std::tanh(double(x)*driveScale+bias)-biasAtZero)*gain*makeup*.72;
        double high=.5*(1+dcPole)*(shaped-dcInput[c])+dcPole*dcOutput[c];
        if(std::abs(high)<1e-20)high=0;
        dcInput[c]=shaped;dcOutput[c]=high;
        return float((1-drive)*x+drive*high);
    }
private:
    void updateDrive() noexcept
    {
        threshold=std::pow(10.0,-drive*1.65);makeup=1+(1-(1-drive)*(1-drive))*1.85;
        driveScale=1+4.5*drive;bias=.08*drive;biasAtZero=std::tanh(bias);
    }
    double drive=0,targetDrive=0,threshold=1,makeup=1,driveScale=1,bias=0,biasAtZero=0;
    double envCoeff=.001,driveCoeff=.001,dcPole=.999;
    std::array<double,2> env {},dcInput {},dcOutput {};
};

class CPassFilters
{
public:
    void prepare(double sampleRate) noexcept
    {
        sr=std::max(8000.0,sampleRate);haveCoefficients=false;remaining=0;
        coeff.fill(0);target.fill(0);coeff[0]=coeff[5]=target[0]=target[5]=1;
        reset();
    }
    void reset() noexcept {z1.fill(0);z2.fill(0);h1.fill(0);h2.fill(0);}
    void setCoefficients(double cutoffHz,double resonancePct,bool highPass,int rampSamples=64) noexcept
    {
        const double fc=limit(20.0,sr*.485,cutoffHz);
        const double norm=limit(0.0,1.0,resonancePct*.01),q=.7071067811865476+norm*norm*5.2;
        auto make=[&](int offset,double quality){
            const double w=twoPi*fc/sr,c=std::cos(w),s=std::sin(w),inv=1/(1+s/(2*quality));
            target[std::size_t(offset)]=.5*(highPass?1+c:1-c)*inv;
            target[std::size_t(offset+1)]=(highPass?-(1+c):1-c)*inv;
            target[std::size_t(offset+2)]=target[std::size_t(offset)];
            target[std::size_t(offset+3)]=-2*c*inv;
            target[std::size_t(offset+4)]=(1-s/(2*quality))*inv;
        };
        make(0,q);make(5,.7071067811865476);
        const double nextBound=std::max(1.0,q/std::sqrt(1-1/(4*q*q)));
        peakBound=std::max(lastTargetBound,nextBound);lastTargetBound=nextBound;
        remaining=std::max(0,rampSamples);
        if(!haveCoefficients || remaining==0){coeff=target;remaining=0;haveCoefficients=true;}
    }
    void advance() noexcept
    {
        if(remaining>0){for(std::size_t i=0;i<coeff.size();++i)coeff[i]+=(target[i]-coeff[i])/remaining;--remaining;}
    }
    double getPeakGainBound() const noexcept {return peakBound;}
    float processSample(int ch,float input,double hdMix) noexcept
    {
        const auto c=std::size_t(ch);const double x=input;
        const double y=coeff[0]*x+z1[c];
        z1[c]=coeff[1]*x-coeff[3]*y+z2[c];z2[c]=coeff[2]*x-coeff[4]*y;
        // Stable Butterworth secondary section; unlike the old HD feedback,
        // its gain is <= 1. Keep running it while HD is deselected.
        const double h=coeff[5]*y+h1[c];
        h1[c]=coeff[6]*y-coeff[8]*h+h2[c];h2[c]=coeff[7]*y-coeff[9]*h;
        for(auto* state:{&z1[c],&z2[c],&h1[c],&h2[c]})if(std::abs(*state)<1e-20)*state=0;
        return float(y+hdMix*.5*(h-y));
    }
private:
    double sr=44100,peakBound=1,lastTargetBound=1;
    bool haveCoefficients=false;int remaining=0;
    std::array<double,10> coeff {},target {};
    std::array<double,2> z1 {},z2 {},h1 {},h2 {};
};

class CLFO
{
public:
    void prepare(double sampleRate)
    {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        phase = 0.0;
        shValue = 0.0f;
        rngState=0x12345678u;
    }

    void setParameters(float rateHz, float depthPct, int waveType) noexcept
    {
        rate = limit(0.02, 30.0, static_cast<double>(rateHz));
        depth = limit(0.0f, 1.0f, depthPct * 0.01f);
        waveform = limit(0, 4, waveType);
    }

    inline float tick() noexcept
    {
        const double inc = rate / sr;
        phase += inc;
        if (phase >= 1.0)
        {
            phase -= 1.0;
            // Update Sample & Hold value once per cycle
            rngState = rngState * 1664525u + 1013904223u;
            shValue = (static_cast<float>(rngState & 0x00ffffffu) / 8388608.0f) - 1.0f;
        }

        float raw = 0.0f;
        switch (waveform)
        {
            case 0: // Sine
                raw = std::sin(static_cast<float>(phase * twoPi));
                break;
            case 1: // Triangle
                raw = static_cast<float>(phase < 0.5 ? (phase * 4.0 - 1.0) : (3.0 - phase * 4.0));
                break;
            case 2: // SawUp
                raw = static_cast<float>(phase * 2.0 - 1.0);
                break;
            case 3: // Square
                raw = (phase < 0.5) ? 1.0f : -1.0f;
                break;
            case 4: // S&H
            default:
                raw = shValue;
                break;
        }
        return raw * depth;
    }

private:
    double sr = 44100.0;
    double phase = 0.0;
    double rate = 1.0;
    float depth = 0.5f;
    int waveform = 0;
    uint32_t rngState = 0x12345678u;
    float shValue = 0.0f;
};

// Adapted from the supplied project; proprietary equivalence is unverified.
class CDelayLine
{
public:
    void prepare(double sampleRate)
    {
        sr = sampleRate > 0.0 ? sampleRate : 44100.0;
        smoothingCoeff=-std::expm1(std::log1p(-.0015)*44100.0/sr);
        // Max 16 seconds delay buffer per channel 
        maxSamples = std::max(65536, static_cast<int>( std::ceil(sr * 16.0) ));
        for (int c = 0; c < 2; ++c)
        {
            buffer[c].assign(static_cast<size_t>(maxSamples), 0.0f);
            writePos[c] = 0;
            smoothDelaySamples[c] = sr * 0.25;
        }
    }

    void reset()
    {
        for (int c = 0; c < 2; ++c)
        {
            std::fill(buffer[c].begin(), buffer[c].end(), 0.0f);
            writePos[c] = 0;
        }
    }

    void snapToTarget() noexcept {smoothDelaySamples=targetDelaySamples;}
    double getSmoothedDelayMs(int ch) const noexcept {return smoothDelaySamples[std::size_t(ch)]*1000.0/sr;}
    void setTargetDelayMs(int ch, double delayMs) noexcept
    {
        double samps = (delayMs * 0.001) * sr;
        targetDelaySamples[ch] = limit(1.0, static_cast<double>(maxSamples - 8), samps);
    }

    inline float readSample(int ch, float lfoModSamples) noexcept
    {
        // Smooth delay time changes to avoid clicks when dragging knobs
        smoothDelaySamples[ch] += smoothingCoeff * (targetDelaySamples[ch] - smoothDelaySamples[ch]);
        double d = limit(1.0, static_cast<double>(maxSamples - 8),
                                smoothDelaySamples[ch] + static_cast<double>(lfoModSamples));

        double readIdx = static_cast<double>(writePos[ch]) - d;
        while (readIdx < 0.0)
            readIdx += static_cast<double>(maxSamples);

        int idx0 = static_cast<int>(readIdx);
        float frac = static_cast<float>(readIdx - static_cast<double>(idx0));

        const auto& buf = buffer[ch];
        int i_1 = (idx0 - 1 + maxSamples) % maxSamples;
        int i0  = idx0 % maxSamples;
        int i1  = (idx0 + 1) % maxSamples;
        int i2  = (idx0 + 2) % maxSamples;

        // 4-point Hermite polynomial interpolation for lush modulation
        float y_1 = buf[static_cast<size_t>(i_1)];
        float y0  = buf[static_cast<size_t>(i0)];
        float y1  = buf[static_cast<size_t>(i1)];
        float y2  = buf[static_cast<size_t>(i2)];

        float c0 = y0;
        float c1 = 0.5f * (y1 - y_1);
        float c2 = y_1 - 2.5f * y0 + 2.0f * y1 - 0.5f * y2;
        float c3 = 0.5f * (y2 - y_1) + 1.5f * (y0 - y1);
        return ((c3 * frac + c2) * frac + c1) * frac + c0;
    }

    inline void writeSample(int ch, float sampleToWrite) noexcept
    {
        // Anti-denormal 
        if (std::fabs(sampleToWrite) < 1.0e-18f)
            sampleToWrite = 0.0f;
        buffer[ch][static_cast<size_t>(writePos[ch])] = limit(-4.0f, 4.0f, sampleToWrite);
        if (++writePos[ch] >= maxSamples)
            writePos[ch] = 0;
    }

private:
    double sr = 44100.0;
    int maxSamples = 192000;
    double smoothingCoeff=.0015;
    std::array<std::vector<float>, 2> buffer;
    std::array<int, 2> writePos {{ 0, 0 }};
    std::array<double, 2> targetDelaySamples {{ 11025.0, 22050.0 }};
    std::array<double, 2> smoothDelaySamples {{ 11025.0, 22050.0 }};
};

struct FactoryPreset
{
    const char* name;
    int fxMode;         // 0..5
    float inputDb;      // -24..+24
    float outputDb;     // -24..+24
    float mixPct;       // 0..100
    bool dlyLOn;
    bool dlyROn;
    bool dlySync;
    int dlyLXTime;      // 0..21
    int dlyRXTime;      // 0..21
    bool dlyLDot;
    bool dlyRDot;
    bool dlyLTri;
    bool dlyRTri;
    float dlyTempo;     // 40..500
    float dlyFeedback;  // 0..100
    bool inLoop;
    bool filterOn;
    bool hdFilter;
    float lowCutHz;     // 22..11025
    float highCutHz;    // 200..22050
    float resonancePct; // 0..100
    float overdrivePct; // 0..100
    bool lfoOn;
    bool lfoSync;
    float lfoRateHz;    // 0.05..22
    float lfoDepthPct;  // 0..100
    int lfoWave;        // 0..4
    float stereoWidth;  // 0..100
    bool peakLimit;
};

} // namespace tdelay

