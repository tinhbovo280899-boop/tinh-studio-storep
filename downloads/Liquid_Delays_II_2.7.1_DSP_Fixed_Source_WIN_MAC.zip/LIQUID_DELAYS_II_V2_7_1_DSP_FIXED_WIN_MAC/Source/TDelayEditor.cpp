#include "TDelayEditor.h"
#include "BinaryData.h"

TDelayLookAndFeel::TDelayLookAndFeel()
{
    setColour(juce::Slider::textBoxTextColourId, juce::Colour(0xffe2f1ff));
    setColour(juce::Slider::textBoxBackgroundColourId, juce::Colour(0xff0b1320));
    setColour(juce::Slider::textBoxOutlineColourId, juce::Colour(0xff233854));
    setColour(juce::ComboBox::backgroundColourId, juce::Colour(0xff0d1726));
    setColour(juce::ComboBox::textColourId, juce::Colour(0xffe6f4ff));
    setColour(juce::ComboBox::outlineColourId, juce::Colour(0xff2c4b70));
    setColour(juce::PopupMenu::backgroundColourId, juce::Colour(0xff0d1726));
    setColour(juce::PopupMenu::textColourId, juce::Colour(0xffe6f4ff));
    setColour(juce::PopupMenu::highlightedBackgroundColourId, juce::Colour(0xff0088cc));
}

void TDelayLookAndFeel::drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                                         float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                                         juce::Slider& slider)
{
    const float radius = static_cast<float>(juce::jmin(width / 2, height / 2)) - 5.0f;
    const float centreX = static_cast<float>(x) + static_cast<float>(width) * 0.5f;
    const float centreY = static_cast<float>(y) + static_cast<float>(height) * 0.5f;
    const float rx = centreX - radius;
    const float ry = centreY - radius;
    const float rw = radius * 2.0f;
    const float angle = rotaryStartAngle + sliderPos * (rotaryEndAngle - rotaryStartAngle);

    // Outer shadow & brushed metal bezel
    g.setColour(juce::Colour(0x99000000));
    g.fillEllipse(rx + 1.5f, ry + 2.5f, rw, rw);

    juce::ColourGradient bodyGrad(juce::Colour(0xff2a394c), centreX, ry,
                                  juce::Colour(0xff0d141f), centreX, ry + rw, false);
    g.setGradientFill(bodyGrad);
    g.fillEllipse(rx, ry, rw, rw);

    g.setColour(juce::Colour(0xff3b526e));
    g.drawEllipse(rx, ry, rw, rw, 1.4f);

    // Inner cap
    const float innerR = radius * 0.74f;
    juce::ColourGradient capGrad(juce::Colour(0xff1e2a3a), centreX - innerR * 0.3f, centreY - innerR * 0.3f,
                                 juce::Colour(0xff0b1018), centreX + innerR * 0.5f, centreY + innerR * 0.5f, true);
    g.setGradientFill(capGrad);
    g.fillEllipse(centreX - innerR, centreY - innerR, innerR * 2.0f, innerR * 2.0f);

    // Background arc
    juce::Path bgArc;
    bgArc.addCentredArc(centreX, centreY, radius + 2.2f, radius + 2.2f, 0.0f, rotaryStartAngle, rotaryEndAngle, true);
    g.setColour(juce::Colour(0xff182638));
    g.strokePath(bgArc, juce::PathStrokeType(2.8f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    // Value glow arc
    juce::Colour accent = slider.findColour(juce::Slider::rotarySliderFillColourId);
    if (accent.isTransparent())
        accent = juce::Colour(0xff00d4ff);

    juce::Path valArc;
    valArc.addCentredArc(centreX, centreY, radius + 2.2f, radius + 2.2f, 0.0f, rotaryStartAngle, angle, true);
    g.setColour(accent);
    g.strokePath(valArc, juce::PathStrokeType(3.0f, juce::PathStrokeType::curved, juce::PathStrokeType::rounded));

    // Pointer line
    juce::Path p;
    const float pointerLength = innerR * 0.82f;
    p.addRoundedRectangle(-1.4f, -innerR, 2.8f, pointerLength, 1.2f);
    g.setColour(accent.brighter(0.45f));
    g.fillPath(p, juce::AffineTransform::rotation(angle).translated(centreX, centreY));
}

void TDelayLookAndFeel::drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                                         bool shouldDrawButtonAsHighlighted, bool)
{
    auto bounds = button.getLocalBounds().toFloat().reduced(1.5f);
    const bool on = button.getToggleState();

    juce::Colour baseCol = on ? juce::Colour(0xff0099cc) : juce::Colour(0xff142030);
    if (shouldDrawButtonAsHighlighted)
        baseCol = baseCol.brighter(0.15f);

    g.setColour(baseCol);
    g.fillRoundedRectangle(bounds, 4.5f);

    g.setColour(on ? juce::Colour(0xff5ce6ff) : juce::Colour(0xff2c425e));
    g.drawRoundedRectangle(bounds, 4.5f, 1.2f);

    // LED dot on left
    const float ledR = 3.5f;
    const float ledX = bounds.getX() + 8.0f;
    const float ledY = bounds.getCentreY() - ledR;
    g.setColour(on ? juce::Colour(0xff7affff) : juce::Colour(0xff384c66));
    g.fillEllipse(ledX, ledY, ledR * 2.0f, ledR * 2.0f);

    g.setColour(on ? juce::Colours::white : juce::Colour(0xffa9c1dc));
    g.setFont(juce::Font(juce::FontOptions(11.5f, juce::Font::bold)));
    auto textRect = bounds.withTrimmedLeft(18.0f);
    g.drawFittedText(button.getButtonText(), textRect.toNearestInt(), juce::Justification::centredLeft, 1);
}

void TDelayVisualizer::paint(juce::Graphics& g)
{
    auto r = getLocalBounds().toFloat();

    // Deep liquid glass display background
    juce::ColourGradient bg(juce::Colour(0xff07101c), r.getX(), r.getY(),
                            juce::Colour(0xff0e1e33), r.getX(), r.getBottom(), false);
    g.setGradientFill(bg);
    g.fillRoundedRectangle(r, 8.0f);

    g.setColour(juce::Colour(0xff26476e));
    g.drawRoundedRectangle(r.reduced(0.5f), 8.0f, 1.5f);

    // Subtle grid lines
    g.setColour(juce::Colour(0x224888c8));
    for (int i = 1; i < 8; ++i)
    {
        float x = r.getX() + r.getWidth() * (static_cast<float>(i) / 8.0f);
        g.drawVerticalLine(static_cast<int>(x), r.getY() + 4.0f, r.getBottom() - 4.0f);
    }
    for (int j = 1; j < 4; ++j)
    {
        float y = r.getY() + r.getHeight() * (static_cast<float>(j) / 4.0f);
        g.drawHorizontalLine(static_cast<int>(y), r.getX() + 4.0f, r.getRight() - 4.0f);
    }

    auto& apvts = processor.getAPVTS();
    const float lowCutHz   = apvts.getRawParameterValue("lowCut")->load();
    const float highCutHz  = apvts.getRawParameterValue("highCut")->load();
    const float resPct     = apvts.getRawParameterValue("resonance")->load();
    const float fbPct      = apvts.getRawParameterValue("dlyFeedback")->load();
    const float drivePct   = apvts.getRawParameterValue("overdrive")->load();
    const bool  dlyLOn     = apvts.getRawParameterValue("dlyLOn")->load() > 0.5f;
    const bool  dlyROn     = apvts.getRawParameterValue("dlyROn")->load() > 0.5f;
    const bool  filterOn   = apvts.getRawParameterValue("filterOn")->load() > 0.5f;
    const bool  lfoOn      = apvts.getRawParameterValue("lfoOn")->load() > 0.5f;
    const float delayMsL   = processor.getEffectiveDelayMsL();
    const float delayMsR   = processor.getEffectiveDelayMsR();
    const float lfoVal     = processor.getLfoMeter();

    // 1. Draw Filter Passband Curve in background
    if (filterOn)
    {
        juce::Path filterPath;
        const float plotTop = r.getY() + 18.0f;
        const float plotBot = r.getBottom() - 20.0f;
        const float plotH   = plotBot - plotTop;

        auto freqToNorm = [](float f) {
            return (std::log10(juce::jlimit(20.0f, 22050.0f, f)) - std::log10(20.0f))
                 / (std::log10(22050.0f) - std::log10(20.0f));
        };

        const float lcX = freqToNorm(lowCutHz);
        const float hcX = freqToNorm(highCutHz);
        const float resPeak = (resPct * 0.01f) * 0.28f;

        filterPath.startNewSubPath(r.getX(), plotBot);
        const int steps = 96;
        for (int i = 0; i <= steps; ++i)
        {
            float t = static_cast<float>(i) / static_cast<float>(steps);
            float x = r.getX() + t * r.getWidth();
            float hpGain = 1.0f / (1.0f + std::pow(juce::jmax(0.001f, lcX / juce::jmax(0.001f, t)), 4.0f));
            float lpGain = 1.0f / (1.0f + std::pow(juce::jmax(0.001f, t / juce::jmax(0.001f, hcX)), 4.0f));
            float resBump = resPeak * (std::exp(-std::pow((t - lcX) * 14.0f, 2.0f))
                                     + std::exp(-std::pow((t - hcX) * 14.0f, 2.0f)));
            float gain = juce::jlimit(0.0f, 1.15f, hpGain * lpGain + resBump);
            float y = plotBot - gain * (plotH * 0.72f);
            filterPath.lineTo(x, y);
        }
        juce::Path fillPath = filterPath;
        fillPath.lineTo(r.getRight(), plotBot);
        fillPath.closeSubPath();

        g.setColour(juce::Colour(0x2400d4ff));
        g.fillPath(fillPath);
        g.setColour(juce::Colour(0x9900d4ff));
        g.strokePath(filterPath, juce::PathStrokeType(1.6f));
    }

    // 2. Draw Stereo Delay Echo Tap Bars (Left = Cyan above center, Right = Amber/Magenta below center)
    const float midY = r.getCentreY() + 4.0f;
    const float maxDisplayMs = juce::jmax(1200.0f, juce::jmax(delayMsL, delayMsR) * 4.2f);
    const float fbRatio = juce::jlimit(0.05f, 0.92f, fbPct * 0.009f);

    g.setColour(juce::Colour(0x557098c0));
    g.drawHorizontalLine(static_cast<int>(midY), r.getX() + 8.0f, r.getRight() - 8.0f);

    for (int tap = 1; tap <= 8; ++tap)
    {
        float gain = std::pow(fbRatio, static_cast<float>(tap - 1));
        if (gain < 0.03f)
            break;

        if (dlyLOn)
        {
            float tMs = delayMsL * static_cast<float>(tap);
            float x = r.getX() + 18.0f + (tMs / maxDisplayMs) * (r.getWidth() - 36.0f);
            if (x < r.getRight() - 10.0f)
            {
                float barH = gain * (r.getHeight() * 0.38f);
                juce::Rectangle<float> bar(x - 3.5f, midY - barH, 7.0f, barH);
                g.setColour(juce::Colour(0xff00e5ff).withAlpha(0.35f + 0.6f * gain));
                g.fillRoundedRectangle(bar, 2.5f);
                g.setColour(juce::Colours::white.withAlpha(0.7f * gain));
                g.fillEllipse(x - 3.0f, midY - barH - 3.0f, 6.0f, 6.0f);
            }
        }

        if (dlyROn)
        {
            float tMs = delayMsR * static_cast<float>(tap);
            float x = r.getX() + 18.0f + (tMs / maxDisplayMs) * (r.getWidth() - 36.0f);
            if (x < r.getRight() - 10.0f)
            {
                float barH = gain * (r.getHeight() * 0.38f);
                juce::Rectangle<float> bar(x - 3.5f, midY, 7.0f, barH);
                juce::Colour rCol = (drivePct > 25.0f) ? juce::Colour(0xffff7b29) : juce::Colour(0xffff3898);
                g.setColour(rCol.withAlpha(0.35f + 0.6f * gain));
                g.fillRoundedRectangle(bar, 2.5f);
                g.setColour(juce::Colours::white.withAlpha(0.7f * gain));
                g.fillEllipse(x - 3.0f, midY + barH - 3.0f, 6.0f, 6.0f);
            }
        }
    }

    // 3. Top & Bottom HUD Readouts inside Visualizer
    g.setFont(juce::Font(juce::FontOptions(11.5f, juce::Font::bold)));
    g.setColour(juce::Colour(0xff7ce8ff));
    g.drawText(juce::String::formatted("L DELAY: %.1f ms", delayMsL),
               static_cast<int>(r.getX()) + 10, static_cast<int>(r.getY()) + 4, 150, 16,
               juce::Justification::centredLeft);

    g.setColour(juce::Colour(0xffff85bd));
    g.drawText(juce::String::formatted("R DELAY: %.1f ms", delayMsR),
               static_cast<int>(r.getX()) + 165, static_cast<int>(r.getY()) + 4, 150, 16,
               juce::Justification::centredLeft);

    g.setColour(juce::Colour(0xffffc857));
    g.drawText(juce::String::formatted("DRIVE: %.0f%% | FILTER: %.0fHz - %.0fHz", drivePct, lowCutHz, highCutHz),
               static_cast<int>(r.getRight()) - 255, static_cast<int>(r.getY()) + 4, 245, 16,
               juce::Justification::centredRight);

    // LFO modulation bar at bottom right
    if (lfoOn)
    {
        float lfoBarW = 90.0f;
        float lfoBarX = r.getRight() - lfoBarW - 10.0f;
        float lfoBarY = r.getBottom() - 14.0f;
        g.setColour(juce::Colour(0xff182c44));
        g.fillRoundedRectangle(lfoBarX, lfoBarY, lfoBarW, 8.0f, 3.0f);
        float dotX = lfoBarX + (lfoVal * 0.5f + 0.5f) * (lfoBarW - 8.0f);
        g.setColour(juce::Colour(0xff00ffaa));
        g.fillEllipse(dotX, lfoBarY, 8.0f, 8.0f);
    }
}

TDelayAudioProcessorEditor::TDelayAudioProcessorEditor(TDelayAudioProcessor& p)
    : AudioProcessorEditor(&p),
      audioProcessor(p),
      visualizer(p),
      licenseOverlay(
          [this]() { return audioProcessor.getLicenseManager().snapshot(); },
          [this](const juce::String& k) { audioProcessor.getLicenseManager().requestActivation(k); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { audioProcessor.getLicenseManager().requestTrial(); audioProcessor.refreshLicenseState(); updateLicenseBadge(); },
          [this]() { licenseOverlay.setVisible(false); updateLicenseBadge(); repaint(); }
      )
{
    setLookAndFeel(&customLookAndFeel);
    bgSkinImage = juce::ImageCache::getFromMemory(BinaryData::bg_skin_png, BinaryData::bg_skin_pngSize);

    addAndMakeVisible(visualizer);

    // Preset selector
    const auto& presets = TDelayAudioProcessor::getFactoryPresets();
    for (int i = 0; i < static_cast<int>(presets.size()); ++i)
        presetBox.addItem(juce::String::fromUTF8(presets[static_cast<size_t>(i)].name), i + 1);
    presetBox.setSelectedId(audioProcessor.getCurrentProgram() + 1, juce::dontSendNotification);
    presetBox.onChange = [this]
    {
        int idx = presetBox.getSelectedId() - 1;
        if (idx >= 0)
            audioProcessor.setCurrentProgram(idx);
    };
    addAndMakeVisible(presetBox);

    // FX Mode Routing Box
    fxModeBox.addItemList({
        "Filters -> Drive -> Delays",
        "Filters -> Delays -> Drive",
        "Delays -> Drive -> Filters",
        "Delays -> Filters -> Drive",
        "Drive -> Delays -> Filters",
        "Drive -> Filters -> Delays"
    }, 1);
    addAndMakeVisible(fxModeBox);
    fxModeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "fxMode", fxModeBox);

    // License button
    licenseBtn.setColour(juce::TextButton::buttonColourId, juce::Colour(0xff142840));
    licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff7affc6));
    licenseBtn.onClick = [this]
    {
        audioProcessor.refreshLicenseState();
        licenseOverlay.setVisible(!licenseOverlay.isVisible());
        if (licenseOverlay.isVisible())
            licenseOverlay.toFront(true);
        resized();
    };
    addAndMakeVisible(licenseBtn);

    // Sync division combos
    juce::StringArray syncNames;
    for (const auto& d : tdelay::kSyncDivisions)
        syncNames.add(d.label);
    dlyLXTimeBox.addItemList(syncNames, 1);
    dlyRXTimeBox.addItemList(syncNames, 1);
    addAndMakeVisible(dlyLXTimeBox);
    addAndMakeVisible(dlyRXTimeBox);
    dlyLXTimeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "dlyLXTime", dlyLXTimeBox);
    dlyRXTimeAtt = std::make_unique<ComboAttachment>(audioProcessor.getAPVTS(), "dlyRXTime", dlyRXTimeBox);

    // Toggle buttons
    for (auto* btn : { &dlyLOnBtn, &dlyROnBtn, &dlySyncBtn, &inLoopBtn,
                       &dlyLDotBtn, &dlyRDotBtn, &dlyLTriBtn, &dlyRTriBtn,
                       &filterOnBtn, &hdFilterBtn, &lfoOnBtn, &lfoSyncBtn,
                       &peakLimitBtn, &bypassBtn })
    {
        addAndMakeVisible(*btn);
    }

    auto& apvts = audioProcessor.getAPVTS();
    dlyLOnAtt    = std::make_unique<ButtonAttachment>(apvts, "dlyLOn",    dlyLOnBtn);
    dlyROnAtt    = std::make_unique<ButtonAttachment>(apvts, "dlyROn",    dlyROnBtn);
    dlySyncAtt   = std::make_unique<ButtonAttachment>(apvts, "dlySync",   dlySyncBtn);
    inLoopAtt    = std::make_unique<ButtonAttachment>(apvts, "inLoop",    inLoopBtn);
    dlyLDotAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyLDot",   dlyLDotBtn);
    dlyRDotAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyRDot",   dlyRDotBtn);
    dlyLTriAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyLTri",   dlyLTriBtn);
    dlyRTriAtt   = std::make_unique<ButtonAttachment>(apvts, "dlyRTri",   dlyRTriBtn);
    filterOnAtt  = std::make_unique<ButtonAttachment>(apvts, "filterOn",  filterOnBtn);
    hdFilterAtt  = std::make_unique<ButtonAttachment>(apvts, "hdFilter",  hdFilterBtn);
    lfoOnAtt     = std::make_unique<ButtonAttachment>(apvts, "lfoOn",     lfoOnBtn);
    lfoSyncAtt   = std::make_unique<ButtonAttachment>(apvts, "lfoSync",   lfoSyncBtn);
    peakLimitAtt = std::make_unique<ButtonAttachment>(apvts, "peakLimit", peakLimitBtn);
    bypassAtt    = std::make_unique<ButtonAttachment>(apvts, "bypass",    bypassBtn);

    // LFO Waveform combo
    lfoWaveBox.addItemList({ "Sine", "Triangle", "Saw", "Square", "S&H" }, 1);
    addAndMakeVisible(lfoWaveBox);
    lfoWaveAtt = std::make_unique<ComboAttachment>(apvts, "lfoWave", lfoWaveBox);

    // Rotary knobs
    setupRotaryKnob(dlyTempoSlider,    dlyTempoLabel,    "TEMPO",       " BPM");
    setupRotaryKnob(dlyFeedbackSlider, dlyFeedbackLabel, "FEEDBACK",    " %");
    setupRotaryKnob(lowCutSlider,      lowCutLabel,      "LOW CUT",     " Hz");
    setupRotaryKnob(resonanceSlider,   resonanceLabel,   "RESONANCE",   " %");
    setupRotaryKnob(highCutSlider,     highCutLabel,     "HIGH CUT",    " Hz");
    setupRotaryKnob(overdriveSlider,   overdriveLabel,   "TUBE DRIVE",  " %");
    setupRotaryKnob(lfoRateSlider,     lfoRateLabel,     "LFO RATE",    " Hz");
    setupRotaryKnob(lfoDepthSlider,    lfoDepthLabel,    "LFO DEPTH",   " %");
    setupRotaryKnob(inputLevelSlider,  inputLevelLabel,  "INPUT",       " dB");
    setupRotaryKnob(outputLevelSlider, outputLevelLabel, "OUTPUT",      " dB");
    setupRotaryKnob(stereoWidthSlider, stereoWidthLabel, "WIDTH",       " %");
    setupRotaryKnob(mixSlider,         mixLabel,         "DRY / WET",   " %");

    overdriveSlider.setColour(juce::Slider::rotarySliderFillColourId, juce::Colour(0xffff8c29));
    lfoRateSlider.setColour(juce::Slider::rotarySliderFillColourId,   juce::Colour(0xff00e89c));
    lfoDepthSlider.setColour(juce::Slider::rotarySliderFillColourId,  juce::Colour(0xff00e89c));
    mixSlider.setColour(juce::Slider::rotarySliderFillColourId,       juce::Colour(0xffff4ca8));

    dlyTempoAtt    = std::make_unique<SliderAttachment>(apvts, "dlyTempo",    dlyTempoSlider);
    dlyFeedbackAtt = std::make_unique<SliderAttachment>(apvts, "dlyFeedback", dlyFeedbackSlider);
    lowCutAtt      = std::make_unique<SliderAttachment>(apvts, "lowCut",      lowCutSlider);
    resonanceAtt   = std::make_unique<SliderAttachment>(apvts, "resonance",   resonanceSlider);
    highCutAtt     = std::make_unique<SliderAttachment>(apvts, "highCut",     highCutSlider);
    overdriveAtt   = std::make_unique<SliderAttachment>(apvts, "overdrive",   overdriveSlider);
    lfoRateAtt     = std::make_unique<SliderAttachment>(apvts, "lfoRate",     lfoRateSlider);
    lfoDepthAtt    = std::make_unique<SliderAttachment>(apvts, "lfoDepth",    lfoDepthSlider);
    inputLevelAtt  = std::make_unique<SliderAttachment>(apvts, "inputLevel",  inputLevelSlider);
    outputLevelAtt = std::make_unique<SliderAttachment>(apvts, "outputLevel", outputLevelSlider);
    stereoWidthAtt = std::make_unique<SliderAttachment>(apvts, "stereoWidth", stereoWidthSlider);
    mixAtt         = std::make_unique<SliderAttachment>(apvts, "mix",         mixSlider);

    addChildComponent(licenseOverlay);
    if (!audioProcessor.isPluginUnlocked())
        licenseOverlay.setVisible(true);

    updateLicenseBadge();
    setSize(860, 560);
    startTimerHz(30);
}

TDelayAudioProcessorEditor::~TDelayAudioProcessorEditor()
{
    stopTimer();
    setLookAndFeel(nullptr);
}

void TDelayAudioProcessorEditor::setupRotaryKnob(juce::Slider& s, juce::Label& l,
                                                 const juce::String& text, const juce::String& suffix)
{
    s.setSliderStyle(juce::Slider::RotaryHorizontalVerticalDrag);
    s.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 68, 17);
    if (suffix.isNotEmpty())
        s.setTextValueSuffix(suffix);
    addAndMakeVisible(s);

    l.setText(text, juce::dontSendNotification);
    l.setJustificationType(juce::Justification::centred);
    l.setColour(juce::Label::textColourId, juce::Colour(0xff9ec2e6));
    l.setFont(juce::Font(juce::FontOptions(11.0f, juce::Font::bold)));
    addAndMakeVisible(l);
}

void TDelayAudioProcessorEditor::updateLicenseBadge()
{
    const auto snap = audioProcessor.getLicenseManager().snapshot();
    if (snap.activated)
    {
        licenseBtn.setButtonText(juce::String::fromUTF8("Đã kích hoạt vĩnh viễn"));
        licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xff5effb8));
    }
    else if (snap.allowed)
    {
        licenseBtn.setButtonText(juce::String::fromUTF8("Dùng thử (còn ") + juce::String(snap.daysLeft) + juce::String::fromUTF8(" ngày)"));
        licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffffd166));
    }
    else
    {
        licenseBtn.setButtonText(juce::String::fromUTF8("Hết hạn dùng thử - Nhập Key"));
        licenseBtn.setColour(juce::TextButton::textColourOffId, juce::Colour(0xffff5c77));
    }
}

void TDelayAudioProcessorEditor::timerCallback()
{
    updateLicenseBadge();
    visualizer.repaint();
    repaint(0, 0, getWidth(), 56);
}

void TDelayAudioProcessorEditor::paint(juce::Graphics& g)
{
    auto bounds = getLocalBounds().toFloat();

    // Deep studio rack chassis gradient
    juce::ColourGradient chassis(juce::Colour(0xff0d1624), 0.0f, 0.0f,
                                 juce::Colour(0xff070c14), 0.0f, bounds.getHeight(), false);
    g.setGradientFill(chassis);
    g.fillRect(bounds);

    // Subtle texture blend from extracted Nomad Factory Liquid Delays II faceplate
    if (bgSkinImage.isValid())
    {
        g.setOpacity(0.11f);
        g.drawImageWithin(bgSkinImage, 0, 0, getWidth(), getHeight(), juce::RectanglePlacement::stretchToFit);
        g.setOpacity(1.0f);
    }

    // Top Header Bar
    juce::Rectangle<float> headerRect(10.0f, 8.0f, bounds.getWidth() - 20.0f, 44.0f);
    g.setColour(juce::Colour(0xff111e30));
    g.fillRoundedRectangle(headerRect, 7.0f);
    g.setColour(juce::Colour(0xff29466b));
    g.drawRoundedRectangle(headerRect, 7.0f, 1.2f);

    // Brand Title
    g.setColour(juce::Colour(0xff00e1ff));
    g.setFont(juce::Font(juce::FontOptions(20.0f, juce::Font::bold)));
    g.drawText("LIQUID DELAYS II", 22, 12, 210, 24, juce::Justification::centredLeft);

    g.setColour(juce::Colour(0xff9ab8d8));
    g.setFont(juce::Font(juce::FontOptions(10.5f, juce::Font::bold)));
    g.drawText("NOMAD FACTORY RETRO TUBE DELAY  |  NT STUDIO x64", 22, 32, 340, 16, juce::Justification::centredLeft);

    // Section Cards
    auto drawSectionPanel = [&](juce::Rectangle<float> rect, const juce::String& title, juce::Colour accentCol)
    {
        g.setColour(juce::Colour(0xcc0e1928));
        g.fillRoundedRectangle(rect, 8.0f);
        g.setColour(juce::Colour(0xff243d5c));
        g.drawRoundedRectangle(rect, 8.0f, 1.2f);

        juce::Rectangle<float> banner(rect.getX(), rect.getY(), rect.getWidth(), 24.0f);
        g.setColour(accentCol.withAlpha(0.18f));
        g.fillRoundedRectangle(banner, 8.0f);
        g.setColour(accentCol);
        g.setFont(juce::Font(juce::FontOptions(11.5f, juce::Font::bold)));
        g.drawText(title, banner.reduced(10.0f, 0.0f).toNearestInt(), juce::Justification::centredLeft);
    };

    drawSectionPanel({ 12.0f, 204.0f, 412.0f, 170.0f }, "DUAL STEREO DELAY ENGINE (LEFT / RIGHT SYNC)", juce::Colour(0xff00d9ff));
    drawSectionPanel({ 434.0f, 204.0f, 414.0f, 170.0f }, "LIQUID RESONANT FILTERS & TUBE OVERDRIVE",    juce::Colour(0xffff9233));
    drawSectionPanel({ 12.0f, 382.0f, 360.0f, 166.0f }, "LFO TAPE / FILTER MODULATION",                 juce::Colour(0xff00e89c));
    drawSectionPanel({ 382.0f, 382.0f, 466.0f, 166.0f }, "STEREO IMAGE, BRICKWALL LIMITER & MASTER MIX", juce::Colour(0xffff52a8));
}

void TDelayAudioProcessorEditor::resized()
{
    // Top bar layout
    presetBox.setBounds(255, 16, 235, 28);
    fxModeBox.setBounds(498, 16, 195, 28);
    licenseBtn.setBounds(701, 16, 140, 28);

    // Interactive Dual Tap & Filter Response Visualizer
    visualizer.setBounds(12, 58, getWidth() - 24, 138);

    // 1. Dual Stereo Delay Section (12, 204, 412, 170)
    dlyLOnBtn.setBounds(24, 236, 76, 24);
    dlyLXTimeBox.setBounds(106, 236, 98, 24);
    dlyLDotBtn.setBounds(210, 236, 62, 24);
    dlyLTriBtn.setBounds(276, 236, 62, 24);

    dlyROnBtn.setBounds(24, 268, 76, 24);
    dlyRXTimeBox.setBounds(106, 268, 98, 24);
    dlyRDotBtn.setBounds(210, 268, 62, 24);
    dlyRTriBtn.setBounds(276, 268, 62, 24);

    dlySyncBtn.setBounds(24, 304, 88, 24);
    inLoopBtn.setBounds(118, 304, 96, 24);

    dlyTempoLabel.setBounds(225, 294, 90, 16);
    dlyTempoSlider.setBounds(225, 308, 90, 62);

    dlyFeedbackLabel.setBounds(324, 232, 90, 16);
    dlyFeedbackSlider.setBounds(324, 248, 90, 118);

    // 2. Resonant Filters & Overdrive Section (434, 204, 414, 170)
    filterOnBtn.setBounds(446, 234, 96, 24);
    hdFilterBtn.setBounds(548, 234, 102, 24);

    lowCutLabel.setBounds(442, 262, 92, 16);
    lowCutSlider.setBounds(442, 278, 92, 88);

    resonanceLabel.setBounds(542, 262, 92, 16);
    resonanceSlider.setBounds(542, 278, 92, 88);

    highCutLabel.setBounds(642, 262, 92, 16);
    highCutSlider.setBounds(642, 278, 92, 88);

    overdriveLabel.setBounds(744, 236, 94, 16);
    overdriveSlider.setBounds(744, 252, 94, 114);

    // 3. LFO Modulation Section (12, 382, 360, 166)
    lfoOnBtn.setBounds(24, 414, 82, 24);
    lfoSyncBtn.setBounds(112, 414, 86, 24);
    lfoWaveBox.setBounds(24, 448, 174, 26);

    lfoRateLabel.setBounds(206, 414, 76, 16);
    lfoRateSlider.setBounds(206, 430, 76, 108);

    lfoDepthLabel.setBounds(286, 414, 76, 16);
    lfoDepthSlider.setBounds(286, 430, 76, 108);

    // 4. Master & Stereo Width Section (382, 382, 466, 166)
    peakLimitBtn.setBounds(394, 414, 104, 24);
    bypassBtn.setBounds(394, 446, 104, 24);

    inputLevelLabel.setBounds(504, 414, 80, 16);
    inputLevelSlider.setBounds(504, 430, 80, 108);

    outputLevelLabel.setBounds(588, 414, 80, 16);
    outputLevelSlider.setBounds(588, 430, 80, 108);

    stereoWidthLabel.setBounds(672, 414, 80, 16);
    stereoWidthSlider.setBounds(672, 430, 80, 108);

    mixLabel.setBounds(756, 414, 84, 16);
    mixSlider.setBounds(756, 430, 84, 108);

    licenseOverlay.setBounds(getLocalBounds());
}
