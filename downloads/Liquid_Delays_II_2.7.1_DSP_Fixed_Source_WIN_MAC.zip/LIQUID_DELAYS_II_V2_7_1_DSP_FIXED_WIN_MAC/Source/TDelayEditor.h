#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_graphics/juce_graphics.h>
#include <juce_gui_basics/juce_gui_basics.h>
#include "licensing/ProductConfig.h" 
#include "TDelayProcessor.h"
#include "licensing/LicensePanel.h"

class TDelayLookAndFeel : public juce::LookAndFeel_V4
{
public:
    TDelayLookAndFeel();
    void drawRotarySlider(juce::Graphics& g, int x, int y, int width, int height,
                          float sliderPos, float rotaryStartAngle, float rotaryEndAngle,
                          juce::Slider& slider) override;
    void drawToggleButton(juce::Graphics& g, juce::ToggleButton& button,
                          bool shouldDrawButtonAsHighlighted, bool shouldDrawButtonAsDown) override;
};

class TDelayVisualizer : public juce::Component
{
public:
    explicit TDelayVisualizer(TDelayAudioProcessor& p) : processor(p) {}
    void paint(juce::Graphics& g) override;

private:
    TDelayAudioProcessor& processor;
};

class TDelayAudioProcessorEditor : public juce::AudioProcessorEditor,
                                   private juce::Timer
{
public:
    explicit TDelayAudioProcessorEditor(TDelayAudioProcessor&);
    ~TDelayAudioProcessorEditor() override;

    void paint(juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void updateLicenseBadge();
    void setupRotaryKnob(juce::Slider& s, juce::Label& l, const juce::String& text, const juce::String& suffix = {});

    TDelayAudioProcessor& audioProcessor;
    TDelayLookAndFeel customLookAndFeel;
    TDelayVisualizer visualizer;
    juce::Image bgSkinImage;

    // Top bar controls
    juce::ComboBox presetBox;
    juce::ComboBox fxModeBox;
    juce::TextButton licenseBtn { juce::String::fromUTF8("Dùng thử 7 ngày") };

    // Delay Left & Right controls
    juce::ToggleButton dlyLOnBtn   { "L ON" };
    juce::ToggleButton dlyROnBtn   { "R ON" };
    juce::ToggleButton dlySyncBtn  { "SYNC" };
    juce::ToggleButton inLoopBtn   { "IN LOOP" };
    juce::ComboBox dlyLXTimeBox;
    juce::ComboBox dlyRXTimeBox;
    juce::ToggleButton dlyLDotBtn  { "L DOT" };
    juce::ToggleButton dlyRDotBtn  { "R DOT" };
    juce::ToggleButton dlyLTriBtn  { "L TRI" };
    juce::ToggleButton dlyRTriBtn  { "R TRI" };
    juce::Slider dlyTempoSlider, dlyFeedbackSlider;
    juce::Label  dlyTempoLabel,  dlyFeedbackLabel;

    // Filter & Tube Overdrive controls
    juce::ToggleButton filterOnBtn { "FILTER ON" };
    juce::ToggleButton hdFilterBtn { "HD 2-STAGE" };
    juce::Slider lowCutSlider, resonanceSlider, highCutSlider, overdriveSlider;
    juce::Label  lowCutLabel,  resonanceLabel,  highCutLabel,  overdriveLabel;

    // LFO Modulation controls
    juce::ToggleButton lfoOnBtn   { "LFO ON" };
    juce::ToggleButton lfoSyncBtn { "LFO SYNC" };
    juce::ComboBox lfoWaveBox;
    juce::Slider lfoRateSlider, lfoDepthSlider;
    juce::Label  lfoRateLabel,  lfoDepthLabel;

    // Master & Stereo Width controls
    juce::ToggleButton peakLimitBtn { "PEAK LIMIT" };
    juce::ToggleButton bypassBtn    { "BYPASS" };
    juce::Slider inputLevelSlider, outputLevelSlider, stereoWidthSlider, mixSlider;
    juce::Label  inputLevelLabel,  outputLevelLabel,  stereoWidthLabel,  mixLabel;

    // APVTS Attachments
    using SliderAttachment = juce::AudioProcessorValueTreeState::SliderAttachment;
    using ButtonAttachment = juce::AudioProcessorValueTreeState::ButtonAttachment;
    using ComboAttachment  = juce::AudioProcessorValueTreeState::ComboBoxAttachment;

    std::unique_ptr<ComboAttachment>  fxModeAtt, dlyLXTimeAtt, dlyRXTimeAtt, lfoWaveAtt;
    std::unique_ptr<ButtonAttachment> dlyLOnAtt, dlyROnAtt, dlySyncAtt, inLoopAtt;
    std::unique_ptr<ButtonAttachment> dlyLDotAtt, dlyRDotAtt, dlyLTriAtt, dlyRTriAtt;
    std::unique_ptr<ButtonAttachment> filterOnAtt, hdFilterAtt, lfoOnAtt, lfoSyncAtt;
    std::unique_ptr<ButtonAttachment> peakLimitAtt, bypassAtt;
    std::unique_ptr<SliderAttachment> dlyTempoAtt, dlyFeedbackAtt;
    std::unique_ptr<SliderAttachment> lowCutAtt, resonanceAtt, highCutAtt, overdriveAtt;
    std::unique_ptr<SliderAttachment> lfoRateAtt, lfoDepthAtt;
    std::unique_ptr<SliderAttachment> inputLevelAtt, outputLevelAtt, stereoWidthAtt, mixAtt;

    AutoKeyLicensePanel licenseOverlay;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TDelayAudioProcessorEditor)
};
