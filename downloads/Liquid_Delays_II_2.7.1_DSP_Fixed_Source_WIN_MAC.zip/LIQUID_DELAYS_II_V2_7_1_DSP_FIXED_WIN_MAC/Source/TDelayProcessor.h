#pragma once

#include <juce_core/juce_core.h>
#include <juce_audio_basics/juce_audio_basics.h>
#include <juce_audio_processors/juce_audio_processors.h>
#include "licensing/ProductConfig.h" 
#include <array>
#include <vector>
#include <atomic>
#include "AppBranding.h"
#include "licensing/LicenseManager.h"

#include "TDelayDSP.h"

class TDelayAudioProcessor : public juce::AudioProcessor
{
public:
    TDelayAudioProcessor();
    ~TDelayAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void processBlockBypassed(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    void reset() override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return AppBranding::kAppDisplayName; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override;

    int getNumPrograms() override;
    int getCurrentProgram() override { return currentPresetIndex; }
    void setCurrentProgram(int index) override;
    const juce::String getProgramName(int index) override;
    void changeProgramName(int index, const juce::String& newName) override;

    void getStateInformation(juce::MemoryBlock& destData) override;
    void setStateInformation(const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState& getAPVTS() noexcept { return apvts; }
    tak::license::LicenseManager& getLicenseManager() noexcept { return licenseManager; }
    bool isPluginUnlocked() const noexcept { return pluginUnlocked.load(std::memory_order_relaxed); }
    void refreshLicenseState();

    // Real-time UI meters (0x50c..0x51c in CNomadVST)
    float getInputLevelL() const noexcept  { return meterInL.load(std::memory_order_relaxed); }
    float getInputLevelR() const noexcept  { return meterInR.load(std::memory_order_relaxed); }
    float getOutputLevelL() const noexcept { return meterOutL.load(std::memory_order_relaxed); }
    float getOutputLevelR() const noexcept { return meterOutR.load(std::memory_order_relaxed); }
    float getLfoMeter() const noexcept     { return meterLfo.load(std::memory_order_relaxed); }
    float getEffectiveDelayMsL() const noexcept { return currentDelayMsL.load(std::memory_order_relaxed); }
    float getEffectiveDelayMsR() const noexcept { return currentDelayMsR.load(std::memory_order_relaxed); }

    static juce::AudioProcessorValueTreeState::ParameterLayout createParameterLayout();
    static const std::vector<tdelay::FactoryPreset>& getFactoryPresets();

private:
    void processAudioBlock(juce::AudioBuffer<float>&, bool hostBypassed);
    void loadAudioTargets(bool snap);
    float updateDelayTimes();
    enum {InputGain,OutputGain,Wet,Feedback,Width,LfoOn,FilterMix,HdMix,LeftOn,RightOn,LimiterMix,ParameterCount};
    std::array<double,ParameterCount> smooth {}, target {};
    double processingSampleRate=44100,parameterCoeff=.001,meterRelease=.001;
    double activeMix=1,routeMix=1,lfoSmooth=0;
    int filterControlCountdown=0,routingMode=0;
    bool routingInLoop=true;
    std::array<float,2> inputEnvelope {},outputEnvelope {};
    juce::AudioProcessorValueTreeState apvts;
    tak::license::LicenseManager licenseManager;
    std::atomic<bool> pluginUnlocked { true };

    tdelay::CPassFilters lowCutFilter;
    tdelay::CPassFilters highCutFilter;
    tdelay::COverdrive overdrive;
    tdelay::CDelayLine delayLine;
    tdelay::CLFO lfo;
    tdelay::CBrickWallLimiter brickWallLimiter;

    std::array<float, 2> feedbackSample {{ 0.0f, 0.0f }};
    int currentPresetIndex = 0;

    std::atomic<float> meterInL { 0.0f }, meterInR { 0.0f };
    std::atomic<float> meterOutL { 0.0f }, meterOutR { 0.0f };
    std::atomic<float> meterLfo { 0.0f };
    std::atomic<float> currentDelayMsL { 250.0f }, currentDelayMsR { 500.0f };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(TDelayAudioProcessor)
};
