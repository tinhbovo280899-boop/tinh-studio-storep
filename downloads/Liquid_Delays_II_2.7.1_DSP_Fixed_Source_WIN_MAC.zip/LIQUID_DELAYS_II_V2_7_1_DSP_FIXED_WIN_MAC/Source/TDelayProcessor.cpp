#include "TDelayProcessor.h"
#include "TDelayEditor.h"

namespace tdelay
{

static const std::vector<FactoryPreset> kPresets = {
    // Name, fxMode, inDb, outDb, mix, LOn, ROn, sync, LX, RX, LDot, RDot, LTri, RTri, tempo, fb, inLoop, fltOn, hdFlt, lowCut, highCut, res, drive, lfoOn, lfoSync, lfoRate, lfoDepth, lfoWave, width, limit
    { "01. Vocal Ping-Pong 1/8 - 1/4 (Bolero/Ballad)", 0, 0.0f, 0.0f, 32.0f, true, true, true, 4, 7, false, false, false, false, 120.0f, 36.0f, true,  true, true,  280.0f, 3800.0f, 25.0f, 18.0f, true,  false, 0.65f, 22.0f, 0, 100.0f, true },
    { "02. Liquid Warm Tape Echo (1/4D - 1/4)",        0, 0.0f, 0.0f, 35.0f, true, true, true, 7, 9, false, true,  false, false, 118.0f, 42.0f, true,  true, true,  340.0f, 2900.0f, 35.0f, 32.0f, true,  false, 0.85f, 30.0f, 0, 100.0f, true },
    { "03. Slapback Vocal Doubler (1/16 - 1/16D)",     2, 0.0f, 0.0f, 26.0f, true, true, true, 1, 3, false, true,  false, false, 125.0f, 18.0f, false, true, false, 180.0f, 6200.0f, 15.0f, 12.0f, true,  false, 1.40f, 18.0f, 1, 90.0f,  true },
    { "04. Nomad Factory Default (1/8T - 1/4)",        0, 0.0f, 0.0f, 35.0f, true, true, true, 2, 7, false, false, false, false, 120.0f, 33.0f, false, true, true,  800.2f, 2300.0f, 50.0f,  0.0f, false, false, 1.00f, 50.0f, 2, 100.0f, false },
    { "05. Wide Stereo Chorus Delay (Modulated)",      1, 0.0f, 0.0f, 38.0f, true, true, true, 4, 6, false, true,  false, false, 120.0f, 40.0f, true,  true, true,  220.0f, 4800.0f, 28.0f, 15.0f, true,  false, 0.55f, 48.0f, 0, 100.0f, true },
    { "06. Analog BBD Dark Vocal Tail",                5, 0.0f, 0.5f, 30.0f, true, true, true, 7, 7, true,  false, false, false, 110.0f, 48.0f, true,  true, true,  420.0f, 2100.0f, 42.0f, 28.0f, true,  false, 0.40f, 26.0f, 0, 95.0f,  true },
    { "07. Dub Reggae Resonant Filter Echo",           0, 0.0f, 0.0f, 45.0f, true, true, true, 6, 7, true,  false, false, false, 130.0f, 62.0f, true,  true, true,  650.0f, 1950.0f, 68.0f, 45.0f, true,  true,  0.35f, 40.0f, 1, 100.0f, true },
    { "08. Karaoke / Live Mic Sweetener",              2, 0.0f, 0.0f, 28.0f, true, true, true, 4, 7, false, false, false, false, 122.0f, 34.0f, true,  true, true,  260.0f, 4200.0f, 20.0f, 10.0f, false, false, 0.80f, 15.0f, 0, 100.0f, true },
    { "09. Tube Driven Rock Lead Delay",               4, 1.5f, 0.0f, 34.0f, true, true, true, 7, 9, false, true,  false, false, 128.0f, 38.0f, false, true, true,  310.0f, 3600.0f, 30.0f, 55.0f, false, false, 1.10f, 20.0f, 0, 100.0f, true },
    { "10. Shimmering Ambient 1/2 Bar Throws",         3, 0.0f, 0.0f, 42.0f, true, true, true, 9, 10, true, false, false, false, 100.0f, 54.0f, true,  true, true,  240.0f, 5400.0f, 22.0f, 14.0f, true,  false, 0.32f, 35.0f, 0, 100.0f, true },
    { "11. Triplet Groove Echo (1/8T - 1/4T)",         0, 0.0f, 0.0f, 33.0f, true, true, true, 2, 5, false, false, true,  true,  120.0f, 40.0f, true,  true, true,  300.0f, 3900.0f, 30.0f, 20.0f, false, false, 1.00f, 20.0f, 0, 100.0f, true },
    { "12. Lo-Fi Telephone Radio Echo",                0, 0.0f, 1.0f, 40.0f, true, true, true, 4, 4, false, false, false, false, 120.0f, 35.0f, false, true, true,  950.0f, 1850.0f, 55.0f, 60.0f, true,  false, 1.80f, 25.0f, 1, 65.0f,  true }
};

} // namespace tdelay

const std::vector<tdelay::FactoryPreset>& TDelayAudioProcessor::getFactoryPresets()
{
    return tdelay::kPresets;
}

juce::AudioProcessorValueTreeState::ParameterLayout TDelayAudioProcessor::createParameterLayout()
{
    std::vector<std::unique_ptr<juce::RangedAudioParameter>> params;

    juce::StringArray fxModes {
        "Filters -> Drive -> Delays",
        "Filters -> Delays -> Drive",
        "Delays -> Drive -> Filters",
        "Delays -> Filters -> Drive",
        "Drive -> Delays -> Filters",
        "Drive -> Filters -> Delays"
    };
    params.push_back(std::make_unique<juce::AudioParameterChoice>("fxMode", "FX Mode", fxModes, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "inputLevel", "Input Level",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "outputLevel", "Output Level",
        juce::NormalisableRange<float>(-24.0f, 24.0f, 0.1f), 0.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "mix", "Mix",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 32.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyLOn", "DLY L On/Off", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyROn", "DLY R On/Off", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlySync", "DLY Sync", true));

    juce::StringArray syncChoices;
    for (const auto& d : tdelay::kSyncDivisions)
        syncChoices.add(d.label);

    params.push_back(std::make_unique<juce::AudioParameterChoice>("dlyLXTime", "DLY L-XTime", syncChoices, 4));
    params.push_back(std::make_unique<juce::AudioParameterChoice>("dlyRXTime", "DLY R-XTime", syncChoices, 7));

    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyLDot", "DLY L-Dot", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyRDot", "DLY R-Dot", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyLTri", "DLY L-Tri", false));
    params.push_back(std::make_unique<juce::AudioParameterBool>("dlyRTri", "DLY R-Tri", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "dlyTempo", "DLY Tempo",
        juce::NormalisableRange<float>(40.0f, 500.0f, 0.1f), 120.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "dlyFeedback", "DLY Feedback",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 36.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("inLoop", "InLoop", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("filterOn", "Filter", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("hdFilter", "HDFilter", true));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lowCut", "Low Cut",
        juce::NormalisableRange<float>(22.0f, 11025.0f, 1.0f, 0.35f), 280.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "highCut", "High Cut",
        juce::NormalisableRange<float>(200.0f, 22050.0f, 1.0f, 0.35f), 3800.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "resonance", "Resonance",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 25.0f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "overdrive", "Overdrive",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 18.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("lfoOn", "LFO", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("lfoSync", "LFO Sync", false));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lfoRate", "LFO Rate",
        juce::NormalisableRange<float>(0.05f, 22.0f, 0.01f, 0.45f), 0.65f));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "lfoDepth", "LFO Depth",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 22.0f));

    juce::StringArray lfoWaves { "Sine", "Triangle", "Saw", "Square", "S&H" };
    params.push_back(std::make_unique<juce::AudioParameterChoice>("lfoWave", "LFO Wave", lfoWaves, 0));

    params.push_back(std::make_unique<juce::AudioParameterFloat>(
        "stereoWidth", "Stereo Width",
        juce::NormalisableRange<float>(0.0f, 100.0f, 0.1f), 100.0f));

    params.push_back(std::make_unique<juce::AudioParameterBool>("peakLimit", "PeakLimit", true));
    params.push_back(std::make_unique<juce::AudioParameterBool>("bypass", "Bypass", false));

    return { params.begin(), params.end() };
}

TDelayAudioProcessor::TDelayAudioProcessor()
    : AudioProcessor(BusesProperties()
                     .withInput("Input", juce::AudioChannelSet::stereo(), true)
                     .withOutput("Output", juce::AudioChannelSet::stereo(), true)),
      apvts(*this, nullptr, "TDelayParameters", createParameterLayout()),
      licenseManager(tak::license::productConfiguration(), tak::license::StorePaths::forProduct(tak::license::productConfiguration()), {}, true)
{
    refreshLicenseState();
    setCurrentProgram(0);
}

void TDelayAudioProcessor::prepareToPlay(double sampleRate, int samplesPerBlock)
{
    juce::ignoreUnused(samplesPerBlock);
    processingSampleRate=std::max(8000.0,sampleRate);
    parameterCoeff=-std::expm1(-1.0/(.020*processingSampleRate));
    meterRelease=std::exp(-1.0/(.15*processingSampleRate));
    lowCutFilter.prepare(sampleRate);highCutFilter.prepare(sampleRate);
    overdrive.setDrive(apvts.getRawParameterValue("overdrive")->load()*.01f);
    overdrive.prepare(sampleRate);delayLine.prepare(sampleRate);lfo.prepare(sampleRate);brickWallLimiter.prepare(sampleRate);
    updateDelayTimes();delayLine.snapToTarget();loadAudioTargets(true);
    routingMode=int(apvts.getRawParameterValue("fxMode")->load());
    routingInLoop=apvts.getRawParameterValue("inLoop")->load()>.5f;
    filterControlCountdown=0;routeMix=1;lfoSmooth=0;inputEnvelope.fill(0);outputEnvelope.fill(0);
    activeMix=apvts.getRawParameterValue("bypass")->load()>.5f?0:1;
}
void TDelayAudioProcessor::reset()
{
    delayLine.reset();delayLine.snapToTarget();lowCutFilter.reset();highCutFilter.reset();overdrive.reset();
    brickWallLimiter.reset();lfo.prepare(processingSampleRate);filterControlCountdown=0;lfoSmooth=0;
    inputEnvelope.fill(0);outputEnvelope.fill(0);meterInL.store(0);meterInR.store(0);meterOutL.store(0);meterOutR.store(0);
}
void TDelayAudioProcessor::releaseResources(){reset();}

bool TDelayAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    const auto out = layouts.getMainOutputChannelSet();
    const auto in  = layouts.getMainInputChannelSet();
    if (out != juce::AudioChannelSet::mono() && out != juce::AudioChannelSet::stereo())
        return false;
    return in == out || in == juce::AudioChannelSet::mono();
}

int TDelayAudioProcessor::getNumPrograms()
{
    return static_cast<int>(tdelay::kPresets.size());
}

const juce::String TDelayAudioProcessor::getProgramName(int index)
{
    if (index >= 0 && index < static_cast<int>(tdelay::kPresets.size()))
        return juce::String::fromUTF8(tdelay::kPresets[static_cast<size_t>(index)].name);
    return {};
}

void TDelayAudioProcessor::changeProgramName(int, const juce::String&) {}

void TDelayAudioProcessor::setCurrentProgram(int index)
{
    if (index < 0 || index >= static_cast<int>(tdelay::kPresets.size()))
        return;
    currentPresetIndex = index;
    const auto& p = tdelay::kPresets[static_cast<size_t>(index)];

    auto setVal = [this](const char* id, float plainVal)
    {
        if (auto* param = apvts.getParameter(id))
            param->setValueNotifyingHost(param->convertTo0to1(plainVal));
    };

    setVal("fxMode",      static_cast<float>(p.fxMode));
    setVal("inputLevel",  p.inputDb);
    setVal("outputLevel", p.outputDb);
    setVal("mix",         p.mixPct);
    setVal("dlyLOn",      p.dlyLOn ? 1.0f : 0.0f);
    setVal("dlyROn",      p.dlyROn ? 1.0f : 0.0f);
    setVal("dlySync",     p.dlySync ? 1.0f : 0.0f);
    setVal("dlyLXTime",   static_cast<float>(p.dlyLXTime));
    setVal("dlyRXTime",   static_cast<float>(p.dlyRXTime));
    setVal("dlyLDot",     p.dlyLDot ? 1.0f : 0.0f);
    setVal("dlyRDot",     p.dlyRDot ? 1.0f : 0.0f);
    setVal("dlyLTri",     p.dlyLTri ? 1.0f : 0.0f);
    setVal("dlyRTri",     p.dlyRTri ? 1.0f : 0.0f);
    setVal("dlyTempo",    p.dlyTempo);
    setVal("dlyFeedback", p.dlyFeedback);
    setVal("inLoop",      p.inLoop ? 1.0f : 0.0f);
    setVal("filterOn",    p.filterOn ? 1.0f : 0.0f);
    setVal("hdFilter",    p.hdFilter ? 1.0f : 0.0f);
    setVal("lowCut",      p.lowCutHz);
    setVal("highCut",     p.highCutHz);
    setVal("resonance",   p.resonancePct);
    setVal("overdrive",   p.overdrivePct);
    setVal("lfoOn",       p.lfoOn ? 1.0f : 0.0f);
    setVal("lfoSync",     p.lfoSync ? 1.0f : 0.0f);
    setVal("lfoRate",     p.lfoRateHz);
    setVal("lfoDepth",    p.lfoDepthPct);
    setVal("lfoWave",     static_cast<float>(p.lfoWave));
    setVal("stereoWidth", p.stereoWidth);
    setVal("peakLimit",   p.peakLimit ? 1.0f : 0.0f);
}

void TDelayAudioProcessor::loadAudioTargets(bool snap)
{
    auto value=[this](const char* id){return double(apvts.getRawParameterValue(id)->load());};
    target={{std::pow(10.0,value("inputLevel")/20),std::pow(10.0,value("outputLevel")/20),value("mix")*.01,
        std::clamp(value("dlyFeedback")*.0096,0.0,.96),value("stereoWidth")*.01,value("lfoOn"),value("filterOn"),value("hdFilter"),
        value("dlyLOn"),value("dlyROn"),value("peakLimit")}};
    if(snap)smooth=target;
}
float TDelayAudioProcessor::updateDelayTimes()
{
    auto value=[this](const char* id){return apvts.getRawParameterValue(id)->load();};
    float bpm=value("dlyTempo");
    if(value("dlySync")>.5f || value("lfoSync")>.5f)
        if(auto* head=getPlayHead())if(auto pos=head->getPosition())if(auto tempo=pos->getBpm())
            if(std::isfinite(*tempo) && *tempo>=30 && *tempo<=500)bpm=float(*tempo);
    const double bar=240000/std::clamp(double(bpm),40.0,500.0);
    for(int c=0;c<2;++c)
    {
        const int index=juce::jlimit(0,21,int(value(c==0?"dlyLXTime":"dlyRXTime")));
        double ms=bar*tdelay::kSyncDivisions[std::size_t(index)].wholeBarRatio;
        if(value(c==0?"dlyLDot":"dlyRDot")>.5f)ms*=1.5;
        if(value(c==0?"dlyLTri":"dlyRTri")>.5f)ms*=2.0/3;
        ms=std::clamp(ms,1.0,15000.0);delayLine.setTargetDelayMs(c,ms);
        (c==0?currentDelayMsL:currentDelayMsR).store(float(ms),std::memory_order_relaxed);
    }
    return bpm;
}
double TDelayAudioProcessor::getTailLengthSeconds() const
{
    const double delay=.001*std::max(currentDelayMsL.load(),currentDelayMsR.load())+.0024;
    const double fb=std::clamp(double(apvts.getRawParameterValue("dlyFeedback")->load())*.0096,0.0,.96);
    const double repeats=fb>1e-6?1+std::ceil(std::log(1e-5)/std::log(fb)):1;
    return delay*repeats+2; // includes filter/drive settling; no fixed 4 s truncation
}
void TDelayAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&)
{processAudioBlock(buffer,false);}
void TDelayAudioProcessor::processBlockBypassed(juce::AudioBuffer<float>& buffer,juce::MidiBuffer&)
{processAudioBlock(buffer,true);}
void TDelayAudioProcessor::processAudioBlock(juce::AudioBuffer<float>& buffer,bool hostBypassed)
{
    juce::ScopedNoDenormals noDenormals;
    const int channels=buffer.getNumChannels(),samples=buffer.getNumSamples();
    if(samples<=0 || channels<=0)return;
    for(int c=getTotalNumInputChannels();c<getTotalNumOutputChannels();++c)buffer.clear(c,0,samples);
    if(!licenseManager.isAllowed()){buffer.clear();meterInL.store(0);meterInR.store(0);meterOutL.store(0);meterOutR.store(0);return;}
    auto value=[this](const char* id){return apvts.getRawParameterValue(id)->load();};
    loadAudioTargets(false);
    const bool bypass=hostBypassed || value("bypass")>.5f;
    const int wantedMode=juce::jlimit(0,5,int(value("fxMode")));const bool wantedLoop=value("inLoop")>.5f;
    const double lowCut=value("lowCut"),highCut=value("highCut"),resonance=value("resonance");
    const float bpm=updateDelayTimes();
    const float rate=value("lfoSync")>.5f?juce::jlimit(.05f,22.f,bpm/120):value("lfoRate");
    lfo.setParameters(rate,value("lfoDepth"),int(value("lfoWave")));overdrive.setDrive(value("overdrive")*.01f);
    float* left=buffer.getWritePointer(0);float* right=channels>1?buffer.getWritePointer(1):nullptr;
    const bool monoInput=getTotalNumInputChannels()==1;
    const double fadeStep=1/(.005*processingSampleRate);
    const double lfoCoeff=-std::expm1(-1.0/(.001*processingSampleRate));
    float lastLfo=0;
    for(int i=0;i<samples;++i)
    {
        for(std::size_t k=0;k<smooth.size();++k){smooth[k]+=parameterCoeff*(target[k]-smooth[k]);if(std::abs(target[k]-smooth[k])<1e-10)smooth[k]=target[k];}
        activeMix+=std::clamp((bypass?0.0:1.0)-activeMix,-fadeStep,fadeStep);
        const bool pendingRoute=wantedMode!=routingMode || wantedLoop!=routingInLoop;
        routeMix+=std::clamp((pendingRoute?0.0:1.0)-routeMix,-fadeStep,fadeStep);
        if(pendingRoute && routeMix<=0){routingMode=wantedMode;routingInLoop=wantedLoop;lowCutFilter.reset();highCutFilter.reset();overdrive.reset();}
        lfoSmooth+=lfoCoeff*(lfo.tick()-lfoSmooth);
        lastLfo=float(lfoSmooth*smooth[LfoOn]);
        // A fixed 64-sample control clock, independent of host block size.
        if(filterControlCountdown==0)
        {
            const double factor=std::exp2(double(lastLfo)*.65);
            lowCutFilter.setCoefficients(lowCut*factor,resonance,true,64);
            highCutFilter.setCoefficients(highCut*factor,resonance,false,64);
            filterControlCountdown=64;
        }
        --filterControlCountdown;lowCutFilter.advance();highCutFilter.advance();overdrive.advance();
        const float rawL=left[i],rawR=(!monoInput && right)?right[i]:rawL;
        const std::array<float,2> dry{{rawL,rawR}},input{{float(rawL*smooth[InputGain]),float(rawR*smooth[InputGain])}};
        const float mod=float(lastLfo*.0024*processingSampleRate);
        const float tapL=delayLine.readSample(0,mod),tapR=delayLine.readSample(1,-mod);
        auto filter=[&](int c,float x){float y=lowCutFilter.processSample(c,x,smooth[HdMix]);y=highCutFilter.processSample(c,y,smooth[HdMix]);return float((1-smooth[FilterMix])*x+smooth[FilterMix]*y);};
        auto drive=[&](int c,float x){return overdrive.processSample(c,x);};
        const double filterBound=1+smooth[FilterMix]*(lowCutFilter.getPeakGainBound()*highCutFilter.getPeakGainBound()-1);
        const double loopScale=1/(filterBound*overdrive.getFeedbackGainBound());
        std::array<float,2> wet {};
        for(int c=0;c<2;++c)
        {
            const float tap=c==0?tapL:tapR,cross=c==0?tapR:tapL;
            auto delay=[&](float x){
                float fb=float((.84*tap+.16*cross)*smooth[Feedback]);
                if(routingInLoop)
                {
                    const bool filterFirst=routingMode==0 || routingMode==1 || routingMode==3;
                    fb=filterFirst?drive(c,filter(c,fb)):filter(c,drive(c,fb));
                    fb=float(fb*loopScale);
                }
                delayLine.writeSample(c,x+fb);
                return float(tap*smooth[c==0?LeftOn:RightOn]);
            };
            float x=input[std::size_t(c)];
            switch(routingMode)
            {
                case 0:if(!routingInLoop)x=drive(c,filter(c,x));x=delay(x);break;
                case 1:if(!routingInLoop)x=filter(c,x);x=delay(x);if(!routingInLoop)x=drive(c,x);break;
                case 2:x=delay(x);if(!routingInLoop)x=filter(c,drive(c,x));break;
                case 3:x=delay(x);if(!routingInLoop)x=drive(c,filter(c,x));break;
                case 4:if(!routingInLoop)x=drive(c,x);x=delay(x);if(!routingInLoop)x=filter(c,x);break;
                default:if(!routingInLoop)x=filter(c,drive(c,x));x=delay(x);break;
            }
            wet[std::size_t(c)]=float(x*smooth[OutputGain]*routeMix);
        }
        const double mid=.5*(wet[0]+wet[1]),side=.5*(wet[0]-wet[1])*smooth[Width];
        const std::array<double,2> stereo{{mid+side,mid-side}};
        for(int c=0;c<2;++c)
        {
            double y=(1-smooth[Wet])*dry[std::size_t(c)]+smooth[Wet]*stereo[std::size_t(c)];
            const float limited=brickWallLimiter.processSample(c,float(y),true);
            y=(1-smooth[LimiterMix])*y+smooth[LimiterMix]*limited;
            const float out=float((1-activeMix)*dry[std::size_t(c)]+activeMix*y);
            if(c==0)left[i]=out;else if(right)right[i]=out;
            inputEnvelope[std::size_t(c)]=std::max(std::abs(input[std::size_t(c)]),float(inputEnvelope[std::size_t(c)]*meterRelease));
            outputEnvelope[std::size_t(c)]=std::max(std::abs(out),float(outputEnvelope[std::size_t(c)]*meterRelease));
        }
    }
    meterInL.store(inputEnvelope[0],std::memory_order_relaxed);meterInR.store(inputEnvelope[1],std::memory_order_relaxed);
    meterOutL.store(outputEnvelope[0],std::memory_order_relaxed);meterOutR.store(outputEnvelope[1],std::memory_order_relaxed);meterLfo.store(lastLfo,std::memory_order_relaxed);
}

juce::AudioProcessorEditor* TDelayAudioProcessor::createEditor()
{
    return new TDelayAudioProcessorEditor(*this);
}

void TDelayAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    std::unique_ptr<juce::XmlElement> xml(state.createXml());
    copyXmlToBinary(*xml, destData);
}

void TDelayAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    std::unique_ptr<juce::XmlElement> xmlState(getXmlFromBinary(data, sizeInBytes));
    if (xmlState != nullptr && xmlState->hasTagName(apvts.state.getType()))
        apvts.replaceState(juce::ValueTree::fromXml(*xmlState));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new TDelayAudioProcessor();
}

void TDelayAudioProcessor::refreshLicenseState()
{
    licenseManager.poll();
    pluginUnlocked.store(licenseManager.isAllowed(), std::memory_order_relaxed);
}
