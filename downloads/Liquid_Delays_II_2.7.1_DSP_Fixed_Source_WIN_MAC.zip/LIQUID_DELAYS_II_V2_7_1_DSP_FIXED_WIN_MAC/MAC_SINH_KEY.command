#!/bin/bash
set -eu
ROOT="$(cd "$(dirname "$0")" && pwd -P)"
TOOL="$ROOT/build_mac_universal/OwnerTools/Release/LiquidDelaysIIOwnerKeygen"
[[ -x "$TOOL" ]] || { echo 'Build plugin truoc bang MAC_1_BUILD_VA_TAO_BO_CAI.command';exit 1; }
bash "$ROOT/tools/mac.sh" Check
printf '1. Tao cap khoa MOI + cap nhat public header (can rebuild; khong thay khoa cu cua khach)\n2. Sinh TAK1 tu private key hien co va phieu ma may\n0. Thoat\n'
read -r choice
case "$choice" in
1) read -r -p 'Thu muc luu khoa CHU moi: ' directory;"$TOOL" --new-keys --dir "$directory" --source "$ROOT";;
2) read -r -p 'PRIVATE_KEY.txt: ' private
   read -r -p 'Phieu ma may: ' request
   read -r -p 'Ten khach: ' owner
   read -r -p 'So ngay (0 = vinh vien): ' days
   read -r -p 'File .taklic moi: ' output
   "$TOOL" --request "$request" --private "$private" --owner "$owner" --days "$days" --out "$output";;
*) echo 'Khong thay doi gi.';;
esac
